# LMG .dk Image Bank

WordPress plugin for traveltalk.travel: a ".dk image bank" tab in the media window that searches traveltalk.dk's media library and copies a chosen image here once (title, alt, caption, credit), deduplicated with LMG Translator's picture copy.

Optional wp-config.php overrides: `LMG_DKIB_SOURCE`, `LMG_DKIB_USER`, `LMG_DKIB_PASS`. Otherwise the Translator bridge peer and login are used.
