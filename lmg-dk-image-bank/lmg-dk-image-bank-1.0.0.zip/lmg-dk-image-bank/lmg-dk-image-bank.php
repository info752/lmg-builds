<?php
/**
 * Plugin Name: LMG .dk Image Bank
 * Description: Adds a ".dk image bank" tab to the media window on traveltalk.travel. Search traveltalk.dk's media library and use any image; it is copied here once, with title, alt text, caption and credit.
 * Version:     1.0.0
 * Author:      Leisure Media Group
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'LMG_DKIB_VERSION', '1.0.0' );
define( 'LMG_DKIB_FILE', __FILE__ );
define( 'LMG_DKIB_DIR', plugin_dir_path( __FILE__ ) );

/**
 * Source: LMG_DKIB_SOURCE in wp-config.php, else the Translator bridge peer
 * (on .travel), else https://traveltalk.dk. Login: LMG_DKIB_USER / LMG_DKIB_PASS,
 * else the Translator bridge login, else none (the public media API).
 *
 * Meta on an imported attachment:
 *   _lmgt_imported_from  canonical .dk file address (shared with Translator's picture copy)
 *   _lmg_dkib_id         attachment ID on .dk
 *   _lmg_dkib_credit     credit as on .dk
 *   _lmg_dkib_original   [title, alt, caption] in Danish, when the texts were translated
 */
class LMG_DKIB {

	const OPT      = 'lmg_dkib_settings';
	const PER_PAGE = 40;
	const FIELDS   = 'id,date,title,alt_text,caption,mime_type,source_url,media_details';

	public static function boot() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
		add_action( 'wp_ajax_lmg_dkib_notes_seen', function () {
			check_ajax_referer( 'lmg_dkib_notes_seen' );
			update_user_meta( get_current_user_id(), 'lmg_dkib_notes_seen', LMG_DKIB_VERSION );
			wp_send_json_success();
		} );
		if ( self::is_source_site() ) return;
		add_action( 'wp_enqueue_media', array( __CLASS__, 'assets' ) );
		add_action( 'wp_ajax_lmg_dkib_search', array( __CLASS__, 'ajax_search' ) );
		add_action( 'wp_ajax_lmg_dkib_import', array( __CLASS__, 'ajax_import' ) );
	}

	// ---- source and login ---------------------------------------------------

	public static function source() {
		if ( defined( 'LMG_DKIB_SOURCE' ) ) return untrailingslashit( (string) LMG_DKIB_SOURCE );
		if ( class_exists( 'LMGT_Bridge' ) && LMGT_Bridge::is_target() && LMGT_Bridge::peer() ) return untrailingslashit( LMGT_Bridge::peer() );
		return 'https://traveltalk.dk';
	}

	private static function host( $url ) {
		return preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) ) );
	}

	public static function is_source_site() {
		return self::host( home_url() ) === self::host( self::source() );
	}

	private static function login() {
		if ( defined( 'LMG_DKIB_USER' ) && defined( 'LMG_DKIB_PASS' ) ) return array( (string) LMG_DKIB_USER, (string) LMG_DKIB_PASS );
		if ( class_exists( 'LMGT_Bridge' ) && LMGT_Bridge::is_target() && LMGT_Bridge::peer_user() !== '' && LMGT_Bridge::peer_pass() !== '' ) {
			return array( LMGT_Bridge::peer_user(), LMGT_Bridge::peer_pass() );
		}
		return null;
	}

	public static function settings() {
		return wp_parse_args( (array) get_option( self::OPT, array() ), array( 'translate' => 1 ) );
	}

	/** GET on the source's media API. Returns [data, headers] or WP_Error. */
	private static function get( $path, array $query = array() ) {
		$url  = add_query_arg( $query, self::source() . '/wp-json/wp/v2/media' . $path );
		$args = array( 'timeout' => 25, 'headers' => array( 'Accept' => 'application/json' ) );
		$auth = self::login();
		if ( $auth ) {
			$b = base64_encode( $auth[0] . ':' . str_replace( ' ', '', $auth[1] ) );
			$args['headers']['Authorization'] = 'Basic ' . $b;
			$args['headers']['X-LMGT-Auth']   = $b;
		}
		$r    = wp_remote_get( $url, $args );
		$code = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
		if ( $auth && in_array( $code, array( 401, 403 ), true ) ) {
			unset( $args['headers']['Authorization'], $args['headers']['X-LMGT-Auth'] );
			$r    = wp_remote_get( $url, $args );
			$code = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
		}
		if ( in_array( $code, array( 429, 503, 508 ), true ) ) {
			sleep( 3 );
			$r    = wp_remote_get( $url, $args );
			$code = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
		}
		if ( is_wp_error( $r ) ) return new WP_Error( 'lmg_dkib', sprintf( 'Could not reach %s: %s', self::host( self::source() ), $r->get_error_message() ) );
		$data = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( $code < 200 || $code >= 300 || ! is_array( $data ) ) {
			$msg = is_array( $data ) && isset( $data['message'] ) ? wp_strip_all_tags( $data['message'] ) : 'HTTP ' . $code;
			return new WP_Error( 'lmg_dkib', sprintf( '%s answered: %s', self::host( self::source() ), $msg ) );
		}
		return array( $data, wp_remote_retrieve_headers( $r ) );
	}

	// ---- shape of one .dk image ---------------------------------------------

	/** Same key as Translator's picture copy, so an image it already copied is reused. */
	public static function canon( $url ) {
		if ( class_exists( 'LMGT_LocalPics' ) && method_exists( 'LMGT_LocalPics', 'canon' ) ) return LMGT_LocalPics::canon( $url )[0];
		$url = preg_replace( '/[?#].*$/', '', (string) $url );
		$url = preg_replace( '#^http://#i', 'https://', $url );
		$url = preg_replace( '#^(https://)www\.#i', '$1', $url );
		if ( preg_match( '/^(.*)-(\d{2,5})x(\d{2,5})(\.[A-Za-z0-9]{2,5})$/', $url, $m ) ) $url = $m[1] . $m[4];
		return $url;
	}

	private static function plain( $v ) {
		if ( is_array( $v ) ) $v = isset( $v['raw'] ) ? $v['raw'] : ( isset( $v['rendered'] ) ? $v['rendered'] : '' );
		return trim( html_entity_decode( wp_strip_all_tags( (string) $v ), ENT_QUOTES, 'UTF-8' ) );
	}

	private static function item( array $m ) {
		$d     = isset( $m['media_details'] ) && is_array( $m['media_details'] ) ? $m['media_details'] : array();
		$sizes = isset( $d['sizes'] ) && is_array( $d['sizes'] ) ? $d['sizes'] : array();
		$thumb = '';
		foreach ( array( 'medium', 'medium_large', 'thumbnail', 'large' ) as $s ) {
			if ( ! empty( $sizes[ $s ]['source_url'] ) ) { $thumb = $sizes[ $s ]['source_url']; break; }
		}
		$meta   = isset( $d['image_meta'] ) && is_array( $d['image_meta'] ) ? $d['image_meta'] : array();
		$credit = trim( (string) ( ! empty( $meta['credit'] ) ? $meta['credit'] : ( ! empty( $meta['copyright'] ) ? $meta['copyright'] : '' ) ) );
		$src    = (string) ( isset( $m['source_url'] ) ? $m['source_url'] : '' );
		return array(
			'id'      => (int) $m['id'],
			'date'    => isset( $m['date'] ) ? substr( (string) $m['date'], 0, 10 ) : '',
			'title'   => self::plain( isset( $m['title'] ) ? $m['title'] : '' ),
			'alt'     => self::plain( isset( $m['alt_text'] ) ? $m['alt_text'] : '' ),
			'caption' => self::plain( isset( $m['caption'] ) ? $m['caption'] : '' ),
			'credit'  => $credit,
			'mime'    => (string) ( isset( $m['mime_type'] ) ? $m['mime_type'] : '' ),
			'src'     => $src,
			'thumb'   => $thumb !== '' ? $thumb : $src,
			'width'   => isset( $d['width'] ) ? (int) $d['width'] : 0,
			'height'  => isset( $d['height'] ) ? (int) $d['height'] : 0,
			'key'     => self::canon( $src ),
		);
	}

	/** Local attachment already made from this .dk image, or 0. */
	public static function existing( $dk_id, $key ) {
		$q = array( 'post_type' => 'attachment', 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => true );
		$ids = get_posts( $q + array( 'meta_key' => '_lmg_dkib_id', 'meta_value' => (string) (int) $dk_id ) );
		if ( ! $ids && $key !== '' ) $ids = get_posts( $q + array( 'meta_key' => '_lmgt_imported_from', 'meta_value' => $key ) );
		return $ids ? (int) $ids[0] : 0;
	}

	/** [key => local ID] for a page of results, in one query. */
	private static function imported_map( array $items ) {
		global $wpdb;
		$keys = array_values( array_filter( wp_list_pluck( $items, 'key' ) ) );
		$ids  = array_map( 'strval', wp_list_pluck( $items, 'id' ) );
		$map  = array();
		if ( $keys ) {
			$ph   = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_lmgt_imported_from' AND meta_value IN ($ph)", $keys ) );
			foreach ( $rows as $r ) $map[ 'k' . $r->meta_value ] = (int) $r->post_id;
		}
		if ( $ids ) {
			$ph   = implode( ',', array_fill( 0, count( $ids ), '%s' ) );
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_lmg_dkib_id' AND meta_value IN ($ph)", $ids ) );
			foreach ( $rows as $r ) $map[ 'i' . $r->meta_value ] = (int) $r->post_id;
		}
		return $map;
	}

	// ---- AJAX -----------------------------------------------------------------

	public static function ajax_search() {
		check_ajax_referer( 'lmg_dkib' );
		if ( ! current_user_can( 'upload_files' ) ) wp_send_json_error( array( 'message' => 'You may not add media on this site.' ), 403 );
		$q    = isset( $_POST['q'] ) ? sanitize_text_field( wp_unslash( $_POST['q'] ) ) : '';
		$page = max( 1, isset( $_POST['page'] ) ? (int) $_POST['page'] : 1 );
		$tkey = 'lmg_dkib_' . md5( $q . '|' . $page );
		$res  = get_transient( $tkey );
		if ( ! is_array( $res ) ) {
			$query = array( 'media_type' => 'image', 'per_page' => self::PER_PAGE, 'page' => $page, 'orderby' => 'date', 'order' => 'desc', '_fields' => self::FIELDS );
			if ( $q !== '' ) { $query['search'] = $q; unset( $query['orderby'] ); }
			$r = self::get( '', $query );
			if ( is_wp_error( $r ) ) {
				// Past the last page the API answers 400.
				if ( $page > 1 && strpos( $r->get_error_message(), 'page number' ) !== false ) wp_send_json_success( array( 'items' => array(), 'pages' => $page - 1, 'total' => 0 ) );
				wp_send_json_error( array( 'message' => $r->get_error_message() ) );
			}
			list( $data, $h ) = $r;
			$items = array();
			foreach ( $data as $m ) {
				if ( is_array( $m ) && isset( $m['id'] ) && strpos( (string) ( isset( $m['mime_type'] ) ? $m['mime_type'] : 'image/' ), 'image/' ) === 0 ) $items[] = self::item( $m );
			}
			$res = array( 'items' => $items, 'pages' => (int) ( isset( $h['x-wp-totalpages'] ) ? $h['x-wp-totalpages'] : 1 ), 'total' => (int) ( isset( $h['x-wp-total'] ) ? $h['x-wp-total'] : count( $items ) ) );
			set_transient( $tkey, $res, 10 * MINUTE_IN_SECONDS );
		}
		$map = self::imported_map( $res['items'] );
		foreach ( $res['items'] as &$it ) {
			$it['local'] = isset( $map[ 'i' . $it['id'] ] ) ? $map[ 'i' . $it['id'] ] : ( isset( $map[ 'k' . $it['key'] ] ) ? $map[ 'k' . $it['key'] ] : 0 );
		}
		unset( $it );
		wp_send_json_success( $res );
	}

	public static function ajax_import() {
		check_ajax_referer( 'lmg_dkib' );
		if ( ! current_user_can( 'upload_files' ) ) wp_send_json_error( array( 'message' => 'You may not add media on this site.' ), 403 );
		$dk_id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		$post  = isset( $_POST['post'] ) ? (int) $_POST['post'] : 0;
		if ( $post && ! current_user_can( 'edit_post', $post ) ) $post = 0;
		if ( $dk_id <= 0 ) wp_send_json_error( array( 'message' => 'No image chosen.' ) );
		$id = self::import( $dk_id, $post );
		if ( is_wp_error( $id ) ) wp_send_json_error( array( 'message' => $id->get_error_message() ) );
		$js = wp_prepare_attachment_for_js( $id );
		if ( ! $js ) wp_send_json_error( array( 'message' => 'The image was copied but could not be loaded.' ) );
		wp_send_json_success( $js );
	}

	/** Copy one .dk image here, or return the copy made earlier. */
	public static function import( $dk_id, $post_id = 0 ) {
		$r = self::get( '/' . (int) $dk_id, array( '_fields' => self::FIELDS ) );
		if ( is_wp_error( $r ) ) return $r;
		$it = self::item( $r[0] );
		if ( strpos( $it['mime'], 'image/' ) !== 0 || $it['src'] === '' ) return new WP_Error( 'lmg_dkib', 'That is not an image.' );
		if ( self::host( $it['src'] ) !== self::host( self::source() ) ) return new WP_Error( 'lmg_dkib', 'The image file is not on ' . self::host( self::source() ) . '.' );

		$have = self::existing( $it['id'], $it['key'] );
		if ( $have ) {
			if ( ! get_post_meta( $have, '_lmg_dkib_id', true ) ) update_post_meta( $have, '_lmg_dkib_id', (string) $it['id'] );
			return $have;
		}

		$texts = array( 'title' => $it['title'], 'alt' => $it['alt'], 'caption' => $it['caption'] );
		$orig  = $texts;
		if ( self::settings()['translate'] ) $texts = self::translate( $texts );

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$tmp = download_url( $it['src'], 90 );
		if ( is_wp_error( $tmp ) && preg_match( '/\b5\d\d\b/', $tmp->get_error_message() ) ) { sleep( 3 ); $tmp = download_url( $it['src'], 90 ); }
		if ( is_wp_error( $tmp ) ) return new WP_Error( 'lmg_dkib', 'Download failed: ' . $tmp->get_error_message() );

		$name = sanitize_file_name( wp_basename( (string) wp_parse_url( $it['src'], PHP_URL_PATH ) ) );
		$name = preg_replace( '/-scaled(\.[a-z0-9]+)$/i', '$1', $name );
		$data = array( 'post_title' => $texts['title'] !== '' ? $texts['title'] : pathinfo( $name, PATHINFO_FILENAME ), 'post_excerpt' => $texts['caption'] );
		$id   = media_handle_sideload( array( 'name' => $name, 'tmp_name' => $tmp ), (int) $post_id, null, $data );
		if ( is_wp_error( $id ) ) { if ( file_exists( $tmp ) ) @unlink( $tmp ); return $id; }

		update_post_meta( $id, '_lmgt_imported_from', $it['key'] );
		update_post_meta( $id, '_lmg_dkib_id', (string) $it['id'] );
		if ( $texts['alt'] !== '' ) update_post_meta( $id, '_wp_attachment_image_alt', $texts['alt'] );
		if ( $texts !== $orig ) update_post_meta( $id, '_lmg_dkib_original', $orig );
		if ( $it['credit'] !== '' ) {
			update_post_meta( $id, '_lmg_dkib_credit', $it['credit'] );
			$meta = wp_get_attachment_metadata( $id );
			if ( is_array( $meta ) ) {
				if ( empty( $meta['image_meta'] ) || ! is_array( $meta['image_meta'] ) ) $meta['image_meta'] = array();
				if ( empty( $meta['image_meta']['credit'] ) ) {
					$meta['image_meta']['credit'] = $it['credit'];
					wp_update_attachment_metadata( $id, $meta );
				}
			}
		}
		return (int) $id;
	}

	/** Danish texts into this site's language with Translator's DeepL key; unchanged when that is not possible. */
	private static function translate( array $texts ) {
		if ( ! class_exists( 'LMGT_Engines' ) || ! method_exists( 'LMGT_Engines', 'deepl_available' ) || ! LMGT_Engines::deepl_available() ) return $texts;
		$to = strtolower( substr( get_locale(), 0, 2 ) );
		if ( $to === 'da' || ( class_exists( 'LMGT_Langs' ) && ! LMGT_Langs::get( $to ) ) ) return $texts;
		$keys = array_keys( array_filter( $texts, 'strlen' ) );
		if ( ! $keys ) return $texts;
		$r = LMGT_Engines::deepl( array_values( array_intersect_key( $texts, array_flip( $keys ) ) ), 'da', $to );
		if ( is_wp_error( $r ) || empty( $r['texts'] ) || count( $r['texts'] ) !== count( $keys ) ) return $texts;
		foreach ( $keys as $i => $k ) {
			$t = trim( wp_strip_all_tags( (string) $r['texts'][ $i ] ) );
			if ( $t !== '' ) $texts[ $k ] = $t;
		}
		return $texts;
	}

	// ---- media window -------------------------------------------------------

	public static function assets() {
		if ( ! current_user_can( 'upload_files' ) ) return;
		$u = plugin_dir_url( __FILE__ ) . 'assets/';
		wp_enqueue_style( 'lmg-dkib', $u . 'dkib.css', array(), LMG_DKIB_VERSION );
		wp_enqueue_script( 'lmg-dkib', $u . 'dkib.js', array( 'jquery', 'media-views' ), LMG_DKIB_VERSION, true );
		wp_localize_script( 'lmg-dkib', 'LMG_DKIB', array(
			'ajax'     => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'lmg_dkib' ),
			'tab'      => '.dk image bank',
			'source'   => self::host( self::source() ),
			'search'   => 'Search traveltalk.dk images (Danish words work best)',
			'more'     => 'Show more',
			'use'      => 'Use this image',
			'here'     => 'Already on this site',
			'working'  => 'Copying…',
			'none'     => 'No images found.',
			'latest'   => 'Newest images on traveltalk.dk',
			'help'     => 'Click an image to copy it here. It then opens selected in the Media Library tab, ready to insert or set as featured image.',
			'loading'  => 'Loading…',
		) );
	}

	// ---- admin page and notes -------------------------------------------------

	public static function menu() {
		add_media_page( '.dk image bank', '.dk image bank', 'upload_files', 'lmg-dkib', array( __CLASS__, 'page' ) );
	}

	public static function notice() {
		if ( ! current_user_can( 'upload_files' ) || get_user_meta( get_current_user_id(), 'lmg_dkib_notes_seen', true ) === LMG_DKIB_VERSION ) return;
		if ( isset( $_GET['page'] ) && $_GET['page'] === 'lmg-dkib' ) return;
		echo '<div class="notice notice-info is-dismissible" id="lmg-dkib-notice"><p>LMG .dk Image Bank ' . esc_html( LMG_DKIB_VERSION ) . ' is installed. <a href="' . esc_url( admin_url( 'upload.php?page=lmg-dkib' ) ) . '">What is new</a></p></div>';
		echo "<script>jQuery(document).on('click','#lmg-dkib-notice .notice-dismiss',function(){jQuery.post(ajaxurl,{action:'lmg_dkib_notes_seen',_ajax_nonce:'" . esc_js( wp_create_nonce( 'lmg_dkib_notes_seen' ) ) . "'});});</script>";
	}

	public static function page() {
		update_user_meta( get_current_user_id(), 'lmg_dkib_notes_seen', LMG_DKIB_VERSION );
		$admin = current_user_can( 'manage_options' );
		if ( $admin && isset( $_POST['lmg_dkib_save'] ) && check_admin_referer( 'lmg_dkib_settings' ) ) {
			update_option( self::OPT, array( 'translate' => empty( $_POST['translate'] ) ? 0 : 1 ) );
			echo '<div class="notice notice-success is-dismissible"><p>Saved.</p></div>';
		}
		$s = self::settings();
		echo '<div class="wrap" style="max-width:820px"><h1>.dk image bank</h1>';
		if ( self::is_source_site() ) {
			echo '<div class="notice notice-warning inline"><p>This is ' . esc_html( self::host( self::source() ) ) . ' itself, so the image bank tab is off here. Install the plugin on traveltalk.travel.</p></div></div>';
			return;
		}
		$t = self::get( '', array( 'media_type' => 'image', 'per_page' => 1, '_fields' => 'id' ) );
		$deepl = class_exists( 'LMGT_Engines' ) && method_exists( 'LMGT_Engines', 'deepl_available' ) && LMGT_Engines::deepl_available();
		echo '<table class="widefat striped" style="margin:1em 0"><tbody>';
		echo '<tr><th style="width:34%">Image bank</th><td>' . esc_html( self::source() ) . '</td></tr>';
		echo '<tr><th>Connection</th><td>' . ( is_wp_error( $t ) ? '<span style="color:#b32d2e">' . esc_html( $t->get_error_message() ) . '</span>' : '<span style="color:#008a20">OK, ' . esc_html( number_format_i18n( (int) ( isset( $t[1]['x-wp-total'] ) ? $t[1]['x-wp-total'] : 0 ) ) ) . ' images</span>' ) . '</td></tr>';
		echo '<tr><th>Login</th><td>' . ( self::login() ? 'Translator bridge login' : 'None (public images only)' ) . '</td></tr>';
		echo '<tr><th>Translation of texts</th><td>' . ( $deepl ? 'DeepL via LMG Translator' : 'Not available here (no DeepL key in LMG Translator on this site): texts stay in Danish' ) . '</td></tr>';
		echo '</tbody></table>';
		if ( $admin ) {
			echo '<form method="post">';
			wp_nonce_field( 'lmg_dkib_settings' );
			echo '<p><label><input type="checkbox" name="translate" value="1"' . checked( $s['translate'], 1, false ) . '> Translate title, alt text and caption into this site\'s language when an image is copied</label></p>';
			echo '<p><button class="button button-primary" name="lmg_dkib_save" value="1">Save</button></p></form>';
		}
		echo '<hr>';
		$md = is_readable( LMG_DKIB_DIR . 'RELEASE-NOTES.md' ) ? file_get_contents( LMG_DKIB_DIR . 'RELEASE-NOTES.md' ) : '';
		if ( $md !== '' ) echo class_exists( 'LMGT_Notes' ) && method_exists( 'LMGT_Notes', 'html' ) ? LMGT_Notes::html( $md ) : '<pre style="white-space:pre-wrap">' . esc_html( $md ) . '</pre>';
		echo '</div>';
	}
}

add_action( 'plugins_loaded', array( 'LMG_DKIB', 'boot' ), 20 );
