( function ( $, wp, L ) {
	if ( ! wp || ! wp.media || ! wp.media.view || ! wp.media.view.MediaFrame || ! L ) return;
	var Select = wp.media.view.MediaFrame.Select;
	var baseRouter = Select.prototype.browseRouter;
	var baseBind = Select.prototype.bindHandlers;

	Select.prototype.browseRouter = function ( routerView ) {
		baseRouter.apply( this, arguments );
		routerView.set( 'lmg_dkib', { text: L.tab, priority: 60 } );
	};
	Select.prototype.bindHandlers = function () {
		baseBind.apply( this, arguments );
		this.on( 'content:render:lmg_dkib', function () {
			this.content.set( new Bank( { controller: this } ) );
		}, this );
	};

	var Bank = wp.media.View.extend( {
		className: 'lmg-dkib',
		events: {
			'submit .lmg-dkib-form': 'search',
			'click .lmg-dkib-item': 'pick',
			'click .lmg-dkib-more': 'more'
		},
		initialize: function () {
			this.q = '';
			this.page = 1;
			this.pages = 1;
			this.items = [];
			this.busy = false;
		},
		render: function () {
			this.$el.html(
				'<form class="lmg-dkib-form"><input type="search" class="lmg-dkib-q"><button type="submit" class="button">Search</button></form>' +
				'<p class="lmg-dkib-help"></p><p class="lmg-dkib-status"></p><div class="lmg-dkib-grid"></div>' +
				'<p class="lmg-dkib-foot"><button type="button" class="button lmg-dkib-more"></button></p>'
			);
			this.$( '.lmg-dkib-q' ).attr( 'placeholder', L.search );
			this.$( '.lmg-dkib-help' ).text( L.help );
			this.$( '.lmg-dkib-more' ).text( L.more ).hide();
			this.load( true );
			return this;
		},
		search: function ( e ) {
			e.preventDefault();
			this.q = $.trim( this.$( '.lmg-dkib-q' ).val() );
			this.page = 1;
			this.load( true );
		},
		more: function () {
			if ( this.page >= this.pages ) return;
			this.page++;
			this.load( false );
		},
		status: function ( t, err ) {
			this.$( '.lmg-dkib-status' ).text( t || '' ).toggleClass( 'is-error', !! err );
		},
		load: function ( fresh ) {
			var self = this;
			if ( this.busy ) return;
			this.busy = true;
			if ( fresh ) { this.items = []; this.$( '.lmg-dkib-grid' ).empty(); }
			this.status( L.loading );
			$.post( L.ajax, { action: 'lmg_dkib_search', _ajax_nonce: L.nonce, q: this.q, page: this.page } ).done( function ( r ) {
				if ( ! r || ! r.success ) { self.status( r && r.data && r.data.message ? r.data.message : 'Error', true ); return; }
				self.pages = r.data.pages || 1;
				$.each( r.data.items, function ( i, it ) { self.add( it ); } );
				if ( ! self.items.length ) self.status( L.none );
				else self.status( self.q === '' ? L.latest : r.data.total + ' – ' + L.source );
				self.$( '.lmg-dkib-more' ).toggle( self.page < self.pages );
			} ).fail( function ( x ) {
				self.status( 'Error ' + ( x && x.status ? x.status : '' ), true );
			} ).always( function () { self.busy = false; } );
		},
		add: function ( it ) {
			var n = this.items.push( it ) - 1;
			var $b = $( '<button type="button" class="lmg-dkib-item"></button>' ).attr( 'data-n', n );
			$b.attr( 'title', [ it.title, it.alt, it.credit ? '© ' + it.credit : '', it.width ? it.width + '×' + it.height : '' ].filter( Boolean ).join( '\n' ) );
			$( '<img loading="lazy">' ).attr( 'src', it.thumb ).attr( 'alt', it.alt ).appendTo( $b );
			$( '<span class="lmg-dkib-cap"></span>' ).text( it.title || it.alt || '' ).appendTo( $b );
			if ( it.local ) $( '<span class="lmg-dkib-badge"></span>' ).text( L.here ).appendTo( $b );
			this.$( '.lmg-dkib-grid' ).append( $b );
		},
		pick: function ( e ) {
			var self = this, $b = $( e.currentTarget ), it = this.items[ +$b.attr( 'data-n' ) ];
			if ( ! it || $b.hasClass( 'is-busy' ) ) return;
			var post = wp.media.view.settings.post && wp.media.view.settings.post.id ? wp.media.view.settings.post.id : 0;
			$b.addClass( 'is-busy' );
			this.status( L.working );
			$.post( L.ajax, { action: 'lmg_dkib_import', _ajax_nonce: L.nonce, id: it.id, post: post } ).done( function ( r ) {
				if ( ! r || ! r.success ) { self.status( r && r.data && r.data.message ? r.data.message : 'Error', true ); return; }
				self.status( '' );
				self.chosen( r.data );
			} ).fail( function ( x ) {
				self.status( 'Error ' + ( x && x.status ? x.status : '' ), true );
			} ).always( function () { $b.removeClass( 'is-busy' ); } );
		},
		chosen: function ( json ) {
			var frame = this.controller, state = frame.state();
			var att = wp.media.model.Attachment.get( json.id );
			att.set( att.parse( json ) );
			var lib = state.get( 'library' );
			if ( lib && lib.add ) lib.add( att, { at: 0 } );
			var sel = state.get( 'selection' );
			if ( sel ) {
				if ( sel.multiple ) sel.add( att ); else sel.reset( [ att ] );
			}
			frame.content.mode( 'browse' );
		}
	} );
} )( jQuery, window.wp, window.LMG_DKIB );
