<?php
/**
 * Plugin Name: LMG DK Language Redirects
 * Description: 301-redirects old language-prefix URLs on traveltalk.dk (/en/, /de/, /fr/ …) to traveltalk.travel. Swedish, Norwegian and Finnish stay on traveltalk.dk (Traveltalk Nordic). Tools → Language redirects.
 * Version: 1.1.0
 * Author: Leisure Media Group
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class LMG_DK_Lang_Redirects {
	const OPT_MAP   = 'lmgdlr_map';
	const OPT_AFTER = 'lmgdlr_after_on';
	const OPT_LOG   = 'lmgdlr_log';
	const TARGET    = 'https://traveltalk.travel';

	/** .dk prefix => .travel prefix ('' = English root). */
	private static $langs = array(
		'en' => '', 'de' => 'de', 'fr' => 'fr', 'es' => 'es', 'it' => 'it', 'pt' => 'pt',
		'nl' => 'nl', 'sv' => 'sv', 'se' => 'sv', 'no' => 'nb', 'nb' => 'nb', 'nn' => 'nb',
		'fi' => 'fi', 'pl' => 'pl', 'ja' => 'ja', 'zh' => 'zh', 'ko' => 'ko', 'th' => 'th',
		'da' => '',
	);

	/**
	 * 1.1.0: Traveltalk Nordic (G, 10 Nov 2026). Swedish, Norwegian and Finnish
	 * live on traveltalk.dk under /sv/, /no/ and /fi/ (LMG Translator). Those
	 * prefixes are never sent to .travel; old Nordic addresses go to the
	 * language's own front page on .dk instead. .dk prefix => .dk prefix.
	 */
	private static $nordic = array( 'sv' => 'sv', 'se' => 'sv', 'no' => 'no', 'nb' => 'no', 'nn' => 'no', 'fi' => 'fi' );

	/** Always redirected (pages already replaced on .travel). */
	private static $ready = array(
		'/en/thailand-travel-guide-beyond-beaches/' => 'https://traveltalk.travel/destinations/asia/thailand/',
		'/fi/' => 'https://traveltalk.travel/fi/',
		'/no/' => 'https://traveltalk.travel/nb/',
		'/se/' => 'https://traveltalk.travel/sv/',
		'/fi/tiella/' => 'https://traveltalk.travel/fi/',
		'/fi/junalla/' => 'https://traveltalk.travel/fi/',
		'/fi/laivalla-ja-risteillen/' => 'https://traveltalk.travel/fi/',
		'/fi/lentaen/' => 'https://traveltalk.travel/fi/',
		'/fi/matkailuala/' => 'https://traveltalk.travel/fi/',
		'/no/reisebransjen/' => 'https://traveltalk.travel/nb/',
		'/no/paa-veien/' => 'https://traveltalk.travel/nb/',
		'/no/med-tog/' => 'https://traveltalk.travel/nb/',
		'/no/med-baat-og-cruise/' => 'https://traveltalk.travel/nb/',
		'/no/med-fly/' => 'https://traveltalk.travel/nb/',
		'/se/resebranschen/' => 'https://traveltalk.travel/sv/',
		'/se/pa-vagen/' => 'https://traveltalk.travel/sv/',
		'/se/med-tag/' => 'https://traveltalk.travel/sv/',
		'/se/med-bat-och-kryssning/' => 'https://traveltalk.travel/sv/',
		'/se/med-flyg/' => 'https://traveltalk.travel/sv/',
	);

	/** Live on .dk until copied to .travel; redirected only when the toggle is on. */
	private static $after = array(
		'/en/singapore-travel-guide-futuristic-city-food/' => 'https://traveltalk.travel/singapore-travel-guide-futuristic-city-food/',
		'/de/thailand-reisen-tipps-reiseziel/' => 'https://traveltalk.travel/de/thailand-reisen-tipps-reiseziel/',
		'/sv/resa-till-thailand-guide/' => 'https://traveltalk.travel/sv/resa-till-thailand-guide/',
		'/no/reise-til-thailand-smilets-land/' => 'https://traveltalk.travel/nb/reise-til-thailand-smilets-land/',
		'/fi/matka-thaimaahan-vinkit-ja-kohteet/' => 'https://traveltalk.travel/fi/matka-thaimaahan-vinkit-ja-kohteet/',
	);

	public static function init() {
		add_action( 'init', array( __CLASS__, 'early' ), 0 );
		add_action( 'template_redirect', array( __CLASS__, 'on_404' ), 1 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_post_lmgdlr_save', array( __CLASS__, 'save' ) );
	}

	private static function path() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return null; }
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$p   = strtolower( rawurldecode( (string) wp_parse_url( $uri, PHP_URL_PATH ) ) );
		if ( '' === $p || 0 === strpos( $p, '/wp-' ) ) { return null; }
		return trailingslashit( $p );
	}

	private static function lang_of( $path ) {
		if ( preg_match( '#^/([a-z]{2})/#', $path, $m ) && isset( self::$langs[ $m[1] ] ) ) { return $m[1]; }
		return null;
	}

	private static function home_for( $lang ) {
		if ( isset( self::$nordic[ $lang ] ) ) { return home_url( '/' . self::$nordic[ $lang ] . '/' ); }
		$t = self::$langs[ $lang ];
		return self::TARGET . '/' . ( '' === $t ? '' : $t . '/' );
	}

	private static function custom_map() {
		$out = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) get_option( self::OPT_MAP, '' ) ) as $line ) {
			$parts = array_map( 'trim', str_getcsv( $line ) );
			if ( count( $parts ) < 2 || '' === $parts[0] || 'source' === strtolower( $parts[0] ) ) { continue; }
			$src = wp_parse_url( $parts[0], PHP_URL_PATH );
			if ( ! $src || ! wp_http_validate_url( $parts[1] ) ) { continue; }
			$out[ trailingslashit( strtolower( $src ) ) ] = $parts[1];
		}
		return $out;
	}

	/** A Nordic language's own front page on .dk (/sv/, /no/, /fi/): never redirected. */
	private static function nordic_home( $path ) {
		return preg_match( '#^/([a-z]{2})/$#', $path, $m ) && isset( self::$nordic[ $m[1] ] ) && self::$nordic[ $m[1] ] === $m[1];
	}

	public static function early() {
		$path = self::path();
		if ( null === $path || self::nordic_home( $path ) ) { return; }
		$lang = self::lang_of( $path );
		if ( null !== $lang && isset( self::$nordic[ $lang ] ) ) {
			$custom = self::custom_map();
			if ( isset( $custom[ $path ] ) ) { self::go( $path, $custom[ $path ] ); }
			// Old Nordic pages and the /se/, /nb/, /nn/ roots: the language's front page on .dk. Live translations are left alone.
			if ( isset( self::$ready[ $path ] ) || preg_match( '#^/[a-z]{2}/$#', $path ) ) { self::go( $path, self::home_for( $lang ) ); }
			return;
		}
		$map = self::custom_map() + self::$ready;
		if ( get_option( self::OPT_AFTER ) ) { $map += self::$after; }
		if ( isset( $map[ $path ] ) ) { self::go( $path, $map[ $path ] ); }
		if ( preg_match( '#^/([a-z]{2})/$#', $path, $m ) && isset( self::$langs[ $m[1] ] ) ) {
			self::go( $path, self::home_for( $m[1] ) );
		}
	}

	public static function on_404() {
		if ( ! is_404() ) { return; }
		$path = self::path();
		if ( null === $path ) { return; }
		$lang = self::lang_of( $path );
		if ( null === $lang || self::nordic_home( $path ) ) { return; } // a Nordic front page that 404s must not redirect to itself
		if ( isset( self::$after[ $path ] ) && ! isset( self::$nordic[ $lang ] ) ) { self::go( $path, self::$after[ $path ] ); }
		self::go( $path, self::home_for( $lang ) );
	}

	private static function go( $path, $to ) {
		$log = get_option( self::OPT_LOG, array() );
		if ( ! is_array( $log ) ) { $log = array(); }
		$row = isset( $log[ $path ] ) ? $log[ $path ] : array( 'to' => $to, 'n' => 0 );
		$row['to'] = $to; $row['n']++; $row['t'] = time();
		unset( $log[ $path ] );
		$log[ $path ] = $row;
		if ( count( $log ) > 300 ) { $log = array_slice( $log, -300, null, true ); }
		update_option( self::OPT_LOG, $log, false );
		nocache_headers();
		wp_redirect( $to, 301, 'LMG DK Language Redirects' );
		exit;
	}

	public static function menu() {
		add_management_page( 'Language redirects', 'Language redirects', 'manage_options', 'lmgdlr', array( __CLASS__, 'page' ) );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'No access' ); }
		check_admin_referer( 'lmgdlr_save' );
		if ( isset( $_POST['clear_log'] ) ) {
			delete_option( self::OPT_LOG );
		} else {
			update_option( self::OPT_MAP, sanitize_textarea_field( wp_unslash( $_POST['map'] ?? '' ) ), false );
			update_option( self::OPT_AFTER, empty( $_POST['after_on'] ) ? 0 : 1, false );
		}
		wp_safe_redirect( admin_url( 'tools.php?page=lmgdlr&saved=1' ) );
		exit;
	}

	public static function page() {
		$log = array_reverse( (array) get_option( self::OPT_LOG, array() ), true );
		?>
		<div class="wrap">
			<h1>Language redirects → traveltalk.travel</h1>
			<?php if ( isset( $_GET['saved'] ) ) : ?><div class="notice notice-success"><p>Saved.</p></div><?php endif; ?>
			<p>Language roots (/en/, /de/ …) and the known old pages always 301 to .travel. Any other 404 under a language prefix goes to that language's .travel home.</p>
			<p><strong>Swedish, Norwegian and Finnish stay on traveltalk.dk</strong> (/sv/, /no/, /fi/). Old addresses under /se/, /nb/ and the old Nordic pages go to that language's front page here, not to .travel.</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'lmgdlr_save' ); ?>
				<input type="hidden" name="action" value="lmgdlr_save">
				<h2>Extra mappings</h2>
				<p>One per line: <code>/en/old-slug/,https://traveltalk.travel/new-slug/</code> (same format as the Redirection CSVs). These win over everything else.</p>
				<textarea name="map" rows="10" class="large-text code"><?php echo esc_textarea( get_option( self::OPT_MAP, '' ) ); ?></textarea>
				<h2>Translations still live on .dk</h2>
				<label><input type="checkbox" name="after_on" value="1" <?php checked( get_option( self::OPT_AFTER ) ); ?>> Redirect these now (turn on once they are on .travel):</label>
				<ul style="list-style:disc;margin-left:2em"><?php foreach ( self::$after as $s => $t ) { if ( isset( self::$nordic[ (string) self::lang_of( $s ) ] ) ) { continue; } echo '<li><code>' . esc_html( $s ) . '</code> → ' . esc_html( $t ) . '</li>'; } ?></ul>
				<?php submit_button( 'Save' ); ?>
			</form>
			<h2>Redirected URLs (last 300)</h2>
			<table class="widefat striped"><thead><tr><th>From</th><th>To</th><th>Hits</th><th>Last</th></tr></thead><tbody>
			<?php if ( ! $log ) : ?><tr><td colspan="4">Nothing yet.</td></tr><?php endif; ?>
			<?php foreach ( $log as $p => $r ) : ?>
				<tr><td><code><?php echo esc_html( $p ); ?></code></td><td><?php echo esc_html( $r['to'] ); ?></td><td><?php echo (int) $r['n']; ?></td><td><?php echo esc_html( wp_date( 'Y-m-d H:i', (int) $r['t'] ) ); ?></td></tr>
			<?php endforeach; ?>
			</tbody></table>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:1em">
				<?php wp_nonce_field( 'lmgdlr_save' ); ?>
				<input type="hidden" name="action" value="lmgdlr_save"><input type="hidden" name="clear_log" value="1">
				<?php submit_button( 'Clear log', 'secondary', 'submit', false ); ?>
			</form>
		</div>
		<?php
	}
}
LMG_DK_Lang_Redirects::init();
