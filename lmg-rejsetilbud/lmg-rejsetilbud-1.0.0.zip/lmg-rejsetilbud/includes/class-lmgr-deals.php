<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Stored data:
 *   _lmgr            on a deal: provider, url, price, old_price, currency, per_person, includes, departure, period, expires, checked, langs, countries
 *   _lmgr_country    on a deal: one row per country page id (for querying)
 *   _lmgr_expires    on a deal: Y-m-d, 9999-12-31 when open-ended (for querying)
 *   _lmgr_clicks     on a deal: [Y-m => n]
 *   lmgr_settings    option
 *   lmgr_remote      option on traveltalk.travel: .dk deal id => deal record pushed by .dk
 *   lmgr_remote_clicks option on traveltalk.travel: .dk deal id => [Y-m => n]
 */
class LMGR_Deals {

	const OPEN = '9999-12-31';

	public static function boot() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_filter( 'lmgt_post_types', array( __CLASS__, 'translator_types' ) );
		add_action( 'template_redirect', array( __CLASS__, 'go' ), 1 );
		add_action( 'lmgr_daily', array( __CLASS__, 'daily' ) );
		add_action( 'pre_get_posts', array( __CLASS__, 'archive_query' ) );
		add_action( 'init', function () {
			if ( ! wp_next_scheduled( 'lmgr_daily' ) ) wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'lmgr_daily' );
		}, 20 );
	}

	// ---- Settings ------------------------------------------------------------

	public static function is_travel() {
		return strpos( (string) wp_parse_url( home_url(), PHP_URL_HOST ), 'traveltalk.travel' ) !== false;
	}

	public static function defaults() {
		return array(
			'per_box'         => 3,
			'place'           => 'auto',
			'noindex_expired' => 1,
			'disclosure'      => 1,
			'default_langs'   => array( self::site_lang() ),
			'slug'            => self::is_travel() ? 'travel-deals' : 'rejsetilbud',
		);
	}

	public static function settings() {
		$s = wp_parse_args( (array) get_option( 'lmgr_settings', array() ), self::defaults() );
		$s['per_box']       = max( 1, min( 12, (int) $s['per_box'] ) );
		$s['default_langs'] = array_values( array_intersect( (array) $s['default_langs'], LMGR_I18n::LANGS ) );
		return $s;
	}

	// ---- Language (same rules as LMG Faktabokse) -------------------------------

	public static function site_lang() {
		if ( class_exists( 'LMGT_Langs' ) && method_exists( 'LMGT_Langs', 'source' ) ) return LMGT_Langs::source();
		$c = strtolower( substr( get_locale(), 0, 2 ) );
		if ( $c === 'no' || $c === 'nn' ) $c = 'nb';
		return in_array( $c, LMGR_I18n::LANGS, true ) ? $c : 'en';
	}

	public static function lang_of( $post_id ) {
		$l = (string) get_post_meta( (int) $post_id, '_lmgt_lang', true );
		return $l !== '' ? $l : self::site_lang();
	}

	public static function source_of( $post_id ) {
		$s = (int) get_post_meta( (int) $post_id, '_lmgt_source', true );
		return ( $s && get_post( $s ) ) ? $s : (int) $post_id;
	}

	public static function translation_type() {
		return defined( 'LMGT_CPT' ) ? LMGT_CPT : 'lmgt_translation';
	}

	/** Published translation of a local post in a language, or the post itself in its own language; 0 if none. */
	public static function local_in_lang( $post_id, $lang ) {
		if ( self::lang_of( $post_id ) === $lang ) return get_post_status( $post_id ) === 'publish' ? (int) $post_id : 0;
		$ids = get_posts( array(
			'post_type'      => array_values( array_unique( array_merge( array_values( get_post_types( array( 'public' => true ) ) ), array( self::translation_type() ) ) ) ),
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
			'meta_query'     => array(
				array( 'key' => '_lmgt_source', 'value' => (int) $post_id ),
				array( 'key' => '_lmgt_lang', 'value' => $lang ),
			),
		) );
		return $ids ? (int) $ids[0] : 0;
	}

	// ---- Post type -------------------------------------------------------------

	public static function register() {
		$travel = self::is_travel();
		register_post_type( LMGR_CPT, array(
			'labels'        => $travel ? array(
				'name' => 'Travel deals', 'singular_name' => 'Travel deal', 'add_new' => 'Add deal', 'add_new_item' => 'Add travel deal',
				'edit_item' => 'Edit travel deal', 'all_items' => 'All deals', 'search_items' => 'Search deals', 'not_found' => 'No deals yet',
			) : array(
				'name' => 'Rejsetilbud', 'singular_name' => 'Rejsetilbud', 'add_new' => 'Nyt tilbud', 'add_new_item' => 'Nyt rejsetilbud',
				'edit_item' => 'Rediger rejsetilbud', 'all_items' => 'Alle tilbud', 'search_items' => 'Søg i tilbud', 'not_found' => 'Ingen tilbud endnu',
			),
			'public'        => true,
			'has_archive'   => true,
			'rewrite'       => array( 'slug' => sanitize_title( self::settings()['slug'] ), 'with_front' => false ),
			'menu_icon'     => 'dashicons-tickets-alt',
			'menu_position' => 6,
			'show_in_rest'  => true,
			'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'author' ),
			'taxonomies'    => array( 'category', 'post_tag' ),
		) );
	}

	/** Deals can be translated, but stay ordinary articles for its length rules (not pillar pages). */
	public static function translator_types( $types ) {
		$types   = (array) $types;
		$types[] = LMGR_CPT;
		return $types;
	}

	// ---- Records ---------------------------------------------------------------

	public static function raw( $id ) {
		$d = get_post_meta( (int) $id, '_lmgr', true );
		return is_array( $d ) ? $d : array();
	}

	/** One shape for a deal, local or pushed from .dk. */
	public static function normalize( array $d ) {
		$f = array(
			'id' => 0, 'status' => 'publish', 'title' => '', 'provider' => '', 'url' => '', 'price' => '', 'old_price' => '', 'currency' => 'DKK',
			'per_person' => 1, 'includes' => '', 'departure' => '', 'period' => '', 'expires' => '', 'checked' => '', 'langs' => array(),
			'countries' => array(), 'lang' => 'da', 'image' => '',
		);
		$d = wp_parse_args( $d, $f );
		$d['countries'] = array_values( array_filter( array_map( 'intval', (array) $d['countries'] ) ) );
		$d['langs']     = array_values( array_intersect( (array) $d['langs'], LMGR_I18n::LANGS ) );
		if ( ! in_array( $d['lang'], $d['langs'], true ) ) array_unshift( $d['langs'], $d['lang'] );
		return $d;
	}

	public static function local( $id ) {
		$p = get_post( (int) $id );
		if ( ! $p || $p->post_type !== LMGR_CPT ) return null;
		$d = self::raw( $p->ID );
		$d['id']     = (int) $p->ID;
		$d['status'] = $p->post_status;
		$d['title']  = get_the_title( $p );
		$d['lang']   = self::site_lang();
		$d['image']  = (string) get_the_post_thumbnail_url( $p, 'large' );
		return self::normalize( $d );
	}

	public static function remote_all() {
		$r = get_option( 'lmgr_remote', array() );
		return is_array( $r ) ? $r : array();
	}

	public static function remote( $dk_id ) {
		$all = self::remote_all();
		return isset( $all[ (int) $dk_id ] ) ? self::normalize( $all[ (int) $dk_id ] ) : null;
	}

	public static function today() {
		return current_time( 'Y-m-d' );
	}

	public static function is_expired( array $d ) {
		return $d['expires'] !== '' && $d['expires'] < self::today();
	}

	public static function is_live( array $d ) {
		return $d['status'] === 'publish' && ! self::is_expired( $d ) && $d['url'] !== '';
	}

	/** Live local deals for a country page, newest first. */
	public static function for_country( $page_id, $limit = 3 ) {
		$ids = get_posts( array(
			'post_type'      => LMGR_CPT,
			'post_status'    => 'publish',
			'posts_per_page' => (int) $limit,
			'fields'         => 'ids',
			'no_found_rows'  => true,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'meta_query'     => array(
				array( 'key' => '_lmgr_country', 'value' => (int) $page_id ),
				array( 'key' => '_lmgr_expires', 'value' => self::today(), 'compare' => '>=', 'type' => 'DATE' ),
			),
		) );
		$out = array();
		foreach ( $ids as $id ) {
			$d = self::local( $id );
			if ( $d && self::is_live( $d ) ) $out[] = $d;
		}
		return $out;
	}

	/** Live pushed deals for a .dk country page id (on .travel). */
	public static function remote_for_country( $dk_page, $lang, $limit = 3 ) {
		$out = array();
		foreach ( self::remote_all() as $id => $d ) {
			$d = self::normalize( $d );
			if ( ! self::is_live( $d ) || ! in_array( (int) $dk_page, $d['countries'], true ) || ! in_array( $lang, $d['langs'], true ) ) continue;
			$out[] = $d;
		}
		usort( $out, function ( $a, $b ) { return $b['id'] <=> $a['id']; } );
		return $out;
	}

	public static function save_record( $id, array $d ) {
		$d = self::normalize( $d );
		unset( $d['id'], $d['status'], $d['title'], $d['lang'], $d['image'] );
		update_post_meta( $id, '_lmgr', wp_slash( $d ) );
		delete_post_meta( $id, '_lmgr_country' );
		foreach ( $d['countries'] as $c ) add_post_meta( $id, '_lmgr_country', (int) $c );
		update_post_meta( $id, '_lmgr_expires', $d['expires'] !== '' ? $d['expires'] : self::OPEN );
		// Deals are translated exactly as written: no length warnings, never held back for being short.
		update_post_meta( $id, '_lmgt_as_written', '1' );
	}

	// ---- Clicks ----------------------------------------------------------------

	/** The tracked address a reader clicks: counts, then sends on to the agency. */
	public static function go_url( array $d, $lang ) {
		$key = self::is_travel() ? 'r' . $d['id'] : (string) $d['id'];
		return add_query_arg( array( 'lmgr_go' => $key, 'l' => $lang ), home_url( '/' ) );
	}

	public static function go() {
		if ( empty( $_GET['lmgr_go'] ) ) return;
		$key    = sanitize_text_field( wp_unslash( $_GET['lmgr_go'] ) );
		$remote = $key[0] === 'r';
		$id     = (int) ltrim( $key, 'r' );
		$d      = $remote ? self::remote( $id ) : self::local( $id );
		if ( ! $d || $d['url'] === '' || $d['status'] !== 'publish' ) {
			wp_safe_redirect( home_url( '/' ), 302 );
			exit;
		}
		if ( ! self::is_bot() ) self::count( $id, $remote );
		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow' );
		wp_redirect( esc_url_raw( $d['url'] ), 302, 'LMG Rejsetilbud' );
		exit;
	}

	private static function is_bot() {
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? strtolower( (string) $_SERVER['HTTP_USER_AGENT'] ) : '';
		return $ua === '' || preg_match( '/bot|crawl|spider|slurp|preview|facebookexternalhit|curl|wget|python|headless|lighthouse/', $ua );
	}

	private static function count( $id, $remote ) {
		$m = current_time( 'Y-m' );
		if ( $remote ) {
			$all = (array) get_option( 'lmgr_remote_clicks', array() );
			$all[ $id ][ $m ] = ( isset( $all[ $id ][ $m ] ) ? (int) $all[ $id ][ $m ] : 0 ) + 1;
			update_option( 'lmgr_remote_clicks', $all, false );
			return;
		}
		$c = get_post_meta( $id, '_lmgr_clicks', true );
		if ( ! is_array( $c ) ) $c = array();
		$c[ $m ] = ( isset( $c[ $m ] ) ? (int) $c[ $m ] : 0 ) + 1;
		update_post_meta( $id, '_lmgr_clicks', $c );
	}

	public static function clicks( $id, $remote = false ) {
		if ( $remote ) {
			$all = (array) get_option( 'lmgr_remote_clicks', array() );
			$c   = isset( $all[ $id ] ) ? (array) $all[ $id ] : array();
		} else {
			$c = get_post_meta( $id, '_lmgr_clicks', true );
			if ( ! is_array( $c ) ) $c = array();
		}
		$m = current_time( 'Y-m' );
		return array( 'month' => isset( $c[ $m ] ) ? (int) $c[ $m ] : 0, 'total' => array_sum( array_map( 'intval', $c ) ), 'by_month' => $c );
	}

	// ---- Expiry ----------------------------------------------------------------

	/** Once a day: country pages whose deal just ran out are cleared from the page cache, so the box drops it. */
	public static function daily() {
		$yesterday = gmdate( 'Y-m-d', strtotime( self::today() . ' -1 day' ) );
		$pages     = array();
		foreach ( get_posts( array( 'post_type' => LMGR_CPT, 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids', 'no_found_rows' => true, 'meta_key' => '_lmgr_expires', 'meta_value' => $yesterday ) ) as $id ) {
			$pages[] = $id;
			foreach ( self::raw( $id )['countries'] ?? array() as $c ) $pages[] = (int) $c;
		}
		foreach ( self::remote_all() as $id => $d ) {
			if ( isset( $d['expires'] ) && $d['expires'] === $yesterday ) $pages = array_merge( $pages, LMGR_Sync::target_posts_for( (int) $id ), LMGR_Sync::target_hubs_for( $d ) );
		}
		self::purge( $pages );
	}

	public static function purge( array $ids ) {
		$done = array();
		foreach ( $ids as $id ) {
			$id = (int) $id;
			if ( ! $id || isset( $done[ $id ] ) ) continue;
			$done[ $id ] = 1;
			do_action( 'litespeed_purge_post', $id );
			clean_post_cache( $id );
		}
		if ( $done ) do_action( 'litespeed_purge_posttype', LMGR_CPT );
	}

	/** The deals archive lists live deals only. */
	public static function archive_query( $q ) {
		if ( is_admin() || ! $q->is_main_query() || ! $q->is_post_type_archive( LMGR_CPT ) ) return;
		$q->set( 'meta_query', array( array( 'key' => '_lmgr_expires', 'value' => self::today(), 'compare' => '>=', 'type' => 'DATE' ) ) );
	}
}
