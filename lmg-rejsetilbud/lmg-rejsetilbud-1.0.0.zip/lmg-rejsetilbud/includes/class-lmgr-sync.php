<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * .dk → .travel: the deal's facts (price, link, expiry, countries, languages) travel over
 * LMG Translator's bridge, with its pairing and login. The text itself travels as the
 * Translator's own translation of the deal.
 */
class LMGR_Sync {

	const PATH = '/rejsetilbud';

	public static function boot() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'save_post_' . LMGR_CPT, array( __CLASS__, 'on_save' ), 30, 2 );
		add_action( 'before_delete_post', array( __CLASS__, 'on_delete' ) );
	}

	public static function on() {
		return class_exists( 'LMGT_Bridge' ) && method_exists( 'LMGT_Bridge', 'is_source' ) && LMGT_Bridge::is_source() && method_exists( 'LMGT_Bridge', 'call' );
	}

	public static function is_target() {
		return class_exists( 'LMGT_Bridge' ) && method_exists( 'LMGT_Bridge', 'is_target' ) && LMGT_Bridge::is_target();
	}

	// ---- Source (.dk) ------------------------------------------------------------

	public static function on_save( $id, $post ) {
		if ( wp_is_post_revision( $id ) || wp_is_post_autosave( $id ) || $post->post_status === 'auto-draft' ) return;
		$d = LMGR_Deals::local( $id );
		if ( $d ) LMGR_Deals::purge( array_merge( array( $id ), $d['countries'] ) );
		self::push( $id );
	}

	public static function on_delete( $id ) {
		if ( get_post_type( $id ) !== LMGR_CPT || ! self::on() ) return;
		LMGT_Bridge::call( 'POST', self::PATH, array( 'id' => (int) $id, 'status' => 'deleted' ) );
	}

	public static function payload( $id ) {
		$d = LMGR_Deals::local( $id );
		if ( ! $d ) return null;
		$d['url_page'] = get_permalink( $id );
		return $d;
	}

	/** True when sent, a message when not, null when the site has no bridge. */
	public static function push( $id ) {
		if ( ! self::on() ) return null;
		$p = self::payload( $id );
		if ( ! $p ) return null;
		$r = LMGT_Bridge::call( 'POST', self::PATH, $p );
		if ( is_wp_error( $r ) ) {
			update_post_meta( $id, '_lmgr_sync', array( 'ok' => 0, 'at' => current_time( 'mysql' ), 'msg' => $r->get_error_message() ) );
			return $r->get_error_message();
		}
		update_post_meta( $id, '_lmgr_sync', array( 'ok' => 1, 'at' => current_time( 'mysql' ), 'msg' => '' ) );
		return true;
	}

	public static function push_all() {
		$ok = 0; $fail = 0;
		foreach ( get_posts( array( 'post_type' => LMGR_CPT, 'post_status' => array( 'publish', 'draft', 'pending', 'future', 'private' ), 'posts_per_page' => -1, 'fields' => 'ids', 'no_found_rows' => true ) ) as $id ) {
			$r = self::push( $id );
			if ( $r === true ) $ok++; elseif ( $r !== null ) $fail++;
		}
		return array( $ok, $fail );
	}

	// ---- Target (.travel) ----------------------------------------------------------

	public static function routes() {
		register_rest_route( 'lmgt/v2', self::PATH, array(
			'methods'             => 'POST',
			'permission_callback' => function () { return current_user_can( 'edit_others_posts' ); },
			'callback'            => array( __CLASS__, 'receive' ),
		) );
	}

	public static function receive( WP_REST_Request $req ) {
		$p  = (array) $req->get_json_params();
		$id = isset( $p['id'] ) ? (int) $p['id'] : 0;
		if ( ! $id ) return new WP_Error( 'lmgr_id', 'No deal id', array( 'status' => 400 ) );
		$all = LMGR_Deals::remote_all();
		$old = isset( $all[ $id ] ) ? $all[ $id ] : null;

		if ( isset( $p['status'] ) && $p['status'] === 'deleted' ) {
			unset( $all[ $id ] );
		} else {
			$all[ $id ] = array(
				'id'         => $id,
				'status'     => sanitize_key( isset( $p['status'] ) ? $p['status'] : 'draft' ),
				'title'      => sanitize_text_field( isset( $p['title'] ) ? $p['title'] : '' ),
				'provider'   => sanitize_text_field( isset( $p['provider'] ) ? $p['provider'] : '' ),
				'url'        => esc_url_raw( isset( $p['url'] ) ? $p['url'] : '' ),
				'price'      => self::num( isset( $p['price'] ) ? $p['price'] : '' ),
				'old_price'  => self::num( isset( $p['old_price'] ) ? $p['old_price'] : '' ),
				'currency'   => strtoupper( substr( sanitize_key( isset( $p['currency'] ) ? $p['currency'] : 'dkk' ), 0, 3 ) ),
				'per_person' => empty( $p['per_person'] ) ? 0 : 1,
				'includes'   => sanitize_text_field( isset( $p['includes'] ) ? $p['includes'] : '' ),
				'departure'  => sanitize_text_field( isset( $p['departure'] ) ? $p['departure'] : '' ),
				'period'     => sanitize_text_field( isset( $p['period'] ) ? $p['period'] : '' ),
				'expires'    => self::ymd( isset( $p['expires'] ) ? $p['expires'] : '' ),
				'checked'    => self::ymd( isset( $p['checked'] ) ? $p['checked'] : '' ),
				'langs'      => array_values( array_intersect( (array) ( isset( $p['langs'] ) ? $p['langs'] : array() ), LMGR_I18n::LANGS ) ),
				'countries'  => array_values( array_filter( array_map( 'intval', (array) ( isset( $p['countries'] ) ? $p['countries'] : array() ) ) ) ),
				'lang'       => in_array( isset( $p['lang'] ) ? $p['lang'] : '', LMGR_I18n::LANGS, true ) ? $p['lang'] : 'da',
				'image'      => esc_url_raw( isset( $p['image'] ) ? $p['image'] : '' ),
				'url_page'   => esc_url_raw( isset( $p['url_page'] ) ? $p['url_page'] : '' ),
				'at'         => current_time( 'mysql' ),
			);
		}
		update_option( 'lmgr_remote', $all, false );

		$purge = self::target_posts_for( $id );
		if ( $old ) $purge = array_merge( $purge, self::target_hubs_for( $old ) );
		if ( isset( $all[ $id ] ) ) $purge = array_merge( $purge, self::target_hubs_for( $all[ $id ] ) );
		LMGR_Deals::purge( $purge );

		return array( 'ok' => true, 'id' => $id );
	}

	/** Translations on this site of a .dk post. */
	public static function target_posts_for( $dk_id ) {
		if ( ! class_exists( 'LMGT_Bridge' ) || ! method_exists( 'LMGT_Bridge', 'members' ) ) return array();
		return array_map( 'intval', (array) LMGT_Bridge::members( (int) $dk_id ) );
	}

	public static function target_hubs_for( $d ) {
		$out = array();
		foreach ( isset( $d['countries'] ) ? (array) $d['countries'] : array() as $c ) $out = array_merge( $out, self::target_posts_for( (int) $c ) );
		return $out;
	}

	/** The published translation on this site of a .dk post, in a language; 0 if none. */
	public static function target_in_lang( $dk_id, $lang ) {
		if ( ! class_exists( 'LMGT_Bridge' ) || ! method_exists( 'LMGT_Bridge', 'member' ) ) return 0;
		$id = (int) LMGT_Bridge::member( (int) $dk_id, $lang );
		return $id && get_post_status( $id ) === 'publish' ? $id : 0;
	}

	private static function num( $v ) {
		$v = str_replace( array( ' ', "\u{00A0}" ), '', (string) $v );
		return $v === '' || ! is_numeric( $v ) ? '' : (string) (float) $v;
	}

	private static function ymd( $v ) {
		return preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $v ) ? (string) $v : '';
	}
}
