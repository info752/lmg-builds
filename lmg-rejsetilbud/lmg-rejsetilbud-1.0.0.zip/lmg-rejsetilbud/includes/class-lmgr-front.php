<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LMGR_Front {

	private static $done = array();

	public static function boot() {
		add_filter( 'the_content', array( __CLASS__, 'content' ), 25 );
		add_action( 'lmg_faktabokse_after_getting_there', array( __CLASS__, 'after_there' ), 10, 2 );
		add_shortcode( 'lmg_rejsetilbud', array( __CLASS__, 'shortcode' ) );
		add_action( 'wp_enqueue_scripts', function () {
			wp_enqueue_style( 'lmg-rejsetilbud', LMGR_URL . 'assets/lmgr.css', array(), LMGR_VERSION );
		} );
		add_filter( 'wp_robots', array( __CLASS__, 'robots' ) );
		add_filter( 'rank_math/frontend/robots', array( __CLASS__, 'robots_rm' ) );
	}

	// ---- What the current post is ------------------------------------------------

	/** If the post is a deal (or a translation of one): [record, remote?]. */
	public static function deal_of( $post_id ) {
		$post_id = (int) $post_id;
		if ( get_post_type( $post_id ) === LMGR_CPT ) {
			$d = LMGR_Deals::local( $post_id );
			return $d ? array( $d, false ) : null;
		}
		if ( get_post_type( $post_id ) !== LMGR_Deals::translation_type() ) return null;
		$rs = (int) get_post_meta( $post_id, '_lmgt_remote_source', true );
		if ( $rs ) {
			$d = LMGR_Deals::remote( $rs );
			return $d ? array( $d, true ) : null;
		}
		$src = LMGR_Deals::source_of( $post_id );
		if ( $src !== $post_id && get_post_type( $src ) === LMGR_CPT ) {
			$d = LMGR_Deals::local( $src );
			return $d ? array( $d, false ) : null;
		}
		return null;
	}

	/** Live deals for the country page being shown, each with the post to link to in its language. */
	public static function deals_for_page( $post_id, $limit ) {
		$lang = LMGR_Deals::lang_of( $post_id );
		$out  = array();
		$rs   = (int) get_post_meta( $post_id, '_lmgt_remote_source', true );
		if ( $rs && LMGR_Sync::is_target() ) {
			foreach ( LMGR_Deals::remote_for_country( $rs, $lang ) as $d ) {
				$page = LMGR_Sync::target_in_lang( $d['id'], $lang );
				if ( ! $page ) continue;
				$out[] = array( $d, $page, true );
				if ( count( $out ) >= $limit ) break;
			}
			return $out;
		}
		$hub = LMGR_Deals::source_of( $post_id );
		foreach ( LMGR_Deals::for_country( $hub, 24 ) as $d ) {
			if ( ! in_array( $lang, $d['langs'], true ) ) continue;
			$page = LMGR_Deals::local_in_lang( $d['id'], $lang );
			if ( ! $page ) continue;
			$out[] = array( $d, $page, false );
			if ( count( $out ) >= $limit ) break;
		}
		return $out;
	}

	public static function country_name( $post_id ) {
		if ( class_exists( 'LMGF_Data' ) && method_exists( 'LMGF_Data', 'view' ) ) {
			$v = LMGF_Data::view( $post_id );
			if ( $v && ! empty( $v['name'] ) ) return $v['name'];
		}
		return get_the_title( $post_id );
	}

	/** The country page in a language, for a deal: first country with a published page. */
	public static function hub_link( array $d, $lang, $remote ) {
		foreach ( $d['countries'] as $c ) {
			$p = $remote ? LMGR_Sync::target_in_lang( $c, $lang ) : LMGR_Deals::local_in_lang( $c, $lang );
			if ( $p ) return $p;
		}
		return 0;
	}

	// ---- Placement ---------------------------------------------------------------

	public static function content( $html ) {
		if ( is_admin() || is_feed() || ! is_singular() || ! in_the_loop() || ! is_main_query() ) return $html;
		$id = (int) get_the_ID();
		if ( $id !== (int) get_queried_object_id() ) return $html;

		$deal = self::deal_of( $id );
		if ( $deal ) return self::deal_page( $html, $deal[0], $deal[1], LMGR_Deals::lang_of( $id ) );

		$set = LMGR_Deals::settings();
		if ( $set['place'] === 'manual' || isset( self::$done[ $id ] ) || has_shortcode( $html, 'lmg_rejsetilbud' ) ) return $html;
		return $html . self::box( $id );
	}

	/** Right under "Sådan kommer du til …" when LMG Faktabokse shows it. */
	public static function after_there( $slug, $post_id ) {
		if ( LMGR_Deals::settings()['place'] !== 'auto' || (int) $post_id !== (int) get_queried_object_id() ) return;
		$html = self::box( (int) $post_id );
		self::$done[ (int) $post_id ] = 1;
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput -- built from escaped parts
	}

	public static function shortcode( $atts ) {
		$a    = shortcode_atts( array( 'land' => 0, 'antal' => 0 ), $atts, 'lmg_rejsetilbud' );
		$id   = (int) get_the_ID();
		$set  = LMGR_Deals::settings();
		$n    = (int) $a['antal'] ? max( 1, min( 24, (int) $a['antal'] ) ) : $set['per_box'];
		$lang = LMGR_Deals::lang_of( $id );
		if ( (int) $a['land'] ) {
			$rows = self::rows_for_country( (int) $a['land'], $lang, $n );
			$name = get_the_title( (int) $a['land'] );
			$title = sprintf( LMGR_I18n::t( 'box_title', $lang ), $name );
		} elseif ( $a['land'] === 'alle' || $a['land'] === 'all' ) {
			$rows  = self::rows_all( $lang, $n );
			$title = LMGR_I18n::t( 'all_title', $lang );
		} else {
			self::$done[ $id ] = 1;
			return self::box( $id, $n );
		}
		return self::wrap( $rows, $title, $lang );
	}

	private static function rows_for_country( $dk_page, $lang, $n ) {
		$out = array();
		if ( LMGR_Sync::is_target() ) {
			foreach ( LMGR_Deals::remote_for_country( $dk_page, $lang ) as $d ) {
				$p = LMGR_Sync::target_in_lang( $d['id'], $lang );
				if ( $p ) $out[] = array( $d, $p, true );
				if ( count( $out ) >= $n ) break;
			}
			return $out;
		}
		foreach ( LMGR_Deals::for_country( $dk_page, 24 ) as $d ) {
			$p = in_array( $lang, $d['langs'], true ) ? LMGR_Deals::local_in_lang( $d['id'], $lang ) : 0;
			if ( $p ) $out[] = array( $d, $p, false );
			if ( count( $out ) >= $n ) break;
		}
		return $out;
	}

	private static function rows_all( $lang, $n ) {
		$out = array();
		if ( LMGR_Sync::is_target() ) {
			$all = array_map( array( 'LMGR_Deals', 'normalize' ), LMGR_Deals::remote_all() );
			usort( $all, function ( $a, $b ) { return $b['id'] <=> $a['id']; } );
			foreach ( $all as $d ) {
				if ( ! LMGR_Deals::is_live( $d ) || ! in_array( $lang, $d['langs'], true ) ) continue;
				$p = LMGR_Sync::target_in_lang( $d['id'], $lang );
				if ( $p ) $out[] = array( $d, $p, true );
				if ( count( $out ) >= $n ) break;
			}
			return $out;
		}
		$ids = get_posts( array( 'post_type' => LMGR_CPT, 'post_status' => 'publish', 'posts_per_page' => 48, 'fields' => 'ids', 'no_found_rows' => true,
			'meta_query' => array( array( 'key' => '_lmgr_expires', 'value' => LMGR_Deals::today(), 'compare' => '>=', 'type' => 'DATE' ) ) ) );
		foreach ( $ids as $id ) {
			$d = LMGR_Deals::local( $id );
			if ( ! $d || ! LMGR_Deals::is_live( $d ) || ! in_array( $lang, $d['langs'], true ) ) continue;
			$p = LMGR_Deals::local_in_lang( $id, $lang );
			if ( $p ) $out[] = array( $d, $p, false );
			if ( count( $out ) >= $n ) break;
		}
		return $out;
	}

	// ---- The box on a country page ---------------------------------------------------

	public static function box( $post_id, $limit = 0 ) {
		$limit = $limit ? $limit : LMGR_Deals::settings()['per_box'];
		$rows  = self::deals_for_page( $post_id, $limit );
		if ( ! $rows ) return '';
		$lang = LMGR_Deals::lang_of( $post_id );
		return self::wrap( $rows, sprintf( LMGR_I18n::t( 'box_title', $lang ), self::country_name( $post_id ) ), $lang );
	}

	private static function wrap( array $rows, $title, $lang ) {
		if ( ! $rows ) return '';
		$cards = '';
		foreach ( $rows as $r ) $cards .= self::card( $r[0], $r[1], $lang );
		$h  = '<section class="lmgr" lang="' . esc_attr( LMGR_I18n::html_lang( $lang ) ) . '">';
		$h .= '<h2 class="lmgr-title">' . esc_html( $title ) . '</h2>';
		$h .= '<p class="lmgr-intro">' . esc_html( LMGR_I18n::t( 'box_intro', $lang ) ) . '</p>';
		$h .= '<div class="lmgr-cards">' . $cards . '</div>';
		$arch = LMGR_Sync::is_target() ? '' : get_post_type_archive_link( LMGR_CPT );
		if ( $arch && $lang === LMGR_Deals::site_lang() ) $h .= '<p class="lmgr-all"><a href="' . esc_url( $arch ) . '">' . esc_html( LMGR_I18n::t( 'all_deals', $lang ) ) . ' →</a></p>';
		if ( LMGR_Deals::settings()['disclosure'] ) $h .= '<p class="lmgr-disclosure">' . esc_html( LMGR_I18n::t( 'disclosure', $lang ) ) . '</p>';
		return $h . '</section>';
	}

	public static function price_html( array $d, $lang ) {
		if ( $d['price'] === '' ) return '';
		$h = '<span class="lmgr-price">' . esc_html( sprintf( LMGR_I18n::t( 'from', $lang ), LMGR_I18n::money( $d['price'], $d['currency'], $lang ) ) ) . '</span>';
		if ( $d['per_person'] ) $h .= ' <span class="lmgr-pp">' . esc_html( LMGR_I18n::t( 'per_person', $lang ) ) . '</span>';
		if ( $d['old_price'] !== '' && (float) $d['old_price'] > (float) $d['price'] ) $h .= ' <s class="lmgr-old">' . esc_html( sprintf( LMGR_I18n::t( 'before', $lang ), LMGR_I18n::money( $d['old_price'], $d['currency'], $lang ) ) ) . '</s>';
		return $h;
	}

	public static function card( array $d, $page, $lang ) {
		$img = get_the_post_thumbnail_url( $page, 'medium_large' );
		if ( ! $img ) $img = $d['image'];
		$h  = '<article class="lmgr-card">';
		if ( $img ) $h .= '<a class="lmgr-img" href="' . esc_url( get_permalink( $page ) ) . '"><img src="' . esc_url( $img ) . '" alt="" loading="lazy" decoding="async"></a>';
		$h .= '<div class="lmgr-body">';
		$h .= '<p class="lmgr-pricebar">' . self::price_html( $d, $lang ) . '</p>';
		$h .= '<h3 class="lmgr-card-title"><a href="' . esc_url( get_permalink( $page ) ) . '">' . esc_html( get_the_title( $page ) ) . '</a></h3>';
		$meta = array();
		if ( $d['provider'] !== '' ) $meta[] = sprintf( LMGR_I18n::t( 'with', $lang ), $d['provider'] );
		if ( $d['expires'] !== '' ) $meta[] = sprintf( LMGR_I18n::t( 'valid', $lang ), LMGR_I18n::date( $d['expires'], $lang ) );
		if ( $meta ) $h .= '<p class="lmgr-meta">' . esc_html( implode( ' · ', $meta ) ) . '</p>';
		$h .= '<p class="lmgr-actions"><a class="lmgr-btn" href="' . esc_url( LMGR_Deals::go_url( $d, $lang ) ) . '" rel="sponsored nofollow noopener" target="_blank">' . esc_html( LMGR_I18n::t( 'see_deal', $lang ) ) . '</a>'
			. ' <a class="lmgr-more" href="' . esc_url( get_permalink( $page ) ) . '">' . esc_html( LMGR_I18n::t( 'read_more', $lang ) ) . '</a></p>';
		return $h . '</div></article>';
	}

	// ---- The deal's own page ------------------------------------------------------------

	public static function deal_page( $html, array $d, $remote, $lang ) {
		if ( LMGR_Deals::is_expired( $d ) || $d['status'] !== 'publish' ) {
			$hub = self::hub_link( $d, $lang, $remote );
			$body = $hub
				? sprintf( esc_html( LMGR_I18n::t( 'expired_body', $lang ) ), '<a href="' . esc_url( get_permalink( $hub ) ) . '">' . esc_html( get_the_title( $hub ) ) . '</a>' )
				: esc_html( LMGR_I18n::t( 'expired_body_plain', $lang ) );
			$note = '<aside class="lmgr lmgr-expired" lang="' . esc_attr( LMGR_I18n::html_lang( $lang ) ) . '"><p class="lmgr-title">' . esc_html( LMGR_I18n::t( 'expired_title', $lang ) ) . '</p><p>' . $body . '</p></aside>';
			$more = $hub ? self::box( $hub ) : '';
			return $note . $html . $more;
		}
		return self::facts( $d, $lang ) . $html . self::cta( $d, $lang );
	}

	public static function facts( array $d, $lang ) {
		$rows = '';
		$add  = function ( $k, $v ) use ( &$rows, $lang ) {
			if ( $v !== '' ) $rows .= '<div class="lmgr-row"><dt>' . esc_html( LMGR_I18n::t( $k, $lang ) ) . '</dt><dd>' . esc_html( $v ) . '</dd></div>';
		};
		$add( 'includes', $d['includes'] );
		$add( 'departure', $d['departure'] );
		$add( 'period', $d['period'] );
		$h  = '<section class="lmgr lmgr-deal" lang="' . esc_attr( LMGR_I18n::html_lang( $lang ) ) . '">';
		$h .= '<p class="lmgr-pricebar lmgr-pricebar-lg">' . self::price_html( $d, $lang ) . '</p>';
		$meta = array();
		if ( $d['provider'] !== '' ) $meta[] = sprintf( LMGR_I18n::t( 'with', $lang ), $d['provider'] );
		if ( $d['expires'] !== '' ) $meta[] = sprintf( LMGR_I18n::t( 'valid', $lang ), LMGR_I18n::date( $d['expires'], $lang ) );
		if ( $meta ) $h .= '<p class="lmgr-meta">' . esc_html( implode( ' · ', $meta ) ) . '</p>';
		if ( $rows ) $h .= '<dl class="lmgr-list">' . $rows . '</dl>';
		$h .= '<p class="lmgr-actions"><a class="lmgr-btn" href="' . esc_url( LMGR_Deals::go_url( $d, $lang ) ) . '" rel="sponsored nofollow noopener" target="_blank">' . esc_html( LMGR_I18n::t( 'see_deal', $lang ) ) . '</a></p>';
		if ( $d['checked'] !== '' ) $h .= '<p class="lmgr-checked">' . esc_html( sprintf( LMGR_I18n::t( 'checked', $lang ), LMGR_I18n::date( $d['checked'], $lang ) ) ) . '</p>';
		return $h . '</section>';
	}

	public static function cta( array $d, $lang ) {
		$h  = '<aside class="lmgr lmgr-cta" lang="' . esc_attr( LMGR_I18n::html_lang( $lang ) ) . '">';
		$h .= '<p class="lmgr-pricebar">' . self::price_html( $d, $lang ) . '</p>';
		$h .= '<p class="lmgr-actions"><a class="lmgr-btn" href="' . esc_url( LMGR_Deals::go_url( $d, $lang ) ) . '" rel="sponsored nofollow noopener" target="_blank">' . esc_html( LMGR_I18n::t( 'see_deal', $lang ) ) . '</a></p>';
		if ( LMGR_Deals::settings()['disclosure'] ) $h .= '<p class="lmgr-disclosure">' . esc_html( LMGR_I18n::t( 'disclosure', $lang ) ) . '</p>';
		return $h . '</aside>';
	}

	// ---- Expired deals out of Google ---------------------------------------------------

	private static function expired_here() {
		if ( ! is_singular() ) return false;
		$deal = self::deal_of( get_queried_object_id() );
		return $deal && LMGR_Deals::settings()['noindex_expired'] && LMGR_Deals::is_expired( $deal[0] );
	}

	public static function robots( $r ) {
		if ( self::expired_here() ) { $r['noindex'] = true; unset( $r['index'] ); }
		return $r;
	}

	public static function robots_rm( $r ) {
		if ( self::expired_here() ) $r['index'] = 'noindex';
		return $r;
	}
}
