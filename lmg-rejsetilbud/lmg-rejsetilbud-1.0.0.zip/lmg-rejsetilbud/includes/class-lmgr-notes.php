<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Release notes, from RELEASE-NOTES.md in the plugin folder.
 *
 * Rejsetilbud → Settings → Release notes shows the file. After an update,
 * each editor sees one notice linking to it, until they open the tab or dismiss
 * the notice (user meta lmgr_notes_seen = the version they saw).
 */
class LMGR_Notes {

	public static function boot() {
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
		add_action( 'wp_ajax_lmgr_notes_seen', function () {
			check_ajax_referer( 'lmgr_notes_seen' );
			update_user_meta( get_current_user_id(), 'lmgr_notes_seen', LMGR_VERSION );
			wp_send_json_success();
		} );
	}

	public static function notice() {
		if ( ! current_user_can( 'edit_others_posts' ) || get_user_meta( get_current_user_id(), 'lmgr_notes_seen', true ) === LMGR_VERSION ) return;
		if ( isset( $_GET['page'], $_GET['tab'] ) && $_GET['page'] === LMGR_Admin::SLUG && $_GET['tab'] === 'notes' ) return;
		echo '<div class="notice notice-info is-dismissible" id="lmgr-notes-notice"><p>LMG Rejsetilbud ' . esc_html( LMGR_VERSION ) . ' is installed. <a href="' . esc_url( LMGR_Admin::url( 'notes' ) ) . '">What is new</a></p></div>';
		echo "<script>jQuery(document).on('click','#lmgr-notes-notice .notice-dismiss',function(){jQuery.post(ajaxurl,{action:'lmgr_notes_seen',_ajax_nonce:'" . esc_js( wp_create_nonce( 'lmgr_notes_seen' ) ) . "'});});</script>";
	}

	public static function render() {
		update_user_meta( get_current_user_id(), 'lmgr_notes_seen', LMGR_VERSION );
		$md = is_readable( LMGR_DIR . 'RELEASE-NOTES.md' ) ? file_get_contents( LMGR_DIR . 'RELEASE-NOTES.md' ) : '';
		echo '<div class="lmgr-notes" style="max-width:820px">' . ( $md === '' ? '<p>No release notes found.</p>' : self::html( $md ) ) . '</div>';
	}

	/** The few Markdown forms the notes use: headings, lists (two-space nesting), bold, code, paragraphs. */
	public static function html( $md ) {
		$inline = function ( $t ) {
			$t = esc_html( $t );
			$t = preg_replace( '/\*\*(.+?)\*\*/', '<strong>$1</strong>', $t );
			return preg_replace( '/`([^`]+)`/', '<code>$1</code>', $t );
		};
		$out   = '';
		$depth = 0;
		foreach ( preg_split( '/\R/', $md ) as $line ) {
			$item = preg_match( '/^( *)- (.*)$/', $line, $m );
			$want = $item ? intdiv( strlen( $m[1] ), 2 ) + 1 : 0;
			while ( $depth > $want ) { $out .= '</li></ul>'; $depth--; }
			if ( $item ) {
				if ( $depth < $want ) { $out .= '<ul style="list-style:disc;margin-left:20px">'; $depth++; }
				else $out .= '</li>';
				$out .= '<li>' . $inline( $m[2] );
				continue;
			}
			if ( trim( $line ) === '' ) continue;
			if ( preg_match( '/^(#{1,3}) (.*)$/', $line, $h ) ) {
				$n    = strlen( $h[1] );
				$out .= '<h' . $n . '>' . $inline( $h[2] ) . '</h' . $n . '>';
			} else {
				$out .= '<p>' . $inline( $line ) . '</p>';
			}
		}
		while ( $depth > 0 ) { $out .= '</li></ul>'; $depth--; }
		return $out;
	}
}
