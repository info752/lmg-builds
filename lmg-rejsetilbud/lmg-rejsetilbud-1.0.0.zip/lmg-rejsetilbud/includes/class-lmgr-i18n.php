<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Reader-facing words in the ten LMG Translator languages (Norwegian is `nb`). */
class LMGR_I18n {

	const LANGS = array( 'da', 'en', 'de', 'fr', 'es', 'it', 'sv', 'nb', 'pt', 'fi' );

	const NAMES = array( 'da' => 'Danish', 'en' => 'English', 'de' => 'German', 'fr' => 'French', 'es' => 'Spanish', 'it' => 'Italian', 'sv' => 'Swedish', 'nb' => 'Norwegian', 'pt' => 'Portuguese', 'fi' => 'Finnish' );

	public static function table() {
		static $t = null;
		if ( $t !== null ) return $t;
		$t = array(
			'box_title' => array(
				'da' => 'Rejsetilbud til %s', 'en' => 'Travel deals: %s', 'de' => 'Reiseangebote: %s', 'fr' => 'Offres de voyage : %s',
				'es' => 'Ofertas de viaje: %s', 'it' => 'Offerte di viaggio: %s', 'sv' => 'Reseerbjudanden till %s', 'nb' => 'Reisetilbud til %s',
				'pt' => 'Ofertas de viagem: %s', 'fi' => 'Matkatarjoukset: %s',
			),
			'box_intro' => array(
				'da' => 'Udvalgte tilbud lige nu. Vi har læst det med småt, så du ved, hvad du får.',
				'en' => 'Hand-picked offers right now. We have read the small print, so you know what you get.',
				'de' => 'Ausgewählte Angebote. Wir haben das Kleingedruckte gelesen, damit Sie wissen, was Sie bekommen.',
				'fr' => 'Une sélection d’offres du moment. Nous avons lu les petites lignes pour vous.',
				'es' => 'Ofertas seleccionadas ahora mismo. Hemos leído la letra pequeña para que sepas lo que obtienes.',
				'it' => 'Offerte selezionate del momento. Abbiamo letto le clausole per te.',
				'sv' => 'Utvalda erbjudanden just nu. Vi har läst det finstilta, så att du vet vad du får.',
				'nb' => 'Utvalgte tilbud akkurat nå. Vi har lest det med liten skrift, så du vet hva du får.',
				'pt' => 'Ofertas selecionadas do momento. Lemos as letras miúdas para você.',
				'fi' => 'Valitut tarjoukset juuri nyt. Luimme pienen präntin puolestasi.',
			),
			'all_title' => array(
				'da' => 'Aktuelle rejsetilbud', 'en' => 'Current travel deals', 'de' => 'Aktuelle Reiseangebote', 'fr' => 'Offres de voyage du moment',
				'es' => 'Ofertas de viaje actuales', 'it' => 'Offerte di viaggio del momento', 'sv' => 'Aktuella reseerbjudanden', 'nb' => 'Aktuelle reisetilbud',
				'pt' => 'Ofertas de viagem atuais', 'fi' => 'Ajankohtaiset matkatarjoukset',
			),
			'from'     => array( 'da' => 'fra %s', 'en' => 'from %s', 'de' => 'ab %s', 'fr' => 'dès %s', 'es' => 'desde %s', 'it' => 'da %s', 'sv' => 'från %s', 'nb' => 'fra %s', 'pt' => 'a partir de %s', 'fi' => 'alk. %s' ),
			'before'   => array( 'da' => 'Før %s', 'en' => 'Was %s', 'de' => 'Statt %s', 'fr' => 'Au lieu de %s', 'es' => 'Antes %s', 'it' => 'Prima %s', 'sv' => 'Förut %s', 'nb' => 'Før %s', 'pt' => 'Antes %s', 'fi' => 'Ennen %s' ),
			'per_person' => array( 'da' => 'pr. person', 'en' => 'per person', 'de' => 'pro Person', 'fr' => 'par personne', 'es' => 'por persona', 'it' => 'a persona', 'sv' => 'per person', 'nb' => 'per person', 'pt' => 'por pessoa', 'fi' => 'per henkilö' ),
			'valid'    => array( 'da' => 'Gælder til %s', 'en' => 'Valid until %s', 'de' => 'Gültig bis %s', 'fr' => 'Valable jusqu’au %s', 'es' => 'Válida hasta el %s', 'it' => 'Valida fino al %s', 'sv' => 'Gäller till %s', 'nb' => 'Gjelder til %s', 'pt' => 'Válida até %s', 'fi' => 'Voimassa %s asti' ),
			'with'     => array( 'da' => 'Hos %s', 'en' => 'With %s', 'de' => 'Bei %s', 'fr' => 'Chez %s', 'es' => 'Con %s', 'it' => 'Con %s', 'sv' => 'Hos %s', 'nb' => 'Hos %s', 'pt' => 'Com %s', 'fi' => 'Tarjoaja: %s' ),
			'departure' => array( 'da' => 'Afrejse', 'en' => 'Departure', 'de' => 'Abflug', 'fr' => 'Départ', 'es' => 'Salida', 'it' => 'Partenza', 'sv' => 'Avresa', 'nb' => 'Avreise', 'pt' => 'Partida', 'fi' => 'Lähtö' ),
			'period'   => array( 'da' => 'Rejseperiode', 'en' => 'Travel dates', 'de' => 'Reisezeitraum', 'fr' => 'Période', 'es' => 'Fechas', 'it' => 'Periodo', 'sv' => 'Resperiod', 'nb' => 'Reiseperiode', 'pt' => 'Período', 'fi' => 'Matka-aika' ),
			'includes' => array( 'da' => 'Inkluderet', 'en' => 'Included', 'de' => 'Inklusive', 'fr' => 'Inclus', 'es' => 'Incluye', 'it' => 'Incluso', 'sv' => 'Ingår', 'nb' => 'Inkludert', 'pt' => 'Inclui', 'fi' => 'Sisältää' ),
			'see_deal' => array( 'da' => 'Se tilbuddet', 'en' => 'See the deal', 'de' => 'Zum Angebot', 'fr' => 'Voir l’offre', 'es' => 'Ver la oferta', 'it' => 'Vedi l’offerta', 'sv' => 'Se erbjudandet', 'nb' => 'Se tilbudet', 'pt' => 'Ver a oferta', 'fi' => 'Katso tarjous' ),
			'read_more' => array( 'da' => 'Læs vores omtale', 'en' => 'Read our review', 'de' => 'Unsere Einschätzung', 'fr' => 'Notre avis', 'es' => 'Nuestra opinión', 'it' => 'La nostra opinione', 'sv' => 'Läs vår bedömning', 'nb' => 'Les vår omtale', 'pt' => 'Nossa opinião', 'fi' => 'Lue arviomme' ),
			'all_deals' => array( 'da' => 'Se alle rejsetilbud', 'en' => 'See all travel deals', 'de' => 'Alle Reiseangebote', 'fr' => 'Toutes les offres', 'es' => 'Ver todas las ofertas', 'it' => 'Tutte le offerte', 'sv' => 'Se alla erbjudanden', 'nb' => 'Se alle reisetilbud', 'pt' => 'Ver todas as ofertas', 'fi' => 'Kaikki tarjoukset' ),
			'disclosure' => array(
				'da' => 'Annoncelink: Vi kan få provision, hvis du bestiller via vores link. Det koster ikke dig noget, og det påvirker ikke, hvad vi skriver.',
				'en' => 'Affiliate link: we may earn a commission if you book through our link. It costs you nothing and does not change what we write.',
				'de' => 'Werbelink: Wir erhalten eventuell eine Provision, wenn Sie über unseren Link buchen. Für Sie entstehen keine Kosten, und es beeinflusst unsere Texte nicht.',
				'fr' => 'Lien affilié : nous pouvons toucher une commission si vous réservez via notre lien. Cela ne vous coûte rien et ne change pas ce que nous écrivons.',
				'es' => 'Enlace de afiliado: podemos recibir una comisión si reservas a través de nuestro enlace. No te cuesta nada y no cambia lo que escribimos.',
				'it' => 'Link di affiliazione: potremmo ricevere una commissione se prenoti tramite il nostro link. Per te non cambia nulla, né cambia ciò che scriviamo.',
				'sv' => 'Annonslänk: Vi kan få provision om du bokar via vår länk. Det kostar dig inget och påverkar inte vad vi skriver.',
				'nb' => 'Annonselenke: Vi kan få provisjon hvis du bestiller via lenken vår. Det koster deg ingenting og påvirker ikke hva vi skriver.',
				'pt' => 'Link de afiliado: podemos receber comissão se você reservar pelo nosso link. Não custa nada para você e não muda o que escrevemos.',
				'fi' => 'Kumppanilinkki: voimme saada palkkion, jos varaat linkkimme kautta. Se ei maksa sinulle mitään eikä vaikuta siihen, mitä kirjoitamme.',
			),
			'expired_title' => array( 'da' => 'Tilbuddet er udløbet', 'en' => 'This deal has expired', 'de' => 'Dieses Angebot ist abgelaufen', 'fr' => 'Cette offre a expiré', 'es' => 'Esta oferta ha caducado', 'it' => 'Questa offerta è scaduta', 'sv' => 'Erbjudandet har gått ut', 'nb' => 'Tilbudet er utløpt', 'pt' => 'Esta oferta expirou', 'fi' => 'Tarjous on päättynyt' ),
			'expired_body' => array(
				'da' => 'Det her tilbud gælder ikke længere. Find de aktuelle tilbud og alt om rejsen på siden %s.',
				'en' => 'This offer is no longer available. Find the current deals and everything about the trip on %s.',
				'de' => 'Dieses Angebot gilt nicht mehr. Aktuelle Angebote und alles zur Reise finden Sie auf der Seite %s.',
				'fr' => 'Cette offre n’est plus disponible. Retrouvez les offres actuelles et tout sur le voyage sur la page %s.',
				'es' => 'Esta oferta ya no está disponible. Encuentra las ofertas actuales y todo sobre el viaje en %s.',
				'it' => 'Questa offerta non è più disponibile. Trovi le offerte attuali e tutto sul viaggio nella pagina %s.',
				'sv' => 'Erbjudandet gäller inte längre. Hitta aktuella erbjudanden och allt om resan på sidan %s.',
				'nb' => 'Dette tilbudet gjelder ikke lenger. Finn aktuelle tilbud og alt om reisen på siden %s.',
				'pt' => 'Esta oferta não está mais disponível. Veja as ofertas atuais e tudo sobre a viagem em %s.',
				'fi' => 'Tämä tarjous ei ole enää voimassa. Löydät ajankohtaiset tarjoukset ja kaiken matkasta sivulta %s.',
			),
			'expired_body_plain' => array(
				'da' => 'Det her tilbud gælder ikke længere.', 'en' => 'This offer is no longer available.', 'de' => 'Dieses Angebot gilt nicht mehr.',
				'fr' => 'Cette offre n’est plus disponible.', 'es' => 'Esta oferta ya no está disponible.', 'it' => 'Questa offerta non è più disponibile.',
				'sv' => 'Erbjudandet gäller inte längre.', 'nb' => 'Dette tilbudet gjelder ikke lenger.', 'pt' => 'Esta oferta não está mais disponível.', 'fi' => 'Tämä tarjous ei ole enää voimassa.',
			),
			'checked' => array( 'da' => 'Pris tjekket %s. Priser kan ændre sig.', 'en' => 'Price checked %s. Prices can change.', 'de' => 'Preis geprüft am %s. Preise können sich ändern.', 'fr' => 'Prix vérifié le %s. Les prix peuvent changer.', 'es' => 'Precio comprobado el %s. Los precios pueden cambiar.', 'it' => 'Prezzo verificato il %s. I prezzi possono cambiare.', 'sv' => 'Pris kontrollerat %s. Priser kan ändras.', 'nb' => 'Pris sjekket %s. Prisene kan endre seg.', 'pt' => 'Preço verificado em %s. Os preços podem mudar.', 'fi' => 'Hinta tarkistettu %s. Hinnat voivat muuttua.' ),
		);
		return $t;
	}

	public static function t( $key, $lang ) {
		$t = self::table();
		if ( ! isset( $t[ $key ] ) ) return $key;
		$s = isset( $t[ $key ][ $lang ] ) ? $t[ $key ][ $lang ] : ( isset( $t[ $key ]['en'] ) ? $t[ $key ]['en'] : $t[ $key ]['da'] );
		return apply_filters( 'lmg_rejsetilbud_text', $s, $key, $lang );
	}

	public static function html_lang( $l ) {
		return $l === 'nb' ? 'no' : $l;
	}

	/** 3499 DKK → "3.499 kr." (da), "DKK 3,499" (en), "3 499 DKK" (fr/sv/nb/fi), "3.499 DKK" (de/es/it/pt). */
	public static function money( $amount, $currency, $lang ) {
		$amount = (float) $amount;
		$dec    = floor( $amount ) == $amount ? 0 : 2;
		$cur    = strtoupper( $currency ? $currency : 'DKK' );
		switch ( $lang ) {
			case 'da':
				$n = number_format( $amount, $dec, ',', '.' );
				return $cur === 'DKK' ? $n . ' kr.' : $n . ' ' . $cur;
			case 'en':
				$sym = array( 'EUR' => '€', 'GBP' => '£', 'USD' => '$' );
				return isset( $sym[ $cur ] ) ? $sym[ $cur ] . number_format( $amount, $dec ) : $cur . ' ' . number_format( $amount, $dec );
			case 'fr': case 'sv': case 'nb': case 'fi':
				return number_format( $amount, $dec, ',', "\u{00A0}" ) . "\u{00A0}" . $cur;
			default:
				return number_format( $amount, $dec, ',', '.' ) . ' ' . $cur;
		}
	}

	public static function date( $ymd, $lang ) {
		$ts = strtotime( $ymd . ' 12:00:00' );
		if ( ! $ts ) return $ymd;
		switch ( $lang ) {
			case 'en':
				$m = array( 1 => 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December' );
				return gmdate( 'j', $ts ) . ' ' . $m[ (int) gmdate( 'n', $ts ) ] . ' ' . gmdate( 'Y', $ts );
			case 'sv':
				return gmdate( 'Y-m-d', $ts );
			case 'fr': case 'es': case 'it': case 'pt':
				return gmdate( 'd/m/Y', $ts );
			default:
				return gmdate( 'j.n.Y', $ts );
		}
	}
}
