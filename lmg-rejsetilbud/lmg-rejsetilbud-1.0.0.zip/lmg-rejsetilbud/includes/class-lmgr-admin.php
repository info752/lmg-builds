<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LMGR_Admin {

	const SLUG = 'lmg-rejsetilbud';

	public static function boot() {
		add_action( 'add_meta_boxes_' . LMGR_CPT, array( __CLASS__, 'boxes' ) );
		add_action( 'save_post_' . LMGR_CPT, array( __CLASS__, 'save' ), 10, 2 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_post_lmgr_clicks_csv', array( __CLASS__, 'csv' ) );
		add_filter( 'manage_' . LMGR_CPT . '_posts_columns', array( __CLASS__, 'columns' ) );
		add_action( 'manage_' . LMGR_CPT . '_posts_custom_column', array( __CLASS__, 'column' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', function ( $hook ) {
			if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) || get_post_type() !== LMGR_CPT ) return;
			wp_add_inline_style( 'common', '.lmgr-mb label{display:block;font-weight:600;margin:.8em 0 .2em}.lmgr-mb input[type=text],.lmgr-mb input[type=url],.lmgr-mb textarea,.lmgr-mb select{width:100%}.lmgr-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:0 1.2em}.lmgr-mb .description{color:#646970}.lmgr-mb h4{margin:1.4em 0 .2em;padding-top:1em;border-top:1px solid #dcdcde}.lmgr-langs label{display:inline-block;font-weight:400;margin-right:1em}' );
		} );
	}

	public static function url( $tab = 'overview' ) {
		return admin_url( 'edit.php?post_type=' . LMGR_CPT . '&page=' . self::SLUG . '&tab=' . $tab );
	}

	// ---- Meta box ------------------------------------------------------------------

	public static function boxes() {
		add_meta_box( 'lmgr', LMGR_Deals::is_travel() ? 'The deal' : 'Tilbuddet', array( __CLASS__, 'render' ), LMGR_CPT, 'normal', 'high' );
		add_meta_box( 'lmgr_fb', 'Facebook', array( __CLASS__, 'render_fb' ), LMGR_CPT, 'side', 'default' );
	}

	/** Country pages to pick from: LMG Faktabokse's country pages first, then all other pages. */
	private static function country_options() {
		$country = array();
		if ( class_exists( 'LMGF_Data' ) && method_exists( 'LMGF_Data', 'map' ) ) {
			foreach ( (array) LMGF_Data::map() as $page ) {
				if ( get_post( $page ) ) $country[ (int) $page ] = get_the_title( $page );
			}
			asort( $country );
		}
		$other = array();
		foreach ( get_pages( array( 'post_status' => 'publish', 'sort_column' => 'post_title' ) ) as $p ) {
			if ( ! isset( $country[ $p->ID ] ) && ! get_post_meta( $p->ID, '_lmgt_source', true ) ) $other[ $p->ID ] = $p->post_title;
		}
		return array( $country, $other );
	}

	public static function render( $post ) {
		wp_nonce_field( 'lmgr_save', 'lmgr_nonce' );
		$d   = LMGR_Deals::local( $post->ID );
		$d   = $d ? $d : LMGR_Deals::normalize( array( 'langs' => LMGR_Deals::settings()['default_langs'], 'lang' => LMGR_Deals::site_lang() ) );
		$new = $post->post_status === 'auto-draft';
		if ( $new ) $d['langs'] = LMGR_Deals::settings()['default_langs'];
		$v   = function ( $k ) use ( $d ) { return esc_attr( (string) $d[ $k ] ); };

		echo '<div class="lmgr-mb">';
		echo '<p class="description">Headline above: lead with the place and the price, for example "Phuket: 10 dage med fly og hotel fra 6.999 kr.". The text below the headline is our own take: who the trip suits, what is good, what to watch in the small print. That is what sets us apart from a plain deals list.</p>';

		echo '<div class="lmgr-grid">';
		echo '<div><label for="lmgr_provider">Travel agency / provider</label><input type="text" id="lmgr_provider" name="lmgr[provider]" value="' . $v( 'provider' ) . '" placeholder="Apollo"></div>';
		echo '<div><label for="lmgr_price">Price from</label><input type="text" id="lmgr_price" name="lmgr[price]" value="' . $v( 'price' ) . '" placeholder="6999" inputmode="decimal"></div>';
		echo '<div><label for="lmgr_old">Normal price (optional)</label><input type="text" id="lmgr_old" name="lmgr[old_price]" value="' . $v( 'old_price' ) . '" placeholder="8999" inputmode="decimal"></div>';
		echo '<div><label for="lmgr_cur">Currency</label><select id="lmgr_cur" name="lmgr[currency]">';
		foreach ( array( 'DKK', 'EUR', 'SEK', 'NOK', 'GBP', 'USD' ) as $c ) echo '<option' . selected( $d['currency'], $c, false ) . '>' . $c . '</option>';
		echo '</select></div>';
		echo '</div>';
		echo '<p><label style="font-weight:400"><input type="checkbox" name="lmgr[per_person]" value="1" ' . checked( $d['per_person'], 1, false ) . '> Price is per person</label></p>';

		echo '<label for="lmgr_url">Link to the deal (the affiliate link from Partner-ads, Adtraction, Awin or the agency)</label><input type="url" id="lmgr_url" name="lmgr[url]" value="' . esc_attr( $d['url'] ) . '" placeholder="https://" required>';
		echo '<p class="description">Readers go through our own address first, so every click is counted, then on to this link.</p>';

		echo '<div class="lmgr-grid">';
		echo '<div><label for="lmgr_inc">Included</label><input type="text" id="lmgr_inc" name="lmgr[includes]" value="' . $v( 'includes' ) . '" placeholder="Fly, 9 nætter på hotel, transfer"></div>';
		echo '<div><label for="lmgr_dep">Departure</label><input type="text" id="lmgr_dep" name="lmgr[departure]" value="' . $v( 'departure' ) . '" placeholder="København"></div>';
		echo '<div><label for="lmgr_per">Travel dates</label><input type="text" id="lmgr_per" name="lmgr[period]" value="' . $v( 'period' ) . '" placeholder="Januar–marts 2027"></div>';
		echo '<div><label for="lmgr_exp">Valid until (last day)</label><input type="date" id="lmgr_exp" name="lmgr[expires]" value="' . $v( 'expires' ) . '"></div>';
		echo '<div><label for="lmgr_chk">Price checked</label><input type="date" id="lmgr_chk" name="lmgr[checked]" value="' . esc_attr( $d['checked'] !== '' ? $d['checked'] : ( $new ? current_time( 'Y-m-d' ) : '' ) ) . '"></div>';
		echo '</div>';
		echo '<p class="description">On the day after "Valid until" the deal leaves every box, and its page says it has expired and points to the country page.</p>';

		list( $country, $other ) = self::country_options();
		echo '<h4>Country pages</h4><p class="description">The deal shows in the box on these pages. Hold Ctrl (Cmd on Mac) to pick more than one.</p>';
		echo '<select name="lmgr[countries][]" multiple size="8">';
		if ( $country ) {
			echo '<optgroup label="Country pages (LMG Faktabokse)">';
			foreach ( $country as $id => $t ) echo '<option value="' . (int) $id . '"' . ( in_array( (int) $id, $d['countries'], true ) ? ' selected' : '' ) . '>' . esc_html( $t ) . '</option>';
			echo '</optgroup><optgroup label="Other pages">';
		}
		foreach ( $other as $id => $t ) echo '<option value="' . (int) $id . '"' . ( in_array( (int) $id, $d['countries'], true ) ? ' selected' : '' ) . '>' . esc_html( $t ) . '</option>';
		if ( $country ) echo '</optgroup>';
		echo '</select>';

		echo '<h4>Languages</h4><p class="description">Where the deal may be shown. A package from Copenhagen is usually for Danish readers only; tick other languages only if readers there can book it. The deal shows in a language once its translation is published.</p><p class="lmgr-langs">';
		foreach ( LMGR_I18n::LANGS as $l ) {
			$own = $l === LMGR_Deals::site_lang();
			echo '<label><input type="checkbox" name="lmgr[langs][]" value="' . esc_attr( $l ) . '" ' . checked( $own || in_array( $l, $d['langs'], true ), true, false ) . ( $own ? ' disabled' : '' ) . '> ' . esc_html( LMGR_I18n::NAMES[ $l ] ) . '</label>';
		}
		echo '</p>';

		if ( LMGR_Sync::on() ) {
			$s = get_post_meta( $post->ID, '_lmgr_sync', true );
			echo '<p class="description">traveltalk.travel: ' . ( is_array( $s ) ? ( $s['ok'] ? 'deal facts sent ' . esc_html( $s['at'] ) : '<span style="color:#b32d2e">not sent (' . esc_html( $s['msg'] ) . '). It is tried again with the Translator\'s queue.</span>' ) : 'sent when you save.' ) . '</p>';
		}
		$c = LMGR_Deals::clicks( $post->ID );
		if ( ! $new ) echo '<p class="description">Clicks: ' . (int) $c['month'] . ' this month, ' . (int) $c['total'] . ' in all.</p>';
		echo '</div>';
	}

	public static function fb_text( $post ) {
		$d = LMGR_Deals::local( $post->ID );
		if ( ! $d ) return '';
		$l     = LMGR_Deals::site_lang();
		$lines = array( get_the_title( $post ), '' );
		$price = $d['price'] !== '' ? sprintf( LMGR_I18n::t( 'from', $l ), LMGR_I18n::money( $d['price'], $d['currency'], $l ) ) . ( $d['per_person'] ? ' ' . LMGR_I18n::t( 'per_person', $l ) : '' ) : '';
		if ( $price ) $lines[] = '💰 ' . ucfirst( $price ) . ( $d['old_price'] !== '' && (float) $d['old_price'] > (float) $d['price'] ? ' (' . lcfirst( sprintf( LMGR_I18n::t( 'before', $l ), LMGR_I18n::money( $d['old_price'], $d['currency'], $l ) ) ) . ')' : '' );
		if ( $d['includes'] !== '' ) $lines[] = '✈️ ' . $d['includes'];
		if ( $d['period'] !== '' ) $lines[] = '📅 ' . $d['period'] . ( $d['departure'] !== '' ? ', ' . $d['departure'] : '' );
		if ( $d['expires'] !== '' ) $lines[] = '⏳ ' . sprintf( LMGR_I18n::t( 'valid', $l ), LMGR_I18n::date( $d['expires'], $l ) );
		$ex = trim( wp_strip_all_tags( get_the_excerpt( $post ) ) );
		if ( $ex !== '' ) { $lines[] = ''; $lines[] = $ex; }
		$lines[] = '';
		$lines[] = '👉 ' . get_permalink( $post );
		return implode( "\n", $lines );
	}

	public static function render_fb( $post ) {
		if ( $post->post_status === 'auto-draft' ) { echo '<p class="description">Save the deal first.</p>'; return; }
		echo '<p class="description">Ready to paste. The link goes to our deal page, so the reader meets our review before the agency. Write the excerpt as the one line that sells it.</p>';
		echo '<textarea id="lmgr-fb" rows="11" style="width:100%;font-size:12px" readonly>' . esc_textarea( self::fb_text( $post ) ) . '</textarea>';
		echo '<p><button type="button" class="button" onclick="var t=document.getElementById(\'lmgr-fb\');t.select();(navigator.clipboard?navigator.clipboard.writeText(t.value):Promise.resolve(document.execCommand(\'copy\'))).then(function(){this.textContent=\'Copied\';}.bind(this));">Copy</button></p>';
	}

	public static function save( $id, $post ) {
		if ( ! isset( $_POST['lmgr_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['lmgr_nonce'] ) ), 'lmgr_save' ) ) return;
		if ( wp_is_post_revision( $id ) || wp_is_post_autosave( $id ) || ! current_user_can( 'edit_post', $id ) ) return;
		$in  = isset( $_POST['lmgr'] ) ? (array) wp_unslash( $_POST['lmgr'] ) : array();
		$num = function ( $k ) use ( $in ) {
			$v = isset( $in[ $k ] ) ? str_replace( array( ' ', '.', "\u{00A0}" ), '', trim( (string) $in[ $k ] ) ) : '';
			$v = str_replace( ',', '.', $v );
			return $v !== '' && is_numeric( $v ) ? (string) (float) $v : '';
		};
		$ymd = function ( $k ) use ( $in ) { return isset( $in[ $k ] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $in[ $k ] ) ? $in[ $k ] : ''; };
		$txt = function ( $k ) use ( $in ) { return isset( $in[ $k ] ) ? sanitize_text_field( $in[ $k ] ) : ''; };
		$url = isset( $in['url'] ) ? esc_url_raw( trim( $in['url'] ), array( 'http', 'https' ) ) : '';
		$cur = isset( $in['currency'] ) && in_array( $in['currency'], array( 'DKK', 'EUR', 'SEK', 'NOK', 'GBP', 'USD' ), true ) ? $in['currency'] : 'DKK';
		$old = LMGR_Deals::raw( $id );

		LMGR_Deals::save_record( $id, array(
			'provider'   => $txt( 'provider' ),
			'url'        => $url,
			'price'      => $num( 'price' ),
			'old_price'  => $num( 'old_price' ),
			'currency'   => $cur,
			'per_person' => empty( $in['per_person'] ) ? 0 : 1,
			'includes'   => $txt( 'includes' ),
			'departure'  => $txt( 'departure' ),
			'period'     => $txt( 'period' ),
			'expires'    => $ymd( 'expires' ),
			'checked'    => $ymd( 'checked' ),
			'langs'      => array_merge( array( LMGR_Deals::site_lang() ), isset( $in['langs'] ) ? array_map( 'sanitize_key', (array) $in['langs'] ) : array() ),
			'countries'  => isset( $in['countries'] ) ? array_map( 'intval', (array) $in['countries'] ) : array(),
			'lang'       => LMGR_Deals::site_lang(),
		) );
		// Country pages the deal was taken off also need a fresh box.
		if ( ! empty( $old['countries'] ) ) LMGR_Deals::purge( (array) $old['countries'] );
	}

	// ---- List columns ------------------------------------------------------------------

	public static function columns( $c ) {
		$out = array();
		foreach ( $c as $k => $v ) {
			$out[ $k ] = $v;
			if ( $k === 'title' ) {
				$out['lmgr_price']   = 'Price';
				$out['lmgr_valid']   = 'Valid until';
				$out['lmgr_country'] = 'Country pages';
				$out['lmgr_clicks']  = 'Clicks (month / all)';
			}
		}
		unset( $out['tags'] );
		return $out;
	}

	public static function column( $col, $id ) {
		$d = LMGR_Deals::local( $id );
		if ( ! $d ) return;
		$l = LMGR_Deals::site_lang();
		switch ( $col ) {
			case 'lmgr_price':
				echo $d['price'] !== '' ? esc_html( LMGR_I18n::money( $d['price'], $d['currency'], $l ) ) : '—';
				if ( $d['provider'] !== '' ) echo '<br><span class="description">' . esc_html( $d['provider'] ) . '</span>';
				if ( $d['url'] === '' ) echo '<br><span style="color:#b32d2e">No link</span>';
				break;
			case 'lmgr_valid':
				if ( $d['expires'] === '' ) { echo '—'; break; }
				echo LMGR_Deals::is_expired( $d ) ? '<span style="color:#b32d2e">' . esc_html( LMGR_I18n::date( $d['expires'], $l ) ) . ' · expired</span>' : esc_html( LMGR_I18n::date( $d['expires'], $l ) );
				break;
			case 'lmgr_country':
				$n = array();
				foreach ( $d['countries'] as $c ) $n[] = '<a href="' . esc_url( get_permalink( $c ) ) . '">' . esc_html( get_the_title( $c ) ) . '</a>';
				echo $n ? implode( ', ', $n ) : '<span style="color:#b32d2e">None: shows in no box</span>'; // phpcs:ignore
				break;
			case 'lmgr_clicks':
				$c = LMGR_Deals::clicks( $id );
				echo (int) $c['month'] . ' / ' . (int) $c['total'];
				break;
		}
	}

	// ---- Settings page -------------------------------------------------------------------

	public static function menu() {
		add_submenu_page( 'edit.php?post_type=' . LMGR_CPT, 'LMG Rejsetilbud', 'Settings and clicks', 'edit_others_posts', self::SLUG, array( __CLASS__, 'page' ) );
	}

	public static function page() {
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'overview';
		$tabs = array( 'overview' => 'Clicks', 'settings' => 'Settings', 'notes' => 'Release notes' );
		echo '<div class="wrap"><h1>LMG Rejsetilbud ' . esc_html( LMGR_VERSION ) . '</h1><h2 class="nav-tab-wrapper">';
		foreach ( $tabs as $k => $t ) echo '<a class="nav-tab' . ( $tab === $k ? ' nav-tab-active' : '' ) . '" href="' . esc_url( self::url( $k ) ) . '">' . esc_html( $t ) . '</a>';
		echo '</h2>';
		if ( isset( $_GET['lmgr_msg'] ) ) echo '<div class="notice notice-success"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['lmgr_msg'] ) ) ) . '</p></div>';
		if ( $tab === 'notes' ) LMGR_Notes::render();
		elseif ( $tab === 'settings' ) self::settings_tab();
		else self::overview_tab();
		echo '</div>';
	}

	/** Every deal with clicks per month: the numbers to show an agency. */
	private static function click_rows() {
		$rows = array();
		if ( LMGR_Sync::is_target() ) {
			foreach ( LMGR_Deals::remote_all() as $id => $d ) {
				$d = LMGR_Deals::normalize( $d );
				$rows[] = array( 'id' => (int) $id, 'title' => $d['title'], 'provider' => $d['provider'], 'expires' => $d['expires'], 'status' => $d['status'], 'clicks' => LMGR_Deals::clicks( (int) $id, true ) );
			}
		} else {
			foreach ( get_posts( array( 'post_type' => LMGR_CPT, 'post_status' => array( 'publish', 'draft', 'pending', 'future', 'private' ), 'posts_per_page' => -1, 'fields' => 'ids', 'no_found_rows' => true ) ) as $id ) {
				$d = LMGR_Deals::local( $id );
				$rows[] = array( 'id' => (int) $id, 'title' => $d['title'], 'provider' => $d['provider'], 'expires' => $d['expires'], 'status' => $d['status'], 'clicks' => LMGR_Deals::clicks( $id ) );
			}
		}
		usort( $rows, function ( $a, $b ) { return $b['clicks']['total'] <=> $a['clicks']['total']; } );
		return $rows;
	}

	private static function overview_tab() {
		$rows = self::click_rows();
		echo '<p>' . ( LMGR_Sync::is_target() ? 'Deals sent from traveltalk.dk, with clicks counted on this site.' : 'Clicks on "See the deal" from our boxes and deal pages, counted before the reader leaves for the agency. Search engines and link previews are not counted.' ) . '</p>';
		echo '<p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=lmgr_clicks_csv' ), 'lmgr_csv' ) ) . '">Download clicks (CSV, per deal and month)</a></p>';
		if ( ! $rows ) { echo '<p>No deals yet.</p>'; return; }
		$by_provider = array();
		foreach ( $rows as $r ) {
			$p = $r['provider'] !== '' ? $r['provider'] : '—';
			if ( ! isset( $by_provider[ $p ] ) ) $by_provider[ $p ] = array( 0, 0, 0 );
			$by_provider[ $p ][0]++;
			$by_provider[ $p ][1] += $r['clicks']['month'];
			$by_provider[ $p ][2] += $r['clicks']['total'];
		}
		uasort( $by_provider, function ( $a, $b ) { return $b[2] <=> $a[2]; } );
		echo '<h2>Per agency</h2><table class="widefat striped" style="max-width:700px"><thead><tr><th>Agency</th><th>Deals</th><th>Clicks this month</th><th>Clicks in all</th></tr></thead><tbody>';
		foreach ( $by_provider as $p => $n ) echo '<tr><td>' . esc_html( $p ) . '</td><td>' . (int) $n[0] . '</td><td>' . (int) $n[1] . '</td><td>' . (int) $n[2] . '</td></tr>';
		echo '</tbody></table>';
		echo '<h2>Per deal</h2><table class="widefat striped"><thead><tr><th>Deal</th><th>Agency</th><th>Valid until</th><th>Status</th><th>This month</th><th>In all</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$t = LMGR_Sync::is_target() ? esc_html( $r['title'] ) : '<a href="' . esc_url( get_edit_post_link( $r['id'] ) ) . '">' . esc_html( $r['title'] ) . '</a>';
			$exp = $r['expires'] !== '' && $r['expires'] < LMGR_Deals::today();
			echo '<tr><td>' . $t . '</td><td>' . esc_html( $r['provider'] ) . '</td><td>' . esc_html( $r['expires'] ) . ( $exp ? ' <span style="color:#b32d2e">expired</span>' : '' ) . '</td><td>' . esc_html( $r['status'] ) . '</td><td>' . (int) $r['clicks']['month'] . '</td><td>' . (int) $r['clicks']['total'] . '</td></tr>'; // phpcs:ignore
		}
		echo '</tbody></table>';
	}

	public static function csv() {
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_die( 'Not allowed' );
		check_admin_referer( 'lmgr_csv' );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="rejsetilbud-klik-' . current_time( 'Y-m-d' ) . '.csv"' );
		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" );
		fputcsv( $out, array( 'site', 'deal_id', 'deal', 'agency', 'valid_until', 'month', 'clicks' ), ';' );
		$site = wp_parse_url( home_url(), PHP_URL_HOST );
		foreach ( self::click_rows() as $r ) {
			$months = $r['clicks']['by_month'];
			if ( ! $months ) $months = array( current_time( 'Y-m' ) => 0 );
			ksort( $months );
			foreach ( $months as $m => $n ) fputcsv( $out, array( $site, $r['id'], $r['title'], $r['provider'], $r['expires'], $m, (int) $n ), ';' );
		}
		fclose( $out );
		exit;
	}

	private static function settings_tab() {
		$s = LMGR_Deals::settings();
		echo '<form method="post">';
		wp_nonce_field( 'lmgr_settings', 'lmgr_settings_nonce' );
		echo '<table class="form-table">';
		echo '<tr><th>Deals per box</th><td><input type="number" name="s[per_box]" min="1" max="12" value="' . (int) $s['per_box'] . '" class="small-text"> <span class="description">On each country page. Newest first.</span></td></tr>';
		echo '<tr><th>Where the box goes</th><td><select name="s[place]">'
			. '<option value="auto"' . selected( $s['place'], 'auto', false ) . '>Right under "Sådan kommer du til …" when the fact boxes show it, otherwise at the end of the text</option>'
			. '<option value="after"' . selected( $s['place'], 'after', false ) . '>At the end of the text</option>'
			. '<option value="manual"' . selected( $s['place'], 'manual', false ) . '>Only where I put [lmg_rejsetilbud]</option>'
			. '</select><p class="description">[lmg_rejsetilbud] puts the box anywhere in a text. [lmg_rejsetilbud land="123"] shows the deals for the page with ID 123; [lmg_rejsetilbud land="alle" antal="9"] shows the newest deals for all countries.</p></td></tr>';
		echo '<tr><th>Expired deals</th><td><label><input type="checkbox" name="s[noindex_expired]" value="1" ' . checked( $s['noindex_expired'], 1, false ) . '> Ask Google not to index a deal page once it has expired</label></td></tr>';
		echo '<tr><th>Affiliate notice</th><td><label><input type="checkbox" name="s[disclosure]" value="1" ' . checked( $s['disclosure'], 1, false ) . '> Show "Annoncelink: Vi kan få provision …" under boxes and deals</label><p class="description">Danish marketing law requires that readers can see a link is commercial. Leave it on.</p></td></tr>';
		echo '<tr><th>New deals are shown in</th><td>';
		foreach ( LMGR_I18n::LANGS as $l ) echo '<label style="margin-right:1em"><input type="checkbox" name="s[default_langs][]" value="' . esc_attr( $l ) . '" ' . checked( in_array( $l, $s['default_langs'], true ) || $l === LMGR_Deals::site_lang(), true, false ) . '> ' . esc_html( LMGR_I18n::NAMES[ $l ] ) . '</label>';
		echo '</td></tr>';
		echo '<tr><th>Address of deal pages</th><td>' . esc_html( home_url( '/' ) ) . '<input type="text" name="s[slug]" value="' . esc_attr( $s['slug'] ) . '" class="regular-text" style="width:12em">/…</td></tr>';
		echo '</table>';
		submit_button( 'Save settings' );
		echo '</form>';

		if ( LMGR_Sync::on() ) {
			echo '<h2>traveltalk.travel</h2><p>Deal facts (price, link, dates, countries, languages) go to traveltalk.travel each time you save a deal, through the Translator\'s bridge. The deal\'s text goes there as its translation. Use this after installing the plugin on traveltalk.travel, or if a send failed.</p>';
			echo '<form method="post">';
			wp_nonce_field( 'lmgr_push_all', 'lmgr_push_nonce' );
			submit_button( 'Send all deals to traveltalk.travel again', 'secondary', 'lmgr_push_all', false );
			echo '</form>';
		}
	}

	public static function save_settings() {
		if ( isset( $_POST['lmgr_push_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['lmgr_push_nonce'] ) ), 'lmgr_push_all' ) && current_user_can( 'edit_others_posts' ) ) {
			list( $ok, $fail ) = LMGR_Sync::push_all();
			wp_safe_redirect( add_query_arg( 'lmgr_msg', rawurlencode( sprintf( '%d deals sent, %d failed.', $ok, $fail ) ), self::url( 'settings' ) ) );
			exit;
		}
		if ( ! isset( $_POST['lmgr_settings_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['lmgr_settings_nonce'] ) ), 'lmgr_settings' ) || ! current_user_can( 'manage_options' ) ) return;
		$in  = isset( $_POST['s'] ) ? (array) wp_unslash( $_POST['s'] ) : array();
		$old = LMGR_Deals::settings();
		$new = array(
			'per_box'         => max( 1, min( 12, isset( $in['per_box'] ) ? (int) $in['per_box'] : 3 ) ),
			'place'           => isset( $in['place'] ) && in_array( $in['place'], array( 'auto', 'after', 'manual' ), true ) ? $in['place'] : 'auto',
			'noindex_expired' => empty( $in['noindex_expired'] ) ? 0 : 1,
			'disclosure'      => empty( $in['disclosure'] ) ? 0 : 1,
			'default_langs'   => array_values( array_intersect( array_map( 'sanitize_key', isset( $in['default_langs'] ) ? (array) $in['default_langs'] : array() ), LMGR_I18n::LANGS ) ),
			'slug'            => sanitize_title( isset( $in['slug'] ) && $in['slug'] !== '' ? $in['slug'] : LMGR_Deals::defaults()['slug'] ),
		);
		update_option( 'lmgr_settings', $new, false );
		if ( $new['slug'] !== $old['slug'] ) {
			LMGR_Deals::register();
			flush_rewrite_rules();
		}
		do_action( 'litespeed_purge_all' );
		wp_safe_redirect( add_query_arg( 'lmgr_msg', 'Settings saved.', self::url( 'settings' ) ) );
		exit;
	}
}
