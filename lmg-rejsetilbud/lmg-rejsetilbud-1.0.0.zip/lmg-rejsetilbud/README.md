# LMG Rejsetilbud

Travel deals linked to country pages, for traveltalk.dk and traveltalk.travel. See RELEASE-NOTES.md.

- Post type `rejsetilbud`; deal facts in `_lmgr`, `_lmgr_country`, `_lmgr_expires`, clicks in `_lmgr_clicks`.
- Box under LMG Faktabokse's `lmg_faktabokse_after_getting_there`, else end of content; shortcode `[lmg_rejsetilbud]`.
- LMG Translator: added through `lmgt_post_types`, marked `_lmgt_as_written`. Deal facts go to .travel over the bridge (`POST lmgt/v2/rejsetilbud`), stored in option `lmgr_remote`.
- Tracked links: `/?lmgr_go=<id>` (.dk) and `/?lmgr_go=r<dk id>` (.travel).
