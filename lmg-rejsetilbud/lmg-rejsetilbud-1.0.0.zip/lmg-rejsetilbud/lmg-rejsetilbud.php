<?php
/**
 * Plugin Name: LMG Rejsetilbud
 * Description: Travel deals ("Rejsetilbud") linked to country pages: deal pages, a deals box on each country page, expiry, click counting, Facebook text, and translation through LMG Translator (also on traveltalk.travel).
 * Version:     1.0.0
 * Author:      Leisure Media Group
 * Text Domain: lmg-rejsetilbud
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'LMGR_VERSION', '1.0.0' );
define( 'LMGR_FILE', __FILE__ );
define( 'LMGR_DIR', plugin_dir_path( __FILE__ ) );
define( 'LMGR_URL', plugin_dir_url( __FILE__ ) );
define( 'LMGR_CPT', 'rejsetilbud' );

require_once LMGR_DIR . 'includes/class-lmgr-i18n.php';
require_once LMGR_DIR . 'includes/class-lmgr-deals.php';
require_once LMGR_DIR . 'includes/class-lmgr-sync.php';
require_once LMGR_DIR . 'includes/class-lmgr-front.php';
require_once LMGR_DIR . 'includes/class-lmgr-admin.php';
require_once LMGR_DIR . 'includes/class-lmgr-notes.php';

LMGR_Deals::boot();
LMGR_Sync::boot();
LMGR_Front::boot();
if ( is_admin() ) {
	LMGR_Admin::boot();
	LMGR_Notes::boot();
}

register_activation_hook( __FILE__, function () {
	LMGR_Deals::register();
	flush_rewrite_rules();
	if ( ! wp_next_scheduled( 'lmgr_daily' ) ) wp_schedule_event( strtotime( 'tomorrow 00:15' ) - (int) ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ), 'daily', 'lmgr_daily' );
} );

register_deactivation_hook( __FILE__, function () {
	wp_clear_scheduled_hook( 'lmgr_daily' );
	flush_rewrite_rules();
} );
