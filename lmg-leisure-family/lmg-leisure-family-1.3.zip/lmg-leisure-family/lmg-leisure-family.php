<?php
/**
 * Plugin Name: LMG Leisure Family
 * Description: "The Leisure Family" — the Lucky 8 portfolio sign-off block, auto-appended to every post. Optional video push on travel sites. Shortcode [leisure_family]. Options: lmg_family_sub, lmg_video_push_url, lmg_video_push_label, lmg_video_push_cta.
 * Version: 1.3
 */
if ( ! defined('ABSPATH') ) exit;

function lmg_family_render(){
    $members = [
        ['Traveltalk.dk',     'Rejser med dybde — for den nysgerrige rejsende.', 'https://www.traveltalk.dk',  'Rejser · DK'],
        ['Traveltalk.travel', 'Travel with depth, the world over.',              'https://traveltalk.travel',  'Travel · Intl'],
        ['Vacation-Talk',     'Travel inspiration, destinations & ideas.',        'https://vacation-talk.com',  'Inspiration'],
        ['Winetalk.dk',       'Vin som hverdagens luksus.',                       'https://winetalk.dk',        'Vin'],
        ['WorldSportTalk',    'Global sport, up close.',                          'https://worldsporttalk.com', 'Sport'],
        ['Think Smarter',     'Clearer thinking — and AI in particular.',         'https://think-smarter.net',  'Ideas · AI'],
        ['Leisuretalk',       'The whole family, in one place.',                  'https://leisuretalk.net',    'The Group'],
        ['Gadvisory',         'Is your business AI-ready? Take the test.',        'https://gadvisory.net',      'For business'],
    ];
    $sub = get_option('lmg_family_sub', 'Eight sites, one family — travel, wine, sport and sharper thinking. Explore the rest of the universe.');
    ob_start(); ?>
<div class="lmg-fam">
  <div class="lmg-fam-head">
    <span class="lmg-fam-eyebrow">The Leisure Family</span>
    <p class="lmg-fam-sub"><?php echo esc_html($sub); ?></p>
  </div>
  <div class="lmg-fam-grid">
<?php foreach ($members as $m): ?>
    <a class="lmg-fam-box" href="<?php echo esc_url($m[2]); ?>" target="_blank" rel="noopener">
      <span class="lmg-fam-tag"><?php echo esc_html($m[3]); ?></span>
      <span class="lmg-fam-name"><?php echo esc_html($m[0]); ?></span>
      <span class="lmg-fam-line"><?php echo esc_html($m[1]); ?></span>
    </a>
<?php endforeach; ?>
  </div>
</div>
<style id="lmg-fam-css" data-no-optimize="1" data-no-defer="1" data-no-minify="1">
.lmg-vpush{max-width:1100px;margin:2.4rem auto 0;padding:16px;text-align:center;border-top:1px solid #ece9e2;border-bottom:1px solid #ece9e2}
.lmg-vpush p{margin:0;font-family:'EB Garamond',Georgia,serif;font-size:1.05rem;color:#3a382f}
.lmg-vpush a{color:#C4704A;font-weight:600;text-decoration:none}
.lmg-vpush a:hover{text-decoration:underline}
.lmg-vpush img.emoji,.lmg-vpush img.wp-smiley,.lmg-fam img.emoji{height:1em!important;width:1em!important;max-width:1em!important;display:inline-block!important;margin:0 .18em!important;vertical-align:-.12em!important;padding:0!important;border:0!important;box-shadow:none!important;border-radius:0!important}
.entry-content .lmg-vpush p::first-letter,.wp-block-post-content .lmg-vpush p::first-letter,.lmg-vpush p::first-letter{font-size:inherit!important;color:inherit!important;float:none!important;line-height:inherit!important;margin:0!important}
.lmg-fam{max-width:1100px;margin:2.6rem auto 1rem;padding:0 16px}
.lmg-fam-head{text-align:center;margin-bottom:1.4rem}
.lmg-fam-eyebrow{display:block;font-family:'Inter',sans-serif;font-size:12px;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:#C4704A}
.lmg-fam-sub{margin:.5rem auto 0;max-width:600px;font-family:'EB Garamond',Georgia,serif;font-size:1.02rem;color:#5a574f}
.lmg-fam-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem}
.lmg-fam-box{display:flex;flex-direction:column;gap:.25rem;padding:1rem 1.05rem;border:1px solid #ece9e2;border-radius:10px;background:#fff;text-decoration:none;transition:transform .16s ease,box-shadow .16s ease,border-color .16s ease}
.lmg-fam-box:hover{transform:translateY(-3px);box-shadow:0 10px 24px rgba(0,0,0,.10);border-color:#C4704A}
.lmg-fam-tag{font-family:'Inter',sans-serif;font-size:10px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:#C4704A}
.lmg-fam-name{font-family:'Playfair Display',Georgia,serif;font-size:1.12rem;font-weight:700;color:#1a1a1a;line-height:1.15}
.lmg-fam-line{font-family:'EB Garamond',Georgia,serif;font-size:.92rem;color:#5a574f;line-height:1.35}
.lmg-fam .lmg-fam-box .lmg-fam-name::first-letter{font-size:inherit!important;color:inherit!important;float:none!important;line-height:inherit!important;margin:0!important}
@media(max-width:900px){.lmg-fam-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:480px){.lmg-fam-grid{grid-template-columns:1fr}}
</style>
<?php
    return ob_get_clean();
}
add_shortcode('leisure_family', 'lmg_family_render');

function lmg_video_push_render(){
    $url = get_option('lmg_video_push_url','');
    if(!$url) return '';
    $label = get_option('lmg_video_push_label','Watch the films — 365 ways to travel the world');
    $cta   = get_option('lmg_video_push_cta','Watch');
    return '<div class="lmg-vpush"><p>🎬 <strong>'.esc_html($label).'</strong> <a href="'.esc_url($url).'">'.esc_html($cta).' →</a></p></div>';
}

// Auto-append to the end of every single post
add_filter('the_content', function($c){
    if( is_singular('post') && is_main_query() && in_the_loop() ){
        $c .= lmg_video_push_render() . lmg_family_render();
    }
    return $c;
// 1.3 (G, 13 Nov): the family goes lowest – after the inline newsletter box (priority 99) and every other block.
}, 1000);
