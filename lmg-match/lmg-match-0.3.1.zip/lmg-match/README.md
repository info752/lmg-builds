# LMG Match

An interactive question-and-recommendation layer inside WordPress. It asks a visitor a
short question set and answers with the site's own published articles, scored by a
transparent deterministic engine — and records, in aggregate, what people actually wanted.

First instance: **"Hvilket Italien vil du gerne opleve?" → "Se dit Italien"** on traveltalk.dk.

Built generic first. Nothing in the engine knows about Italy, TravelTalk, or a widget.

Status: **prototype, not installed anywhere.** The front end is verified in a browser
against the live TravelTalk corpus. The PHP has not run inside WordPress yet — see §10.

---

## 1. What was found in the existing TravelTalk environment

Measured read-only against `https://www.traveltalk.dk/wp-json/wp/v2` on 2026-09-05.

| Finding | Detail |
| --- | --- |
| **Italy corpus** | Category `italien` (id 55, parent `europa`). **96 published posts.** |
| **Term count disagrees with REST** | The term reports `count: 109`, REST `X-WP-Total` reports 96. 13 unaccounted. *Inferred*, not verified: the term count includes non-published or non-post objects. Worth a look, not a blocker. |
| **No region sub-categories** | Category 55 has **zero children**. Puglia, Toscana, Sicilien etc. are not terms. |
| **Effectively no tags** | Across all 96 posts: **0 usable tags.** The only tags on the site that surfaced are internal (`forsiden`, `ga-report`, `leisureintel-audit`, `trafik-analyse`). **A tag-driven recommender had nothing to stand on.** |
| **Categories are the real vocabulary** | 31 distinct categories in use on the Italy posts, and they map cleanly onto the brief's own question options: `mad-og-vin`, `kunst-og-kultur`, `sol-og-strand`, `storbyferie`, `naturrejser`, `vandreferie`, `togrejser`, `familieferie`, `luksusrejser`, `weekend-rejser`. |
| **Coverage is uneven, and it matters** | 61 of 96 posts carry an interest facet. 17 carry a value facet. **5** carry a party facet, **1** a duration facet, **1** a season facet. **35 posts carry no facet at all.** |
| **Exclusions have something to bite on** | 1 published Italy post is in `charterferie`; 13 are from the 2020–22 Covid vintage. 14 posts excluded in every run. |

**The consequence, and it drove the whole design:** the corpus can answer question 1 well,
question 5 weakly, and questions 2–4 barely at all. So questions 2–4 are collected as
learning signal and weighted **0** for ranking. A weight the content cannot support would
not improve results; it would invent them.

## 2. Implementation approach, and why

- **A WordPress plugin with a shortcode**, matching the `lmg-*` convention already in the repo.
- **A headless engine** (`assets/lmg-match-engine.js`) with no DOM and no dependencies. The
  widget is one front door; a concierge asking the same questions in prose is another.
  `LMGMatch.describe(config)` hands an agent the question set, and `recommend()` ranks
  identically whoever called it. That is the Aianna fusion point, built in now rather than retrofitted.
- **Deterministic rules, not a model.** Same answers, same results, always. Every result
  carries the reason it matched. The brief asked not to build an AI recommendation engine for V1, and there is no reason to: the logic is inspectable, free, and instant.
- **Questions, copy, weights and exclusions are JSON.** A new destination is a config file.
  Proof: `config/traveltalk-spanien.json` differs from the Italy config in three fields —
  id, subject, content — and runs against 67 Spanish posts with no code change.
- **Real files, not live queries.** The content map is generated and committed, so the widget
  cannot be slowed or broken by a REST call at request time.
- **A page view that ignores the widget pays almost nothing.** Assets total 34 KB uncompressed
  and load only where the shortcode renders. The content map — 60 KB on the Italy set, the
  heavy part — is fetched on first interaction, and prefetched on hover/focus so the click
  still feels instant. Verified: **0 requests for the map on page load, 1 after Start.**
  LiteSpeed is told to leave these files alone (`data-no-optimize`), because on this stack
  combined and UCSS-stripped copies go stale and fail silently.

## 3. What was built

```
lmg-match/
  lmg-match.php                       plugin: shortcode, assets, event API, admin readout
  assets/lmg-match-engine.js          headless scoring — no DOM, no deps
  assets/lmg-match-ui.js              the on-site widget
  assets/lmg-match.css                design-manual tokens (§10.1), mobile-first
  config/traveltalk-italien.json      V1 question set, Danish copy, weights, exclusions
  config/traveltalk-spanien.json      the same set, different subject — genericity proof
  content/traveltalk-italien.items.json    96 items, generated
  content/traveltalk-spanien.items.json    67 items, generated
  tools/build-content-map.py          regenerates a map from any site's REST API
  demo/index.html                     standalone harness, no WordPress needed
```

Usage on a page:

```
[lmg_match config="traveltalk-italien"]
[lmg_match config="traveltalk-italien" subject="Spanien" content="traveltalk-spanien.items.json"]
```

## 4. Where it is

`/Users/Bruger/code/leisuretalk/lmg-match/` — in the repo, installed on no site.

Local preview: `demo/index.html` (served on :8766 during the build session).
Add `?config=traveltalk-spanien` to check the second instance.

## 5. How the recommendation logic works

For each item, for each answered facet the item actually has:

```
share  = (chosen values this item covers) / (values the visitor chose)
total += weight(facet) × share
```

Then `score = total / max(weight seen, scoreFloor)`, giving 0…1.

Four decisions carry the quality:

1. **Score on positive evidence only.** A missing facet is never a penalty. With 35 of 96
   posts carrying no facets, penalising absence would hand every result to the handful of
   richly-categorised posts and bury the rest.
2. **A score floor.** Without it, a post whose only facet is a low-weight one normalises to a
   perfect 1.00 — a single `familieferie` tag outranking a post matching two of three chosen
   interests. Verified: "Slotte i Italien", matching only *komfort*, scores **0.30**, not 1.00.
3. **Deterministic ordering** — score, then breadth of evidence, then recency, then id. No
   randomness, so the logic can be audited and a result reproduced.
4. **Diversity cap** — at most 2 results per region, so five answers about food don't return
   five posts about Rome. Items with no detected region are never capped.

**When there is nothing, it says so.** An uncovered combination returns zero results and the
honest line, not padded weak matches. Verified: `interest: ["smaa_byer"]` → 0 results →
*"Vi har ikke dækket den kombination endnu."*

## 6. What data is captured

Five events: `start`, `answer`, `result`, `click`, `signup`.

Recorded: which config, a random session id, the facet and values chosen, how many results
came back, how many were confident, whether the result was thin, which post ids were shown,
which was clicked and at what position, and elapsed seconds.

**Not recorded:** no IP, no user agent, no user id, no free text, no cross-session identifier,
no referrer. There is deliberately no column that could re-identify a visitor. The session id
is random, lives in memory for one visit, and is never matched to anything else.

Nothing is sent before consent (`analytics.requireConsent`, on by default). The e-mail address
from the newsletter form goes to the ESP through the site's own endpoint and is **never**
attached to an analytics event — the funnel data stays aggregate, and the list stays separate.

The most valuable output is the **thin** flag: every time a reader asked for a combination we
have not covered. That is the commissioning list.

## 7. Where the data is stored

`{prefix}lmg_match_events`, created on activation. Raw rows are deleted after **90 days** by a
daily cron (`lmg_match_prune`) — enforced, not promised.

Readout: **Tools → LMG Match**. Event totals, most-chosen options, most-common *combinations*,
and the count of thin results.

## 8. How to edit it

| To change | Edit |
| --- | --- |
| Questions, options, order, Danish copy | `config/<id>.json` |
| How much a facet counts | `facetWeights` |
| Number of results, diversity, thresholds | `results` |
| Charter / Rusland / Covid-era exclusions | `exclusions` |
| Newsletter copy, whether it gates | `activation.newsletter` |
| Partner slots | `activation.partners` — empty at launch, generic by design |
| The content map | `content/<id>.items.json`, or re-run the generator |

Regenerate a map:

```bash
python3 tools/build-content-map.py --site https://www.traveltalk.dk --category 55 --out content/traveltalk-italien.items.json
```

The generator **preserves every item marked `"source": "curated"`** and regenerates the rest,
so hand-mapping survives a refresh. It aborts rather than writing a partial map if the fetched
count disagrees with `X-WP-Total` — a truncated REST response parses cleanly and silently
undercounts. That guard already caught one real bug during the build.

Provenance is recorded per item: `measured` (from real WP terms), `auto` (inferred from
title/slug keywords — a guess, used only for `region`, which affects diversity and can never
change whether something matches), `curated` (a human edited it).

## 9. Privacy considerations

- Aggregate by construction, not by policy — the table has no column to identify anyone.
- Consent-gated; no consent, no transmission.
- Retention enforced in code at 90 days.
- The endpoint is public (pages are cached, so a nonce would be stale). It is write-only,
  accepts a strict whitelist, drops everything else, and is rate-limited via a salted,
  one-minute transient that is never written to the events table.
- **The newsletter is not gated on the answer.** `activation.newsletter.gate` is `false` and
  must stay false until the legal read on GDPR Art. 7(4) comes back. Tightening later is a
  config change; loosening later means a contaminated list.

## 10. Known limitations

1. **The PHP has never run inside WordPress.** No local WP on this machine. The engine, UI,
   CSS, configs and content maps are verified in a real browser against the real corpus; the
   plugin file is reviewed but unexecuted. It is not "working" until it renders on a page.
2. **Questions 2–4 cannot rank anything.** Weighted 0 on purpose. They collect signal only.
3. **Two of the eight interest options have no content at all** — *Små byer & landsbyer* and
   *Det ukendte Italien*. Both currently return the honest empty state. They need curation.
4. **`region` is inferred from keywords**, and 51 of 96 items have none detected. It only
   affects diversity.
5. **The 109-vs-96 discrepancy is unexplained.** Inferred, not verified.
6. **No admin UI for editing configs** — they are files. Deliberate for a prototype.
7. **Reasons can be monotonous.** When every result matched for the same single reason the
   per-card line is suppressed, because repeating it four times tells the reader nothing.
8. **Not tested on a real mobile device** — only at a mobile viewport.

## 11. Recommended for V2

1. **Curate the gaps first.** `smaa_byer` and `det_ukendte` are two of eight options and
   return nothing. Roughly 20 curated items would fix the worst of it — and the map file is
   built for exactly this, with `"source": "curated"` protecting the work.
2. **Let the thin log commission the content.** After a few hundred sessions the uncovered
   combinations are a ranked, evidence-based list of what to write. That is the whole point.
3. **Then raise the weights on party/duration/season** once the content can answer them.
4. **Fuse with Aianna.** The engine is already headless and self-describing; the concierge
   asks the five questions in prose and calls `recommend()`. No second ranking system.
5. **Consider real taxonomy.** If the facets prove useful, they belong as WP terms rather than
   a JSON map — but only after the mapping has been proven by use, not before.
6. **Partner slots** stay empty until there is traffic worth showing anyone.

---

## Data scope

Access granted to any account is granted for the Leisure Media Group collaboration only. This
work touches **traveltalk.dk's published content and nothing else** — no Drive, no mailbox, no
calendar, no other site, no other business. Approving access somewhere is a technical step,
not consent to look around. If a task appears to need something outside that, stop and ask;
do not reach for it and explain afterwards. Report honestly what was actually opened,
including anything opened by mistake.

**Nothing is deleted.** Removed things go to draft for a second look.

---

## 12. 2026-09-06 — 13 sets live: 5 countries + 8 clusters

Supersedes §10's "installed on no site" and the Italy-only framing above.

> **Current as of 2026-09-11: 17 sets — 9 countries + 8 clusters.** The counts in this
> entry are what was live on 2026-09-06 and are left as written. Østrig, USA, Danmark and
> Tyskland have been added since; the eight clusters are unchanged.

### Two shapes now

| | Q1 | why |
| --- | --- | --- |
| **country** | `interest`, multi-select ≤3 | inside Italy, what separates posts is what the trip is *about* |
| **cluster** | `destination`, **single-select** | inside Mad og vin every post is about food; what separates them is *where* |

The cluster shape needed **no engine change**. `diversify.by` already read
`item.facets[rule.by]`, so it only needed a `destination` facet — now generated from
the real term tree (`italien > europa > rejsemal`) and stored at **both levels**, so a
config asks at whichever altitude its corpus supports: Mad og vin names countries (25
Italian posts), Eventyrrejser names continents (156 posts over 78 destinations, none
above 8).

**Destination is single-select, and that is a correctness fix, not a preference.**
The engine scores `share = hits / values-chosen`. Right for interests (food AND art);
wrong for destinations, where three picks mean *any of them*. Measured before the fix:
choosing Italien in Mad og vin returned Split, Madrid and the Whitsunday Islands at
0.33. Clusters now use one destination plus `minScore: 0.5`, which sits cleanly between
a right-country result (≥0.67) and a wrong-country one (≤0.33).

### Two defects found in what was already here

1. **`CATEGORY_FACETS` never read eight real category slugs** — `skiferie`,
   `eventyrrejser`, `golfrejser`, `cykelferie`, `dykkerferie`, `sejlerferie`,
   `krydstogt`, `safari`. Every map undercounted its own coverage. **Østrig measured
   44% and is really 90%**; Italien 49% → 62%; Frankrig 49% → 71%. Confirmed two
   independent ways — SQL on the server and REST through the generator — which returned
   identical distributions.

2. **The five configs were byte-identical copies.** Greece offered "Kunst & historie",
   "Togrejser", "Små byer" and "Det ukendte Grækenland" against a corpus holding zero of
   each: four of eight buttons led to the empty state. §10.3 recorded this as a known
   limitation for Italy; it was in fact worse elsewhere and got copied forward.

`tools/build-configs.py` now scaffolds a set and **refuses to write an option the corpus
cannot answer** (≥`MIN_ITEMS` posts surviving the exclusions). It is a one-shot scaffold:
after it writes a config, the JSON is the source of truth and is edited by hand.

### Not deployed, deliberately

`danmark` (18 scoreable), `graekenland` (7), `tyskland` (7), `portugal` (6). A bracket
cannot be placed on a set the server does not have, and that is the point.

**Their blocker is mostly one config field.** `exclusions.dateRange {2020, 2022}` was
written as "the Covid vintage". Measured: of 349 published posts from 2020–22, **22
mention Covid at all**. 94% of what the rule removes is not Covid content. Replacing the
date range with an `ids` list of those 22 would make three of the four viable at once.
Left alone — it is an editorial ruling, not a bug.

### Known, unchanged

- Region keyword detection is weak on some sets (Danmark 9/38; Wien 1/124 on Østrig).
  Region only affects result diversity, never whether something matches.
- Questions 3–5 still rank nothing (weight 0) and are collected as demand signal.
- **Config and content JSON are not CDN-cached** (unlike the versioned assets): CDN,
  origin and local file all returned identical bytes immediately after deploy. A config
  fix lands at once; no version bump needed.
