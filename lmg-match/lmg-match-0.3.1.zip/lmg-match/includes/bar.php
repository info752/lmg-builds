<?php
/**
 * Pop-up after a delay offers the question set; a small tab stays on the page so the questions can be
 * found again; any link to #find-din-rejse opens them. Settings → LMG Match pop-up.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

function lmg_match_bar_opt( $key ) {
	$defaults = array(
		'enabled'  => 1,
		'delay'    => 10,
		'cooldown' => 14,
		'where'    => 'articles_front',
		'config'   => 'traveltalk-eventyrrejser',
		'text'     => 'Svar på {n} spørgsmål på 10 sek. og du er klar til afgang.',
		'tab'      => 'Find din rejse',
		'button'   => 'Find din rejse',
	);
	$o = get_option( 'lmg_match_bar', array() );
	return isset( $o[ $key ] ) && $o[ $key ] !== '' ? $o[ $key ] : $defaults[ $key ];
}

/** The question set that fits the page: the article's own country or interest if a set exists, else the default. */
function lmg_match_bar_config() {
	$default = sanitize_file_name( lmg_match_bar_opt( 'config' ) );
	if ( is_singular( 'post' ) ) {
		foreach ( (array) get_the_category( get_queried_object_id() ) as $cat ) {
			$ids = array_merge( array( $cat->term_id ), get_ancestors( $cat->term_id, 'category' ) );
			foreach ( $ids as $id ) {
				$t = get_term( $id, 'category' );
				if ( $t && ! is_wp_error( $t ) && file_exists( LMG_MATCH_DIR . 'config/traveltalk-' . $t->slug . '.json' ) ) {
					return 'traveltalk-' . $t->slug;
				}
			}
		}
	}
	return file_exists( LMG_MATCH_DIR . 'config/' . $default . '.json' ) ? $default : '';
}

function lmg_match_bar_applies() {
	if ( is_admin() || is_feed() || is_404() || is_search() ) return false;
	if ( ! lmg_match_bar_opt( 'enabled' ) ) return false;
	$where = lmg_match_bar_opt( 'where' );
	$ok = $where === 'all'
		|| is_singular( 'post' )
		|| ( $where === 'articles_front' && is_front_page() );
	if ( ! $ok ) return false;
	$post = is_singular() ? get_post() : null;
	if ( $post && has_shortcode( $post->post_content, 'lmg_match' ) ) return false; // the page already has the widget
	return true;
}

add_action( 'wp_enqueue_scripts', function () {
	if ( is_admin() || is_feed() ) return;
	$config = lmg_match_bar_config();
	if ( ! $config ) return;
	$v = LMG_MATCH_VERSION;

	wp_enqueue_style( 'lmg-match-bar', LMG_MATCH_URL . "assets/lmg-match-bar-{$v}.css", array(), null );
	wp_enqueue_script( 'lmg-match-bar', LMG_MATCH_URL . "assets/lmg-match-bar-{$v}.js", array(), null, true );

	$decoded = json_decode( file_get_contents( LMG_MATCH_DIR . 'config/' . $config . '.json' ), true );
	$n       = is_array( $decoded ) && ! empty( $decoded['questions'] ) ? count( $decoded['questions'] ) : 5;
	$content = ! empty( $decoded['content'] ) ? LMG_MATCH_URL . 'content/' . lmg_match_safe_file( $decoded['content'] ) : '';

	wp_add_inline_script( 'lmg-match-bar', 'window.LMG_MATCH_BAR=' . wp_json_encode( array(
		'delay'        => max( 3, (int) lmg_match_bar_opt( 'delay' ) ),
		'cooldownDays' => max( 0, (int) lmg_match_bar_opt( 'cooldown' ) ),
		'show'         => lmg_match_bar_applies(),
		'text'         => str_replace( '{n}', (string) $n, lmg_match_bar_opt( 'text' ) ),
		'tab'          => lmg_match_bar_opt( 'tab' ),
		'button'       => lmg_match_bar_opt( 'button' ),
		'config'       => LMG_MATCH_URL . 'config/' . $config . '.json',
		'content'      => $content,
		'placement'    => $config,
		'css'          => LMG_MATCH_URL . "assets/lmg-match-{$v}.css",
		'engine'       => LMG_MATCH_URL . "assets/lmg-match-engine-{$v}.js",
		'ui'           => LMG_MATCH_URL . "assets/lmg-match-ui-{$v}.js",
	) ) . ';', 'before' );
}, 30 );

// Keep the optimiser off the bar files, as with the rest of the plugin.
add_filter( 'script_loader_tag', function ( $tag, $handle ) {
	return $handle === 'lmg-match-bar' ? str_replace( '<script ', '<script data-no-optimize="1" ', $tag ) : $tag;
}, 10, 2 );
add_filter( 'style_loader_tag', function ( $tag, $handle ) {
	return $handle === 'lmg-match-bar' ? str_replace( '<link ', '<link data-no-optimize="1" ', $tag ) : $tag;
}, 10, 2 );

// --- Settings page -----------------------------------------------------------

add_action( 'admin_menu', function () {
	add_options_page( 'LMG Match pop-up', 'LMG Match pop-up', 'manage_options', 'lmg-match-bar', 'lmg_match_bar_page' );
} );

add_action( 'admin_init', function () {
	register_setting( 'lmg_match_bar', 'lmg_match_bar', array( 'sanitize_callback' => function ( $in ) {
		$in = (array) $in;
		return array(
			'enabled'  => empty( $in['enabled'] ) ? 0 : 1,
			'delay'    => max( 3, (int) ( $in['delay'] ?? 25 ) ),
			'cooldown' => max( 0, (int) ( $in['cooldown'] ?? 14 ) ),
			'where'    => in_array( $in['where'] ?? '', array( 'articles', 'articles_front', 'all' ), true ) ? $in['where'] : 'articles_front',
			'config'   => sanitize_file_name( $in['config'] ?? '' ),
			'text'     => sanitize_text_field( $in['text'] ?? '' ),
			'tab'      => sanitize_text_field( $in['tab'] ?? '' ),
			'button'   => sanitize_text_field( $in['button'] ?? '' ),
		);
	} ) );
} );

function lmg_match_bar_page() {
	if ( ! current_user_can( 'manage_options' ) ) return;
	$sets = array();
	foreach ( glob( LMG_MATCH_DIR . 'config/traveltalk-*.json' ) as $f ) { $sets[] = basename( $f, '.json' ); }
	$where = lmg_match_bar_opt( 'where' );
	?>
	<div class="wrap">
		<h1>LMG Match pop-up</h1>
		<form method="post" action="options.php">
			<?php settings_fields( 'lmg_match_bar' ); ?>
			<table class="form-table" role="presentation">
				<tr><th>Show the pop-up</th><td><label><input type="checkbox" name="lmg_match_bar[enabled]" value="1" <?php checked( lmg_match_bar_opt( 'enabled' ) ); ?>> On</label></td></tr>
				<tr><th>Seconds before the pop-up appears</th><td><input type="number" min="3" name="lmg_match_bar[delay]" value="<?php echo esc_attr( lmg_match_bar_opt( 'delay' ) ); ?>"></td></tr>
				<tr><th>Days before the same visitor sees it again</th><td><input type="number" min="0" name="lmg_match_bar[cooldown]" value="<?php echo esc_attr( lmg_match_bar_opt( 'cooldown' ) ); ?>"> <span class="description">after they close it or open it</span></td></tr>
				<tr><th>Where</th><td><select name="lmg_match_bar[where]">
					<option value="articles_front" <?php selected( $where, 'articles_front' ); ?>>Articles and the front page</option>
					<option value="articles" <?php selected( $where, 'articles' ); ?>>Articles only</option>
					<option value="all" <?php selected( $where, 'all' ); ?>>Every page</option>
				</select></td></tr>
				<tr><th>Question set for the front page and other pages</th><td><select name="lmg_match_bar[config]">
					<?php foreach ( $sets as $s ) : ?><option value="<?php echo esc_attr( $s ); ?>" <?php selected( lmg_match_bar_opt( 'config' ), $s ); ?>><?php echo esc_html( $s ); ?></option><?php endforeach; ?>
				</select> <span class="description">An article uses the set for its own country or interest when there is one.</span></td></tr>
				<tr><th>Text in the pop-up <span class="description">({n} = number of questions)</span></th><td><input type="text" class="large-text" name="lmg_match_bar[text]" value="<?php echo esc_attr( lmg_match_bar_opt( 'text' ) ); ?>"></td></tr>
				<tr><th>Small tab that stays on the page</th><td><input type="text" name="lmg_match_bar[tab]" value="<?php echo esc_attr( lmg_match_bar_opt( 'tab' ) ); ?>"></td></tr>
				<tr><th>Button</th><td><input type="text" name="lmg_match_bar[button]" value="<?php echo esc_attr( lmg_match_bar_opt( 'button' ) ); ?>"></td></tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<p>To see the pop-up at once on any page, add <code>?lmgbar=1</code> to its address. To open the questions from a menu item or a button, make a link to <code>#find-din-rejse</code>.</p>
		<h2>Release notes</h2>
		<pre style="white-space:pre-wrap;background:#fff;padding:1rem;max-width:900px"><?php echo esc_html( file_get_contents( LMG_MATCH_DIR . 'RELEASE-NOTES.md' ) ); ?></pre>
	</div>
	<?php
}
