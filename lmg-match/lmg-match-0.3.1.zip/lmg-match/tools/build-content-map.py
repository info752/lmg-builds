#!/usr/bin/env python3
"""
Build a draft content map for lmg-match from a site's WordPress REST API.

The map is what the recommender scores against. It is deliberately a FILE, not a
live query: it is inspectable, diffable, hand-editable, and it cannot make the
widget slow or fragile at request time.

Provenance is recorded per item and per facet:

    "source": "measured"   facets read from real WP terms on the post
    "source": "auto"       facets inferred from title/slug keywords — a GUESS
    "source": "curated"    a human edited this entry; the generator will not touch it

Re-running preserves every item marked "curated" and regenerates the rest.

Usage:
    python3 tools/build-content-map.py \
        --site https://www.traveltalk.dk \
        --category 55 \
        --out content/traveltalk-italien.items.json
"""

import argparse
import json
import os
import re
import sys
import urllib.request
from html import unescape

# --- Category → facet mapping -------------------------------------------------
# Measured: these are real category slugs in use on the site. Read as
# "a post in this category genuinely carries this facet value".

CATEGORY_FACETS = {
    "kunst-og-kultur": ("interest", "kunst_historie"),
    "mad-og-vin":      ("interest", "mad_vin"),
    "sol-og-strand":   ("interest", "strand_kyst"),
    "naturrejser":     ("interest", "natur_bjerge"),
    "aktiv-ferie":     ("interest", "natur_bjerge"),
    "vandreferie":     ("interest", "natur_bjerge"),
    "storbyferie":     ("interest", "storby"),
    "togrejser":       ("interest", "tog"),
    # Added 2026-09-06. Every one of these is a real, long-standing category slug
    # that this mapping simply never read, so every set has been undercounting its
    # own coverage: Oestrig measured 44% and is really 90%, Italien 49% / 62%,
    # Frankrig 49% / 71%. A value only ever reaches a reader if a config also
    # OFFERS it as an option, so adding them here cannot change an existing set.
    "skiferie":        ("interest", "ski"),
    "eventyrrejser":   ("interest", "eventyr"),
    "golfrejser":      ("interest", "golf"),
    "cykelferie":      ("interest", "cykel"),
    "dykkerferie":     ("interest", "dyk"),
    "sejlerferie":     ("interest", "sejl"),
    "krydstogt":       ("interest", "krydstogt"),
    "safari":          ("interest", "safari"),
    "familieferie":    ("party", "familie"),
    "bryllupsrejser":  ("party", "par"),
    "weekend-rejser":  ("duration", "weekend"),
    "jul-og-nytaar":   ("season", "vinter"),
    "luksusrejser":    ("value", "komfort"),
    "ferieboliger":    ("value", "fleksibilitet"),
    "camping":         ("value", "pris"),
    "glamping":        ("value", "oplevelse"),
    "slotsferie":      ("value", "komfort"),
}

# Facets the site's taxonomy cannot express. Listed so the gap is visible in the
# output rather than silently absent. These need human curation.
UNSUPPORTED_FACETS = {
    "interest": ["smaa_byer", "det_ukendte"],
}

# --- Destination facet -------------------------------------------------------
# A place is anything descended from the Rejsemål root. Membership is decided by
# the real term tree, not by a keyword list, so a destination added to the site
# next year is picked up without touching this file.
GEO_ROOT = "rejsemal"

# Editorial and housekeeping categories that sit outside the destination tree.
# Listed only to skip work; anything not under GEO_ROOT is dropped anyway.
NON_GEO = {
    "rejsebureauer", "uncategorized-da", "rejsetrends-og-indsigt", "video",
    "om-traveltalk", "flyselskaber", "lufthavne", "rejseforsikring",
    "rejseoekonomi", "forsiden", "nyheder",
}

# --- Keyword inference -------------------------------------------------------
# Only ever used for `region`, which drives result DIVERSITY, not matching.
# A wrong region spreads results a little oddly; it cannot produce a wrong
# recommendation. Anything that could change a match stays measured-only.

REGION_SETS = {}

REGION_SETS["italien"] = [
    ("puglia",        r"\bpuglia|lecce|alberobello|salento\b"),
    ("toscana",       r"\btoscana|firenze|siena|chianti|lucca\b"),
    ("liguria",       r"\bliguri|cinque terre|corniglia|portofino|genova\b"),
    ("campania",      r"\bamalfi|positano|napoli|capri|sorrent|pompeji\b"),
    ("lazio",         r"\brom\b|\broma\b|\blazio\b"),
    ("veneto",        r"\bvenedig|venezia|verona|veneto|dolomit\b"),
    ("lombardiet",    r"\bmilano|comosø|como|lombardi|garda\b"),
    ("piemonte",      r"\bpiemonte|torino|barolo|langhe\b"),
    ("sicilien",      r"\bsicili|palermo|taormina|etna\b"),
    ("sardinien",     r"\bsardini|cagliari|costa smeralda\b"),
    ("umbrien",       r"\bumbri|perugia|assisi\b"),
    ("emilia-romagna", r"\bbologna|emilia|romagna|rimini|modena|parma\b"),
    ("le-marche",     r"\ble marche|marche\b"),
    ("trentino",      r"\btrentino|s(ü|y)dtirol|bolzano|alto adige\b"),
    ("calabrien",     r"\bcalabri\b"),
]

REGION_SETS["frankrig"] = [
    ("paris",         r"\bparis|versailles|ile-de-france|île-de-france\b"),
    ("provence",      r"\bprovence|marseille|avignon|arles|luberon|camargue|aix-en-provence\b"),
    ("cote-dazur",    r"\bcôte d.azur|cote d.azur|riviera|nice|cannes|antibes|saint-tropez|menton\b"),
    ("bourgogne",     r"\bbourgogne|burgund|beaune|dijon|chablis\b"),
    ("bordeaux",      r"\bbordeaux|m(é|e)doc|saint-(é|e)milion|aquitaine|arcachon\b"),
    ("bretagne",      r"\bbretagne|saint-malo|quimper|carnac|bretonsk\b"),
    ("normandiet",    r"\bnormandi|rouen|honfleur|mont saint-michel|bayeux|(é|e)tretat\b"),
    ("loire",         r"\bloire|amboise|chenonceau|chambord|saumur\b"),
    ("alsace",        r"\balsace|strasbourg|colmar|riquewihr|mulhouse\b"),
    ("champagne",     r"\bchampagne|reims|(é|e)pernay\b"),
    ("korsika",       r"\bkorsika|corse|ajaccio|bastia|bonifacio\b"),
    ("alperne",       r"\bchamonix|savoie|annecy|mont blanc|megève|megeve|courchevel|tignes\b"),
    ("occitanie",     r"\btoulouse|carcassonne|languedoc|montpellier|n(î|i)mes|roussillon\b"),
    ("dordogne",      r"\bdordogne|p(é|e)rigord|sarlat|lascaux\b"),
    ("baskerlandet",  r"\bbiarritz|bayonne|baskerland|saint-jean-de-luz\b"),
    ("rhone",         r"\brh(ô|o)ne|lyon|beaujolais|grenoble\b"),
    ("auvergne",      r"\bauvergne|clermont-ferrand\b"),
]

REGION_SETS["graekenland"] = [
    ("kreta",         r"\bkreta|chania|heraklion|rethymno|knossos\b"),
    ("santorini",     r"\bsantorini|thira\b"),
    ("mykonos",       r"\bmykonos|delos\b"),
    ("rhodos",        r"\brhodos|lindos\b"),
    ("korfu",         r"\bkorfu|corfu|kerkyra\b"),
    ("athen",         r"\bathen|akropolis|attika|pir(æ|a)eus\b"),
    ("peloponnes",    r"\bpeloponnes|nafplio|mykene|olympia|monemvasia\b"),
    ("kykladerne",    r"\bkyklader|cyclades|naxos|paros|milos|folegandros|amorgos\b"),
    ("ioniske-oer",   r"\bzakynthos|kefalonia|lefkada|ithaka|paxos\b"),
    ("dodekaneserne", r"\bdodekanes|patmos|karpathos|symi\b"),
    ("nordgraekenland", r"\bthessaloniki|halkidiki|chalkidiki|meteora|pelion|epirus|zagori\b"),
    ("nordoehavet",   r"\blesbos|samos|chios|ikaria|skiathos|skopelos|thassos\b"),
]

REGION_SETS["portugal"] = [
    ("lissabon",      r"\blissabon|lisboa|sintra|cascais|bel(é|e)m|estoril\b"),
    ("porto",         r"\bporto|douro|oporto\b"),
    ("algarve",       r"\balgarve|faro|albufeira|sagres|tavira\b"),
    ("madeira",       r"\bmadeira|funchal\b"),
    ("azorerne",      r"\bazorer|a(ç|c)ores|azores|s(ã|a)o miguel\b"),
    ("alentejo",      r"\balentejo|(é|e)vora|comporta|monsaraz\b"),
    ("centro",        r"\bcoimbra|aveiro|nazar(é|e)|(ó|o)bidos|f(á|a)tima|serra da estrela\b"),
    ("minho",         r"\bminho|braga|guimar(ã|a)es|viana do castelo|ger(ê|e)s\b"),
]

REGION_SETS["spanien"] = [
    ("andalusien",    r"\bandalusien|sevilla|granada|malaga|m(á|a)laga|c(ó|o)rdoba|ronda|cadiz|c(á|a)diz|marbella\b"),
    ("catalonien",    r"\bcatalonien|barcelona|costa brava|girona|tarragona|sitges|montserrat\b"),
    ("madrid",        r"\bmadrid|toledo|segovia|escorial\b"),
    ("baleariske",    r"\bmallorca|menorca|ibiza|formentera|balear\b"),
    ("kanariske",     r"\bkanari|tenerife|gran canaria|lanzarote|fuerteventura|la palma\b"),
    ("baskerlandet",  r"\bbaskerland|bilbao|san sebasti(á|a)n|rioja|navarra|pamplona\b"),
    ("valencia",      r"\bvalencia|alicante|costa blanca|benidorm|murcia\b"),
    ("galicien",      r"\bgalicien|santiago de compostela|rias baixas|a coru(ñ|n)a\b"),
    ("asturien",      r"\basturien|picos de europa|oviedo|cantabrien\b"),
    ("extremadura",   r"\bextremadura|c(á|a)ceres|m(é|e)rida\b"),
]

REGION_SETS["oestrig"] = [
    ("tyrol",         r"\btyrol|innsbruck|kitzb(ü|u)hel|ischgl|s(ö|o)lden|mayrhofen|zillertal|arlberg|serfaus|(ö|o)tztal\b"),
    ("salzburg",      r"\bsalzburg|salzkammergut|zell am see|kaprun|saalbach|hallstatt|pinzgau|flachau\b"),
    ("wien",          r"\bwien\b|\bvienna\b|sch(ö|o)nbrunn\b"),
    ("vorarlberg",    r"\bvorarlberg|z(ü|u)rs|bregenz|montafon\b"),
    ("steiermark",    r"\bsteiermark|graz|schladming|dachstein\b"),
    ("kaernten",      r"\bk(ä|a)rnten|carinthia|villach|klagenfurt|w(ö|o)rthersee|bad kleinkirchheim\b"),
    ("osttirol",      r"\bosttirol|lienz\b"),
    ("niederoesterreich", r"\bnieder(ö|o)sterreich|wachau|semmering|krems\b"),
]

REGION_SETS["usa"] = [
    ("new-york",      r"\bnew york|manhattan|brooklyn\b"),
    ("californien",   r"\bcalifornien|california|los angeles|san francisco|san diego|napa|yosemite|palm springs\b"),
    ("florida",       r"\bflorida|miami|orlando|key west\b"),
    ("nevada",        r"\blas vegas|nevada\b"),
    ("hawaii",        r"\bhawaii|honolulu|maui|oahu\b"),
    ("nationalparker", r"\byellowstone|grand canyon|zion|utah|arizona|national ?park|monument valley\b"),
    ("sydstaterne",   r"\bnew orleans|louisiana|texas|nashville|memphis|tennessee|charleston\b"),
    ("new-england",   r"\bboston|new england|maine|vermont|massachusetts\b"),
    ("nordvest",      r"\bseattle|portland|oregon|alaska\b"),
    ("chicago",       r"\bchicago|illinois\b"),
]

REGION_SETS["danmark"] = [
    ("koebenhavn",    r"\bk(ø|o)benhavn|copenhagen|amager|frederiksberg|christianshavn\b"),
    ("nordsjaelland", r"\bnordsj(æ|a)lland|helsing(ø|o)r|louisiana|gilleleje|hornb(æ|a)k|dyrehaven\b"),
    ("bornholm",      r"\bbornholm|gudhjem|r(ø|o)nne|hammershus|christians(ø|o)\b"),
    ("fyn",           r"\bfyn\b|odense|(æ|a)r(ø|o)|svendborg|langeland|t(å|a)singe\b"),
    ("vestjylland",   r"\bvestjylland|ringk(ø|o)bing|holmsland|hvide sande|bl(å|a)vand|s(ø|o)ndervig|thy\b"),
    ("oestjylland",   r"\baarhus|(å|a)rhus|djursland|mols|vejle|horsens|silkeborg|himmelbjerget\b"),
    ("nordjylland",   r"\bskagen|aalborg|(å|a)lborg|l(ø|o)kken|l(æ|a)s(ø|o)|hirtshals|r(å|a)bjerg\b"),
    ("sydjylland",    r"\bs(ø|o)nderjylland|ribe|r(ø|o)m(ø|o)|fan(ø|o)|esbjerg|m(ø|o)gelt(ø|o)nder|vadehavet\b"),
    ("sydsjaelland",  r"\bm(ø|o)n\b|stevns|falster|lolland|sydsj(æ|a)lland\b"),
]

REGION_SETS["tyskland"] = [
    ("berlin",        r"\bberlin|potsdam\b"),
    ("bayern",        r"\bbayern|m(ü|u)nchen|munich|neuschwanstein|garmisch|bayerske|allg(ä|a)u|n(ü|u)rnberg\b"),
    ("hamborg",       r"\bhamborg|hamburg|elbphilharmonie\b"),
    ("rhinlandet",    r"\brhin|rhein|k(ö|o)ln|cologne|d(ü|u)sseldorf|mosel|koblenz\b"),
    ("bodensoeen",    r"\bbodens(ø|o)|konstanz|lindau|meersburg\b"),
    ("sortskoven",    r"\bsortskov|schwarzwald|black forest|freiburg|baden-baden\b"),
    ("saksen",        r"\bdresden|leipzig|saksen|sachsen\b"),
    ("nordtyskland",  r"\bsylt|r(ü|u)gen|usedom|l(ü|u)beck|ostsee|nordsee|bremen\b"),
]

# Kept so the original Italy-only name still resolves.
REGION_PATTERNS = REGION_SETS["italien"]


def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": "lmg-match/0.1 (+LMG content map builder)"})
    with urllib.request.urlopen(req, timeout=30) as r:
        # r.headers is case-insensitive; dict() would lose that and X-WP-Total
        # would silently read as 0, which defeats the truncation guard below.
        return json.loads(r.read().decode("utf-8")), r.headers


def clean(html):
    text = re.sub(r"<[^>]+>", "", html or "")
    return unescape(text).replace("\xa0", " ").strip()


def trim(text, limit=200):
    """Truncate on a word boundary. A hard slice leaves 'det ukendte Ital'."""
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) <= limit:
        return text
    cut = text[:limit]
    space = cut.rfind(" ")
    if space > limit * 0.6:
        cut = cut[:space]
    return cut.rstrip(" .,;:—-") + "…"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--site", required=True)
    ap.add_argument("--category", required=True, type=int)
    ap.add_argument("--out", required=True)
    ap.add_argument("--per-page", type=int, default=100)
    ap.add_argument("--regions", default="italien",
                    help="Region keyword set to infer from: "
                         + ", ".join(sorted(REGION_SETS)) + ", or 'none'. "
                         "Region affects result DIVERSITY only, never whether an item matches. "
                         "Defaults to italien so the original Italy invocation is unchanged.")
    args = ap.parse_args()

    if args.regions != "none" and args.regions not in REGION_SETS:
        sys.exit("ABORT: unknown --regions '%s'. Known: %s, none."
                 % (args.regions, ", ".join(sorted(REGION_SETS))))
    region_patterns = [] if args.regions == "none" else REGION_SETS[args.regions]

    base = args.site.rstrip("/") + "/wp-json/wp/v2"

    # Term vocabulary first, so category ids can be resolved to slugs.
    # `parent` is fetched because the destination facet walks the real term tree
    # (italien > europa > rejsemal). That is measured site structure, not a guess.
    terms, _ = fetch(f"{base}/categories?per_page=100&_fields=id,slug,name,count,parent")
    page = 2
    while True:
        more, _ = fetch(f"{base}/categories?per_page=100&page={page}&_fields=id,slug,name,count,parent")
        if not more:
            break
        terms += more
        page += 1
    by_id = {t["id"]: t for t in terms}
    by_slug = {t["slug"]: t for t in terms}

    def ancestry(slug):
        """Slug and every ancestor slug, walking real WP parents. Measured."""
        out, term, guard = [], by_slug.get(slug), 0
        while term and guard < 12:
            out.append(term["slug"])
            term = by_id.get(term.get("parent") or 0)
            guard += 1
        return out

    def destinations(slugs):
        """
        Every geographic value a post carries: the country itself AND its continent.

        Both levels are emitted so a config can ask its destination question at
        whichever level its corpus can actually answer. Mad og vin has 25 Italian
        posts and can name Italy; Eventyrrejser is spread over 78 destinations and
        only holds up at continent level (Asien 42, Europa 39, Sydamerika 21).
        Same map, same engine — the config chooses the altitude.
        """
        found = []
        for slug in slugs:
            if slug in CATEGORY_FACETS or slug in NON_GEO:
                continue
            line = ancestry(slug)
            if GEO_ROOT not in line:
                continue                       # not under Rejsemål ⇒ not a place
            for value in line:
                if value != GEO_ROOT and value not in found:
                    found.append(value)
        return found

    # Posts. Paged explicitly and reconciled against X-WP-Total, because a
    # truncated REST response parses cleanly and silently undercounts.
    posts, page = [], 1
    expected = None
    while True:
        data, headers = fetch(
            f"{base}/posts?categories={args.category}&per_page={args.per_page}&page={page}"
            "&orderby=id&order=asc&_fields=id,link,title,excerpt,date,categories"
        )
        if expected is None:
            expected = int(headers.get("X-WP-Total", 0))
        if not data:
            break
        posts += data
        if len(posts) >= expected:
            break
        page += 1

    if expected is not None and len(posts) != expected:
        sys.exit(f"ABORT: fetched {len(posts)} posts, X-WP-Total says {expected}. Refusing to write a partial map.")

    # Preserve human edits from any previous run.
    curated = {}
    if os.path.exists(args.out):
        with open(args.out) as f:
            for item in json.load(f).get("items", []):
                if item.get("source") == "curated":
                    curated[item["id"]] = item

    items, unmapped = [], 0
    for p in posts:
        if p["id"] in curated:
            items.append(curated[p["id"]])
            continue

        title = clean(p["title"]["rendered"])
        slugs = [by_id[c]["slug"] for c in p.get("categories", []) if c in by_id]

        facets, evidence = {}, {}
        for slug in slugs:
            if slug in CATEGORY_FACETS:
                facet, value = CATEGORY_FACETS[slug]
                facets.setdefault(facet, [])
                if value not in facets[facet]:
                    facets[facet].append(value)
                    evidence.setdefault(facet, []).append(slug)

        # Measured from the term tree, so it carries the same weight as interest —
        # unlike `region` below, this is never a guess and may safely decide a match.
        places = destinations(slugs)
        if places:
            facets["destination"] = places
            evidence["destination"] = places

        haystack = (title + " " + p["link"]).lower()
        for region, pattern in region_patterns:
            if re.search(pattern, haystack):
                facets["region"] = [region]
                break

        if not facets.get("interest"):
            unmapped += 1

        items.append({
            "id": p["id"],
            "title": title,
            "link": p["link"],                      # canonical, straight from the API — never constructed
            "excerpt": trim(clean(p["excerpt"]["rendered"])),
            "date": p["date"][:10],
            "categories": slugs,
            "facets": facets,
            "evidence": evidence,                   # which term produced which facet
            # "auto" only when a keyword-guessed region is the ONLY thing we know.
            # Written as a set test because `destination` now sits alongside it and
            # a length check would quietly stop flagging guesses.
            "source": "auto" if set(facets) == {"region"} else "measured",
        })

    out = {
        "generated": True,
        "site": args.site,
        "category": args.category,
        "count": len(items),
        "note": (
            "Facets other than `region` are read from real WP categories (measured). "
            "`region` is inferred from title/slug keywords (auto) and only affects result "
            "diversity, never whether an item matches. Set an item's \"source\" to "
            "\"curated\" to protect your edits from the next run."
        ),
        "facet_gaps": UNSUPPORTED_FACETS,
        "items": items,
    }

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)

    print(f"wrote {args.out}: {len(items)} items ({len(curated)} curated preserved)")
    print(f"items with no interest facet: {unmapped}")
    with_region = sum(1 for i in items if "region" in i.get("facets", {}))
    print(f"items with a region detected: {with_region} (set: {args.regions})")
    for facet in ("interest", "destination", "value", "party", "duration", "season"):
        n = sum(1 for i in items if i.get("facets", {}).get(facet))
        print(f"  {facet}: {n}")


if __name__ == "__main__":
    main()
