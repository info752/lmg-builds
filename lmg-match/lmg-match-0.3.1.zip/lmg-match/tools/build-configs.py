#!/usr/bin/env python3
"""
Scaffold lmg-match question sets from a spec.

WHY THIS EXISTS, AND WHAT IT IS NOT
-----------------------------------
A question set is a JSON file, and that stays true: after this script writes one,
the file is the source of truth and is edited by hand. This is a ONE-SHOT
SCAFFOLD for bringing a batch of sets into existence with identical plumbing
(weights, exclusions, newsletter copy, analytics, result rules), not a build step.
Do not re-run it over a set someone has edited — it would overwrite the edit.

WHAT IT ENFORCES, AND WHY THAT IS THE POINT
-------------------------------------------
Every option a set offers must be backed by content that actually exists. The
five sets written before this script were byte-identical copies of the Italy one,
so Greece offered "Kunst & historie", "Togrejser", "Små byer" and "Det ukendte
Grækenland" against a corpus holding ZERO of each: four of eight buttons led to
the honest-empty state. This script reads the generated content map and REFUSES
to write an option the corpus cannot answer (see MIN_ITEMS).

Two shapes:

  country — "Hvilket Italien vil du gerne opleve?"
            Q1 is interest; the corpus discriminates on what the trip is about.

  cluster — "Hvor vil du spise dig igennem?"
            Q1 is destination; inside Mad og vin every post is about food, so the
            thing that separates them is WHERE. Needs no engine change: the
            engine scores whatever facets it is handed, and the content map now
            carries `destination` measured from the real term tree.

Usage:
    python3 tools/build-configs.py            # write every set in SPECS
    python3 tools/build-configs.py oestrig    # write one
"""

import json
import os
import sys
import collections

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

# An option must be answerable by at least this many published posts. Below it,
# the button is a trapdoor: the reader picks it and is told we have nothing.
MIN_ITEMS = 2

ACCENT = "#B8956A"
SITE = "traveltalk.dk"

# Danish labels. Sentence case throughout — no title case (house rule).
INTEREST_LABELS = {
    "kunst_historie": ("Kunst & historie", "kunst og historie"),
    "mad_vin":        ("Mad & vin", "mad og vin"),
    "strand_kyst":    ("Strand & kyst", "strand og kyst"),
    "natur_bjerge":   ("Natur & bjerge", "natur og bjerge"),
    "storby":         ("Storby & atmosfære", "storby"),
    "ski":            ("Ski & vintersport", "ski og vintersport"),
    "eventyr":        ("Eventyr & action", "eventyr"),
    "cykel":          ("Cykelferie", "cykelferie"),
    "golf":           ("Golf", "golf"),
    "dyk":            ("Dykning", "dykning"),
    "sejl":           ("Sejlads", "sejlads"),
    "krydstogt":      ("Krydstogt", "krydstogt"),
    "safari":         ("Safari", "safari"),
    "tog":            ("Togrejser", "togrejser"),
    "smaa_byer":      ("Små byer & landsbyer", "små byer"),
    "det_ukendte":    ("Det ukendte {{subject}}", "det mindre kendte"),
}

DESTINATION_LABELS = {
    "italien": "Italien", "frankrig": "Frankrig", "spanien": "Spanien",
    "graekenland": "Grækenland", "portugal": "Portugal", "oestrig": "Østrig",
    "tyskland": "Tyskland", "danmark": "Danmark", "england": "England",
    "schweiz": "Schweiz", "norge": "Norge", "sverige": "Sverige",
    "kroatien": "Kroatien", "tyrkiet": "Tyrkiet", "usa": "USA",
    "thailand": "Thailand", "japan": "Japan", "singapore": "Singapore",
    "indonesien": "Indonesien", "filippinerne": "Filippinerne",
    "europa": "Europa", "asien": "Asien", "afrika": "Afrika",
    "nordamerika": "Nordamerika", "sydamerika": "Sydamerika",
    "oceanien": "Oceanien", "caribien": "Caribien",
    "mellemoesten": "Mellemøsten", "amerika": "Amerika",
}

# Order options are offered in. Depth decides: the reader meets what we cover best
# first, and the tail of the list is never the empty end of the corpus.
def by_count(values, counts):
    return sorted(values, key=lambda v: (-counts.get(v, 0), v))


# --- The sets ----------------------------------------------------------------
# `dest` lists the destination options for a cluster, at whichever altitude the
# corpus supports. Mad og vin names countries because it has 25 Italian posts;
# Eventyrrejser names continents because its 156 posts are spread over 78
# destinations and no single country holds more than 8.

SPECS = {
    # ---- country sets ----
    "italien":     dict(kind="country", subject="Italien", regions="italien"),
    "frankrig":    dict(kind="country", subject="Frankrig", regions="frankrig"),
    "spanien":     dict(kind="country", subject="Spanien", regions="spanien"),
    "graekenland": dict(kind="country", subject="Grækenland", regions="graekenland"),
    "portugal":    dict(kind="country", subject="Portugal", regions="portugal"),
    "oestrig":     dict(kind="country", subject="Østrig", regions="oestrig"),
    "usa":         dict(kind="country", subject="USA", regions="usa"),
    "danmark":     dict(kind="country", subject="Danmark", regions="danmark"),
    "tyskland":    dict(kind="country", subject="Tyskland", regions="tyskland"),

    # ---- cluster sets ----
    "mad-og-vin": dict(
        kind="cluster", subject="Mad og vin",
        eyebrow="Find din madrejse",
        title="Hvor vil du spise dig igennem?",
        body="Vi har skrevet om køkkener og vinmarker over hele verden. "
             "Fortæl os hvor og hvordan, så finder vi det, der passer til dig.",
        cta="Se din madrejse", resultTitle="Din madrejse",
        dest=["italien", "graekenland", "spanien", "frankrig", "oestrig",
              "portugal", "tyskland", "asien"],
    ),
    "storbyferie": dict(
        kind="cluster", subject="Storbyferie",
        eyebrow="Find din storby",
        title="Hvilken storby bliver den næste?",
        body="Fra en lang weekend til en uge. Fortæl os hvor i verden du kigger hen, "
             "så finder vi byerne og det, der er værd at gå efter.",
        cta="Se din storby", resultTitle="Din storby",
        dest=["italien", "usa", "frankrig", "tyskland", "oestrig", "spanien",
              "england", "asien"],
    ),
    "sol-og-strand": dict(
        kind="cluster", subject="Sol og strand",
        eyebrow="Find din strand",
        title="Hvor skal solen ramme dig?",
        body="Kyster, øer og det vand, der er værd at rejse efter. "
             "Fortæl os hvor du kigger hen, så finder vi stederne.",
        cta="Se din strand", resultTitle="Din strand",
        dest=["graekenland", "spanien", "italien", "portugal", "asien",
              "caribien", "mellemoesten", "afrika"],
    ),
    "skiferie": dict(
        kind="cluster", subject="Skiferie",
        eyebrow="Find din skiferie",
        title="Hvor skal skiene stå i år?",
        body="Pister, hytter og byer der kan mere end lifte. "
             "Fortæl os hvor du kigger hen, så finder vi resten.",
        cta="Se din skiferie", resultTitle="Din skiferie",
        dest=["oestrig", "italien", "frankrig", "schweiz", "norge"],
        # 17% of ski posts carry a second interest. Asking it to rank would be
        # ranking on almost nothing, so it is collected and weighted 0.
        interest_weight=0,
    ),
    "kunst-og-kultur": dict(
        kind="cluster", subject="Kunst og kultur",
        eyebrow="Find din kulturrejse",
        title="Hvor vil du se kunsten?",
        body="Museer, arkitektur og byer der bærer deres historie udenpå. "
             "Fortæl os hvor du kigger hen.",
        cta="Se din kulturrejse", resultTitle="Din kulturrejse",
        dest=["italien", "frankrig", "spanien", "tyskland", "oestrig",
              "danmark", "usa", "asien"],
    ),
    "naturrejser": dict(
        kind="cluster", subject="Naturrejser",
        eyebrow="Find din naturrejse",
        title="Hvilken natur trækker?",
        body="Bjerge, kyster, skov og vildmark. Fortæl os hvilken del af verden "
             "du kigger mod, så finder vi turene.",
        cta="Se din naturrejse", resultTitle="Din naturrejse",
        dest=["europa", "asien", "afrika", "sydamerika", "nordamerika"],
    ),
    "familieferie": dict(
        kind="cluster", subject="Familieferie",
        eyebrow="Find familiens rejse",
        title="Hvor skal familien hen?",
        body="Steder der fungerer for både børn og voksne. "
             "Fortæl os hvor I kigger hen, så finder vi dem.",
        cta="Se familiens rejse", resultTitle="Familiens rejse",
        dest=["oestrig", "graekenland", "spanien", "frankrig", "italien", "danmark"],
    ),
    "eventyrrejser": dict(
        kind="cluster", subject="Eventyrrejser",
        eyebrow="Find dit eventyr",
        title="Hvor skal eventyret foregå?",
        body="De rejser man tager for at komme et sted hen, man ikke kan forklare "
             "bagefter. Fortæl os hvilken del af verden, så finder vi dem.",
        cta="Se dit eventyr", resultTitle="Dit eventyr",
        dest=["asien", "europa", "sydamerika", "nordamerika", "afrika",
              "oceanien", "caribien"],
    ),
}


def load_map(key):
    path = os.path.join(ROOT, "content", f"traveltalk-{key}.items.json")
    if not os.path.exists(path):
        return None, path
    with open(path) as f:
        return json.load(f)["items"], path


def counts_for(items, facet, exclusions):
    """Count items per facet value, applying the same exclusions the engine will.

    Counting the raw corpus would offer options the engine then filters away —
    the charter and Covid-era posts are removed before anything is scored.
    """
    drop_cats = set(exclusions["categories"])
    drop_ids = set(exclusions.get("ids") or [])
    rng = exclusions.get("dateRange")          # optional now, and normally absent
    c = collections.Counter()
    for it in items:
        if drop_cats & set(it.get("categories", [])):
            continue
        if it.get("id") in drop_ids:
            continue
        if rng:
            year = int((it.get("date") or "0000")[:4])
            if rng["from"] <= year <= rng["to"]:
                continue
        for v in it.get("facets", {}).get(facet, []):
            c[v] += 1
    return c


# The 12 posts that are genuinely ABOUT the pandemic — a Covid word in the title,
# or three or more mentions in the body. Audited per post on 2026-09-06, not
# inferred from a date. Nothing here is deleted or drafted: these stay published,
# indexed and linked; they are simply not offered as a recommendation.
COVID_IDS = [52975, 52976, 53058, 53065, 53083, 53087,
             53091, 53169, 53174, 53222, 53229, 53230]

EXCLUSIONS = {
    # NO charterferie. G, 7 Sep 2026: "vi kan nævne og beholde charter, det er bare
    # lavt prioriteret … ved at beholde det får vi mere trafik på det vi faktisk kan,
    # uden at udelukke nogen eller virke snobbede … det er bare ikke noget vi
    # udelukker eller noget vi prioriterer."
    #
    # This replaces the earlier Greece-only workaround, which is now deleted: the
    # ruling is portfolio-wide, so the special case is gone rather than kept.
    # 92 post-slots across the sets come back, 16 of them the Greek islands.
    "categories": ["busrejser", "erhvervsrejser",
                   "rusland", "iran", "syrien"],
    # NO dateRange. It used to be {from: 2020, to: 2022}, written as "the Covid
    # vintage" — and the premise was measured false on 2026-09-06. Of 349 published
    # posts in that window, 323 never mention Covid at all. Across the 13 live sets
    # the rule was hiding 191 posts to suppress THREE, taking Disneyland i Paris
    # (2.960 ord), Rejsen til Madagaskar (3.414 ord) and Skirejsetips til Østrig
    # with it. G's ruling on the asymmetry: a stray Covid mention costs far less
    # than ten good posts made invisible.
    #
    # A single passing mention is deliberately NOT an exclusion. 14 posts mention
    # it once — "Skiferie i USA, Snowbird i Utah: rent pudder" among them — and a
    # first pass that scored by keyword DENSITY wrongly flagged them, because
    # density punishes a short post for one word. They are all kept.
    "ids": COVID_IDS,
}


def build(key, spec):
    items, path = load_map(key)
    if items is None:
        return None, f"no content map at {path}"

    kind = spec["kind"]
    subject = spec["subject"]
    exclusions = dict(EXCLUSIONS)
    if spec.get("exclude_categories") is not None:
        exclusions["categories"] = spec["exclude_categories"]
    icounts = counts_for(items, "interest", exclusions)
    dcounts = counts_for(items, "destination", exclusions)

    # --- Q1 -------------------------------------------------------------------
    dropped = []
    if kind == "country":
        live = [v for v, n in icounts.items() if n >= MIN_ITEMS]
        dropped = [v for v in INTEREST_LABELS if v not in live and v in icounts or
                   (v not in icounts and v in ("smaa_byer", "det_ukendte"))]
        live = by_count(live, icounts)
        q1 = {
            "id": "interest", "facet": "interest",
            "title": "Hvad trækker mest?", "help": "Vælg op til 3",
            "multiple": True, "max": 3,
            "options": [{"value": v, "label": INTEREST_LABELS[v][0]} for v in live],
        }
        q1_counts = {v: icounts[v] for v in live}
    else:
        wanted = spec["dest"]
        live = [v for v in wanted if dcounts.get(v, 0) >= MIN_ITEMS]
        dropped = [v for v in wanted if v not in live]
        live = by_count(live, dcounts)
        # SINGLE-select, deliberately, and it is not a UI preference.
        #
        # The engine scores share = hits / values-you-chose. For interests that is
        # exactly right: ask for food AND art, and an item covering one of the two
        # has genuinely given you half. For destinations it is wrong — picking
        # Italy, Greece and Spain means ANY of them, not all three, yet an Italian
        # post would score 1/3 and fall below a wrong-country post that happened to
        # match on interest. Measured before this was fixed: choosing Italien in
        # Mad og vin returned Split, Madrid and the Whitsunday Islands at 0.33.
        # One country per run keeps the primary axis exact.
        q1 = {
            "id": "destination", "facet": "destination",
            "title": "Hvor i verden?",
            "multiple": False,
            "options": [{"value": v, "label": DESTINATION_LABELS[v]} for v in live],
        }
        q1_counts = {v: dcounts[v] for v in live}

    if not live:
        return None, "no option survived the content check"

    questions = [q1]

    # --- Q2, cluster only: what else is it about ------------------------------
    if kind == "cluster":
        self_values = {
            "mad-og-vin": "mad_vin", "storbyferie": "storby",
            "sol-og-strand": "strand_kyst", "skiferie": "ski",
            "kunst-og-kultur": "kunst_historie", "naturrejser": "natur_bjerge",
            "eventyrrejser": "eventyr", "familieferie": None,
        }
        skip = self_values.get(key)
        sec = by_count([v for v, n in icounts.items()
                        if n >= MIN_ITEMS and v != skip and v in INTEREST_LABELS],
                       icounts)[:6]
        if sec:
            questions.append({
                "id": "interest", "facet": "interest",
                "title": "Hvad skal der ellers være?",
                "help": "Vælg op til 2", "multiple": True, "max": 2,
                "options": [{"value": v, "label": INTEREST_LABELS[v][0]} for v in sec],
            })

    questions += [
        {"id": "party", "facet": "party", "title": "Hvordan rejser du?",
         "multiple": False, "options": [
             {"value": "alene", "label": "Alene"},
             {"value": "par", "label": "Som par"},
             {"value": "familie", "label": "Med familie"},
             {"value": "venner", "label": "Med venner"}]},
        {"id": "duration", "facet": "duration", "title": "Hvor lang tid har du?",
         "multiple": False, "options": [
             {"value": "weekend", "label": "Weekend / kort tur"},
             {"value": "d4_7", "label": "4–7 dage"},
             {"value": "d8_14", "label": "8–14 dage"},
             {"value": "d15", "label": "Mere end 2 uger"}]},
        {"id": "season", "facet": "season", "title": "Hvornår tænker du på at rejse?",
         "help": "Vælg en årstid, eller spring over hvis det ikke ligger fast",
         "multiple": False, "required": False, "options": [
             {"value": "foraar", "label": "Forår", "months": [3, 4, 5]},
             {"value": "sommer", "label": "Sommer", "months": [6, 7, 8]},
             {"value": "efteraar", "label": "Efterår", "months": [9, 10, 11]},
             {"value": "vinter", "label": "Vinter", "months": [12, 1, 2]}]},
        {"id": "value", "facet": "value", "title": "Hvad vejer tungest?",
         "multiple": False, "options": [
             {"value": "oplevelse", "label": "Oplevelsen"},
             {"value": "komfort", "label": "Komfort"},
             {"value": "fleksibilitet", "label": "Fleksibilitet"},
             {"value": "pris", "label": "Pris"}]},
    ]

    interest_weight = spec.get("interest_weight", 0.5)
    if kind == "country":
        weights = {"interest": 1.0, "value": 0.3, "party": 0.25,
                   "duration": 0, "season": 0}
        floor, diversify = 1.0, {"by": "region", "max": 2}
    else:
        weights = {"destination": 1.0, "interest": interest_weight,
                   "value": 0.3, "party": 0.25, "duration": 0, "season": 0}
        # Floor sits above the destination weight alone, so an item that matches
        # only the country cannot normalise to a perfect score.
        floor = 1.0 + max(interest_weight, 0.5)
        diversify = {"by": "destination", "max": 2}

    labels = {
        "interest": {v: INTEREST_LABELS[v][1] for v in INTEREST_LABELS},
        "destination": dict(DESTINATION_LABELS),
        "value": {"pris": "pris", "komfort": "komfort",
                  "fleksibilitet": "fleksibilitet", "oplevelse": "oplevelsen"},
        "party": {"familie": "familierejser", "par": "par"},
    }

    if kind == "country":
        intro = {
            "eyebrow": "Find dit {{subject}}",
            "title": "Hvilket {{subject}} vil du gerne opleve?",
            "body": "{{subject}} er ikke én destination. Fortæl os lidt om, hvad du "
                    "drømmer om, så finder vi de steder og oplevelser, der passer "
                    "bedst til dig.",
            "start": "Start",
            "duration": f"{len(questions)} spørgsmål. 30 sekunder. Klogere på rejsedrømme.",
        }
        cta, rtitle = "Se dit {{subject}}", "Dit {{subject}}"
        empty = ("Vi har ikke dækket den kombination endnu. Prøv en anden vinkel, "
                 "eller kig med i nyhedsbrevet — vi skriver om {{subject}} hele året.")
    else:
        intro = {
            "eyebrow": spec["eyebrow"], "title": spec["title"], "body": spec["body"],
            "start": "Start",
            "duration": f"{len(questions)} spørgsmål. 30 sekunder. Klogere på rejsedrømme.",
        }
        cta, rtitle = spec["cta"], spec["resultTitle"]
        empty = ("Vi har ikke dækket den kombination endnu. Prøv en anden vinkel, "
                 "eller kig med i nyhedsbrevet — vi skriver hele året.")

    cfg = {
        "id": f"traveltalk-{key}",
        "version": "0.2.0",
        "locale": "da-DK",
        "site": SITE,
        "accent": ACCENT,
        "subject": subject,
        "purpose": "Giver læseren en personlig anbefaling ud fra Traveltalks eget "
                   "indhold, og giver Traveltalk aggregeret indsigt i, hvad læserne "
                   "faktisk vil have.",
        "content": f"traveltalk-{key}.items.json",
        "_options_note": (
            "Q1's options are not a copied list — each one is backed by at least "
            f"{MIN_ITEMS} published posts that survive the exclusions below, "
            "counted from the content map when this set was scaffolded. "
            "Adding an option the corpus cannot answer puts a trapdoor in the "
            "funnel: the reader picks it and is told we have nothing."
        ),
        "_coverage": q1_counts,
        "intro": intro,
        "questions": questions,
        "_facetWeights_note": (
            "A facet is weighted above 0 only where the corpus can actually carry "
            "it. duration and season are collected as demand signal and rank "
            "nothing, because almost no post records either."
        ),
        "facetWeights": weights,
        "matchLabels": labels,
        "results": {
            # minScore is the cut, and for a cluster it is load-bearing.
            # With the floor below, a right-country result scores >= 0.67 and a
            # wrong-country one <= 0.33, so 0.5 cleanly removes results from
            # somewhere the reader did not ask about. It also means a thin answer
            # returns two results and says so, rather than padding to four with
            # posts about another continent.
            "count": 4, "minScore": 0.5 if kind == "cluster" else 0.01,
            "scoreFloor": floor,
            "confidentScore": 0.34, "minConfident": 2,
            "diversify": diversify,
            "cta": cta, "title": rtitle, "matchPrefix": "Matcher",
            "thinNote": "Vi har ikke skrevet så meget om lige den kombination endnu. "
                        "Her er det nærmeste, vi har.",
            "emptyNote": empty,
            "restart": "Prøv igen",
        },
        "_exclusions_note": (
            "Editorial rulings, kept in config so they can be switched off without "
            "a deploy. Charter is a brand exclusion; 2020–22 is the Covid vintage."
        ),
        "exclusions": exclusions,
        "activation": {
            "newsletter": {
                "enabled": True, "provider": "brevo", "gate": False,
                "_gate_note": "MUST stay false until the legal read on GDPR Art. 7(4) "
                              "comes back. Tightening later is a config change; "
                              "loosening later means a contaminated list.",
                "eyebrow": "Nyhedsbrev",
                "headline": "Mere {{subject}} i indbakken",
                "sub": "Vi skriver om {{subject}} hele året. Et brev om ugen, "
                       "ingen tilbudsmails.",
                "placeholder": "Din e-mail", "cta": "Tilmeld",
                "legal": "Du kan afmelde når som helst. Vi deler ikke din adresse.",
            },
            "partners": [],
            "_partners_note": "Built generic and empty at launch. A partner entry is "
                              "{ id, name, blurb, url, facets:{} } and is matched by "
                              "the same engine. Switching one on is a config change.",
        },
        "analytics": {
            "enabled": True,
            "requireConsent": False,
            "_consent_note": "false by G's explicit call 2026-09-05: the gate was not "
                             "merely strict, it was dead — setConsent() was never wired "
                             "to Complianz, so every own-table event was dropped in the "
                             "browser. GA4 is governed separately by Complianz.",
            "endpoint": "/wp-json/lmg-match/v1/event",
            "_note": "Aggregated only. No IP, no user agent, no free text, no "
                     "cross-session identifier.",
        },
    }

    out = os.path.join(ROOT, "config", f"traveltalk-{key}.json")
    with open(out, "w") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=1)
    return {"path": out, "n": len(items), "live": live, "counts": q1_counts,
            "dropped": sorted(set(dropped)), "kind": kind}, None


def main():
    wanted = sys.argv[1:] or list(SPECS)
    ok, fail = [], []
    for key in wanted:
        if key not in SPECS:
            fail.append((key, "not in SPECS"))
            continue
        res, err = build(key, SPECS[key])
        (fail if err else ok).append((key, err or res))

    for key, r in ok:
        opts = ", ".join(f"{v}:{r['counts'][v]}" for v in r["live"])
        print(f"{r['kind']:8s} {key:16s} {r['n']:4d} items  Q1 options: {opts}")
        if r["dropped"]:
            print(f"{'':25s} dropped (no content): {', '.join(r['dropped'])}")
    for key, err in fail:
        print(f"SKIP     {key:16s} {err}")
    print(f"\n{len(ok)} written, {len(fail)} skipped")


if __name__ == "__main__":
    main()
