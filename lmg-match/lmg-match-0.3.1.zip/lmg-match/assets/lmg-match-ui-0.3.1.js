/**
 * lmg-match UI — the on-site layer.
 *
 * Renders a question set from config and hands the answers to the engine.
 * It holds no matching logic of its own: change how results are chosen in
 * lmg-match-engine.js, and the widget, the concierge and any future front door
 * all change together.
 *
 * No framework, no dependencies, no render-blocking work.
 */
(function (window, document) {
    'use strict';

    var Engine = window.LMGMatch;
    if (!Engine) { return; }

    // --- helpers -------------------------------------------------------------

    function tpl(str, vars) {
        if (typeof str !== 'string') return str;
        return str.replace(/\{\{(\w+)\}\}/g, function (m, key) {
            return vars[key] !== undefined ? vars[key] : m;
        });
    }

    function el(tag, attrs, children) {
        var node = document.createElement(tag);
        for (var k in attrs || {}) {
            if (k === 'text') node.textContent = attrs[k];
            else if (k === 'html') node.innerHTML = attrs[k];
            else if (attrs[k] !== null && attrs[k] !== undefined) node.setAttribute(k, attrs[k]);
        }
        (children || []).forEach(function (c) { if (c) node.appendChild(c); });
        return node;
    }

    function randomId() {
        // Session-scoped and disposable. Not a visitor identifier: it exists so a
        // sequence of events can be stitched into one funnel, and it is gone when
        // the tab closes. Never stored, never matched to anything else.
        return 'm' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
    }

    // --- widget --------------------------------------------------------------

    /**
     * `loadItems` is a function returning a Promise for the content map, not the
     * map itself. The map is the heavy part (60 KB on the Italy set) and a page
     * view that never touches the widget should not pay for it — it is fetched on
     * first interaction, and prefetched on hover/focus so the wait is invisible.
     */
    function Widget(root, config, loadItems) {
        this.root = root;
        this.config = config;
        this.items = null;
        this.loadItems = loadItems;
        this.itemsPromise = null;
        this.vars = { subject: config.subject || '' };
        this.placement = root.getAttribute('data-placement') || '';
        this.sessionId = randomId();
        this.consent = !config.analytics || !config.analytics.requireConsent;
        this.session = null;
        this.startedAt = null;
        this.render();
    }

    Widget.prototype.ensureItems = function () {
        var self = this;
        if (this.itemsPromise) return this.itemsPromise;
        this.itemsPromise = Promise.resolve(this.loadItems()).then(function (items) {
            self.items = items;
            return items;
        });
        return this.itemsPromise;
    };

    Widget.prototype.t = function (str) { return tpl(str, this.vars); };

    /**
     * Every event is aggregate-shaped: what was chosen, never who chose it.
     * Nothing is sent before consent, and nothing sent contains free text.
     */
    Widget.prototype.emit = function (name, payload) {
        var cfg = this.config.analytics || {};
        var detail = {
            event: name,
            config: this.config.id,
            session: this.sessionId,
            at: new Date().toISOString(),
            data: payload || {}
        };

        this.root.dispatchEvent(new CustomEvent('lmg-match:' + name, { detail: detail, bubbles: true }));

        // GA4 first, and outside the block below: it has its own consent regime
        // (Complianz / Consent Mode) and must not be gated by ours as well.
        this.toGA(name, payload || {}, (this.session && this.session.answers) || {});

        if (!cfg.enabled) return;
        if (cfg.requireConsent && !this.consent) return;
        if (!cfg.endpoint) return;

        try {
            var body = JSON.stringify(detail);
            if (navigator.sendBeacon) {
                navigator.sendBeacon(cfg.endpoint, new Blob([body], { type: 'application/json' }));
            } else {
                fetch(cfg.endpoint, {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: body, keepalive: true
                }).catch(function () {});
            }
        } catch (e) { /* analytics must never break the experience */ }
    };

    Widget.prototype.setConsent = function (granted) { this.consent = !!granted; };

    /**
     * GA4.
     *
     * Deliberately carries NO session identifier. GA4 already holds geo, device
     * and behavioural history; giving it our session key would make the anonymous
     * response table joinable to all of that and quietly undo the privacy position.
     * The facets travel as event parameters instead, which answers the same
     * question — "do readers from search want different things than newsletter
     * readers?" — inside GA4, without a bridge between the two systems.
     *
     * Consent is not checked here on purpose: gtag is governed by the site's own
     * consent tooling (Complianz + GA4 Consent Mode), which is the correct place
     * for it. Adding a second gate would mean two mechanisms disagreeing.
     *
     * Event names are generic with the destination as a parameter, so one set of
     * GA4 reports serves every destination and two can be compared in one view.
     */
    function gaValue(v) {
        if (Array.isArray(v)) v = v.slice().sort().join(',');
        if (v === null || v === undefined) return undefined;
        if (typeof v === 'boolean') return v ? 1 : 0;
        return String(v).slice(0, 100);   // GA4 caps parameter values at 100 chars
    }

    Widget.prototype.ga = function (name, params) {
        if (typeof window.gtag !== 'function') return;
        var out = { config_id: this.config.id, subject: this.config.subject || '', placement: this.placement || '' };
        for (var k in params) {
            var v = gaValue(params[k]);
            if (v !== undefined && v !== '') out[k] = v;
        }
        try { window.gtag('event', name, out); } catch (e) { /* never break the widget */ }
    };

    /** Internal event → GA4 event(s). */
    Widget.prototype.toGA = function (name, payload, answers) {
        if (name === 'start') {
            this.ga('match_start', {});
        } else if (name === 'answer') {
            this.ga('match_answer', {
                question: payload.question, facet: payload.facet,
                value: payload.values, step: payload.step
            });
        } else if (name === 'result') {
            // Two events on purpose: what the reader told us, and what we showed
            // back. They fire together now, but they answer different questions
            // and will diverge the moment results can fail independently.
            this.ga('match_complete', {
                interests: answers.interest, season: answers.season,
                party: answers.party, trip_length: answers.duration,
                price: answers.value, seconds: payload.seconds
            });
            this.ga('match_result', {
                results_count: payload.returned, confident: payload.confident,
                thin: payload.thin, article_ids: payload.ids
            });
        } else if (name === 'click') {
            this.ga('match_article_click', {
                article_id: payload.id, position: payload.position, score: payload.score
            });
        } else if (name === 'signup') {
            this.ga('match_signup', {});
        }
    };

    Widget.prototype.clear = function () {
        while (this.root.firstChild) this.root.removeChild(this.root.firstChild);
    };

    Widget.prototype.render = function () {
        this.clear();
        this.root.className = 'lmg-match';
        if (this.config.accent) this.root.style.setProperty('--lmg-accent', this.config.accent);
        this.renderIntro();
    };

    // --- screens -------------------------------------------------------------

    Widget.prototype.renderIntro = function () {
        var self = this;
        var intro = this.config.intro || {};

        var start = el('button', { type: 'button', class: 'lmg-match__btn' , text: this.t(intro.start || 'Start') });

        // Warm the content map before it is needed, so the click feels instant.
        var prefetch = function () { self.ensureItems(); };
        start.addEventListener('pointerenter', prefetch, { once: true });
        start.addEventListener('focus', prefetch, { once: true });

        start.addEventListener('click', function () {
            if (self.startedAt) return;                 // guard against a double click
            self.startedAt = Date.now();
            self.emit('start', {});
            start.disabled = true;

            self.ensureItems().then(function (items) {
                self.session = Engine.createSession(self.config, items);
                self.renderQuestion();
            }).catch(function () {
                start.disabled = false;
                self.startedAt = null;
            });
        });

        this.root.appendChild(el('div', { class: 'lmg-match__screen' }, [
            intro.eyebrow ? el('p', { class: 'lmg-match__eyebrow', text: this.t(intro.eyebrow) }) : null,
            el('h2', { class: 'lmg-match__title', text: this.t(intro.title || '') }),
            intro.body ? el('p', { class: 'lmg-match__body', text: this.t(intro.body) }) : null,
            el('div', { class: 'lmg-match__actions' }, [start]),
            intro.duration ? el('p', { class: 'lmg-match__meta', text: this.t(intro.duration) }) : null
        ]));
    };

    Widget.prototype.renderQuestion = function () {
        var self = this;
        var q = this.session.current;
        if (!q) return this.renderResults();

        var chosen = (this.session.answers[q.facet] || []).slice();
        var multiple = !!q.multiple;
        var max = q.max || (multiple ? 99 : 1);

        var options = el('div', { class: 'lmg-match__options' + (multiple ? ' is-multi' : '') });

        (q.options || []).forEach(function (opt) {
            var selected = chosen.indexOf(opt.value) !== -1;
            var btn = el('button', {
                type: 'button',
                class: 'lmg-match__option' + (selected ? ' is-selected' : ''),
                'aria-pressed': multiple ? String(selected) : null,
                text: self.t(opt.label)
            });

            btn.addEventListener('click', function () {
                if (multiple) {
                    var at = chosen.indexOf(opt.value);
                    if (at !== -1) chosen.splice(at, 1);
                    // Cap without blocking: drop the oldest choice so the newest
                    // one always lands. The brief is explicit that three is a
                    // ceiling, not a quota — never force exactly three.
                    else { chosen.push(opt.value); if (chosen.length > max) chosen.shift(); }
                    self.session.answer(q.id, chosen);
                    self.renderQuestion();
                } else {
                    self.session.answer(q.id, [opt.value]);
                    self.advance(q, [opt.value]);
                }
            });

            options.appendChild(btn);
        });

        var actions = [];

        if (this.session.index > 0) {
            var back = el('button', { type: 'button', class: 'lmg-match__link', text: 'Tilbage' });
            back.addEventListener('click', function () { self.session.back(); self.renderQuestion(); });
            actions.push(back);
        }

        if (multiple) {
            var next = el('button', {
                type: 'button',
                class: 'lmg-match__btn',
                text: 'Videre',
                disabled: chosen.length ? null : 'disabled'
            });
            next.addEventListener('click', function () { self.advance(q, chosen); });
            actions.push(next);
        }

        if (q.required === false) {
            var skip = el('button', { type: 'button', class: 'lmg-match__link', text: 'Spring over' });
            skip.addEventListener('click', function () { self.session.answer(q.id, []); self.advance(q, []); });
            actions.push(skip);
        }

        var heading = el('h2', { class: 'lmg-match__title', id: 'lmg-q-' + q.id, tabindex: '-1', text: this.t(q.title) });

        this.clear();
        this.root.appendChild(el('div', {
            class: 'lmg-match__screen', role: 'group', 'aria-labelledby': 'lmg-q-' + q.id
        }, [
            this.renderProgress(),
            heading,
            q.help ? el('p', { class: 'lmg-match__help', text: this.t(q.help) }) : null,
            options,
            actions.length ? el('div', { class: 'lmg-match__actions' }, actions) : null
        ]));

        // Move focus to the new question rather than leaving it on a button that
        // no longer exists — otherwise a keyboard or screen-reader user is dropped
        // back at the top of the document on every step.
        heading.focus();
    };

    Widget.prototype.renderProgress = function () {
        var total = this.session.total;
        var at = this.session.index;
        var bar = el('div', {
            class: 'lmg-match__progress',
            role: 'progressbar',
            'aria-valuemin': '0', 'aria-valuemax': String(total), 'aria-valuenow': String(at),
            'aria-label': 'Spørgsmål ' + (at + 1) + ' af ' + total
        }, [el('span', { style: 'width:' + Math.round((at / total) * 100) + '%' })]);
        return bar;
    };

    Widget.prototype.advance = function (q, chosen) {
        // step is 1-based, so GA4 shows plainly which question loses people
        this.emit('answer', { question: q.id, facet: q.facet, values: chosen, step: this.session.index + 1 });
        this.session.next();
        if (this.session.complete) this.renderResults();
        else this.renderQuestion();
    };

    Widget.prototype.renderResults = function () {
        var self = this;
        var out = this.session.recommend();
        var rules = this.config.results || {};

        this.emit('result', {
            answers: this.session.answers,
            returned: out.results.length,
            confident: out.confident,
            thin: out.thin,
            excluded: out.excluded,
            ids: out.results.map(function (r) { return r.item.id; }),
            seconds: this.startedAt ? Math.round((Date.now() - this.startedAt) / 1000) : null
        });

        var cards = el('div', { class: 'lmg-match__cards' });

        // When every result matched for the same single reason, the per-card line
        // repeats itself four times and tells the reader nothing they can act on —
        // the summary above already said it. Show it per card only when it varies.
        var distinct = {};
        out.results.forEach(function (r) { distinct[r.reasons.slice(0, 3).join(', ')] = 1; });
        var reasonsVary = Object.keys(distinct).length > 1;

        out.results.forEach(function (r, i) {
            var reasons = reasonsVary ? r.reasons.slice(0, 3).join(', ') : '';
            var link = el('a', {
                class: 'lmg-match__card',
                href: r.item.link,          // canonical URL from the REST API — never constructed here
                rel: 'bookmark'
            }, [
                reasons ? el('p', {
                    class: 'lmg-match__why',
                    text: (rules.matchPrefix || 'Matcher') + ': ' + reasons
                }) : null,
                el('h3', { class: 'lmg-match__cardTitle', text: r.item.title }),
                r.item.excerpt ? el('p', { class: 'lmg-match__excerpt', text: r.item.excerpt }) : null
            ]);

            link.addEventListener('click', function () {
                self.emit('click', { id: r.item.id, position: i + 1, score: Math.round(r.score * 100) / 100 });
            });

            cards.appendChild(link);
        });

        var screen = el('div', { class: 'lmg-match__screen lmg-match__screen--results' }, [
            el('h2', { class: 'lmg-match__title', tabindex: '-1', text: this.t(rules.title || '') }),
            el('p', { class: 'lmg-match__body', text: this.summarise(out) }),
            out.thin && out.results.length ? el('p', { class: 'lmg-match__note', text: this.t(rules.thinNote || '') }) : null,
            out.results.length ? cards : el('p', { class: 'lmg-match__note', text: this.t(rules.emptyNote || '') })
        ]);

        var news = this.renderNewsletter();
        if (news) screen.appendChild(news);

        var again = el('button', { type: 'button', class: 'lmg-match__link', text: this.t(rules.restart || 'Prøv igen') });
        again.addEventListener('click', function () {
            // A fresh session id: a second run is a new answer set, not a continuation
            // of the first. The map itself stays loaded.
            self.session = null;
            self.startedAt = null;
            self.sessionId = randomId();
            self.render();
        });
        screen.appendChild(el('div', { class: 'lmg-match__actions' }, [again]));

        this.clear();
        this.root.appendChild(screen);
        screen.querySelector('.lmg-match__title').focus();
    };

    /**
     * The one-line editorial read on the answers, e.g.
     * "Mad og vin, små byer — og en uge. Det peger mod det langsomme Italien."
     * Built from the chosen labels, never invented: the widget must not claim
     * a match the engine did not make.
     */
    Widget.prototype.summarise = function (out) {
        var labels = [];
        var answers = this.session.answers;
        var map = this.config.matchLabels || {};

        for (var facet in answers) {
            if (!map[facet]) continue;
            (answers[facet] || []).forEach(function (v) {
                if (map[facet][v]) labels.push(map[facet][v]);
            });
        }

        if (!labels.length || !out.results.length) return '';

        var list = labels.slice(0, 3);
        var joined = list.length > 1
            ? list.slice(0, -1).join(', ') + ' og ' + list[list.length - 1]
            : list[0];

        return joined.charAt(0).toUpperCase() + joined.slice(1) + ' — det peger på disse.';
    };

    Widget.prototype.renderNewsletter = function () {
        var self = this;
        var n = (this.config.activation || {}).newsletter;
        if (!n || !n.enabled) return null;

        var input = el('input', {
            type: 'email', class: 'lmg-match__input',
            placeholder: this.t(n.placeholder || ''), 'aria-label': this.t(n.placeholder || 'E-mail')
        });
        var submit = el('button', { type: 'submit', class: 'lmg-match__btn', text: this.t(n.cta || '') });

        var form = el('form', { class: 'lmg-match__signup' }, [
            n.eyebrow ? el('p', { class: 'lmg-match__eyebrow', text: this.t(n.eyebrow) }) : null,
            el('h3', { class: 'lmg-match__cardTitle', text: this.t(n.headline || '') }),
            n.sub ? el('p', { class: 'lmg-match__body', text: this.t(n.sub) }) : null,
            el('div', { class: 'lmg-match__field' }, [input, submit]),
            n.legal ? el('p', { class: 'lmg-match__meta', text: this.t(n.legal) }) : null
        ]);

        form.addEventListener('submit', function (e) {
            e.preventDefault();
            if (!input.value || input.value.indexOf('@') === -1) { input.focus(); return; }
            // The address goes to the ESP through the site's own endpoint.
            // It is never attached to an analytics event — the funnel data stays
            // aggregate, and the mailing list stays separate from it.
            self.emit('signup', { provider: n.provider || null });
            form.replaceChildren(el('p', { class: 'lmg-match__body', text: 'Tak. Tjek din indbakke for at bekræfte.' }));
        });

        return form;
    };

    // --- boot ----------------------------------------------------------------

    function mount(root) {
        var configUrl = root.getAttribute('data-config');
        var contentUrl = root.getAttribute('data-content');
        if (!configUrl) return;

        fetch(configUrl)
            .then(function (r) { return r.json(); })
            .then(function (config) {
                // Page context wins over the config file, so one question set can
                // serve Italy on an Italy page and Spain on a Spanish one.
                var subject = root.getAttribute('data-subject');
                if (subject) config.subject = subject;

                // A bare filename in the config resolves against the CONFIG's location,
                // not the page's — otherwise the same config breaks whenever the page
                // embedding it sits at a different depth.
                var url = contentUrl ||
                    new URL('../content/' + config.content, new URL(configUrl, location.href)).href;

                var w = new Widget(root, config, function () {
                    return fetch(url).then(function (r) { return r.json(); });
                });
                root.lmgMatch = w;                       // handle for the concierge or a console
                window.dispatchEvent(new CustomEvent('lmg-match:ready', { detail: { widget: w } }));
            })
            .catch(function (err) {
                if (window.console) console.error('lmg-match: could not load', err);
                root.textContent = '';
            });
    }

    function init() {
        var nodes = document.querySelectorAll('[data-lmg-match]');
        for (var i = 0; i < nodes.length; i++) mount(nodes[i]);
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();

    window.LMGMatchUI = { Widget: Widget, mount: mount };
}(window, document));
