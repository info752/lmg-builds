(function (w, d) {
    'use strict';
    var C = w.LMG_MATCH_BAR;
    if (!C) return;

    function ls(k, v) {
        try { if (v === undefined) return w.localStorage.getItem(k); w.localStorage.setItem(k, v); } catch (e) { return null; }
    }
    var KEY = 'lmg_match_bar';
    var force = /[?&]lmgbar=1/.test(w.location.search);
    var dlg, card, slot, tab, loaded = false;

    function remember() { ls(KEY, String(Date.now())); }
    function el(tag, cls, html) { var n = d.createElement(tag); n.className = cls; if (html) n.innerHTML = html; return n; }

    function ensureDlg() {
        if (dlg) return;
        dlg = el('div', 'lmg-dlg');
        dlg.setAttribute('role', 'dialog');
        dlg.setAttribute('aria-modal', 'true');
        dlg.addEventListener('click', function (e) { if (e.target === dlg) close(); });
        d.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
        d.body.appendChild(dlg);
    }

    function showCard() {
        ensureDlg();
        remember();
        dlg.textContent = '';
        card = el('div', 'lmg-dlg__card', '<button type="button" class="lmg-dlg__x" aria-label="Luk">&times;</button><p class="lmg-dlg__txt"></p><button type="button" class="lmg-dlg__go"></button>');
        card.querySelector('.lmg-dlg__txt').textContent = C.text;
        card.querySelector('.lmg-dlg__go').textContent = C.button;
        card.querySelector('.lmg-dlg__go').addEventListener('click', openWidget);
        card.querySelector('.lmg-dlg__x').addEventListener('click', close);
        dlg.appendChild(card);
        dlg.classList.add('is-on');
    }

    function loadCss(u) { var l = d.createElement('link'); l.rel = 'stylesheet'; l.href = u; l.setAttribute('data-no-optimize', '1'); d.head.appendChild(l); }
    function loadJs(u, cb) { var s = d.createElement('script'); s.src = u; s.setAttribute('data-no-optimize', '1'); s.onload = cb; d.body.appendChild(s); }

    function openWidget() {
        remember();
        ensureDlg();
        if (!slot) {
            var box = el('div', 'lmg-dlg__box', '<button type="button" class="lmg-dlg__x" aria-label="Luk">&times;</button>');
            box.querySelector('.lmg-dlg__x').addEventListener('click', close);
            slot = el('div', 'lmg-dlg__slot');
            box.appendChild(slot);
            dlg.textContent = '';
            dlg.appendChild(box);
        } else { dlg.textContent = ''; dlg.appendChild(slot.parentNode); }
        dlg.classList.add('is-on');
        if (loaded) return;
        loaded = true;
        loadCss(C.css);
        loadJs(C.engine, function () {
            loadJs(C.ui, function () {
                var n = d.createElement('div');
                n.setAttribute('data-lmg-match', '1');
                n.setAttribute('data-config', C.config);
                if (C.content) n.setAttribute('data-content', C.content);
                n.setAttribute('data-placement', 'popup:' + C.placement);
                slot.appendChild(n);
                w.LMGMatchUI.mount(n);
            });
        });
    }

    function close() { if (dlg) dlg.classList.remove('is-on'); }

    // A link anywhere on the site (a menu item, a button) with the address #find-din-rejse opens the questions.
    d.addEventListener('click', function (e) {
        var a = e.target.closest ? e.target.closest('a[href$="#find-din-rejse"],a.lmg-open') : null;
        if (a) { e.preventDefault(); openWidget(); }
    });
    if (w.location.hash === '#find-din-rejse') openWidget();

    function start() {
        if (!C.show) return;
        // The tab stays for good, so the questions can be found again and taken with another set of interests.
        tab = el('button', 'lmg-tab');
        tab.type = 'button';
        tab.textContent = C.tab;
        tab.addEventListener('click', openWidget);
        d.body.appendChild(tab);

        var seen = parseInt(ls(KEY), 10);
        if (!force && seen && Date.now() - seen < C.cooldownDays * 86400000) return;
        setTimeout(showCard, force ? 500 : C.delay * 1000);
    }
    if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
}(window, document));
