/**
 * lmg-match engine — headless, deterministic, no DOM, no dependencies.
 *
 * Nothing in here knows about Italy, TravelTalk, or a widget. It takes a config,
 * a content map and a set of answers, and returns ranked results with the reason
 * each one matched. That makes it usable three ways from the same code:
 *
 *   1. the widget UI (assets/lmg-match-ui.js)
 *   2. a conversational agent asking the same questions in prose
 *   3. a test or a batch job, in Node or anywhere else
 *
 * Design rule that matters most: SCORE ON POSITIVE EVIDENCE ONLY.
 * A missing facet is not a mismatch. On the TravelTalk Italy corpus, 35 of 96
 * posts carry no facets at all and only 8 carry more than one; penalising absence
 * would hand every result to the handful of richly-tagged posts and bury the rest.
 * An item is scored on the facets it actually has, and ignored on the ones it doesn't.
 */
(function (root, factory) {
    if (typeof module === 'object' && module.exports) module.exports = factory();
    else root.LMGMatch = factory();
}(typeof self !== 'undefined' ? self : this, function () {
    'use strict';

    function asArray(v) {
        if (v === null || v === undefined) return [];
        return Array.isArray(v) ? v : [v];
    }

    function overlap(answerValues, itemValues) {
        var hits = [];
        for (var i = 0; i < answerValues.length; i++) {
            if (itemValues.indexOf(answerValues[i]) !== -1) hits.push(answerValues[i]);
        }
        return hits;
    }

    /**
     * Hard filters. These remove an item from consideration entirely — they are
     * not a scoring penalty. Every one is config, never hard-coded: the editorial
     * rulings they express are the owner's to change, and a rule written into code
     * is a rule nobody can switch off.
     */
    function isExcluded(item, exclusions) {
        if (!exclusions) return false;

        var cats = asArray(item.categories);
        var byCat = asArray(exclusions.categories);
        for (var i = 0; i < byCat.length; i++) {
            if (cats.indexOf(byCat[i]) !== -1) return 'category:' + byCat[i];
        }

        var ids = asArray(exclusions.ids);
        if (ids.indexOf(item.id) !== -1) return 'id';

        var range = exclusions.dateRange;
        if (range && item.date) {
            var year = parseInt(item.date.slice(0, 4), 10);
            if (year >= range.from && year <= range.to) return 'date:' + year;
        }

        return false;
    }

    /**
     * Score one item against the answers.
     * Returns null when nothing matched at all, so callers can tell
     * "no evidence" apart from "scored zero".
     */
    function scoreItem(item, answers, facetWeights, labels, floor) {
        var total = 0, possible = 0, reasons = [], matched = {};

        for (var facet in answers) {
            if (!Object.prototype.hasOwnProperty.call(answers, facet)) continue;

            var chosen = asArray(answers[facet]);
            if (!chosen.length) continue;

            var itemValues = asArray(item.facets && item.facets[facet]);
            if (!itemValues.length) continue;   // no evidence either way — skip, never penalise

            var weight = facetWeights[facet] === undefined ? 1 : facetWeights[facet];
            if (weight <= 0) continue;          // facet collected for learning, not for matching

            var hits = overlap(chosen, itemValues);
            possible += weight;

            if (hits.length) {
                // Share of what the visitor asked for that this item actually covers.
                var share = hits.length / chosen.length;
                total += weight * share;
                matched[facet] = hits;

                for (var h = 0; h < hits.length; h++) {
                    var label = labels[facet] && labels[facet][hits[h]];
                    if (label) reasons.push(label);
                }
            }
        }

        if (!possible) return null;

        // Normalising by `possible` alone would let a post whose ONLY facet is a
        // low-weight one score a perfect 1.0 — a single familieferie tag beating a
        // post that matched two of three chosen interests. The floor is the weight
        // a well-covered item would be judged on (config: results.scoreFloor), so
        // thin evidence can no longer buy a top score.
        var denominator = Math.max(possible, floor || 0);

        return {
            item: item,
            score: total / denominator,   // 0..1, comparable across differing facet coverage
            weightSeen: possible,
            matched: matched,
            reasons: reasons
        };
    }

    /**
     * Deterministic ordering. No randomness anywhere — the same answers must
     * always produce the same result, or the logic cannot be inspected or trusted.
     *
     * score desc → evidence breadth desc → recency desc → id asc
     */
    function compare(a, b) {
        if (b.score !== a.score) return b.score - a.score;
        if (b.weightSeen !== a.weightSeen) return b.weightSeen - a.weightSeen;
        var da = (a.item.date || ''), db = (b.item.date || '');
        if (da !== db) return db < da ? -1 : 1;
        return a.item.id - b.item.id;
    }

    /**
     * Cap how many results may come from the same group (region, by default),
     * so five answers about food don't return five posts about Rome.
     * Overflow is kept in order and used only if the result set is short.
     */
    function diversify(scored, rule) {
        if (!rule || !rule.by) return scored;

        var seen = {}, kept = [], overflow = [];
        var max = rule.max || 2;

        for (var i = 0; i < scored.length; i++) {
            var values = asArray(scored[i].item.facets && scored[i].item.facets[rule.by]);
            var key = values.length ? values[0] : '__ungrouped__';

            // Ungrouped items are not a group — capping them would penalise
            // items merely for having no region detected.
            if (key === '__ungrouped__') { kept.push(scored[i]); continue; }

            seen[key] = (seen[key] || 0) + 1;
            (seen[key] <= max ? kept : overflow).push(scored[i]);
        }

        return kept.concat(overflow);
    }

    /**
     * Main entry point. Pure: same inputs, same output, no side effects.
     *
     *   config  — question set, weights, exclusions, result rules (config/*.json)
     *   items   — content map (content/*.items.json), or its `items` array
     *   answers — { facet: [values] }
     */
    function recommend(config, items, answers) {
        var pool = (items && items.items) ? items.items : asArray(items);
        var rules = config.results || {};
        var weights = config.facetWeights || {};
        var labels = config.matchLabels || {};
        var minScore = rules.minScore === undefined ? 0.01 : rules.minScore;
        var want = rules.count || 4;

        var scored = [], excluded = 0;

        for (var i = 0; i < pool.length; i++) {
            if (isExcluded(pool[i], config.exclusions)) { excluded++; continue; }
            var s = scoreItem(pool[i], answers, weights, labels, rules.scoreFloor);
            if (s && s.score >= minScore) scored.push(s);
        }

        scored.sort(compare);
        scored = diversify(scored, rules.diversify);

        var results = scored.slice(0, want);

        // Honesty rule, inherited from the concierge brief: when we have not
        // covered it, say so rather than padding with weak matches.
        var confident = results.filter(function (r) { return r.score >= (rules.confidentScore || 0.34); });

        return {
            results: results,
            confident: confident.length,
            thin: confident.length < (rules.minConfident || 2),
            poolSize: pool.length,
            excluded: excluded,
            considered: scored.length
        };
    }

    /**
     * Session wrapper for a step-through UI or a conversation.
     * Holds answers, exposes progress, delegates scoring to recommend().
     */
    function createSession(config, items) {
        var answers = {};
        var index = 0;
        var questions = config.questions || [];

        return {
            config: config,
            questions: questions,

            get current() { return questions[index] || null; },
            get index() { return index; },
            get total() { return questions.length; },
            get answers() { return answers; },
            get complete() { return index >= questions.length; },

            answer: function (questionId, values) {
                var q = null;
                for (var i = 0; i < questions.length; i++) {
                    if (questions[i].id === questionId) { q = questions[i]; break; }
                }
                if (!q) throw new Error('lmg-match: unknown question "' + questionId + '"');

                var chosen = asArray(values);
                if (q.max && chosen.length > q.max) chosen = chosen.slice(0, q.max);

                answers[q.facet] = chosen;
                return this;
            },

            goTo: function (i) { index = Math.max(0, Math.min(i, questions.length)); return this; },
            next: function () { index = Math.min(index + 1, questions.length); return this; },
            back: function () { index = Math.max(index - 1, 0); return this; },

            reset: function () { answers = {}; index = 0; return this; },

            recommend: function () { return recommend(config, items, answers); }
        };
    }

    /**
     * Machine-readable description of a question set.
     *
     * This is the handoff surface for a conversational agent. Instead of the
     * widget stepping a visitor through five screens, the agent can ask the same
     * things in prose, collect the answers, and call recommend() with them — the
     * ranking, the exclusions and the reasons stay identical, because it is the
     * same engine. The UI and the concierge are two front doors to one room.
     */
    function describe(config) {
        return {
            id: config.id,
            subject: config.subject || null,
            purpose: config.purpose || '',
            questions: (config.questions || []).map(function (q) {
                return {
                    id: q.id,
                    facet: q.facet,
                    ask: q.title,
                    multiple: !!q.multiple,
                    max: q.max || 1,
                    required: q.required !== false,
                    options: (q.options || []).map(function (o) {
                        return { value: o.value, label: o.label };
                    })
                };
            }),
            call: 'LMGMatch.recommend(config, items, answers) where answers = { facet: [value, ...] }'
        };
    }

    return {
        version: '0.1.0',
        recommend: recommend,
        createSession: createSession,
        describe: describe,
        // exported for tests and for anyone auditing the logic
        _internal: { scoreItem: scoreItem, isExcluded: isExcluded, diversify: diversify, compare: compare }
    };
}));
