<?php
/**
 * Plugin Name: LMG Match
 * Description: Interactive question-and-recommendation layer. Asks a visitor a short, configurable question set and answers with the site's own published content, scored by a transparent deterministic rule engine. Question sets and content maps are JSON files, so a new one is configuration rather than a build. Captures aggregated, consent-gated interest signal — no personal profiling.
 * Version:     0.3.1
 * Author:      LMG
 * License:     GPL-2.0+
 *
 * The matching logic lives in assets/lmg-match-engine.js and is deliberately
 * headless: the widget is one front door to it, a concierge asking the same
 * questions in prose is another. Both call the same engine, so both rank the
 * same way.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// Bump on EVERY asset change. The enqueued URL carries this as ?ver=, so an
// unchanged number means browsers and the CDN keep serving the old file and the
// deploy looks like it did nothing. Cost an hour on 2026-09-05.
define( 'LMG_MATCH_VERSION', '0.3.1' );
define( 'LMG_MATCH_DIR', plugin_dir_path( __FILE__ ) );
define( 'LMG_MATCH_URL', plugin_dir_url( __FILE__ ) );
define( 'LMG_MATCH_TABLE', 'lmg_match_events' );
require_once LMG_MATCH_DIR . 'includes/bar.php';

/** Days to keep raw event rows. Aggregates outlive them; rows do not. */
define( 'LMG_MATCH_RETENTION_DAYS', 90 );

// -----------------------------------------------------------------------------
// Activation — storage
// -----------------------------------------------------------------------------

register_activation_hook( __FILE__, 'lmg_match_activate' );

function lmg_match_activate() {
	global $wpdb;

	$table   = $wpdb->prefix . LMG_MATCH_TABLE;
	$collate = $wpdb->get_charset_collate();

	// No IP, no user agent, no user id, no free text. There is deliberately no
	// column here that could re-identify a visitor: the question this table
	// answers is "what do readers want", never "who asked".
	$sql = "CREATE TABLE {$table} (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		created_at DATETIME NOT NULL,
		config VARCHAR(64) NOT NULL,
		session CHAR(20) NOT NULL,
		event VARCHAR(32) NOT NULL,
		facet VARCHAR(32) DEFAULT NULL,
		payload LONGTEXT DEFAULT NULL,
		PRIMARY KEY (id),
		KEY config_event (config, event),
		KEY created_at (created_at),
		KEY session (session)
	) {$collate};";

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql );

	if ( ! wp_next_scheduled( 'lmg_match_prune' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'lmg_match_prune' );
	}
}

register_deactivation_hook( __FILE__, function () {
	wp_clear_scheduled_hook( 'lmg_match_prune' );
} );

/** Retention is enforced, not promised. */
add_action( 'lmg_match_prune', function () {
	global $wpdb;
	$table = $wpdb->prefix . LMG_MATCH_TABLE;
	$wpdb->query( $wpdb->prepare(
		"DELETE FROM {$table} WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
		LMG_MATCH_RETENTION_DAYS
	) );
} );

// -----------------------------------------------------------------------------
// Assets
// -----------------------------------------------------------------------------

add_action( 'wp_enqueue_scripts', function () {
	// The VERSION IS IN THE FILENAME, and that is deliberate.
	//
	// This stack strips ?ver= from static URLs and serves assets with
	// max-age=31536000 behind the Quic.cloud CDN. So a version bump alone changes
	// nothing: browsers and the CDN keep the old file for a year while the origin
	// quietly holds the new one. Measured 2026-09-05, after exactly that happened.
	//
	// A versioned filename is a new object, so there is nothing to serve stale.
	// It also fails LOUDLY — bump the constant without renaming the files and the
	// asset 404s immediately, instead of silently running last week's code.
	$v = LMG_MATCH_VERSION;

	wp_register_style( 'lmg-match', LMG_MATCH_URL . "assets/lmg-match-{$v}.css", array(), null );

	wp_register_script( 'lmg-match-engine', LMG_MATCH_URL . "assets/lmg-match-engine-{$v}.js", array(), null, true );

	wp_register_script( 'lmg-match-ui', LMG_MATCH_URL . "assets/lmg-match-ui-{$v}.js", array( 'lmg-match-engine' ), null, true );
} );

/**
 * Keep LiteSpeed's combine/UCSS pipeline off these files.
 *
 * The house lesson, learned the hard way on this stack: optimised copies go
 * stale and get stripped, and a widget whose JS is half-combined fails silently.
 * Real enqueued files (not inlined) so they cache across pages, but marked so
 * the optimiser leaves them alone.
 */
add_filter( 'script_loader_tag', function ( $tag, $handle ) {
	if ( strpos( $handle, 'lmg-match' ) === 0 ) {
		$tag = str_replace( '<script ', '<script data-no-optimize="1" ', $tag );
	}
	return $tag;
}, 10, 2 );

add_filter( 'style_loader_tag', function ( $tag, $handle ) {
	if ( strpos( $handle, 'lmg-match' ) === 0 ) {
		$tag = str_replace( '<link ', '<link data-no-optimize="1" ', $tag );
	}
	return $tag;
}, 10, 2 );

// -----------------------------------------------------------------------------
// Shortcode
// -----------------------------------------------------------------------------

/**
 * Sanitise a bare filename.
 *
 * NOT sanitize_file_name(): it mangles multi-dot names, turning
 * "traveltalk-italien.items.json" into "traveltalk-italien.items_.json" — which
 * 404s, and the widget then fails silently with an empty box. Found on the first
 * server-side render, 2026-09-05. Do not "fix" this back.
 */
function lmg_match_safe_file( $name ) {
	$name = basename( (string) $name );
	$name = preg_replace( '/[^A-Za-z0-9._-]/', '', $name );
	return ( $name === '' || strpos( $name, '..' ) !== false ) ? '' : $name;
}

/**
 * Enqueue in the head where possible.
 *
 * A shortcode runs during the_content — after wp_head has already printed — so
 * enqueuing from inside it pushes the stylesheet to the footer and the widget
 * flashes unstyled. Scanning the post for the shortcode here gets the CSS into
 * the head instead. The in-shortcode enqueue stays as a fallback for the cases
 * this misses (widgets, blocks, template calls).
 */
add_action( 'wp_enqueue_scripts', function () {
	if ( ! is_singular() ) return;
	$post = get_post();
	if ( ! $post || ! has_shortcode( $post->post_content, 'lmg_match' ) ) return;
	wp_enqueue_style( 'lmg-match' );
	wp_enqueue_script( 'lmg-match-ui' );
}, 20 );

/**
 * [lmg_match config="traveltalk-italien"]
 *
 * Optional:
 *   subject="Spanien"   override the templated subject
 *   content="…json"     override the content map named in the config
 *
 * Assets are enqueued only where the shortcode actually renders, so a page
 * without the widget carries none of its weight.
 */
add_shortcode( 'lmg_match', function ( $atts ) {
	$atts = shortcode_atts( array(
		'config'  => '',
		'subject' => '',
		'content' => '',
	), $atts, 'lmg_match' );

	$config = sanitize_file_name( $atts['config'] );
	if ( ! $config ) return '';

	$config_path = LMG_MATCH_DIR . 'config/' . $config . '.json';
	if ( ! file_exists( $config_path ) ) {
		return current_user_can( 'edit_posts' )
			? '<p><strong>lmg-match:</strong> ingen konfiguration ved <code>config/' . esc_html( $config ) . '.json</code></p>'
			: '';
	}

	wp_enqueue_style( 'lmg-match' );
	wp_enqueue_script( 'lmg-match-ui' );

	$content = $atts['content'] ? lmg_match_safe_file( $atts['content'] ) : '';

	$attrs = array(
		'data-lmg-match' => '1',
		'data-config'    => LMG_MATCH_URL . 'config/' . $config . '.json',
	);

	if ( $content ) {
		$attrs['data-content'] = LMG_MATCH_URL . 'content/' . $content;
	} else {
		// Resolve the config's own content file to a URL so the browser never
		// has to guess a path relative to the JSON.
		$decoded = json_decode( file_get_contents( $config_path ), true );
		if ( ! empty( $decoded['content'] ) ) {
			$attrs['data-content'] = LMG_MATCH_URL . 'content/' . lmg_match_safe_file( $decoded['content'] );
		}
	}

	if ( $atts['subject'] ) {
		$attrs['data-subject'] = $atts['subject'];
	}

	// Where the widget is sitting, for GA4. Tells us whether the pillar page
	// converts better than an article — which matters as soon as it is on many
	// posts. The post ID is content, not a visitor identifier.
	$host = get_post();
	if ( $host ) {
		$attrs['data-placement'] = $host->post_type . ':' . $host->ID;
	}

	$html = '<div';
	foreach ( $attrs as $key => $value ) {
		$html .= ' ' . $key . '="' . esc_attr( $value ) . '"';
	}
	$html .= '></div>';

	return $html;
} );

// -----------------------------------------------------------------------------
// Event capture
// -----------------------------------------------------------------------------

add_action( 'rest_api_init', function () {
	register_rest_route( 'lmg-match/v1', '/event', array(
		'methods'             => 'POST',
		'callback'            => 'lmg_match_record_event',
		// Public by design: visitors are anonymous and pages are cached, so a
		// nonce would be stale on arrival. The endpoint is write-only, accepts
		// a strict whitelist, and stores nothing free-form.
		'permission_callback' => '__return_true',
	) );
} );

function lmg_match_record_event( WP_REST_Request $request ) {
	global $wpdb;

	$body = $request->get_json_params();
	if ( ! is_array( $body ) ) {
		return new WP_REST_Response( array( 'ok' => false ), 400 );
	}

	$allowed_events = array( 'start', 'answer', 'result', 'click', 'signup' );
	$event = isset( $body['event'] ) ? sanitize_key( $body['event'] ) : '';
	if ( ! in_array( $event, $allowed_events, true ) ) {
		return new WP_REST_Response( array( 'ok' => false ), 400 );
	}

	// Flood control. The transient key is a salted hash of the address, held for
	// a minute and never written to the events table — abuse control only, and
	// it cannot be worked backwards into a visitor record.
	$fingerprint = 'lmg_match_rl_' . substr(
		hash_hmac( 'sha256', lmg_match_remote_addr(), wp_salt( 'auth' ) ), 0, 24
	);
	$hits = (int) get_transient( $fingerprint );
	if ( $hits > 60 ) {
		return new WP_REST_Response( array( 'ok' => false, 'reason' => 'rate' ), 429 );
	}
	set_transient( $fingerprint, $hits + 1, MINUTE_IN_SECONDS );

	$data = isset( $body['data'] ) && is_array( $body['data'] ) ? $body['data'] : array();

	// Whitelist. Anything not named here is dropped rather than stored "just in case".
	$clean = array();
	foreach ( array( 'question', 'facet', 'returned', 'confident', 'thin', 'excluded', 'position', 'score', 'seconds', 'provider' ) as $key ) {
		if ( isset( $data[ $key ] ) && ! is_array( $data[ $key ] ) ) {
			$clean[ $key ] = is_bool( $data[ $key ] ) ? (int) $data[ $key ] : sanitize_text_field( (string) $data[ $key ] );
		}
	}
	if ( isset( $data['values'] ) && is_array( $data['values'] ) ) {
		$clean['values'] = array_slice( array_map( 'sanitize_key', $data['values'] ), 0, 8 );
	}
	if ( isset( $data['ids'] ) && is_array( $data['ids'] ) ) {
		$clean['ids'] = array_slice( array_map( 'absint', $data['ids'] ), 0, 10 );
	}
	if ( isset( $data['answers'] ) && is_array( $data['answers'] ) ) {
		$answers = array();
		foreach ( $data['answers'] as $facet => $values ) {
			if ( ! is_array( $values ) ) continue;
			$answers[ sanitize_key( $facet ) ] = array_slice( array_map( 'sanitize_key', $values ), 0, 8 );
		}
		$clean['answers'] = $answers;
	}
	if ( isset( $data['id'] ) ) {
		$clean['id'] = absint( $data['id'] );
	}

	$wpdb->insert(
		$wpdb->prefix . LMG_MATCH_TABLE,
		array(
			'created_at' => current_time( 'mysql' ),
			'config'     => substr( sanitize_key( isset( $body['config'] ) ? $body['config'] : '' ), 0, 64 ),
			'session'    => substr( sanitize_key( isset( $body['session'] ) ? $body['session'] : '' ), 0, 20 ),
			'event'      => $event,
			'facet'      => isset( $clean['facet'] ) ? substr( $clean['facet'], 0, 32 ) : null,
			'payload'    => wp_json_encode( $clean ),
		),
		array( '%s', '%s', '%s', '%s', '%s', '%s' )
	);

	return new WP_REST_Response( array( 'ok' => true ), 204 );
}

function lmg_match_remote_addr() {
	$keys = array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' );
	foreach ( $keys as $key ) {
		if ( ! empty( $_SERVER[ $key ] ) ) {
			$parts = explode( ',', $_SERVER[ $key ] );
			return trim( $parts[0] );
		}
	}
	return '0.0.0.0';
}

// -----------------------------------------------------------------------------
// Readout — the point of collecting any of this
// -----------------------------------------------------------------------------

add_action( 'admin_menu', function () {
	add_management_page(
		'LMG Match',
		'LMG Match',
		'manage_options',
		'lmg-match',
		'lmg_match_admin_page'
	);
} );

function lmg_match_admin_page() {
	global $wpdb;
	$table = $wpdb->prefix . LMG_MATCH_TABLE;

	$totals = $wpdb->get_results(
		"SELECT event, COUNT(*) AS n, COUNT(DISTINCT session) AS sessions
		 FROM {$table} GROUP BY event", ARRAY_A
	);

	$answers = $wpdb->get_results(
		"SELECT payload FROM {$table} WHERE event = 'answer' ORDER BY id DESC LIMIT 5000",
		ARRAY_A
	);

	$counts = array();
	$pairs  = array();
	foreach ( (array) $answers as $row ) {
		$data = json_decode( $row['payload'], true );
		if ( empty( $data['values'] ) || ! is_array( $data['values'] ) ) continue;
		$facet = isset( $data['facet'] ) ? $data['facet'] : 'ukendt';
		foreach ( $data['values'] as $value ) {
			$key = $facet . ':' . $value;
			$counts[ $key ] = isset( $counts[ $key ] ) ? $counts[ $key ] + 1 : 1;
		}
		// Combinations are the interesting part: what people pair, not just what they pick.
		$values = $data['values'];
		sort( $values );
		for ( $i = 0; $i < count( $values ); $i++ ) {
			for ( $j = $i + 1; $j < count( $values ); $j++ ) {
				$key = $values[ $i ] . ' + ' . $values[ $j ];
				$pairs[ $key ] = isset( $pairs[ $key ] ) ? $pairs[ $key ] + 1 : 1;
			}
		}
	}
	arsort( $counts );
	arsort( $pairs );

	// "We haven't written about that" — the single most valuable output.
	$thin = (int) $wpdb->get_var(
		"SELECT COUNT(*) FROM {$table} WHERE event = 'result' AND payload LIKE '%\"thin\":1%'"
	);
	$results_total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE event = 'result'" );

	echo '<div class="wrap"><h1>LMG Match</h1>';

	echo '<h2>Hændelser</h2><table class="widefat striped" style="max-width:520px"><thead><tr><th>Hændelse</th><th>Antal</th><th>Sessioner</th></tr></thead><tbody>';
	foreach ( (array) $totals as $row ) {
		printf( '<tr><td>%s</td><td>%d</td><td>%d</td></tr>',
			esc_html( $row['event'] ), (int) $row['n'], (int) $row['sessions'] );
	}
	echo '</tbody></table>';

	printf(
		'<h2>Huller i dækningen</h2><p><strong>%d af %d</strong> resultater var tynde — læseren spurgte om noget, vi ikke har skrevet nok om. Det er listen over, hvad der bør skrives.</p>',
		$thin, $results_total
	);

	echo '<h2>Mest valgte</h2><table class="widefat striped" style="max-width:520px"><tbody>';
	$i = 0;
	foreach ( $counts as $key => $n ) {
		if ( $i++ >= 20 ) break;
		printf( '<tr><td>%s</td><td>%d</td></tr>', esc_html( $key ), (int) $n );
	}
	echo '</tbody></table>';

	echo '<h2>Kombinationer</h2><table class="widefat striped" style="max-width:520px"><tbody>';
	$i = 0;
	foreach ( $pairs as $key => $n ) {
		if ( $i++ >= 20 ) break;
		printf( '<tr><td>%s</td><td>%d</td></tr>', esc_html( $key ), (int) $n );
	}
	echo '</tbody></table>';

	echo '<p style="margin-top:2em;color:#666">Ingen IP, ingen user agent, ingen fritekst, intet ID på tværs af sessioner. Rå hændelser slettes efter ' . (int) LMG_MATCH_RETENTION_DAYS . ' dage.</p>';
	echo '</div>';
}
