<?php
/**
 * Plugin Name: TT Travel Destinations Menu
 * Description: traveltalk.travel dropdowns like traveltalk.dk's Rejsemål menu. Activate = build the submenus under Travel Destinations and Travel Interests from the published pages. New pages and English translations are added as they are published. Deactivate = remove them.
 * Version: 1.4
 */

if ( ! defined( 'ABSPATH' ) ) exit;

const TT_TDM_PARENTS = [ 119 => 79, 118 => 84 ]; // menu item ID => page ID

function tt_tdm_menu_id() {
	$t = get_the_terms( 119, 'nav_menu' );
	return ( $t && ! is_wp_error( $t ) ) ? $t[0]->term_id : 0;
}

function tt_tdm_children( $menu_id, $parent_item ) {
	return array_filter( (array) wp_get_nav_menu_items( $menu_id, [ 'post_status' => 'any' ] ), function ( $i ) use ( $parent_item ) {
		return (int) $i->menu_item_parent === (int) $parent_item;
	} );
}

function tt_tdm_add( $menu_id, $page_id, $parent_item, $depth ) {
	foreach ( get_pages( [ 'parent' => $page_id, 'post_status' => 'publish', 'sort_column' => 'post_title' ] ) as $p ) {
		$item = wp_update_nav_menu_item( $menu_id, 0, [
			'menu-item-object-id' => $p->ID,
			'menu-item-object'    => 'page',
			'menu-item-type'      => 'post_type',
			'menu-item-title'     => $p->post_title,
			'menu-item-parent-id' => $parent_item,
			'menu-item-status'    => 'publish',
		] );
		if ( ! is_wp_error( $item ) && $depth < 3 ) tt_tdm_add( $menu_id, $p->ID, $item, $depth + 1 );
	}
}

function tt_tdm_remove( $menu_id, $parent_item ) {
	foreach ( tt_tdm_children( $menu_id, $parent_item ) as $c ) {
		tt_tdm_remove( $menu_id, $c->ID );
		wp_delete_post( $c->ID, true );
	}
}

function tt_tdm_purge() {
	do_action( 'litespeed_purge_all' );
}

register_activation_hook( __FILE__, function () {
	$menu_id = tt_tdm_menu_id();
	if ( ! $menu_id ) return;
	foreach ( TT_TDM_PARENTS as $item => $page ) {
		if ( ! tt_tdm_children( $menu_id, $item ) ) tt_tdm_add( $menu_id, $page, $item, 1 );
	}
	tt_tdm_sync();
	if ( ! wp_next_scheduled( 'tt_tdm_daily' ) ) wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'tt_tdm_daily' );
} );

// 1.1: keep the dropdowns up to date. Only adds; never moves, renames or removes an item.

function tt_tdm_has( $menu_id, $object_id ) {
	foreach ( (array) wp_get_nav_menu_items( $menu_id, [ 'post_status' => 'any' ] ) as $i ) {
		if ( $i->type === 'post_type' && (int) $i->object_id === (int) $object_id ) return true;
	}
	return false;
}

function tt_tdm_new_item( $menu_id, $post, $parent_item ) {
	return wp_update_nav_menu_item( $menu_id, 0, [
		'menu-item-object-id' => $post->ID,
		'menu-item-object'    => $post->post_type,
		'menu-item-type'      => 'post_type',
		'menu-item-title'     => $post->post_title,
		'menu-item-parent-id' => $parent_item,
		'menu-item-status'    => 'publish',
	] );
}

function tt_tdm_sort_key( $title ) {
	return remove_accents( strtolower( preg_replace( '/^the\s+/i', '', trim( wp_strip_all_tags( $title ) ) ) ) );
}

/** A–Z among siblings, reusing their own positions so nothing else in the menu moves. */
function tt_tdm_sort( $menu_id, $parent_item ) {
	$kids = array_values( tt_tdm_children( $menu_id, $parent_item ) );
	$pos  = array_map( function ( $i ) { return (int) $i->menu_order; }, $kids );
	sort( $pos );
	usort( $kids, function ( $a, $b ) { return strcmp( tt_tdm_sort_key( $a->title ), tt_tdm_sort_key( $b->title ) ); } );
	foreach ( $kids as $n => $i ) {
		if ( (int) $i->menu_order !== $pos[ $n ] ) wp_update_post( [ 'ID' => $i->ID, 'menu_order' => $pos[ $n ] ] );
	}
}

function tt_tdm_fill( $menu_id, $page_id, $parent_item, $depth, &$touched ) {
	foreach ( get_pages( [ 'parent' => $page_id, 'post_status' => 'publish', 'sort_column' => 'post_title' ] ) as $p ) {
		$item = 0;
		foreach ( tt_tdm_children( $menu_id, $parent_item ) as $c ) {
			if ( $c->type === 'post_type' && (int) $c->object_id === (int) $p->ID ) $item = (int) $c->ID;
		}
		if ( ! $item && ! tt_tdm_has( $menu_id, $p->ID ) ) {
			$item = tt_tdm_new_item( $menu_id, $p, $parent_item );
			if ( is_wp_error( $item ) ) { tt_tdm_log( $p->ID, 'Not added: ' . $item->get_error_message() ); continue; }
			$touched[ $parent_item ] = true;
			tt_tdm_log( $p->ID, 'Added under ' . tt_tdm_item_title( $parent_item ) );
		}
		if ( $item && $depth < 3 ) tt_tdm_fill( $menu_id, $p->ID, $item, $depth + 1, $touched );
	}
}

/** Menu items under the two dropdowns, by lower-case title, for placing translations by their breadcrumb. */
function tt_tdm_by_title( $menu_id ) {
	$all = (array) wp_get_nav_menu_items( $menu_id, [ 'post_status' => 'any' ] );
	$in  = array_map( 'intval', array_keys( TT_TDM_PARENTS ) );
	$out = [];
	foreach ( $all as $i ) {
		if ( ! in_array( (int) $i->ID, $in, true ) ) continue;
		$out[ strtolower( trim( wp_strip_all_tags( $i->title ) ) ) ] = (int) $i->ID;
		$out[ strtolower( trim( get_the_title( TT_TDM_PARENTS[ (int) $i->ID ] ) ) ) ] = (int) $i->ID;
	}
	for ( $grew = true; $grew; ) {
		$grew = false;
		foreach ( $all as $i ) {
			if ( in_array( (int) $i->menu_item_parent, $in, true ) && ! in_array( (int) $i->ID, $in, true ) ) {
				$in[]   = (int) $i->ID;
				$grew   = true;
				$k      = strtolower( trim( wp_strip_all_tags( $i->title ) ) );
				$out[ $k ] = isset( $out[ $k ] ) ? $out[ $k ] : (int) $i->ID;
			}
		}
	}
	return $out;
}

function tt_tdm_sibling_named( $menu_id, $parent_item, $title, $except ) {
	$want = tt_tdm_sort_key( $title );
	foreach ( tt_tdm_children( $menu_id, $parent_item ) as $c ) {
		if ( (int) $c->ID !== (int) $except && tt_tdm_sort_key( $c->title ) === $want ) return $c;
	}
	return null;
}

/** 1.2, once: take out what 1.1 added by mistake — translations of articles, and a second entry beside one of the same name. */
function tt_tdm_cleanup_11( $menu_id, &$touched ) {
	if ( get_option( 'tt_tdm_cleanup_12' ) ) return;
	foreach ( (array) wp_get_nav_menu_items( $menu_id, [ 'post_status' => 'any' ] ) as $i ) {
		if ( $i->type !== 'post_type' || $i->object !== 'lmgt_translation' ) continue;
		$article = get_post_meta( (int) $i->object_id, '_lmgt_source_type', true ) === 'post';
		$twin    = tt_tdm_sibling_named( $menu_id, (int) $i->menu_item_parent, $i->title, (int) $i->ID );
		if ( ! $article && ! ( $twin && $twin->object !== 'lmgt_translation' ) ) continue;
		tt_tdm_log( (int) $i->object_id, 'Taken out (clean-up of 1.1): ' . ( $article ? 'an article, not a guide' : 'second entry beside "' . $twin->title . '"' ) );
		tt_tdm_remove( $menu_id, (int) $i->ID );
		wp_delete_post( (int) $i->ID, true );
		$touched[ (int) $i->menu_item_parent ] = true;
	}
	update_option( 'tt_tdm_cleanup_12', time(), false );
}

// 1.3: what the last pass did, for Tools → Destinations menu.
function tt_tdm_log( $post_id, $what ) {
	$GLOBALS['tt_tdm_rows'][] = [ (int) $post_id, $what ];
}

function tt_tdm_item_title( $item_id ) {
	$p = get_post( (int) $item_id );
	$t = $p ? wp_strip_all_tags( (string) wp_setup_nav_menu_item( $p )->title ) : '';
	return $t !== '' ? $t : '#' . (int) $item_id;
}

/**
 * 1.4: when the breadcrumb's last name matches no dropdown entry (it can still be in Danish, "Caribien"),
 * follow its link instead: the English translation of that traveltalk.dk page, then the dropdown entry
 * pointing to it, else the entry carrying its title. Returns a key of $titles, or ''.
 */
function tt_tdm_by_link( $menu_id, $step, $titles ) {
	if ( empty( $step['url'] ) || ! class_exists( 'LMGT_Sync' ) || ! method_exists( 'LMGT_Sync', 'member_of' ) ) return '';
	$m = (int) LMGT_Sync::member_of( $step['url'], 'en' );
	if ( ! $m ) return '';
	$ids = array_flip( $titles );
	foreach ( (array) wp_get_nav_menu_items( $menu_id, [ 'post_status' => 'any' ] ) as $i ) {
		if ( (int) $i->object_id === $m && isset( $ids[ (int) $i->ID ] ) ) return $ids[ (int) $i->ID ];
	}
	$t = strtolower( trim( html_entity_decode( get_the_title( $m ), ENT_QUOTES, 'UTF-8' ) ) );
	$parts = preg_split( '/\s+[\x{2014}\x{2013}|-]\s+|:\s+/u', $t, 2 );
	foreach ( array_unique( [ $t, trim( $parts[0] ) ] ) as $c ) if ( $c !== '' && isset( $titles[ $c ] ) ) return $c;
	return '';
}

function tt_tdm_sync() {
	$GLOBALS['tt_tdm_rows'] = [];
	$menu_id = tt_tdm_menu_id();
	if ( ! $menu_id ) {
		update_option( 'tt_tdm_report', [ 'at' => time(), 'error' => 'The main menu (the one holding Travel Destinations) was not found.', 'rows' => [] ], false );
		return;
	}
	$touched = [];
	tt_tdm_cleanup_11( $menu_id, $touched );
	foreach ( TT_TDM_PARENTS as $item => $page ) tt_tdm_fill( $menu_id, $page, $item, 1, $touched );

	// English translations from traveltalk.dk: under the menu item named like the last step of their breadcrumb.
	if ( post_type_exists( 'lmgt_translation' ) ) {
		$titles = tt_tdm_by_title( $menu_id );
		$ids    = get_posts( [ 'post_type' => 'lmgt_translation', 'post_status' => 'publish', 'posts_per_page' => 500, 'fields' => 'ids', 'meta_key' => '_lmgt_lang', 'meta_value' => 'en', 'no_found_rows' => true, 'lmgt_all' => true ] );
		foreach ( $ids as $id ) {
			if ( tt_tdm_has( $menu_id, $id ) ) continue;
			// 1.2: guides (pages on traveltalk.dk) only. Articles are left out without a line in the report.
			if ( get_post_meta( $id, '_lmgt_source_type', true ) !== 'page' ) continue;
			$trail = get_post_meta( $id, '_lmgt_trail', true );
			if ( ! is_array( $trail ) || ! $trail ) { tt_tdm_log( $id, 'Not added: it has no breadcrumb. Re-send it from traveltalk.dk, or add it by hand.' ); continue; }
			$last  = end( $trail );
			$k     = isset( $last['name'] ) ? strtolower( trim( $last['name'] ) ) : '';
			if ( $k === '' || ! isset( $titles[ $k ] ) ) $k = tt_tdm_by_link( $menu_id, $last, $titles );
			if ( $k === '' || ! isset( $titles[ $k ] ) ) { tt_tdm_log( $id, 'Not added: its breadcrumb ends in "' . ( isset( $last['name'] ) ? $last['name'] : '' ) . '", and no dropdown entry has that name.' ); continue; }
			$twin = tt_tdm_sibling_named( $menu_id, $titles[ $k ], get_the_title( $id ), 0 );
			if ( $twin ) { tt_tdm_log( $id, 'Not added: "' . $twin->title . '" is already under ' . tt_tdm_item_title( $titles[ $k ] ) . '.' ); continue; }
			$r = tt_tdm_new_item( $menu_id, get_post( $id ), $titles[ $k ] );
			if ( is_wp_error( $r ) ) { tt_tdm_log( $id, 'Not added: ' . $r->get_error_message() ); continue; }
			$touched[ $titles[ $k ] ] = true;
			tt_tdm_log( $id, 'Added under ' . tt_tdm_item_title( $titles[ $k ] ) );
		}
	}
	foreach ( array_keys( $touched ) as $parent ) tt_tdm_sort( $menu_id, $parent );
	if ( $touched ) tt_tdm_purge();
	update_option( 'tt_tdm_report', [ 'at' => time(), 'rows' => $GLOBALS['tt_tdm_rows'] ], false );
}

add_action( 'tt_tdm_sync', 'tt_tdm_sync' );
// An update uploaded over 1.0 does not run the activation step: start the schedule and a first pass here.
add_action( 'admin_init', function () {
	if ( ! get_option( 'tt_tdm_cleanup_12' ) && ! wp_next_scheduled( 'tt_tdm_sync' ) ) wp_schedule_single_event( time() + 30, 'tt_tdm_sync' );
	if ( wp_next_scheduled( 'tt_tdm_daily' ) ) return;
	wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'tt_tdm_daily' );
	wp_schedule_single_event( time() + 30, 'tt_tdm_sync' );
} );
add_action( 'tt_tdm_daily', 'tt_tdm_sync' );
add_action( 'transition_post_status', function ( $new, $old, $post ) {
	if ( $new === $old || ( $new !== 'publish' && $old !== 'publish' ) ) return;
	if ( ! in_array( $post->post_type, [ 'page', 'lmgt_translation' ], true ) ) return;
	// 1.3: at the end of the same request, so it no longer waits for a visitor to start WordPress' scheduler. The scheduled run stays as a backup.
	if ( empty( $GLOBALS['tt_tdm_due'] ) ) {
		$GLOBALS['tt_tdm_due'] = true;
		add_action( 'shutdown', 'tt_tdm_sync', 20 );
	}
	if ( ! wp_next_scheduled( 'tt_tdm_sync' ) ) wp_schedule_single_event( time() + 300, 'tt_tdm_sync' );
}, 10, 3 );

// 1.3: Tools → Destinations menu.
add_action( 'admin_menu', function () {
	add_management_page( 'Destinations menu', 'Destinations menu', 'edit_theme_options', 'tt-tdm', 'tt_tdm_page' );
} );

add_action( 'admin_post_tt_tdm_sync_now', function () {
	if ( ! current_user_can( 'edit_theme_options' ) ) wp_die( 'Not allowed.' );
	check_admin_referer( 'tt_tdm_sync_now' );
	tt_tdm_sync();
	wp_safe_redirect( admin_url( 'tools.php?page=tt-tdm&done=1' ) );
	exit;
} );

function tt_tdm_page() {
	$data = get_plugin_data( __FILE__, false, false );
	$rep  = get_option( 'tt_tdm_report' );
	$next = wp_next_scheduled( 'tt_tdm_daily' );
	$tz   = function ( $t ) { return $t ? wp_date( 'j M Y H:i', $t ) : 'never'; };
	echo '<div class="wrap"><h1>Destinations menu</h1>';
	if ( ! empty( $_GET['done'] ) ) echo '<div class="notice notice-success"><p>Sync done.</p></div>';
	echo '<p>Version ' . esc_html( $data['Version'] ) . '. Last sync: <strong>' . esc_html( $tz( is_array( $rep ) ? $rep['at'] : 0 ) ) . '</strong>. Next daily check: ' . esc_html( $tz( $next ) ) . '. Clean-up of 1.1 entries: ' . esc_html( get_option( 'tt_tdm_cleanup_12' ) ? 'done ' . $tz( get_option( 'tt_tdm_cleanup_12' ) ) : 'not yet' ) . '.</p>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="tt_tdm_sync_now">';
	wp_nonce_field( 'tt_tdm_sync_now' );
	submit_button( 'Sync now', 'primary', 'submit', false );
	echo '</form>';
	echo '<p class="description">A sync runs by itself when a page or translation is published, and once a day. It only adds entries, A–Z. English versions that still live on traveltalk.dk are not on this site yet: copy them over from traveltalk.dk (Translator → Catch-up, or the traveltalk.travel box on the Danish page), and they are added here.</p>';
	if ( is_array( $rep ) && ! empty( $rep['error'] ) ) echo '<div class="notice notice-error inline"><p>' . esc_html( $rep['error'] ) . '</p></div>';
	$rows = is_array( $rep ) && ! empty( $rep['rows'] ) ? $rep['rows'] : [];
	echo '<h2>Last sync</h2>';
	if ( ! $rows ) {
		echo '<p>Nothing new: everything that can go into the dropdowns is there.</p></div>';
		return;
	}
	echo '<table class="widefat striped"><thead><tr><th>Page</th><th>What happened</th></tr></thead><tbody>';
	foreach ( $rows as $r ) {
		$link = get_edit_post_link( $r[0] );
		echo '<tr><td>' . ( $link ? '<a href="' . esc_url( $link ) . '">' . esc_html( get_the_title( $r[0] ) ) . '</a>' : esc_html( '#' . $r[0] ) ) . '</td><td>' . esc_html( $r[1] ) . '</td></tr>';
	}
	echo '</tbody></table></div>';
}

register_deactivation_hook( __FILE__, function () {
	wp_clear_scheduled_hook( 'tt_tdm_daily' );
	wp_clear_scheduled_hook( 'tt_tdm_sync' );
	$menu_id = tt_tdm_menu_id();
	if ( ! $menu_id ) return;
	foreach ( array_keys( TT_TDM_PARENTS ) as $item ) tt_tdm_remove( $menu_id, $item );
	tt_tdm_purge();
} );

add_action( 'wp_head', function () {
	echo '<style id="tt-travel-destinations-menu">' . file_get_contents( __DIR__ . '/menu.css' ) . '</style>';
}, 99 );
