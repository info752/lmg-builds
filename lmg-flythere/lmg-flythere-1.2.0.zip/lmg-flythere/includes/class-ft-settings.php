<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Site settings: departure airports and box wording. */
class LMGFT_Settings {

	const OPT = 'lmgft_settings';

	public static function boot() {
		add_action( 'admin_menu', function () {
			add_submenu_page( 'lmgft', 'Settings', 'Settings', 'manage_options', 'lmgft-settings', array( __CLASS__, 'page' ) );
		}, 30 );
		add_action( 'admin_post_lmgft_settings', array( __CLASS__, 'save' ) );
	}

	public static function is_travel() {
		return (bool) preg_match( '/\.travel$/i', (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	}

	public static function defaults() {
		if ( self::is_travel() ) {
			return array(
				'departures' => 'LHR, CDG, FRA, AMS, MAD, FCO, MUC, ZRH',
				'h_main'     => 'Travel with … to {land}',
				'g_airline'  => 'Airlines', 'g_rail' => 'Rail', 'g_ferry' => 'Ferries', 'g_bus' => 'Coach',
				'g_cruise'   => 'Cruise lines', 'g_agency' => 'Travel agencies & tour operators', 'g_other' => 'More ways to travel',
				'label'      => 'Partner', 'cta_go' => 'See routes', 'cta_trip' => 'See trips', 'from' => 'From',
			);
		}
		return array(
			'departures' => 'CPH, OSL, ARN, HEL',
			'h_main'     => 'Rejs med … til {land}',
			'g_airline'  => 'Flyselskaber', 'g_rail' => 'Tog', 'g_ferry' => 'Færger', 'g_bus' => 'Bus',
			'g_cruise'   => 'Krydstogt', 'g_agency' => 'Rejsebureauer', 'g_other' => 'Andre måder at rejse på',
			'label'      => 'Partner', 'cta_go' => 'Se ruter', 'cta_trip' => 'Se rejser', 'from' => 'Fra',
		);
	}

	public static function get( $key = null ) {
		$s = wp_parse_args( (array) get_option( self::OPT, array() ), self::defaults() );
		return $key ? ( $s[ $key ] ?? '' ) : $s;
	}

	/** Departure airport codes for this site. LMG Faktabokse may supply them. */
	public static function departures() {
		$own  = array_values( array_filter( array_map( 'strtoupper', array_map( 'trim', explode( ',', self::get( 'departures' ) ) ) ) ) );
		$list = apply_filters( 'lmg_faktabokse_departures', $own );
		return array_values( array_unique( array_map( 'strtoupper', (array) $list ) ) );
	}

	/** Built-in wording for translated pages on traveltalk.travel. */
	public static function words( $lang ) {
		$keys = array( 'h_main', 'g_airline', 'g_rail', 'g_ferry', 'g_bus', 'g_cruise', 'g_agency', 'g_other', 'label', 'cta_go', 'cta_trip', 'from' );
		$w = array(
			'en' => array( 'Travel with … to {land}', 'Airlines', 'Rail', 'Ferries', 'Coach', 'Cruise lines', 'Travel agencies & tour operators', 'More ways to travel', 'Partner', 'See routes', 'See trips', 'From' ),
			'de' => array( 'Reisen mit … nach {land}', 'Fluggesellschaften', 'Bahn', 'Fähren', 'Fernbus', 'Kreuzfahrten', 'Reiseveranstalter', 'Weitere Reisemöglichkeiten', 'Partner', 'Strecken ansehen', 'Reisen ansehen', 'Ab' ),
			'fr' => array( 'Voyager avec … en {land}', 'Compagnies aériennes', 'Train', 'Ferries', 'Autocar', 'Croisières', 'Agences et voyagistes', 'Autres façons de voyager', 'Partenaire', 'Voir les liaisons', 'Voir les voyages', 'Depuis' ),
			'es' => array( 'Viaja con … a {land}', 'Aerolíneas', 'Tren', 'Ferris', 'Autobús', 'Cruceros', 'Agencias y turoperadores', 'Otras formas de viajar', 'Socio', 'Ver rutas', 'Ver viajes', 'Desde' ),
			'it' => array( 'Viaggia con … in {land}', 'Compagnie aeree', 'Treno', 'Traghetti', 'Autobus', 'Crociere', 'Agenzie e tour operator', 'Altri modi di viaggiare', 'Partner', 'Vedi le rotte', 'Vedi i viaggi', 'Da' ),
			'pt' => array( 'Viaje com … para {land}', 'Companhias aéreas', 'Comboio', 'Ferries', 'Autocarro', 'Cruzeiros', 'Agências e operadores', 'Outras formas de viajar', 'Parceiro', 'Ver rotas', 'Ver viagens', 'De' ),
			'sv' => array( 'Res med … till {land}', 'Flygbolag', 'Tåg', 'Färjor', 'Buss', 'Kryssningar', 'Resebyråer', 'Fler sätt att resa', 'Partner', 'Se rutter', 'Se resor', 'Från' ),
			'no' => array( 'Reis med … til {land}', 'Flyselskaper', 'Tog', 'Ferger', 'Buss', 'Cruise', 'Reisebyråer', 'Flere måter å reise på', 'Partner', 'Se ruter', 'Se reiser', 'Fra' ),
			'fi' => array( 'Matkusta … kohteeseen {land}', 'Lentoyhtiöt', 'Juna', 'Lautat', 'Bussi', 'Risteilyt', 'Matkatoimistot', 'Muita tapoja matkustaa', 'Kumppani', 'Katso reitit', 'Katso matkat', 'Lähtö' ),
			'da' => array( 'Rejs med … til {land}', 'Flyselskaber', 'Tog', 'Færger', 'Bus', 'Krydstogt', 'Rejsebureauer', 'Andre måder at rejse på', 'Partner', 'Se ruter', 'Se rejser', 'Fra' ),
		);
		$w['nb'] = $w['no'];
		if ( $lang && isset( $w[ $lang ] ) ) return array_combine( $keys, $w[ $lang ] );
		$s = self::get();
		$o = array();
		foreach ( $keys as $k ) $o[ $k ] = $s[ $k ];
		return $o;
	}

	public static function page() {
		$s = self::get();
		$f = array(
			'departures' => 'Departure airports on this site (comma separated airport codes)',
			'h_main'     => 'Box heading ({land} becomes the country)',
			'g_airline'  => 'Group: airlines',
			'g_rail'     => 'Group: rail',
			'g_ferry'    => 'Group: ferries',
			'g_bus'      => 'Group: coach / bus',
			'g_cruise'   => 'Group: cruise lines',
			'g_agency'   => 'Group: travel agencies',
			'g_other'    => 'Group: other (car hire etc.)',
			'label'      => 'Label on paid lines',
			'cta_go'     => 'Button text: airlines, rail, ferries, coach',
			'cta_trip'   => 'Button text: cruise lines, agencies, other',
			'from'       => 'Word before departure airports',
		);
		echo '<div class="wrap"><h1>Fly There settings</h1>';
		if ( isset( $_GET['saved'] ) ) echo '<div class="notice notice-success"><p>Saved.</p></div>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="lmgft_settings">';
		wp_nonce_field( 'lmgft_settings' );
		echo '<table class="form-table">';
		foreach ( $f as $k => $label ) {
			echo '<tr><th><label for="lmgft-' . esc_attr( $k ) . '">' . esc_html( $label ) . '</label></th><td><input class="regular-text" id="lmgft-' . esc_attr( $k ) . '" name="s[' . esc_attr( $k ) . ']" value="' . esc_attr( $s[ $k ] ) . '"></td></tr>';
		}
		echo '</table><p class="description">This wording is used on pages in the site\'s own language. Translated pages on traveltalk.travel use built-in wording in their language.</p>';
		$fb = apply_filters( 'lmg_faktabokse_departures', null );
		if ( is_array( $fb ) ) echo '<p class="description">LMG Faktabokse is active and supplies the departure airports: ' . esc_html( implode( ', ', $fb ) ) . '.</p>';
		submit_button();
		echo '</form></div>';
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'No access' );
		check_admin_referer( 'lmgft_settings' );
		$in  = isset( $_POST['s'] ) ? (array) wp_unslash( $_POST['s'] ) : array();
		$out = array();
		foreach ( array_keys( self::defaults() ) as $k ) $out[ $k ] = sanitize_text_field( $in[ $k ] ?? '' );
		update_option( self::OPT, $out );
		wp_safe_redirect( admin_url( 'admin.php?page=lmgft-settings&saved=1' ) );
		exit;
	}
}
