<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Fly There → Import list: partner list (CSV) to Fly There cards. Nothing is shown in the box by an import. */
class LMGFT_Import {

	public static function boot() {
		add_action( 'admin_menu', function () {
			add_submenu_page( 'lmgft', 'Import list', 'Import list', 'edit_others_posts', 'lmgft-import', array( __CLASS__, 'page' ) );
		}, 25 );
		add_action( 'admin_post_lmgft_import', array( __CLASS__, 'run' ) );
	}

	private static function host() {
		return preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) );
	}

	public static function page() {
		echo '<div class="wrap"><h1>Import partner list</h1>';
		$r = get_transient( 'lmgft_import_' . get_current_user_id() );
		if ( $r ) {
			delete_transient( 'lmgft_import_' . get_current_user_id() );
			echo '<div class="notice notice-' . ( $r['error'] ? 'error' : 'success' ) . '"><p>' . esc_html( $r['error'] ?: sprintf( 'New cards: %d. Existing cards filled in: %d. Rows for another site, skipped: %d. Rows without a name, skipped: %d.', $r['new'], $r['upd'], $r['site'], $r['bad'] ) ) . '</p></div>';
		}
		echo '<p>Upload the "Rejs med" list for this site (a CSV file). Each row becomes a partner card with type, website and a note in the contact log. <strong>Nothing appears in the box</strong>: every imported card starts on ladder step 0 without "Show in the box". Carriers that have stopped flying come in as Declined and never show.</p>';
		echo '<p>Rows are matched to existing cards by name, so you can import the same list again later. An existing card only gets fields that are empty on it; nothing you have written is overwritten.</p>';
		echo '<p>This site is <strong>' . esc_html( self::host() ) . '</strong>. Only rows whose "site" column says this site are imported.</p>';
		echo '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="lmgft_import">';
		wp_nonce_field( 'lmgft_import' );
		echo '<p><input type="file" name="csv" accept=".csv,text/csv" required></p>';
		submit_button( 'Import' );
		echo '</form></div>';
	}

	public static function run() {
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_die( 'No access' );
		check_admin_referer( 'lmgft_import' );
		$res = array( 'new' => 0, 'upd' => 0, 'site' => 0, 'bad' => 0, 'error' => '' );
		$f   = $_FILES['csv']['tmp_name'] ?? '';
		if ( ! $f || ! is_uploaded_file( $f ) ) {
			$res['error'] = 'No file received.';
		} else {
			$res = self::import_file( $f, $res );
		}
		set_transient( 'lmgft_import_' . get_current_user_id(), $res, 300 );
		wp_safe_redirect( admin_url( 'admin.php?page=lmgft-import' ) );
		exit;
	}

	/** Also used by tests. */
	public static function import_file( $file, $res = null ) {
		$res   = $res ?: array( 'new' => 0, 'upd' => 0, 'site' => 0, 'bad' => 0, 'error' => '' );
		$h     = fopen( $file, 'r' );
		$first = $h ? fgets( $h ) : false;
		if ( ! $first ) { $res['error'] = 'The file is empty.'; return $res; }
		$head = array_map( 'trim', str_getcsv( preg_replace( '/^\xEF\xBB\xBF/', '', $first ) ) );
		if ( ! in_array( 'name', $head, true ) || ! in_array( 'ft_kind', $head, true ) ) { $res['error'] = 'This does not look like the partner list: the columns "name" and "ft_kind" are missing.'; fclose( $h ); return $res; }
		$host  = self::host();
		$kinds = LMGFT_Partners::kinds();
		$user  = wp_get_current_user()->display_name ?: 'Import';
		while ( ( $row = fgetcsv( $h ) ) !== false ) {
			if ( count( $row ) < count( $head ) ) $row = array_pad( $row, count( $head ), '' );
			$r = array_combine( $head, array_slice( $row, 0, count( $head ) ) );
			$name = trim( (string) $r['name'] );
			if ( $name === '' ) { $res['bad']++; continue; }
			$site = preg_replace( '/^www\./', '', strtolower( trim( (string) ( $r['site'] ?? '' ) ) ) );
			if ( $site !== '' && $site !== $host ) { $res['site']++; continue; }
			$kind = isset( $kinds[ $r['ft_kind'] ?? '' ] ) ? $r['ft_kind'] : ( isset( $kinds[ $r['ft_kind_fallback'] ?? '' ] ) ? $r['ft_kind_fallback'] : 'other' );
			$status = in_array( $r['status'] ?? '', array_keys( LMGFT_Partners::statuses() ), true ) ? $r['status'] : 'prospect';
			$id   = self::find( $name );
			$isnew = ! $id;
			if ( $isnew ) {
				$id = wp_insert_post( array( 'post_type' => LMGFT_Partners::PT, 'post_title' => sanitize_text_field( $name ), 'post_status' => 'publish' ), true );
				if ( is_wp_error( $id ) ) { $res['bad']++; continue; }
			}
			$set = function ( $k, $v ) use ( $id, $isnew ) {
				if ( $isnew || (string) get_post_meta( $id, '_ft_' . $k, true ) === '' ) update_post_meta( $id, '_ft_' . $k, $v );
			};
			$set( 'kind', $kind );
			$set( 'website', esc_url_raw( (string) ( $r['website'] ?? '' ) ) );
			if ( $isnew ) {
				update_post_meta( $id, '_ft_status', $status );
				update_post_meta( $id, '_ft_ladder', 0 );
				update_post_meta( $id, '_ft_show', '' );
			} elseif ( $status === 'declined' ) {
				update_post_meta( $id, '_ft_status', 'declined' );
				update_post_meta( $id, '_ft_show', '' );
			}
			foreach ( array( 'subgroup', 'hub_base', 'alliance', 'status_2026' ) as $k ) {
				if ( ! empty( $r[ $k ] ) ) $set( $k, sanitize_text_field( $r[ $k ] ) );
			}
			if ( $isnew ) {
				$bits = array_filter( array(
					'Imported from the partner list (' . ( $r['group'] ?? '' ) . ( ! empty( $r['subgroup'] ) ? ', ' . $r['subgroup'] : '' ) . ').',
					! empty( $r['hub_base'] ) ? 'Hub/base: ' . $r['hub_base'] . ' (not checked departures).' : '',
					! empty( $r['alliance'] ) ? 'Alliance: ' . $r['alliance'] . '.' : '',
					! empty( $r['status_2026'] ) && $r['status_2026'] !== 'active' ? 'Status 2026: ' . $r['status_2026'] . '.' : '',
					! empty( $r['note'] ) ? $r['note'] : '',
					( $r['check_routes'] ?? '' ) === 'yes' ? 'Check routes before pitching.' : '',
				) );
				update_post_meta( $id, '_ft_log', array( array( 'd' => current_time( 'Y-m-d H:i' ), 'u' => $user, 't' => sanitize_textarea_field( implode( ' ', $bits ) ) ) ) );
				$res['new']++;
			} else {
				$res['upd']++;
			}
		}
		fclose( $h );
		return $res;
	}

	private static function find( $name ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type = %s AND post_status NOT IN ('trash','auto-draft') AND LOWER(post_title) = LOWER(%s) LIMIT 1", LMGFT_Partners::PT, $name ) );
	}
}
