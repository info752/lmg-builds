<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Fly There → Report: pipeline overview, monthly numbers, partner report, CSV. */
class LMGFT_Report {

	public static function boot() {
		add_action( 'admin_post_lmgft_csv', array( __CLASS__, 'csv' ) );
	}

	private static function month() {
		$m = isset( $_GET['m'] ) ? sanitize_text_field( wp_unslash( $_GET['m'] ) ) : current_time( 'Y-m' );
		if ( ! preg_match( '/^\d{4}-\d{2}$/', $m ) ) $m = current_time( 'Y-m' );
		return array( $m, $m . '-01', gmdate( 'Y-m-t', strtotime( $m . '-01' ) ) );
	}

	private static function ctr( $v, $c ) {
		return $v ? round( 100 * $c / $v, 1 ) . ' %' : '–';
	}

	public static function page() {
		if ( ! current_user_can( 'edit_others_posts' ) ) return;
		list( $m, $from, $to ) = self::month();
		$partner = isset( $_GET['partner'] ) ? (int) $_GET['partner'] : 0;
		if ( $partner && get_post_type( $partner ) === LMGFT_Partners::PT ) { self::partner( $partner, $m, $from, $to ); return; }

		echo '<div class="wrap"><h1>Fly There</h1>';
		self::pipeline();
		echo '<h2>Numbers for ' . esc_html( date_i18n( 'F Y', strtotime( $from ) ) ) . '</h2>';
		self::month_form( $m );
		$rows = LMGFT_Stats::by( 'partner_id', $from, $to );
		if ( ! $rows ) {
			echo '<p>No views or clicks counted this month yet. Views are counted when a visitor has the box on screen for one second; your own visits while logged in are not counted.</p>';
		} else {
			echo '<table class="widefat striped" style="max-width:900px"><thead><tr><th>Partner</th><th>Type</th><th>Ladder</th><th>Views</th><th>Clicks</th><th>Click rate</th><th></th></tr></thead><tbody>';
			foreach ( $rows as $r ) {
				$id = (int) $r['k'];
				echo '<tr><td>' . esc_html( get_the_title( $id ) ?: '#' . $id ) . '</td><td>' . esc_html( LMGFT_Partners::kinds()[ LMGFT_Partners::meta( $id, 'kind' ) ] ?? '' ) . '</td><td>' . esc_html( LMGFT_Partners::ladder()[ (int) LMGFT_Partners::meta( $id, 'ladder' ) ] ?? '' ) . '</td><td>' . (int) $r['views'] . '</td><td>' . (int) $r['clicks'] . '</td><td>' . esc_html( self::ctr( $r['views'], $r['clicks'] ) ) . '</td><td><a href="' . esc_url( admin_url( 'admin.php?page=lmgft&partner=' . $id . '&m=' . $m ) ) . '">Partner report</a></td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '<p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=lmgft_csv&m=' . $m ), 'lmgft_csv' ) ) . '">Download CSV for the month</a></p>';
		self::by_tables( $from, $to, 0 );
		echo '</div>';
	}

	private static function month_form( $m ) {
		echo '<form method="get" style="margin:8px 0 16px"><input type="hidden" name="page" value="lmgft">';
		if ( ! empty( $_GET['partner'] ) ) echo '<input type="hidden" name="partner" value="' . (int) $_GET['partner'] . '">';
		echo '<input type="month" name="m" value="' . esc_attr( $m ) . '"> <button class="button">Show</button></form>';
	}

	private static function pipeline() {
		$ids = get_posts( array( 'post_type' => LMGFT_Partners::PT, 'post_status' => array( 'publish', 'draft' ), 'posts_per_page' => -1, 'fields' => 'ids' ) );
		$st  = array_fill_keys( array_keys( LMGFT_Partners::statuses() ), 0 );
		$ld  = array_fill_keys( array_keys( LMGFT_Partners::ladder() ), 0 );
		$due = array();
		$today = current_time( 'Y-m-d' );
		foreach ( $ids as $id ) {
			$s = LMGFT_Partners::meta( $id, 'status' ) ?: 'prospect';
			if ( isset( $st[ $s ] ) ) $st[ $s ]++;
			$l = (int) LMGFT_Partners::meta( $id, 'ladder' );
			if ( isset( $ld[ $l ] ) ) $ld[ $l ]++;
			$d = LMGFT_Partners::meta( $id, 'next_date' );
			if ( $d && $d <= gmdate( 'Y-m-d', strtotime( $today . ' +7 days' ) ) && ! in_array( $s, array( 'declined', 'paused' ), true ) ) $due[ $id ] = $d;
		}
		asort( $due );
		echo '<h2>Pipeline</h2><p>';
		foreach ( LMGFT_Partners::statuses() as $k => $l ) echo '<a style="margin-right:14px" href="' . esc_url( admin_url( 'edit.php?post_type=' . LMGFT_Partners::PT . '&ft_status=' . $k ) ) . '">' . esc_html( $l ) . ': <strong>' . (int) $st[ $k ] . '</strong></a>';
		echo '</p><p>';
		foreach ( LMGFT_Partners::ladder() as $k => $l ) echo '<span style="margin-right:14px">' . esc_html( $l ) . ': <strong>' . (int) $ld[ $k ] . '</strong></span>';
		echo '</p><p><a class="button button-primary" href="' . esc_url( admin_url( 'post-new.php?post_type=' . LMGFT_Partners::PT ) ) . '">Add partner</a> <a class="button" href="' . esc_url( admin_url( 'edit.php?post_type=' . LMGFT_Partners::PT ) ) . '">All partners</a></p>';
		if ( $due ) {
			echo '<h3>Next steps due within 7 days</h3><ul>';
			foreach ( $due as $id => $d ) {
				echo '<li style="' . ( $d < $today ? 'color:#b32d2e' : '' ) . '"><strong>' . esc_html( $d ) . '</strong> · <a href="' . esc_url( get_edit_post_link( $id ) ) . '">' . esc_html( get_the_title( $id ) ) . '</a> · ' . esc_html( LMGFT_Partners::meta( $id, 'next_action' ) ) . '</li>';
			}
			echo '</ul>';
		}
	}

	private static function by_tables( $from, $to, $partner ) {
		$langs = LMGFT_Stats::by( 'lang', $from, $to, $partner );
		$cs    = LMGFT_Stats::by( 'country', $from, $to, $partner );
		echo '<div style="display:flex;gap:24px;flex-wrap:wrap;max-width:900px">';
		foreach ( array( 'Country' => $cs, 'Language' => $langs ) as $title => $rows ) {
			if ( ! $rows ) continue;
			echo '<table class="widefat striped" style="flex:1;min-width:280px"><thead><tr><th>' . esc_html( $title ) . '</th><th>Views</th><th>Clicks</th><th>Click rate</th></tr></thead><tbody>';
			foreach ( $rows as $r ) echo '<tr><td>' . esc_html( $title === 'Country' ? LMGFT_Box::country_name( $r['k'] ) : strtoupper( $r['k'] ) ) . '</td><td>' . (int) $r['views'] . '</td><td>' . (int) $r['clicks'] . '</td><td>' . esc_html( self::ctr( $r['views'], $r['clicks'] ) ) . '</td></tr>';
			echo '</tbody></table>';
		}
		echo '</div>';
	}

	private static function partner( $id, $m, $from, $to ) {
		$t   = LMGFT_Stats::totals( $id, $from, $to );
		$fee = LMGFT_Partners::meta( $id, 'price' );
		echo '<div class="wrap lmgft-report" style="max-width:900px"><p class="hide-print"><a href="' . esc_url( admin_url( 'admin.php?page=lmgft&m=' . $m ) ) . '">← All partners</a></p>';
		echo '<h1>' . esc_html( get_the_title( $id ) ) . ' on ' . esc_html( wp_parse_url( home_url(), PHP_URL_HOST ) ) . '</h1>';
		echo '<p>' . esc_html( date_i18n( 'F Y', strtotime( $from ) ) ) . ' · countries: ' . esc_html( LMGFT_Partners::meta( $id, 'countries' ) ) . '</p>';
		echo '<div class="hide-print">';
		self::month_form( $m );
		echo '</div>';
		echo '<table class="widefat" style="max-width:500px;font-size:15px"><tbody><tr><th>Views of your line</th><td><strong>' . (int) $t['views'] . '</strong></td></tr><tr><th>Clicks to your site</th><td><strong>' . (int) $t['clicks'] . '</strong></td></tr><tr><th>Click rate</th><td><strong>' . esc_html( self::ctr( $t['views'], $t['clicks'] ) ) . '</strong></td></tr>';
		if ( $fee ) echo '<tr><th>Agreed price</th><td>' . esc_html( $fee ) . '</td></tr>';
		echo '</tbody></table><p style="max-width:640px">A view is counted when a reader has your line on screen for at least one second. A click is counted when a reader follows your link; your own statistics see these visits as utm_campaign=flythere. Search engines, bots and our own staff are not counted.</p>';
		self::by_tables( $from, $to, $id );
		echo '<p class="hide-print"><button class="button" onclick="window.print()">Print or save as PDF</button></p></div>';
		echo '<style>@media print{#adminmenumain,#wpadminbar,#wpfooter,.hide-print,.notice{display:none!important}#wpcontent{margin:0!important}}</style>';
	}

	public static function csv() {
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_die( 'No access' );
		check_admin_referer( 'lmgft_csv' );
		list( $m, $from, $to ) = self::month();
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT day, partner_id, country, lang, views, clicks FROM ' . LMGFT_Stats::table() . ' WHERE day BETWEEN %s AND %s ORDER BY day, partner_id', $from, $to ), ARRAY_A );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="flythere-' . $m . '.csv"' );
		$o = fopen( 'php://output', 'w' );
		fputcsv( $o, array( 'day', 'partner', 'country', 'language', 'views', 'clicks' ) );
		foreach ( (array) $rows as $r ) fputcsv( $o, array( $r['day'], get_the_title( $r['partner_id'] ), $r['country'], $r['lang'], $r['views'], $r['clicks'] ) );
		fclose( $o );
		exit;
	}
}
