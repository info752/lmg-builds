<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** The partner box under "Sådan kommer du til [land]" on country pages. */
class LMGFT_Box {

	private static $done = array();

	public static function boot() {
		add_action( 'lmg_faktabokse_after_getting_there', function ( $country, $post_id = 0 ) {
			echo self::render( $country );
		}, 10, 2 );
		add_shortcode( 'lmg_flythere', function ( $a ) {
			$a = shortcode_atts( array( 'country' => '' ), $a );
			return self::render( $a['country'] );
		} );
	}

	public static function lang() {
		if ( class_exists( 'LMGT_Front' ) && method_exists( 'LMGT_Front', 'current_lang' ) ) {
			$l = LMGT_Front::current_lang();
			if ( $l ) return $l;
		}
		return substr( get_locale(), 0, 2 );
	}

	public static function country_name( $slug ) {
		$t = get_term_by( 'slug', $slug, 'category' );
		return apply_filters( 'lmg_flythere_country_name', $t ? $t->name : ucfirst( str_replace( '-', ' ', $slug ) ), $slug, self::lang() );
	}

	public static function render( $country ) {
		$country = sanitize_title( (string) $country );
		if ( $country === '' || isset( self::$done[ $country ] ) ) return '';
		$ids = LMGFT_Partners::for_country( $country );
		if ( ! $ids ) return '';
		self::$done[ $country ] = true;
		$lang  = self::lang();
		$w     = LMGFT_Settings::words( self::translated() ? $lang : '' );
		$name  = self::country_name( $country );
		$group = array_fill_keys( LMGFT_Partners::box_kinds(), array() );
		foreach ( $ids as $id ) {
			$k = LMGFT_Partners::meta( $id, 'kind' );
			if ( isset( $group[ $k ] ) ) $group[ $k ][] = $id;
		}
		$group = array_filter( $group );
		if ( ! $group ) return '';
		self::assets();
		$all = array_merge( ...array_values( $group ) );
		$h   = '<aside class="lmg-ft" data-c="' . esc_attr( $country ) . '" data-l="' . esc_attr( $lang ) . '" data-p="' . esc_attr( implode( ',', $all ) ) . '">';
		$h  .= '<h3 class="lmg-ft-h">' . esc_html( str_replace( '{land}', $name, $w['h_main'] ) ) . '</h3>';
		foreach ( $group as $kind => $list ) {
			$h .= '<h4 class="lmg-ft-g">' . esc_html( $w[ 'g_' . $kind ] ) . '</h4><ul class="lmg-ft-list">';
			foreach ( $list as $id ) $h .= self::item( $id, $kind, $country, $lang, $w );
			$h .= '</ul>';
		}
		return $h . '</aside>';
	}

	private static function translated() {
		return class_exists( 'LMGT_Front' ) && method_exists( 'LMGT_Front', 'current_lang' ) && LMGT_Front::current_lang();
	}

	private static function item( $id, $kind, $country, $lang, $w ) {
		$paid = LMGFT_Partners::is_paid( $id );
		$url  = LMGFT_Partners::meta( $id, 'link_url' );
		$line = LMGFT_Partners::meta( $id, 'line' );
		$deps = (array) ( LMGFT_Partners::meta( $id, 'departures' ) ?: array() );
		$h    = '<li class="lmg-ft-item' . ( $paid ? ' is-paid' : '' ) . '">';
		if ( $paid && has_post_thumbnail( $id ) ) $h .= '<span class="lmg-ft-logo">' . get_the_post_thumbnail( $id, 'thumbnail', array( 'alt' => get_the_title( $id ), 'loading' => 'lazy' ) ) . '</span>';
		$h .= '<span class="lmg-ft-txt"><strong>' . esc_html( get_the_title( $id ) ) . '</strong>';
		if ( $paid ) $h .= ' <span class="lmg-ft-label">' . esc_html( $w['label'] ) . '</span>';
		if ( $line ) $h .= '<span class="lmg-ft-line">' . esc_html( $line ) . '</span>';
		if ( $deps ) $h .= '<span class="lmg-ft-from">' . esc_html( $w['from'] . ' ' . implode( ', ', $deps ) ) . '</span>';
		$h .= '</span>';
		if ( $url ) {
			$rel = $paid ? 'sponsored nofollow noopener' : 'nofollow noopener';
			$h  .= '<a class="lmg-ft-cta" href="' . esc_url( LMGFT_Stats::link( $id, $country, $lang ) ) . '" rel="' . $rel . '" target="_blank">' . esc_html( in_array( $kind, array( 'airline', 'rail', 'ferry', 'bus' ), true ) ? $w['cta_go'] : $w['cta_trip'] ) . '</a>';
		}
		return $h . '</li>';
	}

	private static function assets() {
		wp_enqueue_style( 'lmg-ft', LMGFT_URL . 'assets/ft.css', array(), LMGFT_VERSION );
		wp_enqueue_script( 'lmg-ft', LMGFT_URL . 'assets/ft.js', array(), LMGFT_VERSION, true );
		wp_localize_script( 'lmg-ft', 'lmgFt', array( 'u' => esc_url_raw( rest_url( 'lmg-ft/v1/seen' ) ) ) );
	}
}
