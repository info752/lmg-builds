<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Partners: the contact record, the ladder, and what shows in the box. */
class LMGFT_Partners {

	const PT = 'lmg_ft_partner';

	public static function kinds() {
		return array(
			'airline' => 'Airline',
			'rail'    => 'Rail',
			'cruise'  => 'Cruise line',
			'ferry'   => 'Ferry',
			'bus'     => 'Coach / bus',
			'agency'  => 'Travel agency / tour operator',
			'other'   => 'Other (car hire etc.)',
			'tourist' => 'Tourist office (contact only)',
		);
	}

	/** Kinds shown in the box, in the box's order. Tourist offices are contacts only. */
	public static function box_kinds() {
		return array( 'airline', 'rail', 'ferry', 'bus', 'cruise', 'agency', 'other' );
	}

	public static function ladder() {
		return array(
			0 => '0 Listed (free)',
			1 => '1 Media contact (free)',
			2 => '2 Founding partner (pilot)',
			3 => '3 Campaign',
			4 => '4 Annual',
		);
	}

	public static function statuses() {
		return array(
			'prospect'  => 'Prospect',
			'contacted' => 'Contacted',
			'replied'   => 'Replied',
			'meeting'   => 'Meeting / proposal',
			'active'    => 'Active',
			'paused'    => 'Paused',
			'declined'  => 'Declined',
		);
	}

	public static function fields() {
		return array( 'kind', 'ladder', 'status', 'contact_name', 'contact_role', 'contact_email', 'contact_phone', 'website', 'next_action', 'next_date', 'countries', 'departures', 'link_url', 'line', 'show', 'start', 'end', 'price', 'lr_org' );
	}

	public static function boot() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'add_meta_boxes_' . self::PT, array( __CLASS__, 'boxes' ) );
		add_action( 'save_post_' . self::PT, array( __CLASS__, 'save' ), 10, 2 );
		add_filter( 'manage_' . self::PT . '_posts_columns', array( __CLASS__, 'columns' ) );
		add_action( 'manage_' . self::PT . '_posts_custom_column', array( __CLASS__, 'column' ), 10, 2 );
		add_filter( 'manage_edit-' . self::PT . '_sortable_columns', function ( $c ) { $c['ft_next'] = 'ft_next'; $c['ft_ladder'] = 'ft_ladder'; return $c; } );
		add_action( 'pre_get_posts', array( __CLASS__, 'list_query' ) );
		add_action( 'restrict_manage_posts', array( __CLASS__, 'filters' ) );
		add_filter( 'enter_title_here', function ( $t, $p ) { return $p->post_type === self::PT ? 'Company name, e.g. Finnair' : $t; }, 10, 2 );
	}

	public static function register() {
		register_post_type( self::PT, array(
			'labels'       => array( 'name' => 'Partners', 'singular_name' => 'Partner', 'add_new_item' => 'Add partner', 'edit_item' => 'Edit partner', 'all_items' => 'Partners', 'featured_image' => 'Logo', 'set_featured_image' => 'Set logo' ),
			'public'       => false,
			'show_ui'      => true,
			'show_in_menu' => 'lmgft',
			'supports'     => array( 'title', 'thumbnail' ),
			'capability_type' => 'post',
			'map_meta_cap' => true,
		) );
	}

	public static function meta( $id, $k ) {
		return get_post_meta( $id, '_ft_' . $k, true );
	}

	public static function boxes() {
		add_meta_box( 'ft_contact', 'Contact and ladder', array( __CLASS__, 'box_contact' ), self::PT, 'normal', 'high' );
		add_meta_box( 'ft_place', 'In the box on country pages', array( __CLASS__, 'box_place' ), self::PT, 'normal' );
		add_meta_box( 'ft_log', 'Contact log', array( __CLASS__, 'box_log' ), self::PT, 'normal' );
		add_meta_box( 'ft_numbers', 'Numbers, last 30 days', array( __CLASS__, 'box_numbers' ), self::PT, 'side' );
	}

	private static function select( $name, $opts, $cur ) {
		$h = '<select name="ft[' . esc_attr( $name ) . ']" id="ft-' . esc_attr( $name ) . '">';
		foreach ( $opts as $v => $l ) $h .= '<option value="' . esc_attr( $v ) . '"' . selected( (string) $cur, (string) $v, false ) . '>' . esc_html( $l ) . '</option>';
		return $h . '</select>';
	}

	private static function input( $name, $cur, $type = 'text', $ph = '' ) {
		return '<input type="' . esc_attr( $type ) . '" class="regular-text" name="ft[' . esc_attr( $name ) . ']" id="ft-' . esc_attr( $name ) . '" value="' . esc_attr( $cur ) . '" placeholder="' . esc_attr( $ph ) . '">';
	}

	private static function row( $label, $name, $html ) {
		return '<tr><th><label for="ft-' . esc_attr( $name ) . '">' . esc_html( $label ) . '</label></th><td>' . $html . '</td></tr>';
	}

	public static function box_contact( $post ) {
		wp_nonce_field( 'ft_save', 'ft_nonce' );
		$m = function ( $k ) use ( $post ) { return self::meta( $post->ID, $k ); };
		$status = $m( 'status' ) ?: 'prospect';
		echo '<table class="form-table">';
		echo self::row( 'Type', 'kind', self::select( 'kind', self::kinds(), $m( 'kind' ) ?: 'airline' ) );
		echo self::row( 'Ladder step', 'ladder', self::select( 'ladder', self::ladder(), (int) $m( 'ladder' ) ) );
		echo self::row( 'Status', 'status', self::select( 'status', self::statuses(), $status ) );
		$org = LMGFT_Relate::ready() ? LMGFT_Relate::org( (int) $m( 'lr_org' ) ) : null;
		if ( $org ) {
			$c    = $org->contact;
			$edit = admin_url( 'admin.php?page=lr-lead-detail&id=' . (int) $org->id );
			$ro   = function ( $v ) { return '<span>' . ( $v !== '' && $v !== null ? esc_html( $v ) : '<span style="color:#888">–</span>' ) . '</span>'; };
			echo '<tr><th>LeisureRelate lead</th><td><strong>' . esc_html( $org->name ) . '</strong> · stage: ' . esc_html( LMGFT_Relate::stage( $org->id ) ) . ' · <a href="' . esc_url( $edit ) . '">Edit in LeisureRelate</a><input type="hidden" name="ft[lr_org]" value="' . (int) $org->id . '"><p class="description">Contact details come from LeisureRelate and are edited there. Status changes here move the lead\'s stage in LeisureRelate, and notes are written to its history.</p></td></tr>';
			echo '<tr><th>Contact person</th><td>' . $ro( $c->full_name ?? '' ) . ( ! empty( $c->job_title ) ? ', ' . esc_html( $c->job_title ) : '' ) . '</td></tr>';
			echo '<tr><th>Email</th><td>' . ( ! empty( $c->email ) ? '<a href="mailto:' . esc_attr( $c->email ) . '">' . esc_html( $c->email ) . '</a>' : $ro( '' ) ) . '</td></tr>';
			echo '<tr><th>Phone</th><td>' . $ro( $c->phone ?? ( $c->mobile ?? '' ) ) . '</td></tr>';
			echo '<tr><th>Website</th><td>' . $ro( $org->website ?? '' ) . '</td></tr>';
		} else {
			echo self::row( 'Contact person', 'contact_name', self::input( 'contact_name', $m( 'contact_name' ) ) );
			echo self::row( 'Role', 'contact_role', self::input( 'contact_role', $m( 'contact_role' ), 'text', 'e.g. Nordic marketing manager' ) );
			echo self::row( 'Email', 'contact_email', self::input( 'contact_email', $m( 'contact_email' ), 'email' ) );
			echo self::row( 'Phone', 'contact_phone', self::input( 'contact_phone', $m( 'contact_phone' ) ) );
			echo self::row( 'Website', 'website', self::input( 'website', $m( 'website' ), 'url' ) );
		}
		echo self::row( 'Next step', 'next_action', self::input( 'next_action', $m( 'next_action' ), 'text', 'e.g. Send pilot offer with October numbers' ) );
		echo self::row( 'Next step date', 'next_date', self::input( 'next_date', $m( 'next_date' ), 'date' ) );
		echo self::row( 'Agreed price', 'price', self::input( 'price', $m( 'price' ), 'text', 'e.g. DKK 4,000 per quarter, or press trip' ) );
		if ( ! $org && LMGFT_Relate::ready() ) {
			$opts = array( '' => '(not linked)' ) + LMGFT_Relate::orgs();
			echo self::row( 'LeisureRelate lead', 'lr_org', self::select( 'lr_org', $opts, (int) $m( 'lr_org' ) ) . '<p><label><input type="checkbox" name="ft_lr_create" value="1"> Not in LeisureRelate yet: create it there when I save</label></p><p class="description">Pick the lead if it already exists, or tick the box to create it with the contact details above. After that the contact details are kept in LeisureRelate only. <a href="' . esc_url( admin_url( 'admin.php?page=lmgft-relate' ) ) . '">Search LeisureRelate</a></p>' );
		}
		echo '</table>';
	}

	public static function box_place( $post ) {
		$m    = function ( $k ) use ( $post ) { return self::meta( $post->ID, $k ); };
		$deps = (array) ( $m( 'departures' ) ?: array() );
		$dh   = '';
		foreach ( LMGFT_Settings::departures() as $code ) {
			$dh .= '<label style="margin-right:12px"><input type="checkbox" name="ft[departures][]" value="' . esc_attr( $code ) . '"' . checked( in_array( $code, $deps, true ), true, false ) . '> ' . esc_html( $code ) . '</label>';
		}
		echo '<table class="form-table">';
		echo self::row( 'Show in the box', 'show', '<label><input type="checkbox" name="ft[show]" id="ft-show" value="1"' . checked( $m( 'show' ), '1', false ) . '> Yes, show this partner on its countries</label>' );
		echo self::row( 'Countries', 'countries', self::input( 'countries', $m( 'countries' ), 'text', 'vietnam, thailand, japan' ) . '<p class="description">The country category slugs, comma separated. The same countries as on the country pages.</p>' );
		echo self::row( 'Departure airports', 'departures', $dh . '<p class="description">Where this partner flies from (or sells trips from). Leave all empty if it does not matter.</p>' );
		echo self::row( 'Link', 'link_url', self::input( 'link_url', $m( 'link_url' ), 'url', 'https://…' ) . '<p class="description">Their route or booking page. We add tracking tags so they see our visits in their own statistics.</p>' );
		echo self::row( 'Line in the box', 'line', '<textarea class="large-text" rows="2" name="ft[line]" id="ft-line" maxlength="180">' . esc_textarea( $m( 'line' ) ) . '</textarea><p class="description">One short sentence, e.g. "Direct from Copenhagen 3 times a week in winter." Max 180 characters.</p>' );
		echo self::row( 'From', 'start', self::input( 'start', $m( 'start' ), 'date' ) );
		echo self::row( 'To', 'end', self::input( 'end', $m( 'end' ), 'date' ) . '<p class="description">Leave empty for no end. After the end date the line disappears by itself.</p>' );
		echo '</table><p class="description">Ladder steps 2 to 4 are paid: the line goes on top, shows the logo and is marked with the label from Settings. Steps 0 and 1 show as a plain line.</p>';
	}

	public static function box_log( $post ) {
		$log = (array) ( get_post_meta( $post->ID, '_ft_log', true ) ?: array() );
		echo '<p><textarea class="large-text" rows="3" name="ft_note" placeholder="Add a note: who you spoke to, what was agreed. It is saved with today\'s date when you press Update."></textarea></p>';
		if ( ! $log ) { echo '<p class="description">No notes yet.</p>'; self::relate_history( $post ); return; }
		echo '<ul style="margin:0">';
		foreach ( array_reverse( $log ) as $e ) {
			echo '<li style="border-top:1px solid #eee;padding:6px 0"><strong>' . esc_html( $e['d'] ) . '</strong> · ' . esc_html( $e['u'] ) . '<br>' . nl2br( esc_html( $e['t'] ) ) . '</li>';
		}
		echo '</ul>';
		self::relate_history( $post );
	}

	private static function relate_history( $post ) {
		$org = (int) self::meta( $post->ID, 'lr_org' );
		$h   = $org ? LMGFT_Relate::history( $org, 10 ) : array();
		if ( ! $h ) return;
		echo '<h4 style="margin:14px 0 4px">Latest in LeisureRelate</h4><ul style="margin:0">';
		foreach ( $h as $e ) echo '<li style="border-top:1px solid #eee;padding:4px 0;color:#444"><strong>' . esc_html( mysql2date( 'Y-m-d H:i', $e->created_at ) ) . '</strong> · ' . esc_html( $e->type ) . '<br>' . nl2br( esc_html( wp_trim_words( $e->body, 60 ) ) ) . '</li>';
		echo '</ul>';
	}

	public static function box_numbers( $post ) {
		$r = LMGFT_Stats::totals( $post->ID, gmdate( 'Y-m-d', strtotime( '-30 days' ) ), gmdate( 'Y-m-d' ) );
		$ctr = $r['views'] ? round( 100 * $r['clicks'] / $r['views'], 1 ) : 0;
		echo '<p>Views: <strong>' . (int) $r['views'] . '</strong><br>Clicks: <strong>' . (int) $r['clicks'] . '</strong><br>Click rate: <strong>' . esc_html( $ctr ) . ' %</strong></p>';
		echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=lmgft&partner=' . $post->ID ) ) . '">Partner report</a></p>';
	}

	public static function save( $id, $post ) {
		if ( ! isset( $_POST['ft_nonce'] ) || ! wp_verify_nonce( $_POST['ft_nonce'], 'ft_save' ) ) return;
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $id ) ) return;
		$in  = isset( $_POST['ft'] ) ? (array) wp_unslash( $_POST['ft'] ) : array();
		$old    = self::meta( $id, 'status' );
		$linked = (int) ( $in['lr_org'] ?? 0 ) && LMGFT_Relate::org( (int) $in['lr_org'] );
		foreach ( self::fields() as $k ) {
			if ( $linked && in_array( $k, array( 'contact_name', 'contact_role', 'contact_email', 'contact_phone', 'website' ), true ) ) continue;
			$v = $in[ $k ] ?? '';
			switch ( $k ) {
				case 'departures':
					$v = array_values( array_intersect( array_map( 'strtoupper', (array) $v ), LMGFT_Settings::departures() ) );
					break;
				case 'website':
				case 'link_url':
					$v = esc_url_raw( $v );
					break;
				case 'contact_email':
					$v = sanitize_email( $v );
					break;
				case 'line':
					$v = mb_substr( sanitize_textarea_field( $v ), 0, 180 );
					break;
				case 'countries':
					$v = implode( ', ', array_filter( array_map( 'sanitize_title', explode( ',', $v ) ) ) );
					break;
				case 'ladder':
				case 'lr_org':
					$v = (int) $v;
					break;
				case 'show':
					$v = $v ? '1' : '';
					break;
				case 'start':
				case 'end':
				case 'next_date':
					$v = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : '';
					break;
				default:
					$v = sanitize_text_field( $v );
			}
			update_post_meta( $id, '_ft_' . $k, $v );
		}
		if ( ! $linked && ! empty( $_POST['ft_lr_create'] ) && LMGFT_Relate::ready() ) {
			$org = LMGFT_Relate::create_from_card( $id );
			if ( $org ) {
				update_post_meta( $id, '_ft_lr_org', $org );
				$linked = true;
				$old    = ''; // the new lead already has the right stage
			}
		}
		$user  = wp_get_current_user()->display_name;
		$notes = array();
		$note  = isset( $_POST['ft_note'] ) ? trim( sanitize_textarea_field( wp_unslash( $_POST['ft_note'] ) ) ) : '';
		$new   = self::meta( $id, 'status' );
		if ( $old && $old !== $new ) $notes[] = 'Status: ' . ( self::statuses()[ $old ] ?? $old ) . ' → ' . ( self::statuses()[ $new ] ?? $new );
		if ( $note !== '' ) $notes[] = $note;
		if ( $notes ) {
			$log = (array) ( get_post_meta( $id, '_ft_log', true ) ?: array() );
			foreach ( $notes as $t ) $log[] = array( 'd' => current_time( 'Y-m-d H:i' ), 'u' => $user, 't' => $t );
			update_post_meta( $id, '_ft_log', $log );
			$org = (int) self::meta( $id, 'lr_org' );
			if ( $org ) foreach ( $notes as $t ) LMGFT_Relate::log( $org, 'Fly There (' . $post->post_title . '): ' . $t );
		}
		$org = (int) self::meta( $id, 'lr_org' );
		if ( $org && $old && $old !== $new ) LMGFT_Relate::set_stage( $org, $new );
	}

	public static function columns( $c ) {
		$date = $c['date'] ?? null;
		unset( $c['date'] );
		$c['ft_kind']   = 'Type';
		$c['ft_ladder'] = 'Ladder';
		$c['ft_status'] = 'Status';
		$c['ft_next']   = 'Next step';
		$c['ft_box']    = 'In the box';
		$c['ft_30']     = 'Views / clicks, 30 days';
		return $c;
	}

	public static function column( $col, $id ) {
		switch ( $col ) {
			case 'ft_kind':
				echo esc_html( self::kinds()[ self::meta( $id, 'kind' ) ] ?? '' );
				break;
			case 'ft_ladder':
				echo esc_html( self::ladder()[ (int) self::meta( $id, 'ladder' ) ] ?? '' );
				break;
			case 'ft_status':
				echo esc_html( self::statuses()[ self::meta( $id, 'status' ) ] ?? '' );
				break;
			case 'ft_next':
				$d    = self::meta( $id, 'next_date' );
				$late = $d && $d < current_time( 'Y-m-d' ) && ! in_array( self::meta( $id, 'status' ), array( 'declined', 'paused' ), true );
				echo '<span style="' . ( $late ? 'color:#b32d2e;font-weight:600' : '' ) . '">' . esc_html( $d ) . '</span> ' . esc_html( self::meta( $id, 'next_action' ) );
				break;
			case 'ft_box':
				echo self::live( $id ) ? esc_html( self::meta( $id, 'countries' ) ) : '<span style="color:#888">no</span>';
				break;
			case 'ft_30':
				$r = LMGFT_Stats::totals( $id, gmdate( 'Y-m-d', strtotime( '-30 days' ) ), gmdate( 'Y-m-d' ) );
				echo (int) $r['views'] . ' / ' . (int) $r['clicks'];
				break;
		}
	}

	public static function filters( $pt ) {
		if ( $pt !== self::PT ) return;
		$k = isset( $_GET['ft_kind'] ) ? sanitize_key( $_GET['ft_kind'] ) : '';
		$s = isset( $_GET['ft_status'] ) ? sanitize_key( $_GET['ft_status'] ) : '';
		echo '<select name="ft_kind"><option value="">All types</option>';
		foreach ( self::kinds() as $v => $l ) echo '<option value="' . esc_attr( $v ) . '"' . selected( $k, $v, false ) . '>' . esc_html( $l ) . '</option>';
		echo '</select><select name="ft_status"><option value="">All statuses</option>';
		foreach ( self::statuses() as $v => $l ) echo '<option value="' . esc_attr( $v ) . '"' . selected( $s, $v, false ) . '>' . esc_html( $l ) . '</option>';
		echo '</select>';
	}

	public static function list_query( $q ) {
		if ( ! is_admin() || ! $q->is_main_query() || $q->get( 'post_type' ) !== self::PT ) return;
		$mq = array();
		foreach ( array( 'kind', 'status' ) as $f ) {
			if ( ! empty( $_GET[ 'ft_' . $f ] ) ) $mq[] = array( 'key' => '_ft_' . $f, 'value' => sanitize_key( $_GET[ 'ft_' . $f ] ) );
		}
		if ( $mq ) $q->set( 'meta_query', $mq );
		$ob = $q->get( 'orderby' );
		if ( $ob === 'ft_next' ) { $q->set( 'meta_key', '_ft_next_date' ); $q->set( 'orderby', 'meta_value' ); }
		if ( $ob === 'ft_ladder' ) { $q->set( 'meta_key', '_ft_ladder' ); $q->set( 'orderby', 'meta_value_num' ); }
	}

	/** Is the partner shown in the box today? */
	public static function live( $id ) {
		if ( get_post_status( $id ) !== 'publish' || self::meta( $id, 'show' ) !== '1' ) return false;
		if ( in_array( self::meta( $id, 'status' ), array( 'paused', 'declined' ), true ) ) return false;
		$t = current_time( 'Y-m-d' );
		$s = self::meta( $id, 'start' );
		$e = self::meta( $id, 'end' );
		if ( $s && $t < $s ) return false;
		if ( $e && $t > $e ) return false;
		return true;
	}

	public static function is_paid( $id ) {
		return (int) self::meta( $id, 'ladder' ) >= 2;
	}

	/** Live partners for a country, paid first. */
	public static function for_country( $country ) {
		$country = sanitize_title( $country );
		if ( $country === '' ) return array();
		$ids  = get_posts( array(
			'post_type'      => self::PT,
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			'fields'         => 'ids',
			'meta_query'     => array(
				array( 'key' => '_ft_show', 'value' => '1' ),
				array( 'key' => '_ft_countries', 'value' => $country, 'compare' => 'LIKE' ),
			),
		) );
		$deps = LMGFT_Settings::departures();
		$out  = array();
		foreach ( $ids as $id ) {
			$cs = array_map( 'trim', explode( ',', (string) self::meta( $id, 'countries' ) ) );
			if ( ! in_array( $country, $cs, true ) || ! self::live( $id ) ) continue;
			$pd = (array) ( self::meta( $id, 'departures' ) ?: array() );
			if ( $pd && $deps && ! array_intersect( $pd, $deps ) ) continue;
			$out[] = $id;
		}
		usort( $out, function ( $a, $b ) {
			$d = (int) self::meta( $b, 'ladder' ) - (int) self::meta( $a, 'ladder' );
			return $d ?: strcasecmp( get_the_title( $a ), get_the_title( $b ) );
		} );
		return $out;
	}
}
