<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Counting: views (box seen on screen) and clicks (through our short link). No cookies, no personal data. */
class LMGFT_Stats {

	const DBV = '1';

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'lmg_ft_stats';
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( 'CREATE TABLE ' . self::table() . " (
  day date NOT NULL,
  partner_id bigint(20) unsigned NOT NULL,
  country varchar(80) NOT NULL DEFAULT '',
  lang varchar(10) NOT NULL DEFAULT '',
  views int(10) unsigned NOT NULL DEFAULT 0,
  clicks int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY  (day,partner_id,country,lang),
  KEY partner_day (partner_id,day)
) " . $wpdb->get_charset_collate() . ';' );
		update_option( 'lmgft_db', self::DBV );
	}

	public static function maybe_install() {
		if ( get_option( 'lmgft_db' ) !== self::DBV ) self::install();
	}

	public static function boot() {
		add_action( 'rest_api_init', function () {
			register_rest_route( 'lmg-ft/v1', '/seen', array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'seen' ),
				'permission_callback' => '__return_true',
			) );
		} );
		add_action( 'template_redirect', array( __CLASS__, 'go' ), 1 );
	}

	public static function is_bot() {
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? strtolower( (string) $_SERVER['HTTP_USER_AGENT'] ) : '';
		return $ua === '' || (bool) preg_match( '/bot|crawl|spider|slurp|preview|fetch|monitor|lighthouse|headless|curl|wget|python|scan/', $ua );
	}

	/** Staff looking at their own pages are not counted. */
	private static function skip() {
		return self::is_bot() || ( is_user_logged_in() && current_user_can( 'edit_posts' ) );
	}

	public static function add( $partner, $country, $lang, $col ) {
		global $wpdb;
		$col = $col === 'clicks' ? 'clicks' : 'views';
		$wpdb->query( $wpdb->prepare(
			'INSERT INTO ' . self::table() . " (day, partner_id, country, lang, $col) VALUES (%s, %d, %s, %s, 1) ON DUPLICATE KEY UPDATE $col = $col + 1",
			current_time( 'Y-m-d' ), (int) $partner, substr( sanitize_title( $country ), 0, 80 ), substr( sanitize_key( $lang ), 0, 10 )
		) );
	}

	/** POST {p:[ids], c:country, l:lang} sent by the box once it has been on screen. */
	public static function seen( WP_REST_Request $r ) {
		if ( self::skip() ) return new WP_REST_Response( array( 'ok' => true, 'counted' => 0 ), 200 );
		$country = sanitize_title( (string) $r->get_param( 'c' ) );
		$lang    = sanitize_key( (string) $r->get_param( 'l' ) );
		$ids     = array_slice( array_unique( array_map( 'intval', (array) $r->get_param( 'p' ) ) ), 0, 20 );
		$live    = LMGFT_Partners::for_country( $country );
		$n       = 0;
		foreach ( $ids as $id ) {
			if ( in_array( $id, $live, true ) ) { self::add( $id, $country, $lang, 'views' ); $n++; }
		}
		return new WP_REST_Response( array( 'ok' => true, 'counted' => $n ), 200 );
	}

	public static function link( $partner, $country, $lang ) {
		return add_query_arg( array( 'lmg_ft_go' => (int) $partner, 'c' => $country, 'l' => $lang ), home_url( '/' ) );
	}

	/** ?lmg_ft_go=ID&c=country&l=lang : count and send on with tracking tags. */
	public static function go() {
		if ( empty( $_GET['lmg_ft_go'] ) ) return;
		$id      = (int) $_GET['lmg_ft_go'];
		$country = isset( $_GET['c'] ) ? sanitize_title( wp_unslash( $_GET['c'] ) ) : '';
		$lang    = isset( $_GET['l'] ) ? sanitize_key( wp_unslash( $_GET['l'] ) ) : '';
		$url     = get_post_type( $id ) === LMGFT_Partners::PT ? LMGFT_Partners::meta( $id, 'link_url' ) : '';
		if ( ! $url ) { wp_safe_redirect( home_url( '/' ) ); exit; }
		if ( ! self::skip() && LMGFT_Partners::live( $id ) ) self::add( $id, $country, $lang, 'clicks' );
		$host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$url  = add_query_arg( array(
			'utm_source'   => rawurlencode( preg_replace( '/^www\./', '', $host ) ),
			'utm_medium'   => 'referral',
			'utm_campaign' => 'flythere',
			'utm_content'  => rawurlencode( $country . ( $lang ? '-' . $lang : '' ) ),
		), $url );
		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow' );
		wp_redirect( $url, 302, 'LMG Fly There' );
		exit;
	}

	public static function totals( $partner, $from, $to ) {
		global $wpdb;
		$where = $partner ? $wpdb->prepare( ' AND partner_id = %d', $partner ) : '';
		$r     = $wpdb->get_row( $wpdb->prepare( 'SELECT COALESCE(SUM(views),0) views, COALESCE(SUM(clicks),0) clicks FROM ' . self::table() . " WHERE day BETWEEN %s AND %s$where", $from, $to ), ARRAY_A );
		return $r ?: array( 'views' => 0, 'clicks' => 0 );
	}

	/** Rows grouped by partner_id, country or lang. */
	public static function by( $group, $from, $to, $partner = 0 ) {
		global $wpdb;
		$group = in_array( $group, array( 'partner_id', 'country', 'lang' ), true ) ? $group : 'partner_id';
		$where = $partner ? $wpdb->prepare( ' AND partner_id = %d', $partner ) : '';
		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT $group k, SUM(views) views, SUM(clicks) clicks FROM " . self::table() . " WHERE day BETWEEN %s AND %s$where GROUP BY $group ORDER BY views DESC", $from, $to ), ARRAY_A );
	}
}
