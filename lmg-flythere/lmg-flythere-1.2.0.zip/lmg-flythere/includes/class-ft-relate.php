<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * LeisureRelate CRM on the same site: one contact list, no double bookkeeping.
 * Contact data lives in LeisureRelate; a linked Fly There card reads it from there.
 */
class LMGFT_Relate {

	public static function boot() {
		if ( ! self::ready() ) return;
		add_action( 'admin_menu', function () {
			add_submenu_page( 'lmgft', 'Fetch from LeisureRelate', 'Fetch from LeisureRelate', 'edit_others_posts', 'lmgft-relate', array( __CLASS__, 'page' ) );
		}, 20 );
		add_action( 'admin_post_lmgft_relate_import', array( __CLASS__, 'import' ) );
		add_filter( 'views_edit-' . LMGFT_Partners::PT, function ( $v ) {
			$v['lmgft_relate'] = '<a href="' . esc_url( admin_url( 'admin.php?page=lmgft-relate' ) ) . '">Fetch from LeisureRelate</a>';
			return $v;
		} );
	}

	public static function ready() {
		global $wpdb;
		static $ok = null;
		if ( $ok === null ) $ok = (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->prefix . 'lr_organisations' ) );
		return $ok;
	}

	private static function t( $n ) {
		global $wpdb;
		return $wpdb->prefix . 'lr_' . $n;
	}

	/** id => name, or null when LeisureRelate is not on this site. */
	public static function orgs() {
		if ( ! self::ready() ) return null;
		global $wpdb;
		$out = array();
		foreach ( (array) $wpdb->get_results( 'SELECT id, name FROM ' . self::t( 'organisations' ) . ' ORDER BY name LIMIT 3000' ) as $r ) $out[ (int) $r->id ] = $r->name;
		return $out;
	}

	public static function lead_types() {
		if ( class_exists( 'LR_DB' ) && method_exists( 'LR_DB', 'lead_types' ) ) return LR_DB::lead_types();
		return array( 'travel-agency' => 'Travel Agency', 'advertiser' => 'Advertiser', 'sponsor' => 'Sponsor', 'destination' => 'Destination / Tourism Board', 'other' => 'Other' );
	}

	public static function stages() {
		return class_exists( 'LR_DB' ) && method_exists( 'LR_DB', 'pipeline_stages' ) ? LR_DB::pipeline_stages() : array();
	}

	public static function stage( $org ) {
		$o = self::org( $org );
		if ( ! $o ) return '';
		return self::stages()[ (int) $o->pipeline_stage ] ?? (string) $o->pipeline_stage;
	}

	/** The lead with its primary contact (full_name, job_title, email, phone). */
	public static function org( $id ) {
		if ( ! self::ready() || ! $id ) return null;
		global $wpdb;
		$o = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'organisations' ) . ' WHERE id = %d', $id ) );
		if ( ! $o ) return null;
		$o->contact = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t( 'contacts' ) . ' WHERE organisation_id = %d ORDER BY is_primary DESC, id ASC LIMIT 1', $id ) );
		return $o;
	}

	public static function search( $q, $type ) {
		global $wpdb;
		$w = array( '1=1' );
		$v = array();
		if ( $q !== '' ) {
			$like = '%' . $wpdb->esc_like( $q ) . '%';
			$w[]  = '(o.name LIKE %s OR o.website LIKE %s)';
			array_push( $v, $like, $like );
		}
		if ( $type !== '' ) { $w[] = 'o.lead_type = %s'; $v[] = $type; }
		$sql = 'SELECT o.id, o.name, o.lead_type, o.pipeline_stage, o.website, o.site_id,
			(SELECT c.full_name FROM ' . self::t( 'contacts' ) . ' c WHERE c.organisation_id = o.id ORDER BY c.is_primary DESC, c.id LIMIT 1) contact
			FROM ' . self::t( 'organisations' ) . ' o WHERE ' . implode( ' AND ', $w ) . ' ORDER BY o.name LIMIT 200';
		return (array) ( $v ? $wpdb->get_results( $wpdb->prepare( $sql, $v ) ) : $wpdb->get_results( $sql ) );
	}

	/** Fly There card linked to a lead, or 0. */
	public static function card_for( $org ) {
		$ids = get_posts( array( 'post_type' => LMGFT_Partners::PT, 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_ft_lr_org', 'meta_value' => (int) $org ) );
		return $ids ? (int) $ids[0] : 0;
	}

	public static function kind_for( $lead_type ) {
		$map = array( 'travel-agency' => 'agency', 'destination' => 'tourist', 'airline' => 'airline', 'rail' => 'rail', 'cruise' => 'cruise', 'ferry' => 'ferry', 'bus' => 'bus' );
		return $map[ $lead_type ] ?? 'other';
	}

	private static function type_for( $kind ) {
		$map = array( 'agency' => 'travel-agency', 'tourist' => 'destination', 'airline' => 'advertiser' );
		return $map[ $kind ] ?? 'other';
	}

	/** Fly There status → LeisureRelate stage. Paused and declined leave the stage alone. */
	public static function stage_for( $status ) {
		$map = array( 'prospect' => 1, 'contacted' => 3, 'replied' => 4, 'meeting' => 5, 'active' => 8 );
		return $map[ $status ] ?? 0;
	}

	public static function set_stage( $org, $status ) {
		$s = self::stage_for( $status );
		if ( ! $s || ! self::ready() ) return;
		if ( class_exists( 'LR_Orgs' ) && method_exists( 'LR_Orgs', 'update' ) ) {
			LR_Orgs::update( $org, array( 'pipeline_stage' => $s ) );
		} else {
			global $wpdb;
			$wpdb->update( self::t( 'organisations' ), array( 'pipeline_stage' => $s ), array( 'id' => (int) $org ) );
		}
	}

	/** Make a new lead in LeisureRelate from a Fly There card, with its contact person. */
	public static function create_from_card( $id ) {
		if ( ! self::ready() ) return 0;
		global $wpdb;
		$m   = function ( $k ) use ( $id ) { return LMGFT_Partners::meta( $id, $k ); };
		$row = array(
			'name'           => get_the_title( $id ),
			'site_id'        => LMGFT_Settings::is_travel() ? 'traveltalk-travel' : 'traveltalk-dk',
			'market'         => LMGFT_Settings::is_travel() ? '' : 'dk',
			'lead_type'      => self::type_for( $m( 'kind' ) ),
			'website'        => $m( 'website' ),
			'pipeline_stage' => self::stage_for( $m( 'status' ) ?: 'prospect' ) ?: 1,
			'notes'          => 'Created from Fly There.',
		);
		if ( class_exists( 'LR_Orgs' ) && method_exists( 'LR_Orgs', 'insert' ) ) {
			$org = (int) LR_Orgs::insert( $row );
		} else {
			$row['lr_wp_owner_id'] = get_current_user_id();
			$wpdb->insert( self::t( 'organisations' ), $row );
			$org = (int) $wpdb->insert_id;
		}
		if ( ! $org ) return 0;
		if ( $m( 'contact_name' ) ) {
			$wpdb->insert( self::t( 'contacts' ), array(
				'organisation_id' => $org,
				'full_name'       => $m( 'contact_name' ),
				'job_title'       => $m( 'contact_role' ),
				'email'           => $m( 'contact_email' ),
				'phone'           => $m( 'contact_phone' ),
				'is_primary'      => 1,
			) );
		}
		return $org;
	}

	public static function log( $org, $text ) {
		if ( ! self::ready() ) return;
		global $wpdb;
		$wpdb->insert( self::t( 'interactions' ), array( 'org_id' => (int) $org, 'wp_user_id' => get_current_user_id(), 'type' => 'note', 'body' => $text, 'is_system' => 1, 'created_at' => current_time( 'mysql' ) ) );
		$wpdb->update( self::t( 'organisations' ), array( 'last_activity' => current_time( 'mysql' ) ), array( 'id' => (int) $org ) );
	}

	public static function history( $org, $n = 10 ) {
		if ( ! self::ready() ) return array();
		global $wpdb;
		return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT type, body, created_at FROM ' . self::t( 'interactions' ) . ' WHERE org_id = %d ORDER BY created_at DESC, id DESC LIMIT %d', $org, $n ) );
	}

	/** Fly There → Fetch from LeisureRelate */
	public static function page() {
		$q    = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
		$type = isset( $_GET['lt'] ) ? sanitize_text_field( wp_unslash( $_GET['lt'] ) ) : 'travel-agency';
		$rows = self::search( $q, $type );
		$st   = self::stages();
		echo '<div class="wrap"><h1>Fetch from LeisureRelate</h1>';
		if ( isset( $_GET['made'] ) ) echo '<div class="notice notice-success"><p>' . (int) $_GET['made'] . ' Fly There card(s) made. Open each card to tick the box, countries and link.</p></div>';
		echo '<p>Leads in LeisureRelate you can bring into Fly There. The contact person, email, phone and website stay in LeisureRelate, so you keep them in one place only.</p>';
		echo '<form method="get"><input type="hidden" name="page" value="lmgft-relate"><input type="search" name="q" value="' . esc_attr( $q ) . '" placeholder="Search name or website"> <select name="lt"><option value="">All types</option>';
		foreach ( self::lead_types() as $k => $l ) echo '<option value="' . esc_attr( $k ) . '"' . selected( $type, $k, false ) . '>' . esc_html( $l ) . '</option>';
		echo '</select> <button class="button">Search</button></form>';
		if ( ! $rows ) { echo '<p>No leads found.</p></div>'; return; }
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="lmgft_relate_import">';
		wp_nonce_field( 'lmgft_relate_import' );
		echo '<table class="widefat striped" style="margin-top:12px"><thead><tr><td class="check-column"><input type="checkbox" onclick="document.querySelectorAll(\'.lmgft-org\').forEach(function(c){c.checked=this.checked}.bind(this))"></td><th>Name</th><th>Type</th><th>Stage</th><th>Contact</th><th>Website</th><th>Fly There</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$card = self::card_for( $r->id );
			echo '<tr><th class="check-column">' . ( $card ? '' : '<input type="checkbox" class="lmgft-org" name="org[]" value="' . (int) $r->id . '">' ) . '</th><td><strong>' . esc_html( $r->name ) . '</strong></td><td>' . esc_html( self::lead_types()[ $r->lead_type ] ?? $r->lead_type ) . '</td><td>' . esc_html( $st[ (int) $r->pipeline_stage ] ?? $r->pipeline_stage ) . '</td><td>' . esc_html( (string) $r->contact ) . '</td><td>' . esc_html( (string) $r->website ) . '</td><td>' . ( $card ? '<a href="' . esc_url( get_edit_post_link( $card ) ) . '">Open card</a>' : '–' ) . '</td></tr>';
		}
		echo '</tbody></table><p><button class="button button-primary">Make Fly There cards for the ticked leads</button></p></form></div>';
	}

	public static function import() {
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_die( 'No access' );
		check_admin_referer( 'lmgft_relate_import' );
		$made = 0;
		$last = 0;
		foreach ( array_map( 'intval', (array) ( $_POST['org'] ?? array() ) ) as $org ) {
			$o = self::org( $org );
			if ( ! $o || self::card_for( $org ) ) continue;
			$id = wp_insert_post( array( 'post_type' => LMGFT_Partners::PT, 'post_title' => $o->name, 'post_status' => 'publish' ) );
			if ( ! $id || is_wp_error( $id ) ) continue;
			update_post_meta( $id, '_ft_lr_org', $org );
			update_post_meta( $id, '_ft_kind', self::kind_for( $o->lead_type ) );
			update_post_meta( $id, '_ft_status', 'prospect' );
			update_post_meta( $id, '_ft_ladder', 0 );
			update_post_meta( $id, '_ft_log', array( array( 'd' => current_time( 'Y-m-d H:i' ), 'u' => wp_get_current_user()->display_name, 't' => 'Fetched from LeisureRelate.' ) ) );
			$made++;
			$last = $id;
		}
		if ( $made === 1 ) { wp_safe_redirect( get_edit_post_link( $last, 'url' ) ); exit; }
		wp_safe_redirect( admin_url( 'admin.php?page=lmgft-relate&made=' . $made ) );
		exit;
	}
}
