# LMG Fly There

Partner lines (airlines, travel agencies) on country pages, contact log and ladder, view and click counting, monthly reports.

- Hook: listens to `lmg_faktabokse_after_getting_there( $country_slug, $post_id )` from LMG Faktabokse. Shortcode fallback: `[lmg_flythere country="vietnam"]`.
- Departures: filter `lmg_faktabokse_departures` (array of airport codes) overrides the setting.
- Country name: filter `lmg_flythere_country_name( $name, $slug, $lang )`.
- Language: `LMGT_Front::current_lang()` from LMG Translator, else the site locale.
- Counting: table `{prefix}lmg_ft_stats` (day, partner, country, lang, views, clicks). Views via `POST /wp-json/lmg-ft/v1/seen`; clicks via `/?lmg_ft_go=ID&c=country&l=lang` (302 with UTM tags).
- Partners: post type `lmg_ft_partner`, meta `_ft_*`. Optional link to LeisureRelate (`lr_organisations`, `lr_interactions`).
