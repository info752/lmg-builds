(function () {
	if (!window.lmgFt || !('IntersectionObserver' in window) || document.body.classList.contains('logged-in')) return;
	var boxes = document.querySelectorAll('.lmg-ft[data-p]');
	var send = function (el) {
		var body = JSON.stringify({ p: el.getAttribute('data-p').split(',').map(Number), c: el.getAttribute('data-c'), l: el.getAttribute('data-l') });
		if (navigator.sendBeacon) navigator.sendBeacon(lmgFt.u, new Blob([body], { type: 'application/json' }));
		else fetch(lmgFt.u, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: body, keepalive: true });
	};
	var io = new IntersectionObserver(function (entries) {
		entries.forEach(function (e) {
			var el = e.target;
			if (e.isIntersecting) {
				el._t = setTimeout(function () { io.unobserve(el); send(el); }, 1000);
			} else if (el._t) {
				clearTimeout(el._t);
			}
		});
	}, { threshold: 0.5 });
	boxes.forEach(function (b) { io.observe(b); });
})();
