<?php
/**
 * Plugin Name: LMG Fly There
 * Description: Airline and travel agency partners on country pages: contacts and ladder, partner lines in the box, counted views and clicks, monthly reports.
 * Version:     1.2.0
 * Author:      Leisure Media Group
 * License:     Proprietary
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'LMGFT_VERSION', '1.2.0' );
define( 'LMGFT_DIR', plugin_dir_path( __FILE__ ) );
define( 'LMGFT_URL', plugin_dir_url( __FILE__ ) );

require_once LMGFT_DIR . 'includes/class-ft-settings.php';
require_once LMGFT_DIR . 'includes/class-ft-partners.php';
require_once LMGFT_DIR . 'includes/class-ft-relate.php';
require_once LMGFT_DIR . 'includes/class-ft-stats.php';
require_once LMGFT_DIR . 'includes/class-ft-box.php';
require_once LMGFT_DIR . 'includes/class-ft-report.php';
require_once LMGFT_DIR . 'includes/class-ft-notes.php';
require_once LMGFT_DIR . 'includes/class-ft-import.php';

register_activation_hook( __FILE__, array( 'LMGFT_Stats', 'install' ) );

add_action( 'plugins_loaded', function () {
	LMGFT_Stats::maybe_install();
	LMGFT_Settings::boot();
	LMGFT_Partners::boot();
	LMGFT_Stats::boot();
	LMGFT_Box::boot();
	LMGFT_Report::boot();
	LMGFT_Relate::boot();
	LMGFT_Import::boot();
	LMGFT_Notes::boot();
} );

add_action( 'admin_menu', function () {
	add_menu_page( 'Fly There', 'Fly There', 'edit_others_posts', 'lmgft', array( 'LMGFT_Report', 'page' ), 'dashicons-airplane', 58 );
	add_submenu_page( 'lmgft', 'Report', 'Report', 'edit_others_posts', 'lmgft', array( 'LMGFT_Report', 'page' ) );
}, 9 );
