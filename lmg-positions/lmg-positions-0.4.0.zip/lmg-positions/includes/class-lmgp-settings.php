<?php
if (!defined('ABSPATH')) exit;

/**
 * LMGP_Settings — markets, seed keywords and limits per site (G 2026-10-28).
 * .dk = Danish only on google.dk; .travel = en (UK + US), de, fr, es, it.
 * Seeds: country destinations as guide searches; "!" marks a template that is tracked only
 * ("rejser til X" — measured for the baseline and the advertiser list, never targeted).
 */
class LMGP_Settings {

    const OPTION = 'lmgp_settings';

    /** DataForSEO credentials are shared with LeisureIntel's own box (same option names). */
    const DFS_LOGIN = 'li_dataforseo_login';
    const DFS_PASS  = 'li_dataforseo_password';

    // Location codes: DataForSEO uses 2000 + ISO 3166 numeric.
    const PROFILES = [
        'traveltalk.dk' => [
            "da-dk|da|2208|da|Dansk · google.dk",
        ],
        'traveltalk.travel' => [
            "en-gb|en|2826|en|English · google.co.uk",
            "en-us|en|2840|en|English · google.com (US)",
            "de-de|de|2276|de|Deutsch · google.de",
            "fr-fr|fr|2250|fr|Français · google.fr",
            "es-es|es|2724|es|Español · google.es",
            "it-it|it|2380|it|Italiano · google.it",
        ],
    ];

    const LOCALE_MARKETS = [
        'da' => "da-dk|da|2208|da|Dansk · google.dk",
        'sv' => "sv-se|sv|2752|sv|Svenska · google.se",
        'nb' => "nb-no|nb|2578|nb|Norsk · google.no",
        'fi' => "fi-fi|fi|2246|fi|Suomi · google.fi",
        'de' => "de-de|de|2276|de|Deutsch · google.de",
        'en' => "en-gb|en|2826|en|English · google.co.uk",
    ];

    const TEMPLATES = [
        'da' => "ferie i {x}\nseværdigheder i {x}\n!rejser til {x}",
        'en' => "{x} travel guide\nthings to do in {x}\n!{x} holidays",
        'de' => "{x} Sehenswürdigkeiten\n{x} Reiseführer\n!{x} Reisen",
        'fr' => "visiter {x}\n{x} guide de voyage\n!voyage {x}",
        'es' => "qué ver en {x}\n{x} guía de viaje\n!viajes a {x}",
        'it' => '',
    ];

    // Same 26 countries in each language, in the same order.
    const COUNTRIES = [
        'da' => "Frankrig\nSpanien\nItalien\nGrækenland\nPortugal\nKroatien\nØstrig\nTyskland\nEngland\nTyrkiet\nCypern\nMalta\nIsland\nNorge\nSverige\nDanmark\nHolland\nEgypten\nMarokko\nThailand\nVietnam\nJapan\nIndonesien\nUSA\nMexico\nAustralien",
        'en' => "France\nSpain\nItaly\nGreece\nPortugal\nCroatia\nAustria\nGermany\nEngland\nTurkey\nCyprus\nMalta\nIceland\nNorway\nSweden\nDenmark\nNetherlands\nEgypt\nMorocco\nThailand\nVietnam\nJapan\nIndonesia\nUSA\nMexico\nAustralia",
        'de' => "Frankreich\nSpanien\nItalien\nGriechenland\nPortugal\nKroatien\nÖsterreich\nDeutschland\nEngland\nTürkei\nZypern\nMalta\nIsland\nNorwegen\nSchweden\nDänemark\nNiederlande\nÄgypten\nMarokko\nThailand\nVietnam\nJapan\nIndonesien\nUSA\nMexiko\nAustralien",
        'fr' => "France\nEspagne\nItalie\nGrèce\nPortugal\nCroatie\nAutriche\nAllemagne\nAngleterre\nTurquie\nChypre\nMalte\nIslande\nNorvège\nSuède\nDanemark\nPays-Bas\nÉgypte\nMaroc\nThaïlande\nVietnam\nJapon\nIndonésie\nÉtats-Unis\nMexique\nAustralie",
        'es' => "Francia\nEspaña\nItalia\nGrecia\nPortugal\nCroacia\nAustria\nAlemania\nInglaterra\nTurquía\nChipre\nMalta\nIslandia\nNoruega\nSuecia\nDinamarca\nPaíses Bajos\nEgipto\nMarruecos\nTailandia\nVietnam\nJapón\nIndonesia\nEstados Unidos\nMéxico\nAustralia",
        'it' => '',
    ];

    const INTERESTS = [
        'da' => "skiferie\nvandreferie\nnaturoplevelser\nbadeferie\ngolfferie\nvinferie\nstorbyferie\nadventure rejser",
        'en' => "best ski resorts in europe\nhiking holidays\nnature travel\nbest beaches in europe\ngolf holidays\nwine regions to visit\ncity breaks europe\nadventure travel",
        'de' => "Skiurlaub\nWanderurlaub\nNaturreisen\nStrandurlaub\nGolfurlaub\nWeinreisen\nStädtereisen\nAbenteuerreisen",
        'fr' => "vacances au ski\nrandonnée en europe\nvoyage nature\nplus belles plages d'europe\nséjour golf\noenotourisme\ncity break europe\nvoyage aventure",
        'es' => "vacaciones de esquí\nsenderismo en europa\nturismo de naturaleza\nmejores playas de europa\nviajes de golf\nenoturismo\nescapadas urbanas europa\nviajes de aventura",
        'it' => '',
    ];

    // Domains we accept we cannot beat (G 2026-10-28: "a number of bigger companies"). Substring match.
    const BIG_PLAYERS = "wikipedia.org\ntripadvisor.\nbooking.com\nexpedia.\nhotels.com\nairbnb.\nlonelyplanet.com\nyoutube.com\nfacebook.com\ninstagram.com\nreddit.com\ngetyourguide.\nviator.com\nkayak.\nmomondo.\nskyscanner.";

    public static function host() {
        $h = strtolower((string) wp_parse_url(home_url(), PHP_URL_HOST));
        return preg_replace('/^www\./', '', $h);
    }

    public static function defaults() {
        $host = self::host();
        if (isset(self::PROFILES[$host])) {
            $markets = implode("\n", self::PROFILES[$host]);
        } else {
            $loc = substr(get_locale(), 0, 2);
            $markets = self::LOCALE_MARKETS[$loc] ?? self::LOCALE_MARKETS['en'];
        }
        return [
            'markets'      => $markets,
            'templates'    => self::TEMPLATES,
            'countries'    => self::COUNTRIES,
            'interests'    => self::INTERESTS,
            'big_players'  => self::BIG_PLAYERS,
            'window_days'  => 28,
            'min_impr'     => 5,
            'gsc_per_mkt'  => 50,   // GSC keywords at positions 4–20 sent to Google per market
            'max_tasks'    => 1000, // hard cap per run
            'depth'        => 20,   // results per keyword; billed per page of 10
        ];
    }

    public static function get() {
        $s = get_option(self::OPTION, []);
        return array_merge(self::defaults(), is_array($s) ? $s : []);
    }

    public static function save(array $in) {
        $d = self::defaults();
        $out = [];
        $out['markets']     = self::clean_lines($in['markets'] ?? $d['markets']);
        $out['big_players'] = self::clean_lines($in['big_players'] ?? $d['big_players']);
        foreach (['templates', 'countries', 'interests'] as $k) {
            $out[$k] = [];
            foreach (self::langs($out['markets']) as $lang) {
                $out[$k][$lang] = self::clean_lines($in[$k][$lang] ?? ($d[$k][$lang] ?? ''));
            }
        }
        $out['window_days'] = max(7, min(90, (int) ($in['window_days'] ?? $d['window_days'])));
        $out['min_impr']    = max(1, (int) ($in['min_impr'] ?? $d['min_impr']));
        $out['gsc_per_mkt'] = max(0, min(500, (int) ($in['gsc_per_mkt'] ?? $d['gsc_per_mkt'])));
        $out['max_tasks']   = max(1, min(5000, (int) ($in['max_tasks'] ?? $d['max_tasks'])));
        $depth              = (int) ($in['depth'] ?? $d['depth']);
        $out['depth']       = in_array($depth, [10, 20, 30], true) ? $depth : 20;
        update_option(self::OPTION, $out, false);
    }

    public static function reset() {
        delete_option(self::OPTION);
    }

    /** "key|lang|location_code|language_code|label" lines → [key => [...]] */
    public static function markets($s = null) {
        $s = $s ?? self::get();
        $out = [];
        foreach (self::lines($s['markets']) as $line) {
            $p = array_map('trim', explode('|', $line));
            if (count($p) < 4 || $p[0] === '' || !ctype_digit($p[2])) continue;
            $out[$p[0]] = [
                'key'      => $p[0],
                'lang'     => strtolower($p[1]),
                'location' => (int) $p[2],
                'language' => $p[3],
                'label'    => $p[4] ?? $p[0],
            ];
        }
        return $out;
    }

    public static function langs($markets_text) {
        $langs = [];
        foreach (self::markets(['markets' => $markets_text]) as $m) $langs[$m['lang']] = true;
        return array_keys($langs);
    }

    /**
     * Seed keywords for one language: templates × countries, plus interests.
     * Returns [keyword => track_only(bool)].
     */
    public static function seeds($lang, $s = null) {
        $s = $s ?? self::get();
        $out = [];
        $countries = self::lines($s['countries'][$lang] ?? '');
        foreach (self::lines($s['templates'][$lang] ?? '') as $tpl) {
            $track = (substr($tpl, 0, 1) === '!');
            $tpl = ltrim($tpl, '! ');
            if (strpos($tpl, '{x}') === false) { $out[self::norm($tpl)] = $track; continue; }
            foreach ($countries as $c) $out[self::norm(str_replace('{x}', $c, $tpl))] = $track;
        }
        foreach (self::lines($s['interests'][$lang] ?? '') as $kw) {
            $out[self::norm($kw)] = $out[self::norm($kw)] ?? false;
        }
        return $out;
    }

    public static function big_players($s = null) {
        $s = $s ?? self::get();
        return array_map('strtolower', self::lines($s['big_players']));
    }

    public static function norm($kw) {
        return trim(preg_replace('/\s+/u', ' ', mb_strtolower((string) $kw)));
    }

    public static function lines($text) {
        return array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', (string) $text)), 'strlen'));
    }

    private static function clean_lines($text) {
        return implode("\n", self::lines(sanitize_textarea_field((string) $text)));
    }
}
