<?php
if (!defined('ABSPATH')) exit;

/**
 * LMGP_DFS — minimal DataForSEO v3 client (Google organic SERP, standard queue).
 * Billing happens at task_post (per 10-result page); task_get and user_data are free.
 * Credentials live in the site's options (shared with LeisureIntel), never in code.
 */
class LMGP_DFS {

    const BASE = 'https://api.dataforseo.com/v3/';

    public static function is_configured() {
        return get_option(LMGP_Settings::DFS_LOGIN, '') !== '' && get_option(LMGP_Settings::DFS_PASS, '') !== '';
    }

    private static function request($method, $path, $body = null) {
        $args = [
            'method'  => $method,
            'timeout' => 45,
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode(get_option(LMGP_Settings::DFS_LOGIN, '') . ':' . get_option(LMGP_Settings::DFS_PASS, '')),
                'Content-Type'  => 'application/json',
            ],
        ];
        if ($body !== null) $args['body'] = wp_json_encode($body);
        $r = wp_remote_request(self::BASE . $path, $args);
        if (is_wp_error($r)) return $r;
        $code = wp_remote_retrieve_response_code($r);
        $json = json_decode(wp_remote_retrieve_body($r), true);
        if (!is_array($json)) return new WP_Error('lmgp_dfs', "DataForSEO svarede ikke med JSON (HTTP {$code}).");
        if ((int) ($json['status_code'] ?? 0) !== 20000) {
            return new WP_Error('lmgp_dfs', 'DataForSEO: ' . ($json['status_message'] ?? "HTTP {$code}") . ' (' . ($json['status_code'] ?? '?') . ')');
        }
        return $json;
    }

    /** Account balance in USD, or WP_Error. */
    public static function balance() {
        $j = self::request('GET', 'appendix/user_data');
        if (is_wp_error($j)) return $j;
        $money = $j['tasks'][0]['result'][0]['money'] ?? null;
        if (!is_array($money) || !isset($money['balance'])) return new WP_Error('lmgp_dfs', 'Ingen saldo i svaret fra DataForSEO.');
        return (float) $money['balance'];
    }

    /**
     * Post up to 100 tasks. $tasks: [['keyword','location_code','language_code','depth','tag'], ...]
     * Returns [tag => task_id | WP_Error].
     */
    public static function post_tasks(array $tasks) {
        $j = self::request('POST', 'serp/google/organic/task_post', array_values($tasks));
        if (is_wp_error($j)) return $j;
        $out = [];
        foreach ((array) ($j['tasks'] ?? []) as $t) {
            $tag = (string) ($t['data']['tag'] ?? '');
            if ($tag === '') continue;
            $out[$tag] = ((int) ($t['status_code'] ?? 0) === 20100)
                ? (string) $t['id']
                : new WP_Error('lmgp_dfs', (string) ($t['status_message'] ?? 'task_post fejlede'));
        }
        return $out;
    }

    /**
     * Fetch one finished task. Returns ['pending'=>true] while queued,
     * ['organic'=>[[pos,domain,url,title]...], 'paid'=>[[domain,url,title]...]] when done, or WP_Error.
     */
    public static function get_task($id) {
        $j = self::request('GET', 'serp/google/organic/task_get/advanced/' . rawurlencode($id));
        if (is_wp_error($j)) return $j;
        $t = $j['tasks'][0] ?? [];
        $sc = (int) ($t['status_code'] ?? 0);
        if (in_array($sc, [40601, 40602], true)) return ['pending' => true]; // handed / in queue
        if ($sc === 40102) return ['organic' => [], 'paid' => []];         // no search results
        if ($sc !== 20000) return new WP_Error('lmgp_dfs', (string) ($t['status_message'] ?? "Status {$sc}"));
        $organic = [];
        $paid = [];
        foreach ((array) ($t['result'][0]['items'] ?? []) as $it) {
            $type = $it['type'] ?? '';
            if ($type === 'organic') {
                $organic[] = [
                    (int) ($it['rank_group'] ?? 0),
                    self::domain($it['domain'] ?? ''),
                    (string) ($it['url'] ?? ''),
                    mb_substr((string) ($it['title'] ?? ''), 0, 120),
                ];
            } elseif ($type === 'paid') {
                $paid[] = [
                    self::domain($it['domain'] ?? ''),
                    (string) ($it['url'] ?? ''),
                    mb_substr((string) ($it['title'] ?? ''), 0, 120),
                ];
            }
        }
        return ['organic' => $organic, 'paid' => $paid];
    }

    public static function domain($d) {
        return preg_replace('/^www\./', '', strtolower(trim((string) $d)));
    }
}
