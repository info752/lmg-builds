<?php
if (!defined('ABSPATH')) exit;

/**
 * LMGP_Admin — the "Positioner" page under LeisureIntel (falls back to Tools).
 * Every button is a manual action by an admin; the only thing that runs on its own is collecting
 * finished DataForSEO results into this plugin's own table.
 */
class LMGP_Admin {

    const SLUG = 'lmg-positions';

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'menu'], 25);
        add_action('admin_notices', [__CLASS__, 'notice']);
        foreach (['baseline', 'fetch', 'collect', 'settings', 'reset', 'creds', 'test', 'csv'] as $a) {
            add_action('admin_post_lmgp_' . $a, [__CLASS__, 'handle_' . $a]);
        }
    }

    public static function menu() {
        global $admin_page_hooks;
        if (isset($admin_page_hooks['leisureintel'])) {
            add_submenu_page('leisureintel', 'Positioner', 'Positioner', 'manage_options', self::SLUG, [__CLASS__, 'render']);
        } else {
            add_management_page('Positioner', 'Positioner', 'manage_options', self::SLUG, [__CLASS__, 'render']);
        }
    }

    private static function url($args = []) {
        return add_query_arg(array_merge(['page' => self::SLUG], $args), admin_url('admin.php'));
    }

    private static function guard($action) {
        if (!current_user_can('manage_options')) wp_die('Adgang nægtet.');
        check_admin_referer('lmgp_' . $action);
    }

    private static function back($msg, $args = []) {
        wp_safe_redirect(self::url(array_merge($args, ['lmgp_msg' => rawurlencode($msg)])));
        exit;
    }

    private static function run_arg() {
        return isset($_REQUEST['run']) ? (int) $_REQUEST['run'] : 0;
    }

    /* ── Handlers ────────────────────────────────────────────────────────── */

    public static function handle_baseline() {
        self::guard('baseline');
        $run = LMGP_Data::take_baseline();
        if (is_wp_error($run)) self::back($run->get_error_message());
        self::back("Baseline taget: {$run['rows']} søgeord.", ['run' => $run['id']]);
    }

    public static function handle_fetch() {
        self::guard('fetch');
        $id = self::run_arg();
        $res = LMGP_Data::fetch($id);
        if (is_wp_error($res)) self::back($res->get_error_message(), ['run' => $id]);
        $msg = "{$res['posted']} søgeord sendt til DataForSEO. Resultaterne hentes automatisk hvert 5. minut.";
        if ($res['errors']) $msg .= ' Fejl: ' . implode(' · ', $res['errors']);
        self::back($msg, ['run' => $id]);
    }

    public static function handle_collect() {
        self::guard('collect');
        $n = LMGP_Data::collect(60);
        self::back("{$n} resultater hentet.", ['run' => self::run_arg()]);
    }

    public static function handle_settings() {
        self::guard('settings');
        LMGP_Settings::save(wp_unslash($_POST['lmgp'] ?? []));
        self::back('Indstillinger gemt. De gælder fra næste baseline.', ['run' => self::run_arg()]);
    }

    public static function handle_reset() {
        self::guard('reset');
        LMGP_Settings::reset();
        self::back('Indstillinger sat tilbage til standard.', ['run' => self::run_arg()]);
    }

    public static function handle_creds() {
        self::guard('creds');
        update_option(LMGP_Settings::DFS_LOGIN, sanitize_text_field(wp_unslash($_POST['login'] ?? '')));
        $pass = sanitize_text_field(wp_unslash($_POST['password'] ?? ''));
        if ($pass !== '') update_option(LMGP_Settings::DFS_PASS, $pass);
        self::back('DataForSEO-login gemt.', ['run' => self::run_arg()]);
    }

    public static function handle_test() {
        self::guard('test');
        $b = LMGP_DFS::balance();
        self::back(is_wp_error($b) ? $b->get_error_message() : sprintf('Forbindelse OK. Saldo hos DataForSEO: $%s', number_format($b, 2)), ['run' => self::run_arg()]);
    }

    public static function handle_csv() {
        self::guard('csv');
        $id = self::run_arg();
        $type = sanitize_key($_GET['type'] ?? 'rows');
        $market = sanitize_text_field(wp_unslash($_GET['market'] ?? ''));
        $big = LMGP_Settings::big_players();
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="positioner-' . LMGP_Settings::host() . "-run{$id}-{$type}.csv\"");
        $f = fopen('php://output', 'w');
        fwrite($f, "\xEF\xBB\xBF");
        if ($type === 'owners') {
            fputcsv($f, ['domæne', 'søgeord over os', 'gns. placering', 'eksempler']);
            foreach (LMGP_Data::owners($id, $market, 500) as $o) fputcsv($f, [$o['domain'], $o['n'], $o['pos'], implode(' | ', $o['kw'])]);
        } elseif ($type === 'ads') {
            fputcsv($f, ['annoncør', 'søgeord', 'markeder', 'eksempler']);
            foreach (LMGP_Data::advertisers($id, $market) as $a) fputcsv($f, [$a['domain'], $a['n'], implode(' ', array_keys($a['markets'])), implode(' | ', $a['kw'])]);
        } else {
            fputcsv($f, ['marked', 'søgeord', 'kilde', 'kun måling', 'gsc placering', 'gsc visninger', 'gsc klik', 'gsc side', 'google placering', 'vores url', 'top 10 domæner', 'annoncører', 'forslag']);
            foreach (LMGP_Data::rows($id, $market) as $r) {
                fputcsv($f, [
                    $r->market, $r->keyword, $r->source, (int) $r->track_only,
                    $r->gsc_pos, $r->gsc_impr, $r->gsc_clicks, $r->gsc_page,
                    $r->serp_status === 'done' ? ($r->serp_pos === null ? '>' . LMGP_Settings::get()['depth'] : $r->serp_pos) : '',
                    $r->serp_url,
                    implode(' ', array_map(function ($o) { return $o[0] . ':' . $o[1]; }, array_slice(LMGP_Data::top($r), 0, 10))),
                    implode(' ', array_unique(array_column(LMGP_Data::ads($r), 0))),
                    LMGP_Data::action($r, $big),
                ]);
            }
        }
        fclose($f);
        exit;
    }

    /* ── Page ────────────────────────────────────────────────────────────── */

    private static function button($action, $label, $hidden = [], $primary = false, $confirm = '') {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="display:inline-block;margin:0 6px 6px 0;"'
           . ($confirm !== '' ? ' onsubmit="return confirm(' . esc_attr(wp_json_encode($confirm)) . ');"' : '') . '>';
        echo '<input type="hidden" name="action" value="lmgp_' . esc_attr($action) . '">';
        wp_nonce_field('lmgp_' . $action);
        foreach ($hidden as $k => $v) echo '<input type="hidden" name="' . esc_attr($k) . '" value="' . esc_attr($v) . '">';
        echo '<button class="button' . ($primary ? ' button-primary' : '') . '">' . esc_html($label) . '</button></form>';
    }

    private static function csv_link($id, $type, $market, $label) {
        $u = wp_nonce_url(add_query_arg(['action' => 'lmgp_csv', 'run' => $id, 'type' => $type, 'market' => $market], admin_url('admin-post.php')), 'lmgp_csv');
        return '<a class="button" href="' . esc_url($u) . '">' . esc_html($label) . '</a>';
    }

    private static function fmt_pos($p) {
        return $p === null ? '—' : esc_html(rtrim(rtrim(number_format((float) $p, 1, ',', ''), '0'), ','));
    }

    public static function render() {
        $s = LMGP_Settings::get();
        $markets = LMGP_Settings::markets($s);
        $runs = LMGP_Data::runs();
        $id = self::run_arg() ?: ($runs ? (int) array_key_first($runs) : 0);
        $run = $id ? LMGP_Data::run($id) : null;
        $market = sanitize_text_field(wp_unslash($_GET['market'] ?? ''));
        if ($market !== '' && !isset($markets[$market])) $market = '';
        $host = LMGP_Settings::host();

        if (is_admin()) update_user_meta(get_current_user_id(), 'lmgp_notes_seen', LMGP_VERSION);
        echo '<div class="wrap"><h1>Positioner — ' . esc_html($host) . '</h1>';
        echo '<p style="max-width:820px;">Hvor står vi i Google i dag, pr. sprog? Hvem ejer pladserne over os, og hvem annoncerer? '
           . 'Siden læser og foreslår; den ændrer intet indhold. Hvert forslag er dit at tage eller lade ligge.</p>';
        if (!empty($_GET['lmgp_msg'])) {
            echo '<div class="notice notice-info is-dismissible"><p>' . esc_html(sanitize_text_field(wp_unslash($_GET['lmgp_msg']))) . '</p></div>';
        }

        LMGP_Cockpit::render();

        // 1. Status
        $gsc = LMGP_Data::gsc_available();
        $dfs = LMGP_DFS::is_configured();
        echo '<h2>1. Forbindelser</h2><table class="widefat striped" style="max-width:820px;"><tbody>';
        echo '<tr><td style="width:220px;"><strong>Rank Math (Search Console)</strong></td><td>'
           . ($gsc ? '<span style="color:#1a7f37;">Data fundet.</span>' : '<span style="color:#d63638;">Ingen Rank Math-analysedata på denne side. Forbind Rank Math → Analytics med Search Console.</span>') . '</td></tr>';
        echo '<tr><td><strong>DataForSEO</strong></td><td>'
           . ($dfs ? 'Login gemt (delt med LeisureIntel).' : '<span style="color:#d63638;">Login mangler.</span>') . '</td></tr>';
        echo '<tr><td><strong>Markeder</strong></td><td>' . esc_html(implode(' · ', array_column($markets, 'label'))) . '</td></tr>';
        echo '</tbody></table><p>';
        if ($dfs) self::button('test', 'Test forbindelse og vis saldo', ['run' => $id]);
        echo '</p><details style="max-width:820px;"><summary>DataForSEO-login</summary>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="lmgp_creds"><input type="hidden" name="run" value="' . (int) $id . '">';
        wp_nonce_field('lmgp_creds');
        echo '<p>API-login (din e-mail) <input type="text" name="login" class="regular-text" autocomplete="off" value="' . esc_attr(get_option(LMGP_Settings::DFS_LOGIN, '')) . '"></p>';
        echo '<p>API-adgangskode <input type="password" name="password" class="regular-text" autocomplete="new-password" placeholder="' . ($dfs ? 'uændret' : '') . '"> '
           . '<span class="description">Fra app.dataforseo.com → API Access. Ikke din login-adgangskode.</span></p>';
        echo '<p><button class="button">Gem login</button></p></form></details>';

        // 2. Baseline
        echo '<h2>2. Baseline</h2><p style="max-width:820px;">Tager alle søgeord fra Search Console (sidste ' . (int) $s['window_days'] . ' dage, mindst '
           . (int) $s['min_impr'] . ' visninger) pr. sprog, plus listen over lande og rejseinteresser. Koster intet.</p><p>';
        self::button('baseline', 'Tag baseline nu', [], !$runs);
        echo '</p>';
        if ($runs) {
            echo '<p>Kørsel: ';
            foreach ($runs as $r) {
                $cur = ((int) $r['id'] === $id);
                echo '<a href="' . esc_url(self::url(['run' => $r['id']])) . '" class="button' . ($cur ? ' button-primary' : '') . '" style="margin:0 4px 4px 0;">#'
                   . (int) $r['id'] . ' · ' . esc_html(mysql2date('j. M Y H:i', $r['date'])) . '</a>';
            }
            echo '</p>';
        }
        if (!$run) { self::render_settings($s, $id); echo '</div>'; return; }

        echo '<p><strong>Kørsel #' . (int) $run['id'] . '</strong> · periode ' . esc_html($run['window']) . ' · ' . (int) $run['rows'] . ' søgeord'
           . (empty($run['gsc']) ? ' · <span style="color:#d63638;">uden Search Console-data</span>' : '') . '</p>';
        $b = LMGP_Data::buckets($id);
        echo '<table class="widefat striped" style="max-width:820px;"><thead><tr><th>Marked (Search Console)</th><th>Guld 1–10</th><th>heraf top 5</th><th>Sølv 11–20</th><th>Bronze 21–30</th><th>Øvrige 31+</th><th>Visninger</th><th>Klik</th></tr></thead><tbody>';
        foreach ($markets as $mk => $m) {
            if (!in_array($mk, (array) $run['markets'], true)) continue;
            $x = $b[$mk] ?? ['guld' => 0, 'top 5' => 0, 'sølv' => 0, 'bronze' => 0, 'øvrige' => 0, 'impr' => 0, 'clicks' => 0];
            echo '<tr><td>' . esc_html($m['label']) . '</td>';
            foreach (['guld', 'top 5', 'sølv', 'bronze', 'øvrige'] as $k) echo '<td>' . (int) $x[$k] . '</td>';
            echo '<td>' . number_format_i18n($x['impr']) . '</td><td>' . number_format_i18n($x['clicks']) . '</td></tr>';
        }
        echo '</tbody></table><p class="description" style="max-width:820px;">Search Console giver en gennemsnitsplacering på tværs af lande; engelsk tæller derfor ens for UK og US her. Google-placeringen pr. land står i tabellen nedenfor.</p>';

        // 3. Google results
        $p = LMGP_Data::progress($id);
        $cand = count(LMGP_Data::fetch_candidates($id));
        echo '<h2>3. Google-resultater (DataForSEO)</h2>';
        echo '<p style="max-width:820px;">Sender listen over lande og interesser og de ' . (int) $s['gsc_per_mkt'] . ' vigtigste søgeord på plads 4–20 pr. marked til Google. '
           . 'Viser top ' . (int) $s['depth'] . ', hvem der ligger over os, og hvem der annoncerer.</p>';
        echo '<p>Hentet: <strong>' . (int) $p['done'] . '</strong> · i kø: ' . (int) $p['posted'] . ' · fejl: ' . (int) $p['error'] . ' · klar til at sende: ' . (int) $cand . '</p><p>';
        if ($cand && $dfs) {
            $cost = LMGP_Data::estimate($cand);
            self::button('fetch', "Hent Google-resultater for {$cand} søgeord (ca. \${$cost})", ['run' => $id], true,
                "Send {$cand} søgeord til DataForSEO? Anslået pris ca. \${$cost} (standardkø, " . (int) $s['depth'] . " resultater pr. søgeord).");
        }
        if ($p['posted']) self::button('collect', 'Hent færdige resultater nu', ['run' => $id]);
        echo '</p>';

        // Market filter
        echo '<p>Vis: <a class="button' . ($market === '' ? ' button-primary' : '') . '" href="' . esc_url(self::url(['run' => $id])) . '">Alle</a> ';
        foreach ($markets as $mk => $m) {
            echo '<a class="button' . ($market === $mk ? ' button-primary' : '') . '" href="' . esc_url(self::url(['run' => $id, 'market' => $mk])) . '">' . esc_html($m['label']) . '</a> ';
        }
        echo '</p>';

        // 4. Slot owners and advertisers
        if ($p['done']) {
            $owners = LMGP_Data::owners($id, $market, 25);
            $ads = array_slice(LMGP_Data::advertisers($id, $market), 0, 25);
            echo '<div style="display:flex;gap:24px;flex-wrap:wrap;max-width:1200px;">';
            echo '<div style="flex:1;min-width:360px;"><h2>4. Hvem ejer pladserne over os</h2><table class="widefat striped"><thead><tr><th>Domæne</th><th>Søgeord over os</th><th>Gns. plads</th><th>Eksempler</th></tr></thead><tbody>';
            $big = LMGP_Settings::big_players($s);
            foreach ($owners as $o) {
                echo '<tr><td>' . esc_html($o['domain']) . (LMGP_Data::is_big($o['domain'], $big) ? ' <span class="description">(stor spiller)</span>' : '') . '</td><td>' . (int) $o['n'] . '</td><td>'
                   . self::fmt_pos($o['pos']) . '</td><td>' . esc_html(implode(', ', $o['kw'])) . '</td></tr>';
            }
            if (!$owners) echo '<tr><td colspan="4">Ingen endnu.</td></tr>';
            echo '</tbody></table><p>' . self::csv_link($id, 'owners', $market, 'Hent som CSV') . '</p></div>';
            echo '<div style="flex:1;min-width:360px;"><h2>5. Annoncører på vores søgeord</h2><table class="widefat striped"><thead><tr><th>Annoncør</th><th>Søgeord</th><th>Markeder</th><th>Eksempler</th></tr></thead><tbody>';
            foreach ($ads as $a) {
                echo '<tr><td>' . esc_html($a['domain']) . '</td><td>' . (int) $a['n'] . '</td><td>' . esc_html(implode(' ', array_keys($a['markets']))) . '</td><td>' . esc_html(implode(', ', array_slice($a['kw'], 0, 3))) . '</td></tr>';
            }
            if (!$ads) echo '<tr><td colspan="4">Ingen annoncer set endnu.</td></tr>';
            echo '</tbody></table><p>' . self::csv_link($id, 'ads', $market, 'Hent som CSV') . '</p></div></div>';
        }

        // 6. Keyword table
        $rows = LMGP_Data::rows($id, $market, 300);
        $big = LMGP_Settings::big_players($s);
        echo '<h2>6. Søgeord og forslag</h2><p>' . self::csv_link($id, 'rows', $market, 'Hent hele tabellen som CSV') . ' <span class="description">Viser højst 300 rækker her; CSV har alle.</span></p>';
        echo '<table class="widefat striped"><thead><tr><th>Marked</th><th>Søgeord</th><th>Kilde</th><th>GSC-plads</th><th>Visninger</th><th>Google-plads</th><th>Vores side</th><th>Top 3</th><th>Annoncører</th><th>Forslag</th></tr></thead><tbody>';
        foreach ($rows as $r) {
            $top = array_slice(LMGP_Data::top($r), 0, 3);
            $page = $r->serp_url !== '' ? $r->serp_url : $r->gsc_page;
            $gpos = $r->serp_status === 'done' ? ($r->serp_pos === null ? '>' . (int) $s['depth'] : (int) $r->serp_pos) : ($r->serp_status === 'posted' ? 'i kø' : '');
            echo '<tr><td>' . esc_html($r->market) . '</td><td>' . esc_html($r->keyword) . ((int) $r->track_only ? ' <span class="description">(kun måling)</span>' : '') . '</td>'
               . '<td>' . esc_html($r->source) . '</td><td>' . self::fmt_pos($r->gsc_pos) . '</td><td>' . (int) $r->gsc_impr . '</td><td>' . esc_html((string) $gpos) . '</td>'
               . '<td>' . ($page !== '' ? '<a href="' . esc_url($page) . '" target="_blank" rel="noopener">' . esc_html(wp_parse_url($page, PHP_URL_PATH) ?: '/') . '</a>' : '—') . '</td>'
               . '<td>' . esc_html(implode(', ', array_map(function ($o) { return $o[0] . '. ' . $o[1]; }, $top))) . '</td>'
               . '<td>' . esc_html(implode(', ', array_slice(array_unique(array_column(LMGP_Data::ads($r), 0)), 0, 3))) . '</td>'
               . '<td>' . esc_html(LMGP_Data::action($r, $big)) . '</td></tr>';
        }
        if (!$rows) echo '<tr><td colspan="10">Ingen søgeord i denne kørsel.</td></tr>';
        echo '</tbody></table>';

        self::render_settings($s, $id);
        LMGP_AIV::render();
        self::render_notes();
        echo '</div>';
    }

    /** One-time notice after an update, with a link to the release notes on the Positioner page. */
    public static function notice() {
        if (!current_user_can('manage_options') || get_user_meta(get_current_user_id(), 'lmgp_notes_seen', true) === LMGP_VERSION) return;
        if (isset($_GET['page']) && $_GET['page'] === self::SLUG) return;
        echo '<div class="notice notice-info"><p>LMG Positions er opdateret til ' . esc_html(LMGP_VERSION) . '. <a href="' . esc_url(self::url()) . '#lmgp-notes">Hvad er nyt</a></p></div>';
    }

    private static function render_notes() {
        $f = LMGP_DIR . 'RELEASE-NOTES.md';
        if (!is_readable($f)) return;
        echo '<h2 id="lmgp-notes" style="margin-top:32px;">Release notes</h2><div style="max-width:820px;background:#fff;padding:8px 16px;white-space:pre-wrap;">'
           . esc_html(file_get_contents($f)) . '</div>';
    }

    private static function render_settings($s, $id) {
        $langs = LMGP_Settings::langs($s['markets']);
        echo '<h2 style="margin-top:32px;">Indstillinger</h2><details style="max-width:1000px;"><summary>Markeder, søgeord-lister og grænser</summary>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="lmgp_settings"><input type="hidden" name="run" value="' . (int) $id . '">';
        wp_nonce_field('lmgp_settings');
        echo '<p><strong>Markeder</strong> — én pr. linje: <code>nøgle|sprog|location_code|language_code|navn</code>. Sproget matcher stien (/de/, /fr/ …); sider uden sprogsti tæller som første markeds sprog.</p>';
        echo '<textarea name="lmgp[markets]" rows="6" class="large-text code">' . esc_textarea($s['markets']) . '</textarea>';
        foreach ($langs as $l) {
            echo '<h3>Sprog: ' . esc_html($l) . '</h3><div style="display:flex;gap:12px;flex-wrap:wrap;">';
            echo '<div style="flex:1;min-width:240px;"><p>Skabeloner (<code>{x}</code> = land; <code>!</code> foran = kun måling)</p><textarea name="lmgp[templates][' . esc_attr($l) . ']" rows="6" class="large-text">' . esc_textarea($s['templates'][$l] ?? '') . '</textarea></div>';
            echo '<div style="flex:1;min-width:200px;"><p>Lande</p><textarea name="lmgp[countries][' . esc_attr($l) . ']" rows="6" class="large-text">' . esc_textarea($s['countries'][$l] ?? '') . '</textarea></div>';
            echo '<div style="flex:1;min-width:200px;"><p>Rejseinteresser (hele søgeord)</p><textarea name="lmgp[interests][' . esc_attr($l) . ']" rows="6" class="large-text">' . esc_textarea($s['interests'][$l] ?? '') . '</textarea></div></div>';
        }
        echo '<p><strong>Store spillere</strong> (dem vi ikke kan slå; del af domænet, én pr. linje)</p><textarea name="lmgp[big_players]" rows="5" class="large-text code">' . esc_textarea($s['big_players']) . '</textarea>';
        echo '<p>Periode <input type="number" name="lmgp[window_days]" value="' . (int) $s['window_days'] . '" min="7" max="90" style="width:70px"> dage · '
           . 'mindst <input type="number" name="lmgp[min_impr]" value="' . (int) $s['min_impr'] . '" min="1" style="width:70px"> visninger · '
           . 'GSC-søgeord til Google pr. marked <input type="number" name="lmgp[gsc_per_mkt]" value="' . (int) $s['gsc_per_mkt'] . '" min="0" max="500" style="width:70px"> · '
           . 'højst <input type="number" name="lmgp[max_tasks]" value="' . (int) $s['max_tasks'] . '" min="1" max="5000" style="width:80px"> søgeord pr. kørsel · '
           . 'dybde <select name="lmgp[depth]">';
        foreach ([10, 20, 30] as $d) echo '<option value="' . $d . '"' . selected((int) $s['depth'], $d, false) . '>top ' . $d . '</option>';
        echo '</select></p><p><button class="button button-primary">Gem indstillinger</button></p></form>';
        self::button('reset', 'Sæt tilbage til standard', ['run' => $id], false, 'Sæt alle indstillinger tilbage til standard?');
        echo '</details>';
    }
}
