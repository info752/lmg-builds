<?php
if (!defined('ABSPATH')) exit;

/**
 * LMGP_AIV — AI visibility: do ChatGPT and Perplexity (with web search) name or look at our pages
 * when asked travel questions? Live calls to DataForSEO's LLM Responses API, one call at a time from
 * the admin page, under a monthly spend cap. Reads and records only; changes no content.
 */
class LMGP_AIV {

    const OPT = 'lmgp_aiv';
    const ENGINES = [
        'chatgpt'    => ['label' => 'ChatGPT',    'path' => 'ai_optimization/chat_gpt/llm_responses'],
        'perplexity' => ['label' => 'Perplexity', 'path' => 'ai_optimization/perplexity/llm_responses'],
    ];

    const DEFAULT_QUESTIONS = [
        'traveltalk.dk' => "Hvor kan man stå på ski i Norge, og hvad koster en skiferie?\nHvor er de bedste skiområder i Østrig for en familie?\nHvilke ikoniske togrejser i Europa er værd at tage?\nHvad skal man vide før man rejser til Maldiverne?\nHvad er typisk filippinsk mad, og hvad skal man smage?\nHvad er en taverna i Grækenland?\nHvad kan man opleve i Danang i Vietnam, og hvad er Den Gyldne Bro?\nHvad er de mindste lande i Asien, og kan man rejse til dem?\nHvor kan man følge i Hemingways fodspor i Spanien?\nHvilke kunstrejser i Europa kan anbefales?\nHvilke rejsebureauer kan man bruge til gruppe- og rundrejser?\nHvilken rejseside kan man bruge til inspiration til ferie, hvis man kan lide kultur og mad?",
        'traveltalk.travel' => "What are the best things to do in Greece beyond the islands?\nWhat should I know before travelling to Cambodia and Angkor Wat?\nIs Singapore worth visiting for food and culture?\nWhat is a taverna in Greece and what should I order?\nWhich scenic train journeys in Europe are worth taking?\nWhat are the best ski resorts in Austria for beginners?\nWhere can I follow Hemingway's footsteps in Spain?\nWhich travel websites give good inspiration for culture and food trips?",
    ];

    public static function defaults() {
        $q = self::DEFAULT_QUESTIONS[LMGP_Settings::host()] ?? self::DEFAULT_QUESTIONS['traveltalk.dk'];
        return ['questions' => $q, 'cap' => 2.0, 'models' => ['chatgpt' => '', 'perplexity' => ''], 'runs' => [], 'spent' => []];
    }

    public static function get() {
        $o = get_option(self::OPT, []);
        $d = self::defaults();
        $o = is_array($o) ? array_merge($d, $o) : $d;
        $o['models'] = array_merge($d['models'], (array) $o['models']);
        return $o;
    }

    private static function save($o) { update_option(self::OPT, $o, false); }

    public static function questions($o = null) {
        $o = $o ?: self::get();
        $q = array_values(array_filter(array_map('trim', preg_split('/\R/', (string) $o['questions']))));
        return array_slice($q, 0, 40);
    }

    public static function month_spent($o = null) {
        $o = $o ?: self::get();
        return (float) ($o['spent'][gmdate('Y-m')] ?? 0);
    }

    /* ── DataForSEO ─────────────────────────────────────────────────────── */

    private static function call($method, $path, $body = null) {
        $args = ['method' => $method, 'timeout' => 90, 'headers' => [
            'Authorization' => 'Basic ' . base64_encode(get_option(LMGP_Settings::DFS_LOGIN, '') . ':' . get_option(LMGP_Settings::DFS_PASS, '')),
            'Content-Type'  => 'application/json',
        ]];
        if ($body !== null) $args['body'] = wp_json_encode($body);
        $r = wp_remote_request(LMGP_DFS::BASE . $path, $args);
        if (is_wp_error($r)) return $r;
        $j = json_decode(wp_remote_retrieve_body($r), true);
        if (!is_array($j)) return new WP_Error('lmgp_aiv', 'DataForSEO svarede ikke med JSON (HTTP ' . wp_remote_retrieve_response_code($r) . ').');
        if ((int) ($j['status_code'] ?? 0) !== 20000) return new WP_Error('lmgp_aiv', 'DataForSEO: ' . ($j['status_message'] ?? '?') . ' (' . ($j['status_code'] ?? '?') . ')');
        $t = $j['tasks'][0] ?? [];
        if ((int) ($t['status_code'] ?? 0) !== 20000) return new WP_Error('lmgp_aiv', 'DataForSEO: ' . ($t['status_message'] ?? '?') . ' (' . ($t['status_code'] ?? '?') . ')');
        return $j;
    }

    /** Model to use: the one set in Settings, else picked from DataForSEO's own model list (cheap-sounding first). */
    public static function model($engine, $o) {
        if (!empty($o['models'][$engine])) return $o['models'][$engine];
        $c = get_transient('lmgp_aiv_model_' . $engine);
        if ($c) return $c;
        $j = self::call('GET', self::ENGINES[$engine]['path'] . '/models');
        if (is_wp_error($j)) return $j;
        $names = [];
        foreach ((array) ($j['tasks'][0]['result'] ?? []) as $m) {
            $n = is_array($m) ? ($m['model_name'] ?? '') : (string) $m;
            if ($n !== '') $names[] = $n;
        }
        if (!$names) return new WP_Error('lmgp_aiv', 'Ingen modeller i svaret fra DataForSEO.');
        $pref = $engine === 'perplexity' ? ['sonar'] : ['mini', 'nano'];
        $pick = $names[0];
        foreach ($pref as $p) {
            foreach ($names as $n) { if (stripos($n, $p) !== false && stripos($n, 'pro') === false && stripos($n, 'deep') === false) { $pick = $n; break 2; } }
        }
        set_transient('lmgp_aiv_model_' . $engine, $pick, DAY_IN_SECONDS);
        return $pick;
    }

    /** Collect every URL and all answer text from a result, whatever the exact field layout. */
    private static function harvest($node, &$urls, &$text, $key = '') {
        if (is_array($node)) {
            foreach ($node as $k => $v) self::harvest($v, $urls, $text, (string) $k);
            return;
        }
        if (!is_string($node)) return;
        if ($key === 'url' || (strpos($node, 'http') === 0 && preg_match('#^https?://\S+$#', $node))) $urls[] = $node;
        elseif ($key === 'text' || $key === 'content') $text .= ' ' . $node;
    }

    /** One question to one engine. Returns the stored row. */
    public static function ask($engine, $question, $o) {
        $row = ['q' => $question, 'engine' => $engine, 'ok' => false, 'cost' => 0.0, 'model' => '', 'ours' => [], 'text_hit' => false, 'sources' => [], 'err' => ''];
        $model = self::model($engine, $o);
        if (is_wp_error($model)) { $row['err'] = $model->get_error_message(); return $row; }
        $row['model'] = $model;
        $body = ['user_prompt' => $question, 'model_name' => $model];
        if ($engine === 'chatgpt') $body['web_search'] = true;
        $j = self::call('POST', self::ENGINES[$engine]['path'] . '/live', [$body]);
        if (is_wp_error($j)) { $row['err'] = $j->get_error_message(); return $row; }
        $t = $j['tasks'][0];
        $row['cost'] = (float) ($t['cost'] ?? 0);
        $urls = []; $text = '';
        self::harvest($t['result'] ?? [], $urls, $text);
        $doms = [];
        foreach ($urls as $u) {
            $d = LMGP_DFS::domain(wp_parse_url($u, PHP_URL_HOST) ?: '');
            if ($d === '') continue;
            $doms[$d] = ($doms[$d] ?? 0) + 1;
            if (strpos($d, 'traveltalk.') === 0) $row['ours'][] = $u;
        }
        $row['ours'] = array_values(array_unique($row['ours']));
        $row['text_hit'] = (stripos($text, 'traveltalk') !== false);
        arsort($doms);
        $row['sources'] = array_slice(array_keys($doms), 0, 8);
        $row['ok'] = true;
        return $row;
    }

    /* ── Runs ───────────────────────────────────────────────────────────── */

    /** Start a run. $pilot = 3 questions on ChatGPT only. Returns run id. */
    public static function start($pilot, $engines) {
        $o = self::get();
        $qs = self::questions($o);
        if ($pilot) { $qs = array_slice($qs, 0, 3); $engines = array_slice($engines, 0, 1); }
        $jobs = [];
        foreach ($engines as $e) foreach ($qs as $q) $jobs[] = [$e, $q];
        $id = time();
        $o['runs'][$id] = ['id' => $id, 'pilot' => (bool) $pilot, 'jobs' => $jobs, 'rows' => [], 'done' => 0];
        krsort($o['runs']);
        $o['runs'] = array_slice($o['runs'], 0, 6, true);
        self::save($o);
        return $id;
    }

    /** Do the next job of a run. Returns progress array. */
    public static function step($id) {
        $o = self::get();
        if (empty($o['runs'][$id])) return ['error' => 'Kørslen findes ikke.'];
        $run = &$o['runs'][$id];
        $n = count($run['jobs']);
        if ($run['done'] >= $n) return ['done' => $n, 'total' => $n, 'finished' => true, 'spent' => self::month_spent($o)];
        if (self::month_spent($o) >= (float) $o['cap']) {
            return ['done' => $run['done'], 'total' => $n, 'finished' => true, 'capped' => true, 'spent' => self::month_spent($o)];
        }
        [$e, $q] = $run['jobs'][$run['done']];
        $row = self::ask($e, $q, $o);
        $run['rows'][] = $row;
        $run['done']++;
        $o['spent'][gmdate('Y-m')] = round(self::month_spent($o) + $row['cost'], 5);
        self::save($o);
        return ['done' => $run['done'], 'total' => $n, 'finished' => $run['done'] >= $n, 'spent' => $o['spent'][gmdate('Y-m')],
                'last' => ['engine' => $e, 'ok' => $row['ok'], 'err' => $row['err'], 'cost' => $row['cost']]];
    }

    public static function ajax_step() {
        if (!current_user_can('manage_options')) wp_send_json_error('Adgang nægtet.', 403);
        check_ajax_referer('lmgp_aiv');
        wp_send_json(self::step((int) ($_POST['run'] ?? 0)));
    }

    public static function handle_start() {
        if (!current_user_can('manage_options')) wp_die('Adgang nægtet.');
        check_admin_referer('lmgp_aiv_start');
        if (!LMGP_DFS::is_configured()) wp_safe_redirect(add_query_arg(['page' => LMGP_Admin::SLUG, 'lmgp_msg' => rawurlencode('Gem DataForSEO-login først.')], admin_url('admin.php')) . '#lmgp-aiv') && exit;
        $mode = sanitize_key($_POST['mode'] ?? 'pilot');
        $engines = $mode === 'pilot' ? ['chatgpt'] : array_values(array_intersect(array_keys(self::ENGINES), (array) ($_POST['engines'] ?? ['chatgpt', 'perplexity'])));
        if (!$engines) $engines = ['chatgpt'];
        $id = self::start($mode === 'pilot', $engines);
        wp_safe_redirect(add_query_arg(['page' => LMGP_Admin::SLUG, 'aiv_run' => $id, 'aiv_go' => 1], admin_url('admin.php')) . '#lmgp-aiv');
        exit;
    }

    public static function handle_settings() {
        if (!current_user_can('manage_options')) wp_die('Adgang nægtet.');
        check_admin_referer('lmgp_aiv_settings');
        $o = self::get();
        $o['questions'] = sanitize_textarea_field(wp_unslash($_POST['questions'] ?? ''));
        $o['cap'] = max(0.1, (float) ($_POST['cap'] ?? 2));
        foreach (['chatgpt', 'perplexity'] as $e) $o['models'][$e] = sanitize_text_field(wp_unslash($_POST['model_' . $e] ?? ''));
        self::save($o);
        delete_transient('lmgp_aiv_model_chatgpt');
        delete_transient('lmgp_aiv_model_perplexity');
        wp_safe_redirect(add_query_arg(['page' => LMGP_Admin::SLUG, 'lmgp_msg' => rawurlencode('AI-synlighed: indstillinger gemt.')], admin_url('admin.php')) . '#lmgp-aiv');
        exit;
    }

    public static function init() {
        add_action('wp_ajax_lmgp_aiv_step', [__CLASS__, 'ajax_step']);
        add_action('admin_post_lmgp_aiv_start', [__CLASS__, 'handle_start']);
        add_action('admin_post_lmgp_aiv_settings', [__CLASS__, 'handle_settings']);
    }

    /* ── Page section ───────────────────────────────────────────────────── */

    public static function render() {
        $o = self::get();
        $qs = self::questions($o);
        $spent = self::month_spent($o);
        $runId = (int) ($_GET['aiv_run'] ?? 0);
        $go = !empty($_GET['aiv_go']);
        if (!$runId && $o['runs']) $runId = (int) array_key_first($o['runs']);
        $run = $runId && isset($o['runs'][$runId]) ? $o['runs'][$runId] : null;

        echo '<h2 id="lmgp-aiv" style="margin-top:32px;">AI-synlighed (ChatGPT og Perplexity)</h2>';
        echo '<p style="max-width:820px;">Spørger ChatGPT og Perplexity (med websøgning) om rejsespørgsmål og tæller, hvor ofte vores sider nævnes eller er blandt de sider, de kigger på. Hvert kald koster penge hos DataForSEO; prisen læses fra DataForSEOs svar og lægges sammen her. Denne måned: <strong>$' . esc_html(number_format($spent, 3)) . '</strong> af loftet <strong>$' . esc_html(number_format((float) $o['cap'], 2)) . '</strong>. '
           . count($qs) . ' spørgsmål.</p>';

        if (LMGP_DFS::is_configured()) {
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="display:inline-block;margin-right:12px;"><input type="hidden" name="action" value="lmgp_aiv_start"><input type="hidden" name="mode" value="pilot">';
            wp_nonce_field('lmgp_aiv_start');
            echo '<button class="button button-primary">Pilot: 3 spørgsmål, kun ChatGPT</button></form>';
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="display:inline-block;" onsubmit="return confirm(\'Kør alle ' . count($qs) . ' spørgsmål på begge motorer? Det koster penge hos DataForSEO (loft: $' . esc_js(number_format((float) $o['cap'], 2)) . ').\')"><input type="hidden" name="action" value="lmgp_aiv_start"><input type="hidden" name="mode" value="full">';
            wp_nonce_field('lmgp_aiv_start');
            echo '<button class="button">Kør alle spørgsmål (ChatGPT + Perplexity)</button></form>';
        } else {
            echo '<p style="color:#d63638;">Gem DataForSEO-login under 1. Forbindelser først.</p>';
        }

        if ($run) {
            $n = count($run['jobs']);
            echo '<div id="lmgp-aiv-prog" style="margin:12px 0;max-width:820px;" data-run="' . (int) $run['id'] . '" data-go="' . ($go && $run['done'] < $n ? 1 : 0) . '" data-nonce="' . esc_attr(wp_create_nonce('lmgp_aiv')) . '" data-url="' . esc_url(admin_url('admin-ajax.php')) . '">'
               . '<strong>Kørsel ' . esc_html(gmdate('j/n Y H:i', $run['id'])) . ' UTC' . ($run['pilot'] ? ' (pilot)' : '') . ':</strong> <span class="lmgp-aiv-n">' . (int) $run['done'] . '</span> af ' . $n . ' kald <span class="lmgp-aiv-msg"></span></div>';

            $ok = array_filter($run['rows'], function ($r) { return $r['ok']; });
            $hits = array_filter($ok, function ($r) { return $r['ours'] || $r['text_hit']; });
            $cost = array_sum(array_column($run['rows'], 'cost'));
            if ($run['rows']) {
                echo '<p style="max-width:820px;">Nævnt eller set: <strong>' . count($hits) . '</strong> af ' . count($ok) . ' svar · pris for kørslen $' . esc_html(number_format($cost, 4))
                   . (count($ok) ? ' (≈ $' . esc_html(number_format($cost / max(1, count($ok)), 4)) . ' pr. svar)' : '') . '</p>';
                echo '<table class="widefat striped" style="max-width:1100px;"><thead><tr><th>Spørgsmål</th><th>Motor</th><th>Os?</th><th>Vores sider</th><th>Sider de kigger på</th><th>Pris</th></tr></thead><tbody>';
                foreach ($run['rows'] as $r) {
                    $us = !$r['ok'] ? '<span style="color:#d63638;">fejl</span>' : ($r['ours'] ? '<strong style="color:#1a7f37;">ja, link</strong>' : ($r['text_hit'] ? 'nævnt' : 'nej'));
                    echo '<tr><td>' . esc_html($r['q']) . '</td><td>' . esc_html(self::ENGINES[$r['engine']]['label']) . '<br><span class="description">' . esc_html($r['model']) . '</span></td><td>' . $us . '</td><td>'
                       . ($r['ok'] ? esc_html(implode(', ', array_map(function ($u) { return preg_replace('#^https?://(www\.)?#', '', $u); }, $r['ours']))) : esc_html($r['err']))
                       . '</td><td>' . esc_html(implode(', ', $r['sources'])) . '</td><td>$' . esc_html(number_format($r['cost'], 4)) . '</td></tr>';
                }
                echo '</tbody></table>';
            }
            echo '<script>(function(){var b=document.getElementById("lmgp-aiv-prog");if(!b)return;var n=b.querySelector(".lmgp-aiv-n"),m=b.querySelector(".lmgp-aiv-msg");'
               . 'function step(){var f=new FormData();f.append("action","lmgp_aiv_step");f.append("run",b.dataset.run);f.append("_ajax_nonce",b.dataset.nonce);'
               . 'fetch(b.dataset.url,{method:"POST",body:f,credentials:"same-origin"}).then(function(r){return r.json()}).then(function(j){'
               . 'if(j.error){m.textContent=j.error;return}n.textContent=j.done;'
               . 'if(j.capped){m.textContent="— stoppet: månedens loft er nået.";return}'
               . 'if(j.finished){m.textContent="— færdig. Genindlæser…";location.href=location.href.replace(/&aiv_go=1/,"")+"";return}'
               . 'if(j.last&&!j.last.ok){m.textContent="— fejl: "+j.last.err}else{m.textContent="— kører…"}step()}).catch(function(e){m.textContent="— afbrudt ("+e+"). Genindlæs for at fortsætte."})}'
               . 'if(b.dataset.go==="1"){m.textContent="— kører…";step()}})();</script>';
        }

        echo '<details style="max-width:1000px;margin-top:12px;"><summary>Spørgsmål, loft og modeller</summary>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="lmgp_aiv_settings">';
        wp_nonce_field('lmgp_aiv_settings');
        echo '<p>Spørgsmål, ét pr. linje (højst 40). De første 3 bruges i pilotkørslen.</p><textarea name="questions" rows="14" class="large-text">' . esc_textarea($o['questions']) . '</textarea>';
        echo '<p>Månedligt loft i USD <input type="number" step="0.1" min="0.1" name="cap" value="' . esc_attr($o['cap']) . '" style="width:80px"> <span class="description">Kørsler stopper, når månedens samlede pris når loftet.</span></p>';
        echo '<p>Model, ChatGPT <input type="text" name="model_chatgpt" value="' . esc_attr($o['models']['chatgpt']) . '" placeholder="tom = vælges automatisk"> &nbsp; Model, Perplexity <input type="text" name="model_perplexity" value="' . esc_attr($o['models']['perplexity']) . '" placeholder="tom = vælges automatisk"></p>';
        echo '<p><button class="button">Gem</button></p></form></details>';
    }
}
