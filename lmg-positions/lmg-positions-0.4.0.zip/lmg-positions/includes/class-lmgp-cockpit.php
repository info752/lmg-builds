<?php
if (!defined('ABSPATH')) exit;

/**
 * LMGP_Cockpit — "Overblik": one sweeping look per language. Where do we stand (gold 1–10, silver 11–20,
 * bronze 21–30, other 31+), are clicks rising or falling against the 28 days before, what to attack, what
 * to defend, and what the translations look like. Reads Rank Math's Search Console table, the
 * Translator's translation posts and, where LeisureIntel has it, GA4. Writes nothing but one cached copy.
 */
class LMGP_Cockpit {

    const CACHE = 'lmgp_cockpit';
    const TTL   = 6 * HOUR_IN_SECONDS;
    const DAYS  = 28;

    public static function init() {
        add_action('admin_post_lmgp_refresh', [__CLASS__, 'handle_refresh']);
    }

    public static function handle_refresh() {
        if (!current_user_can('manage_options')) wp_die('Adgang nægtet.');
        check_admin_referer('lmgp_refresh');
        delete_transient(self::CACHE);
        wp_safe_redirect(add_query_arg(['page' => LMGP_Admin::SLUG], admin_url('admin.php')));
        exit;
    }

    public static function metal($pos) {
        $p = (float) $pos;
        if ($p < 10.5) return 'guld';
        if ($p < 20.5) return 'sølv';
        if ($p < 30.5) return 'bronze';
        return 'øvrige';
    }

    /** Cached result of compute(); the cache is cleared by the refresh button or after six hours. */
    public static function get() {
        $c = get_transient(self::CACHE);
        if (is_array($c) && ($c['v'] ?? '') === LMGP_VERSION) return $c;
        $c = self::compute();
        $c['v'] = LMGP_VERSION;
        set_transient(self::CACHE, $c, self::TTL);
        return $c;
    }

    private static function page_lang($url, array $langs, $default) {
        $seg = strtolower(strtok(trim((string) wp_parse_url($url, PHP_URL_PATH), '/'), '/') ?: '');
        if ($seg === 'no') $seg = 'nb';
        if (in_array($seg, $langs, true)) return $seg;
        // A language prefix that is not one of ours (for example /en/ on .dk) is left out.
        return in_array($seg, LMGP_Data::LANG_PREFIXES, true) ? '' : $default;
    }

    public static function compute() {
        global $wpdb;
        $s = LMGP_Settings::get();
        $markets = LMGP_Settings::markets($s);
        if (!$markets) return ['error' => 'Ingen markeder sat op under Indstillinger.'];
        if (!LMGP_Data::gsc_available()) return ['error' => 'Ingen Rank Math-analysedata på denne side. Forbind Rank Math → Analytics med Search Console.'];
        $langs   = array_values(array_unique(array_column($markets, 'lang')));
        $default = reset($markets)['lang'];
        $t       = LMGP_Data::gsc_table();
        $min     = (int) $s['min_impr'];

        // Windows end on the newest day Search Console has delivered, not on today.
        $last = $wpdb->get_var("SELECT MAX(created) FROM {$t}");
        if (!$last) return ['error' => 'Rank Math har endnu ingen Search Console-data.'];
        $end   = strtotime(substr($last, 0, 10) . ' 00:00:00 UTC') + DAY_IN_SECONDS;
        $cur_a = gmdate('Y-m-d', $end - self::DAYS * DAY_IN_SECONDS);
        $cur_b = gmdate('Y-m-d', $end);
        $prv_a = gmdate('Y-m-d', $end - 2 * self::DAYS * DAY_IN_SECONDS);
        $out = [
            'built'  => current_time('mysql'),
            'window' => $cur_a . ' → ' . gmdate('Y-m-d', $end - DAY_IN_SECONDS),
            'prev'   => $prv_a . ' → ' . gmdate('Y-m-d', strtotime($cur_a . ' UTC') - DAY_IN_SECONDS),
            'min'    => $min,
            'langs'  => [],
        ];
        foreach ($langs as $l) {
            $out['langs'][$l] = ['clicks' => [0, 0], 'impr' => [0, 0], 'metals' => ['guld' => 0, 'sølv' => 0, 'bronze' => 0, 'øvrige' => 0], 'top5' => 0,
                                 'attack' => [], 'defend' => [], 'climb' => [], 'n_attack' => 0, 'n_defend' => 0, 'n_climb' => 0];
        }

        // Totals per language and window, from page totals.
        foreach ([[$cur_a, $cur_b, 0], [$prv_a, $cur_a, 1]] as $w) {
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT page, SUM(clicks) AS c, SUM(impressions) AS i FROM {$t} WHERE created >= %s AND created < %s GROUP BY page", $w[0], $w[1]
            ));
            foreach ((array) $rows as $r) {
                $l = self::page_lang($r->page, $langs, $default);
                if ($l === '' || !isset($out['langs'][$l])) continue;
                $out['langs'][$l]['clicks'][$w[2]] += (int) $r->c;
                $out['langs'][$l]['impr'][$w[2]]   += (int) $r->i;
            }
        }

        // Keywords per language and window (impression-weighted position).
        $kw = [];
        foreach ([[$cur_a, $cur_b, 'cur'], [$prv_a, $cur_a, 'prv']] as $w) {
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT query, page, SUM(impressions) AS i, SUM(clicks) AS c, SUM(position * impressions) AS pw
                 FROM {$t} WHERE created >= %s AND created < %s AND query <> '' GROUP BY query, page HAVING i > 0", $w[0], $w[1]
            ));
            foreach ((array) $rows as $r) {
                $l = self::page_lang($r->page, $langs, $default);
                if ($l === '' || !isset($out['langs'][$l])) continue;
                $key = $l . '|' . LMGP_Settings::norm($r->query);
                if (!isset($kw[$key])) $kw[$key] = ['l' => $l, 'q' => LMGP_Settings::norm($r->query), 'cur' => null, 'prv' => null, 'page' => '', 'pi' => -1];
                $x = &$kw[$key];
                if ($x[$w[2]] === null) $x[$w[2]] = ['i' => 0, 'c' => 0, 'pw' => 0.0];
                $x[$w[2]]['i']  += (int) $r->i;
                $x[$w[2]]['c']  += (int) $r->c;
                $x[$w[2]]['pw'] += (float) $r->pw;
                if ($w[2] === 'cur' && (int) $r->i > $x['pi']) { $x['page'] = $r->page; $x['pi'] = (int) $r->i; }
                unset($x);
            }
        }
        foreach ($kw as $x) {
            $L = &$out['langs'][$x['l']];
            $pc = $x['cur'] && $x['cur']['i'] > 0 ? $x['cur']['pw'] / $x['cur']['i'] : null;
            $pp = $x['prv'] && $x['prv']['i'] > 0 ? $x['prv']['pw'] / $x['prv']['i'] : null;
            $ic = $x['cur']['i'] ?? 0;
            $ip = $x['prv']['i'] ?? 0;
            $cc = $x['cur']['c'] ?? 0;
            $cp = $x['prv']['c'] ?? 0;
            if ($pc !== null && $ic >= $min) {
                $m = self::metal($pc);
                $L['metals'][$m]++;
                if ($pc < 5.5) $L['top5']++;
                if (($m === 'sølv' || $m === 'bronze') && $ic >= 20) {
                    $L['n_attack']++;
                    $L['attack'][] = ['q' => $x['q'], 'pos' => round($pc, 1), 'i' => $ic, 'c' => $cc, 'page' => $x['page'], 'metal' => $m];
                }
                if ($pp !== null && $ip >= $min && $pp - $pc >= 3) {
                    $L['n_climb']++;
                    $L['climb'][] = ['q' => $x['q'], 'from' => round($pp, 1), 'pos' => round($pc, 1), 'i' => $ic, 'c' => $cc, 'page' => $x['page']];
                }
            }
            // Defend: was gold, now lower by 1.5 places or more, gone, or clicks down 30 % (on at least 5 clicks).
            if ($pp !== null && $ip >= $min && $pp < 10.5) {
                $worse = $pc === null || $ic < $min || $pc - $pp >= 1.5;
                $less  = $cp >= 5 && $cc <= $cp * 0.7;
                if ($worse || $less) {
                    $L['n_defend']++;
                    $L['defend'][] = ['q' => $x['q'], 'from' => round($pp, 1), 'pos' => $pc === null ? null : round($pc, 1), 'c' => $cc, 'cp' => $cp, 'page' => $x['page']];
                }
            }
            unset($L);
        }
        foreach ($out['langs'] as $l => &$L) {
            usort($L['attack'], function ($a, $b) { return $b['i'] <=> $a['i']; });
            usort($L['defend'], function ($a, $b) { return $b['cp'] <=> $a['cp']; });
            usort($L['climb'],  function ($a, $b) { return ($b['from'] - $b['pos']) <=> ($a['from'] - $a['pos']); });
            $L['attack'] = array_slice($L['attack'], 0, 12);
            $L['defend'] = array_slice($L['defend'], 0, 12);
            $L['climb']  = array_slice($L['climb'], 0, 8);
            $L['verdict'] = self::verdict($L);
        }
        unset($L);
        $out['translations'] = self::translations();
        $out['ga4']          = self::ga4(['cur_a' => $cur_a, 'cur_b' => $cur_b, 'prv_a' => $prv_a]);
        $out['sources']      = self::sources();
        $out['last_day']     = substr($last, 0, 10);
        $out['default']      = $default;
        return $out;
    }

    /** [primary, [all that apply]]: dive first, then defend, attack, climb. Each is [code, label, why]. */
    public static function verdict(array $L) {
        list($c, $p) = $L['clicks'];
        list($ic, $ip) = $L['impr'];
        if ($c + $p + $ic + $ip === 0) return ['none', []];
        $all = [];
        if (($p >= 20 && $c < $p * 0.8) || ($ip >= 200 && $ic < $ip * 0.75)) {
            $why = $p >= 20 && $c < $p * 0.8 ? 'klik ' . self::pct($c, $p) : 'visninger ' . self::pct($ic, $ip);
            $all[] = ['dive', 'Dyk', $why];
        }
        if ($L['n_defend'] > 0) $all[] = ['defend', 'Forsvar', $L['n_defend'] . ' guld-søgeord taber plads eller klik'];
        if ($L['n_attack'] > 0) $all[] = ['attack', 'Angrib', $L['n_attack'] . ' sølv/bronze-søgeord med mange visninger'];
        if ($p >= 20 && $c >= $p * 1.2) $all[] = ['climb', 'Stig', 'klik ' . self::pct($c, $p)];
        return [$all ? $all[0][0] : 'hold', $all];
    }

    public static function pct($now, $before) {
        if ($before <= 0) return $now > 0 ? 'nyt' : '—';
        $d = round(($now - $before) / $before * 100);
        return ($d > 0 ? '+' : '') . $d . ' %';
    }

    /** Published translations per language on this site (copies already moved elsewhere left out). */
    public static function translations() {
        global $wpdb;
        if (!defined('LMGT_CPT')) return null;
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT l.meta_value AS lang, COUNT(*) AS n FROM {$wpdb->posts} p
             JOIN {$wpdb->postmeta} l ON l.post_id = p.ID AND l.meta_key = '_lmgt_lang'
             WHERE p.post_type = %s AND p.post_status = 'publish'
               AND NOT EXISTS (SELECT 1 FROM {$wpdb->postmeta} m WHERE m.post_id = p.ID AND m.meta_key = '_lmgt_moved_to' AND m.meta_value <> '')
             GROUP BY l.meta_value", LMGT_CPT
        ));
        $out = [];
        foreach ((array) $rows as $r) $out[$r->lang] = (int) $r->n;
        return $out;
    }

    /**
     * GA4 visits, last 28 days against the 28 before. First LeisureIntel's own GA4 connection (where it is set up),
     * else the copy Rank Math keeps of Google Analytics. Returns ['items' => [[label, cur, prv], …], 'note' => '…'],
     * ['error' => '…'], or null.
     */
    public static function ga4($win = null) {
        $li = null;
        if (class_exists('LI_GA4')) {
            $g = new LI_GA4();
            if ($g->is_configured()) {
                $r = $g->run_report([
                    'dateRanges' => [
                        ['startDate' => '28daysAgo', 'endDate' => 'yesterday', 'name' => 'cur'],
                        ['startDate' => '56daysAgo', 'endDate' => '29daysAgo', 'name' => 'prv'],
                    ],
                    'metrics' => [['name' => 'sessions'], ['name' => 'activeUsers']],
                ]);
                if (!is_wp_error($r)) {
                    $o = ['sessions' => [0, 0], 'users' => [0, 0]];
                    foreach ((array) ($r['rows'] ?? []) as $row) {
                        $name = $row['dimensionValues'][0]['value'] ?? '';
                        $k = ($name === 'prv' || $name === 'date_range_1') ? 1 : 0;
                        $o['sessions'][$k] = (int) ($row['metricValues'][0]['value'] ?? 0);
                        $o['users'][$k]    = (int) ($row['metricValues'][1]['value'] ?? 0);
                    }
                    return ['items' => [['sessioner', $o['sessions'][0], $o['sessions'][1]], ['brugere', $o['users'][0], $o['users'][1]]],
                            'note' => 'LeisureIntels GA4, ejendom ' . (string) get_option('li_ga4_property_id', '') . ', hele siden'];
                }
                $li = $r->get_error_message();
            }
        }
        $rm = $win ? self::ga_rankmath($win) : null;
        if ($rm && empty($rm['error'])) return $rm;
        if ($li !== null) return ['error' => 'LeisureIntels GA4: ' . $li . ($rm && !empty($rm['error']) ? ' · Rank Math: ' . $rm['error'] : '')];
        if ($rm && !empty($rm['error'])) return ['error' => 'Rank Math: ' . $rm['error'] . ' · LeisureIntels egen GA4 er ikke sat op'];
        return ['error' => 'ikke forbundet på denne side'];
    }

    /** All Rank Math analytics tables on this site: name, columns, approximate rows, first and last day. For the "Datakilder" panel. */
    public static function sources() {
        global $wpdb;
        $out = [];
        $like = $wpdb->esc_like($wpdb->prefix . 'rank_math_analytics') . '%';
        foreach ((array) $wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s', $like)) as $t) {
            if (!preg_match('/^[A-Za-z0-9_]+$/', $t)) continue;
            $cols = [];
            foreach ((array) $wpdb->get_results("SHOW COLUMNS FROM `{$t}`") as $c) $cols[] = $c->Field;
            $st = $wpdb->get_row($wpdb->prepare('SHOW TABLE STATUS LIKE %s', $t));
            $row = ['table' => substr($t, strlen($wpdb->prefix)), 'cols' => $cols, 'rows' => $st ? (int) $st->Rows : null, 'min' => null, 'max' => null];
            $dc = self::date_col($cols);
            if ($dc) {
                $m = $wpdb->get_row("SELECT MIN(`{$dc}`) AS a, MAX(`{$dc}`) AS b FROM `{$t}`");
                if ($m) { $row['min'] = substr((string) $m->a, 0, 10); $row['max'] = substr((string) $m->b, 0, 10); }
            }
            $out[] = $row;
        }
        return $out;
    }

    private static function date_col(array $cols) {
        foreach (['created', 'date', 'day', 'created_at'] as $c) if (in_array($c, $cols, true)) return $c;
        return '';
    }

    /** Rank Math's copy of Google Analytics: page views and visitors, summed over all pages and days in the two windows. */
    private static function ga_rankmath(array $win) {
        global $wpdb;
        $t = $wpdb->prefix . 'rank_math_analytics_ga';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) !== $t) return ['error' => 'ingen Google Analytics-data i Rank Math (modulet er ikke forbundet)'];
        $cols = [];
        foreach ((array) $wpdb->get_results("SHOW COLUMNS FROM `{$t}`") as $c) $cols[] = $c->Field;
        $dc = self::date_col($cols);
        $metrics = [];
        foreach ([['sessioner', ['sessions', 'visits']], ['besøgende', ['visitors', 'users']], ['sidevisninger', ['pageviews', 'views']]] as $m) {
            foreach ($m[1] as $col) if (in_array($col, $cols, true)) { $metrics[$m[0]] = $col; break; }
        }
        if (!$dc || !$metrics) return ['error' => 'tabellen ' . substr($t, strlen($wpdb->prefix)) . ' har ukendte kolonner (' . implode(', ', $cols) . ')'];
        $sel = [];
        foreach (array_values($metrics) as $i => $col) $sel[] = "COALESCE(SUM(`{$col}`),0) AS m{$i}";
        $items = [];
        $sums = [];
        foreach ([[$win['cur_a'], $win['cur_b']], [$win['prv_a'], $win['cur_a']]] as $k => $w) {
            $r = $wpdb->get_row($wpdb->prepare("SELECT " . implode(',', $sel) . " FROM `{$t}` WHERE `{$dc}` >= %s AND `{$dc}` < %s", $w[0], $w[1]), ARRAY_A);
            $sums[$k] = $r ?: [];
        }
        $i = 0;
        foreach ($metrics as $label => $col) {
            $items[] = [$label, (int) ($sums[0]['m' . $i] ?? 0), (int) ($sums[1]['m' . $i] ?? 0)];
            $i++;
        }
        $max = $wpdb->get_var("SELECT MAX(`{$dc}`) FROM `{$t}`");
        if (!array_sum(array_column($items, 1)) && !array_sum(array_column($items, 2))) return ['error' => 'Rank Math har ingen Google Analytics-rækker i perioden (seneste dag: ' . ($max ? substr($max, 0, 10) : 'ingen') . ')'];
        return ['items' => $items, 'note' => 'Rank Maths kopi af Google Analytics, hele siden; besøgende er summeret pr. side og dag, så samme person kan tælle flere gange'];
    }

    /* ── Page ─────────────────────────────────────────────────────────────── */

    private static function colour($code) {
        return ['dive' => '#d63638', 'defend' => '#b26200', 'attack' => '#2271b1', 'climb' => '#1a7f37', 'hold' => '#50575e', 'none' => '#8c8f94'][$code] ?? '#50575e';
    }

    private static function label($code) {
        return ['dive' => 'Dyk', 'defend' => 'Forsvar', 'attack' => 'Angrib', 'climb' => 'Stig', 'hold' => 'Hold kursen', 'none' => 'Ingen data'][$code] ?? '';
    }

    private static function delta($now, $before) {
        $p = self::pct($now, $before);
        $col = ($before > 0 && $now < $before) ? '#d63638' : (($before > 0 && $now > $before) ? '#1a7f37' : '#50575e');
        return '<span style="color:' . $col . ';">' . esc_html($p) . '</span>';
    }

    private static function page_link($url) {
        return $url === '' ? '—' : '<a href="' . esc_url($url) . '" target="_blank" rel="noopener">' . esc_html(wp_parse_url($url, PHP_URL_PATH) ?: '/') . '</a>';
    }

    public static function render() {
        $d = self::get();
        echo '<h2>Overblik</h2>';
        if (!empty($d['error'])) {
            echo '<p style="color:#d63638;">' . esc_html($d['error']) . '</p>';
            return;
        }
        $refresh = wp_nonce_url(add_query_arg(['action' => 'lmgp_refresh'], admin_url('admin-post.php')), 'lmgp_refresh');
        echo '<p style="max-width:900px;">Ét blik pr. sprog: guld 1–10, sølv 11–20, bronze 21–30, øvrige 31+. Seneste ' . (int) self::DAYS . ' dage (' . esc_html($d['window'])
           . ') mod de ' . (int) self::DAYS . ' før (' . esc_html($d['prev']) . '). Søgeord med mindst ' . (int) $d['min'] . ' visninger. Søgeordenes placering er Search Consoles gennemsnit, ikke et enkelt land. '
           . 'Opdateret ' . esc_html(mysql2date('j. M H:i', $d['built'])) . ' · <a href="' . esc_url($refresh) . '">Opdatér nu</a></p>';

        $s = LMGP_Settings::get();
        $runs = LMGP_Data::runs();
        $base = $runs ? LMGP_Data::run_metals((int) array_key_first($runs)) : [];
        $base_id = $runs ? (int) array_key_first($runs) : 0;

        echo '<table class="widefat striped" style="max-width:1200px;"><thead><tr><th>Sprog</th><th>Guld</th><th>Sølv</th><th>Bronze</th><th>Øvrige</th>'
           . '<th>Klik (28 d)</th><th>Visninger (28 d)</th><th>Oversættelser</th><th>Dom</th></tr></thead><tbody>';
        foreach ($d['langs'] as $l => $L) {
            list($code, $all) = $L['verdict'];
            echo '<tr><td><strong>' . esc_html($l) . '</strong></td>';
            foreach (['guld', 'sølv', 'bronze', 'øvrige'] as $m) {
                $n = (int) $L['metals'][$m];
                $extra = '';
                if ($m === 'guld') $extra = ' <span class="description">(top 5: ' . (int) $L['top5'] . ')</span>';
                if ($base_id && isset($base[$l][$m])) {
                    $diff = $n - (int) $base[$l][$m];
                    if ($diff !== 0) $extra .= ' <span class="description" title="Siden baseline #' . $base_id . '">' . ($diff > 0 ? '+' : '') . $diff . '</span>';
                }
                echo '<td>' . $n . $extra . '</td>';
            }
            echo '<td>' . number_format_i18n($L['clicks'][0]) . ' ' . self::delta($L['clicks'][0], $L['clicks'][1]) . '</td>';
            echo '<td>' . number_format_i18n($L['impr'][0]) . ' ' . self::delta($L['impr'][0], $L['impr'][1]) . '</td>';
            $tr = is_array($d['translations']) ? ($d['translations'][$l] ?? 0) : null;
            echo '<td>' . ($l === $d['default'] ? '<span class="description">original</span>' : ($tr === null ? '—' : (int) $tr)) . '</td>';
            echo '<td><strong style="color:' . esc_attr(self::colour($code)) . ';">' . esc_html(self::label($code)) . '</strong>';
            foreach ($all as $a) echo '<br><span class="description">' . esc_html($a[1] . ': ' . $a[2]) . '</span>';
            echo '</td></tr>';
        }
        echo '</tbody></table>';
        if ($base_id) echo '<p class="description">Små tal ved guld/sølv/bronze: ændring siden baseline #' . $base_id . ' (første sprog-marked). Dom: dyk hvis klik falder mere end 20 % (eller visninger 25 %), forsvar hvis guld-søgeord taber, angrib hvis sølv/bronze har mange visninger, stig hvis klik vokser mere end 20 %.</p>';

        $g = $d['ga4'];
        echo '<p><strong>Besøg (GA4):</strong> ';
        if ($g === null) echo 'ikke tilgængelig.';
        elseif (!empty($g['error'])) echo '<span style="color:#b26200;">' . esc_html($g['error']) . '</span>';
        else {
            $parts = [];
            foreach ($g['items'] as $it) $parts[] = number_format_i18n($it[1]) . ' ' . esc_html($it[0]) . ' ' . self::delta($it[1], $it[2]);
            echo implode(', ', $parts) . ' <span class="description">(' . esc_html($g['note']) . ')</span>';
        }
        echo '</p>';

        // Datakilder: what Rank Math has stored, and how fresh it is.
        $age = !empty($d['last_day']) ? (int) floor((time() - strtotime($d['last_day'] . ' 00:00:00 UTC')) / DAY_IN_SECONDS) : null;
        echo '<details style="max-width:1200px;margin-bottom:12px;"><summary><strong>Datakilder</strong>'
           . ($age !== null ? ' — Search Console-data i Rank Math går til ' . esc_html($d['last_day']) . ' (' . (int) $age . ' dage siden)' . ($age > 4 ? ' <span style="color:#b26200;">ældre end normalt</span>' : '') : '') . '</summary>';
        echo '<p class="description">Overblikket læser Rank Maths kopi af Googles data, ikke Google direkte. Rank Math henter nyt i omgange; Search Console ligger typisk 2–3 dage efter.</p>';
        if (empty($d['sources'])) echo '<p>Ingen Rank Math-analysetabeller fundet.</p>';
        else {
            echo '<table class="widefat striped"><thead><tr><th>Tabel</th><th>Rækker (ca.)</th><th>Første dag</th><th>Seneste dag</th><th>Kolonner</th></tr></thead><tbody>';
            foreach ($d['sources'] as $r) {
                echo '<tr><td>' . esc_html($r['table']) . '</td><td>' . ($r['rows'] === null ? '—' : number_format_i18n($r['rows'])) . '</td><td>' . esc_html($r['min'] ?: '—') . '</td><td>' . esc_html($r['max'] ?: '—') . '</td><td>' . esc_html(implode(', ', $r['cols'])) . '</td></tr>';
            }
            echo '</tbody></table>';
        }
        echo '</details>';

        foreach ($d['langs'] as $l => $L) {
            if (!$L['attack'] && !$L['defend'] && !$L['climb']) continue;
            echo '<details style="max-width:1200px;margin-bottom:8px;"><summary><strong>' . esc_html($l) . '</strong> — angrib, forsvar, stig</summary>';
            if ($L['defend']) {
                echo '<h4>Forsvar: guld der svækkes</h4><table class="widefat striped"><thead><tr><th>Søgeord</th><th>Før</th><th>Nu</th><th>Klik før → nu</th><th>Side</th></tr></thead><tbody>';
                foreach ($L['defend'] as $r) echo '<tr><td>' . esc_html($r['q']) . '</td><td>' . esc_html($r['from']) . '</td><td>' . ($r['pos'] === null ? 'væk' : esc_html($r['pos'])) . '</td><td>' . (int) $r['cp'] . ' → ' . (int) $r['c'] . '</td><td>' . self::page_link($r['page']) . '</td></tr>';
                echo '</tbody></table>';
            }
            if ($L['attack']) {
                echo '<h4>Angrib: sølv og bronze med flest visninger</h4><table class="widefat striped"><thead><tr><th>Søgeord</th><th>Metal</th><th>Plads</th><th>Visninger</th><th>Klik</th><th>Side</th></tr></thead><tbody>';
                foreach ($L['attack'] as $r) echo '<tr><td>' . esc_html($r['q']) . '</td><td>' . esc_html($r['metal']) . '</td><td>' . esc_html($r['pos']) . '</td><td>' . (int) $r['i'] . '</td><td>' . (int) $r['c'] . '</td><td>' . self::page_link($r['page']) . '</td></tr>';
                echo '</tbody></table>';
            }
            if ($L['climb']) {
                echo '<h4>Stig: søgeord der er rykket mindst 3 pladser op</h4><table class="widefat striped"><thead><tr><th>Søgeord</th><th>Før → nu</th><th>Visninger</th><th>Side</th></tr></thead><tbody>';
                foreach ($L['climb'] as $r) echo '<tr><td>' . esc_html($r['q']) . '</td><td>' . esc_html($r['from']) . ' → ' . esc_html($r['pos']) . '</td><td>' . (int) $r['i'] . '</td><td>' . self::page_link($r['page']) . '</td></tr>';
                echo '</tbody></table>';
            }
            echo '</details>';
        }
    }
}
