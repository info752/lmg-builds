<?php
if (!defined('ABSPATH')) exit;

/**
 * LMGP_Data — runs, the keyword table, baseline from Rank Math's GSC data, DataForSEO fetch/collect,
 * and the read-outs (buckets, slot owners, advertisers, proposed action).
 * Writes only to its own table and options. Never touches posts, pages, redirects or settings.
 */
class LMGP_Data {

    const RUNS = 'lmgp_runs';
    const CRON = 'lmgp_collect';
    const LANG_PREFIXES = ['da', 'en', 'de', 'fr', 'es', 'it', 'sv', 'nb', 'no', 'fi', 'nl', 'pt', 'pl', 'is', 'el', 'tr', 'ja', 'zh', 'ko', 'ru'];
    const PRICE_PER_PAGE = 0.0006; // USD, standard queue, per 10 results (DataForSEO pricing page, Oct 2026)

    public static function table() {
        global $wpdb;
        return $wpdb->prefix . 'lmgp_rows';
    }

    public static function gsc_table() {
        global $wpdb;
        return $wpdb->prefix . 'rank_math_analytics_gsc';
    }

    public static function init() {
        add_action(self::CRON, [__CLASS__, 'collect']);
    }

    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE " . self::table() . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            run_id INT UNSIGNED NOT NULL,
            market VARCHAR(20) NOT NULL,
            lang VARCHAR(8) NOT NULL,
            keyword VARCHAR(255) NOT NULL,
            source VARCHAR(8) NOT NULL,
            track_only TINYINT(1) NOT NULL DEFAULT 0,
            gsc_pos DECIMAL(6,1) NULL,
            gsc_impr INT UNSIGNED NOT NULL DEFAULT 0,
            gsc_clicks INT UNSIGNED NOT NULL DEFAULT 0,
            gsc_page VARCHAR(500) NOT NULL DEFAULT '',
            task_id VARCHAR(64) NOT NULL DEFAULT '',
            serp_status VARCHAR(10) NOT NULL DEFAULT 'none',
            serp_pos SMALLINT NULL,
            serp_url VARCHAR(500) NOT NULL DEFAULT '',
            top_json LONGTEXT NULL,
            ads_json TEXT NULL,
            posted_at DATETIME NULL,
            fetched_at DATETIME NULL,
            PRIMARY KEY  (id),
            KEY run_market (run_id, market),
            KEY serp (serp_status)
        ) {$charset};");
        update_option('lmgp_db_version', LMGP_DB_VERSION, false);
    }

    public static function maybe_upgrade() {
        if (get_option('lmgp_db_version') !== LMGP_DB_VERSION) self::install();
    }

    public static function deactivate() {
        wp_clear_scheduled_hook(self::CRON);
    }

    /* ── Runs ─────────────────────────────────────────────────────────────── */

    public static function runs() {
        $r = get_option(self::RUNS, []);
        return is_array($r) ? $r : [];
    }

    public static function run($id) {
        $r = self::runs();
        return $r[$id] ?? null;
    }

    private static function save_run(array $run) {
        $all = self::runs();
        $all[$run['id']] = $run;
        krsort($all);
        update_option(self::RUNS, $all, false);
    }

    public static function gsc_available() {
        global $wpdb;
        $t = self::gsc_table();
        return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) === $t;
    }

    /** Language of a page from its first path segment (/de/, /fr/ …); otherwise the site's main language. */
    private static function page_lang($url, array $langs, $default) {
        $path = trim((string) wp_parse_url($url, PHP_URL_PATH), '/');
        $seg = strtolower(strtok($path, '/') ?: '');
        // A known language prefix that is not one of our markets (e.g. /en/ on .dk) is returned as is, so it is left out.
        return (in_array($seg, $langs, true) || in_array($seg, self::LANG_PREFIXES, true)) ? $seg : $default;
    }

    /**
     * Take a baseline: every GSC keyword (last N days, ≥ min impressions) per language, plus the seed list.
     * Costs nothing. Returns the run or WP_Error.
     */
    public static function take_baseline() {
        global $wpdb;
        $s = LMGP_Settings::get();
        $markets = LMGP_Settings::markets($s);
        if (!$markets) return new WP_Error('lmgp', 'Ingen markeder sat op under Indstillinger.');
        $langs = array_values(array_unique(array_column($markets, 'lang')));
        $default = reset($markets)['lang'];

        $since = gmdate('Y-m-d', time() - (int) $s['window_days'] * DAY_IN_SECONDS);
        $gsc = [];
        if (self::gsc_available()) {
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT query, page, SUM(impressions) AS i, SUM(clicks) AS c,
                        SUM(position * impressions) AS pw, AVG(position) AS ap
                 FROM " . self::gsc_table() . "
                 WHERE created >= %s AND query <> ''
                 GROUP BY query, page",
                $since
            ));
            foreach ((array) $rows as $r) {
                $lang = self::page_lang($r->page, $langs, $default);
                if (!in_array($lang, $langs, true)) continue;
                $kw = LMGP_Settings::norm($r->query);
                $k = $lang . '|' . $kw;
                $i = (int) $r->i;
                if (!isset($gsc[$k])) $gsc[$k] = ['lang' => $lang, 'kw' => $kw, 'i' => 0, 'c' => 0, 'pw' => 0.0, 'ap' => (float) $r->ap, 'page' => '', 'page_i' => -1];
                $g = &$gsc[$k];
                $g['i']  += $i;
                $g['c']  += (int) $r->c;
                $g['pw'] += (float) $r->pw;
                if ($i > $g['page_i']) { $g['page'] = $r->page; $g['page_i'] = $i; }
                unset($g);
            }
        }

        $runs = self::runs();
        $id = $runs ? max(array_keys($runs)) + 1 : 1;
        $values = [];
        $count = 0;
        foreach ($markets as $m) {
            $seeds = LMGP_Settings::seeds($m['lang'], $s);
            $seen = [];
            foreach ($gsc as $g) {
                if ($g['lang'] !== $m['lang'] || $g['i'] < (int) $s['min_impr']) continue;
                $pos = $g['i'] > 0 ? round($g['pw'] / $g['i'], 1) : round($g['ap'], 1);
                $is_seed = array_key_exists($g['kw'], $seeds);
                $values[] = [$id, $m['key'], $m['lang'], $g['kw'], $is_seed ? 'both' : 'gsc', $is_seed && $seeds[$g['kw']] ? 1 : 0, $pos, $g['i'], $g['c'], $g['page']];
                $seen[$g['kw']] = true;
            }
            foreach ($seeds as $kw => $track) {
                if (isset($seen[$kw])) continue;
                $values[] = [$id, $m['key'], $m['lang'], $kw, 'seed', $track ? 1 : 0, null, 0, 0, ''];
            }
        }
        foreach (array_chunk($values, 200) as $chunk) {
            $ph = [];
            $args = [];
            foreach ($chunk as $v) {
                $ph[] = $v[6] === null ? '(%d,%s,%s,%s,%s,%d,NULL,%d,%d,%s)' : '(%d,%s,%s,%s,%s,%d,%f,%d,%d,%s)';
                foreach ($v as $j => $x) { if (!($j === 6 && $x === null)) $args[] = $x; }
            }
            $wpdb->query($wpdb->prepare(
                "INSERT INTO " . self::table() . " (run_id, market, lang, keyword, source, track_only, gsc_pos, gsc_impr, gsc_clicks, gsc_page) VALUES " . implode(',', $ph),
                $args
            ));
            $count += count($chunk);
        }

        $run = [
            'id'      => $id,
            'date'    => current_time('mysql'),
            'window'  => $since . ' → ' . current_time('Y-m-d'),
            'rows'    => $count,
            'gsc'     => self::gsc_available(),
            'markets' => array_keys($markets),
        ];
        self::save_run($run);
        return $run;
    }

    /* ── Google results via DataForSEO ───────────────────────────────────── */

    /** Rows that a fetch would send: all seeds + the top GSC keywords at positions 4–20 per market. */
    public static function fetch_candidates($run_id) {
        global $wpdb;
        $s = LMGP_Settings::get();
        $t = self::table();
        $ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM {$t} WHERE run_id = %d AND serp_status = 'none' AND source IN ('seed','both') ORDER BY id",
            $run_id
        ));
        foreach (array_keys(LMGP_Settings::markets($s)) as $mk) {
            $ids = array_merge($ids, $wpdb->get_col($wpdb->prepare(
                "SELECT id FROM {$t} WHERE run_id = %d AND market = %s AND serp_status = 'none' AND source = 'gsc'
                   AND gsc_pos >= 3.5 AND gsc_pos < 20.5 ORDER BY gsc_impr DESC LIMIT %d",
                $run_id, $mk, (int) $s['gsc_per_mkt']
            )));
        }
        return array_slice(array_map('intval', $ids), 0, (int) $s['max_tasks']);
    }

    public static function estimate($n) {
        $pages = (int) ceil(LMGP_Settings::get()['depth'] / 10);
        return round($n * $pages * self::PRICE_PER_PAGE, 2);
    }

    /** Post the candidate rows to DataForSEO. Returns ['posted'=>n, 'errors'=>[...]] or WP_Error. */
    public static function fetch($run_id) {
        global $wpdb;
        if (!LMGP_DFS::is_configured()) return new WP_Error('lmgp', 'DataForSEO-login mangler.');
        $s = LMGP_Settings::get();
        $markets = LMGP_Settings::markets($s);
        $ids = self::fetch_candidates($run_id);
        if (!$ids) return ['posted' => 0, 'errors' => []];
        @set_time_limit(300);
        $t = self::table();
        $posted = 0;
        $errors = [];
        foreach (array_chunk($ids, 100) as $chunk) {
            $rows = $wpdb->get_results("SELECT id, market, keyword FROM {$t} WHERE id IN (" . implode(',', $chunk) . ")");
            $tasks = [];
            foreach ($rows as $r) {
                if (!isset($markets[$r->market])) continue;
                $tasks[] = [
                    'keyword'       => $r->keyword,
                    'location_code' => $markets[$r->market]['location'],
                    'language_code' => $markets[$r->market]['language'],
                    'device'        => 'desktop',
                    'depth'         => (int) $s['depth'],
                    'tag'           => (string) $r->id,
                ];
            }
            if (!$tasks) continue;
            $res = LMGP_DFS::post_tasks($tasks);
            if (is_wp_error($res)) { $errors[] = $res->get_error_message(); break; }
            foreach ($res as $tag => $task) {
                if (is_wp_error($task)) {
                    $errors[] = $task->get_error_message();
                    $wpdb->update($t, ['serp_status' => 'error'], ['id' => (int) $tag]);
                    continue;
                }
                $wpdb->update($t, ['task_id' => $task, 'serp_status' => 'posted', 'posted_at' => current_time('mysql')], ['id' => (int) $tag]);
                $posted++;
            }
        }
        if ($posted && !wp_next_scheduled(self::CRON)) wp_schedule_single_event(time() + 5 * MINUTE_IN_SECONDS, self::CRON);
        $run = self::run($run_id);
        if ($run) { $run['fetched'] = current_time('mysql'); self::save_run($run); }
        return ['posted' => $posted, 'errors' => array_values(array_unique($errors))];
    }

    /** Collect finished tasks (reads only). Runs from cron every 5 minutes while anything is pending. */
    public static function collect($limit = 40) {
        global $wpdb;
        if (!LMGP_DFS::is_configured()) return 0;
        $t = self::table();
        $host = LMGP_Settings::host();
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, task_id, posted_at FROM {$t} WHERE serp_status = 'posted' ORDER BY id LIMIT %d", $limit
        ));
        $done = 0;
        foreach ((array) $rows as $r) {
            $res = LMGP_DFS::get_task($r->task_id);
            if (is_wp_error($res)) {
                if (strtotime($r->posted_at) < current_time('timestamp') - 3 * DAY_IN_SECONDS) {
                    $wpdb->update($t, ['serp_status' => 'error'], ['id' => $r->id]);
                }
                continue;
            }
            if (!empty($res['pending'])) continue;
            $pos = null;
            $url = '';
            foreach ($res['organic'] as $o) {
                if ($o[1] === $host || substr($o[1], -strlen('.' . $host)) === '.' . $host) { $pos = $o[0]; $url = $o[2]; break; }
            }
            $wpdb->update($t, [
                'serp_status' => 'done',
                'serp_pos'    => $pos,
                'serp_url'    => $url,
                'top_json'    => wp_json_encode($res['organic']),
                'ads_json'    => wp_json_encode($res['paid']),
                'fetched_at'  => current_time('mysql'),
            ], ['id' => $r->id]);
            $done++;
        }
        $left = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE serp_status = 'posted'");
        if ($left && !wp_next_scheduled(self::CRON)) wp_schedule_single_event(time() + 5 * MINUTE_IN_SECONDS, self::CRON);
        return $done;
    }

    /* ── Read-outs ───────────────────────────────────────────────────────── */

    public static function progress($run_id) {
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT serp_status, COUNT(*) AS n FROM " . self::table() . " WHERE run_id = %d GROUP BY serp_status", $run_id
        ));
        $out = ['none' => 0, 'posted' => 0, 'done' => 0, 'error' => 0];
        foreach ((array) $rows as $r) $out[$r->serp_status] = (int) $r->n;
        return $out;
    }

    /** G's metals (29 Oct–31 Oct 2026): gold 1–10, silver 11–20, bronze 21–30, other 31+. */
    public static function bucket($pos) {
        if ($pos === null) return 'øvrige';
        $p = (float) $pos;
        if ($p < 10.5) return 'guld';
        if ($p < 20.5) return 'sølv';
        if ($p < 30.5) return 'bronze';
        return 'øvrige';
    }

    /** GSC baseline per market: keyword counts per position bucket (GSC-sourced rows only). */
    public static function buckets($run_id) {
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT market, gsc_pos, gsc_impr, gsc_clicks FROM " . self::table() . " WHERE run_id = %d AND source IN ('gsc','both')", $run_id
        ));
        $out = [];
        foreach ((array) $rows as $r) {
            $b = self::bucket($r->gsc_pos);
            if (!isset($out[$r->market])) $out[$r->market] = ['guld' => 0, 'top 5' => 0, 'sølv' => 0, 'bronze' => 0, 'øvrige' => 0, 'impr' => 0, 'clicks' => 0];
            $out[$r->market][$b]++;
            if ($r->gsc_pos !== null && (float) $r->gsc_pos < 5.5) $out[$r->market]['top 5']++;
            $out[$r->market]['impr']   += (int) $r->gsc_impr;
            $out[$r->market]['clicks'] += (int) $r->gsc_clicks;
        }
        return $out;
    }

    /** Metal counts per language for one run, from the first market of each language (Search Console does not split countries). */
    public static function run_metals($run_id) {
        global $wpdb;
        $first = [];
        foreach (LMGP_Settings::markets() as $mk => $m) { if (!isset($first[$m['lang']])) $first[$m['lang']] = $mk; }
        $out = [];
        foreach ($first as $lang => $mk) {
            $out[$lang] = ['guld' => 0, 'sølv' => 0, 'bronze' => 0, 'øvrige' => 0];
            $rows = $wpdb->get_col($wpdb->prepare(
                "SELECT gsc_pos FROM " . self::table() . " WHERE run_id = %d AND market = %s AND source IN ('gsc','both') AND gsc_pos IS NOT NULL", $run_id, $mk
            ));
            foreach ((array) $rows as $p) $out[$lang][self::bucket($p)]++;
        }
        return $out;
    }

    public static function rows($run_id, $market = '', $limit = 0) {
        global $wpdb;
        $sql = "SELECT * FROM " . self::table() . " WHERE run_id = %d";
        $args = [$run_id];
        if ($market !== '') { $sql .= ' AND market = %s'; $args[] = $market; }
        $sql .= " ORDER BY (serp_status = 'done') DESC, gsc_impr DESC, keyword";
        if ($limit) { $sql .= ' LIMIT %d'; $args[] = $limit; }
        return $wpdb->get_results($wpdb->prepare($sql, $args)) ?: [];
    }

    /** Our current position: Google's (when fetched) else GSC's average. */
    public static function our_pos($r) {
        if ($r->serp_status === 'done') return $r->serp_pos === null ? null : (int) $r->serp_pos;
        return $r->gsc_pos === null ? null : (float) $r->gsc_pos;
    }

    public static function top($r) {
        $t = json_decode((string) $r->top_json, true);
        return is_array($t) ? $t : [];
    }

    public static function ads($r) {
        $a = json_decode((string) $r->ads_json, true);
        return is_array($a) ? $a : [];
    }

    public static function is_big($domain, array $big) {
        foreach ($big as $b) { if ($b !== '' && strpos($domain, $b) !== false) return true; }
        return false;
    }

    /** Proposed action — a proposal for G, never applied. */
    public static function action($r, array $big) {
        if ((int) $r->track_only) return 'Kun måling (annoncører)';
        $pos = self::our_pos($r);
        if ($r->serp_status === 'done' && ($pos === null || $pos > 10)) {
            $big5 = 0;
            foreach (array_slice(self::top($r), 0, 5) as $o) { if (self::is_big($o[1], $big)) $big5++; }
            if ($big5 >= 4) return 'Uden for rækkevidde – kun måling';
        }
        if ($pos !== null && $pos < 3.5)  return 'Hold pladsen';
        if ($pos !== null && $pos < 10.5) return 'Mod top 5: titel, metabeskrivelse, links fra hub';
        if ($pos !== null && $pos < 20.5) return 'Mod top 10: udfyld huller mod top 3';
        if ($r->gsc_page !== '' || $r->serp_url !== '') return 'Omskriv eller udbyg siden';
        return 'Ny side – hvis emnet er værd at eje';
    }

    /** Who holds the slots above us: domain → keywords where it ranks above us (top 10). */
    public static function owners($run_id, $market = '', $limit = 30) {
        $host = LMGP_Settings::host();
        $out = [];
        foreach (self::rows($run_id, $market) as $r) {
            if ($r->serp_status !== 'done' || (int) $r->track_only) continue;
            $ours = $r->serp_pos === null ? 11 : (int) $r->serp_pos;
            foreach (self::top($r) as $o) {
                if ($o[0] >= $ours || $o[0] > 10 || $o[1] === $host) continue;
                if (!isset($out[$o[1]])) $out[$o[1]] = ['domain' => $o[1], 'n' => 0, 'pos' => 0, 'kw' => []];
                $out[$o[1]]['n']++;
                $out[$o[1]]['pos'] += $o[0];
                if (count($out[$o[1]]['kw']) < 3 && !in_array($r->keyword, $out[$o[1]]['kw'], true)) $out[$o[1]]['kw'][] = $r->keyword;
            }
        }
        foreach ($out as &$d) $d['pos'] = round($d['pos'] / $d['n'], 1);
        unset($d);
        usort($out, function ($a, $b) { return $b['n'] <=> $a['n']; });
        return array_slice($out, 0, $limit);
    }

    /** Advertisers on our keywords: domain → keywords and markets. The ad-sales list. */
    public static function advertisers($run_id, $market = '') {
        $out = [];
        foreach (self::rows($run_id, $market) as $r) {
            if ($r->serp_status !== 'done') continue;
            foreach (self::ads($r) as $a) {
                if ($a[0] === '') continue;
                if (!isset($out[$a[0]])) $out[$a[0]] = ['domain' => $a[0], 'n' => 0, 'markets' => [], 'kw' => []];
                $out[$a[0]]['n']++;
                $out[$a[0]]['markets'][$r->market] = true;
                if (count($out[$a[0]]['kw']) < 5 && !in_array($r->keyword, $out[$a[0]]['kw'], true)) $out[$a[0]]['kw'][] = $r->keyword;
            }
        }
        usort($out, function ($a, $b) { return $b['n'] <=> $a['n']; });
        return $out;
    }
}
