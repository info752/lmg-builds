<?php
/*
Plugin Name: LMG Positions
Description: Positioner — overblik (guld/sølv/bronze, dyk/forsvar/angrib/stig pr. sprog), AI-synlighed (ChatGPT og Perplexity), baseline af vores Google-placeringer pr. sprog (Rank Math GSC-data), hvem der ejer pladserne over os, hvem der annoncerer, og et forslag til handling pr. søgeord. Læser og foreslår; ændrer intet indhold. Vises under LeisureIntel-menuen.
Version: 0.4.0
Author: Leisure Media Group Ltd
Requires PHP: 7.4
*/

if (!defined('ABSPATH')) exit;

define('LMGP_VERSION', '0.4.0');
define('LMGP_DB_VERSION', '1');
define('LMGP_DIR', plugin_dir_path(__FILE__));

require_once LMGP_DIR . 'includes/class-lmgp-settings.php';
require_once LMGP_DIR . 'includes/class-lmgp-dfs.php';
require_once LMGP_DIR . 'includes/class-lmgp-data.php';
require_once LMGP_DIR . 'includes/class-lmgp-aiv.php';
require_once LMGP_DIR . 'includes/class-lmgp-cockpit.php';
require_once LMGP_DIR . 'includes/class-lmgp-admin.php';

register_activation_hook(__FILE__, ['LMGP_Data', 'install']);
register_deactivation_hook(__FILE__, ['LMGP_Data', 'deactivate']);

function lmg_positions_init() {
    LMGP_Data::maybe_upgrade();
    LMGP_Data::init();   // cron: collects finished DataForSEO tasks (reads only)
    LMGP_Cockpit::init();
    LMGP_AIV::init();
    LMGP_Admin::init();  // submenu under LeisureIntel, or Tools if LeisureIntel is inactive
}
add_action('plugins_loaded', 'lmg_positions_init');
