<?php
/**
 * Plugin Name: LMG Rank Math Keywords
 * Description: LMG SEO menu. Svage sider finds strong posts with weak Rank Math scores (missing hub/internal/external links, bare country keyword) and fixes them one post at a time. Fokusnøgleord fills empty Rank Math focus keywords.
 * Version: 1.1.0
 * Author: Leisure Media Group
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Text Domain: lmg-rmk
 */

defined( 'ABSPATH' ) || exit;

define( 'LMG_RMK_VERSION', '1.1.0' );
define( 'LMG_RMK_META', 'rank_math_focus_keyword' );
define( 'LMG_RMK_DIR', plugin_dir_path( __FILE__ ) );

require_once LMG_RMK_DIR . 'includes/class-generator.php';
require_once LMG_RMK_DIR . 'includes/class-admin.php';
require_once LMG_RMK_DIR . 'includes/class-notes.php';
require_once LMG_RMK_DIR . 'includes/class-menu.php';
require_once LMG_RMK_DIR . 'includes/class-weak.php';

LMG_RMK_Admin::init();
LMG_RMK_Notes::boot();
LMG_RMK_Menu::init();
LMG_RMK_Weak::init();

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	require_once LMG_RMK_DIR . 'includes/class-cli.php';
	WP_CLI::add_command( 'lmg-rmk', 'LMG_RMK_CLI' );
}
