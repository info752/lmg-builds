<?php
defined( 'ABSPATH' ) || exit;

class LMG_RMK_Generator {

	const OPT = 'lmg_rmk_settings';

	private static $places = null;

	public static function defaults() {
		return array(
			'post_types' => array(),
			'statuses'   => array( 'publish', 'future', 'draft', 'pending', 'private' ),
			'extra'      => 2,
			'places'     => '',
			'home'       => "danmark\ndenmark\ndänemark",
			'auto_save'  => 1,
			'overwrite'  => 0,
		);
	}

	public static function settings() {
		$s = wp_parse_args( (array) get_option( self::OPT, array() ), self::defaults() );
		if ( empty( $s['post_types'] ) ) {
			$s['post_types'] = self::all_post_types();
		}
		return $s;
	}

	public static function all_post_types() {
		$types = get_post_types( array( 'public' => true ), 'names' );
		unset( $types['attachment'] );
		return array_values( $types );
	}

	private static function lower( $s ) {
		return function_exists( 'mb_strtolower' ) ? mb_strtolower( $s, 'UTF-8' ) : strtolower( $s );
	}

	public static function clean( $s ) {
		$s = wp_strip_all_tags( html_entity_decode( (string) $s, ENT_QUOTES, 'UTF-8' ) );
		$s = preg_replace( '/[^\p{L}\p{N}\s\-]+/u', ' ', $s );
		return trim( preg_replace( '/\s+/u', ' ', self::lower( $s ) ) );
	}

	public static function places() {
		if ( null !== self::$places ) {
			return self::$places;
		}
		$list = array();
		foreach ( (array) include LMG_RMK_DIR . 'includes/countries.php' as $row ) {
			foreach ( explode( '|', $row ) as $name ) {
				$list[] = self::lower( trim( $name ) );
			}
		}
		$s = self::settings();
		foreach ( preg_split( '/[\r\n,]+/', (string) $s['places'] ) as $name ) {
			$name = trim( $name );
			if ( '' !== $name ) {
				$list[] = self::lower( $name );
			}
		}
		$list = array_unique( array_filter( apply_filters( 'lmg_rmk_places', $list ) ) );
		usort(
			$list,
			function ( $a, $b ) {
				return mb_strlen( $b ) - mb_strlen( $a );
			}
		);
		self::$places = $list;
		return $list;
	}

	private static function home() {
		$s = self::settings();
		return array_filter( array_map( 'trim', preg_split( '/[\r\n,]+/', self::lower( (string) $s['home'] ) ) ) );
	}

	private static function stopwords() {
		return apply_filters(
			'lmg_rmk_stopwords',
			array( 'og', 'i', 'på', 'til', 'fra', 'med', 'for', 'af', 'en', 'et', 'den', 'det', 'de', 'der', 'som', 'er', 'at', 'om', 'din', 'dit', 'dine', 'vores', 'her', 'så', 'hvad', 'hvor', 'hvordan', 'hvorfor', 'bedste', 'guide', 'alt', 'du', 'skal', 'vide', 'the', 'and', 'of', 'to', 'in', 'on', 'for', 'a', 'an', 'with', 'from', 'your', 'our', 'what', 'how', 'why', 'best', 'all', 'you', 'need', 'know', 'is', 'are', 'der', 'die', 'das', 'und', 'nach', 'mit', 'von', 'im', 'ein', 'eine', 'für', 'zu', 'auf', 'ihr', 'ihre', 'alles', 'beste', 'besten' )
		);
	}

	public static function find_place( $text, $skip_home = false ) {
		$text = ' ' . self::clean( $text ) . ' ';
		$home = $skip_home ? self::home() : array();
		foreach ( self::places() as $p ) {
			if ( $skip_home && in_array( $p, $home, true ) ) {
				continue;
			}
			if ( preg_match( '/(?<![\p{L}\p{N}])' . preg_quote( $p, '/' ) . '(?![\p{L}\p{N}])/u', $text ) ) {
				return $p;
			}
		}
		return '';
	}

	private static function most_frequent_place( $text ) {
		$text = ' ' . self::clean( $text ) . ' ';
		$home = self::home();
		$best = '';
		$max  = 0;
		foreach ( self::places() as $p ) {
			if ( in_array( $p, $home, true ) ) {
				continue;
			}
			$n = preg_match_all( '/(?<![\p{L}\p{N}])' . preg_quote( $p, '/' ) . '(?![\p{L}\p{N}])/u', $text );
			if ( $n > $max ) {
				$max  = $n;
				$best = $p;
			}
		}
		return $max >= 2 ? $best : '';
	}

	public static function title_phrase( $title ) {
		$parts = preg_split( '/\s*[:|–—]\s*|\s+-\s+/u', html_entity_decode( (string) $title, ENT_QUOTES, 'UTF-8' ) );
		$title = $parts[0];
		$words = array_values( array_filter( explode( ' ', self::clean( $title ) ), 'strlen' ) );
		$stop  = self::stopwords();
		while ( $words && in_array( reset( $words ), $stop, true ) ) {
			array_shift( $words );
		}
		while ( $words && in_array( end( $words ), $stop, true ) ) {
			array_pop( $words );
		}
		if ( count( $words ) > 5 ) {
			$words = array_slice( array_values( array_diff( $words, $stop ) ), 0, 4 );
		}
		$words = array_values( $words );
		$phrase = trim( implode( ' ', $words ) );
		return ( count( $words ) >= 2 && mb_strlen( $phrase ) <= 60 ) ? $phrase : '';
	}

	public static function term_names( $post ) {
		$names   = array();
		$primary = (int) get_post_meta( $post->ID, 'rank_math_primary_category', true );
		if ( $primary ) {
			$t = get_term( $primary );
			if ( $t && ! is_wp_error( $t ) ) {
				$names[] = $t->name;
			}
		}
		foreach ( get_object_taxonomies( $post->post_type, 'objects' ) as $tax ) {
			if ( ! $tax->public || in_array( $tax->name, array( 'post_format', 'language', 'post_translations' ), true ) ) {
				continue;
			}
			$terms = get_the_terms( $post->ID, $tax->name );
			if ( $terms && ! is_wp_error( $terms ) ) {
				foreach ( $terms as $t ) {
					$names[] = $t->name;
				}
			}
		}
		$skip = array( 'uncategorized', 'ikke kategoriseret', 'ukategoriseret', 'allgemein', 'unkategorisiert' );
		$out  = array();
		foreach ( $names as $n ) {
			$n = self::clean( $n );
			if ( '' !== $n && ! in_array( $n, $skip, true ) && mb_strlen( $n ) <= 50 ) {
				$out[] = $n;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * @return string[] Keywords, main first.
	 */
	public static function suggest( $post ) {
		$post = get_post( $post );
		if ( ! $post ) {
			return array();
		}
		$s     = self::settings();
		$title = $post->post_title;
		$terms = self::term_names( $post );

		$main = self::find_place( $title );
		if ( '' === $main ) {
			$main = self::find_place( implode( ' ', $terms ), true );
		}
		if ( '' === $main ) {
			$main = self::find_place( str_replace( '-', ' ', $post->post_name ), true );
		}
		if ( '' === $main ) {
			$main = self::most_frequent_place( mb_substr( wp_strip_all_tags( $post->post_content ), 0, 8000 ) );
		}

		$cands = array();
		$phrase = self::title_phrase( $title );
		if ( '' !== $phrase ) {
			$cands[] = $phrase;
		}
		foreach ( $terms as $t ) {
			$cands[] = ( '' !== $main && false === mb_strpos( $t, $main ) && ! in_array( $t, self::places(), true ) ) ? $t . ' ' . $main : $t;
		}
		if ( '' === $main && '' === $phrase && '' !== self::clean( $title ) ) {
			$cands[] = self::clean( $title );
		}

		$kw = array();
		// 1.1.0: a bare country belongs to the country page. Posts lead with a longer phrase and keep the place second.
		if ( '' !== $main && 'page' !== $post->post_type ) {
			$long = self::longer_keyword( $post, $main );
			if ( '' !== $long ) {
				$kw[] = $long;
			}
		}
		if ( '' !== $main ) {
			$kw[] = $main;
		}
		foreach ( $cands as $c ) {
			if ( count( $kw ) >= 1 + (int) $s['extra'] ) {
				break;
			}
			if ( '' !== $c && ! in_array( $c, $kw, true ) ) {
				$kw[] = $c;
			}
		}
		return array_slice( apply_filters( 'lmg_rmk_suggest', $kw, $post ), 0, 1 + (int) $s['extra'] );
	}

	/** True when the keyword is only a place name (country, region, city from the list) or the post's own category name. */
	public static function is_bare_place( $keyword, $post = null ) {
		$k = self::clean( $keyword );
		if ( '' === $k ) {
			return false;
		}
		if ( in_array( $k, self::places(), true ) ) {
			return true;
		}
		if ( $post ) {
			foreach ( get_the_category( $post->ID ) as $c ) {
				if ( self::clean( $c->name ) === $k && false === strpos( $k, ' ' ) ) {
					return true;
				}
			}
		}
		return false;
	}

	/** A 2-5 word keyword that contains the place: the title phrase, else a category + place, else "rejser til <place>". */
	public static function longer_keyword( $post, $place ) {
		$post  = get_post( $post );
		$place = self::clean( $place );
		if ( ! $post || '' === $place ) {
			return '';
		}
		$re     = '/(?<![\p{L}\p{N}])' . preg_quote( $place, '/' ) . '(?![\p{L}\p{N}])/u';
		$head   = preg_split( '/[,?!.]\s/u', html_entity_decode( (string) $post->post_title, ENT_QUOTES, 'UTF-8' ) . ' ' );
		$phrase = self::title_phrase( trim( $head[0] ) );
		if ( '' !== $phrase && $phrase !== $place && preg_match( $re, $phrase ) && substr_count( $phrase, ' ' ) <= 4 ) {
			return $phrase;
		}
		foreach ( self::term_names( $post ) as $t ) {
			if ( $t !== $place && ! in_array( $t, self::places(), true ) && false === strpos( $t, $place ) && substr_count( $t, ' ' ) <= 2 ) {
				return $t . ' ' . $place;
			}
		}
		if ( '' !== $phrase && $phrase !== $place && substr_count( $phrase, ' ' ) <= 3 ) {
			return $phrase . ' ' . $place;
		}
		return apply_filters( 'lmg_rmk_travel_prefix', 'rejser til', $post ) . ' ' . $place;
	}

	public static function has_keyword( $post_id ) {
		return '' !== trim( (string) get_post_meta( $post_id, LMG_RMK_META, true ) );
	}

	public static function save( $post_id, $keywords ) {
		if ( is_array( $keywords ) ) {
			$keywords = implode( ',', $keywords );
		}
		$parts = array_filter( array_map( 'trim', explode( ',', wp_strip_all_tags( (string) $keywords ) ) ) );
		if ( ! $parts ) {
			return false;
		}
		update_post_meta( $post_id, LMG_RMK_META, implode( ',', array_unique( $parts ) ) );
		return true;
	}

	public static function query_args( $post_type = '', $paged = 1, $per_page = 50, $fields = '' ) {
		$s    = self::settings();
		$args = array(
			'post_type'              => $post_type ? array( $post_type ) : $s['post_types'],
			'post_status'            => $s['statuses'],
			'posts_per_page'         => $per_page,
			'paged'                  => max( 1, (int) $paged ),
			'orderby'                => 'date',
			'order'                  => 'DESC',
			'no_found_rows'          => false,
			'update_post_term_cache' => true,
			'suppress_filters'       => true,
			'lang'                   => '',
			'meta_query'             => array(
				'relation' => 'OR',
				array(
					'key'     => LMG_RMK_META,
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'   => LMG_RMK_META,
					'value' => '',
				),
			),
		);
		if ( $fields ) {
			$args['fields'] = $fields;
		}
		return $args;
	}

	public static function count_missing( $post_type = '' ) {
		$q = new WP_Query( self::query_args( $post_type, 1, 1, 'ids' ) );
		return (int) $q->found_posts;
	}

	/**
	 * Fills one batch. Always reads page 1 since filled posts drop out of the query.
	 */
	public static function fill_batch( $limit = 50, $post_type = '', $dry = false, $offset = 0 ) {
		$args = self::query_args( $post_type, 1, $limit, '' );
		if ( $offset ) {
			$args['offset'] = (int) $offset;
		}
		$q = new WP_Query( $args );
		$done = array();
		$skip = array();
		foreach ( $q->posts as $p ) {
			$kw = self::suggest( $p );
			if ( ! $kw ) {
				$skip[] = $p->ID;
				continue;
			}
			if ( ! $dry ) {
				self::save( $p->ID, $kw );
			}
			$done[ $p->ID ] = implode( ',', $kw );
		}
		return array(
			'done'      => $done,
			'skipped'   => $skip,
			'remaining' => max( 0, (int) $q->found_posts - (int) $offset - count( $done ) - count( $skip ) ),
		);
	}
}
