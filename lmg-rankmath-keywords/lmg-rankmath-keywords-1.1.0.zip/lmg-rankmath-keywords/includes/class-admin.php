<?php
defined( 'ABSPATH' ) || exit;

class LMG_RMK_Admin {

	const SLUG = 'lmg-rmk';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 20 );
		add_action( 'admin_init', array( __CLASS__, 'handle_post' ) );
		add_action( 'wp_ajax_lmg_rmk_fill', array( __CLASS__, 'ajax_fill' ) );
		add_action( 'wp_after_insert_post', array( __CLASS__, 'on_save' ), 99, 2 );
		add_filter( 'plugin_action_links_' . plugin_basename( LMG_RMK_DIR . 'lmg-rankmath-keywords.php' ), array( __CLASS__, 'links' ) );
	}

	public static function links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '">Åbn</a>' );
		return $links;
	}

	public static function menu() {
		add_submenu_page( LMG_RMK_Menu::SLUG, 'Fokusnøgleord', 'Fokusnøgleord', 'edit_others_posts', self::SLUG, array( __CLASS__, 'page' ) );
	}

	public static function on_save( $post_id, $post ) {
		$s = LMG_RMK_Generator::settings();
		if ( empty( $s['auto_save'] ) || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}
		if ( ! in_array( $post->post_type, $s['post_types'], true ) || ! in_array( $post->post_status, array( 'publish', 'future' ), true ) ) {
			return;
		}
		if ( LMG_RMK_Generator::has_keyword( $post_id ) ) {
			return;
		}
		$kw = LMG_RMK_Generator::suggest( $post );
		if ( $kw ) {
			LMG_RMK_Generator::save( $post_id, $kw );
		}
	}

	public static function handle_post() {
		if ( empty( $_POST['lmg_rmk_action'] ) || ! current_user_can( 'edit_others_posts' ) ) {
			return;
		}
		check_admin_referer( 'lmg_rmk' );
		$action = sanitize_key( $_POST['lmg_rmk_action'] );
		$back   = wp_get_referer() ? wp_get_referer() : admin_url( 'admin.php?page=' . self::SLUG );

		if ( 'settings' === $action && current_user_can( 'manage_options' ) ) {
			$all = LMG_RMK_Generator::all_post_types();
			$pt  = isset( $_POST['post_types'] ) ? array_values( array_intersect( array_map( 'sanitize_key', (array) $_POST['post_types'] ), $all ) ) : array();
			$st  = isset( $_POST['statuses'] ) ? array_values( array_intersect( array_map( 'sanitize_key', (array) $_POST['statuses'] ), array( 'publish', 'future', 'draft', 'pending', 'private' ) ) ) : array( 'publish' );
			update_option(
				LMG_RMK_Generator::OPT,
				array(
					'post_types' => $pt,
					'statuses'   => $st ? $st : array( 'publish' ),
					'extra'      => min( 4, max( 0, (int) $_POST['extra'] ) ),
					'places'     => sanitize_textarea_field( wp_unslash( $_POST['places'] ) ),
					'home'       => sanitize_textarea_field( wp_unslash( $_POST['home'] ) ),
					'auto_save'  => empty( $_POST['auto_save'] ) ? 0 : 1,
				)
			);
			wp_safe_redirect( add_query_arg( 'lmg_msg', 'saved', $back ) );
			exit;
		}

		if ( 'save_selected' === $action ) {
			$n   = 0;
			$sel = isset( $_POST['sel'] ) ? array_map( 'absint', (array) $_POST['sel'] ) : array();
			$kws = isset( $_POST['kw'] ) ? (array) wp_unslash( $_POST['kw'] ) : array();
			foreach ( $sel as $id ) {
				if ( $id && isset( $kws[ $id ] ) && current_user_can( 'edit_post', $id ) && LMG_RMK_Generator::save( $id, sanitize_text_field( $kws[ $id ] ) ) ) {
					$n++;
				}
			}
			wp_safe_redirect( add_query_arg( array( 'lmg_msg' => 'filled', 'n' => $n ), $back ) );
			exit;
		}
	}

	public static function ajax_fill() {
		check_ajax_referer( 'lmg_rmk_ajax' );
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			wp_send_json_error( 'forbidden', 403 );
		}
		$type   = isset( $_POST['post_type'] ) ? sanitize_key( $_POST['post_type'] ) : '';
		$offset = isset( $_POST['offset'] ) ? absint( $_POST['offset'] ) : 0;
		$r      = LMG_RMK_Generator::fill_batch( 40, $type, false, $offset );
		wp_send_json_success(
			array(
				'filled'    => count( $r['done'] ),
				'skipped'   => count( $r['skipped'] ),
				'remaining' => $r['remaining'],
			)
		);
	}

	public static function page() {
		$s     = LMG_RMK_Generator::settings();
		$type  = isset( $_GET['pt'] ) ? sanitize_key( $_GET['pt'] ) : '';
		if ( $type && ! in_array( $type, $s['post_types'], true ) ) {
			$type = '';
		}
		$paged = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		$q     = new WP_Query( LMG_RMK_Generator::query_args( $type, $paged, 50 ) );
		$base  = admin_url( 'admin.php?page=' . self::SLUG );
		$rm    = defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' );
		?>
		<div class="wrap">
			<h1>Rank Math nøgleord <a class="page-title-action" href="<?php echo esc_url( admin_url( 'admin.php?page=lmg-rmk-notes' ) ); ?>">Release notes</a></h1>
			<?php if ( ! $rm ) : ?>
				<div class="notice notice-warning"><p>Rank Math ser ikke ud til at være aktiv. Nøgleord gemmes alligevel i <code>rank_math_focus_keyword</code>.</p></div>
			<?php endif; ?>
			<?php if ( isset( $_GET['lmg_msg'] ) && 'saved' === $_GET['lmg_msg'] ) : ?>
				<div class="notice notice-success is-dismissible"><p>Indstillinger gemt.</p></div>
			<?php elseif ( isset( $_GET['lmg_msg'] ) && 'filled' === $_GET['lmg_msg'] ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo (int) $_GET['n']; ?> indlæg fik fokusnøgleord.</p></div>
			<?php endif; ?>

			<h2>Mangler fokusnøgleord</h2>
			<table class="widefat striped" style="max-width:520px">
				<tbody>
				<?php
				$total = 0;
				foreach ( $s['post_types'] as $t ) :
					$n      = LMG_RMK_Generator::count_missing( $t );
					$total += $n;
					$obj    = get_post_type_object( $t );
					?>
					<tr>
						<td><a href="<?php echo esc_url( add_query_arg( 'pt', $t, $base ) ); ?>"><?php echo esc_html( $obj ? $obj->labels->name : $t ); ?></a> <code><?php echo esc_html( $t ); ?></code></td>
						<td style="text-align:right"><strong><?php echo (int) $n; ?></strong></td>
					</tr>
				<?php endforeach; ?>
				<tr><td><a href="<?php echo esc_url( $base ); ?>"><strong>I alt</strong></a></td><td style="text-align:right"><strong id="lmg-rmk-total"><?php echo (int) $total; ?></strong></td></tr>
				</tbody>
			</table>

			<p style="margin-top:16px">
				<button type="button" class="button button-primary" id="lmg-rmk-fill" <?php disabled( 0, $type ? (int) $q->found_posts : $total ); ?>>
					<?php echo $type ? 'Udfyld alle ' . esc_html( $type ) . ' automatisk' : 'Udfyld alle automatisk'; ?>
				</button>
				<span id="lmg-rmk-progress" style="margin-left:10px"></span>
			</p>
			<p class="description">Eksisterende nøgleord røres aldrig. Hovednøgleordet er land/destination fra titel, kategori/tags, slug eller tekst; derefter op til <?php echo (int) $s['extra']; ?> ekstra fra titel og kategorier.</p>

			<h2 style="margin-top:28px">Forhåndsvisning<?php echo $type ? ' – ' . esc_html( $type ) : ''; ?> (<?php echo (int) $q->found_posts; ?>)</h2>
			<form method="post">
				<?php wp_nonce_field( 'lmg_rmk' ); ?>
				<input type="hidden" name="lmg_rmk_action" value="save_selected">
				<table class="widefat striped">
					<thead><tr>
						<td class="check-column"><input type="checkbox" id="lmg-rmk-all" checked></td>
						<th>Titel</th><th style="width:110px">Type</th><th style="width:90px">Status</th><th style="width:45%">Foreslåede nøgleord (kommasepareret, første = hovednøgleord)</th>
					</tr></thead>
					<tbody>
					<?php if ( ! $q->posts ) : ?>
						<tr><td colspan="5">Alle indlæg har fokusnøgleord.</td></tr>
					<?php endif; ?>
					<?php foreach ( $q->posts as $p ) : $kw = implode( ', ', LMG_RMK_Generator::suggest( $p ) ); ?>
						<tr>
							<th class="check-column"><input type="checkbox" name="sel[]" value="<?php echo (int) $p->ID; ?>" <?php checked( '' !== $kw ); ?>></th>
							<td><a href="<?php echo esc_url( get_edit_post_link( $p->ID ) ); ?>"><?php echo esc_html( get_the_title( $p ) ? get_the_title( $p ) : '(uden titel)' ); ?></a></td>
							<td><?php echo esc_html( $p->post_type ); ?></td>
							<td><?php echo esc_html( $p->post_status ); ?></td>
							<td><input type="text" class="large-text" name="kw[<?php echo (int) $p->ID; ?>]" value="<?php echo esc_attr( $kw ); ?>"></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<p>
					<?php submit_button( 'Gem valgte', 'primary', 'submit', false ); ?>
					<?php
					$pages = (int) $q->max_num_pages;
					if ( $pages > 1 ) {
						echo '<span style="margin-left:16px">' . paginate_links(
							array(
								'base'    => add_query_arg( 'paged', '%#%' ),
								'format'  => '',
								'current' => $paged,
								'total'   => $pages,
							)
						) . '</span>';
					}
					?>
				</p>
			</form>

			<?php if ( current_user_can( 'manage_options' ) ) : ?>
			<h2 style="margin-top:28px">Indstillinger</h2>
			<form method="post">
				<?php wp_nonce_field( 'lmg_rmk' ); ?>
				<input type="hidden" name="lmg_rmk_action" value="settings">
				<table class="form-table">
					<tr><th>Indholdstyper</th><td>
						<?php foreach ( LMG_RMK_Generator::all_post_types() as $t ) : ?>
							<label style="margin-right:14px"><input type="checkbox" name="post_types[]" value="<?php echo esc_attr( $t ); ?>" <?php checked( in_array( $t, $s['post_types'], true ) ); ?>> <?php echo esc_html( $t ); ?></label>
						<?php endforeach; ?>
						<p class="description">Ingen valgt = alle offentlige typer.</p>
					</td></tr>
					<tr><th>Statusser</th><td>
						<?php foreach ( array( 'publish', 'future', 'draft', 'pending', 'private' ) as $st ) : ?>
							<label style="margin-right:14px"><input type="checkbox" name="statuses[]" value="<?php echo esc_attr( $st ); ?>" <?php checked( in_array( $st, $s['statuses'], true ) ); ?>> <?php echo esc_html( $st ); ?></label>
						<?php endforeach; ?>
					</td></tr>
					<tr><th>Ekstra nøgleord</th><td><input type="number" min="0" max="4" name="extra" value="<?php echo (int) $s['extra']; ?>" class="small-text"> ud over hovednøgleordet</td></tr>
					<tr><th>Ekstra destinationer</th><td><textarea name="places" rows="5" class="large-text" placeholder="Bali&#10;Toscana&#10;Mallorca"><?php echo esc_textarea( $s['places'] ); ?></textarea><p class="description">Én pr. linje. Regioner, øer og byer der skal kunne blive hovednøgleord (lande på dansk, engelsk og tysk er indbygget).</p></td></tr>
					<tr><th>Hjemland</th><td><textarea name="home" rows="3" class="large-text"><?php echo esc_textarea( $s['home'] ); ?></textarea><p class="description">Ignoreres i kategorier og brødtekst (fx "fly fra Danmark"), men bruges hvis det står i titlen.</p></td></tr>
					<tr><th>Ved udgivelse</th><td><label><input type="checkbox" name="auto_save" value="1" <?php checked( ! empty( $s['auto_save'] ) ); ?>> Udfyld automatisk når et indlæg uden nøgleord udgives eller opdateres</label></td></tr>
				</table>
				<?php submit_button( 'Gem indstillinger' ); ?>
			</form>
			<?php endif; ?>
		</div>
		<script>
		(function(){
			var all=document.getElementById('lmg-rmk-all');
			if(all){all.addEventListener('change',function(){document.querySelectorAll('input[name="sel[]"]').forEach(function(c){c.checked=all.checked;});});}
			var btn=document.getElementById('lmg-rmk-fill'),out=document.getElementById('lmg-rmk-progress');
			if(!btn)return;
			btn.addEventListener('click',function(){
				if(!confirm('Udfyld fokusnøgleord på alle indlæg uden nøgleord?'))return;
				btn.disabled=true;var filled=0,offset=0;
				function step(){
					var fd=new FormData();
					fd.append('action','lmg_rmk_fill');fd.append('_ajax_nonce','<?php echo esc_js( wp_create_nonce( 'lmg_rmk_ajax' ) ); ?>');
					fd.append('post_type','<?php echo esc_js( $type ); ?>');fd.append('offset',offset);
					fetch(ajaxurl,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();}).then(function(j){
						if(!j.success){out.textContent='Fejl: '+JSON.stringify(j.data);btn.disabled=false;return;}
						filled+=j.data.filled;offset+=j.data.skipped;
						out.textContent=filled+' udfyldt, '+j.data.remaining+' tilbage'+(offset?' ('+offset+' uden forslag)':'');
						if(j.data.remaining>0&&(j.data.filled||j.data.skipped)){step();}else{out.textContent+=' – færdig.';setTimeout(function(){location.reload();},1200);}
					}).catch(function(e){out.textContent='Fejl: '+e;btn.disabled=false;});
				}
				step();
			});
		})();
		</script>
		<?php
	}
}
