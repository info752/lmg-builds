<?php
defined( 'ABSPATH' ) || exit;

/**
 * 1.1.0: one "LMG SEO" menu for the SEO tools. Svage sider is the first page, Fokusnøgleord moves here
 * from Tools, and Link repair / Positioner get shortcuts when those plugins run on the site.
 */
class LMG_RMK_Menu {

	const SLUG = 'lmg-seo';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 9 );
		add_action( 'admin_menu', array( __CLASS__, 'shortcuts' ), 99 );
		add_action( 'admin_init', array( __CLASS__, 'old_url' ) );
	}

	public static function menu() {
		add_menu_page( 'LMG SEO', 'LMG SEO', 'edit_others_posts', self::SLUG, array( 'LMG_RMK_Weak', 'page' ), 'dashicons-chart-line', 81 );
		add_submenu_page( self::SLUG, 'Svage sider', 'Svage sider', 'edit_others_posts', self::SLUG, array( 'LMG_RMK_Weak', 'page' ) );
	}

	public static function shortcuts() {
		global $admin_page_hooks;
		$tools = array(
			'lmg-link-repair' => 'Link repair',
			'lmg-positions'   => 'Positioner',
		);
		foreach ( $tools as $slug => $label ) {
			if ( self::registered( $slug ) ) {
				add_submenu_page( self::SLUG, $label, $label . ' ↗', 'manage_options', 'admin.php?page=' . $slug );
			}
		}
		if ( isset( $admin_page_hooks['rank-math'] ) ) {
			add_submenu_page( self::SLUG, 'Rank Math', 'Rank Math ↗', 'manage_options', 'admin.php?page=rank-math' );
		}
	}

	private static function registered( $slug ) {
		global $submenu;
		foreach ( (array) $submenu as $items ) {
			foreach ( (array) $items as $item ) {
				if ( isset( $item[2] ) && $item[2] === $slug ) {
					return true;
				}
			}
		}
		return false;
	}

	/** Bookmarks to the 1.0.0 address (Tools → Rank Math nøgleord) still work. */
	public static function old_url() {
		global $pagenow;
		if ( 'tools.php' === $pagenow && isset( $_GET['page'] ) && LMG_RMK_Admin::SLUG === $_GET['page'] ) {
			wp_safe_redirect( admin_url( 'admin.php?page=' . LMG_RMK_Admin::SLUG ) );
			exit;
		}
	}
}
