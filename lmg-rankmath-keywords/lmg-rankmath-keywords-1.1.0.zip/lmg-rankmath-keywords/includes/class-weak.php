<?php
defined( 'ABSPATH' ) || exit;

/**
 * 1.1.0 Svage sider: published posts with real substance (many words) but a weak Rank Math score.
 * Shows what is missing (hub link, internal/external link, images, bare country keyword) with a
 * suggestion for each, and fixes one post at a time on request. Never in bulk (traffic playbook).
 */
class LMG_RMK_Weak {

	const OPT    = 'lmg_rmk_weak';
	const SET    = 'lmg_rmk_weak_settings';
	const BACKUP = '_lmg_rmk_backup';
	const DONE   = '_lmg_rmk_weak_done';

	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'handle' ) );
		add_action( 'wp_ajax_lmg_rmk_weak_scan', array( __CLASS__, 'ajax_scan' ) );
	}

	public static function settings() {
		$d = array(
			'max_score' => 80,
			'min_words' => 800,
			'per_day'   => 5,
			'types'     => array( 'post' ),
			'external'  => '',
			'sister'    => false !== strpos( (string) wp_parse_url( home_url(), PHP_URL_HOST ), 'traveltalk.travel' ) ? 'https://www.traveltalk.dk' : 'https://traveltalk.travel',
		);
		return wp_parse_args( (array) get_option( self::SET, array() ), $d );
	}

	/* ---------- scan ---------- */

	private static function ids_query( $offset, $limit ) {
		$s = self::settings();
		return new WP_Query(
			array(
				'post_type'        => $s['types'],
				'post_status'      => 'publish',
				'posts_per_page'   => $limit,
				'offset'           => $offset,
				'orderby'          => 'ID',
				'order'            => 'ASC',
				'fields'           => 'ids',
				'suppress_filters' => true,
				'lang'             => '',
				'meta_query'       => array(
					array(
						'key'     => 'rank_math_seo_score',
						'value'   => (int) $s['max_score'],
						'compare' => '<',
						'type'    => 'NUMERIC',
					),
				),
			)
		);
	}

	public static function ajax_scan() {
		check_ajax_referer( 'lmg_rmk_weak' );
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			wp_send_json_error( 'forbidden', 403 );
		}
		$offset = isset( $_POST['offset'] ) ? absint( $_POST['offset'] ) : 0;
		$data   = get_option( self::OPT, array() );
		if ( 0 === $offset || empty( $data['rows'] ) ) {
			$data = array(
				'at'   => time(),
				'rows' => array(),
				'gsc'  => self::gsc_map(),
			);
		}
		$q = self::ids_query( $offset, 40 );
		foreach ( $q->posts as $id ) {
			$row = self::analyse( (int) $id, $data['gsc'] );
			if ( $row ) {
				$data['rows'][ $id ] = $row;
			}
		}
		$data['at'] = time();
		update_option( self::OPT, $data, false );
		$next = $offset + count( $q->posts );
		wp_send_json_success(
			array(
				'done'  => $next,
				'total' => (int) $q->found_posts,
				'found' => count( $data['rows'] ),
				'more'  => $next < (int) $q->found_posts && $q->posts,
			)
		);
	}

	/** page path => [impressions, weighted position] from Rank Math Analytics (Search Console), last 90 days. */
	private static function gsc_map() {
		global $wpdb;
		$t = $wpdb->prefix . 'rank_math_analytics_gsc';
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $t ) ) !== $t ) {
			return array();
		}
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT page, SUM(impressions) i, SUM(position*impressions)/NULLIF(SUM(impressions),0) p FROM $t WHERE created >= %s GROUP BY page", gmdate( 'Y-m-d', time() - 90 * DAY_IN_SECONDS ) ) );
		$map  = array();
		foreach ( (array) $rows as $r ) {
			$k = self::path( $r->page );
			if ( '' === $k ) {
				continue;
			}
			$i = isset( $map[ $k ] ) ? $map[ $k ][0] : 0;
			$map[ $k ] = array( $i + (int) $r->i, round( (float) $r->p, 1 ) );
		}
		return $map;
	}

	private static function path( $url ) {
		$p = wp_parse_url( (string) $url, PHP_URL_PATH );
		return $p ? '/' . trim( $p, '/' ) . '/' : '';
	}

	private static function hosts() {
		$h = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		$h = preg_replace( '/^www\./', '', $h );
		return array( $h, 'www.' . $h );
	}

	/** Internal and external links in the raw text (images and anchors left out). */
	public static function links( $content ) {
		preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\']/i', $content, $m );
		$int = array();
		$ext = array();
		foreach ( array_unique( $m[1] ) as $h ) {
			$h = trim( html_entity_decode( $h ) );
			if ( '' === $h || '#' === $h[0] || preg_match( '/^(mailto|tel|javascript):/i', $h ) || preg_match( '/\.(jpe?g|png|webp|gif|svg|pdf)(\?.*)?$/i', $h ) ) {
				continue;
			}
			$host = strtolower( (string) wp_parse_url( $h, PHP_URL_HOST ) );
			if ( '' === $host || in_array( $host, self::hosts(), true ) ) {
				$int[] = $h;
			} else {
				$ext[] = $h;
			}
		}
		return array( $int, $ext );
	}

	private static function page_for_slug( $slug ) {
		$page = get_page_by_path( $slug, OBJECT, 'page' );
		if ( ! $page ) {
			$q    = get_posts( array( 'post_type' => 'page', 'name' => $slug, 'post_status' => 'publish', 'numberposts' => 1 ) );
			$page = $q ? $q[0] : null;
		}
		return ( $page && 'publish' === $page->post_status ) ? $page : null;
	}

	/** [title, url] of the country/hub page: the deepest category's page, a page named after the place in the title, a parent category's page, else the category archive. */
	public static function hub( $post ) {
		$cats = get_the_category( $post->ID );
		$cats = array_filter(
			$cats,
			function ( $c ) {
				return ! in_array( $c->slug, array( 'uncategorized', 'uncategorized-da', 'ikke-kategoriseret' ), true );
			}
		);
		$place = LMG_RMK_Generator::find_place( $post->post_title );
		if ( $cats ) {
			usort(
				$cats,
				function ( $a, $b ) {
					return count( get_ancestors( $b->term_id, 'category' ) ) - count( get_ancestors( $a->term_id, 'category' ) );
				}
			);
			$c    = $cats[0];
			$page = self::page_for_slug( $c->slug );
			if ( ! $page && '' !== $place ) {
				$page = self::page_for_slug( sanitize_title( $place ) );
			}
			if ( ! $page ) {
				foreach ( get_ancestors( $c->term_id, 'category' ) as $anc ) {
					$t = get_term( $anc, 'category' );
					if ( $t && ! is_wp_error( $t ) && ( $page = self::page_for_slug( $t->slug ) ) ) {
						break;
					}
				}
			}
			if ( $page && (int) $page->ID !== (int) $post->ID ) {
				return array( get_the_title( $page ), get_permalink( $page ) );
			}
			return array( $c->name, get_category_link( $c ) );
		}
		if ( '' !== $place && ( $page = self::page_for_slug( sanitize_title( $place ) ) ) ) {
			return array( get_the_title( $page ), get_permalink( $page ) );
		}
		return array( '', '' );
	}

	/** Up to two other strong posts in the same category, as further internal link ideas. */
	private static function siblings( $post, $linked_paths ) {
		$cats = wp_get_post_categories( $post->ID );
		if ( ! $cats ) {
			return array();
		}
		$q   = get_posts(
			array(
				'post_type'        => 'post',
				'post_status'      => 'publish',
				'category__in'     => $cats,
				'post__not_in'     => array( $post->ID ),
				'numberposts'      => 6,
				'meta_key'         => 'rank_math_seo_score',
				'orderby'          => 'meta_value_num',
				'order'            => 'DESC',
				'suppress_filters' => true,
				'fields'           => 'ids',
			)
		);
		$out = array();
		foreach ( $q as $id ) {
			$u = get_permalink( $id );
			if ( in_array( self::path( $u ), $linked_paths, true ) ) {
				continue;
			}
			$out[] = array( wp_strip_all_tags( get_the_title( $id ) ), $u );
			if ( count( $out ) >= 2 ) {
				break;
			}
		}
		return $out;
	}

	private static function external_for( $place ) {
		$s = self::settings();
		foreach ( preg_split( '/\R/', (string) $s['external'] ) as $line ) {
			$parts = array_map( 'trim', explode( '=', $line, 2 ) );
			if ( 2 === count( $parts ) && '' !== $place && LMG_RMK_Generator::clean( $parts[0] ) === $place && wp_http_validate_url( $parts[1] ) ) {
				return $parts[1];
			}
		}
		return '';
	}

	public static function words( $content ) {
		$t = wp_strip_all_tags( strip_shortcodes( preg_replace( '/<!--.*?-->/s', ' ', $content ) ) );
		return preg_match_all( '/[\p{L}\p{N}]+/u', html_entity_decode( $t, ENT_QUOTES, 'UTF-8' ) );
	}

	public static function analyse( $id, $gsc = array() ) {
		$post = get_post( $id );
		$s    = self::settings();
		if ( ! $post ) {
			return null;
		}
		$c     = (string) $post->post_content;
		$words = self::words( $c );
		if ( $words < (int) $s['min_words'] ) {
			return null;
		}
		list( $int, $ext ) = self::links( $c );
		$paths  = array_map( array( __CLASS__, 'path' ), $int );
		list( $hub_t, $hub_u ) = self::hub( $post );
		$hub_ok = $hub_u && in_array( self::path( $hub_u ), $paths, true );
		$kw_all = (string) get_post_meta( $id, 'rank_math_focus_keyword', true );
		$kw     = trim( (string) strtok( $kw_all, ',' ) );
		$place  = LMG_RMK_Generator::find_place( $post->post_title );
		if ( '' === $place && '' !== $kw && LMG_RMK_Generator::is_bare_place( $kw, $post ) ) {
			$place = LMG_RMK_Generator::clean( $kw );
		}
		$bare   = '' !== $kw && LMG_RMK_Generator::is_bare_place( $kw, $post );
		$sister = false;
		$sh     = strtolower( (string) wp_parse_url( $s['sister'], PHP_URL_HOST ) );
		foreach ( $ext as $e ) {
			if ( $sh && false !== stripos( (string) wp_parse_url( $e, PHP_URL_HOST ), $sh ) ) {
				$sister = true;
			}
		}
		$imgs = preg_match_all( '/<img\s/i', $c );
		$g    = isset( $gsc[ self::path( get_permalink( $id ) ) ] ) ? $gsc[ self::path( get_permalink( $id ) ) ] : array( 0, 0 );
		$miss = array();
		if ( ! $int ) {
			$miss[] = 'int';
		}
		if ( $hub_u && ! $hub_ok ) {
			$miss[] = 'hub';
		}
		if ( ! $ext ) {
			$miss[] = 'ext';
		}
		if ( $bare || '' === $kw ) {
			$miss[] = 'kw';
		}
		if ( $imgs < max( 1, (int) floor( $words / 400 ) ) ) {
			$miss[] = 'img';
		}
		return array(
			'score'  => (int) get_post_meta( $id, 'rank_math_seo_score', true ),
			'words'  => $words,
			'imgs'   => $imgs,
			'int'    => count( $int ),
			'ext'    => count( $ext ),
			'sister' => $sister,
			'hub_t'  => $hub_t,
			'hub_u'  => $hub_u,
			'hub_ok' => $hub_ok,
			'kw'     => $kw_all,
			'bare'   => $bare,
			'kw_new' => ( $bare || '' === $kw ) && '' !== $place ? LMG_RMK_Generator::longer_keyword( $post, $place ) : '',
			'place'  => $place,
			'ext_s'  => self::external_for( $place ),
			'sib'    => self::siblings( $post, $paths ),
			'impr'   => (int) $g[0],
			'pos'    => (float) $g[1],
			'miss'   => $miss,
		);
	}

	/** Search Console pages at position 10-50 with impressions first (closest to page 1), then most gaps, then longest. */
	private static function sorted( $rows ) {
		uasort(
			$rows,
			function ( $a, $b ) {
				$ga = ( $a['impr'] > 0 && $a['pos'] >= 10 && $a['pos'] <= 50 ) ? $a['impr'] : 0;
				$gb = ( $b['impr'] > 0 && $b['pos'] >= 10 && $b['pos'] <= 50 ) ? $b['impr'] : 0;
				if ( $ga !== $gb ) {
					return $gb - $ga;
				}
				$ma = count( array_diff( $a['miss'], array( 'img' ) ) );
				$mb = count( array_diff( $b['miss'], array( 'img' ) ) );
				if ( $ma !== $mb ) {
					return $mb - $ma;
				}
				return $b['words'] - $a['words'];
			}
		);
		return $rows;
	}

	/* ---------- one-post fixes ---------- */

	public static function handle() {
		if ( empty( $_POST['lmg_rmk_weak'] ) || ! current_user_can( 'edit_others_posts' ) ) {
			return;
		}
		check_admin_referer( 'lmg_rmk_weak_form' );
		$do   = sanitize_key( $_POST['lmg_rmk_weak'] );
		$id   = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
		$back = admin_url( 'admin.php?page=' . LMG_RMK_Menu::SLUG );
		$msg  = '';

		if ( 'settings' === $do && current_user_can( 'manage_options' ) ) {
			$types = array_values( array_intersect( array_map( 'sanitize_key', (array) ( isset( $_POST['types'] ) ? $_POST['types'] : array() ) ), LMG_RMK_Generator::all_post_types() ) );
			update_option(
				self::SET,
				array(
					'max_score' => min( 100, max( 1, (int) $_POST['max_score'] ) ),
					'min_words' => max( 0, (int) $_POST['min_words'] ),
					'per_day'   => min( 50, max( 1, (int) $_POST['per_day'] ) ),
					'types'     => $types ? $types : array( 'post' ),
					'external'  => sanitize_textarea_field( wp_unslash( $_POST['external'] ) ),
					'sister'    => esc_url_raw( wp_unslash( $_POST['sister'] ) ),
				),
				false
			);
			wp_safe_redirect( add_query_arg( 'lmg_msg', 'Indstillinger gemt. Scan igen for at bruge dem.', $back ) );
			exit;
		}

		if ( ! $id || ! current_user_can( 'edit_post', $id ) || ! get_post( $id ) ) {
			return;
		}

		if ( 'keyword' === $do ) {
			$new = sanitize_text_field( wp_unslash( $_POST['kw_new'] ) );
			if ( '' !== $new ) {
				$old  = (string) get_post_meta( $id, 'rank_math_focus_keyword', true );
				$rest = array_filter( array_map( 'trim', explode( ',', $old ) ) );
				$all  = array_unique( array_merge( array_map( 'trim', explode( ',', $new ) ), $rest ) );
				update_post_meta( $id, '_lmg_rmk_old_keyword', $old );
				update_post_meta( $id, 'rank_math_focus_keyword', implode( ',', array_slice( $all, 0, 5 ) ) );
				$msg = 'Nyt fokusnøgleord gemt. Det gamle står nu som ekstra nøgleord.';
			}
		}

		if ( 'links' === $do ) {
			$hub  = ! empty( $_POST['add_hub'] ) ? esc_url_raw( wp_unslash( $_POST['hub_u'] ) ) : '';
			$hubt = sanitize_text_field( wp_unslash( $_POST['hub_t'] ) );
			$ext  = esc_url_raw( wp_unslash( $_POST['ext_u'] ) );
			$extt = sanitize_text_field( wp_unslash( $_POST['ext_t'] ) );
			$n    = self::append_links( $id, $hub, $hubt, $ext, $extt );
			$msg  = $n ? $n . ' link(s) tilføjet nederst i teksten.' : 'Intet tilføjet.';
		}

		if ( 'undo' === $do ) {
			$msg = self::undo( $id ) ? 'Teksten er sat tilbage til før linkene.' : 'Kunne ikke fortryde: teksten er ændret siden.';
		}

		if ( 'done' === $do ) {
			update_post_meta( $id, self::DONE, gmdate( 'Y-m-d' ) );
			$msg = 'Markeret som klaret.';
		}

		if ( in_array( $do, array( 'keyword', 'links', 'undo' ), true ) ) {
			$data = get_option( self::OPT, array() );
			if ( isset( $data['rows'][ $id ] ) ) {
				$row = self::analyse( $id, isset( $data['gsc'] ) ? $data['gsc'] : array() );
				if ( $row ) {
					$row['score']        = $data['rows'][ $id ]['score'];
					$data['rows'][ $id ] = $row;
					update_option( self::OPT, $data, false );
				}
			}
		}
		wp_safe_redirect( add_query_arg( array( 'lmg_msg' => rawurlencode( $msg ), 'open' => $id ), $back ) . '#p' . $id );
		exit;
	}

	/** Adds one "Læs mere" paragraph at the end of the text. Saved directly, with a backup for Undo; Translator and other save hooks are not triggered. */
	private static function append_links( $id, $hub, $hubt, $ext, $extt ) {
		global $wpdb;
		$parts = array();
		if ( $hub ) {
			$parts[] = 'Læs mere om <a href="' . esc_url( $hub ) . '">' . esc_html( $hubt ? $hubt : $hub ) . '</a>';
		}
		if ( $ext && wp_http_validate_url( $ext ) ) {
			$parts[] = 'se også <a href="' . esc_url( $ext ) . '" target="_blank" rel="noopener">' . esc_html( $extt ? $extt : wp_parse_url( $ext, PHP_URL_HOST ) ) . '</a>';
		}
		if ( ! $parts ) {
			return 0;
		}
		$p    = '<p class="lmg-rmk-more">' . ucfirst( implode( ', og ', $parts ) ) . '.</p>';
		$old  = (string) get_post_field( 'post_content', $id, 'raw' );
		$add  = false !== strpos( $old, '<!-- wp:' ) ? "\n\n<!-- wp:paragraph {\"className\":\"lmg-rmk-more\"} -->\n" . $p . "\n<!-- /wp:paragraph -->" : "\n\n" . $p;
		$new  = rtrim( $old ) . $add;
		if ( ! get_post_meta( $id, self::BACKUP, true ) ) {
			update_post_meta( $id, self::BACKUP, wp_slash( array( 'content' => $old, 'at' => current_time( 'mysql' ) ) ) );
		}
		update_post_meta( $id, '_lmg_rmk_after', md5( $new ) );
		$wpdb->update( $wpdb->posts, array( 'post_content' => $new ), array( 'ID' => $id ) );
		clean_post_cache( $id );
		do_action( 'litespeed_purge_post', $id );
		return count( $parts );
	}

	private static function undo( $id ) {
		global $wpdb;
		$b   = get_post_meta( $id, self::BACKUP, true );
		$cur = (string) get_post_field( 'post_content', $id, 'raw' );
		if ( ! is_array( $b ) || ! isset( $b['content'] ) || md5( $cur ) !== get_post_meta( $id, '_lmg_rmk_after', true ) ) {
			return false;
		}
		$wpdb->update( $wpdb->posts, array( 'post_content' => $b['content'] ), array( 'ID' => $id ) );
		delete_post_meta( $id, self::BACKUP );
		delete_post_meta( $id, '_lmg_rmk_after' );
		clean_post_cache( $id );
		do_action( 'litespeed_purge_post', $id );
		return true;
	}

	/* ---------- page ---------- */

	private static function label( $k ) {
		$l = array(
			'int' => 'Ingen interne links',
			'hub' => 'Mangler link til hub',
			'ext' => 'Intet eksternt link',
			'kw'  => 'Nøgleord: bart landenavn',
			'img' => 'Få billeder',
		);
		return isset( $l[ $k ] ) ? $l[ $k ] : $k;
	}

	public static function page() {
		$s     = self::settings();
		$data  = get_option( self::OPT, array() );
		$rows  = isset( $data['rows'] ) ? self::sorted( $data['rows'] ) : array();
		$show  = isset( $_GET['vis'] ) ? sanitize_key( $_GET['vis'] ) : 'idag';
		$open  = isset( $_GET['open'] ) ? absint( $_GET['open'] ) : 0;
		$todo  = array();
		$done  = 0;
		foreach ( $rows as $id => $r ) {
			if ( get_post_meta( $id, self::DONE, true ) ) {
				$done++;
				if ( 'klaret' !== $show ) {
					continue;
				}
			} elseif ( 'klaret' === $show ) {
				continue;
			}
			$todo[ $id ] = $r;
		}
		$list = 'idag' === $show ? array_slice( $todo, 0, (int) $s['per_day'], true ) : $todo;
		$base = admin_url( 'admin.php?page=' . LMG_RMK_Menu::SLUG );
		?>
		<div class="wrap">
			<h1>Svage sider <a class="page-title-action" href="<?php echo esc_url( admin_url( 'admin.php?page=lmg-rmk-notes' ) ); ?>">Release notes</a></h1>
			<p>Indlæg med mindst <?php echo (int) $s['min_words']; ?> ord og en Rank Math-score under <?php echo (int) $s['max_score']; ?>. Målet er en acceptabel score, ikke 90. Ret et par stykker om dagen, aldrig alle på én gang.</p>
			<?php if ( ! empty( $_GET['lmg_msg'] ) ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo esc_html( wp_unslash( $_GET['lmg_msg'] ) ); ?></p></div>
			<?php endif; ?>
			<p>
				<button type="button" class="button button-primary" id="lmg-weak-scan"><?php echo $rows ? 'Scan igen' : 'Scan nu'; ?></button>
				<span id="lmg-weak-progress" style="margin-left:10px"><?php echo ! empty( $data['at'] ) ? 'Sidst scannet ' . esc_html( wp_date( 'j. M Y H:i', $data['at'] ) ) . ' · ' . count( $rows ) . ' sider fundet · ' . (int) $done . ' klaret' . ( empty( $data['gsc'] ) ? ' · ingen Search Console-data i Rank Math' : '' ) : ''; ?></span>
			</p>
			<ul class="subsubsub" style="float:none">
				<li><a href="<?php echo esc_url( add_query_arg( 'vis', 'idag', $base ) ); ?>" class="<?php echo 'idag' === $show ? 'current' : ''; ?>">Dagens <?php echo (int) $s['per_day']; ?></a> |</li>
				<li><a href="<?php echo esc_url( add_query_arg( 'vis', 'alle', $base ) ); ?>" class="<?php echo 'alle' === $show ? 'current' : ''; ?>">Alle åbne (<?php echo count( $rows ) - (int) $done; ?>)</a> |</li>
				<li><a href="<?php echo esc_url( add_query_arg( 'vis', 'klaret', $base ) ); ?>" class="<?php echo 'klaret' === $show ? 'current' : ''; ?>">Klaret (<?php echo (int) $done; ?>)</a></li>
			</ul>

			<table class="widefat striped" style="margin-top:8px">
				<thead><tr><th>Indlæg</th><th style="width:60px">Score</th><th style="width:60px">Ord</th><th style="width:120px">Search Console</th><th>Mangler</th><th style="width:90px"></th></tr></thead>
				<tbody>
				<?php if ( ! $list ) : ?>
					<tr><td colspan="6"><?php echo $rows ? 'Intet her.' : 'Tryk Scan nu.'; ?></td></tr>
				<?php endif; ?>
				<?php foreach ( $list as $id => $r ) : $p = get_post( $id ); if ( ! $p ) { continue; } ?>
					<tr id="p<?php echo (int) $id; ?>">
						<td><strong><a href="<?php echo esc_url( get_edit_post_link( $id ) ); ?>"><?php echo esc_html( wp_strip_all_tags( get_the_title( $id ) ) ); ?></a></strong><br><a href="<?php echo esc_url( get_permalink( $id ) ); ?>" target="_blank" style="color:#646970"><?php echo esc_html( self::path( get_permalink( $id ) ) ); ?></a></td>
						<td><strong><?php echo (int) $r['score']; ?></strong></td>
						<td><?php echo (int) $r['words']; ?></td>
						<td><?php echo $r['impr'] ? (int) $r['impr'] . ' visn. · pos ' . esc_html( $r['pos'] ) : '–'; ?></td>
						<td><?php echo esc_html( implode( ' · ', array_map( array( __CLASS__, 'label' ), $r['miss'] ) ) ); ?></td>
						<td><button type="button" class="button lmg-weak-toggle" data-id="<?php echo (int) $id; ?>">Ret</button></td>
					</tr>
					<tr class="lmg-weak-detail" id="d<?php echo (int) $id; ?>" style="<?php echo $open === $id ? '' : 'display:none'; ?>">
						<td colspan="6" style="background:#f6f7f7;padding:14px 18px">
							<?php self::detail( $id, $r, $s ); ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<?php if ( current_user_can( 'manage_options' ) ) : ?>
			<h2 style="margin-top:32px">Indstillinger</h2>
			<form method="post">
				<?php wp_nonce_field( 'lmg_rmk_weak_form' ); ?>
				<input type="hidden" name="lmg_rmk_weak" value="settings">
				<table class="form-table">
					<tr><th>Score under</th><td><input type="number" name="max_score" min="1" max="100" value="<?php echo (int) $s['max_score']; ?>" class="small-text"></td></tr>
					<tr><th>Mindst antal ord</th><td><input type="number" name="min_words" min="0" value="<?php echo (int) $s['min_words']; ?>" class="small-text"></td></tr>
					<tr><th>Sider pr. dag</th><td><input type="number" name="per_day" min="1" max="50" value="<?php echo (int) $s['per_day']; ?>" class="small-text"></td></tr>
					<tr><th>Indholdstyper</th><td>
						<?php foreach ( LMG_RMK_Generator::all_post_types() as $t ) : ?>
							<label style="margin-right:14px"><input type="checkbox" name="types[]" value="<?php echo esc_attr( $t ); ?>" <?php checked( in_array( $t, $s['types'], true ) ); ?>> <?php echo esc_html( $t ); ?></label>
						<?php endforeach; ?>
					</td></tr>
					<tr><th>Søster-site</th><td><input type="url" name="sister" value="<?php echo esc_attr( $s['sister'] ); ?>" class="regular-text"><p class="description">Bruges til forslaget "find samme emne på søster-sitet" som eksternt link.</p></td></tr>
					<tr><th>Eksterne forslag</th><td><textarea name="external" rows="6" class="large-text" placeholder="Tanzania = https://..."><?php echo esc_textarea( $s['external'] ); ?></textarea><p class="description">Én pr. linje: sted = officiel side (turistkontor, nationalpark). Bruges som eksternt forslag for indlæg om stedet.</p></td></tr>
				</table>
				<?php submit_button( 'Gem indstillinger' ); ?>
			</form>
			<?php endif; ?>
		</div>
		<script>
		(function(){
			document.querySelectorAll('.lmg-weak-toggle').forEach(function(b){b.addEventListener('click',function(){var d=document.getElementById('d'+b.dataset.id);d.style.display=d.style.display==='none'?'':'none';});});
			var btn=document.getElementById('lmg-weak-scan'),out=document.getElementById('lmg-weak-progress');
			btn.addEventListener('click',function(){
				btn.disabled=true;
				function step(offset){
					var fd=new FormData();fd.append('action','lmg_rmk_weak_scan');fd.append('_ajax_nonce','<?php echo esc_js( wp_create_nonce( 'lmg_rmk_weak' ) ); ?>');fd.append('offset',offset);
					fetch(ajaxurl,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();}).then(function(j){
						if(!j.success){out.textContent='Fejl: '+JSON.stringify(j.data);btn.disabled=false;return;}
						out.textContent=j.data.done+' af '+j.data.total+' læst · '+j.data.found+' fundet';
						if(j.data.more){step(j.data.done);}else{out.textContent+=' – færdig.';setTimeout(function(){location.reload();},800);}
					}).catch(function(e){out.textContent='Fejl: '+e+' (tryk igen for at fortsætte)';btn.disabled=false;});
				}
				step(0);
			});
		})();
		</script>
		<?php
	}

	private static function detail( $id, $r, $s ) {
		$nonce = wp_nonce_field( 'lmg_rmk_weak_form', '_wpnonce', true, false );
		$sh    = untrailingslashit( $s['sister'] );
		$ext   = $r['ext_s'];
		$extt  = $ext ? wp_parse_url( $ext, PHP_URL_HOST ) : '';
		?>
		<p style="margin-top:0"><strong>Nu:</strong> <?php echo (int) $r['int']; ?> interne links · <?php echo (int) $r['ext']; ?> eksterne<?php echo $r['sister'] ? ' (heraf søster-site)' : ''; ?> · <?php echo (int) $r['imgs']; ?> billeder (mål ca. <?php echo (int) max( 1, floor( $r['words'] / 400 ) ); ?>) · fokusnøgleord: <code><?php echo esc_html( $r['kw'] ? $r['kw'] : '–' ); ?></code></p>

		<?php if ( $r['kw_new'] ) : ?>
		<form method="post" style="margin:10px 0">
			<?php echo $nonce; // phpcs:ignore ?>
			<input type="hidden" name="lmg_rmk_weak" value="keyword"><input type="hidden" name="post_id" value="<?php echo (int) $id; ?>">
			<strong>1. Nøgleord.</strong> <?php echo $r['bare'] ? 'Et bart landenavn hører til landesiden.' : 'Intet fokusnøgleord.'; ?>
			Forslag: <input type="text" name="kw_new" value="<?php echo esc_attr( $r['kw_new'] ); ?>" class="regular-text">
			<button class="button">Gem nøgleord</button>
		</form>
		<?php endif; ?>

		<form method="post" style="margin:10px 0">
			<?php echo $nonce; // phpcs:ignore ?>
			<input type="hidden" name="lmg_rmk_weak" value="links"><input type="hidden" name="post_id" value="<?php echo (int) $id; ?>">
			<strong>2. Links.</strong>
			<?php if ( $r['hub_u'] ) : ?>
				Hub: <a href="<?php echo esc_url( $r['hub_u'] ); ?>" target="_blank"><?php echo esc_html( $r['hub_t'] ); ?></a>
				<?php if ( $r['hub_ok'] ) : ?>
					<span style="color:#008a20">✓ linket</span>
				<?php else : ?>
					<label style="margin-left:6px"><input type="checkbox" name="add_hub" value="1" checked> tilføj</label>
					<input type="hidden" name="hub_u" value="<?php echo esc_attr( $r['hub_u'] ); ?>"><input type="hidden" name="hub_t" value="<?php echo esc_attr( $r['hub_t'] ); ?>">
				<?php endif; ?>
			<?php else : ?>
				Ingen hub fundet (indlægget har ingen kategori eller landeside).
			<?php endif; ?>
			<br>
			<span style="display:inline-block;margin-top:6px">Eksternt link: <input type="url" name="ext_u" value="<?php echo esc_attr( $ext ); ?>" placeholder="https://" class="regular-text"> tekst <input type="text" name="ext_t" value="<?php echo esc_attr( $extt ); ?>" style="width:200px"></span>
			<?php if ( $sh && '' !== $r['place'] ) : ?>
				<a href="<?php echo esc_url( $sh . '/?s=' . rawurlencode( $r['place'] ) ); ?>" target="_blank" style="margin-left:6px">Find på <?php echo esc_html( wp_parse_url( $sh, PHP_URL_HOST ) ); ?> ↗</a>
			<?php endif; ?>
			<?php if ( $r['sib'] ) : ?>
				<br><span style="display:inline-block;margin-top:6px;color:#50575e">Flere interne idéer (sæt dem ind i teksten selv): <?php echo implode( ' · ', array_map( function ( $x ) { return '<a href="' . esc_url( $x[1] ) . '" target="_blank">' . esc_html( $x[0] ) . '</a>'; }, $r['sib'] ) ); // phpcs:ignore ?></span>
			<?php endif; ?>
			<p style="margin:8px 0 0"><button class="button button-primary">Tilføj valgte links</button> <span class="description">Lægges som én "Læs mere"-linje nederst i teksten. Vil du hellere have dem inde i teksten, så ret i editoren.</span></p>
		</form>

		<p style="margin:12px 0 0">
			<strong>3.</strong> <a class="button" href="<?php echo esc_url( get_edit_post_link( $id ) ); ?>" target="_blank">Åbn i editoren og tryk Opdater</a> så Rank Math regner scoren igen.
		</p>
		<form method="post" style="display:inline-block;margin-top:8px">
			<?php echo $nonce; // phpcs:ignore ?>
			<input type="hidden" name="lmg_rmk_weak" value="done"><input type="hidden" name="post_id" value="<?php echo (int) $id; ?>">
			<button class="button">Markér som klaret</button>
		</form>
		<?php if ( get_post_meta( $id, self::BACKUP, true ) ) : ?>
		<form method="post" style="display:inline-block;margin:8px 0 0 6px">
			<?php echo $nonce; // phpcs:ignore ?>
			<input type="hidden" name="lmg_rmk_weak" value="undo"><input type="hidden" name="post_id" value="<?php echo (int) $id; ?>">
			<button class="button-link" style="color:#b32d2e">Fortryd linkene</button>
		</form>
		<?php endif; ?>
		<?php
	}
}
