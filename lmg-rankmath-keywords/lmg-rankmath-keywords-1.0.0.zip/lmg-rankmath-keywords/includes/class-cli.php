<?php
defined( 'ABSPATH' ) || exit;

/**
 * Fill missing Rank Math focus keywords.
 */
class LMG_RMK_CLI {

	/**
	 * Count posts without a focus keyword.
	 *
	 * ## OPTIONS
	 * [--post_type=<type>]
	 */
	public function count( $args, $assoc ) {
		$s = LMG_RMK_Generator::settings();
		$types = ! empty( $assoc['post_type'] ) ? array( $assoc['post_type'] ) : $s['post_types'];
		$total = 0;
		foreach ( $types as $t ) {
			$n = LMG_RMK_Generator::count_missing( $t );
			$total += $n;
			WP_CLI::line( sprintf( '%-24s %d', $t, $n ) );
		}
		WP_CLI::success( "Missing: $total" );
	}

	/**
	 * Fill missing focus keywords.
	 *
	 * ## OPTIONS
	 * [--post_type=<type>]
	 * [--dry-run]
	 * [--batch=<n>]
	 * ---
	 * default: 100
	 * ---
	 */
	public function fill( $args, $assoc ) {
		$dry    = ! empty( $assoc['dry-run'] );
		$type   = isset( $assoc['post_type'] ) ? $assoc['post_type'] : '';
		$batch  = max( 1, (int) ( isset( $assoc['batch'] ) ? $assoc['batch'] : 100 ) );
		$offset = 0;
		$filled = 0;
		do {
			$r = LMG_RMK_Generator::fill_batch( $batch, $type, $dry, $offset );
			foreach ( $r['done'] as $id => $kw ) {
				WP_CLI::line( "$id\t" . get_the_title( $id ) . "\t$kw" );
			}
			$filled += count( $r['done'] );
			$offset += count( $r['skipped'] ) + ( $dry ? count( $r['done'] ) : 0 );
		} while ( $r['remaining'] > 0 && ( $r['done'] || $r['skipped'] ) );
		WP_CLI::success( ( $dry ? 'Would fill ' : 'Filled ' ) . $filled );
	}
}
