<?php
/**
 * Plugin Name: LMG Rank Math Keywords
 * Description: Finds posts, pages and custom post types without a Rank Math focus keyword and fills them (country/destination as main keyword plus 1-2 more). Preview, edit and bulk fill under Tools → Rank Math nøgleord.
 * Version: 1.0.0
 * Author: Leisure Media Group
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Text Domain: lmg-rmk
 */

defined( 'ABSPATH' ) || exit;

define( 'LMG_RMK_VERSION', '1.0.0' );
define( 'LMG_RMK_META', 'rank_math_focus_keyword' );
define( 'LMG_RMK_DIR', plugin_dir_path( __FILE__ ) );

require_once LMG_RMK_DIR . 'includes/class-generator.php';
require_once LMG_RMK_DIR . 'includes/class-admin.php';
require_once LMG_RMK_DIR . 'includes/class-notes.php';

LMG_RMK_Admin::init();
LMG_RMK_Notes::boot();

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	require_once LMG_RMK_DIR . 'includes/class-cli.php';
	WP_CLI::add_command( 'lmg-rmk', 'LMG_RMK_CLI' );
}
