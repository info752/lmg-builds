<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Rejseservice / Travel Services section (brief v2, 18 Nov 2026).
 *
 * Option lmgf_ts:
 *   parent, children[n]   term ids
 *   hero[n], hero[0]      attachment ids (0 = parent)
 *   pages[n]              related page ids, one per line
 *   landing               page id of the landing page
 *   box                   off | pilot | on
 *   pilot                 post ids, one per line
 *   interest              "category-slug | n" lines (fallback for the box)
 *   archives              0/1: cards and heroes on the category pages
 *   moved[path]           old archive path => term id (301 after adopting a category)
 * Option lmgf_ts_runs: last 10 assignment runs [time, user, rows[[post, term]]] for undo.
 * Post meta _lmgf_ts_hide: "1" hides the box on that post.
 */
class LMGF_Services {

	const TAB = 'services';

	public static function boot() {
		add_shortcode( 'lmg_rejseservice', array( __CLASS__, 'sc_landing' ) );
		add_filter( 'the_content', array( __CLASS__, 'content' ), 22 );
		add_filter( 'get_the_archive_description', array( __CLASS__, 'archive' ), 20 );
		add_action( 'template_redirect', array( __CLASS__, 'redirect_moved' ), 1 );
		add_filter( 'post_link', array( __CLASS__, 'keep_link' ), 20, 2 );
		add_action( 'wp_enqueue_scripts', function () {
			if ( is_category() ) wp_enqueue_style( 'lmg-faktabokse', LMGF_URL . 'assets/lmgf.css', array(), LMGF_VERSION );
		} );
		if ( is_admin() ) {
			add_action( 'admin_init', array( __CLASS__, 'actions' ) );
			add_action( 'admin_menu', function () {
				add_posts_page( 'Travel Services categories', self::is_travel() ? 'Travel Services' : 'Rejseservice', 'manage_options', 'lmgf-travel-services', function () { wp_safe_redirect( LMGF_Admin::url( self::TAB ) ); exit; } );
			} );
			add_action( 'load-posts_page_lmgf-travel-services', function () { wp_safe_redirect( LMGF_Admin::url( self::TAB ) ); exit; } );
			add_action( 'admin_post_lmgf_ts_csv', array( __CLASS__, 'csv' ) );
			add_action( 'admin_enqueue_scripts', function ( $hook ) {
				if ( $hook === 'settings_page_' . LMGF_Admin::SLUG && isset( $_GET['tab'] ) && $_GET['tab'] === self::TAB ) wp_enqueue_media();
			} );
		}
	}

	// ---- Definitions ---------------------------------------------------------------

	public static function is_travel() {
		return strpos( (string) wp_parse_url( home_url(), PHP_URL_HOST ), 'traveltalk.travel' ) !== false || LMGF_Data::site_lang() !== 'da';
	}

	/** n => [slug, name, description, finder words]; 0 is the parent. */
	public static function defs() {
		if ( self::is_travel() ) return array(
			0 => array( 'travel-services', 'Travel Services', 'The practical side of travelling', '' ),
			1 => array( 'airlines-flights', 'Airlines & Flights', 'Airlines, flight routes, low-cost carriers and aviation.', 'airline|airways|air lines|flight|low-cost|low cost|aviation|carrier' ),
			2 => array( 'airports', 'Airports', 'International airports, airport guides, transfers and facilities.', 'airport|lounge|terminal|transfer' ),
			3 => array( 'cruises-cruise-lines', 'Cruises & Cruise Lines', 'Cruise companies, ships, itineraries and ports.', 'cruise|ship|ferry|ferries|river' ),
			4 => array( 'trains-railways', 'Trains & Railways', 'Rail operators, train journeys, international rail and scenic routes.', 'train|rail|railway|interrail|eurostar|express' ),
			5 => array( 'buses-coaches', 'Buses & Coaches', 'Bus companies, long-distance coaches and regional transport.', 'bus|coach|flixbus' ),
			6 => array( 'car-rental-mobility', 'Car Rental & Mobility', 'Car rental, transfers, taxis and mobility services.', 'car rental|car hire|rental car|taxi|motorhome|camper|road trip' ),
			7 => array( 'accommodation', 'Accommodation', 'Hotels, resorts, holiday rentals and other places to stay.', 'hotel|resort|hostel|holiday rental|apartment|villa|lodge' ),
			8 => array( 'tour-operators-travel-agencies', 'Tour Operators & Travel Agencies', 'Package holidays, travel companies and specialist operators.', 'travel agency|travel agencies|tour operator|package holiday|travel company|specialist' ),
			9 => array( 'travel-essentials', 'Travel Essentials', 'Travel insurance, visas, payment services and practical travel assistance.', 'insurance|visa|passport|esta|currency|payment|card|luggage|packing' ),
		);
		return array(
			0 => array( 'rejseservice', 'Rejseservice', 'Den praktiske side af rejsen', '' ),
			1 => array( 'flyselskaber', 'Flyselskaber & fly', 'Flyselskaber, flyruter, lavprisselskaber og luftfart.', 'flyselskab|airline|airways|flyrute|lavpris|luftfart|fly ' ),
			2 => array( 'lufthavne', 'Lufthavne', 'Internationale lufthavne, lufthavnsguides, transfers og faciliteter.', 'lufthavn|airport|lounge|terminal|transfer' ),
			3 => array( 'krydstogter-rederier', 'Krydstogter & rederier', 'Rederier, skibe, ruter og havne.', 'krydstogt|rederi|cruise|skib|færge|flodkrydstogt' ),
			4 => array( 'tog-jernbaner', 'Tog & jernbaner', 'Togselskaber, togrejser, internationale tog og naturskønne strækninger.', 'tog|jernban|interrail|nattog|eurostar' ),
			5 => array( 'bus-fjernbus', 'Bus & fjernbus', 'Busselskaber, fjernbusser og regional transport.', 'bus|fjernbus|flixbus' ),
			6 => array( 'biludlejning-transport', 'Biludlejning & transport', 'Biludlejning, transfers, taxa og mobilitet.', 'biludlejning|lejebil|leje bil|autocamper|taxa|roadtrip|bilferie' ),
			7 => array( 'overnatning', 'Overnatning', 'Hoteller, resorts, ferieboliger og andre steder at bo.', 'hotel|resort|feriebolig|ferielejlighed|hostel|villa|overnatning' ),
			8 => array( 'rejsearrangoerer-rejsebureauer', 'Rejsearrangører & rejsebureauer', 'Pakkerejser, rejseselskaber og specialbureauer.', 'rejsebureau|rejsearrangør|rejseselskab|pakkerejse|specialbureau' ),
			9 => array( 'rejsepraktisk', 'Rejsepraktisk', 'Rejseforsikring, visum, betaling og praktisk hjælp på rejsen.', 'forsikring|visum|pas |esta|valuta|betaling|kreditkort|bagage|pakkeliste' ),
		);
	}

	public static function words( $k ) {
		$da = array(
			'box_title' => 'Rejsepraktisk',
			'all'       => 'Se hele Rejseservice',
			'pages'     => 'Læs også',
			'intro'     => 'Den praktiske side af rejsen',
		);
		$en = array(
			'box_title' => 'Practical travel',
			'all'       => 'See all Travel Services',
			'pages'     => 'Also read',
			'intro'     => 'The practical side of travelling',
		);
		$w = self::is_travel() ? $en : $da;
		return $w[ $k ];
	}

	public static function opt() {
		return wp_parse_args( (array) get_option( 'lmgf_ts', array() ), array(
			'parent' => 0, 'children' => array(), 'hero' => array(), 'pages' => array(), 'landing' => 0,
			'box' => 'off', 'pilot' => '', 'interest' => self::is_travel() ? "cruise-holidays | 3\ncruises | 3" : "busrejser | 5\nferieboliger | 7\nkrydstogter | 3",
			'archives' => 0, 'moved' => array(), 'flat' => array(), 'stopped' => array(),
		) );
	}

	public static function save_opt( array $o ) {
		update_option( 'lmgf_ts', $o, false );
	}

	/** n => term id, only terms that still exist. */
	public static function children() {
		$out = array();
		foreach ( (array) self::opt()['children'] as $n => $t ) {
			$term = get_term( (int) $t, 'category' );
			if ( $term && ! is_wp_error( $term ) ) $out[ (int) $n ] = (int) $t;
		}
		return $out;
	}

	public static function ids( $text ) {
		return array_values( array_filter( array_map( 'absint', preg_split( '/[\s,]+/', (string) $text ) ) ) );
	}

	// ---- Front: landing cards ------------------------------------------------------

	public static function sc_landing() {
		wp_enqueue_style( 'lmg-faktabokse', LMGF_URL . 'assets/lmgf.css', array(), LMGF_VERSION );
		return self::cards( true );
	}

	public static function cards( $intro = false ) {
		$o    = self::opt();
		$defs = self::defs();
		$kids = self::children();
		if ( ! $kids ) return '';
		$h = '<div class="lmgf-ts">';
		if ( $intro ) $h .= '<p class="lmgf-ts-intro">' . esc_html( self::words( 'intro' ) ) . '</p>';
		$h .= '<div class="lmgf-ts-grid">';
		foreach ( $kids as $n => $t ) {
			$term = get_term( $t, 'category' );
			$link = get_term_link( $term );
			$img  = ! empty( $o['hero'][ $n ] ) ? wp_get_attachment_image( (int) $o['hero'][ $n ], 'medium_large', false, array( 'class' => 'lmgf-ts-img', 'loading' => 'lazy', 'alt' => '' ) ) : '';
			$desc = $term->description !== '' ? $term->description : $defs[ $n ][2];
			$h   .= '<a class="lmgf-ts-card' . ( $img ? '' : ' lmgf-ts-noimg' ) . '" href="' . esc_url( is_wp_error( $link ) ? '#' : $link ) . '">'
				. ( $img ? '<span class="lmgf-ts-pic">' . $img . '</span>' : '' )
				. '<span class="lmgf-ts-name">' . esc_html( $term->name ) . '</span>'
				. '<span class="lmgf-ts-desc">' . esc_html( wp_strip_all_tags( $desc ) ) . '</span></a>';
		}
		return $h . '</div></div>';
	}

	/** Hero + related pages on a child's category page, cards on the parent's. */
	public static function archive( $desc ) {
		if ( ! is_category() || is_admin() ) return $desc;
		$o = self::opt();
		if ( empty( $o['archives'] ) ) return $desc;
		$t = (int) get_queried_object_id();
		if ( $t && $t === (int) $o['parent'] ) {
			$img = ! empty( $o['hero'][0] ) ? '<div class="lmgf-ts-hero">' . wp_get_attachment_image( (int) $o['hero'][0], 'full', false, array( 'loading' => 'eager', 'alt' => '' ) ) . '</div>' : '';
			return $img . $desc . self::cards();
		}
		$n = array_search( $t, self::children(), true );
		if ( $n === false ) return $desc;
		$img   = ! empty( $o['hero'][ $n ] ) ? '<div class="lmgf-ts-hero">' . wp_get_attachment_image( (int) $o['hero'][ $n ], 'full', false, array( 'loading' => 'eager', 'alt' => '' ) ) . '</div>' : '';
		return $img . $desc . self::related( $n );
	}

	/** Pages linked to a child (for example /rejsebureauer/), with their published sub-pages. */
	public static function related( $n ) {
		$o   = self::opt();
		$ids = self::ids( isset( $o['pages'][ $n ] ) ? $o['pages'][ $n ] : '' );
		if ( ! $ids ) return '';
		$li = '';
		foreach ( $ids as $id ) {
			if ( get_post_status( $id ) !== 'publish' ) continue;
			$li .= '<li><a href="' . esc_url( get_permalink( $id ) ) . '">' . esc_html( get_the_title( $id ) ) . '</a>';
			$subs = get_posts( array( 'post_type' => get_post_type( $id ), 'post_parent' => $id, 'post_status' => 'publish', 'posts_per_page' => 60, 'orderby' => 'title', 'order' => 'ASC', 'no_found_rows' => true ) );
			if ( $subs ) {
				$li .= '<ul>';
				foreach ( $subs as $s ) $li .= '<li><a href="' . esc_url( get_permalink( $s ) ) . '">' . esc_html( get_the_title( $s ) ) . '</a></li>';
				$li .= '</ul>';
			}
			$li .= '</li>';
		}
		return $li === '' ? '' : '<div class="lmgf-ts-related"><p class="lmgf-title">' . esc_html( self::words( 'pages' ) ) . '</p><ul>' . $li . '</ul></div>';
	}

	public static function redirect_moved() {
		if ( ! is_404() ) return;
		$moved = (array) self::opt()['moved'];
		if ( ! $moved ) return;
		$path = trailingslashit( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ) );
		if ( isset( $moved[ $path ] ) ) {
			$link = get_term_link( (int) $moved[ $path ], 'category' );
			if ( ! is_wp_error( $link ) ) { wp_safe_redirect( $link, 301 ); exit; }
		}
	}

	// ---- Front: the info box -------------------------------------------------------

	public static function content( $html ) {
		if ( is_admin() || is_feed() || ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) return $html;
		$id = get_the_ID();
		if ( (int) $id !== (int) get_queried_object_id() ) return $html;
		$o = self::opt();
		if ( $o['box'] === 'off' || get_post_meta( $id, '_lmgf_ts_hide', true ) ) return $html;
		if ( $o['box'] === 'pilot' && ! in_array( (int) $id, self::ids( $o['pilot'] ), true ) ) return $html;
		if ( LMGF_Data::lang_of( $id ) !== LMGF_Data::site_lang() || has_shortcode( $html, 'lmg_rejsepraktisk' ) ) return $html;
		$box = self::box( $id );
		if ( $box === '' ) return $html;
		$pos = self::after_h2( $html, 2 );
		return $pos === false ? $html . $box : substr( $html, 0, $pos ) . $box . substr( $html, $pos );
	}

	/** Offset after the first paragraph under the n-th H2 (or the last H2 if there are fewer); false if none. */
	public static function after_h2( $html, $n ) {
		$off = 0; $last = false;
		for ( $i = 0; $i < $n; $i++ ) {
			$p = stripos( $html, '</h2>', $off );
			if ( $p === false ) break;
			$last = $off = $p + 5;
		}
		if ( $last === false ) return false;
		// After the first paragraph under that heading, so the heading keeps its text.
		$p    = stripos( $html, '</p>', $last );
		$next = stripos( $html, '<h', $last );
		return ( $p !== false && ( $next === false || $p < $next ) ) ? $p + 4 : $last;
	}

	/** Up to four related service posts, ids. */
	public static function picks( $post_id ) {
		$key = 'lmgf_ts_' . $post_id;
		$c   = get_transient( $key );
		if ( is_array( $c ) ) return $c;
		$kids = self::children();
		$out  = array();
		if ( $kids ) {
			$cats = wp_get_post_terms( $post_id, 'category', array( 'fields' => 'all' ) );
			$cats = is_wp_error( $cats ) ? array() : $cats;
			$ts   = array_values( $kids );
			$ts[] = (int) self::opt()['parent'];
			$own  = array();
			foreach ( $cats as $c2 ) if ( ! in_array( (int) $c2->term_id, $ts, true ) ) $own[] = (int) $c2->term_id;
			// A post that only sits in Travel Services is itself a service post: no box.
			if ( $own ) {
				$base = array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 4, 'post__not_in' => array( $post_id ), 'fields' => 'ids', 'no_found_rows' => true, 'ignore_sticky_posts' => true );
				$out  = get_posts( $base + array( 'tax_query' => array(
					'relation' => 'AND',
					array( 'taxonomy' => 'category', 'terms' => array_values( $kids ), 'include_children' => false ),
					array( 'taxonomy' => 'category', 'terms' => $own ),
				) ) );
				if ( ! $out ) {
					$slugs = wp_list_pluck( $cats, 'slug' );
					$want  = array();
					foreach ( preg_split( '/\R/', (string) self::opt()['interest'] ) as $line ) {
						$p = array_map( 'trim', explode( '|', $line ) );
						if ( count( $p ) === 2 && in_array( $p[0], $slugs, true ) && isset( $kids[ (int) $p[1] ] ) ) $want[] = $kids[ (int) $p[1] ];
					}
					if ( $want ) $out = get_posts( $base + array( 'category__in' => array_unique( $want ) ) );
				}
			}
		}
		$out = array_map( 'intval', $out );
		set_transient( $key, $out, 12 * HOUR_IN_SECONDS );
		return $out;
	}

	public static function box( $post_id ) {
		$ids = self::picks( $post_id );
		if ( ! $ids ) return '';
		$o   = self::opt();
		$li  = '';
		foreach ( $ids as $p ) {
			$th  = get_the_post_thumbnail( $p, 'thumbnail', array( 'loading' => 'lazy', 'alt' => '' ) );
			$li .= '<li><a href="' . esc_url( get_permalink( $p ) ) . '">' . ( $th ? '<span class="lmgf-ts-th">' . $th . '</span>' : '' ) . '<span>' . esc_html( get_the_title( $p ) ) . '</span></a></li>';
		}
		$all = '';
		if ( $o['landing'] && get_post_status( $o['landing'] ) === 'publish' ) $all = get_permalink( $o['landing'] );
		elseif ( $o['parent'] ) { $l = get_term_link( (int) $o['parent'], 'category' ); $all = is_wp_error( $l ) ? '' : $l; }
		$h  = '<aside class="lmgf lmgf-box lmgf-ts-box">';
		$h .= '<p class="lmgf-title">' . esc_html( self::words( 'box_title' ) ) . '</p><ul class="lmgf-ts-list">' . $li . '</ul>';
		if ( $all ) $h .= '<p class="lmgf-ts-all"><a href="' . esc_url( $all ) . '">' . esc_html( self::words( 'all' ) ) . ' →</a></p>';
		return $h . '</aside>';
	}

	public static function flush_picks() {
		global $wpdb;
		$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_lmgf\\_ts\\_%' OR option_name LIKE '\\_transient\\_timeout\\_lmgf\\_ts\\_%'" );
	}

	// ---- Admin: actions ------------------------------------------------------------

	private static function back( $args = array() ) {
		wp_safe_redirect( add_query_arg( $args, LMGF_Admin::url( self::TAB ) ) );
		exit;
	}

	public static function actions() {
		if ( empty( $_POST['lmgf_ts_do'] ) || ! current_user_can( 'manage_options' ) ) return;
		check_admin_referer( 'lmgf_ts', 'lmgf_ts_nonce' );
		$do = sanitize_key( $_POST['lmgf_ts_do'] );
		if ( $do === 'create' ) self::back( array( 'done' => self::create() ) );
		if ( $do === 'settings' ) { self::save_settings(); self::back( array( 'done' => 'saved' ) ); }
		if ( $do === 'landing' ) self::back( array( 'done' => self::landing() ) );
		if ( $do === 'menu' ) self::back( array( 'done' => self::add_menu() ) );
		if ( $do === 'restore' ) self::back( array( 'done' => self::restore( isset( $_POST['pick'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['pick'] ) ) : array() ) ) );
		if ( $do === 'apply' ) self::back( array( 'done' => self::apply( isset( $_POST['lines'] ) ? wp_unslash( $_POST['lines'] ) : '' ) ) );
		if ( $do === 'undo' ) self::back( array( 'done' => self::undo( isset( $_POST['run'] ) ? absint( $_POST['run'] ) : -1 ) ) );
	}

	/** Creates the parent and the missing children. An existing category with the same slug is adopted, not duplicated. */
	public static function create() {
		$o    = self::opt();
		$defs = self::defs();
		$made = 0; $adopted = 0; $stopped = array();

		$p = get_term_by( 'slug', $defs[0][0], 'category' );
		if ( ! $p ) {
			$r = wp_insert_term( $defs[0][1], 'category', array( 'slug' => $defs[0][0], 'description' => $defs[0][2] ) );
			if ( is_wp_error( $r ) ) return 'error';
			$pid = (int) $r['term_id']; $made++;
		} else {
			$pid = (int) $p->term_id;
		}
		$o['parent'] = $pid;

		self::save_opt( $o ); // the address filter needs the parent from here on

		// Children: an existing category from the adopt list is moved in, else the brief's own is made.
		foreach ( $defs as $n => $d ) {
			if ( ! $n ) continue;
			if ( ! empty( $o['children'][ $n ] ) && get_term( (int) $o['children'][ $n ], 'category' ) ) {
				$t = get_term( (int) $o['children'][ $n ], 'category' );
				if ( (int) $t->parent !== $pid ) { $r = self::move_in( $t, $pid, $o ); if ( $r === 'stopped' ) $stopped[] = $t->name; }
				continue;
			}
			$t = null;
			foreach ( self::adopt( $n ) as $slug ) { $t = get_term_by( 'slug', $slug, 'category' ); if ( $t ) break; }
			if ( $t ) {
				if ( trim( $t->description ) === '' ) wp_update_term( $t->term_id, 'category', array( 'description' => $d[2] ) );
				$r = self::move_in( $t, $pid, $o );
				if ( $r === 'stopped' ) { $stopped[] = $t->name; continue; }
				$o['children'][ $n ] = (int) $t->term_id; $adopted++;
				self::save_opt( $o );
				continue;
			}
			$r = wp_insert_term( $d[1], 'category', array( 'slug' => $d[0], 'parent' => $pid, 'description' => $d[2] ) );
			if ( ! is_wp_error( $r ) ) { $o['children'][ $n ] = (int) $r['term_id']; $made++; self::save_opt( $o ); }
		}

		// Existing categories that go one level further down, under a child (for example Rejseforsikring under Rejsepraktisk).
		foreach ( self::nest() as $n => $slugs ) {
			if ( empty( $o['children'][ $n ] ) ) continue;
			foreach ( $slugs as $slug ) {
				$t = get_term_by( 'slug', $slug, 'category' );
				if ( ! $t || (int) $t->parent === (int) $o['children'][ $n ] ) continue;
				$r = self::move_in( $t, (int) $o['children'][ $n ], $o );
				if ( $r === 'stopped' ) $stopped[] = $t->name; else $adopted++;
				self::save_opt( $o );
			}
		}
		$o['stopped'] = $stopped;
		self::save_opt( $o );
		self::flush_picks();
		return 'created-' . $made . '-' . $adopted;
	}

	/** Existing categories (by address) that become child n, first found wins. */
	public static function adopt( $n ) {
		$a = self::is_travel() ? array() : array( 1 => array( 'flyselskaber' ), 2 => array( 'lufthavne' ), 7 => array( 'hoteller' ), 8 => array( 'rejsebureauer' ) );
		$a = apply_filters( 'lmgf_ts_adopt', $a );
		$d = self::defs();
		return array_unique( array_merge( isset( $a[ $n ] ) ? (array) $a[ $n ] : array(), array( $d[ $n ][0] ) ) );
	}

	/** Existing categories that go under a child. */
	public static function nest() {
		$a = self::is_travel() ? array() : array( 9 => array( 'rejseforsikring', 'rejseoekonomi', 'rejseudstyr' ) );
		return apply_filters( 'lmgf_ts_nest', $a );
	}

	/** Every post address in a category, id => link. */
	private static function links_in( $term_id ) {
		$out = array();
		$ids = get_posts( array( 'post_type' => 'any', 'post_status' => 'publish', 'cat' => (int) $term_id, 'posts_per_page' => -1, 'fields' => 'ids', 'no_found_rows' => true, 'suppress_filters' => true ) );
		foreach ( $ids as $id ) $out[ $id ] = get_permalink( $id );
		return $out;
	}

	/**
	 * Moves a category under a new parent. Its old place in post addresses is
	 * remembered and kept (see keep_link), every published post's address is
	 * compared before and after, and if a single one differs the move is undone.
	 */
	private static function move_in( $t, $parent, array &$o ) {
		$before   = self::links_in( $t->term_id );
		$old_path = trailingslashit( (string) wp_parse_url( get_term_link( $t ), PHP_URL_PATH ) );
		$old_par  = (int) $t->parent;
		$o['flat'][ (int) $t->term_id ] = self::cat_path( $t );
		self::save_opt( $o );
		wp_update_term( $t->term_id, 'category', array( 'parent' => (int) $parent ) );
		clean_term_cache( $t->term_id, 'category' );
		if ( function_exists( 'wp_cache_flush_group' ) ) wp_cache_flush_group( 'category_relationships' );
		foreach ( array_keys( $before ) as $id ) clean_post_cache( $id );
		$after = self::links_in( $t->term_id );
		foreach ( $before as $id => $link ) {
			if ( ! isset( $after[ $id ] ) || $after[ $id ] !== $link ) {
				wp_update_term( $t->term_id, 'category', array( 'parent' => $old_par ) );
				clean_term_cache( $t->term_id, 'category' );
				unset( $o['flat'][ (int) $t->term_id ] );
				self::save_opt( $o );
				return 'stopped';
			}
		}
		$new_path = trailingslashit( (string) wp_parse_url( get_term_link( (int) $t->term_id, 'category' ), PHP_URL_PATH ) );
		if ( $old_path !== $new_path ) $o['moved'][ $old_path ] = (int) $t->term_id;
		self::save_opt( $o );
		return 'moved';
	}

	/** slug path of a category as it is now, e.g. "rejsebureauer" or "rejseinteresser/krydstogt". */
	public static function cat_path( $t ) {
		$path = $t->slug;
		foreach ( get_ancestors( (int) $t->term_id, 'category', 'taxonomy' ) as $a ) {
			$at = get_term( $a, 'category' );
			if ( $at && ! is_wp_error( $at ) ) $path = $at->slug . '/' . $path;
		}
		return $path;
	}

	/**
	 * Post addresses on sites whose permalinks contain the category (traveltalk.dk):
	 * a category moved under Rejseservice keeps its old place in the address,
	 * so /rejsebureauer/tui/ stays /rejsebureauer/tui/. New subcategories get a short address too.
	 */
	public static function keep_link( $link, $post ) {
		if ( strpos( (string) get_option( 'permalink_structure' ), '%category%' ) === false ) return $link;
		$o = self::opt();
		if ( empty( $o['parent'] ) ) return $link;
		$post = get_post( $post );
		if ( ! $post || ! in_array( $post->post_status, array( 'publish', 'future', 'private', 'draft', 'pending' ), true ) ) return $link;
		$cats = get_the_category( $post->ID );
		if ( ! $cats ) return $link;
		$cats = wp_list_sort( $cats, array( 'term_id' => 'ASC' ) );
		$cat  = apply_filters( 'post_link_category', $cats[0], $cats, $post );
		$cat  = get_term( $cat, 'category' );
		if ( ! $cat || is_wp_error( $cat ) ) return $link;
		$tree = array_map( 'intval', get_ancestors( (int) $cat->term_id, 'category', 'taxonomy' ) );
		if ( (int) $cat->term_id !== (int) $o['parent'] && ! in_array( (int) $o['parent'], $tree, true ) ) return $link;
		$full = self::cat_path( $cat );
		$flat = isset( $o['flat'][ (int) $cat->term_id ] ) ? $o['flat'][ (int) $cat->term_id ] : $cat->slug;
		if ( $full === $flat ) return $link;
		$enc = implode( '/', array_map( 'rawurlencode', explode( '/', $full ) ) );
		$from = '/' . $full . '/';
		if ( strpos( $link, $from ) !== false ) return str_replace( $from, '/' . $flat . '/', $link );
		$from = '/' . $enc . '/';
		return strpos( $link, $from ) !== false ? str_replace( $from, '/' . $flat . '/', $link ) : $link;
	}

	private static function save_settings() {
		$o  = self::opt();
		$in = isset( $_POST['ts'] ) ? (array) wp_unslash( $_POST['ts'] ) : array();
		$o['hero'] = array();
		foreach ( isset( $in['hero'] ) ? (array) $in['hero'] : array() as $n => $v ) if ( absint( $v ) ) $o['hero'][ (int) $n ] = absint( $v );
		$o['pages'] = array();
		foreach ( isset( $in['pages'] ) ? (array) $in['pages'] : array() as $n => $v ) {
			$ids = array();
			foreach ( preg_split( '/[\s,]+/', (string) $v ) as $bit ) {
				$id = ctype_digit( $bit ) ? (int) $bit : ( $bit !== '' ? url_to_postid( $bit ) : 0 );
				if ( $id ) $ids[] = $id;
			}
			if ( $ids ) $o['pages'][ (int) $n ] = implode( "\n", array_unique( $ids ) );
		}
		$o['box']      = in_array( isset( $in['box'] ) ? $in['box'] : '', array( 'off', 'pilot', 'on' ), true ) ? $in['box'] : 'off';
		$o['pilot']    = implode( "\n", self::ids( isset( $in['pilot'] ) ? $in['pilot'] : '' ) );
		$o['interest'] = sanitize_textarea_field( isset( $in['interest'] ) ? $in['interest'] : '' );
		$o['archives'] = empty( $in['archives'] ) ? 0 : 1;
		$o['landing']  = absint( isset( $in['landing'] ) ? $in['landing'] : 0 );
		self::save_opt( $o );
		self::flush_picks();
	}

	/** The menu in the theme's first menu location, else the first menu. */
	public static function main_menu() {
		$locs = get_nav_menu_locations();
		foreach ( array( 'primary', 'main', 'header', 'mobile' ) as $l ) if ( ! empty( $locs[ $l ] ) ) { $m = wp_get_nav_menu_object( $locs[ $l ] ); if ( $m ) return $m; }
		foreach ( $locs as $id ) { $m = $id ? wp_get_nav_menu_object( $id ) : false; if ( $m ) return $m; }
		$all = wp_get_nav_menus();
		return $all ? $all[0] : null;
	}

	public static function in_menu() {
		$m = self::main_menu();
		$p = (int) self::opt()['parent'];
		if ( ! $m || ! $p ) return false;
		foreach ( (array) wp_get_nav_menu_items( $m->term_id ) as $it ) if ( $it->type === 'taxonomy' && (int) $it->object_id === $p ) return true;
		return false;
	}

	private static function add_menu() {
		$m = self::main_menu();
		$p = (int) self::opt()['parent'];
		if ( ! $m || ! $p || self::in_menu() ) return 'menu-ok';
		$item = function ( $term, $parent_item ) use ( $m ) {
			return wp_update_nav_menu_item( $m->term_id, 0, array( 'menu-item-object' => 'category', 'menu-item-object-id' => (int) $term, 'menu-item-type' => 'taxonomy', 'menu-item-status' => 'publish', 'menu-item-parent-id' => (int) $parent_item ) );
		};
		$top = $item( $p, 0 );
		if ( is_wp_error( $top ) ) return 'error';
		foreach ( self::children() as $t ) $item( $t, $top );
		return 'menu-made';
	}

	// ---- Restore old pages ----------------------------------------------------

	/** Pages saved from this site's earlier version, shipped with the plugin: path => [title, meta, html, child, snapshot, note]. */
	public static function restore_set() {
		$host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$file = LMGF_DIR . 'restore/' . ( strpos( $host, 'traveltalk.travel' ) !== false ? 'traveltalk-travel' : 'none' ) . '.json';
		if ( ! is_readable( $file ) ) return array();
		$d = json_decode( (string) file_get_contents( $file ), true );
		return is_array( $d ) ? $d : array();
	}

	/** A page or post already at this address, in any status. */
	public static function at_path( $path ) {
		$p = get_page_by_path( trim( $path, '/' ), OBJECT, array( 'page', 'post' ) );
		if ( $p ) return $p;
		$trash = get_posts( array( 'post_type' => array( 'page', 'post' ), 'post_status' => 'trash', 'name' => basename( trim( $path, '/' ) ) . '__trashed', 'posts_per_page' => 1 ) );
		return $trash ? $trash[0] : null;
	}

	/** Brings the chosen pages back as drafts at their old address. Never overwrites, never publishes. */
	private static function restore( array $pick ) {
		$set = self::restore_set();
		if ( ! $set || ! $pick ) return 'error';
		uksort( $set, function ( $a, $b ) { return substr_count( $a, '/' ) - substr_count( $b, '/' ) ?: strcmp( $a, $b ); } );
		$o = self::opt(); $made = 0; $skip = 0; $fail = 0; $left = 0; $done = 0;
		if ( function_exists( 'set_time_limit' ) ) @set_time_limit( 300 );
		foreach ( $set as $path => $it ) {
			if ( ! in_array( $path, $pick, true ) ) continue;
			if ( self::at_path( $path ) ) { $skip++; continue; }
			$segs   = array_values( array_filter( explode( '/', $path ) ) );
			$slug   = array_pop( $segs );
			$parent = 0;
			if ( $segs ) {
				$pp = get_page_by_path( implode( '/', $segs ), OBJECT, 'page' );
				if ( ! $pp ) { $skip++; continue; }
				$parent = (int) $pp->ID;
			}
			if ( $done >= self::RESTORE_BATCH ) { $left++; continue; }
			$html = ! empty( $it['fetch'] ) ? self::fetch_old( $path, $it['snapshot'] ) : (string) $it['html'];
			if ( $html === '' ) { $fail++; continue; }
			$done++;
			$id = wp_insert_post( array(
				'post_type'    => 'page',
				'post_status'  => 'draft',
				'post_title'   => $it['title'],
				'post_name'    => $slug,
				'post_parent'  => $parent,
				'post_content' => wp_slash( $html ),
				'post_excerpt' => '',
			), true );
			if ( is_wp_error( $id ) ) { $skip++; continue; }
			update_post_meta( $id, '_lmgf_restored', array( 'path' => $path, 'snapshot' => $it['snapshot'], 'note' => $it['note'] ) );
			if ( $it['meta'] !== '' ) update_post_meta( $id, 'rank_math_description', $it['meta'] );
			$made++;
			if ( ! $segs && ! empty( $it['child'] ) ) {
				$n   = (int) $it['child'];
				$ids = self::ids( isset( $o['pages'][ $n ] ) ? $o['pages'][ $n ] : '' );
				if ( ! in_array( (int) $id, $ids, true ) ) { $ids[] = (int) $id; $o['pages'][ $n ] = implode( "\n", $ids ); }
			}
		}
		self::save_opt( $o );
		return 'restored-' . $made . '-' . $skip . '-' . $fail . '-' . $left;
	}

	const RESTORE_BATCH = 12;

	/** The old page's text from its Internet Archive copy, as blocks; '' if it cannot be read. */
	public static function fetch_old( $path, $snap ) {
		if ( ! preg_match( '/^\d{8,14}$/', (string) $snap ) ) return '';
		$host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$url  = 'https://web.archive.org/web/' . $snap . 'id_/https://' . ( strpos( $host, 'www.' ) === 0 ? $host : 'www.' . $host ) . $path;
		$r    = wp_remote_get( $url, array( 'timeout' => 20, 'redirection' => 5, 'user-agent' => 'LMG Faktabokse restore' ) );
		if ( is_wp_error( $r ) || (int) wp_remote_retrieve_response_code( $r ) !== 200 ) return '';
		return self::extract_old( (string) wp_remote_retrieve_body( $r ) );
	}

	public static function extract_old( $raw ) {
		if ( $raw === '' || stripos( $raw, 'coming soon' ) !== false && stripos( $raw, 'content-cell-two' ) === false ) return '';
		$doc = new DOMDocument();
		$prev = libxml_use_internal_errors( true );
		$doc->loadHTML( '<?xml encoding="utf-8"?>' . $raw );
		libxml_clear_errors();
		libxml_use_internal_errors( $prev );
		$xp   = new DOMXPath( $doc );
		$root = null;
		foreach ( array( "//*[contains(concat(' ',normalize-space(@class),' '),' content-cell-two ')]", '//article', "//*[contains(concat(' ',normalize-space(@class),' '),' entry-content ')]" ) as $q ) {
			$n = $xp->query( $q );
			if ( $n && $n->length ) { $root = $n->item( 0 ); break; }
		}
		if ( ! $root ) return '';
		$junk = '/make your travel dreams|bookyourtrip|book your trip|did you know|coming soon|^\s*(photo|foto|image|credit)\s*[:©]/i';
		$out  = array();
		foreach ( $xp->query( './/h2|.//h3|.//h4|.//p|.//ul|.//ol', $root ) as $el ) {
			for ( $a = $el->parentNode; $a && $a !== $root; $a = $a->parentNode ) if ( in_array( strtolower( $a->nodeName ), array( 'p', 'ul', 'ol', 'h2', 'h3', 'h4', 'figcaption' ), true ) ) continue 2;
			$tag = strtolower( $el->nodeName );
			if ( $tag === 'ul' || $tag === 'ol' ) {
				$li = '';
				foreach ( $el->getElementsByTagName( 'li' ) as $i ) { $t = trim( preg_replace( '/\s+/u', ' ', $i->textContent ) ); if ( $t !== '' && ! preg_match( $junk, $t ) ) $li .= '<li>' . esc_html( $t ) . '</li>'; }
				if ( $li !== '' ) $out[] = '<!-- wp:list' . ( $tag === 'ol' ? ' {"ordered":true}' : '' ) . " -->\n<{$tag}>{$li}</{$tag}>\n<!-- /wp:list -->";
				continue;
			}
			$t = trim( preg_replace( '/\s+/u', ' ', $el->textContent ) );
			if ( $t === '' || preg_match( $junk, $t ) ) continue;
			if ( $tag === 'p' ) $out[] = "<!-- wp:paragraph -->\n<p>" . esc_html( $t ) . "</p>\n<!-- /wp:paragraph -->";
			else { $lv = (int) substr( $tag, 1 ); $out[] = '<!-- wp:heading' . ( $lv !== 2 ? ' {"level":' . $lv . '}' : '' ) . " -->\n<{$tag}>" . esc_html( $t ) . "</{$tag}>\n<!-- /wp:heading -->"; }
		}
		return str_word_count( wp_strip_all_tags( implode( ' ', $out ) ) ) < 25 ? '' : implode( "\n\n", $out );
	}

	/** A draft landing page with the cards. An existing page on the same slug is used as it is, never changed. */
	private static function landing() {
		$o    = self::opt();
		$defs = self::defs();
		$have = get_page_by_path( $defs[0][0] );
		if ( $have ) {
			$o['landing'] = (int) $have->ID;
			self::save_opt( $o );
			return has_shortcode( $have->post_content, 'lmg_rejseservice' ) ? 'landing-ok' : 'landing-exists';
		}
		$id = wp_insert_post( array(
			'post_type'    => 'page',
			'post_status'  => 'draft',
			'post_title'   => $defs[0][1],
			'post_name'    => $defs[0][0],
			'post_content' => "<!-- wp:shortcode -->\n[lmg_rejseservice]\n<!-- /wp:shortcode -->",
		) );
		if ( ! $id || is_wp_error( $id ) ) return 'error';
		$o['landing'] = (int) $id;
		self::save_opt( $o );
		return 'landing-made';
	}

	/** "post id or URL | child number" lines into [post, term] pairs plus problems. */
	public static function parse( $text ) {
		$kids = self::children();
		$rows = array(); $bad = array();
		foreach ( preg_split( '/\R/', (string) $text ) as $line ) {
			$line = trim( $line );
			if ( $line === '' ) continue;
			$p = array_map( 'trim', preg_split( '/[|;\t]/', $line ) );
			$id = isset( $p[0] ) ? ( ctype_digit( $p[0] ) ? (int) $p[0] : url_to_postid( $p[0] ) ) : 0;
			$n  = isset( $p[1] ) ? (int) $p[1] : 0;
			if ( ! $id || ! get_post( $id ) ) { $bad[] = array( $line, 'post not found' ); continue; }
			if ( ! isset( $kids[ $n ] ) ) { $bad[] = array( $line, 'child must be 1–9 and created' ); continue; }
			if ( ! is_object_in_taxonomy( get_post_type( $id ), 'category' ) ) { $bad[] = array( $line, get_post_type( $id ) . ' has no categories; link it under Related pages instead' ); continue; }
			$rows[] = array( $id, $kids[ $n ] );
		}
		return array( $rows, $bad );
	}

	/** Adds the child as an extra category. Primary category and URL never change; if the URL would change, the post is put back and listed. */
	private static function apply( $text ) {
		list( $rows ) = self::parse( $text );
		$done = array(); $kept = 0;
		$stopped = array();
		foreach ( $rows as $r ) {
			list( $id, $t ) = $r;
			if ( has_term( $t, 'category', $id ) ) { $kept++; continue; }
			$before  = get_permalink( $id );
			$old     = wp_get_post_terms( $id, 'category', array( 'fields' => 'ids' ) );
			wp_set_post_terms( $id, array( $t ), 'category', true );
			clean_post_cache( $id );
			if ( get_permalink( $id ) !== $before ) {
				wp_set_post_terms( $id, $old, 'category', false );
				$stopped[] = $id;
				continue;
			}
			$done[] = array( $id, $t );
		}
		$runs = (array) get_option( 'lmgf_ts_runs', array() );
		if ( $done || $stopped ) {
			array_unshift( $runs, array( 'time' => time(), 'user' => get_current_user_id(), 'rows' => $done, 'stopped' => $stopped ) );
			update_option( 'lmgf_ts_runs', array_slice( $runs, 0, 10 ), false );
		}
		self::flush_picks();
		return 'applied-' . count( $done ) . '-' . $kept . '-' . count( $stopped );
	}

	private static function undo( $i ) {
		$runs = (array) get_option( 'lmgf_ts_runs', array() );
		if ( ! isset( $runs[ $i ] ) ) return 'error';
		$n = 0;
		foreach ( (array) $runs[ $i ]['rows'] as $r ) {
			wp_remove_object_terms( (int) $r[0], (int) $r[1], 'category' );
			$n++;
		}
		$runs[ $i ]['undone'] = time();
		update_option( 'lmgf_ts_runs', $runs, false );
		self::flush_picks();
		return 'undone-' . $n;
	}

	// ---- Admin: inventory ----------------------------------------------------------

	/** Look-up only: posts and pages in every status whose title matches a child's words. */
	public static function inventory() {
		global $wpdb;
		$types = array_values( array_diff( get_post_types( array( 'public' => true ) ), array( 'attachment' ) ) );
		$in    = "'" . implode( "','", array_map( 'esc_sql', $types ) ) . "'";
		$out   = array();
		foreach ( self::defs() as $n => $d ) {
			if ( ! $n || $d[3] === '' ) continue;
			$re   = '(' . str_replace( ' ', '[[:space:]]', $d[3] ) . ')';
			$rows = $wpdb->get_results( $wpdb->prepare(
				"SELECT ID, post_title, post_status, post_type, post_modified FROM {$wpdb->posts} WHERE post_type IN ($in) AND post_status IN ('publish','draft','pending','private','future','trash') AND LOWER(post_title) REGEXP %s ORDER BY post_status, post_title LIMIT 400",
				$re
			) );
			foreach ( $rows as $r ) {
				if ( get_post_meta( $r->ID, '_lmgt_source', true ) ) continue;
				if ( ! isset( $out[ $r->ID ] ) ) $out[ $r->ID ] = array( 'post' => $r, 'child' => array() );
				$out[ $r->ID ]['child'][] = $n;
			}
		}
		return $out;
	}

	public static function csv() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'No access.' );
		check_admin_referer( 'lmgf_ts_csv' );
		$host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="rejseservice-inventory-' . sanitize_file_name( $host ) . '-' . gmdate( 'Y-m-d' ) . '.csv"' );
		$f = fopen( 'php://output', 'w' );
		fwrite( $f, "\xEF\xBB\xBF" );
		fputcsv( $f, array( 'id', 'url', 'title', 'status', 'type', 'proposed child', 'current categories', 'featured image', 'last modified', 'assign line' ) );
		$kids = self::children();
		foreach ( self::inventory() as $id => $row ) {
			$p    = $row['post'];
			$cats = is_object_in_taxonomy( $p->post_type, 'category' ) ? wp_get_post_terms( $id, 'category', array( 'fields' => 'names' ) ) : array();
			$url  = $p->post_status === 'publish' ? get_permalink( $id ) : home_url( '/?p=' . $id );
			fputcsv( $f, array( $id, $url, $p->post_title, $p->post_status, $p->post_type, implode( ' / ', $row['child'] ), is_wp_error( $cats ) ? '' : implode( ', ', $cats ), has_post_thumbnail( $id ) ? 'y' : 'n', $p->post_modified, $id . ' | ' . $row['child'][0] ) );
		}
		fclose( $f );
		exit;
	}

	// ---- Admin: tab ----------------------------------------------------------------

	private static function form_open( $do ) {
		echo '<form method="post">';
		wp_nonce_field( 'lmgf_ts', 'lmgf_ts_nonce' );
		echo '<input type="hidden" name="lmgf_ts_do" value="' . esc_attr( $do ) . '">';
	}

	private static function notice() {
		if ( empty( $_GET['done'] ) ) return;
		$d = sanitize_text_field( wp_unslash( $_GET['done'] ) );
		$p = explode( '-', $d );
		$msg = array(
			'saved'          => 'Saved.',
			'error'          => 'Something went wrong. Nothing was changed.',
			'landing-made'   => 'A draft landing page was made. Look at it, then publish it when you are happy.',
			'landing-exists' => 'A page with this address already exists, so it was used as the landing page and not changed. Add [lmg_rejseservice] to it where the cards should go.',
			'landing-ok'     => 'The existing page already has the cards.',
			'menu-made'      => 'Added to the main menu with the nine subcategories under it.',
			'menu-ok'        => 'It is already in the menu.',
		);
		if ( isset( $msg[ $d ] ) ) $text = $msg[ $d ];
		elseif ( $p[0] === 'created' ) $text = sprintf( 'Categories made: %d. Existing categories moved in as subcategories: %d.', (int) $p[1], (int) $p[2] );
		elseif ( $p[0] === 'applied' ) $text = sprintf( 'Subcategory added to %d posts. Already there: %d.', (int) $p[1], (int) $p[2] ) . ( (int) $p[3] ? sprintf( ' Stopped on %d posts because their address would have changed; they were put back as they were and are listed under Earlier runs.', (int) $p[3] ) : '' );
		elseif ( $p[0] === 'restored' ) $text = sprintf( 'Restored as drafts: %d. Skipped (already there, or its hub page is missing): %d. Find them under Pages → Drafts.', (int) $p[1], (int) $p[2] ) . ( ! empty( $p[3] ) ? sprintf( ' Could not be read from the Internet Archive this time: %d; try again later.', (int) $p[3] ) : '' ) . ( ! empty( $p[4] ) ? sprintf( ' %d more are still ticked: press the button again (%d pages per press, so the server does not time out).', (int) $p[4], self::RESTORE_BATCH ) : '' );
		elseif ( $p[0] === 'undone' ) $text = sprintf( 'Undone: the category was taken off %d posts again.', (int) $p[1] );
		else return;
		echo '<div class="notice notice-success inline"><p>' . esc_html( $text ) . '</p></div>';
	}

	public static function tab() {
		$o    = self::opt();
		$defs = self::defs();
		$kids = self::children();
		self::notice();

		// 1. Categories
		echo '<p style="font-size:14px;max-width:980px"><strong>' . esc_html( $defs[0][1] ) . '</strong> is a top-level category on this site. The nine services below are its subcategories. Posts are filed in them like in any other category, and the category pages and menu work as usual.</p>';
		echo '<h2>1. Top-level category and subcategories</h2><p>Existing categories are moved in with their posts. Every post keeps its address: the plugin checks each published post\'s address before and after the move, and undoes the move if a single one would change. The category pages get a new address under ' . esc_html( $defs[0][1] ) . ', and the old one sends readers on.</p>';
		if ( ! empty( $o['stopped'] ) ) echo '<div class="notice notice-warning inline"><p>Not moved, because a post address would have changed: <strong>' . esc_html( implode( ', ', (array) $o['stopped'] ) ) . '</strong>. Nothing was changed for these.</p></div>';
		echo '<table class="widefat striped" style="max-width:980px"><thead><tr><th>#</th><th>Category</th><th>Address</th><th>Status</th><th>Posts</th></tr></thead><tbody>';
		foreach ( $defs as $n => $d ) {
			$tid  = $n ? ( isset( $kids[ $n ] ) ? $kids[ $n ] : 0 ) : (int) $o['parent'];
			$term = $tid ? get_term( $tid, 'category' ) : null;
			if ( ! $term ) foreach ( $n ? self::adopt( $n ) : array( $d[0] ) as $slug ) { $term = get_term_by( 'slug', $slug, 'category' ); if ( $term ) break; }
			$ok   = $term && ! is_wp_error( $term );
			$in   = $ok && ( $n ? (int) $term->parent === (int) $o['parent'] && $o['parent'] : true ) && $tid;
			$st   = $in ? '<span style="color:#008a20">in place</span>' : ( $ok ? 'existing category, will be moved in' : 'new, will be made' );
			echo '<tr><td>' . ( $n ? (int) $n : 'top' ) . '</td><td>' . ( $n ? '— ' : '<strong>' ) . esc_html( $ok ? $term->name : $d[1] ) . ( $n ? '' : '</strong>' ) . '</td><td><code>' . esc_html( $ok ? $term->slug : $d[0] ) . '</code></td><td>' . $st . '</td><td>' . ( $ok ? (int) $term->count : 0 ) . '</td></tr>';
			$nest = self::nest();
			if ( $n && isset( $nest[ $n ] ) ) foreach ( $nest[ $n ] as $slug ) {
				$nt = get_term_by( 'slug', $slug, 'category' );
				if ( ! $nt ) continue;
				$nin = $tid && (int) $nt->parent === (int) $tid;
				echo '<tr><td></td><td>&nbsp;&nbsp;&nbsp;&nbsp;— ' . esc_html( $nt->name ) . '</td><td><code>' . esc_html( $nt->slug ) . '</code></td><td>' . ( $nin ? '<span style="color:#008a20">in place</span>' : 'existing category, will be moved in' ) . '</td><td>' . (int) $nt->count . '</td></tr>';
			}
		}
		echo '</tbody></table>';
		self::form_open( 'create' );
		submit_button( count( $kids ) === 9 && $o['parent'] ? 'Check categories again' : 'Make the top-level category and subcategories', 'primary', 'go', false );
		echo '</form>';
		if ( ! $kids ) return;

		// 2. Inventory
		$inv = self::inventory();
		$by  = array();
		foreach ( $inv as $row ) foreach ( $row['child'] as $n ) $by[ $n ][ $row['post']->post_status ] = ( isset( $by[ $n ][ $row['post']->post_status ] ) ? $by[ $n ][ $row['post']->post_status ] : 0 ) + 1;
		echo '<h2 style="margin-top:2em">2. Inventory (look-up only)</h2><p>Posts and pages in every status, also drafts, private and trash, whose title fits a subcategory. It is a starting list, not a decision: check it, then paste the lines you approve into step 3.</p>';
		echo '<table class="widefat striped" style="max-width:980px"><thead><tr><th>#</th><th>Child</th><th>Published</th><th>Draft / pending</th><th>Private</th><th>Trash</th></tr></thead><tbody>';
		foreach ( $defs as $n => $d ) {
			if ( ! $n ) continue;
			$b = isset( $by[ $n ] ) ? $by[ $n ] : array();
			$g = function ( $k ) use ( $b ) { return isset( $b[ $k ] ) ? (int) $b[ $k ] : 0; };
			echo '<tr><td>' . (int) $n . '</td><td>' . esc_html( $d[1] ) . '</td><td>' . $g( 'publish' ) . '</td><td>' . ( $g( 'draft' ) + $g( 'pending' ) + $g( 'future' ) ) . '</td><td>' . $g( 'private' ) . '</td><td>' . $g( 'trash' ) . '</td></tr>';
		}
		echo '</tbody></table><p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=lmgf_ts_csv' ), 'lmgf_ts_csv' ) ) . '">Download the inventory (CSV)</a> <span class="description">' . count( $inv ) . ' posts and pages. The last column is a ready line for step 3.</span></p>';

		// 3. Assign
		$lines = isset( $_POST['lines'] ) ? sanitize_textarea_field( wp_unslash( $_POST['lines'] ) ) : '';
		echo '<h2 style="margin-top:2em">3. File posts in a subcategory</h2><p>One line per post: post ID or address | subcategory number. Example: <code>48211 | 2</code>. The subcategory is added as an extra category. The primary category and the address stay as they are; a post whose address would change is put back and listed. Only published and draft posts with categories can be added; pages are linked under step 4 instead.</p>';
		echo '<form method="post">';
		wp_nonce_field( 'lmgf_ts', 'lmgf_ts_nonce' );
		echo '<textarea name="lines" rows="8" class="large-text code">' . esc_textarea( $lines ) . '</textarea>';
		echo '<p><button class="button" name="lmgf_ts_do" value="preview">Show what will happen</button> ';
		if ( $lines !== '' && isset( $_POST['lmgf_ts_do'] ) && $_POST['lmgf_ts_do'] === 'preview' ) echo '<button class="button button-primary" name="lmgf_ts_do" value="apply">Add the categories</button>';
		echo '</p></form>';
		if ( $lines !== '' && isset( $_POST['lmgf_ts_do'] ) && $_POST['lmgf_ts_do'] === 'preview' && check_admin_referer( 'lmgf_ts', 'lmgf_ts_nonce' ) ) {
			list( $rows, $bad ) = self::parse( $lines );
			echo '<table class="widefat striped" style="max-width:980px"><thead><tr><th>Post</th><th>Status</th><th>Gets</th><th>Primary category</th><th></th></tr></thead><tbody>';
			foreach ( $rows as $r ) {
				$pr = (int) get_post_meta( $r[0], 'rank_math_primary_category', true );
				$pt = $pr ? get_term( $pr, 'category' ) : null;
				echo '<tr><td><a href="' . esc_url( get_edit_post_link( $r[0] ) ) . '">' . esc_html( get_the_title( $r[0] ) ) . '</a> (' . (int) $r[0] . ')</td><td>' . esc_html( get_post_status( $r[0] ) ) . '</td><td>' . esc_html( get_term( $r[1], 'category' )->name ) . '</td><td>' . esc_html( $pt && ! is_wp_error( $pt ) ? $pt->name : '– (unchanged)' ) . '</td><td>' . ( has_term( $r[1], 'category', $r[0] ) ? 'already there' : 'will be added' ) . '</td></tr>';
			}
			foreach ( $bad as $b ) echo '<tr><td colspan="4"><code>' . esc_html( $b[0] ) . '</code></td><td style="color:#b32d2e">' . esc_html( $b[1] ) . '</td></tr>';
			echo '</tbody></table>';
		}
		$runs = (array) get_option( 'lmgf_ts_runs', array() );
		if ( $runs ) {
			echo '<h3>Earlier runs</h3><p class="description">Each run is saved, so it can be taken back. Undo removes only the categories that run added.</p><table class="widefat striped" style="max-width:980px"><tbody>';
			foreach ( $runs as $i => $r ) {
				$u = get_userdata( (int) $r['user'] );
				echo '<tr><td>' . esc_html( wp_date( 'j M Y H:i', (int) $r['time'] ) ) . '</td><td>' . esc_html( $u ? $u->display_name : '' ) . '</td><td>' . count( (array) $r['rows'] ) . ' added' . ( ! empty( $r['stopped'] ) ? ', stopped on ' . esc_html( implode( ', ', array_map( 'intval', $r['stopped'] ) ) ) : '' ) . '</td><td>';
				if ( ! empty( $r['undone'] ) ) echo 'undone ' . esc_html( wp_date( 'j M H:i', (int) $r['undone'] ) );
				elseif ( $r['rows'] ) { self::form_open( 'undo' ); echo '<input type="hidden" name="run" value="' . (int) $i . '"><button class="button-link">Undo</button></form>'; }
				echo '</td></tr>';
			}
			echo '</tbody></table>';
		}

		// Restore
		$set = self::restore_set();
		if ( $set ) {
			echo '<h2 style="margin-top:2em">Restore old pages</h2><p>' . count( $set ) . ' pages from this site\'s earlier version (saved from the Internet Archive). They come back as <strong>drafts</strong> at their old address, text only: choose images from the media library before publishing. The text is read from the Internet Archive when you press the button, ' . (int) self::RESTORE_BATCH . ' pages per press. Old booking lines ("Book your trip here") are left out. Unticked rows are ones we advise against (see the note). A page that already exists at that address is never touched. Hub pages (for example /airlines/) are restored first and linked to their subcategory.</p>';
			self::form_open( 'restore' );
			echo '<table class="widefat striped" style="max-width:980px"><thead><tr><th><input type="checkbox" checked onclick="jQuery(\'.lmgf-pick\').prop(\'checked\',this.checked)"></th><th>Address</th><th>Title</th><th>Words</th><th>Saved</th><th>Now</th><th>Note</th></tr></thead><tbody>';
			foreach ( $set as $path => $it ) {
				$now = self::at_path( $path );
				$w   = isset( $it['words'] ) ? (int) $it['words'] : str_word_count( wp_strip_all_tags( (string) $it['html'] ) );
				echo '<tr><td>' . ( $now ? '' : '<input type="checkbox" class="lmgf-pick" name="pick[]" value="' . esc_attr( $path ) . '"' . ( empty( $it['skip'] ) ? ' checked' : '' ) . '>' ) . '</td><td><code>' . esc_html( $path ) . '</code></td><td>' . esc_html( $it['title'] ) . '</td><td>' . (int) $w . '</td><td>' . esc_html( $it['snapshot'] ) . '</td><td>' . ( $now ? '<a href="' . esc_url( get_edit_post_link( $now->ID ) ) . '">' . esc_html( get_post_status( $now ) ) . '</a>' : '–' ) . '</td><td>' . esc_html( $it['note'] ) . '</td></tr>';
			}
			echo '</tbody></table><p>';
			submit_button( 'Restore the ticked pages as drafts', 'primary', 'go', false );
			echo '</p></form>';
		}

		// 4. Category pages
		echo '<h2 style="margin-top:2em">4. Category pages: hero images, related pages and landing page</h2>';
		self::form_open( 'settings' );
		echo '<table class="widefat striped" style="max-width:980px"><thead><tr><th>#</th><th>Hero image (from this site\'s media library)</th><th>Related pages (ID or address, one per line; their sub-pages are listed too)</th></tr></thead><tbody>';
		foreach ( $defs as $n => $d ) {
			$hid = isset( $o['hero'][ $n ] ) ? (int) $o['hero'][ $n ] : 0;
			echo '<tr><td>' . ( $n ? (int) $n : '–' ) . '<br><strong>' . esc_html( $d[1] ) . '</strong></td><td><span class="lmgf-ts-prev">' . ( $hid ? wp_get_attachment_image( $hid, array( 120, 80 ) ) : '<em style="color:#b32d2e">missing</em>' ) . '</span><br><input type="number" name="ts[hero][' . (int) $n . ']" value="' . ( $hid ?: '' ) . '" style="width:110px"> <button type="button" class="button lmgf-ts-pick">Choose</button></td><td>';
			if ( $n ) echo '<textarea name="ts[pages][' . (int) $n . ']" rows="2" class="large-text code">' . esc_textarea( isset( $o['pages'][ $n ] ) ? $o['pages'][ $n ] : '' ) . '</textarea>';
			else echo '<span class="description">The parent\'s category page shows the nine cards.</span>';
			echo '</td></tr>';
		}
		echo '</tbody></table>';
		$land = (int) $o['landing'];
		echo '<table class="form-table">';
		echo '<tr><th>Landing page</th><td><input type="number" name="ts[landing]" value="' . ( $land ?: '' ) . '" style="width:110px"> ' . ( $land && get_post( $land ) ? '<a href="' . esc_url( get_edit_post_link( $land ) ) . '">' . esc_html( get_the_title( $land ) ) . '</a> (' . esc_html( get_post_status( $land ) ) . ')' : '<span class="description">none yet; use the button below</span>' ) . '<p class="description">The page with [lmg_rejseservice], which shows the line "' . esc_html( self::words( 'intro' ) ) . '" and the nine cards.</p></td></tr>';
		echo '<tr><th>Category pages</th><td><label><input type="checkbox" name="ts[archives]" value="1" ' . checked( $o['archives'], 1, false ) . '> Show hero, cards and related pages on the Rejseservice category pages</label><p class="description">Visible to readers. Leave it off until the pilot is approved.</p></td></tr>';
		echo '</table><h2 style="margin-top:2em">5. Optional: links from destination posts</h2><p>Separate from the categories, and off unless you switch it on. Destination posts can show a short list "' . esc_html( self::words( 'box_title' ) ) . '" pointing readers to matching posts in the subcategories (brief, section 6).</p><table class="form-table">';
		echo '<tr><th>Links from destination posts</th><td><select name="ts[box]">';
		foreach ( array( 'off' => 'Off', 'pilot' => 'Pilot: only on the posts below', 'on' => 'On: all destination and travel-interest posts' ) as $k => $l ) echo '<option value="' . esc_attr( $k ) . '"' . selected( $o['box'], $k, false ) . '>' . esc_html( $l ) . '</option>';
		echo '</select><p class="description">Shown after the second heading. Up to four posts that are both in a Rejseservice child and in the post\'s own destination category; if there are none, posts from the child that fits its travel interest (list below); otherwise nothing is shown. Added when the page is shown, never written into the post.</p>';
		echo '<p><label>Pilot posts (IDs)</label><br><textarea name="ts[pilot]" rows="2" class="large-text code">' . esc_textarea( $o['pilot'] ) . '</textarea></p>';
		echo '<p><label>Travel interests, one per line: category address | child number</label><br><textarea name="ts[interest]" rows="4" class="large-text code">' . esc_textarea( $o['interest'] ) . '</textarea></p></td></tr>';
		echo '</table>';
		submit_button( 'Save', 'primary', 'go', false );
		echo '</form>';
		self::form_open( 'landing' );
		echo '<p>';
		submit_button( $land ? 'Check the landing page' : 'Make the landing page (draft)', 'secondary', 'go', false );
		echo ' <span class="description">Address /' . esc_html( $defs[0][0] ) . '/. If a page already has that address, it is used and left unchanged.</span></p></form>';
		$m = self::main_menu();
		echo '<h2 style="margin-top:2em">6. Main menu</h2><p>Adds "' . esc_html( $defs[0][1] ) . '" to ' . ( $m ? 'the menu <strong>' . esc_html( $m->name ) . '</strong>' : 'the main menu' ) . ', with the nine subcategories under it. Readers see it at once. You can move or remove it under Appearance → Menus.</p>';
		if ( self::in_menu() ) echo '<p><span style="color:#008a20">Already in the menu.</span></p>';
		elseif ( $m ) { self::form_open( 'menu' ); submit_button( 'Add to the main menu', 'secondary', 'go', false ); echo '</form>'; }
		else echo '<p class="description">No menu found. Make one under Appearance → Menus first.</p>';
		?>
<script>
jQuery(function($){$('.lmgf-ts-pick').on('click',function(e){e.preventDefault();var td=$(this).closest('td'),f=wp.media({title:'Hero image',multiple:false,library:{type:'image'}});f.on('select',function(){var a=f.state().get('selection').first().toJSON();td.find('input').val(a.id);var s=(a.sizes&&(a.sizes.thumbnail||a.sizes.medium))||a;td.find('.lmgf-ts-prev').html('<img src="'+s.url+'" style="max-width:120px;max-height:80px">');});f.open();});});
</script>
		<?php
	}
}
