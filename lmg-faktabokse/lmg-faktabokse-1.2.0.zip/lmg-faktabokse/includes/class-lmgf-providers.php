<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Providers (agencies, airlines, airports, …) tagged by where they travel to and from.
 *
 * Post meta on a provider post or page:
 *   _lmgf_serves   one row per destination category term id ("Rejser til")
 *   _lmgf_from     departure codes, comma separated ("Rejser fra"); empty = everywhere
 *   _lmgf_tier     0 none | 1 partner | 2 premium partner | 3 exclusive
 *   _lmgf_until    Y-m-d, last day the tier counts; empty = no end
 *   _lmgf_site     provider's own address (shown only while the tier counts)
 *   _lmgf_blurb    one line shown under the name
 * Option lmgf_pv:     box off|pilot|on, pilot, label, home, max
 * Option lmgf_clicks: [Ym][provider id][term id][in|out] => count, last 13 months
 *
 * Ranking: relevance first (exact country before its region/continent), then tier,
 * then a daily rotation. Tier never lifts a less relevant provider above a more relevant one.
 */
class LMGF_Providers {

	const TAB = 'providers';

	public static function boot() {
		add_filter( 'the_content', array( __CLASS__, 'content' ), 23 );
		add_filter( 'get_the_archive_description', array( __CLASS__, 'archive' ), 21 );
		add_action( 'pre_get_posts', array( __CLASS__, 'filter_query' ) );
		add_action( 'template_redirect', array( __CLASS__, 'go' ), 0 );
		add_action( 'wp_ajax_lmgf_click', array( __CLASS__, 'beacon' ) );
		add_action( 'wp_ajax_nopriv_lmgf_click', array( __CLASS__, 'beacon' ) );
		add_action( 'save_post', array( __CLASS__, 'flush' ), 30 );
		add_shortcode( 'lmg_udbydere', array( __CLASS__, 'sc' ) );
		add_action( 'wp_enqueue_scripts', function () {
			if ( is_category() ) wp_enqueue_style( 'lmg-faktabokse', LMGF_URL . 'assets/lmgf.css', array(), LMGF_VERSION );
		} );
		if ( is_admin() ) {
			add_action( 'add_meta_boxes', array( __CLASS__, 'meta_box' ) );
			add_action( 'save_post', array( __CLASS__, 'save' ), 11, 2 );
			add_action( 'admin_init', array( __CLASS__, 'actions' ) );
			add_action( 'admin_post_lmgf_pv_csv', array( __CLASS__, 'csv' ) );
		}
	}

	// ---- Settings and words -----------------------------------------------------

	public static function opt() {
		$travel = LMGF_Services::is_travel();
		return wp_parse_args( (array) get_option( 'lmgf_pv', array() ), array(
			'box'   => 'off',
			'pilot' => '',
			'label' => $travel ? 'Sponsored' : 'Annonce',
			'home'  => $travel ? '' : 'CPH, BLL, AAL',
			'max'   => 4,
		) );
	}

	public static function words( $k ) {
		$w = LMGF_Services::is_travel() ? array(
			'title' => 'Travel to %s with',
			'all'   => 'All travel agencies going to %s',
			'visit' => 'Visit %s',
			'to'    => 'Travels to',
			'any'   => 'All destinations',
			'show'  => 'Show',
		) : array(
			'title' => 'Rejs til %s med',
			'all'   => 'Alle rejsebureauer der rejser til %s',
			'visit' => 'Gå til %s',
			'to'    => 'Rejser til',
			'any'   => 'Alle rejsemål',
			'show'  => 'Vis',
		);
		return $w[ $k ];
	}

	public static function tiers() {
		return array( 0 => 'Not a partner', 1 => 'Partner', 2 => 'Premium partner (box shows at most 3)', 3 => 'Exclusive (shown alone)' );
	}

	// ---- Destinations -------------------------------------------------------------

	/** Destination categories: every category with a country page, plus the regions above them. term id => name. */
	public static function destinations() {
		static $d = null;
		if ( $d !== null ) return $d;
		$ids = array();
		foreach ( array_keys( LMGF_Data::map() ) as $t ) {
			$ids[ (int) $t ] = true;
			foreach ( get_ancestors( (int) $t, 'category', 'taxonomy' ) as $a ) $ids[ (int) $a ] = true;
		}
		$d = array();
		if ( $ids ) foreach ( get_terms( array( 'taxonomy' => 'category', 'include' => array_keys( $ids ), 'hide_empty' => false ) ) as $t ) $d[ (int) $t->term_id ] = $t->name;
		asort( $d );
		return $d;
	}

	/** The country name as readers of this site see it. */
	public static function name( $term_id ) {
		static $c = array();
		$term_id = (int) $term_id;
		if ( isset( $c[ $term_id ] ) ) return $c[ $term_id ];
		$map = LMGF_Data::map();
		if ( isset( $map[ $term_id ] ) ) return $c[ $term_id ] = LMGF_Data::name_in( $map[ $term_id ], LMGF_Data::site_lang() );
		$t = get_term( $term_id, 'category' );
		return $c[ $term_id ] = ( $t && ! is_wp_error( $t ) ? $t->name : '' );
	}

	/** The destination a page is about: a country page's own category, or the country a post belongs to. 0 if none. */
	public static function dest_of( $post_id ) {
		$src = LMGF_Data::source_of( $post_id );
		$d   = LMGF_Data::raw( $src );
		if ( ! empty( $d['term'] ) ) return (int) $d['term'];
		$cp = LMGF_Data::country_page_for( $post_id );
		if ( ! $cp ) return 0;
		$d = LMGF_Data::raw( $cp );
		return empty( $d['term'] ) ? 0 : (int) $d['term'];
	}

	// ---- Ranking ------------------------------------------------------------------

	public static function tier( $pid ) {
		$t = (int) get_post_meta( $pid, '_lmgf_tier', true );
		$u = (string) get_post_meta( $pid, '_lmgf_until', true );
		if ( $t && $u !== '' && $u < wp_date( 'Y-m-d' ) ) return 0;
		return max( 0, min( 3, $t ) );
	}

	/** Departure check: a provider with departure codes must share one with this site's readers. */
	public static function departs_ok( $pid ) {
		$home = self::codes( self::opt()['home'] );
		$from = self::codes( get_post_meta( $pid, '_lmgf_from', true ) );
		return ! $home || ! $from || array_intersect( $home, $from );
	}

	public static function codes( $s ) {
		return array_values( array_filter( array_map( function ( $c ) { return strtoupper( trim( $c ) ); }, preg_split( '/[\s,;]+/', (string) $s ) ) ) );
	}

	/**
	 * Ranked providers for a destination: [ [id, relevance, tier], … ], cut to the number to show.
	 * Relevance 3 = this country, 2 = the region right above it, 1 = further up.
	 */
	public static function ranked( $term_id, $exclude = 0, $cut = true ) {
		$term_id = (int) $term_id;
		$key     = 'lmgf_pv_' . $term_id . '_' . wp_date( 'Ymd' );
		$all     = get_transient( $key );
		if ( ! is_array( $all ) ) {
			$chain = array_merge( array( $term_id ), array_map( 'intval', get_ancestors( $term_id, 'category', 'taxonomy' ) ) );
			$ids   = get_posts( array(
				'post_type'      => array( 'post', 'page' ),
				'post_status'    => 'publish',
				'posts_per_page' => 200,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_query'     => array(
					array( 'key' => '_lmgf_serves', 'value' => $chain, 'compare' => 'IN', 'type' => 'NUMERIC' ),
					array( 'key' => '_lmgt_source', 'compare' => 'NOT EXISTS' ),
				),
			) );
			$all = array();
			foreach ( $ids as $pid ) {
				if ( ! self::departs_ok( $pid ) ) continue;
				$serves = array_map( 'intval', (array) get_post_meta( $pid, '_lmgf_serves' ) );
				$rel    = 0;
				foreach ( $chain as $i => $c ) if ( in_array( $c, $serves, true ) ) { $rel = max( 1, 3 - $i ); break; }
				if ( $rel ) $all[] = array( (int) $pid, $rel, self::tier( $pid ), crc32( $pid . '|' . wp_date( 'Ymd' ) ) );
			}
			usort( $all, function ( $a, $b ) {
				if ( $a[1] !== $b[1] ) return $b[1] - $a[1];
				if ( $a[2] !== $b[2] ) return $b[2] - $a[2];
				return $a[3] < $b[3] ? -1 : 1;
			} );
			set_transient( $key, $all, DAY_IN_SECONDS );
		}
		$all = array_values( array_filter( $all, function ( $r ) use ( $exclude ) { return $r[0] !== (int) $exclude; } ) );
		if ( ! $cut || ! $all ) return $all;
		$max = max( 1, (int) self::opt()['max'] );
		if ( $all[0][2] === 3 ) $max = 1;
		elseif ( $all[0][2] === 2 ) $max = min( 3, $max );
		return array_slice( $all, 0, $max );
	}

	public static function flush() {
		global $wpdb;
		$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_lmgf\\_pv\\_%' OR option_name LIKE '\\_transient\\_timeout\\_lmgf\\_pv\\_%'" );
	}

	// ---- Front ----------------------------------------------------------------------

	public static function shown_on( $post_id ) {
		$o = self::opt();
		if ( $o['box'] === 'off' ) return false;
		if ( $o['box'] === 'pilot' && ! in_array( (int) $post_id, LMGF_Services::ids( $o['pilot'] ), true ) ) return false;
		return true;
	}

	public static function content( $html ) {
		if ( is_admin() || is_feed() || ! is_singular( array( 'post', 'page' ) ) || ! in_the_loop() || ! is_main_query() ) return $html;
		$id = get_the_ID();
		if ( (int) $id !== (int) get_queried_object_id() || has_shortcode( $html, 'lmg_udbydere' ) ) return $html;
		if ( LMGF_Data::lang_of( $id ) !== LMGF_Data::site_lang() || get_post_meta( $id, '_lmgf_serves' ) || ! self::shown_on( $id ) ) return $html;
		$t = self::dest_of( $id );
		return $t ? $html . self::box( $t, $id ) : $html;
	}

	public static function sc() {
		$t = self::dest_of( get_the_ID() );
		return $t ? self::box( $t, get_the_ID() ) : '';
	}

	public static function box( $term_id, $exclude = 0 ) {
		$rows = self::ranked( $term_id, $exclude );
		if ( ! $rows ) return '';
		$o    = self::opt();
		$name = self::name( $term_id );
		$li   = '';
		foreach ( $rows as $r ) {
			list( $pid, , $tier ) = $r;
			$th    = get_the_post_thumbnail( $pid, 'thumbnail', array( 'loading' => 'lazy', 'alt' => '' ) );
			$blurb = (string) get_post_meta( $pid, '_lmgf_blurb', true );
			$site  = (string) get_post_meta( $pid, '_lmgf_site', true );
			$li   .= '<li class="lmgf-pv-item' . ( $tier ? ' is-partner' : '' ) . '">';
			$li   .= '<a class="lmgf-pv-in" data-p="' . (int) $pid . '" href="' . esc_url( get_permalink( $pid ) ) . '">' . ( $th ? '<span class="lmgf-ts-th">' . $th . '</span>' : '' ) . '<span><strong>' . esc_html( get_the_title( $pid ) ) . '</strong>' . ( $blurb !== '' ? '<small>' . esc_html( $blurb ) . '</small>' : '' ) . '</span></a>';
			if ( $tier ) {
				$li .= '<span class="lmgf-pv-label">' . esc_html( $o['label'] ) . '</span>';
				if ( $site !== '' ) $li .= '<a class="lmgf-pv-out" rel="sponsored noopener" target="_blank" href="' . esc_url( add_query_arg( array( 'lmgf_go' => $pid, 't' => (int) $term_id ), home_url( '/' ) ) ) . '">' . esc_html( sprintf( self::words( 'visit' ), wp_parse_url( $site, PHP_URL_HOST ) ? preg_replace( '/^www\./', '', wp_parse_url( $site, PHP_URL_HOST ) ) : $site ) ) . ' ↗</a>';
			}
			$li .= '</li>';
		}
		$h  = '<aside class="lmgf lmgf-box lmgf-pv-box" data-t="' . (int) $term_id . '">';
		$h .= '<p class="lmgf-title">' . esc_html( sprintf( self::words( 'title' ), $name ) ) . '</p><ul class="lmgf-pv-list">' . $li . '</ul>';
		$kids = LMGF_Services::children();
		if ( isset( $kids[8] ) ) {
			$l = get_term_link( (int) $kids[8], 'category' );
			$tt = get_term( (int) $term_id, 'category' );
			if ( ! is_wp_error( $l ) && $tt && ! is_wp_error( $tt ) ) $h .= '<p class="lmgf-ts-all"><a href="' . esc_url( add_query_arg( 'til', $tt->slug, $l ) ) . '">' . esc_html( sprintf( self::words( 'all' ), $name ) ) . ' →</a></p>';
		}
		$h .= '</aside>';
		return $h . self::beacon_js();
	}

	private static function beacon_js() {
		static $done = false;
		if ( $done ) return '';
		$done = true;
		$u = esc_url_raw( admin_url( 'admin-ajax.php' ) );
		return '<script>document.addEventListener("click",function(e){var a=e.target.closest&&e.target.closest(".lmgf-pv-in");if(!a||!navigator.sendBeacon)return;var b=a.closest(".lmgf-pv-box"),f=new FormData();f.append("action","lmgf_click");f.append("p",a.getAttribute("data-p"));f.append("t",b?b.getAttribute("data-t"):0);navigator.sendBeacon(' . wp_json_encode( $u ) . ',f);});</script>';
	}

	// ---- Category pages: box on country archives, filter on service archives --------

	public static function archive( $desc ) {
		if ( ! is_category() || is_paged() ) return $desc;
		$t    = (int) get_queried_object_id();
		$kids = array_values( LMGF_Services::children() );
		if ( in_array( $t, $kids, true ) ) return $desc . self::filter_form( $t );
		$o = self::opt();
		if ( $o['box'] !== 'on' || ! isset( LMGF_Data::map()[ $t ] ) ) return $desc;
		return $desc . self::box( $t );
	}

	/** Destinations that providers in this category travel to, for the drop-down. */
	public static function filter_form( $cat ) {
		global $wpdb;
		$ids = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids', 'cat' => $cat, 'no_found_rows' => true, 'meta_key' => '_lmgf_serves' ) );
		if ( ! $ids ) return '';
		$tids = $wpdb->get_col( "SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_lmgf_serves' AND post_id IN (" . implode( ',', array_map( 'intval', $ids ) ) . ')' );
		$dest = self::destinations();
		$opts = array();
		foreach ( $tids as $tid ) if ( isset( $dest[ (int) $tid ] ) ) { $tt = get_term( (int) $tid, 'category' ); if ( $tt && ! is_wp_error( $tt ) ) $opts[ $tt->slug ] = self::name( (int) $tid ); }
		if ( ! $opts ) return '';
		asort( $opts );
		$cur = isset( $_GET['til'] ) ? sanitize_title( wp_unslash( $_GET['til'] ) ) : '';
		$h   = '<form class="lmgf-pv-filter" method="get" action="' . esc_url( get_term_link( $cat, 'category' ) ) . '"><label>' . esc_html( self::words( 'to' ) ) . ' <select name="til" onchange="this.form.submit()"><option value="">' . esc_html( self::words( 'any' ) ) . '</option>';
		foreach ( $opts as $slug => $n ) $h .= '<option value="' . esc_attr( $slug ) . '"' . selected( $cur, $slug, false ) . '>' . esc_html( $n ) . '</option>';
		return $h . '</select></label> <noscript><button>' . esc_html( self::words( 'show' ) ) . '</button></noscript></form>';
	}

	/** ?til=italien on a service category page: providers that travel to Italy or to the region it lies in. */
	public static function filter_query( $q ) {
		if ( is_admin() || ! $q->is_main_query() || ! $q->is_category() || empty( $_GET['til'] ) ) return;
		$t = get_term_by( 'slug', sanitize_title( wp_unslash( $_GET['til'] ) ), 'category' );
		if ( ! $t ) return;
		$chain = array_merge( array( (int) $t->term_id ), array_map( 'intval', get_ancestors( (int) $t->term_id, 'category', 'taxonomy' ) ) );
		$mq    = (array) $q->get( 'meta_query' );
		$mq[]  = array( 'key' => '_lmgf_serves', 'value' => $chain, 'compare' => 'IN', 'type' => 'NUMERIC' );
		$q->set( 'meta_query', $mq );
		add_filter( 'wp_robots', function ( $r ) { $r['noindex'] = true; $r['follow'] = true; return $r; } );
		add_filter( 'rank_math/frontend/robots', function ( $r ) { $r['index'] = 'noindex'; return $r; } );
	}

	// ---- Clicks -----------------------------------------------------------------------

	private static function is_bot() {
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
		return $ua === '' || preg_match( '/bot|crawl|spider|slurp|preview|facebookexternalhit|headless|curl|wget|python|monitor/i', $ua );
	}

	public static function count( $pid, $tid, $way ) {
		if ( self::is_bot() || current_user_can( 'edit_posts' ) ) return;
		$c = (array) get_option( 'lmgf_clicks', array() );
		$m = wp_date( 'Ym' );
		$c[ $m ][ $pid ][ $tid ][ $way ] = ( isset( $c[ $m ][ $pid ][ $tid ][ $way ] ) ? (int) $c[ $m ][ $pid ][ $tid ][ $way ] : 0 ) + 1;
		krsort( $c );
		update_option( 'lmgf_clicks', array_slice( $c, 0, 13, true ), false );
	}

	public static function beacon() {
		$pid = isset( $_POST['p'] ) ? (int) $_POST['p'] : 0;
		$tid = isset( $_POST['t'] ) ? (int) $_POST['t'] : 0;
		if ( $pid && get_post_meta( $pid, '_lmgf_serves' ) ) self::count( $pid, $tid, 'in' );
		wp_die( '', '', array( 'response' => 204 ) );
	}

	/** /?lmgf_go=ID&t=TERM: counts the click and sends the reader to the partner's own site. */
	public static function go() {
		if ( empty( $_GET['lmgf_go'] ) ) return;
		$pid  = (int) $_GET['lmgf_go'];
		$site = (string) get_post_meta( $pid, '_lmgf_site', true );
		if ( ! $pid || $site === '' || ! self::tier( $pid ) || get_post_status( $pid ) !== 'publish' ) { wp_safe_redirect( home_url( '/' ) ); exit; }
		self::count( $pid, isset( $_GET['t'] ) ? (int) $_GET['t'] : 0, 'out' );
		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow' );
		wp_redirect( esc_url_raw( $site ), 302, 'LMG Faktabokse' );
		exit;
	}

	// ---- Meta box -----------------------------------------------------------------------

	public static function meta_box() {
		foreach ( array( 'post', 'page' ) as $t ) add_meta_box( 'lmgf_pv', LMGF_Services::is_travel() ? 'Travels to / from' : 'Rejser til / fra', array( __CLASS__, 'render' ), $t, 'side', 'default' );
	}

	public static function render( $post ) {
		if ( LMGF_Data::source_of( $post->ID ) !== (int) $post->ID ) { echo '<p class="description">Set on the original.</p>'; return; }
		wp_nonce_field( 'lmgf_pv', 'lmgf_pv_nonce' );
		$dest   = self::destinations();
		$serves = array_map( 'intval', (array) get_post_meta( $post->ID, '_lmgf_serves' ) );
		$sugg   = $serves ? array() : self::suggest( $post->ID );
		echo '<p class="description">For travel agencies, airlines and other providers. They are shown on the country pages and destination posts they travel to.</p>';
		if ( ! $dest ) { echo '<p><em>No country pages yet.</em></p>'; return; }
		echo '<p><strong>' . esc_html( self::words( 'to' ) ) . '</strong>' . ( $sugg ? ' <button type="button" class="button-link" onclick="this.closest(\'.inside\').querySelectorAll(\'.lmgf-sg input\').forEach(function(i){i.checked=true})">Tick the ' . count( $sugg ) . ' found in the text</button>' : '' ) . '</p>';
		echo '<input type="search" placeholder="Find…" style="width:100%" oninput="var v=this.value.toLowerCase();this.nextElementSibling.querySelectorAll(\'label\').forEach(function(l){l.style.display=l.textContent.toLowerCase().indexOf(v)>-1?\'\':\'none\'})">';
		echo '<div style="max-height:220px;overflow:auto;border:1px solid #dcdcde;padding:4px 6px;margin-top:4px">';
		uasort( $dest, function ( $a, $b ) { return strcmp( $a, $b ); } );
		foreach ( $dest as $tid => $n ) {
			$sg = in_array( (int) $tid, $sugg, true );
			echo '<label style="display:block"' . ( $sg ? ' class="lmgf-sg"' : '' ) . '><input type="checkbox" name="lmgf_pv[serves][]" value="' . (int) $tid . '"' . checked( in_array( (int) $tid, $serves, true ), true, false ) . '> ' . ( $sg ? '<strong>' : '' ) . esc_html( $n ) . ( $sg ? '</strong>' : '' ) . ( isset( LMGF_Data::map()[ $tid ] ) ? '' : ' <span class="description">(region)</span>' ) . '</label>';
		}
		echo '</div><p class="description">A region (for example Asia) covers every country in it, ranked below providers that name the country itself.</p>';
		echo '<p><label><strong>Rejser fra / Travels from</strong><br><input type="text" name="lmgf_pv[from]" value="' . esc_attr( get_post_meta( $post->ID, '_lmgf_from', true ) ) . '" style="width:100%" placeholder="CPH, BLL, AAL"></label><span class="description">Airport codes, comma separated. Empty = no limit.</span></p>';
		echo '<p><label><strong>One line under the name</strong><br><input type="text" name="lmgf_pv[blurb]" maxlength="120" value="' . esc_attr( get_post_meta( $post->ID, '_lmgf_blurb', true ) ) . '" style="width:100%"></label></p>';
		$can = current_user_can( 'manage_options' );
		$t   = (int) get_post_meta( $post->ID, '_lmgf_tier', true );
		echo '<p><label><strong>Partner level</strong><br><select name="lmgf_pv[tier]" style="width:100%"' . ( $can ? '' : ' disabled' ) . '>';
		foreach ( self::tiers() as $k => $l ) echo '<option value="' . (int) $k . '"' . selected( $t, $k, false ) . '>' . esc_html( $l ) . '</option>';
		echo '</select></label></p>';
		echo '<p><label>Until (last day)<br><input type="date" name="lmgf_pv[until]" value="' . esc_attr( get_post_meta( $post->ID, '_lmgf_until', true ) ) . '"' . ( $can ? '' : ' disabled' ) . '></label></p>';
		echo '<p><label>Their own website (partners only)<br><input type="url" name="lmgf_pv[site]" value="' . esc_attr( get_post_meta( $post->ID, '_lmgf_site', true ) ) . '" style="width:100%"' . ( $can ? '' : ' disabled' ) . '></label></p>';
		if ( $t && ! self::tier( $post->ID ) ) echo '<p style="color:#b32d2e">The partner period has ended, so this provider is shown as a normal one.</p>';
	}

	public static function save( $post_id, $post ) {
		if ( ! isset( $_POST['lmgf_pv_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['lmgf_pv_nonce'] ) ), 'lmgf_pv' ) ) return;
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) return;
		$in = isset( $_POST['lmgf_pv'] ) ? (array) wp_unslash( $_POST['lmgf_pv'] ) : array();
		self::set_serves( $post_id, isset( $in['serves'] ) ? (array) $in['serves'] : array() );
		update_post_meta( $post_id, '_lmgf_from', implode( ', ', self::codes( sanitize_text_field( isset( $in['from'] ) ? $in['from'] : '' ) ) ) );
		update_post_meta( $post_id, '_lmgf_blurb', sanitize_text_field( isset( $in['blurb'] ) ? $in['blurb'] : '' ) );
		if ( current_user_can( 'manage_options' ) ) {
			update_post_meta( $post_id, '_lmgf_tier', max( 0, min( 3, (int) ( isset( $in['tier'] ) ? $in['tier'] : 0 ) ) ) );
			$u = isset( $in['until'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $in['until'] ) ? $in['until'] : '';
			update_post_meta( $post_id, '_lmgf_until', $u );
			update_post_meta( $post_id, '_lmgf_site', esc_url_raw( isset( $in['site'] ) ? $in['site'] : '' ) );
		}
		self::flush();
	}

	public static function set_serves( $post_id, array $ids ) {
		$dest = self::destinations();
		delete_post_meta( $post_id, '_lmgf_serves' );
		foreach ( array_unique( array_map( 'intval', $ids ) ) as $t ) if ( isset( $dest[ $t ] ) ) add_post_meta( $post_id, '_lmgf_serves', $t );
	}

	/** Destinations named in a provider's text. */
	public static function suggest( $post_id ) {
		$text = ' ' . wp_strip_all_tags( get_the_title( $post_id ) . ' ' . get_post_field( 'post_content', $post_id ) ) . ' ';
		$out  = array();
		foreach ( self::destinations() as $tid => $n ) {
			$names = array_unique( array( $n, self::name( $tid ) ) );
			foreach ( $names as $nm ) {
				if ( mb_strlen( $nm ) < 3 ) continue;
				if ( preg_match( '/(?<!\pL)' . preg_quote( $nm, '/' ) . 's?(?!\pL)/iu', $text ) ) { $out[] = (int) $tid; break; }
			}
		}
		return $out;
	}

	// ---- Admin tab --------------------------------------------------------------------

	/** Candidate providers: posts in the Rejseservice subcategories and pages under its related pages. */
	public static function candidates() {
		$kids = array_values( LMGF_Services::children() );
		$ids  = $kids ? get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 500, 'fields' => 'ids', 'category__in' => $kids, 'no_found_rows' => true, 'meta_query' => array( array( 'key' => '_lmgt_source', 'compare' => 'NOT EXISTS' ) ) ) ) : array();
		$o    = LMGF_Services::opt();
		foreach ( (array) $o['pages'] as $lines ) foreach ( LMGF_Services::ids( $lines ) as $p ) {
			$ids = array_merge( $ids, get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_parent' => $p, 'posts_per_page' => 200, 'fields' => 'ids', 'no_found_rows' => true ) ) );
		}
		$tagged = get_posts( array( 'post_type' => array( 'post', 'page' ), 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids', 'meta_key' => '_lmgf_serves', 'no_found_rows' => true ) );
		return array_values( array_unique( array_map( 'intval', array_merge( $tagged, $ids ) ) ) );
	}

	private static function back( $args ) {
		wp_safe_redirect( add_query_arg( $args, LMGF_Admin::url( self::TAB ) ) );
		exit;
	}

	public static function actions() {
		if ( empty( $_POST['lmgf_pv_do'] ) || ! current_user_can( 'manage_options' ) ) return;
		check_admin_referer( 'lmgf_pv_tab', 'lmgf_pv_tab_nonce' );
		$do = sanitize_key( $_POST['lmgf_pv_do'] );
		if ( $do === 'settings' ) {
			$in = isset( $_POST['pv'] ) ? (array) wp_unslash( $_POST['pv'] ) : array();
			update_option( 'lmgf_pv', array(
				'box'   => in_array( isset( $in['box'] ) ? $in['box'] : '', array( 'off', 'pilot', 'on' ), true ) ? $in['box'] : 'off',
				'pilot' => sanitize_textarea_field( isset( $in['pilot'] ) ? $in['pilot'] : '' ),
				'label' => sanitize_text_field( isset( $in['label'] ) && $in['label'] !== '' ? $in['label'] : self::opt()['label'] ),
				'home'  => implode( ', ', self::codes( sanitize_text_field( isset( $in['home'] ) ? $in['home'] : '' ) ) ),
				'max'   => max( 1, min( 8, (int) ( isset( $in['max'] ) ? $in['max'] : 4 ) ) ),
			), false );
			self::flush();
			self::back( array( 'done' => 'saved' ) );
		}
		if ( $do === 'tag' ) {
			$n = 0;
			foreach ( isset( $_POST['tag'] ) ? (array) wp_unslash( $_POST['tag'] ) : array() as $pid => $tids ) {
				$pid = (int) $pid;
				if ( ! $pid || get_post_meta( $pid, '_lmgf_serves' ) || ! current_user_can( 'edit_post', $pid ) ) continue;
				self::set_serves( $pid, (array) $tids );
				$n++;
			}
			self::flush();
			self::back( array( 'done' => 'tagged-' . $n ) );
		}
	}

	public static function csv() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'No access' );
		check_admin_referer( 'lmgf_pv_csv' );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=provider-clicks-' . wp_date( 'Y-m-d' ) . '.csv' );
		$f = fopen( 'php://output', 'w' );
		fwrite( $f, "\xEF\xBB\xBF" );
		fputcsv( $f, array( 'Month', 'Provider', 'Provider ID', 'Partner level', 'Destination', 'Clicks to profile', 'Clicks to their site' ) );
		$tiers = self::tiers();
		foreach ( (array) get_option( 'lmgf_clicks', array() ) as $m => $ps ) foreach ( $ps as $pid => $ts ) foreach ( $ts as $tid => $c ) {
			fputcsv( $f, array( substr( $m, 0, 4 ) . '-' . substr( $m, 4 ), get_the_title( $pid ), $pid, $tiers[ self::tier( $pid ) ], $tid ? self::name( (int) $tid ) : '', isset( $c['in'] ) ? (int) $c['in'] : 0, isset( $c['out'] ) ? (int) $c['out'] : 0 ) );
		}
		fclose( $f );
		exit;
	}

	private static function form_open( $do ) {
		echo '<form method="post">';
		wp_nonce_field( 'lmgf_pv_tab', 'lmgf_pv_tab_nonce' );
		echo '<input type="hidden" name="lmgf_pv_do" value="' . esc_attr( $do ) . '">';
	}

	public static function tab() {
		$o = self::opt();
		if ( ! empty( $_GET['done'] ) ) {
			$d = sanitize_text_field( wp_unslash( $_GET['done'] ) );
			$p = explode( '-', $d );
			$t = $d === 'saved' ? 'Saved.' : ( $p[0] === 'tagged' ? sprintf( 'Destinations saved on %d providers.', (int) $p[1] ) : '' );
			if ( $t ) echo '<div class="notice notice-success inline"><p>' . esc_html( $t ) . '</p></div>';
		}
		$dest = self::destinations();
		echo '<p style="font-size:14px;max-width:980px">Travel agencies, airlines and other providers are tagged with the destinations they travel to ("Rejser til / fra" panel when you edit them). Country pages and destination posts then show the matching providers. <strong>The most relevant come first</strong>: a provider that names the country itself always ranks above one that only covers the region. Among equally relevant providers, partners come first and carry the label "' . esc_html( $o['label'] ) . '".</p>';
		if ( ! $dest ) { echo '<p><em>No country pages yet, so there is nothing to tag against.</em></p>'; return; }

		// 1. Settings
		echo '<h2>1. Where the box shows</h2>';
		self::form_open( 'settings' );
		echo '<table class="form-table">';
		echo '<tr><th>Provider box</th><td><select name="pv[box]">';
		foreach ( array( 'off' => 'Off', 'pilot' => 'Pilot: only on the posts and pages below', 'on' => 'On: every country page, country category page and destination post' ) as $k => $l ) echo '<option value="' . esc_attr( $k ) . '"' . selected( $o['box'], $k, false ) . '>' . esc_html( $l ) . '</option>';
		echo '</select><p class="description">Title "' . esc_html( sprintf( self::words( 'title' ), '…' ) ) . '", at the end of the text. Put [lmg_udbydere] in a post to place it elsewhere. If no provider travels to that country or its region, nothing is shown.</p>';
		echo '<p><label>Pilot (post and page IDs)<br><textarea name="pv[pilot]" rows="2" class="large-text code">' . esc_textarea( $o['pilot'] ) . '</textarea></label></p></td></tr>';
		echo '<tr><th>How many</th><td><input type="number" min="1" max="8" name="pv[max]" value="' . (int) $o['max'] . '" style="width:70px"> <span class="description">providers per box. A premium partner at the top cuts it to 3, an exclusive partner to 1 (only when they are also the most relevant).</span></td></tr>';
		echo '<tr><th>Label on partners</th><td><input type="text" name="pv[label]" value="' . esc_attr( $o['label'] ) . '"> <span class="description">Paid placements must be marked clearly. Links to a partner\'s own site are marked as sponsored for search engines.</span></td></tr>';
		echo '<tr><th>Readers travel from</th><td><input type="text" name="pv[home]" value="' . esc_attr( $o['home'] ) . '" placeholder="CPH, BLL, AAL"> <span class="description">Airport codes. A provider with "Rejser fra" codes is only shown if one of them is here. Empty = no limit.</span></td></tr>';
		echo '</table>';
		submit_button( 'Save', 'primary', 'go', false );
		echo '</form>';

		// 2. Providers
		$cand = self::candidates();
		$this_m = wp_date( 'Ym' ); $last_m = wp_date( 'Ym', strtotime( 'first day of last month' ) );
		$clicks = (array) get_option( 'lmgf_clicks', array() );
		$sum = function ( $m, $pid ) use ( $clicks ) { $s = array( 0, 0 ); if ( isset( $clicks[ $m ][ $pid ] ) ) foreach ( $clicks[ $m ][ $pid ] as $c ) { $s[0] += isset( $c['in'] ) ? (int) $c['in'] : 0; $s[1] += isset( $c['out'] ) ? (int) $c['out'] : 0; } return $s; };
		$untagged = array();
		echo '<h2 style="margin-top:2em">2. Providers</h2><p>' . count( $cand ) . ' posts and pages in Rejseservice, or already tagged. Clicks: to the profile on this site / to their own site. Editors\' own clicks and search robots are not counted.</p>';
		echo '<table class="widefat striped" style="max-width:1100px"><thead><tr><th>Provider</th><th>Travels to</th><th>From</th><th>Partner level</th><th>Clicks this month</th><th>Last month</th></tr></thead><tbody>';
		foreach ( $cand as $pid ) {
			$s = array_map( 'intval', (array) get_post_meta( $pid, '_lmgf_serves' ) );
			if ( ! $s ) { $untagged[] = $pid; continue; }
			$names = array(); foreach ( $s as $t ) if ( isset( $dest[ $t ] ) ) $names[] = $dest[ $t ];
			$tier = self::tier( $pid ); $u = get_post_meta( $pid, '_lmgf_until', true );
			$a = $sum( $this_m, $pid ); $b = $sum( $last_m, $pid );
			echo '<tr><td><a href="' . esc_url( get_edit_post_link( $pid ) ) . '">' . esc_html( get_the_title( $pid ) ) . '</a></td><td>' . esc_html( implode( ', ', $names ) ) . '</td><td>' . esc_html( get_post_meta( $pid, '_lmgf_from', true ) ) . '</td><td>' . esc_html( self::tiers()[ $tier ] ) . ( $tier && $u ? ' until ' . esc_html( $u ) : '' ) . '</td><td>' . $a[0] . ' / ' . $a[1] . '</td><td>' . $b[0] . ' / ' . $b[1] . '</td></tr>';
		}
		echo '</tbody></table><p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=lmgf_pv_csv' ), 'lmgf_pv_csv' ) ) . '">Download clicks per provider and destination (CSV)</a> <span class="description">Last 13 months. Use it for partner reports.</span></p>';

		// 3. Suggestions
		echo '<h2 style="margin-top:2em">3. Tag the untagged providers in one go</h2>';
		if ( ! $untagged ) { echo '<p>Every provider has destinations.</p>'; return; }
		echo '<p>' . count( $untagged ) . ' providers have no destinations yet. Ticked boxes are countries and regions named in their own text. Untick what is wrong, then save. Providers with nothing ticked are left alone. Nothing readers see changes until the box is switched on above.</p>';
		self::form_open( 'tag' );
		echo '<table class="widefat striped" style="max-width:1100px"><thead><tr><th style="width:28%">Provider</th><th>Destinations found in the text</th></tr></thead><tbody>';
		$shown = 0;
		foreach ( $untagged as $pid ) {
			if ( $shown >= 150 ) break;
			$sg = self::suggest( $pid );
			echo '<tr><td><a href="' . esc_url( get_edit_post_link( $pid ) ) . '">' . esc_html( get_the_title( $pid ) ) . '</a></td><td>';
			if ( ! $sg ) echo '<span class="description">none found; tag it in the post</span>';
			foreach ( $sg as $t ) echo '<label style="display:inline-block;margin-right:12px"><input type="checkbox" name="tag[' . (int) $pid . '][]" value="' . (int) $t . '" checked> ' . esc_html( $dest[ $t ] ) . '</label>';
			echo '</td></tr>';
			$shown++;
		}
		echo '</tbody></table><p>';
		submit_button( 'Save the ticked destinations', 'primary', 'go', false );
		echo ( count( $untagged ) > 150 ? ' <span class="description">Showing the first 150; save, then the next ones appear.</span>' : '' ) . '</p></form>';
	}
}
