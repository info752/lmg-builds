<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LMGF_Admin {

	const SLUG = 'lmg-faktabokse';

	public static function boot() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'boxes' ) );
		add_action( 'save_post', array( __CLASS__, 'save' ), 10, 2 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	public static function url( $tab = 'overview' ) {
		return admin_url( 'options-general.php?page=' . self::SLUG . '&tab=' . $tab );
	}

	public static function assets( $hook ) {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) return;
		wp_enqueue_script( 'lmgf-admin', LMGF_URL . 'assets/lmgf-admin.js', array(), LMGF_VERSION, true );
		wp_add_inline_style( 'common', '.lmgf-mb label{display:block;font-weight:600;margin:.8em 0 .2em}.lmgf-mb input[type=text],.lmgf-mb textarea,.lmgf-mb select{width:100%}.lmgf-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:0 1.2em}.lmgf-routes-edit{width:100%;border-collapse:collapse;margin-top:.4em}.lmgf-routes-edit td,.lmgf-routes-edit th{padding:3px;text-align:left;vertical-align:top}.lmgf-routes-edit input,.lmgf-routes-edit select{width:100%}.lmgf-mb .description{color:#646970;font-style:normal}.lmgf-mb h4{margin:1.6em 0 .2em;padding-top:1em;border-top:1px solid #dcdcde}' );
	}

	// ---- Meta box ----------------------------------------------------------------

	public static function boxes() {
		$types = array( 'page', 'post' );
		if ( post_type_exists( 'lmgt_translation' ) ) $types[] = 'lmgt_translation';
		foreach ( $types as $t ) add_meta_box( 'lmgf', 'Faktabokse', array( __CLASS__, 'render' ), $t, 'normal', 'default' );
	}

	public static function render( $post ) {
		wp_nonce_field( 'lmgf_save', 'lmgf_nonce' );
		$src = LMGF_Data::source_of( $post->ID );
		echo '<div class="lmgf-mb">';
		if ( $src !== (int) $post->ID ) {
			self::render_translation( $post, $src );
		} else {
			self::render_original( $post );
		}
		echo '</div>';
	}

	private static function render_original( $post ) {
		$d      = LMGF_Data::raw( $post->ID );
		$term   = isset( $d['term'] ) ? (int) $d['term'] : 0;
		$facts  = isset( $d['facts'] ) ? (array) $d['facts'] : array();
		$routes = isset( $d['routes'] ) && $d['routes'] ? array_values( (array) $d['routes'] ) : array();
		$lang   = LMGF_Data::site_lang();

		$linked = LMGF_Data::country_page_for( $post->ID );
		if ( ! $term ) {
			echo '<p><label><input type="checkbox" name="lmgf_hide_more" value="1" ' . checked( get_post_meta( $post->ID, '_lmgf_hide_more', true ), '1', false ) . '> Hide the "Vil du vide mere om …?" box on this post</label></p>';
			if ( $post->post_type === 'post' ) echo '<p><label><input type="checkbox" name="lmgf_ts_hide" value="1" ' . checked( get_post_meta( $post->ID, '_lmgf_ts_hide', true ), '1', false ) . '> Hide the "' . esc_html( LMGF_Services::words( 'box_title' ) ) . '" box on this post</label></p>';
			echo '<p class="description">' . ( $linked
				? 'This post links to the country page <a href="' . esc_url( get_edit_post_link( $linked ) ) . '">' . esc_html( get_the_title( $linked ) ) . '</a> through its category.'
				: 'No country page found for this post\'s categories, so no "Vil du vide mere" box is shown.' ) . '</p>';
		}

		echo '<h4 style="border:0;padding:0;margin-top:.6em">Country page</h4>';
		echo '<p class="description">Choose the country\'s category to make this a country page. Its fact boxes then show on this page, and every post in that category (or its sub-categories) gets a box linking here.</p>';
		echo '<label for="lmgf_term">Country category</label>';
		wp_dropdown_categories( array( 'name' => 'lmgf[term]', 'id' => 'lmgf_term', 'selected' => $term, 'hide_empty' => 0, 'hierarchical' => 1, 'show_option_none' => '— not a country page —', 'option_none_value' => 0 ) );

		echo '<div data-lmgf-country' . ( $term ? '' : ' style="display:none"' ) . '>';
		echo '<label>Country name in the boxes</label><input type="text" name="lmgf[name]" value="' . esc_attr( isset( $d['name'] ) ? $d['name'] : '' ) . '" placeholder="Empty: the category name">';

		echo '<h4>' . esc_html( sprintf( LMGF_I18n::t( 'facts_title', $lang ), '…' ) ) . '</h4><p class="description">Empty fields are left out of the box.</p><div class="lmgf-grid">';
		foreach ( LMGF_I18n::fact_keys() as $k ) {
			echo '<div><label>' . esc_html( LMGF_I18n::t( $k, $lang ) ) . '</label><input type="text" name="lmgf[facts][' . esc_attr( $k ) . ']" value="' . esc_attr( isset( $facts[ $k ] ) ? $facts[ $k ] : '' ) . '"></div>';
		}
		echo '</div><label>More facts, one per line: label | text</label><textarea name="lmgf[extra]" rows="3" placeholder="Drikkepenge | 5–10 % på restauranter">' . esc_textarea( isset( $d['extra'] ) ? $d['extra'] : '' ) . '</textarea>';
		echo '<label>Facts last checked</label><input type="date" name="lmgf[facts_checked]" value="' . esc_attr( isset( $d['facts_checked'] ) ? $d['facts_checked'] : '' ) . '">';

		echo '<h4>' . esc_html( sprintf( LMGF_I18n::t( 'there_title', $lang ), '…' ) ) . '</h4>';
		echo '<p class="description">One row per way to get there. Take routes from the carrier\'s own route map or timetable, never from memory or AI. Travel time in hours, for example 11 or 11–13. The departure list is under <a href="' . esc_url( self::url( 'settings' ) ) . '">Settings → LMG Faktabokse</a>.</p>';
		$deps = LMGF_Data::departures();
		echo '<table class="lmgf-routes-edit"><thead><tr><th>From</th><th>Carrier</th><th>How</th><th>Via</th><th>Hours</th><th>Link (optional)</th><th>Note (optional)</th><th></th></tr></thead><tbody data-lmgf-rows>';
		$routes[] = array(); // one empty row to fill in
		foreach ( $routes as $i => $r ) self::route_row( $i, $r, $deps, $lang );
		echo '</tbody></table>';
		echo '<script type="text/template" id="lmgf-row-tpl">';
		self::route_row( '__i__', array(), $deps, $lang );
		echo '</script>';
		echo '<p><button type="button" class="button" data-lmgf-add>Add row</button></p>';
		echo '<label>Routes last checked</label><input type="date" name="lmgf[routes_checked]" value="' . esc_attr( isset( $d['routes_checked'] ) ? $d['routes_checked'] : '' ) . '">';
		echo '<p class="description">The date shows under the box with "always check with the carrier". The box only shows when there is at least one row.</p>';
		echo '</div>';
	}

	private static function route_row( $i, array $r, array $deps, $lang ) {
		$v = function ( $k ) use ( $r ) { return isset( $r[ $k ] ) ? $r[ $k ] : ''; };
		$n = 'lmgf[routes][' . $i . ']';
		echo '<tr><td><select name="' . esc_attr( $n ) . '[from]"><option value="">—</option>';
		$from = $v( 'from' );
		if ( $from !== '' && ! isset( $deps[ $from ] ) ) $deps[ $from ] = $from . ' (not in the list)';
		foreach ( $deps as $code => $name ) echo '<option value="' . esc_attr( $code ) . '"' . selected( $from, $code, false ) . '>' . esc_html( $code . ' – ' . $name ) . '</option>';
		echo '</select></td>';
		echo '<td><input type="text" name="' . esc_attr( $n ) . '[carrier]" value="' . esc_attr( $v( 'carrier' ) ) . '" placeholder="Finnair"></td>';
		echo '<td><select name="' . esc_attr( $n ) . '[mode]">';
		foreach ( LMGF_I18n::modes() as $m ) echo '<option value="' . esc_attr( $m ) . '"' . selected( $v( 'mode' ) ?: 'fly_1', $m, false ) . '>' . esc_html( LMGF_I18n::t( $m, $lang ) ) . '</option>';
		echo '</select></td>';
		echo '<td><input type="text" name="' . esc_attr( $n ) . '[via]" value="' . esc_attr( $v( 'via' ) ) . '" placeholder="Helsinki"></td>';
		echo '<td><input type="text" name="' . esc_attr( $n ) . '[duration]" value="' . esc_attr( $v( 'duration' ) ) . '" placeholder="13" style="width:5em"></td>';
		echo '<td><input type="url" name="' . esc_attr( $n ) . '[link]" value="' . esc_attr( $v( 'link' ) ) . '" placeholder="https://"></td>';
		echo '<td><input type="text" name="' . esc_attr( $n ) . '[note]" value="' . esc_attr( $v( 'note' ) ) . '" placeholder="Kun om vinteren"></td>';
		echo '<td><button type="button" class="button-link" data-lmgf-del aria-label="Remove row">✕</button></td></tr>';
	}

	private static function render_translation( $post, $src ) {
		$d  = LMGF_Data::raw( $src );
		$tr = get_post_meta( $post->ID, '_lmgf_tr', true );
		if ( ! is_array( $tr ) ) $tr = array();
		$lang = LMGF_Data::lang_of( $post->ID );

		if ( empty( $d['term'] ) ) {
			echo '<p><label><input type="checkbox" name="lmgf_hide_more" value="1" ' . checked( get_post_meta( $post->ID, '_lmgf_hide_more', true ), '1', false ) . '> Hide the "Vil du vide mere" box on this translation</label></p>';
			echo '<p class="description">The country is taken from the original\'s categories. The box shows only when the country page has a published translation in this language.</p>';
			return;
		}
		echo '<p class="description">This translates a country page. Routes, dates and the country category come from <a href="' . esc_url( get_edit_post_link( $src ) ) . '">the original</a>. Labels are translated automatically. Fill in the wording below in this language; an empty field shows the original\'s text.</p>';
		echo '<input type="hidden" name="lmgf_tr_on" value="1">';
		echo '<label>Country name</label><input type="text" name="lmgf_tr[name]" value="' . esc_attr( isset( $tr['name'] ) ? $tr['name'] : '' ) . '" placeholder="' . esc_attr( isset( $d['name'] ) ? $d['name'] : '' ) . '">';
		echo '<div class="lmgf-grid">';
		foreach ( LMGF_I18n::fact_keys() as $k ) {
			$orig = isset( $d['facts'][ $k ] ) ? $d['facts'][ $k ] : '';
			if ( $orig === '' ) continue;
			echo '<div><label>' . esc_html( LMGF_I18n::t( $k, $lang ) ) . '</label><input type="text" name="lmgf_tr[facts][' . esc_attr( $k ) . ']" value="' . esc_attr( isset( $tr['facts'][ $k ] ) ? $tr['facts'][ $k ] : '' ) . '" placeholder="' . esc_attr( $orig ) . '"></div>';
		}
		echo '</div>';
		if ( ! empty( $d['extra'] ) ) {
			echo '<label>More facts, one per line: label | text</label><textarea name="lmgf_tr[extra]" rows="3" placeholder="' . esc_attr( $d['extra'] ) . '">' . esc_textarea( isset( $tr['extra'] ) ? $tr['extra'] : '' ) . '</textarea>';
		}
		foreach ( isset( $d['routes'] ) ? (array) $d['routes'] : array() as $i => $r ) {
			if ( empty( $r['note'] ) ) continue;
			echo '<label>Note, ' . esc_html( trim( ( isset( $r['from'] ) ? $r['from'] : '' ) . ' ' . ( isset( $r['carrier'] ) ? $r['carrier'] : '' ) ) ) . '</label><input type="text" name="lmgf_tr[notes][' . (int) $i . ']" value="' . esc_attr( isset( $tr['notes'][ $i ] ) ? $tr['notes'][ $i ] : '' ) . '" placeholder="' . esc_attr( $r['note'] ) . '">';
		}
	}

	public static function save( $post_id, $post ) {
		if ( ! isset( $_POST['lmgf_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['lmgf_nonce'] ) ), 'lmgf_save' ) ) return;
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) ) return;
		if ( ! current_user_can( 'edit_post', $post_id ) ) return;

		if ( ! empty( $_POST['lmgf_hide_more'] ) ) update_post_meta( $post_id, '_lmgf_hide_more', '1' );
		else delete_post_meta( $post_id, '_lmgf_hide_more' );
		if ( get_post_type( $post_id ) === 'post' && LMGF_Data::source_of( $post_id ) === (int) $post_id ) {
			if ( ! empty( $_POST['lmgf_ts_hide'] ) ) update_post_meta( $post_id, '_lmgf_ts_hide', '1' );
			else delete_post_meta( $post_id, '_lmgf_ts_hide' );
			delete_transient( 'lmgf_ts_' . $post_id );
		}

		if ( ! empty( $_POST['lmgf_tr_on'] ) ) {
			$in  = isset( $_POST['lmgf_tr'] ) ? (array) wp_unslash( $_POST['lmgf_tr'] ) : array();
			$out = array(
				'name'  => sanitize_text_field( isset( $in['name'] ) ? $in['name'] : '' ),
				'facts' => array(),
				'extra' => sanitize_textarea_field( isset( $in['extra'] ) ? $in['extra'] : '' ),
				'notes' => array(),
			);
			foreach ( LMGF_I18n::fact_keys() as $k ) if ( ! empty( $in['facts'][ $k ] ) ) $out['facts'][ $k ] = sanitize_text_field( $in['facts'][ $k ] );
			foreach ( isset( $in['notes'] ) ? (array) $in['notes'] : array() as $i => $n ) if ( trim( $n ) !== '' ) $out['notes'][ (int) $i ] = sanitize_text_field( $n );
			if ( $out['name'] === '' && ! $out['facts'] && $out['extra'] === '' && ! $out['notes'] ) delete_post_meta( $post_id, '_lmgf_tr' );
			else update_post_meta( $post_id, '_lmgf_tr', wp_slash( $out ) );
			return;
		}

		if ( ! isset( $_POST['lmgf'] ) ) return;
		$in   = (array) wp_unslash( $_POST['lmgf'] );
		$term = isset( $in['term'] ) ? absint( $in['term'] ) : 0;
		$old  = LMGF_Data::raw( $post_id );
		if ( ! $term ) {
			if ( $old ) {
				delete_post_meta( $post_id, '_lmgf' );
				LMGF_Data::rebuild_map();
			}
			return;
		}
		$date = function ( $v ) { $v = sanitize_text_field( (string) $v ); return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : ''; };
		$out  = array(
			'term'           => $term,
			'name'           => sanitize_text_field( isset( $in['name'] ) ? $in['name'] : '' ),
			'facts'          => array(),
			'extra'          => sanitize_textarea_field( isset( $in['extra'] ) ? $in['extra'] : '' ),
			'facts_checked'  => $date( isset( $in['facts_checked'] ) ? $in['facts_checked'] : '' ),
			'routes'         => array(),
			'routes_checked' => $date( isset( $in['routes_checked'] ) ? $in['routes_checked'] : '' ),
		);
		foreach ( LMGF_I18n::fact_keys() as $k ) if ( isset( $in['facts'][ $k ] ) && trim( $in['facts'][ $k ] ) !== '' ) $out['facts'][ $k ] = sanitize_text_field( $in['facts'][ $k ] );
		foreach ( isset( $in['routes'] ) ? (array) $in['routes'] : array() as $r ) {
			if ( ! is_array( $r ) ) continue;
			$row = array(
				'from'     => strtoupper( sanitize_text_field( isset( $r['from'] ) ? $r['from'] : '' ) ),
				'carrier'  => sanitize_text_field( isset( $r['carrier'] ) ? $r['carrier'] : '' ),
				'mode'     => in_array( isset( $r['mode'] ) ? $r['mode'] : '', LMGF_I18n::modes(), true ) ? $r['mode'] : 'fly_1',
				'via'      => sanitize_text_field( isset( $r['via'] ) ? $r['via'] : '' ),
				'duration' => sanitize_text_field( isset( $r['duration'] ) ? $r['duration'] : '' ),
				'link'     => esc_url_raw( isset( $r['link'] ) ? $r['link'] : '' ),
				'note'     => sanitize_text_field( isset( $r['note'] ) ? $r['note'] : '' ),
			);
			if ( $row['from'] === '' && $row['carrier'] === '' ) continue;
			$out['routes'][] = $row;
		}
		update_post_meta( $post_id, '_lmgf', wp_slash( $out ) );
		LMGF_Data::rebuild_map();
	}

	// ---- Settings page -------------------------------------------------------------

	public static function menu() {
		add_options_page( 'LMG Faktabokse', 'LMG Faktabokse', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	public static function save_settings() {
		if ( empty( $_POST['lmgf_settings_nonce'] ) || ! current_user_can( 'manage_options' ) ) return;
		check_admin_referer( 'lmgf_settings', 'lmgf_settings_nonce' );
		$in = isset( $_POST['lmgf_settings'] ) ? (array) wp_unslash( $_POST['lmgf_settings'] ) : array();
		update_option( 'lmgf_settings', array(
			'departures' => sanitize_textarea_field( isset( $in['departures'] ) ? $in['departures'] : '' ),
			'place'      => in_array( isset( $in['place'] ) ? $in['place'] : '', array( 'after', 'before', 'manual' ), true ) ? $in['place'] : 'after',
			'more_on'    => empty( $in['more_on'] ) ? 0 : 1,
		) );
		wp_safe_redirect( add_query_arg( 'saved', '1', self::url( 'settings' ) ) );
		exit;
	}

	public static function page() {
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'overview';
		$tabs = array( 'overview' => 'Country pages', 'settings' => 'Settings', 'services' => 'Travel Services categories', 'providers' => 'Providers by destination', 'notes' => 'Release notes' );
		echo '<div class="wrap"><h1>LMG Faktabokse <span style="font-size:13px;color:#646970">' . esc_html( LMGF_VERSION ) . '</span></h1><nav class="nav-tab-wrapper">';
		foreach ( $tabs as $k => $label ) echo '<a class="nav-tab' . ( $tab === $k ? ' nav-tab-active' : '' ) . '" href="' . esc_url( self::url( $k ) ) . '">' . esc_html( $label ) . '</a>';
		echo '</nav>';
		if ( $tab === 'settings' ) self::tab_settings();
		elseif ( $tab === 'services' ) LMGF_Services::tab();
		elseif ( $tab === 'providers' ) LMGF_Providers::tab();
		elseif ( $tab === 'notes' ) LMGF_Notes::render();
		else self::tab_overview();
		echo '</div>';
	}

	private static function tab_overview() {
		$map = LMGF_Data::rebuild_map();
		echo '<p>Every page or post with a country category chosen in its Faktabokse panel. Posts in that category get the "Vil du vide mere om …?" box.</p>';
		foreach ( LMGF_Data::clashes() as $t => $ids ) {
			$term = get_term( $t, 'category' );
			echo '<div class="notice notice-warning inline"><p>The category <strong>' . esc_html( $term && ! is_wp_error( $term ) ? $term->name : $t ) . '</strong> is chosen on ' . count( $ids ) . ' pages. Posts link to <a href="' . esc_url( get_edit_post_link( $map[ $t ] ) ) . '">' . esc_html( get_the_title( $map[ $t ] ) ) . '</a>. Clear it on the others.</p></div>';
		}
		if ( ! $map ) {
			echo '<p><em>No country pages yet. Open a country page, go to the Faktabokse panel below the editor, and choose its country category.</em></p>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr><th>Country page</th><th>Category</th><th>Posts</th><th>Facts</th><th>Routes</th><th>Routes checked</th></tr></thead><tbody>';
		foreach ( $map as $t => $id ) {
			$d    = LMGF_Data::raw( $id );
			$term = get_term( $t, 'category' );
			$chk  = isset( $d['routes_checked'] ) ? $d['routes_checked'] : '';
			$old  = $chk && strtotime( $chk ) < strtotime( '-180 days' );
			$st   = get_post_status( $id );
			echo '<tr><td><a href="' . esc_url( get_edit_post_link( $id ) ) . '">' . esc_html( get_the_title( $id ) ) . '</a>' . ( $st !== 'publish' ? ' <em>(' . esc_html( $st ) . ')</em>' : '' ) . '</td>';
			echo '<td>' . esc_html( $term && ! is_wp_error( $term ) ? $term->name : '?' ) . '</td>';
			echo '<td>' . (int) ( $term && ! is_wp_error( $term ) ? $term->count : 0 ) . '</td>';
			echo '<td>' . count( isset( $d['facts'] ) ? (array) $d['facts'] : array() ) . '</td>';
			echo '<td>' . count( isset( $d['routes'] ) ? (array) $d['routes'] : array() ) . '</td>';
			echo '<td>' . ( $chk ? esc_html( $chk ) . ( $old ? ' <span style="color:#b32d2e">– over 6 months old</span>' : '' ) : '<span style="color:#b32d2e">not set</span>' ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	private static function tab_settings() {
		$s = LMGF_Data::settings();
		if ( ! empty( $_GET['saved'] ) ) echo '<div class="notice notice-success inline"><p>Saved.</p></div>';
		echo '<form method="post">';
		wp_nonce_field( 'lmgf_settings', 'lmgf_settings_nonce' );
		echo '<table class="form-table"><tr><th>Departure points</th><td><textarea name="lmgf_settings[departures]" rows="10" cols="50" class="large-text code">' . esc_textarea( $s['departures'] ) . '</textarea><p class="description">One per line: code | name as readers see it. Keep it to the 5–10 that matter for this site. Removing a code here keeps rows that use it; they show the bare code.</p></td></tr>';
		echo '<tr><th>Country pages</th><td><select name="lmgf_settings[place]">';
		foreach ( array( 'after' => 'Boxes after the text', 'before' => 'Boxes before the text', 'manual' => 'Only where I put [lmg_faktabokse]' ) as $k => $l ) echo '<option value="' . esc_attr( $k ) . '"' . selected( $s['place'], $k, false ) . '>' . esc_html( $l ) . '</option>';
		echo '</select><p class="description">A page with [lmg_faktabokse] in its text always shows the boxes there instead. [lmg_faktabokse part="facts"] or part="there" shows one box.</p></td></tr>';
		echo '<tr><th>Posts</th><td><label><input type="checkbox" name="lmgf_settings[more_on]" value="1" ' . checked( $s['more_on'], 1, false ) . '> Show "Vil du vide mere om …?" at the end of posts</label><p class="description">Put [lmg_vil_du_vide_mere] in a post to place it elsewhere in that post.</p></td></tr></table>';
		submit_button();
		echo '</form>';
	}
}
