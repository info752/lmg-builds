<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Stored data:
 *   _lmgf            on a country page: term, name, facts, extra, facts_checked, routes, routes_checked
 *   _lmgf_tr         on a translation of a country page: name, facts, extra, notes (per route row)
 *   _lmgf_hide_more  on a post: "1" hides the "Vil du vide mere" box
 *   lmgf_map         option: category term id => country page id
 *   lmgf_settings    option: departures, place, more_on
 */
class LMGF_Data {

	public static function boot() {
		add_action( 'save_post', array( __CLASS__, 'maybe_rebuild' ), 20, 2 );
		add_action( 'deleted_post', array( __CLASS__, 'rebuild_map' ) );
		add_action( 'trashed_post', array( __CLASS__, 'rebuild_map' ) );
		add_action( 'untrashed_post', array( __CLASS__, 'rebuild_map' ) );
	}

	// ---- Settings ------------------------------------------------------------

	public static function defaults() {
		$travel = strpos( (string) wp_parse_url( home_url(), PHP_URL_HOST ), 'traveltalk.travel' ) !== false;
		return array(
			'departures' => $travel
				? "LHR | London Heathrow\nCDG | Paris Charles de Gaulle\nFRA | Frankfurt\nAMS | Amsterdam Schiphol\nMAD | Madrid\nFCO | Rome Fiumicino\nMUC | Munich\nZRH | Zurich\nCPH | Copenhagen"
				: "CPH | København\nBLL | Billund\nAAL | Aalborg\nOSL | Oslo\nARN | Stockholm Arlanda\nHEL | Helsinki",
			'place'      => 'after',
			'more_on'    => 1,
		);
	}

	public static function settings() {
		return wp_parse_args( (array) get_option( 'lmgf_settings', array() ), self::defaults() );
	}

	/** Departure points, code => name, in the order the editor listed them. */
	public static function departures() {
		$out = array();
		foreach ( preg_split( '/\R/', (string) self::settings()['departures'] ) as $line ) {
			$p = array_map( 'trim', explode( '|', $line, 2 ) );
			if ( $p[0] === '' ) continue;
			$code = strtoupper( sanitize_text_field( $p[0] ) );
			$out[ $code ] = isset( $p[1] ) && $p[1] !== '' ? sanitize_text_field( $p[1] ) : $code;
		}
		return apply_filters( 'lmg_faktabokse_departures', $out );
	}

	// ---- Language ------------------------------------------------------------

	public static function site_lang() {
		if ( class_exists( 'LMGT_Langs' ) && method_exists( 'LMGT_Langs', 'source' ) ) return LMGT_Langs::source();
		$c = strtolower( substr( get_locale(), 0, 2 ) );
		if ( $c === 'no' || $c === 'nn' ) $c = 'nb';
		return in_array( $c, LMGF_I18n::LANGS, true ) ? $c : 'en';
	}

	public static function lang_of( $post_id ) {
		$l = (string) get_post_meta( (int) $post_id, '_lmgt_lang', true );
		return $l !== '' ? $l : self::site_lang();
	}

	/** The original a translation was made from, or the post itself. */
	public static function source_of( $post_id ) {
		$s = (int) get_post_meta( (int) $post_id, '_lmgt_source', true );
		return ( $s && get_post( $s ) ) ? $s : (int) $post_id;
	}

	/** Every type a country page or its translation can be. 'any' would skip the Translator's own type. */
	public static function types() {
		$t = array_values( get_post_types( array( 'public' => true ) ) );
		if ( post_type_exists( 'lmgt_translation' ) && ! in_array( 'lmgt_translation', $t, true ) ) $t[] = 'lmgt_translation';
		return array_values( array_diff( $t, array( 'attachment' ) ) );
	}

	// ---- Country pages -------------------------------------------------------

	public static function raw( $post_id ) {
		$d = get_post_meta( (int) $post_id, '_lmgf', true );
		return is_array( $d ) ? $d : array();
	}

	public static function is_country_page( $post_id ) {
		$d = self::raw( $post_id );
		return ! empty( $d['term'] );
	}

	public static function map() {
		$m = get_option( 'lmgf_map', null );
		if ( ! is_array( $m ) ) $m = self::rebuild_map();
		return $m;
	}

	public static function maybe_rebuild( $post_id, $post ) {
		if ( wp_is_post_revision( $post_id ) ) return;
		if ( metadata_exists( 'post', $post_id, '_lmgf' ) || in_array( (int) $post_id, array_map( 'intval', (array) get_option( 'lmgf_map', array() ) ), true ) ) {
			self::rebuild_map();
		}
	}

	public static function rebuild_map() {
		$ids = get_posts( array(
			'post_type'      => self::types(),
			'post_status'    => array( 'publish', 'future', 'draft', 'pending', 'private' ),
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_key'       => '_lmgf',
			'orderby'        => 'ID',
			'order'          => 'ASC',
			'no_found_rows'  => true,
		) );
		$map = array();
		foreach ( $ids as $id ) {
			$d = self::raw( $id );
			if ( empty( $d['term'] ) || get_post_meta( $id, '_lmgt_source', true ) ) continue;
			// A published page wins over a draft for the same category.
			$t = (int) $d['term'];
			if ( isset( $map[ $t ] ) && get_post_status( $map[ $t ] ) === 'publish' && get_post_status( $id ) !== 'publish' ) continue;
			$map[ $t ] = (int) $id;
		}
		update_option( 'lmgf_map', $map, false );
		return $map;
	}

	/** Pages sharing one category: term id => [page ids]. Shown as a warning in the overview. */
	public static function clashes() {
		$by = array();
		foreach ( get_posts( array( 'post_type' => self::types(), 'post_status' => array( 'publish', 'draft', 'pending', 'private', 'future' ), 'posts_per_page' => -1, 'fields' => 'ids', 'meta_key' => '_lmgf', 'no_found_rows' => true ) ) as $id ) {
			$d = self::raw( $id );
			if ( ! empty( $d['term'] ) && ! get_post_meta( $id, '_lmgt_source', true ) ) $by[ (int) $d['term'] ][] = (int) $id;
		}
		return array_filter( $by, function ( $ids ) { return count( $ids ) > 1; } );
	}

	/** The country page a post belongs to, through its categories (closest first), or 0. */
	public static function country_page_for( $post_id ) {
		$src = self::source_of( $post_id );
		if ( self::is_country_page( $src ) ) return 0;
		$map = self::map();
		if ( ! $map ) return 0;
		$terms = wp_get_post_terms( $src, 'category', array( 'fields' => 'ids' ) );
		if ( is_wp_error( $terms ) || ! $terms ) return 0;
		$primary = (int) get_post_meta( $src, 'rank_math_primary_category', true );
		if ( $primary && in_array( $primary, $terms, true ) ) array_unshift( $terms, $primary );
		foreach ( array_unique( $terms ) as $t ) {
			$chain = array_merge( array( (int) $t ), array_map( 'intval', get_ancestors( (int) $t, 'category', 'taxonomy' ) ) );
			foreach ( $chain as $c ) {
				if ( isset( $map[ $c ] ) && (int) $map[ $c ] !== (int) $src && get_post_status( $map[ $c ] ) === 'publish' ) return (int) $map[ $c ];
			}
		}
		return 0;
	}

	/** The country page, or its published translation, in a language; 0 if none. */
	public static function page_in_lang( $page_id, $lang ) {
		if ( self::lang_of( $page_id ) === $lang ) return (int) $page_id;
		$ids = get_posts( array(
			'post_type'      => self::types(),
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
			'meta_query'     => array(
				array( 'key' => '_lmgt_source', 'value' => (int) $page_id ),
				array( 'key' => '_lmgt_lang', 'value' => $lang ),
			),
		) );
		return $ids ? (int) $ids[0] : 0;
	}

	/**
	 * Everything a box needs for one post: the country page's data with the
	 * translation's own wording laid over it. Null if the post is no country page.
	 */
	public static function view( $post_id ) {
		$src = self::source_of( $post_id );
		$d   = self::raw( $src );
		if ( empty( $d['term'] ) ) return null;
		$term = get_term( (int) $d['term'], 'category' );
		$tr   = ( $src !== (int) $post_id ) ? get_post_meta( (int) $post_id, '_lmgf_tr', true ) : array();
		if ( ! is_array( $tr ) ) $tr = array();

		$name = ! empty( $tr['name'] ) ? $tr['name'] : ( ! empty( $d['name'] ) ? $d['name'] : ( $term && ! is_wp_error( $term ) ? $term->name : get_the_title( $src ) ) );

		$facts = array();
		foreach ( LMGF_I18n::fact_keys() as $k ) {
			$v = ! empty( $tr['facts'][ $k ] ) ? $tr['facts'][ $k ] : ( isset( $d['facts'][ $k ] ) ? $d['facts'][ $k ] : '' );
			if ( $v !== '' ) $facts[ $k ] = $v;
		}
		$extra = array();
		$ex    = ! empty( $tr['extra'] ) ? $tr['extra'] : ( isset( $d['extra'] ) ? $d['extra'] : '' );
		foreach ( preg_split( '/\R/', (string) $ex ) as $line ) {
			$p = array_map( 'trim', explode( '|', $line, 2 ) );
			if ( count( $p ) === 2 && $p[0] !== '' && $p[1] !== '' ) $extra[] = $p;
		}
		$routes = array();
		foreach ( isset( $d['routes'] ) ? (array) $d['routes'] : array() as $i => $r ) {
			if ( empty( $r['from'] ) && empty( $r['carrier'] ) ) continue;
			if ( ! empty( $tr['notes'][ $i ] ) ) $r['note'] = $tr['notes'][ $i ];
			$routes[] = $r;
		}

		return array(
			'page'           => $src,
			'post'           => (int) $post_id,
			'lang'           => self::lang_of( $post_id ),
			'slug'           => ( $term && ! is_wp_error( $term ) ) ? $term->slug : '',
			'name'           => $name,
			'facts'          => $facts,
			'extra'          => $extra,
			'facts_checked'  => isset( $d['facts_checked'] ) ? $d['facts_checked'] : '',
			'routes'         => $routes,
			'routes_checked' => isset( $d['routes_checked'] ) ? $d['routes_checked'] : '',
		);
	}

	/** Country name as shown in a language: the translation's own, else the original's. */
	public static function name_in( $page_id, $lang ) {
		$t = self::page_in_lang( $page_id, $lang );
		if ( $t ) {
			$v = self::view( $t );
			if ( $v ) return $v['name'];
		}
		$v = self::view( $page_id );
		return $v ? $v['name'] : get_the_title( $page_id );
	}
}
