(function () {
	var box = document.querySelector('.lmgf-mb');
	if (!box) return;
	var term = box.querySelector('#lmgf_term');
	var country = box.querySelector('[data-lmgf-country]');
	if (term && country) {
		term.addEventListener('change', function () {
			country.style.display = term.value && term.value !== '0' ? '' : 'none';
		});
	}
	var rows = box.querySelector('[data-lmgf-rows]');
	var tpl = document.getElementById('lmgf-row-tpl');
	var add = box.querySelector('[data-lmgf-add]');
	if (rows && tpl && add) {
		var n = rows.children.length + 1000;
		add.addEventListener('click', function () {
			var t = document.createElement('tbody');
			t.innerHTML = tpl.innerHTML.replace(/__i__/g, String(n++));
			rows.appendChild(t.firstElementChild);
		});
		rows.addEventListener('click', function (e) {
			if (e.target.closest('[data-lmgf-del]')) e.target.closest('tr').remove();
		});
	}
})();
