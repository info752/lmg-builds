# LMG Faktabokse

Fact boxes on country pages ("Fakta om [land]", "Sådan kommer du til [land]") and a "Vil du vide mere om [land]?" box on every post in the country's category. Ten languages; reads LMG Translator's `_lmgt_source` / `_lmgt_lang` to serve translations.

- Data: `_lmgf` (country page), `_lmgf_tr` (translation wording), `_lmgf_hide_more` (post opt-out), options `lmgf_map` (category → country page) and `lmgf_settings`.
- Shortcodes: `[lmg_faktabokse part="all|facts|there"]`, `[lmg_vil_du_vide_mere]`.
- Hooks for LMG Fly There: action `lmg_faktabokse_after_getting_there( $country_slug, $post_id )` right after the "Sådan kommer du til" box; filter `lmg_faktabokse_departures` (code => name); filter `lmg_faktabokse_text( $string, $key, $lang )`.
- Settings → LMG Faktabokse: country pages overview, settings, release notes.

Release notes for editors: `RELEASE-NOTES.md`.
