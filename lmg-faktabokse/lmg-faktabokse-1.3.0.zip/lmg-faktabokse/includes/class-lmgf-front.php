<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LMGF_Front {

	public static function boot() {
		add_filter( 'the_content', array( __CLASS__, 'content' ), 20 );
		add_shortcode( 'lmg_faktabokse', array( __CLASS__, 'sc_boxes' ) );
		add_shortcode( 'lmg_vil_du_vide_mere', array( __CLASS__, 'sc_more' ) );
		add_action( 'wp_enqueue_scripts', function () {
			if ( is_singular() ) wp_enqueue_style( 'lmg-faktabokse', LMGF_URL . 'assets/lmgf.css', array(), LMGF_VERSION );
		} );
	}

	public static function content( $html ) {
		if ( is_admin() || is_feed() || ! is_singular() || ! in_the_loop() || ! is_main_query() ) return $html;
		$id = get_the_ID();
		if ( (int) $id !== (int) get_queried_object_id() ) return $html;
		$set = LMGF_Data::settings();

		$view = LMGF_Data::view( $id );
		if ( $view ) {
			if ( $set['place'] === 'manual' || has_shortcode( $html, 'lmg_faktabokse' ) ) return $html;
			$box = self::boxes( $view );
			return $set['place'] === 'before' ? $box . $html : $html . $box;
		}

		if ( empty( $set['more_on'] ) || get_post_meta( LMGF_Data::source_of( $id ), '_lmgf_hide_more', true ) || get_post_meta( $id, '_lmgf_hide_more', true ) ) return $html;
		if ( has_shortcode( $html, 'lmg_vil_du_vide_mere' ) ) return $html;
		return $html . self::more( $id );
	}

	public static function sc_boxes( $atts ) {
		$atts = shortcode_atts( array( 'part' => 'all' ), $atts, 'lmg_faktabokse' );
		$view = LMGF_Data::view( get_the_ID() );
		return $view ? self::boxes( $view, $atts['part'] ) : '';
	}

	public static function sc_more() {
		return self::more( get_the_ID() );
	}

	// ---- Boxes -----------------------------------------------------------------

	public static function boxes( array $v, $part = 'all' ) {
		$out = '';
		if ( $part === 'all' || $part === 'facts' ) $out .= self::facts( $v );
		if ( $part === 'all' || $part === 'there' ) {
			$out .= self::there( $v );
			ob_start();
			do_action( 'lmg_faktabokse_after_getting_there', $v['slug'], $v['post'] );
			$out .= ob_get_clean();
		}
		return $out === '' ? '' : '<div class="lmgf" lang="' . esc_attr( self::html_lang( $v['lang'] ) ) . '">' . $out . '</div>';
	}

	public static function facts( array $v ) {
		if ( ! $v['facts'] && ! $v['extra'] ) return '';
		$l    = $v['lang'];
		$rows = '';
		foreach ( $v['facts'] as $k => $val ) {
			$rows .= '<div class="lmgf-row"><dt>' . esc_html( LMGF_I18n::t( $k, $l ) ) . '</dt><dd>' . esc_html( $val ) . '</dd></div>';
		}
		foreach ( $v['extra'] as $p ) {
			$rows .= '<div class="lmgf-row"><dt>' . esc_html( $p[0] ) . '</dt><dd>' . esc_html( $p[1] ) . '</dd></div>';
		}
		$h  = '<section class="lmgf-box lmgf-facts">';
		$h .= '<h2 class="lmgf-title">' . esc_html( sprintf( LMGF_I18n::t( LMGF_I18n::k( 'facts_title' ), $l ), $v['name'] ) ) . '</h2>';
		$h .= '<dl class="lmgf-list">' . $rows . '</dl>';
		if ( $v['facts_checked'] ) $h .= '<p class="lmgf-checked">' . esc_html( sprintf( LMGF_I18n::t( 'checked', $l ), self::date( $v['facts_checked'], $l ) ) ) . '</p>';
		return $h . '</section>';
	}

	public static function there( array $v ) {
		if ( ! $v['routes'] || ! LMGF_Data::is_travel() ) return '';
		$l    = $v['lang'];
		$deps = LMGF_Data::departures();
		$rows = '';
		foreach ( $v['routes'] as $r ) {
			$code = isset( $r['from'] ) ? $r['from'] : '';
			$from = $code === '' ? '' : ( isset( $deps[ $code ] ) ? $deps[ $code ] . ' (' . $code . ')' : $code );
			$mode = in_array( isset( $r['mode'] ) ? $r['mode'] : '', LMGF_I18n::modes(), true ) ? LMGF_I18n::t( $r['mode'], $l ) : '';
			if ( ! empty( $r['via'] ) ) $mode .= ( $mode ? ', ' : '' ) . sprintf( LMGF_I18n::t( 'via', $l ), $r['via'] );
			$with = esc_html( isset( $r['carrier'] ) ? $r['carrier'] : '' );
			if ( ! empty( $r['link'] ) && $with !== '' ) $with = '<a href="' . esc_url( $r['link'] ) . '" rel="nofollow noopener" target="_blank">' . $with . '</a>';
			$time = ! empty( $r['duration'] ) ? sprintf( LMGF_I18n::t( 'duration', $l ), $r['duration'] ) : '';
			$rows .= '<tr>'
				. '<td data-label="' . esc_attr( LMGF_I18n::t( 'col_from', $l ) ) . '">' . esc_html( $from ) . '</td>'
				. '<td data-label="' . esc_attr( LMGF_I18n::t( 'col_with', $l ) ) . '">' . $with . '</td>'
				. '<td data-label="' . esc_attr( LMGF_I18n::t( 'col_how', $l ) ) . '">' . esc_html( $mode ) . '</td>'
				. '<td data-label="' . esc_attr( LMGF_I18n::t( 'col_time', $l ) ) . '">' . esc_html( $time ) . '</td>'
				. '</tr>';
			if ( ! empty( $r['note'] ) ) $rows .= '<tr class="lmgf-note"><td colspan="4">' . esc_html( $r['note'] ) . '</td></tr>';
		}
		$h  = '<section class="lmgf-box lmgf-there">';
		$h .= '<h2 class="lmgf-title">' . esc_html( sprintf( LMGF_I18n::t( 'there_title', $l ), $v['name'] ) ) . '</h2>';
		$h .= '<table class="lmgf-routes"><thead><tr>'
			. '<th scope="col">' . esc_html( LMGF_I18n::t( 'col_from', $l ) ) . '</th>'
			. '<th scope="col">' . esc_html( LMGF_I18n::t( 'col_with', $l ) ) . '</th>'
			. '<th scope="col">' . esc_html( LMGF_I18n::t( 'col_how', $l ) ) . '</th>'
			. '<th scope="col">' . esc_html( LMGF_I18n::t( 'col_time', $l ) ) . '</th>'
			. '</tr></thead><tbody>' . $rows . '</tbody></table>';
		$foot = LMGF_I18n::t( 'routes_note', $l );
		if ( $v['routes_checked'] ) $foot = sprintf( LMGF_I18n::t( 'checked', $l ), self::date( $v['routes_checked'], $l ) ) . '. ' . $foot;
		$h .= '<p class="lmgf-checked">' . esc_html( $foot ) . '</p>';
		return $h . '</section>';
	}

	public static function more( $post_id ) {
		$page = LMGF_Data::country_page_for( $post_id );
		if ( ! $page ) return '';
		$lang   = LMGF_Data::lang_of( $post_id );
		$target = LMGF_Data::page_in_lang( $page, $lang );
		if ( ! $target || get_post_status( $target ) !== 'publish' ) return '';
		$name = LMGF_Data::name_in( $page, $lang );
		$link = '<a href="' . esc_url( get_permalink( $target ) ) . '">' . esc_html( get_the_title( $target ) ) . '</a>';
		$h  = '<aside class="lmgf lmgf-box lmgf-more" lang="' . esc_attr( self::html_lang( $lang ) ) . '">';
		$h .= '<p class="lmgf-title">' . esc_html( sprintf( LMGF_I18n::t( 'more_title', $lang ), $name ) ) . '</p>';
		$h .= '<p>' . sprintf( esc_html( LMGF_I18n::t( LMGF_I18n::k( 'more_body' ), $lang ) ), $link, esc_html( $name ) ) . '</p>';
		return $h . '</aside>';
	}

	// ---- Helpers ---------------------------------------------------------------

	public static function html_lang( $l ) {
		return $l === 'nb' ? 'no' : $l;
	}

	public static function date( $ymd, $lang ) {
		$ts = strtotime( $ymd . ' 12:00:00' );
		if ( ! $ts ) return $ymd;
		switch ( $lang ) {
			case 'en':
				$m = array( 1 => 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December' );
				return gmdate( 'j', $ts ) . ' ' . $m[ (int) gmdate( 'n', $ts ) ] . ' ' . gmdate( 'Y', $ts );
			case 'sv':
				return gmdate( 'Y-m-d', $ts );
			case 'fr': case 'es': case 'it': case 'pt':
				return gmdate( 'd/m/Y', $ts );
			default:
				return gmdate( 'j.n.Y', $ts );
		}
	}
}
