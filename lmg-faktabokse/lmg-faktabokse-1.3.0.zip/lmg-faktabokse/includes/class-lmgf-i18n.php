<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Reader-facing words in the ten LMG Translator languages.
 * Keys follow LMGT_Langs (Norwegian is `nb`).
 */
class LMGF_I18n {

	const LANGS = array( 'da', 'en', 'de', 'fr', 'es', 'it', 'sv', 'nb', 'pt', 'fi' );

	public static function table() {
		static $t = null;
		if ( $t !== null ) return $t;
		$t = array(
			'facts_title' => array(
				'da' => 'Fakta om %s', 'en' => 'Facts about %s', 'de' => '%s – Reisefakten', 'fr' => '%s : l’essentiel',
				'es' => '%s: datos prácticos', 'it' => '%s: informazioni utili', 'sv' => 'Fakta om %s', 'nb' => 'Fakta om %s',
				'pt' => '%s: informações úteis', 'fi' => '%s: perustiedot',
			),
			'there_title' => array(
				'da' => 'Sådan kommer du til %s', 'en' => 'How to get to %s', 'de' => '%s – Anreise', 'fr' => '%s : comment s’y rendre',
				'es' => 'Cómo llegar a %s', 'it' => '%s: come arrivare', 'sv' => 'Så tar du dig till %s', 'nb' => 'Slik kommer du deg til %s',
				'pt' => '%s: como chegar', 'fi' => 'Näin pääset kohteeseen %s',
			),
			'more_title' => array(
				'da' => 'Vil du vide mere om %s?', 'en' => 'Want to know more about %s?', 'de' => 'Mehr über %s erfahren?', 'fr' => '%s : envie d’en savoir plus ?',
				'es' => '¿Quieres saber más sobre %s?', 'it' => '%s: vuoi saperne di più?', 'sv' => 'Vill du veta mer om %s?', 'nb' => 'Vil du vite mer om %s?',
				'pt' => '%s: quer saber mais?', 'fi' => '%s – haluatko tietää lisää?',
			),
			'more_body' => array(
				'da' => 'Gå til siden %1$s. Her finder du også faktabokse om de fleste relevante rejsefakta, inklusive sådan kommer du til %2$s.',
				'en' => 'Go to %1$s. There you will also find fact boxes covering most of the travel facts you need, including how to get to %2$s.',
				'de' => 'Gehen Sie zur Seite %1$s. Dort finden Sie auch Faktenboxen mit den wichtigsten Reiseinformationen, einschließlich der Anreise.',
				'fr' => 'Rendez-vous sur la page %1$s. Vous y trouverez aussi des encadrés avec l’essentiel des informations pratiques, y compris comment s’y rendre.',
				'es' => 'Ve a la página %1$s. Allí también encontrarás fichas con los datos de viaje más importantes, incluido cómo llegar a %2$s.',
				'it' => 'Vai alla pagina %1$s. Troverai anche schede con le principali informazioni di viaggio, compreso come arrivarci.',
				'sv' => 'Gå till sidan %1$s. Där hittar du också faktarutor med de flesta viktiga resefakta, bland annat hur du tar dig till %2$s.',
				'nb' => 'Gå til siden %1$s. Der finner du også faktabokser med de fleste relevante reisefakta, blant annet hvordan du kommer deg til %2$s.',
				'pt' => 'Acesse a página %1$s. Lá você também encontra quadros com as principais informações de viagem, incluindo como chegar.',
				'fi' => 'Siirry sivulle %1$s. Sieltä löydät myös tietolaatikot tärkeimmistä matkatiedoista, myös sen, miten sinne pääsee.',
			),
			'capital'   => array( 'da' => 'Hovedstad', 'en' => 'Capital', 'de' => 'Hauptstadt', 'fr' => 'Capitale', 'es' => 'Capital', 'it' => 'Capitale', 'sv' => 'Huvudstad', 'nb' => 'Hovedstad', 'pt' => 'Capital', 'fi' => 'Pääkaupunki' ),
			'language'  => array( 'da' => 'Sprog', 'en' => 'Language', 'de' => 'Sprache', 'fr' => 'Langue', 'es' => 'Idioma', 'it' => 'Lingua', 'sv' => 'Språk', 'nb' => 'Språk', 'pt' => 'Idioma', 'fi' => 'Kieli' ),
			'currency'  => array( 'da' => 'Valuta', 'en' => 'Currency', 'de' => 'Währung', 'fr' => 'Monnaie', 'es' => 'Moneda', 'it' => 'Valuta', 'sv' => 'Valuta', 'nb' => 'Valuta', 'pt' => 'Moeda', 'fi' => 'Valuutta' ),
			'time'      => array( 'da' => 'Tidsforskel', 'en' => 'Time difference', 'de' => 'Zeitunterschied', 'fr' => 'Décalage horaire', 'es' => 'Diferencia horaria', 'it' => 'Fuso orario', 'sv' => 'Tidsskillnad', 'nb' => 'Tidsforskjell', 'pt' => 'Fuso horário', 'fi' => 'Aikaero' ),
			'visa'      => array( 'da' => 'Visum og indrejse', 'en' => 'Visa and entry', 'de' => 'Visum und Einreise', 'fr' => 'Visa et entrée', 'es' => 'Visado y entrada', 'it' => 'Visto e ingresso', 'sv' => 'Visum och inresa', 'nb' => 'Visum og innreise', 'pt' => 'Visto e entrada', 'fi' => 'Viisumi ja maahantulo' ),
			'best_time' => array( 'da' => 'Bedste rejsetid', 'en' => 'Best time to go', 'de' => 'Beste Reisezeit', 'fr' => 'Meilleure période', 'es' => 'Mejor época para viajar', 'it' => 'Periodo migliore', 'sv' => 'Bästa restid', 'nb' => 'Beste reisetid', 'pt' => 'Melhor época', 'fi' => 'Paras matka-aika' ),
			'plugs'     => array( 'da' => 'Stikkontakter', 'en' => 'Plugs', 'de' => 'Steckdosen', 'fr' => 'Prises électriques', 'es' => 'Enchufes', 'it' => 'Prese elettriche', 'sv' => 'Eluttag', 'nb' => 'Stikkontakter', 'pt' => 'Tomadas', 'fi' => 'Pistorasiat' ),
			'health'    => array( 'da' => 'Sundhed og vaccination', 'en' => 'Health and vaccinations', 'de' => 'Gesundheit und Impfungen', 'fr' => 'Santé et vaccins', 'es' => 'Salud y vacunas', 'it' => 'Salute e vaccini', 'sv' => 'Hälsa och vaccin', 'nb' => 'Helse og vaksiner', 'pt' => 'Saúde e vacinas', 'fi' => 'Terveys ja rokotukset' ),
			'checked'   => array( 'da' => 'Senest tjekket %s', 'en' => 'Last checked %s', 'de' => 'Zuletzt geprüft: %s', 'fr' => 'Vérifié le %s', 'es' => 'Última revisión: %s', 'it' => 'Ultimo controllo: %s', 'sv' => 'Senast kontrollerad %s', 'nb' => 'Sist sjekket %s', 'pt' => 'Última verificação: %s', 'fi' => 'Tarkistettu %s' ),
			'routes_note' => array(
				'da' => 'Tjek altid ruter og tider hos selskabet, før du bestiller.', 'en' => 'Always check routes and times with the carrier before you book.',
				'de' => 'Prüfen Sie Strecken und Zeiten vor der Buchung immer beim Anbieter.', 'fr' => 'Vérifiez toujours les trajets et horaires auprès de la compagnie avant de réserver.',
				'es' => 'Comprueba siempre rutas y horarios con la compañía antes de reservar.', 'it' => 'Verifica sempre rotte e orari con la compagnia prima di prenotare.',
				'sv' => 'Kontrollera alltid rutter och tider hos bolaget innan du bokar.', 'nb' => 'Sjekk alltid ruter og tider hos selskapet før du bestiller.',
				'pt' => 'Confirme sempre rotas e horários com a companhia antes de reservar.', 'fi' => 'Tarkista reitit ja ajat aina yhtiöltä ennen varaamista.',
			),
			'col_from' => array( 'da' => 'Fra', 'en' => 'From', 'de' => 'Ab', 'fr' => 'Départ', 'es' => 'Desde', 'it' => 'Da', 'sv' => 'Från', 'nb' => 'Fra', 'pt' => 'De', 'fi' => 'Mistä' ),
			'col_how'  => array( 'da' => 'Sådan', 'en' => 'How', 'de' => 'Wie', 'fr' => 'Comment', 'es' => 'Cómo', 'it' => 'Come', 'sv' => 'Hur', 'nb' => 'Hvordan', 'pt' => 'Como', 'fi' => 'Miten' ),
			'col_with' => array( 'da' => 'Med', 'en' => 'With', 'de' => 'Mit', 'fr' => 'Avec', 'es' => 'Con', 'it' => 'Con', 'sv' => 'Med', 'nb' => 'Med', 'pt' => 'Com', 'fi' => 'Yhtiö' ),
			'col_time' => array( 'da' => 'Rejsetid', 'en' => 'Travel time', 'de' => 'Reisezeit', 'fr' => 'Durée', 'es' => 'Duración', 'it' => 'Durata', 'sv' => 'Restid', 'nb' => 'Reisetid', 'pt' => 'Duração', 'fi' => 'Matka-aika' ),
			'fly_direct' => array( 'da' => 'Direkte fly', 'en' => 'Direct flight', 'de' => 'Direktflug', 'fr' => 'Vol direct', 'es' => 'Vuelo directo', 'it' => 'Volo diretto', 'sv' => 'Direktflyg', 'nb' => 'Direktefly', 'pt' => 'Voo direto', 'fi' => 'Suora lento' ),
			'fly_1' => array( 'da' => 'Fly med 1 stop', 'en' => 'Flight, 1 stop', 'de' => 'Flug mit 1 Stopp', 'fr' => 'Vol avec 1 escale', 'es' => 'Vuelo con 1 escala', 'it' => 'Volo con 1 scalo', 'sv' => 'Flyg med 1 byte', 'nb' => 'Fly med 1 stopp', 'pt' => 'Voo com 1 escala', 'fi' => 'Lento, 1 vaihto' ),
			'fly_2' => array( 'da' => 'Fly med 2 stop', 'en' => 'Flight, 2 stops', 'de' => 'Flug mit 2 Stopps', 'fr' => 'Vol avec 2 escales', 'es' => 'Vuelo con 2 escalas', 'it' => 'Volo con 2 scali', 'sv' => 'Flyg med 2 byten', 'nb' => 'Fly med 2 stopp', 'pt' => 'Voo com 2 escalas', 'fi' => 'Lento, 2 vaihtoa' ),
			'train' => array( 'da' => 'Tog', 'en' => 'Train', 'de' => 'Zug', 'fr' => 'Train', 'es' => 'Tren', 'it' => 'Treno', 'sv' => 'Tåg', 'nb' => 'Tog', 'pt' => 'Trem', 'fi' => 'Juna' ),
			'bus'   => array( 'da' => 'Bus', 'en' => 'Bus', 'de' => 'Bus', 'fr' => 'Autocar', 'es' => 'Autobús', 'it' => 'Autobus', 'sv' => 'Buss', 'nb' => 'Buss', 'pt' => 'Ônibus', 'fi' => 'Bussi' ),
			'ferry' => array( 'da' => 'Færge', 'en' => 'Ferry', 'de' => 'Fähre', 'fr' => 'Ferry', 'es' => 'Ferri', 'it' => 'Traghetto', 'sv' => 'Färja', 'nb' => 'Ferje', 'pt' => 'Balsa', 'fi' => 'Lautta' ),
			'car'   => array( 'da' => 'Bil', 'en' => 'Car', 'de' => 'Auto', 'fr' => 'Voiture', 'es' => 'Coche', 'it' => 'Auto', 'sv' => 'Bil', 'nb' => 'Bil', 'pt' => 'Carro', 'fi' => 'Auto' ),
			'via'      => array( 'da' => 'via %s', 'en' => 'via %s', 'de' => 'über %s', 'fr' => 'via %s', 'es' => 'vía %s', 'it' => 'via %s', 'sv' => 'via %s', 'nb' => 'via %s', 'pt' => 'via %s', 'fi' => '%s kautta' ),
			'duration' => array( 'da' => 'ca. %s t', 'en' => 'about %s h', 'de' => 'ca. %s Std.', 'fr' => 'env. %s h', 'es' => 'aprox. %s h', 'it' => 'circa %s h', 'sv' => 'ca %s tim', 'nb' => 'ca. %s t', 'pt' => 'cerca de %s h', 'fi' => 'n. %s h' ),
			// 1.3.0: wine and sport sites.
			'facts_title_plain' => array( 'da' => 'Fakta om %s', 'en' => 'Facts about %s', 'de' => 'Fakten zu %s', 'fr' => '%s : les faits', 'es' => 'Datos sobre %s', 'it' => '%s: i fatti', 'sv' => 'Fakta om %s', 'nb' => 'Fakta om %s', 'pt' => 'Factos sobre %s', 'fi' => '%s: faktat' ),
			'more_body_plain' => array( 'da' => 'Gå til siden %1$s. Her finder du også en faktaboks med det vigtigste om %2$s.', 'en' => 'Go to %1$s. There you will also find a fact box with the key facts about %2$s.', 'de' => 'Gehen Sie zur Seite %1$s. Dort finden Sie auch eine Faktenbox mit dem Wichtigsten zu %2$s.', 'fr' => 'Rendez-vous sur la page %1$s. Vous y trouverez aussi un encadré avec l’essentiel sur %2$s.', 'es' => 'Ve a la página %1$s. Allí también encontrarás una ficha con los datos clave sobre %2$s.', 'it' => 'Vai alla pagina %1$s. Troverai anche una scheda con le informazioni principali su %2$s.', 'sv' => 'Gå till sidan %1$s. Där hittar du också en faktaruta med det viktigaste om %2$s.', 'nb' => 'Gå til siden %1$s. Der finner du også en faktaboks med det viktigste om %2$s.', 'pt' => 'Aceda à página %1$s. Lá encontra também um quadro com os factos principais sobre %2$s.', 'fi' => 'Siirry sivulle %1$s. Sieltä löydät myös tietolaatikon, jossa on tärkeimmät tiedot: %2$s.' ),
			'grapes' => array( 'da' => 'Druer', 'en' => 'Grapes', 'de' => 'Rebsorten', 'fr' => 'Cépages', 'es' => 'Uvas', 'it' => 'Vitigni', 'sv' => 'Druvor', 'nb' => 'Druer', 'pt' => 'Castas', 'fi' => 'Rypäleet' ),
			'styles' => array( 'da' => 'Vintyper', 'en' => 'Wine styles', 'de' => 'Weinstile', 'fr' => 'Styles de vin', 'es' => 'Estilos de vino', 'it' => 'Stili di vino', 'sv' => 'Vinstilar', 'nb' => 'Vintyper', 'pt' => 'Estilos de vinho', 'fi' => 'Viinityylit' ),
			'classification' => array( 'da' => 'Klassifikation', 'en' => 'Classification', 'de' => 'Klassifikation', 'fr' => 'Appellations', 'es' => 'Denominaciones', 'it' => 'Denominazioni', 'sv' => 'Klassificering', 'nb' => 'Klassifisering', 'pt' => 'Denominações', 'fi' => 'Luokitus' ),
			'area' => array( 'da' => 'Vinmarksareal', 'en' => 'Vineyard area', 'de' => 'Rebfläche', 'fr' => 'Superficie du vignoble', 'es' => 'Superficie de viñedo', 'it' => 'Superficie vitata', 'sv' => 'Vingårdsareal', 'nb' => 'Vinmarksareal', 'pt' => 'Área de vinha', 'fi' => 'Viinitarhojen pinta-ala' ),
			'vintages' => array( 'da' => 'Gode årgange', 'en' => 'Good recent vintages', 'de' => 'Gute Jahrgänge', 'fr' => 'Bons millésimes', 'es' => 'Buenas añadas', 'it' => 'Annate migliori', 'sv' => 'Bra årgångar', 'nb' => 'Gode årganger', 'pt' => 'Boas colheitas', 'fi' => 'Hyvät vuosikerrat' ),
			'visit' => array( 'da' => 'Bedste tid at besøge', 'en' => 'Best time to visit', 'de' => 'Beste Besuchszeit', 'fr' => 'Meilleure période pour visiter', 'es' => 'Mejor época para visitar', 'it' => 'Periodo migliore per visitare', 'sv' => 'Bästa tid att besöka', 'nb' => 'Beste tid å besøke', 'pt' => 'Melhor época para visitar', 'fi' => 'Paras vierailuaika' ),
			'sport' => array( 'da' => 'Sportsgren', 'en' => 'Sport', 'de' => 'Sportart', 'fr' => 'Sport', 'es' => 'Deporte', 'it' => 'Sport', 'sv' => 'Sport', 'nb' => 'Idrett', 'pt' => 'Desporto', 'fi' => 'Laji' ),
			'when' => array( 'da' => 'Hvornår', 'en' => 'When', 'de' => 'Wann', 'fr' => 'Quand', 'es' => 'Cuándo', 'it' => 'Quando', 'sv' => 'När', 'nb' => 'Når', 'pt' => 'Quando', 'fi' => 'Milloin' ),
			'venue' => array( 'da' => 'Sted / værtsbyer', 'en' => 'Venue / host cities', 'de' => 'Austragungsort', 'fr' => 'Lieu / villes hôtes', 'es' => 'Sede / ciudades', 'it' => 'Sede / città ospitanti', 'sv' => 'Arena / värdstäder', 'nb' => 'Arena / vertsbyer', 'pt' => 'Local / cidades-sede', 'fi' => 'Paikka / isäntäkaupungit' ),
			'format' => array( 'da' => 'Format', 'en' => 'Format', 'de' => 'Modus', 'fr' => 'Format', 'es' => 'Formato', 'it' => 'Formula', 'sv' => 'Format', 'nb' => 'Format', 'pt' => 'Formato', 'fi' => 'Formaatti' ),
			'record' => array( 'da' => 'Rekord / flest titler', 'en' => 'Record / most titles', 'de' => 'Rekord / meiste Titel', 'fr' => 'Record / plus de titres', 'es' => 'Récord / más títulos', 'it' => 'Record / più titoli', 'sv' => 'Rekord / flest titlar', 'nb' => 'Rekord / flest titler', 'pt' => 'Recorde / mais títulos', 'fi' => 'Ennätys / eniten voittoja' ),
			'watch' => array( 'da' => 'Sådan ser du det', 'en' => 'How to watch', 'de' => 'So sehen Sie es', 'fr' => 'Où regarder', 'es' => 'Dónde verlo', 'it' => 'Dove vederlo', 'sv' => 'Så ser du det', 'nb' => 'Slik ser du det', 'pt' => 'Onde ver', 'fi' => 'Mistä katsoa' ),
			'tickets' => array( 'da' => 'Billetter', 'en' => 'Tickets', 'de' => 'Tickets', 'fr' => 'Billets', 'es' => 'Entradas', 'it' => 'Biglietti', 'sv' => 'Biljetter', 'nb' => 'Billetter', 'pt' => 'Bilhetes', 'fi' => 'Liput' ),
		);
		return $t;
	}

	public static function modes() {
		return array( 'fly_direct', 'fly_1', 'fly_2', 'train', 'bus', 'ferry', 'car' );
	}

	/** 1.3.0: the facts follow the site – travel, wine or sport. */
	public static function fact_keys() {
		switch ( LMGF_Data::profile() ) {
			case 'wine':  return array( 'grapes', 'styles', 'classification', 'area', 'vintages', 'visit' );
			case 'sport': return array( 'sport', 'when', 'venue', 'format', 'record', 'watch', 'tickets' );
		}
		return array( 'capital', 'language', 'currency', 'time', 'visa', 'best_time', 'plugs', 'health' );
	}

	/** Reader-facing keys whose wording differs outside travel. */
	public static function k( $key ) {
		return LMGF_Data::is_travel() ? $key : $key . '_plain';
	}

	/** A word in a language, falling back to English, then Danish. */
	public static function t( $key, $lang ) {
		$t = self::table();
		if ( ! isset( $t[ $key ] ) ) return $key;
		if ( isset( $t[ $key ][ $lang ] ) ) $s = $t[ $key ][ $lang ];
		elseif ( isset( $t[ $key ]['en'] ) ) $s = $t[ $key ]['en'];
		else $s = $t[ $key ]['da'];
		return apply_filters( 'lmg_faktabokse_text', $s, $key, $lang );
	}
}
