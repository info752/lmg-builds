<?php
/**
 * Plugin Name: LMG Faktabokse
 * Description: Fact boxes on country pages ("Fakta om …", "Sådan kommer du til …") and a "Vil du vide mere om …?" box on posts. Ten languages, works with LMG Translator. Also the Rejseservice / Travel Services section and its "Rejsepraktisk" box, and travel providers tagged by destination. On winetalk and worldsporttalk the boxes carry wine or sport facts instead.
 * Version:     1.3.0
 * Author:      Leisure Media Group
 * Text Domain: lmg-faktabokse
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'LMGF_VERSION', '1.3.0' );
define( 'LMGF_FILE', __FILE__ );
define( 'LMGF_DIR', plugin_dir_path( __FILE__ ) );
define( 'LMGF_URL', plugin_dir_url( __FILE__ ) );

require_once LMGF_DIR . 'includes/class-lmgf-i18n.php';
require_once LMGF_DIR . 'includes/class-lmgf-data.php';
require_once LMGF_DIR . 'includes/class-lmgf-front.php';
require_once LMGF_DIR . 'includes/class-lmgf-admin.php';
require_once LMGF_DIR . 'includes/class-lmgf-notes.php';
require_once LMGF_DIR . 'includes/class-lmgf-services.php';
require_once LMGF_DIR . 'includes/class-lmgf-providers.php';

LMGF_Data::boot();
LMGF_Front::boot();
// 1.3.0: travel services and providers only on travel sites.
if ( LMGF_Data::is_travel() ) {
	LMGF_Services::boot();
	LMGF_Providers::boot();
}
if ( is_admin() ) {
	LMGF_Admin::boot();
	LMGF_Notes::boot();
}

register_activation_hook( __FILE__, function () {
	LMGF_Data::rebuild_map();
} );
