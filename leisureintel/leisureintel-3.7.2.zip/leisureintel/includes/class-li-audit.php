<?php
if (!defined('ABSPATH')) exit;

class LI_Audit {

    const BATCH_SIZE = 15;

    /**
     * Run a full content audit on all published posts.
     * Returns [ 'posts_audited' => N, 'report_id' => post_id, 'summary' => [...] ]
     */
    public function run($ga4_metrics = []) {
        $posts = $this->get_all_published_posts();
        if (empty($posts)) {
            return new WP_Error('li_audit_error', 'No published posts found.');
        }

        $data_class = new LI_Data();
        $gsc_lookup = $data_class->get_gsc_lookup_all();

        $enriched  = [];
        $site_url  = trailingslashit(get_site_url());

        foreach ($posts as $post) {
            $url  = get_permalink($post->ID);
            $path = '/' . ltrim(str_replace($site_url, '', $url), '/');

            $gsc = $gsc_lookup[$url] ?? $gsc_lookup[rtrim($url, '/')] ?? null;
            $ga4 = $ga4_metrics[$path] ?? $ga4_metrics[rtrim($path, '/')] ?? null;

            $age_days = (int)((time() - strtotime($post->post_date)) / DAY_IN_SECONDS);
            $cats     = wp_get_post_categories($post->ID, ['fields' => 'names']);

            $enriched[] = [
                'post_id'    => $post->ID,
                'title'      => $post->post_title,
                'url'        => $url,
                'path'       => $path,
                'age_days'   => $age_days,
                'categories' => implode(', ', $cats),
                'clicks'     => $gsc ? (int)$gsc->total_clicks : 0,
                'impressions'=> $gsc ? (int)$gsc->total_impressions : 0,
                'position'   => $gsc ? round((float)$gsc->avg_position, 1) : null,
                'pageviews'  => $ga4 ? $ga4['pageviews'] : 0,
                'bounce_rate'=> $ga4 ? $ga4['bounce_rate'] : null,
                'avg_session'=> $ga4 ? $ga4['avg_session_duration'] : null,
            ];
        }

        // Process in batches
        $claude      = new LI_Claude();
        $all_results = [];

        foreach (array_chunk($enriched, self::BATCH_SIZE) as $batch) {
            $classifications = $claude->get_audit_classifications($batch);
            if (!is_wp_error($classifications)) {
                $all_results = array_merge($all_results, $classifications);
            }
        }

        if (empty($all_results)) {
            return new WP_Error('li_audit_error', 'No audit results returned from Claude.');
        }

        // Build lookup by post_id for attaching decisions back to enriched data
        $decision_map = [];
        foreach ($all_results as $r) {
            if (!empty($r['post_id'])) {
                $decision_map[(int)$r['post_id']] = $r;
            }
        }

        // Merge decision back into enriched rows (fallback: keep)
        $full_results = [];
        foreach ($enriched as $item) {
            $decision = $decision_map[$item['post_id']] ?? ['action' => 'behold', 'reason' => ''];
            $item['action'] = $decision['action'] ?? 'behold';
            $item['reason'] = $decision['reason'] ?? '';
            $full_results[]  = $item;
        }

        // ⭐ NEVER-PURGE-ALL GUARDRAIL (G 2026-07-19) — the audit is structurally incapable of a mass-delete.
        // If 'slet' exceeds a small cap, that is a MISREAD of the task, not an instruction: demote every
        // 'slet' to 'forbedring' (rescue-first) with a visible flag, and record the anomaly for the admin.
        // Belt-and-braces with the rescue-first prompt; the audit already only PROPOSES (nothing executes).
        $total_count = count($full_results);
        $slet_count  = count(array_filter($full_results, function($r){ return ($r['action'] ?? '') === 'slet'; }));
        $slet_cap    = max(5, (int) ceil($total_count * 0.05)); // 5% of the batch, or 5, whichever is larger
        $guardrail   = '';
        if ($slet_count > $slet_cap) {
            foreach ($full_results as &$__gr) {
                if (($__gr['action'] ?? '') === 'slet') {
                    $__gr['action'] = 'forbedring';
                    $__gr['reason'] = '[MASSESLETNING BLOKERET — vurder enkeltvis] ' . ($__gr['reason'] ?? '');
                }
            }
            unset($__gr);
            $guardrail = "Massesletning blokeret: {$slet_count} indlæg blev markeret 'slet' (over grænsen på {$slet_cap}). "
                       . "Alle er nedgraderet til 'forbedring' til manuel enkeltvurdering. Et så stort slet-tal er en "
                       . "misforståelse af opgaven, ikke en anbefaling.";
        }

        // Sort: slet → viderestil → forbedring → behold
        $order = ['slet' => 0, 'viderestil' => 1, 'forbedring' => 2, 'behold' => 3];
        usort($full_results, function($a, $b) use ($order) {
            return ($order[$a['action']] ?? 4) - ($order[$b['action']] ?? 4);
        });

        $generator = new LI_Generator();
        $report_id = $generator->create_audit_report($full_results);

        $summary = array_count_values(array_column($full_results, 'action'));

        $log = [
            'date'          => current_time('mysql'),
            'posts_audited' => count($full_results),
            'behold'        => $summary['behold'] ?? 0,
            'forbedring'    => $summary['forbedring'] ?? 0,
            'viderestil'    => $summary['viderestil'] ?? 0,
            'slet'          => $summary['slet'] ?? 0,
            'report_id'     => $report_id,
            'guardrail'     => $guardrail,
        ];
        $audit_log = get_option('li_audit_log', []);
        array_unshift($audit_log, $log);
        update_option('li_audit_log', array_slice($audit_log, 0, 10));

        // Save structured results to approval queue (read-only — no actions executed)
        LI_Approvals::save_pending($full_results, $report_id);

        return [
            'posts_audited' => count($full_results),
            'report_id'     => $report_id,
            'summary'       => $summary,
            'guardrail'     => $guardrail,
        ];
    }

    private function get_all_published_posts() {
        global $wpdb;
        return $wpdb->get_results(
            "SELECT ID, post_title, post_date
             FROM {$wpdb->posts}
             WHERE post_status = 'publish'
               AND post_type = 'post'
             ORDER BY post_date DESC"
        );
    }
}
