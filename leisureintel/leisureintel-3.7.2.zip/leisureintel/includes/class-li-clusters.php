<?php
if (!defined('ABSPATH')) exit;

class LI_Clusters {

    /**
     * Build full cluster dataset: all published posts grouped by category,
     * enriched with GSC and GA4 metrics, scored and signalled.
     */
    public function get_cluster_data() {
        global $wpdb;

        $posts = $wpdb->get_results(
            "SELECT ID, post_title, post_name
             FROM {$wpdb->posts}
             WHERE post_status = 'publish' AND post_type = 'post'"
        );

        if (empty($posts)) return [];

        $data_class  = new LI_Data();
        $gsc_lookup  = $data_class->get_gsc_lookup_all();
        $gsc_90d     = $this->get_gsc_90d_lookup();

        $ga4_metrics = [];
        $ga4 = new LI_GA4();
        if ($ga4->is_configured()) {
            $result = $ga4->get_page_metrics(30);
            if (!is_wp_error($result)) $ga4_metrics = $result;
        }

        $site_url = trailingslashit(get_site_url());
        $clusters = [];

        foreach ($posts as $post) {
            $url  = get_permalink($post->ID);
            $path = '/' . ltrim(str_replace($site_url, '', $url), '/');

            // GSC (Rank Math) stores relative PATHS, not full URLs — match on $path, not $url.
            $gsc     = $gsc_lookup[$path] ?? $gsc_lookup[rtrim($path, '/')] ?? $gsc_lookup[rtrim($path, '/') . '/'] ?? null;
            $ga4_row = $ga4_metrics[$path] ?? $ga4_metrics[rtrim($path, '/')] ?? null;

            $cats = wp_get_post_categories($post->ID, ['fields' => 'all']);
            if (empty($cats)) continue;

            $row = [
                'post_id'    => $post->ID,
                'title'      => $post->post_title,
                'url'        => $url,
                'clicks'     => $gsc ? (int)$gsc->total_clicks : 0,
                'impressions'=> $gsc ? (int)$gsc->total_impressions : 0,
                'position'   => $gsc ? (float)$gsc->avg_position : null,
                'pageviews'  => $ga4_row ? $ga4_row['pageviews'] : 0,
                'avg_session'=> $ga4_row ? $ga4_row['avg_session_duration'] : null,
                'bounce_rate'=> $ga4_row ? $ga4_row['bounce_rate'] : null,
                'clicks_90d' => $gsc_90d[$path] ?? $gsc_90d[rtrim($path, '/')] ?? $gsc_90d[rtrim($path, '/') . '/'] ?? 0,
            ];

            foreach ($cats as $cat) {
                $cid = $cat->term_id;
                if (!isset($clusters[$cid])) {
                    $clusters[$cid] = [
                        'category_id'        => $cid,
                        'category_name'      => $cat->name,
                        'category_slug'      => $cat->slug,
                        'post_count'         => 0,
                        'total_clicks'       => 0,
                        'total_impressions'  => 0,
                        'total_pageviews'    => 0,
                        'clicks_90d'         => 0,
                        '_positions'         => [],
                        '_sessions'          => [],
                        '_bounces'           => [],
                        'top_posts'          => [],
                    ];
                }

                $c = &$clusters[$cid];
                $c['post_count']++;
                $c['total_clicks']      += $row['clicks'];
                $c['total_impressions'] += $row['impressions'];
                $c['total_pageviews']   += $row['pageviews'];
                $c['clicks_90d']        += $row['clicks_90d'];
                if ($row['position'] !== null)   $c['_positions'][] = $row['position'];
                if ($row['avg_session'] !== null) $c['_sessions'][]  = $row['avg_session'];
                if ($row['bounce_rate'] !== null) $c['_bounces'][]   = $row['bounce_rate'];
                $c['top_posts'][] = ['title' => $row['title'], 'clicks' => $row['clicks'], 'url' => $row['url']];
            }
            unset($c);
        }

        // Aggregate, score, signal
        foreach ($clusters as &$cluster) {
            $cluster['avg_position'] = !empty($cluster['_positions'])
                ? round(array_sum($cluster['_positions']) / count($cluster['_positions']), 1)
                : null;
            $cluster['avg_session'] = !empty($cluster['_sessions'])
                ? round(array_sum($cluster['_sessions']) / count($cluster['_sessions']), 1)
                : null;
            $cluster['avg_bounce'] = !empty($cluster['_bounces'])
                ? round(array_sum($cluster['_bounces']) / count($cluster['_bounces']), 1)
                : null;

            // Momentum: annualised 30d vs 90d total
            $cluster['momentum'] = $cluster['clicks_90d'] > 0
                ? round(($cluster['total_clicks'] * 3 - $cluster['clicks_90d']) / $cluster['clicks_90d'], 2)
                : 0;

            // Top 3 posts by clicks
            usort($cluster['top_posts'], fn($a, $b) => $b['clicks'] - $a['clicks']);
            $cluster['top_posts'] = array_slice($cluster['top_posts'], 0, 3);

            $cluster['cluster_score'] = $this->calculate_score($cluster);
            $cluster['signal']        = $this->determine_signal($cluster);

            unset($cluster['_positions'], $cluster['_sessions'], $cluster['_bounces']);
        }
        unset($cluster);

        // Filter out single-post categories and uncategorized (slug = uncategorized)
        $clusters = array_filter($clusters, fn($c) =>
            $c['post_count'] >= 2 && $c['category_slug'] !== 'uncategorized'
        );

        // Sort: strong first, then by score desc
        $signal_order = ['strong' => 0, 'growing' => 1, 'untapped' => 2, 'moderate' => 3, 'weak' => 4];
        usort($clusters, function($a, $b) use ($signal_order) {
            $so = ($signal_order[$a['signal']] ?? 5) - ($signal_order[$b['signal']] ?? 5);
            return $so !== 0 ? $so : $b['cluster_score'] - $a['cluster_score'];
        });

        return array_values($clusters);
    }

    /**
     * Prescription: what does it take to move this cluster from current score to higher?
     * Pure arithmetic — no Claude needed.
     */
    public function get_prescription($data) {
        $score    = (int)($data['cluster_score'] ?? 5);
        $pc       = (int)($data['post_count'] ?? 0);
        $pos      = ($data['avg_position'] !== null && $data['avg_position'] !== '') ? (float)$data['avg_position'] : null;
        $clicks   = (int)($data['total_clicks'] ?? 0);
        $momentum = (float)($data['momentum'] ?? 0);
        $session  = ($data['avg_session'] !== null && $data['avg_session'] !== '') ? (float)$data['avg_session'] : null;
        $bounce   = ($data['avg_bounce'] !== null && $data['avg_bounce'] !== '') ? (float)$data['avg_bounce'] : null;
        $cpp      = $pc > 0 ? $clicks / $pc : 0;

        $actions = [];

        // Post count
        if ($pc < 3)
            $actions[] = ['text' => "Tilføj " . (3 - $pc) . " indlæg mere for at nå minimumstærsklen — +0.5", 'gain' => 0.5, 'p' => 1];
        elseif ($pc < 8)
            $actions[] = ['text' => "Tilføj " . (8 - $pc) . " indlæg (fra {$pc} til 8) — +0.5 i klyngestørrelse", 'gain' => 0.5, 'p' => 1];
        elseif ($pc < 15)
            $actions[] = ['text' => "Tilføj " . (15 - $pc) . " indlæg (fra {$pc} til 15) — yderligere +0.5", 'gain' => 0.5, 'p' => 2];

        // Position
        if ($pos === null) {
            $actions[] = ['text' => "Ingen positionsdata — indeksér og optimer indhold for søgesynlighed — potentielt +1.5", 'gain' => 1.5, 'p' => 1];
        } elseif ($pos > 30) {
            $actions[] = ['text' => "Gennemsnitsposition " . round($pos, 1) . " — løft til top 30 — +0.5", 'gain' => 0.5, 'p' => 1];
        } elseif ($pos > 20) {
            $actions[] = ['text' => "Gennemsnitsposition " . round($pos, 1) . " — løft til top 20 — +0.5", 'gain' => 0.5, 'p' => 1];
        } elseif ($pos > 10) {
            $actions[] = ['text' => "Gennemsnitsposition " . round($pos, 1) . " — løft til top 10 — +0.5", 'gain' => 0.5, 'p' => 2];
        }

        // Clicks per post
        if ($cpp < 8)
            $actions[] = ['text' => "Klik per indlæg: " . round($cpp, 1) . " — mål 8+ med bedre titler og meta — +0.5", 'gain' => 0.5, 'p' => 1];
        elseif ($cpp < 25)
            $actions[] = ['text' => "Klik per indlæg: " . round($cpp, 1) . " — mål 25+ for næste tærskel — +0.5", 'gain' => 0.5, 'p' => 2];

        // Momentum
        if ($momentum < -0.25)
            $actions[] = ['text' => "Klik falder (" . round($momentum * 100) . "%) — opdater + publicer nyt indhold akut — +1.5 hvis vendt", 'gain' => 1.5, 'p' => 1];
        elseif ($momentum <= 0.1)
            $actions[] = ['text' => "Svag momentum — 2-3 nye stærke indlæg kan tilføje +1.0", 'gain' => 1.0, 'p' => 1];
        elseif ($momentum <= 0.25)
            $actions[] = ['text' => "Momentum positiv men kan styrkes — +25% klyvækst låser op for +0.5", 'gain' => 0.5, 'p' => 3];

        // GA4
        if ($session === null)
            $actions[] = ['text' => "Ingen GA4-sessionsdata — tilslut GA4 for op til +1.0 i engagement-scoring", 'gain' => 1.0, 'p' => 1];
        elseif ($session <= 120)
            $actions[] = ['text' => "Sessionstid " . round($session) . "s — mål 120s+ med dybere indhold og faktabokse — +0.5", 'gain' => 0.5, 'p' => 2];

        if ($bounce !== null && $bounce >= 50)
            $actions[] = ['text' => "Bounce rate " . round($bounce) . "% — reducer til under 50% med intern linking og klart CTA — +0.5", 'gain' => 0.5, 'p' => 2];

        usort($actions, fn($a, $b) => $a['p'] !== $b['p'] ? $a['p'] - $b['p'] : $b['gain'] - $a['gain']);

        return [
            'current'   => $score,
            'potential' => (int)min(10, round($score + array_sum(array_column($actions, 'gain')))),
            'actions'   => array_map(fn($a) => ['text' => $a['text'], 'gain' => $a['gain']], $actions),
        ];
    }

    private function get_gsc_90d_lookup() {
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT page, SUM(clicks) as total_clicks
             FROM {$wpdb->prefix}rank_math_analytics_gsc
             WHERE created >= DATE_SUB(NOW(), INTERVAL 90 DAY)
             GROUP BY page"
        );
        $lookup = [];
        foreach ($rows as $row) {
            $lookup[$row->page] = (int)$row->total_clicks;
        }
        return $lookup;
    }

    private function calculate_score($cluster) {
        $score = 5.0;

        // Cluster size — thresholds for boutique niche media (not mass-market)
        if ($cluster['post_count'] >= 15)    $score += 1.5;
        elseif ($cluster['post_count'] >= 8) $score += 1.0;
        elseif ($cluster['post_count'] >= 3) $score += 0.5;

        // Average position quality
        $pos = $cluster['avg_position'];
        if ($pos !== null) {
            if ($pos <= 10)      $score += 1.5;
            elseif ($pos <= 20)  $score += 1.0;
            elseif ($pos <= 30)  $score += 0.5;
        }

        // Click concentration — scaled for luxury niche traffic levels
        $cpp = $cluster['post_count'] > 0 ? $cluster['total_clicks'] / $cluster['post_count'] : 0;
        if ($cpp >= 25)      $score += 1.0;
        elseif ($cpp >= 8)   $score += 0.5;

        // Momentum
        if ($cluster['momentum'] > 0.25)      $score += 1.0;
        elseif ($cluster['momentum'] > 0.1)   $score += 0.5;
        elseif ($cluster['momentum'] < -0.25) $score -= 0.5;

        // GA4 engagement
        if ($cluster['avg_session'] !== null && $cluster['avg_session'] > 120) $score += 0.5;
        if ($cluster['avg_bounce']  !== null && $cluster['avg_bounce']  < 50)  $score += 0.5;

        return (int)max(1, min(10, round($score)));
    }

    private function determine_signal($cluster) {
        $score    = $cluster['cluster_score'];
        $momentum = $cluster['momentum'];
        $clicks   = $cluster['total_clicks'];
        $impr     = $cluster['total_impressions'];

        if ($score >= 8)                      return 'strong';
        if ($momentum > 0.25 && $score >= 5)  return 'growing';
        if ($clicks === 0 && $impr > 100)     return 'untapped';
        if ($score <= 4)                      return 'weak';
        return 'moderate';
    }
}
