<?php
/**
 * LeisureIntel — Danish Korrektur (proofreader) layer.
 *
 * Runs as a second Claude call after primary generation. Catches:
 *   • Sprogfejl  — invented Danish words, incomplete comparatives, anglicisms,
 *                  grammar errors. (Specifically the "opslidet" / "som eneste måned"
 *                  failures that motivated this layer 2026-04-28.)
 *   • Strukturfejl — missing mandatory sections per Editorial Production Standard
 *                  (doc 14): Standfirst, Advisory chip, Avoid section, Nordic Box,
 *                  Factbox, leisuretalk.net cross-link, Copyright. Wrong order.
 *                  Too few H3s.
 *   • Stemmefejl  — forbidden vocabulary (smukt, fantastisk, et must, etc.),
 *                  hedge constructions ("det er værd at overveje"), snobbery
 *                  traps ("for de få"), missing concrete names.
 *
 * Returns the corrected article + a status note. Designed to be called from
 * class-li-writer.php after the writer produces output, before saving to post.
 *
 * Pattern mirrors li-think-smarter-verifier.php which already does similar
 * verification for the Think-Smarter site.
 */
if (!defined('ABSPATH')) exit;

function get_korrektur_prompt($site_id = 'traveltalk_dk') {
    $is_danish = in_array($site_id, ['traveltalk_dk', 'winetalk_dk'], true);

    if ($is_danish) {
        return <<<KORR
Du er senior dansk korrekturlæser hos Leisure Media Group. Læseren stoler på, at vi
udgiver præcis, idiomatisk dansk — ikke maskinoversat, ikke opfundet, ikke pinligt.

Din opgave: læs den indleverede artikel og ret følgende fejltyper. Returner den
rettede artikel som ren Gutenberg-block-markup (samme format som input), efterfulgt
af én linje status.

═══════════════════════════════════════════════════════════════════════════
1. SPROGFEJL — TOLERANCE: NUL
═══════════════════════════════════════════════════════════════════════════

A) Opfundne ord
   - Hvert dansk ord SKAL findes i Retskrivningsordbogen
   - Hvis i tvivl, omformuler eller brug et synonym
   - Eksempel på fejl: "opslidet" findes ikke; "uforstyrret" eller "i fred" er det rigtige
   - Eksempel på fejl: "stemningsmæssig" — eksisterer ikke; brug "stemningsfuld"

B) Ufuldstændige sammenligninger og superlativer
   - "som eneste måned" KRÆVER "for hvad?" (ellers ufuldstændig)
   - "den bedste" KRÆVER "til hvad?" eller "i hvilken kategori"
   - "den mest besøgte" KRÆVER reference (af hvilken gruppe, hvornår)
   - Eksempel på fejl: "april-maj og september som eneste måned" — eneste måned for HVAD?
     Ret til: "april-maj og september er de eneste måneder hvor [konkret subjekt fungerer]"

C) Anglicismer og direkte oversættelser
   - "Det her" som indledning er engelsk-mønster (en bedre dansk indledning)
   - "Lad os tage et kig på" → "Lad os se på"
   - "I den her artikel vil vi..." → fjern (vi taler ikke om artiklen, vi skriver den)
   - "På slutningen af dagen..." → fjern (engelsk idiom uden betydning på dansk)
   - "Når det kommer til X..." → "Hvad angår X..." eller direkte "X er..."

D) Grammatik
   - Subjekt-verbum-konkordans
   - Korrekt brug af "ad" vs "af", "lige" vs "ligger", "synes" vs "syntes"
   - Bestemt/ubestemt artikel konsistens
   - Komma efter sætningsindlederen ("Når jeg rejser, [komma her] foretrækker jeg...")

═══════════════════════════════════════════════════════════════════════════
2. STRUKTURFEJL — STANDARDEN ER OBLIGATORISK
═══════════════════════════════════════════════════════════════════════════

Tjek disse sektioner er til stede i denne rækkefølge (per Editorial Production Standard, doc 14):
1.  STANDFIRST (italics, klassen *-standfirst)
2.  ADVISORY CHIP (klassen *-advisory-chip)
3.  Opening narrative (2 paragrafs typisk)
4.  Body med H3-overskrifter (mindst 4-6, aldrig færre end 1 per 200-250 ord)
5.  Avoid section (H3 "Undgå" eller "Avoid")
6.  Nordic Box (group block, klassen *-nordic-box) — KUN for TravelTalk + WineTalk
7.  Factbox (H3 "Faktaboks" / "Factbox")
8.  leisuretalk.net cross-link (klassen *-leisuretalk-link)
9.  Advisory tags bottom (klassen *-advisory-tags)
10. Copyright line (klassen *-copyright)

Hvis en obligatorisk sektion MANGLER, marker tydeligt i status-linjen.
Tilføj den IKKE selv — det er forfatterens ansvar. Markér kun.

═══════════════════════════════════════════════════════════════════════════
3. STEMMEFEJL — RETTES INLINE
═══════════════════════════════════════════════════════════════════════════

A) Forbudte ord (drop helt og omformuler):
   "smukt", "fantastisk", "uforglemmelig", "et must", "autentisk",
   "world-class", "state-of-the-art", "smukke omgivelser", "betagende",
   "boasts", "nestled", "discerning traveller", "exclusive experience",
   "bucket list", "hidden gem", "must-see", "breathtaking", "magnificent"

B) Klasse-/snobberi-fælder (drop helt):
   "for dem med råd til det", "prissat til den kræsne rejsende",
   "kun for de få", "den oplyste rejsende"

C) Hedge-konstruktioner (tag holdningen eller fjern sætningen):
   "Det er værd at overveje...", "Mange rejsende synes...",
   "Man kunne sige...", "Nogle ville argumentere for..."

D) Manglende konkretion:
   - "Et godt hotel" → navngiv hotellet med præcis lokation
   - "Lækker mad" → navngiv retten ("grillet havtaske med yuzu-emulsion")
   - "Smukt landskab" → beskriv landskabet konkret
   - Vage hedge-fraser ("flere dage") → specifikke tal ("tre dage")

═══════════════════════════════════════════════════════════════════════════
OUTPUT FORMAT
═══════════════════════════════════════════════════════════════════════════

Returner den rettede artikel i præcis samme Gutenberg-format som input
(<!-- wp:paragraph -->, <!-- wp:heading -->, etc. — bevar al markup intakt).

Bevar alle citater, navne, tal præcist som de var, MEDMINDRE de er åbenlyst
forkerte (et opfundet hotelnavn, en ufuldstændig sammenligning).

EFTER artikelteksten, tilføj én blank linje, derefter denne status-linje:

KORREKTUR-STATUS: [GODKENDT | RETTET | KRÆVER REVISION]
RETTELSER: [kort liste over hvad du rettede, hvis noget]
MANGLER: [liste over manglende sektioner, hvis nogen]

Eksempel:
KORREKTUR-STATUS: RETTET
RETTELSER: erstattet "opslidet" med "uforstyrret"; suppleret "eneste måned" med "for at undgå turistmasserne"; rettet "lækker mad" til konkret retbeskrivelse
MANGLER: Avoid section, Factbox

VIGTIGT:
- Ret kun hvad der er objektivt forkert. Hvis forfatterens stil-valg er anderledes
  end dit, bevar forfatterens valg medmindre det er en åbenlys regel-overtrædelse.
- Lad være med at omskrive hele afsnit. Lav minimum nødvendige ændringer.
- Bevar artikelens stemme og struktur. Du er korrekturlæser, ikke ghostwriter.
KORR;
    }

    // English version (for traveltalk.travel, worldsporttalk, think_smarter)
    return <<<KORR
You are a senior English-language proofreader for Leisure Media Group. Readers
trust us to publish precise, idiomatic English — not machine-translated, not
invented, not embarrassing.

Your task: read the article and fix the following error categories. Return the
corrected article in the same Gutenberg block markup format as input, followed
by one status line.

═══════════════════════════════════════════════════════════════════════════
1. LANGUAGE ERRORS — ZERO TOLERANCE
═══════════════════════════════════════════════════════════════════════════

A) Invented words / non-standard compounds
   - Every English word must exist in standard dictionaries
   - Don't accept made-up compound forms

B) Incomplete comparatives and superlatives
   - "the only month" REQUIRES "for what?"
   - "the best" REQUIRES "at what" or "in what category"
   - "the most visited" REQUIRES reference (by whom, when)

C) Translation tells
   - Phrases that read like direct translations from Danish/German/French
   - Awkward word order
   - Calques

D) Grammar
   - Subject-verb agreement
   - Article use (a/an/the)
   - Verb tense consistency
   - Comma placement

═══════════════════════════════════════════════════════════════════════════
2. STRUCTURAL ERRORS — STANDARD IS MANDATORY
═══════════════════════════════════════════════════════════════════════════

Check these sections present in this order (per Editorial Production Standard, doc 14):
1.  Standfirst (italics, class *-standfirst)
2.  Advisory chip (class *-advisory-chip)
3.  Opening narrative (2 paragraphs typically)
4.  Body with H3 headings (min 4-6, never fewer than 1 per 200-250 words)
5.  Avoid section
6.  Nordic Box (group block, class *-nordic-box) — TravelTalk + WineTalk only
7.  Factbox
8.  leisuretalk.net cross-link
9.  Advisory tags bottom
10. Copyright line

If a mandatory section is MISSING, flag clearly in the status line.
Don't add it yourself — that's the writer's responsibility. Just flag.

═══════════════════════════════════════════════════════════════════════════
3. VOICE ERRORS — FIX INLINE
═══════════════════════════════════════════════════════════════════════════

A) Forbidden vocabulary (drop and rephrase):
   "discerning traveller", "exclusive experience" (as flattery), "bucket list",
   "hidden gem", "must-see", "breathtaking", "awe-inspiring", "magnificent",
   "world-renowned", "boasts", "nestled"

B) Snobbery traps (drop):
   "for those who can afford it", "priced for the discerning"

C) Hedge constructions (take the position or remove):
   "It is worth considering...", "Many travelers find...", "One might say..."

D) Missing concreteness:
   - "A good hotel" → name the hotel with precise location
   - "Delicious food" → name the dish
   - Vague time ("several days") → specific number ("three days")

═══════════════════════════════════════════════════════════════════════════
OUTPUT FORMAT
═══════════════════════════════════════════════════════════════════════════

Return the corrected article in the same Gutenberg format as input
(<!-- wp:paragraph -->, <!-- wp:heading -->, etc. — preserve all markup intact).

Preserve all quotes, names, numbers exactly as they were, UNLESS they are
obviously wrong (an invented hotel name, an incomplete comparative).

AFTER the article text, add one blank line, then this status line:

KORREKTUR-STATUS: [APPROVED | CORRECTED | REQUIRES REVISION]
CORRECTIONS: [short list of what you corrected, if anything]
MISSING: [list of missing sections, if any]

IMPORTANT:
- Only fix what is objectively wrong. If the writer's style choice differs from
  yours, preserve the writer's choice unless it's an obvious rule violation.
- Don't rewrite entire paragraphs. Make minimum necessary changes.
- Preserve the article's voice and structure. You are a proofreader, not a ghostwriter.
KORR;
}

/**
 * Run korrektur on an article.
 *
 * @param string $article_text  Raw Gutenberg article text from primary generation.
 * @param string $api_key       Claude API key.
 * @param string $site_id       Site ID for language selection.
 * @param string $model         Model to use (defaults to claude-opus-4-7).
 * @return array|WP_Error {
 *   'corrected_text' => string  (the article with corrections applied),
 *   'status'         => string  ('GODKENDT' | 'RETTET' | 'KRÆVER REVISION' | 'APPROVED' | 'CORRECTED' | 'REQUIRES REVISION'),
 *   'corrections'    => string  (notes on what was changed),
 *   'missing'        => string  (notes on missing sections),
 *   'raw_response'   => string  (full Claude response for debugging),
 * }
 */
/**
 * Run korrektur on a TITLE (typically post_title). Same engine, dedicated wrapper
 * with a tighter prompt — title is short, mostly needs language correctness check.
 *
 * Returns ['corrected' => string, 'changed' => bool, 'note' => string] or WP_Error.
 */
function li_korrektur_title($title, $api_key, $site_id = 'traveltalk_dk', $model = 'claude-opus-4-7') {
    if (empty($api_key)) return new WP_Error('li_korrektur_error', 'Claude API key not configured.');
    $title = trim((string) $title);
    if ($title === '') return ['corrected' => '', 'changed' => false, 'note' => 'empty title'];

    $is_danish = in_array($site_id, ['traveltalk_dk', 'winetalk_dk'], true);
    $sys = $is_danish
        ? "Du er senior dansk korrekturlæser. Læs en artikeltitel og ret SPROGFEJL: opfundne ord, ufuldstændige sammenligninger ('eneste måned' uden 'for hvad'), anglicismer, grammatik. BEVAR den oprindelige stil og længde mest muligt. Returner KUN den rettede titel på første linje, ingen forklaring, ingen anførselstegn.\n\nEksempler på fejl:\n- 'opslidet' findes ikke; 'uforstyrret' eller 'i fred' er det rigtige\n- 'september som eneste måned' er ufuldstændig; 'september er den eneste måned hvor X' er komplet\n\nHvis titlen er fejlfri, returner den uændret."
        : "You are a senior English-language proofreader. Read an article title and fix LANGUAGE ERRORS: invented words, incomplete comparatives ('the only month' without 'for what'), translation tells, grammar. PRESERVE the original style and length as much as possible. Return ONLY the corrected title on the first line, no explanation, no quotation marks.\n\nIf the title is error-free, return it unchanged.";

    $body = json_encode([
        'model' => $model,
        'max_tokens' => 200,
        'system' => $sys,
        'messages' => [['role' => 'user', 'content' => "Titel: $title"]],
    ]);
    $response = wp_remote_post('https://api.anthropic.com/v1/messages', [
        'timeout' => 60,
        'headers' => [
            'Content-Type' => 'application/json',
            'x-api-key' => $api_key,
            'anthropic-version' => '2023-06-01',
        ],
        'body' => $body,
    ]);
    if (is_wp_error($response)) return $response;
    $code = wp_remote_retrieve_response_code($response);
    $decoded = json_decode(wp_remote_retrieve_body($response), true);
    if ($code !== 200) {
        return new WP_Error('li_korrektur_error', "HTTP $code: " . ($decoded['error']['message'] ?? ''));
    }
    $raw = trim($decoded['content'][0]['text'] ?? '');
    // Strip surrounding quotes if Claude added them anyway
    $raw = trim($raw, " \"'");
    // Take first line only
    $corrected = trim(strtok($raw, "\n"));
    if ($corrected === '') $corrected = $title;
    return [
        'corrected' => $corrected,
        'changed' => $corrected !== $title,
        'note' => $corrected !== $title ? 'title corrected' : 'title approved as-is',
    ];
}

function li_korrektur_article($article_text, $api_key, $site_id = 'traveltalk_dk', $model = 'claude-opus-4-7') {
    if (empty($api_key)) {
        return new WP_Error('li_korrektur_error', 'Claude API key not configured for korrektur.');
    }

    $system = get_korrektur_prompt($site_id);

    $body = json_encode([
        'model'      => $model,
        'max_tokens' => 8000,  // Article + corrections can be long
        'system'     => $system,
        'messages'   => [
            ['role' => 'user', 'content' => "Læs og ret følgende artikel:\n\n" . $article_text],
        ],
    ]);

    $response = wp_remote_post('https://api.anthropic.com/v1/messages', [
        'timeout' => 120,
        'headers' => [
            'Content-Type'      => 'application/json',
            'x-api-key'         => $api_key,
            'anthropic-version' => '2023-06-01',
        ],
        'body' => $body,
    ]);

    if (is_wp_error($response)) {
        return new WP_Error('li_korrektur_error', 'Claude API failed: ' . $response->get_error_message());
    }

    $code    = wp_remote_retrieve_response_code($response);
    $decoded = json_decode(wp_remote_retrieve_body($response), true);

    if ($code !== 200) {
        $msg = $decoded['error']['message'] ?? wp_remote_retrieve_body($response);
        return new WP_Error('li_korrektur_error', "Claude API HTTP {$code}: {$msg}");
    }

    $raw = trim($decoded['content'][0]['text'] ?? '');
    if (empty($raw)) {
        return new WP_Error('li_korrektur_error', 'Korrektur returned empty content.');
    }

    // Parse status block at end
    $status = 'UNKNOWN';
    $corrections = '';
    $missing = '';
    $corrected_text = $raw;

    if (preg_match('/(?:^|\n)KORREKTUR-STATUS:\s*([^\n]+)/m', $raw, $sm)) {
        $status = trim($sm[1]);
        // Extract everything before the KORREKTUR-STATUS line as corrected text
        $status_pos = strrpos($raw, 'KORREKTUR-STATUS:');
        $corrected_text = trim(substr($raw, 0, $status_pos));
    }
    if (preg_match('/(?:^|\n)(?:RETTELSER|CORRECTIONS):\s*([^\n]+)/m', $raw, $cm)) {
        $corrections = trim($cm[1]);
    }
    if (preg_match('/(?:^|\n)(?:MANGLER|MISSING):\s*([^\n]+)/m', $raw, $mm)) {
        $missing = trim($mm[1]);
    }

    return [
        'corrected_text' => $corrected_text,
        'status'         => $status,
        'corrections'    => $corrections,
        'missing'        => $missing,
        'raw_response'   => $raw,
    ];
}
