<?php
if (!defined('ABSPATH')) exit;

/**
 * LI_Alerts — plugin-native, top-relevance-only notifications (G 2026-07-19).
 *
 * Replaces the old weekly delete-list email. Fires ONLY when LeisureIntel finds
 * something genuinely worth acting on (e.g. an analysis idea scoring >= THRESHOLD).
 * Surfaced FROM THE PLUGIN ITSELF: a count badge in the admin bar + a dismissible
 * panel on the LeisureIntel page. Never an email, never a content-editor popup.
 */
class LI_Alerts {

    const OPTION    = 'li_alerts';
    const THRESHOLD = 9;      // an idea must score >= this (out of 10) to be "top relevance"
    const CAP       = 50;     // keep at most this many alerts

    public static function init() {
        add_action('admin_bar_menu', [__CLASS__, 'admin_bar_badge'], 90);
        add_action('admin_notices',  [__CLASS__, 'panel']);
        add_action('wp_ajax_li_alerts_seen',    [__CLASS__, 'ajax_mark_seen']);
        add_action('wp_ajax_li_alert_partners', [__CLASS__, 'ajax_partners']);
        // Cadence check moved to LI_Cadence (universal cross-site monitor) — no per-site check here.
    }

    /** Add one alert. Deduped by (type|key). Newest first. */
    public static function push($type, $title, $detail = '', $score = null, $url = '') {
        $key    = md5($type . '|' . $title);
        $alerts = get_option(self::OPTION, []);
        if (!is_array($alerts)) $alerts = [];
        foreach ($alerts as $a) { if (($a['key'] ?? '') === $key) return; } // already alerted
        array_unshift($alerts, [
            'key'     => $key,
            'type'    => $type,
            'title'   => $title,
            'detail'  => $detail,
            'score'   => $score,
            'url'     => $url,
            'created' => current_time('mysql'),
            'seen'    => false,
        ]);
        update_option(self::OPTION, array_slice($alerts, 0, self::CAP));
    }

    /** Scan the stored Idébank for top-relevance ideas and raise alerts. Idempotent (dedup). */
    public static function scan_ideabank() {
        $ideas = get_option('li_ideas', []);
        if (!is_array($ideas)) return 0;
        // li_ideas may be grouped or a flat list of runs; walk recursively for idea-shaped arrays.
        $raised = 0;
        $walk = function($node) use (&$walk, &$raised) {
            if (!is_array($node)) return;
            if (isset($node['title']) && isset($node['confidence'])) {
                if ((int)$node['confidence'] >= self::THRESHOLD) {
                    $before = count(get_option(self::OPTION, []) ?: []);
                    self::push(
                        'idea',
                        $node['title'],
                        trim(($node['angle'] ?? '') . (!empty($node['target_keyword']) ? ' · ' . $node['target_keyword'] : '')),
                        (int)$node['confidence']
                    );
                    if (count(get_option(self::OPTION, []) ?: []) > $before) $raised++;
                }
                return;
            }
            foreach ($node as $child) $walk($child);
        };
        $walk($ideas);
        return $raised;
    }

    public static function count_unseen() {
        $alerts = get_option(self::OPTION, []);
        if (!is_array($alerts)) return 0;
        return count(array_filter($alerts, function($a){ return empty($a['seen']); }));
    }

    public static function mark_all_seen() {
        $alerts = get_option(self::OPTION, []);
        if (!is_array($alerts)) return;
        foreach ($alerts as &$a) $a['seen'] = true;
        unset($a);
        update_option(self::OPTION, $alerts);
    }

    /** Admin-bar badge — always visible to admins; count of unseen top-relevance finds. */
    public static function admin_bar_badge($bar) {
        if (!current_user_can('manage_options')) return;
        $n     = self::count_unseen();
        $color = $n ? '#d63638' : '#8c8f94';
        $label = 'LeisureIntel' . ($n ? " <span style=\"background:$color;color:#fff;border-radius:9px;padding:1px 7px;font-size:11px;margin-left:4px;\">$n</span>" : '');
        $bar->add_node([
            'id'    => 'li-alerts',
            'title' => $label,
            'href'  => admin_url('admin.php?page=leisureintel'),
            'meta'  => ['title' => $n ? "$n nye indsigter af top-relevans" : 'LeisureIntel — ingen nye indsigter'],
        ]);
    }

    /** Dismissible panel — only on the LeisureIntel admin page, only if there are unseen alerts. */
    public static function panel() {
        if (!current_user_can('manage_options')) return;
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || strpos((string)$screen->id, 'leisureintel') === false) return;

        $alerts = array_filter((array) get_option(self::OPTION, []), function($a){ return empty($a['seen']); });
        if (empty($alerts)) return;

        $nonce  = wp_create_nonce('li_alerts_seen');
        $pnonce = wp_create_nonce('li_alert_partners');
        echo '<div class="notice notice-info" style="border-left-color:#2271b1;padding:12px 14px;">';
        echo '<p style="margin:0 0 8px;"><strong>&#9873; LeisureIntel — ' . count($alerts) . ' ny(e) indsigt(er) af top-relevans</strong></p>';
        echo '<ul style="margin:0 0 8px 4px;list-style:none;padding:0;">';
        foreach (array_slice($alerts, 0, 8) as $a) {
            $score = isset($a['score']) ? ' <span style="color:#1a7f37;font-weight:600;">(' . (int)$a['score'] . '/10)</span>' : '';
            echo '<li style="margin:6px 0;padding:6px 0;border-top:1px solid #f0f0f1;">';
            echo '<strong>&#8226; ' . esc_html($a['title']) . '</strong>' . $score;
            if (!empty($a['detail'])) echo '<br><span style="color:#646970;font-size:12px;">' . esc_html($a['detail']) . '</span>';
            // Partner search only makes sense for content topics — operational alerts (cadence/stagnation, flow) have no topic.
            if (!in_array($a['type'] ?? '', ['cadence', 'flow'], true)) {
                echo ' <button type="button" class="button button-small li-alert-partners" style="margin-left:6px;" '
                   . 'data-topic="' . esc_attr($a['title']) . '" data-nonce="' . esc_attr($pnonce) . '">&#129309; Find partnere</button>';
                echo '<div class="li-partners-out" style="margin:6px 0 0;"></div>';
            }
            echo '</li>';
        }
        echo '</ul>';
        echo '<button type="button" class="button button-small" id="li-alerts-seen" data-nonce="' . esc_attr($nonce) . '">Marker som set</button>';
        ?>
        <script>(function($){
            $("#li-alerts-seen").on("click",function(){var b=$(this);b.prop("disabled",true);
                $.post(ajaxurl,{action:"li_alerts_seen",nonce:b.data("nonce")},function(){b.closest(".notice").slideUp();});});
            $(".li-alert-partners").on("click",function(){
                var b=$(this), out=b.next(".li-partners-out");
                b.prop("disabled",true).text("Finder partnere…");
                $.post(ajaxurl,{action:"li_alert_partners",nonce:b.data("nonce"),topic:b.data("topic")},function(r){
                    b.hide();
                    if(!r.success){ out.html("<em style='color:#d63638;'>"+((r.data&&r.data.message)||"Kunne ikke hente partnere")+"</em>"); return; }
                    var ps=(r.data&&r.data.partners)||[], h="";
                    if(!ps.length){ out.html("<em style='color:#646970;'>Ingen oplagte partnere for dette emne.</em>"); return; }
                    ps.forEach(function(p){
                        h+="<div style='background:#fff;border:1px solid #e0e0e0;border-radius:6px;padding:8px 10px;margin:5px 0;'>";
                        h+="<strong>"+(p.name||"")+"</strong> <span style='color:#646970;font-size:12px;'>"+(p.type||"")+(p.country?" · "+p.country:"")+(p.relevance?" · "+p.relevance+"/10":"")+"</span>";
                        if(p.relate_url) h+=" <a href='"+p.relate_url+"' target='_blank' rel='noopener' style='font-size:12px;text-decoration:none;white-space:nowrap;'>&#8599;&#65039; Åbn i Relate</a>";
                        if(p.why) h+="<br><span style='font-size:12px;'>"+p.why+"</span>";
                        if(p.pitch) h+="<br><span style='font-size:12px;'>&#128202; <strong>Data:</strong> "+p.pitch+"</span>";
                        if(p.inspiration) h+="<br><span style='font-size:12px;'>&#10024; <strong>Krog:</strong> "+p.inspiration+"</span>";
                        h+="</div>";
                    });
                    out.html(h);
                }).fail(function(){ b.prop("disabled",false).text("🤝 Find partnere"); out.html("<em style='color:#d63638;'>Netværksfejl — prøv igen.</em>"); });
            });
        })(jQuery);</script>
        <?php
        echo '</div>';
    }

    public static function ajax_mark_seen() {
        check_ajax_referer('li_alerts_seen', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error();
        self::mark_all_seen();
        wp_send_json_success();
    }

    /**
     * Underpublishing warning (G 2026-07-19): a quiet site is a bad Google signal ("lifted finger on/off").
     * Fires a badge alert when the last 7 days' publish count is below the cadence floor. Once per ISO week
     * (title carries the week → weekly re-warn, not daily spam); a daily transient caps the DB cost.
     */
    public static function check_cadence() {
        if (!current_user_can('manage_options')) return;
        if (get_transient('li_cadence_checked')) return;
        set_transient('li_cadence_checked', 1, DAY_IN_SECONDS);
        $floor = (int) get_option('li_cadence_floor_weekly', 2);
        if ($floor <= 0) return;
        global $wpdb;
        $since = date('Y-m-d H:i:s', strtotime('-7 days'));
        $types = post_type_exists('lmgt_translation') ? "'post','lmgt_translation'" : "'post'"; // 3.7.1: translations count
        $n = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type IN ($types) AND post_status='publish' AND post_date > %s", $since));
        if ($n < $floor) {
            $week = date('o-\uW'); // e.g. 2026-u30
            self::push('cadence',
                "Underpublicering ({$week}): {$n} af {$floor} udgivet de sidste 7 dage",
                'Publicér mere for at holde rytmen — Google køler af på stille sites. Nyt fra Idébanken.',
                null);
        }
    }

    /** Partner hook — an insight arrives WITH its outreach hook (databased + inspirational). */
    public static function ajax_partners() {
        check_ajax_referer('li_alert_partners', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Adgang nægtet.']);
        $topic = isset($_POST['topic']) ? sanitize_text_field(wp_unslash($_POST['topic'])) : '';
        if ($topic === '' || !class_exists('LI_Claude')) wp_send_json_error(['message' => 'Mangler emne.']);
        $res = (new LI_Claude())->get_topic_partners($topic);
        if (is_wp_error($res)) wp_send_json_error(['message' => $res->get_error_message()]);
        // Step 2 (G 2026-07-19): deep-link each partner into LeisureRelate's Master Base
        // (hub URL from the satellite config). One click from a suggestion to working it in the CRM.
        $hub = '';
        $s = get_option('lrs_settings', []);
        if (is_array($s) && !empty($s['hub_url'])) $hub = rtrim($s['hub_url'], '/');
        $partners = $res['partners'] ?? [];
        foreach ($partners as &$p) {
            $p['relate_url'] = ($hub && !empty($p['name']))
                ? $hub . '/wp-admin/admin.php?page=lr-master&lr_find=' . rawurlencode($p['name'])
                : '';
        }
        unset($p);
        wp_send_json_success(['partners' => $partners]);
    }
}
