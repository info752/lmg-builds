<?php
if (!defined('ABSPATH')) exit;

/**
 * LI_Cadence — universal cross-site publishing-rhythm monitor (G 2026-07-19).
 * "Standing still is losing, because the field grows." One place watches every content site's
 * 7-day publish count (via its public WP REST API — no per-site install) against a floor, and
 * raises ONE consolidated stagnation alert when any site goes quiet. Replaces the per-site check.
 */
class LI_Cadence {

    // Content sites + weekly floors. Holding/utility sites (leisuretalk, vacation-talk, deals) are omitted — no warn.
    const SITES = [
        ['url' => 'https://www.traveltalk.dk',    'name' => 'traveltalk.dk',      'floor' => 2],
        ['url' => 'https://traveltalk.travel',    'name' => 'traveltalk.travel',  'floor' => 3],
        ['url' => 'https://www.winetalk.dk',      'name' => 'winetalk.dk',        'floor' => 2],
        ['url' => 'https://worldsporttalk.com',   'name' => 'worldsporttalk.com', 'floor' => 3],
        ['url' => 'https://think-smarter.net',    'name' => 'think-smarter.net',  'floor' => 1],
    ];

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'menu'], 21);
        add_action('admin_init', [__CLASS__, 'check']);
        add_action('wp_ajax_li_cadence_refresh', [__CLASS__, 'ajax_refresh']);
    }

    public static function menu() {
        add_submenu_page('leisureintel', 'Publiceringsrytme', 'Publiceringsrytme', 'manage_options', 'li-cadence', [__CLASS__, 'render']);
    }

    /** Poll each site's public REST API for posts published in the last 7 & 30 days. Cached 6h. */
    public static function poll($force = false) {
        if (!$force) { $c = get_transient('li_cadence_cross_v2'); if ($c !== false) return $c; }
        $since7  = gmdate('Y-m-d\T00:00:00', time() - 7 * DAY_IN_SECONDS);
        $since30 = gmdate('Y-m-d\T00:00:00', time() - 30 * DAY_IN_SECONDS);
        $out = [];
        foreach (self::SITES as $s) {
            $out[] = [
                'name'  => $s['name'],
                'floor' => $s['floor'],
                'c7'    => self::count($s['url'], $since7),
                'c30'   => self::count($s['url'], $since30),
            ];
        }
        set_transient('li_cadence_cross_v2', $out, 6 * HOUR_IN_SECONDS);
        return $out;
    }

    /** 3.7.1: posts + LMG Translator translations (a site without Translator answers 404 there and adds 0). */
    private static function count($base, $since) {
        $posts = self::count_type($base, 'posts', $since);
        if ($posts === null) return null;
        return $posts + (int) self::count_type($base, 'lmgt_translation', $since);
    }

    private static function count_type($base, $route, $since) {
        $r = wp_remote_get($base . '/wp-json/wp/v2/' . $route . '?after=' . rawurlencode($since) . '&per_page=1', ['timeout' => 15]);
        if (is_wp_error($r) || (int) wp_remote_retrieve_response_code($r) !== 200) return null;
        $t = wp_remote_retrieve_header($r, 'x-wp-total');
        return $t === '' ? null : (int) $t;
    }

    /** Raise ONE consolidated stagnation alert when any content site is under its 7-day floor. */
    public static function check() {
        if (!current_user_can('manage_options')) return;
        if (get_transient('li_cadence_checked')) return;
        set_transient('li_cadence_checked', 1, DAY_IN_SECONDS);
        $under = array_filter(self::poll(), function ($x) { return $x['c7'] !== null && $x['c7'] < $x['floor']; });
        if ($under && class_exists('LI_Alerts')) {
            $list = implode(', ', array_map(function ($x) { return "{$x['name']} ({$x['c7']}/{$x['floor']})"; }, $under));
            $week = gmdate('o-\uW');
            LI_Alerts::push('cadence',
                "Stagnations-varsel ({$week}): " . count($under) . " sites under gulvet",
                "Under gulvet de sidste 7 dage: {$list}. Stilstand = tilbagegang når andre vokser — publicér.",
                null);
        }
    }

    public static function ajax_refresh() {
        check_ajax_referer('li_cadence', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error();
        wp_send_json_success(self::poll(true));
    }

    public static function render() {
        $rows = self::poll();
        $nonce = wp_create_nonce('li_cadence');
        echo '<div class="wrap"><h1>Publiceringsrytme — alle sites</h1>';
        echo '<p><em>Stilstand er tilbagegang, når feltet vokser.</em> Grøn = på/over gulvet de sidste 7 dage, rød = under. Tallene tæller både indlæg og oversættelser.</p>';
        echo '<table class="widefat striped" style="max-width:640px;"><thead><tr><th>Site</th><th>7 dage</th><th>Gulv/uge</th><th>30 dage</th><th>Status</th></tr></thead><tbody>';
        foreach ($rows as $r) {
            $under = ($r['c7'] !== null && $r['c7'] < $r['floor']);
            $c7 = $r['c7'] === null ? '—' : $r['c7'];
            $color = $under ? '#d63638' : '#1a7f37';
            $label = $r['c7'] === null ? 'ukendt' : ($under ? 'UNDER' : 'OK');
            echo '<tr><td><strong>' . esc_html($r['name']) . '</strong></td>'
               . '<td style="color:' . $color . ';font-weight:600;">' . esc_html($c7) . '</td>'
               . '<td>' . (int) $r['floor'] . '</td>'
               . '<td>' . ($r['c30'] === null ? '—' : (int) $r['c30']) . '</td>'
               . '<td style="color:' . $color . ';font-weight:600;">' . $label . '</td></tr>';
        }
        echo '</tbody></table>';
        echo '<p><button class="button" id="li-cad-refresh" data-nonce="' . esc_attr($nonce) . '">Opdatér nu</button></p>';
        echo '<script>(function($){$("#li-cad-refresh").on("click",function(){var b=$(this);b.prop("disabled",true).text("Opdaterer…");$.post(ajaxurl,{action:"li_cadence_refresh",nonce:b.data("nonce")},function(){location.reload();});});})(jQuery);</script>';
        echo '</div>';
    }
}
