<?php
if (!defined('ABSPATH')) exit;

/**
 * LeisureIntel — Hub-recommender ("Hub-forslag").
 *
 * Turns the tables on hub-building: instead of brute-forcing empty hubs, it ranks
 * which hubs are worth building next.
 *   candidate = a topic (category) with DEPTH (≥ MIN_SPOKES posts) + DEMAND (GSC
 *   impressions) but NO finished hub yet (no pillar, or a thin hub page).
 * Ranked by demand × depth. Reader-fit is implied (we already have content in the
 * topic); PARTNER-fit is checked per row (who identifies with how we think) via
 * the topic-partner engine. Scores against the per-site aim in 03_site_north_stars.md.
 */
class LI_HubRecommender {

    const MIN_SPOKES = 8;      // depth floor to warrant a hub
    const HUB_MIN_WORDS = 800; // a hub page below this doesn't count as "built"

    public static function boot() {
        add_action('wp_ajax_li_hubreco',          [__CLASS__, 'ajax']);
        add_action('wp_ajax_li_hubreco_partners', [__CLASS__, 'ajax_partners']);
    }

    public static function ajax() {
        check_ajax_referer('li_hubreco', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Ingen adgang']);
        wp_send_json_success(['html' => self::report_html()]);
    }

    public static function ajax_partners() {
        check_ajax_referer('li_hubreco', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Ingen adgang']);
        $topic = sanitize_text_field(wp_unslash($_POST['topic'] ?? ''));
        if ($topic === '') wp_send_json_error(['message' => 'Intet emne']);
        $res = (new LI_Claude())->get_topic_partners($topic);
        if (is_wp_error($res)) wp_send_json_error(['message' => $res->get_error_message()]);
        $names = [];
        foreach (($res['partners'] ?? []) as $p) {
            $names[] = ($p['name'] ?? '') . (empty($p['type']) ? '' : ' [' . $p['type'] . ']');
        }
        wp_send_json_success(['partners' => array_filter($names)]);
    }

    private static function report_html() {
        global $wpdb;
        $clusters = (new LI_Clusters())->get_cluster_data();
        if (!$clusters) return '<p><em>Ingen klyngedata — kør klyngeanalyse først.</em></p>';

        $cands = [];
        foreach ($clusters as $c) {
            $spokes = (int) ($c['post_count'] ?? 0);
            if ($spokes < self::MIN_SPOKES) continue;
            $cid  = (int) ($c['category_id'] ?? 0);
            $name = (string) ($c['category_name'] ?? '');
            if ($name === '') continue;

            $hub = self::find_hub_page($name);   // best matching hub PAGE (title-contains, pillar-preferred) | null
            $wc  = $hub ? $hub['wc'] : -1;
            $has_hub = ($hub && $wc >= self::HUB_MIN_WORDS);
            if ($has_hub) continue; // already built — a substantial matching hub page exists

            if ($wc < 0) {
                $status = 'INGEN hub-side fundet';
            } else {
                $mark = $hub['pillar_page'] ? '' : ' · ikke markeret som pillar';
                $status = $wc . ' ord — tynd hub, fyld op: "' . $hub['title'] . '"' . $mark;
            }
            $cands[] = [
                'name'   => $name,
                'spokes' => $spokes,
                'impr'   => (int) ($c['total_impressions'] ?? 0),
                'pv'     => (int) ($c['total_pageviews'] ?? 0),
                'status' => $status,
            ];
        }
        usort($cands, fn($a, $b) => ($b['impr'] <=> $a['impr']) ?: ($b['spokes'] <=> $a['spokes']));

        if (!$cands) return '<p>🎉 <em>Ingen bygge-kandidater — alle dybe emner har allerede en færdig hub.</em></p>';

        $rows = ''; $rank = 0;
        foreach ($cands as $c) {
            $rank++;
            $rows .= "<tr>"
                . "<td>{$rank}</td>"
                . "<td><strong>" . esc_html($c['name']) . "</strong></td>"
                . "<td><strong>{$c['impr']}</strong></td>"
                . "<td>{$c['pv']}</td>"
                . "<td>{$c['spokes']}</td>"
                . "<td style='font-size:12px;'>" . esc_html($c['status']) . "</td>"
                . "<td><button type='button' class='button button-small li-hubreco-p' data-topic='" . esc_attr($c['name']) . "'>Partner-fit?</button><span class='li-hubreco-out' style='display:block;font-size:12px;margin-top:4px;color:#555;'></span></td>"
                . "</tr>";
        }
        $h  = "<p>Bygge-kandidater: emner med <strong>indholdsdybde</strong> (≥" . self::MIN_SPOKES . " spokes) og <strong>søgeefterspørgsel</strong> (GSC-visninger), men <strong>uden en færdig hub</strong>. Rangeret efter efterspørgsel. Tjek <em>partner-fit</em> (hvem tænker som os) før du bygger.</p>";
        $h .= "<table class='widefat striped'><thead><tr><th>#</th><th>Emne (hub-kandidat)</th><th>Visninger (efterspørgsel)</th><th>GA4</th><th>Spokes</th><th>Hub-status</th><th>Partner-fit</th></tr></thead><tbody>{$rows}</tbody></table>";
        $h .= "<p class='description'>Score = efterspørgsel × dybde × gap. Reader-fit er givet (vi har allerede indhold i emnet). Byg de øverste <em>med aligned partnere</em> først — se 03_site_north_stars.md for site-mål + partner-arketyper.</p>";
        return $h;
    }

    /**
     * Find the best existing hub PAGE for a topic.
     * A hub's title is often richer than the bare category name ("Safari" → the page
     * "Safari i Afrika"), so exact-title matching gives false "INGEN hub" flags. Match by
     * title-contains, and rank: Rank Math pillar page first, then exact title, then
     * published, then wordier. Returns ['title','wc','pillar_page'] | null.
     */
    private static function find_hub_page($name) {
        global $wpdb;
        $like = '%' . $wpdb->esc_like($name) . '%';
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT p.ID, p.post_title, p.post_content, p.post_status,
                    (SELECT meta_value FROM {$wpdb->postmeta} m WHERE m.post_id=p.ID AND m.meta_key='rank_math_pillar_content' LIMIT 1) AS pillar
             FROM {$wpdb->posts} p
             WHERE p.post_type='page' AND p.post_status IN('publish','draft')
               AND (p.post_title=%s OR p.post_title LIKE %s)",
            $name, $like
        ));
        if (!$rows) return null;
        $best = null; $best_score = -1;
        foreach ($rows as $r) {
            $wc     = str_word_count(wp_strip_all_tags(strip_shortcodes($r->post_content)));
            $pillar = ($r->pillar === 'on') ? 1 : 0;
            $exact  = (mb_strtolower($r->post_title) === mb_strtolower($name)) ? 1 : 0;
            $pub    = ($r->post_status === 'publish') ? 1 : 0;
            $score  = $pillar * 100000 + $exact * 10000 + $pub * 1000 + min($wc, 999);
            if ($score > $best_score) {
                $best_score = $score;
                $best = ['title' => $r->post_title, 'wc' => $wc, 'pillar_page' => (bool)$pillar];
            }
        }
        return $best;
    }

    public static function render_pane() {
        $nonce = wp_create_nonce('li_hubreco');
        ?>
        <h2>Hub-forslag <span style="font-size:12px;color:#787c82;font-weight:normal;">— hvilke hubs bør vi bygge næst? Efterspørgsel × dybde × gap, med partner-fit. Ikke flere tomme hubs — kun de mest nødvendige.</span></h2>
        <p>
            <button id="li-hubreco-run" class="button button-primary" data-nonce="<?php echo esc_attr($nonce); ?>">Find hub-kandidater</button>
            <span id="li-hubreco-spin" style="display:none;color:#787c82;"><span class="spinner is-active" style="float:none;margin:0 6px 0 0;"></span> Beregner…</span>
        </p>
        <div id="li-hubreco-result" style="margin-top:12px;"></div>
        <script>
        (function(){
            var run = document.getElementById('li-hubreco-run'); if(!run) return;
            var nonce = run.getAttribute('data-nonce');
            run.addEventListener('click', function(){
                run.disabled=true; document.getElementById('li-hubreco-spin').style.display='inline';
                document.getElementById('li-hubreco-result').innerHTML='';
                var fd=new FormData(); fd.append('action','li_hubreco'); fd.append('nonce',nonce);
                fetch(ajaxurl,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();}).then(function(j){
                    run.disabled=false; document.getElementById('li-hubreco-spin').style.display='none';
                    document.getElementById('li-hubreco-result').innerHTML=(j&&j.success)?j.data.html:'<div class="notice notice-warning inline"><p>'+((j&&j.data&&j.data.message)||'Fejl')+'</p></div>';
                }).catch(function(){ run.disabled=false; document.getElementById('li-hubreco-spin').style.display='none'; document.getElementById('li-hubreco-result').innerHTML='<div class="notice notice-warning inline"><p>Netværksfejl.</p></div>'; });
            });
            // per-row partner-fit
            document.addEventListener('click', function(e){
                var b = e.target.closest ? e.target.closest('.li-hubreco-p') : null; if(!b) return;
                var out = b.parentNode.querySelector('.li-hubreco-out');
                b.disabled=true; var orig=b.textContent; b.textContent='Tænker…';
                var fd=new FormData(); fd.append('action','li_hubreco_partners'); fd.append('nonce',nonce); fd.append('topic',b.getAttribute('data-topic'));
                fetch(ajaxurl,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();}).then(function(j){
                    b.disabled=false; b.textContent=orig;
                    if(j&&j.success&&j.data.partners&&j.data.partners.length){ out.innerHTML='<strong>Aligned:</strong> '+j.data.partners.map(function(p){var s=document.createElement('span');s.textContent=p;return s.innerHTML;}).join(' · '); }
                    else { out.textContent=(j&&j.data&&j.data.message)||'ingen fundet'; }
                }).catch(function(){ b.disabled=false; b.textContent=orig; out.textContent='netværksfejl'; });
            });
            if(location.search.indexOf('li_active=hubreco')!==-1){ document.addEventListener('DOMContentLoaded',function(){ var t=document.querySelector('.li-tab-btn[data-tab="hubreco"]'); if(t)t.click(); }); }
        })();
        </script>
        <?php
    }
}
