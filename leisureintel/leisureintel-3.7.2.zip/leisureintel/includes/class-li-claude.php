<?php
if (!defined('ABSPATH')) exit;

class LI_Claude {

    private $api_key;
    private $model;
    private $api_url = 'https://api.anthropic.com/v1/messages';

    public function __construct() {
        $this->api_key = get_option('li_claude_api_key', '');
        $this->model   = get_option('li_claude_model', 'claude-haiku-4-5-20251001');
    }

    // -------------------------------------------------------------------------
    // Locale helpers
    // -------------------------------------------------------------------------

    private function get_locale() {
        return get_option('li_prompt_locale', 'da');
    }

    /** Target output-language name for the current locale (shared by prompt directives). */
    private function lang_name() {
        $map = [
            'da' => 'dansk',
            'sv' => 'svenska',
            'no' => 'norsk (bokmål)',
            'fi' => 'suomi (Finnish)',
            'en' => 'English',
        ];
        return $map[$this->get_locale()] ?? 'dansk';
    }

    private function get_output_language_instruction() {
        // English sites (traveltalk.travel) get an English instruction so output
        // never bleeds Danish — the prompt scaffolding stays Danish, output is English.
        if ($this->get_locale() === 'en') {
            return "Write ALL prose in natural, idiomatic, correctly-spelled English. Every word must be a real English word — no foreign words bleeding in, no invented or garbled words. Use each organisation's correct, real name (never invent or translate a company's name). JSON keys remain in English.\n\n";
        }
        $lang = $this->lang_name();
        return "Skriv ALLE tekstsvar i perfekt, native, korrekt stavet {$lang}. "
             . "Hvert eneste ord skal være et rigtigt {$lang} ord — ingen fremmedord der smutter ind (ingen tyske, svenske, norske eller engelske ord midt i en sætning), og ingen opfundne eller forvanskede ord. "
             . "Korrekt grammatik og stavning. Brug organisationers rigtige, officielle navn (opfind aldrig en oversættelse — fx FDM = Forenede Danske Motorejere, ikke en fransk eller engelsk version). "
             . "JSON-nøgler forbliver på engelsk.\n\n";
    }

    private function get_approved_agencies() {
        $locale = $this->get_locale();

        // Prefer live CPT data — falls back to hard-coded if CPT is empty
        $cpt = new LI_Partner_CPT();
        $live = $cpt->get_partners_for_locale($locale);
        if (!empty($live)) return $live;

        $all = [
            'da' => [
                ['name' => 'Lords Travel',       'domain' => 'lordstravel.dk',       'type' => 'travel_agency', 'note' => 'Luksus skræddersyede rejser siden 1986'],
                ['name' => 'Peacock Travel',      'domain' => 'peacocktravel.dk',     'type' => 'travel_agency', 'note' => 'Eksklusiv luksus, safari, F1, bryllup'],
                ['name' => 'Blixen Tours',        'domain' => 'blixentours.dk',       'type' => 'travel_agency', 'note' => 'Ren luksus safari + Indisk Ocean specialist'],
                ['name' => 'Abundance Travel',    'domain' => 'abundance-travel.dk',  'type' => 'travel_agency', 'note' => '30+ år, VIP adgang, eksklusivt'],
                ['name' => 'The Collection',      'domain' => 'the-collection.dk',    'type' => 'travel_agency', 'note' => 'Boutique, partner med Four Seasons, Aman, One&Only, Belmond'],
                ['name' => 'Voya Travel',         'domain' => 'voya.dk',              'type' => 'travel_agency', 'note' => 'Luksus du ikke kan finde andre steder, yachts og villas'],
                ['name' => 'BECH Travel',         'domain' => 'bechtravel.dk',        'type' => 'travel_agency', 'note' => 'Indisk Ocean specialist, Maldiverne, Mauritius'],
                ['name' => '80days',              'domain' => '80days.dk',            'type' => 'travel_agency', 'note' => 'Eksklusiv skræddersyet, par, familier, multi-generational'],
                ['name' => 'Livingstone Safari',  'domain' => 'livingstone.dk',       'type' => 'travel_agency', 'note' => 'Dansk-ejet, næsten 30 år bespoke Afrika safari'],
                ['name' => 'NYATI Safari',        'domain' => 'nyati-safari.dk',      'type' => 'travel_agency', 'note' => 'Ejer egne eksklusive lodges i Sydafrika'],
                ['name' => 'Panorama Travel',     'domain' => 'panoramatravel.dk',    'type' => 'travel_agency', 'note' => 'Eksotiske destinationer: Bhutan, Borneo, Namibia'],
                ['name' => 'Vilholdt Rejser',     'domain' => 'vilholdt.dk',          'type' => 'travel_agency', 'note' => 'Eneste dansk bureau med lokal operatørstatus på Island'],
                ['name' => 'Vores Afrika',        'domain' => 'voresafrika.dk',       'type' => 'travel_agency', 'note' => '100% dansk-ejet Afrika specialist, fuldt personaliseret'],
                ['name' => 'GG Tours',            'domain' => 'ggtours.dk',           'type' => 'travel_agency', 'note' => 'Luksus spa + resort, slotophold Skandinavien, gastronomi'],
                ['name' => 'Drømmerejser',        'domain' => 'drommerejser.dk',      'type' => 'travel_agency', 'note' => 'Skræddersyede kvalitetsrejser, 100+ samlet erfaring'],
                ['name' => 'Nyhavn Rejser',       'domain' => 'nyhavnrejser.dk',      'type' => 'travel_agency', 'note' => 'Dansk klassiker, premium rejser'],
                ['name' => 'Benns Rejser',        'domain' => 'benns.dk',             'type' => 'travel_agency', 'note' => 'Premium, stærk på fjernrejser'],
                ['name' => 'Topas Rejser',        'domain' => 'topas.dk',             'type' => 'travel_agency', 'note' => 'Kulturrejser og natur, oplevelsesfokus'],
                ['name' => 'Albatros Travel',     'domain' => 'albatros-travel.dk',   'type' => 'travel_agency', 'note' => 'Ekspeditioner og naturrejser, Arktis, Antarktis'],
                ['name' => 'Politiken Plus',      'domain' => 'politikenplus.dk',     'type' => 'travel_agency', 'note' => 'Kulturrejser, medieknyttet kvalitetspublikum'],
                ['name' => 'Risskov Rejser',      'domain' => 'risskovrejser.dk',     'type' => 'travel_agency', 'note' => 'Jysk premium bureau'],
                ['name' => 'Gislinge Rejser',     'domain' => 'gislingerejser.dk',    'type' => 'travel_agency', 'note' => 'Boutique, bespoke, skandinavisk fokus'],
            ],
            'sv' => [
                ['name' => 'Luxury Travel Sweden',              'domain' => 'luxurytravelsweden.com',  'type' => 'travel_agency', 'note' => 'Stockholm-baserat DMC, bespoke skräddarsydda resor, Lapland + arkipelag'],
                ['name' => 'Ecolyx',                           'domain' => 'ecolyx.com',               'type' => 'travel_agency', 'note' => 'Eco-lyx Skandinavien, handplockade boutique-lodges, privat guide-access'],
                ['name' => 'Invita Sweden',                    'domain' => 'invitasweden.com',          'type' => 'travel_agency', 'note' => 'Stockholm boutique DMC, arkipelag, incentive och high-end leisure'],
                ['name' => 'Best Served Scandinavia',          'domain' => 'best-served.co.uk',        'type' => 'travel_agency', 'note' => 'Virtuoso-affilierad, skräddarsydda Norden-resor, stark på Lapland + norrsken'],
                ['name' => 'Nordic Visitor Sweden',            'domain' => 'sweden.nordicvisitor.com', 'type' => 'travel_agency', 'note' => 'Personlig 1-till-1 service, FIT självkörning + guidade resor'],
                ['name' => 'The Luxury Arctic Travel Company', 'domain' => 'theluxuryarctictravelcompany.com', 'type' => 'travel_agency', 'note' => 'Premium Arktis: Abisko, Icehotel, Lapland'],
                ['name' => 'Authentic Scandinavia',            'domain' => 'authentic-scandinavia.com','type' => 'travel_agency', 'note' => 'Premium FIT Skandinavien, stark på naturresor'],
                ['name' => '50 Degrees North',                 'domain' => 'fiftydegreesnorth.com',    'type' => 'travel_agency', 'note' => 'B Corp, Virtuoso-listad, Norge + Sverige + Finland, max 18 pers grupper'],
                ['name' => 'Off The Map Travel',               'domain' => 'offthemap.travel',         'type' => 'travel_agency', 'note' => '15+ år Nordic expertise, UK boutique med skandinavisk fokus'],
                ['name' => 'Ker & Downey',                     'domain' => 'kerdowney.com',            'type' => 'travel_agency', 'note' => 'US lyxoperatör, kurerat Skandinavien-program'],
                ['name' => 'Inlandsbanan AB',                  'domain' => 'res.inlandsbanan.se',      'type' => 'train',         'note' => 'Direktoperatör 1 288 km järnväg Kristinehamn–Gällivare, egna hotellpaket'],
                ['name' => 'Great Rail Journeys',              'domain' => 'greatrail.com',            'type' => 'train',         'note' => 'Escorterade tågresor, dedikerade Inlandsbanan-turer, premium smågrupp'],
                ['name' => 'Tailor Made Rail',                 'domain' => 'tailormaderail.com',       'type' => 'train',         'note' => 'Bespoke tåg-itinerarium, Sverige + bredare Skandinavien'],
                ['name' => 'Railbookers',                      'domain' => 'railbookers.com',          'type' => 'train',         'note' => 'Point-to-point tågresor, Stockholm + Lapland-rutter'],
                ['name' => 'Sailing Sweden',                   'domain' => 'sailingsweden.com',        'type' => 'cruise',        'note' => 'Privata besättningscharters i Stockholms skärgård, lyxbåtar'],
                ['name' => 'XperienceSweden',                  'domain' => 'xperiencesweden.com',      'type' => 'cruise',        'note' => 'Premium yachtcharter med gourmetmiddag, Stockholms skärgård'],
            ],
            'no' => [
                ['name' => '50 Degrees North',        'domain' => 'fiftydegreesnorth.com',    'type' => 'travel_agency', 'note' => 'Lillehammer-basert, B Corp, Virtuoso-listet, bespoke Norge + Skandinavien'],
                ['name' => 'Ecolyx',                  'domain' => 'ecolyx.com',               'type' => 'travel_agency', 'note' => 'Eco-luksus, håndplukkede boutique-lodges, sterk fjordportefølje'],
                ['name' => 'Expa Reiser',             'domain' => 'expareiser.no',            'type' => 'travel_agency', 'note' => 'Norsk boutique, skreddersydde reiser, aktiv + opplevelsesfokus'],
                ['name' => 'Get Norway Travel',       'domain' => 'getnorwaytravel.com',      'type' => 'travel_agency', 'note' => 'Oslo-basert boutique DMC, bespoke for internasjonale gjester'],
                ['name' => 'Authentic Scandinavia',   'domain' => 'authentic-scandinavia.com','type' => 'travel_agency', 'note' => 'Premium FIT, Oslo–Bergen + fjordkryss, elektrisk båt på Nærøyfjord'],
                ['name' => 'Nordiva Tours',           'domain' => 'nordivatours.com',         'type' => 'travel_agency', 'note' => 'Boutique Nord-Europa, bespoke itinerary-design for kresne reisende'],
                ['name' => 'Best Served Scandinavia', 'domain' => 'best-served.co.uk',        'type' => 'travel_agency', 'note' => 'Virtuoso-tilknyttet, skreddersydde Norden-reiser, sterk på fjorder + nordlys'],
                ['name' => 'Off The Map Travel',      'domain' => 'offthemap.travel',         'type' => 'travel_agency', 'note' => '15+ år Nordic expertise, UK boutique'],
                ['name' => 'Ker & Downey',            'domain' => 'kerdowney.com',            'type' => 'travel_agency', 'note' => 'US luksusoperatør, kurert Skandinavien-program'],
                ['name' => 'Norway Adventures',       'domain' => 'norway-adventures.com',    'type' => 'travel_agency', 'note' => 'Private luksusfjordturer, wellness + fjordopplevelse, boutique-lodges'],
                ['name' => 'Fjord Tours',             'domain' => 'fjordtours.com',           'type' => 'travel_agency', 'note' => 'Bergenbanen + Flåmsbana + Nærøyfjord, premium FIT-pakker'],
                ['name' => "Norway's Best",           'domain' => 'norwaysbest.com',          'type' => 'travel_agency', 'note' => 'Kurerte opplevelser, Flåmsbana-pakker, håndplukkede overnattingssteder'],
                ['name' => 'Hurtigruten',             'domain' => 'hurtigruten.com',          'type' => 'cruise',        'note' => 'Kystruten Bergen–Kirkenes, Signature premium all-inclusive tier'],
                ['name' => 'HX Hurtigruten Expeditions','domain' => 'travelhx.com',           'type' => 'cruise',        'note' => 'Ekspedisjonsprodukt, Svalbard + Arktis + Antarktis, eventyrluksus'],
                ['name' => 'Havila Kystruten',        'domain' => 'havilavoyages.com',        'type' => 'cruise',        'note' => 'Ny aktør 2021, identisk rute som Hurtigruten, nyere skip, batteri-hybrid'],
                ['name' => 'Railbookers',             'domain' => 'railbookers.com',          'type' => 'train',         'note' => 'Bergen + Flåm + Oslo pakker, Norway in a Nutshell'],
            ],
            'fi' => [
                ['name' => 'Aventura',                         'domain' => 'aventura.fi',              'type' => 'travel_agency', 'note' => 'Helsinki boutique, täysin yksilölliset luksusmatkaohjelmat, safarit + yksityissaaret'],
                ['name' => 'Private Skies',                    'domain' => 'privateskies.fi',          'type' => 'travel_agency', 'note' => 'Huipputason Helsinki-toimisto, yksityislentokoneet + helikopterit, exklusiiviset ryhmämatkat'],
                ['name' => 'Project Matka',                    'domain' => 'projectmatka.com',         'type' => 'travel_agency', 'note' => 'Suomalainen luksusmatkasuunnittelija, räätälöidyt matkat vaativille matkailijoille'],
                ['name' => 'JeeTravels',                       'domain' => 'jeetravels.com',           'type' => 'travel_agency', 'note' => 'Yksilölliset luksuspaketit, parit + perheet, ESQR-sertifioitu laatu 2025'],
                ['name' => 'Lapland Private',                  'domain' => 'laplandprivate.com',       'type' => 'travel_agency', 'note' => 'Rovaniemi DMC, arkkitehtisuunnitellut huviloita ja lasivilloja, Biosphere-sertifioitu'],
                ['name' => 'Lapland Luxury DMC',               'domain' => 'laplandluxury.com',        'type' => 'travel_agency', 'note' => 'Perheyritys 25+ vuotta, yksityishuvilat + kaikki sisältyvä Arktis, yksityiskokit'],
                ['name' => 'Arctra DMC',                       'domain' => 'arctradmc.fi',             'type' => 'travel_agency', 'note' => 'Rovaniemi Nordic Luxury DMC, yksityiset loma-asunnot syrjäisillä alueilla'],
                ['name' => 'Aurora Safaris',                   'domain' => 'aurorasafaris.com',        'type' => 'travel_agency', 'note' => 'Ainutlaatuiset Arktis-majoitukset: kelluva safiriyleiri, lasikattilakopit, outpost-lodge'],
                ['name' => 'Arctic GM',                        'domain' => 'arcticgm.com',             'type' => 'travel_agency', 'note' => 'Rovaniemi + Levi + Tromsø + Kiruna, Original Aurora Hunters, premium 4x4-kalusto'],
                ['name' => 'DMC Lapland',                      'domain' => 'dmclapland.fi',            'type' => 'travel_agency', 'note' => 'Omistettu Lappi-DMC, FIT + incentive-matkat, Rovaniemi-asiantuntija'],
                ['name' => 'Best Served Scandinavia',          'domain' => 'best-served.co.uk',        'type' => 'travel_agency', 'note' => 'Virtuoso-affilioitunut, räätälöidyt Pohjoismaat-matkat, vahva Lappi + revontulet'],
                ['name' => '50 Degrees North',                 'domain' => 'fiftydegreesnorth.com',    'type' => 'travel_agency', 'note' => 'B Corp, Virtuoso-listattu, kattaa Norja + Ruotsi + Suomi'],
                ['name' => 'The Luxury Arctic Travel Company', 'domain' => 'theluxuryarctictravelcompany.com', 'type' => 'travel_agency', 'note' => 'Premium Arktis: Suomi + Ruotsi + Norja Lappi'],
                ['name' => 'Ker & Downey',                     'domain' => 'kerdowney.com',            'type' => 'travel_agency', 'note' => 'US luksusoperaattori, kurattu Skandinavia-ohjelma'],
            ],
        ];

        return $all[$locale] ?? $all['da'];
    }

    private function get_exclude_brands() {
        $map = [
            'da' => 'Spies, Bravo Tours, Tjæreborg, TUI, Apollo, Ving',
            'sv' => 'Ving Sverige, Apollo Sverige, TUI Sverige (Fritidsresor), Solresor, Ticket, Sunwing',
            'no' => 'Ving Norge, Star Tour, Apollo Norge, Detur, Solia',
            'fi' => 'Aurinkomatkat, TUI Finland (Finnmatkat), Tjäreborg Finland, Detur Finland',
        ];
        return $map[$this->get_locale()] ?? $map['da'];
    }

    // -------------------------------------------------------------------------
    // Prompt builders
    // -------------------------------------------------------------------------

    /**
     * Build analysis prompt from enriched dataset.
     */
    public function build_prompt($dataset, $num_suggestions = 10, $site_description = '') {
        if (empty($site_description)) {
            $site_description = get_option('li_site_description', 'Danmarks ældste uafhængige digitale rejsemedie — luksus og oplevelsesrejser');
        }

        $content_list = '';
        foreach ($dataset as $i => $item) {
            $title    = !empty($item['title']) ? $item['title'] : '(ingen titel)';
            $cats     = !empty($item['categories']) ? $item['categories'] : 'ukendt';
            $pos      = $item['avg_position'] ?? 0;
            $clicks   = $item['total_clicks'] ?? 0;
            $impr     = $item['total_impressions'] ?? 0;
            $conf     = $item['confidence'] ?? '?';
            $momentum = $item['momentum'] ?? 0;
            $season   = $item['season_signal'] ?? '';
            $session  = isset($item['avg_session_duration']) ? $item['avg_session_duration'] . 's' : 'n/a';
            $bounce   = isset($item['bounce_rate']) ? $item['bounce_rate'] . '%' : 'n/a';

            $momentum_txt = '';
            if ($momentum > 1)       $momentum_txt = ' [STIGER +' . $momentum . ' positioner]';
            elseif ($momentum < -1)  $momentum_txt = ' [FALDER ' . $momentum . ' positioner]';

            $season_txt = match($season) {
                'trending'        => ' [TRENDING NU]',
                'seasonal_peak'   => ' [SÆSONSPIDS]',
                'seasonal_trough' => ' [SÆSONDAL]',
                default           => '',
            };

            $content_list .= ($i + 1) . ". {$title}{$momentum_txt}{$season_txt}\n";
            $content_list .= "   URL: {$item['page']}\n";
            $content_list .= "   Klik: {$clicks} | Visninger: {$impr} | Position: {$pos} | Score: {$conf}/10\n";
            $content_list .= "   GA4: {$session} session · {$bounce} bounce\n";
            $content_list .= "   Kategori: {$cats}\n\n";
        }

        // Load site editorial standards
        $site_id = get_option('li_site_id', 'traveltalk_dk');
        if (!function_exists('get_editorial_prompt')) {
            $standards_file = plugin_dir_path(__FILE__) . 'li-editorial-standards.php';
            if (file_exists($standards_file)) require_once $standards_file;
        }

        $prompt  = $this->get_output_language_instruction();
        if (function_exists('get_editorial_prompt')) {
            $prompt .= get_editorial_prompt($site_id) . "\n\n";
            $prompt .= "Du er content-strateg. Baseret på de redaktionelle standarder ovenfor, foreslå KUN emner der opfylder disse krav. Afvis alle idéer der falder i forbudte kategorier.\n\n";
        } else {
            $prompt .= "Du er content-strateg for {$site_description}.\n\n";
        }
        $prompt .= "TOP PERFORMING INDHOLD (30 dage, Google Search Console + GA4):\n\n";
        $prompt .= $content_list;
        $prompt .= "Score/10 er beregnet ud fra: positionsmomentum, CTR-gap vs. forventet, GA4-engagement og søgevolumen.\n";
        $prompt .= "TRENDING/SÆSONSPIDS = nu er tidspunktet at publicere. SÆSONDAL = planlæg til næste sæson.\n\n";
        $prompt .= "Foreslå {$num_suggestions} nye artikelideer. Prioritér sider med høj score og [STIGER]-signal.\n\n";
        $prompt .= "KRITISK: Dit svar skal KUN være et JSON-array. Ingen tekst før eller efter. Start med [ og slut med ].\n\n";
        $prompt .= "[\n  {\n";
        $prompt .= "    \"title\": \"Færdig artikeltitel\",\n";
        $prompt .= "    \"angle\": \"Hvorfor denne vinkel virker (1-2 sætninger)\",\n";
        $prompt .= "    \"structure\": [\"H2 forslag 1\", \"H2 forslag 2\", \"H2 forslag 3\", \"H2 forslag 4\"],\n";
        $prompt .= "    \"target_keyword\": \"primært søgeord\",\n";
        $prompt .= "    \"intent\": \"informational\",\n";
        $prompt .= "    \"inspired_by\": \"URL\",\n";
        $prompt .= "    \"confidence\": 8,\n";
        $prompt .= "    \"timing\": \"nu\" \n";
        $prompt .= "  }\n]\n";
        $prompt .= "\"timing\" er én af: \"nu\", \"næste_sæson\", \"evergreen\".\n";

        return $prompt;
    }

    /**
     * Call Claude API for content suggestions. Returns array or WP_Error.
     */
    public function get_suggestions($dataset, $num_suggestions = 10) {
        $prompt = $this->build_prompt($dataset, $num_suggestions);

        $decoded = $this->call_api($prompt, 4096, '[');
        if (is_wp_error($decoded)) return $decoded;

        $text = '[' . trim($decoded['content'][0]['text'] ?? '');
        return $this->parse_json_array($text);
    }

    /**
     * Build audit prompt for a batch of posts.
     */
    public function build_audit_prompt($posts) {
        $list = '';
        foreach ($posts as $i => $p) {
            $pos     = $p['position'] !== null ? $p['position'] : 'ingen data';
            $session = isset($p['avg_session']) ? round($p['avg_session']) . 's' : 'n/a';
            $bounce  = isset($p['bounce_rate']) ? $p['bounce_rate'] . '%' : 'n/a';
            $age     = $p['age_days'];

            $list .= ($i + 1) . ". [ID:{$p['post_id']}] {$p['title']}\n";
            $list .= "   Kategori: {$p['categories']} | Alder: {$age} dage\n";
            $list .= "   GSC: {$p['clicks']} klik · {$p['impressions']} visninger · pos {$pos}\n";
            $list .= "   GA4: {$p['pageviews']} sidevisninger · {$session} session · {$bounce} bounce\n\n";
        }

        $site_description = get_option('li_site_description', 'luksus rejsemedie');
        $prompt  = $this->get_output_language_instruction();
        $prompt .= "Du er redaktionel indholdsrådgiver for {$site_description}.\n\n";

        $prompt .= "FORSTÅ DETTE FØRST — det afgør alt:\n";
        $prompt .= "Sitet ligger i gennemsnit omkring position 75 i Google. Næsten ALLE indlæg har derfor få eller ingen klik — ikke fordi de er dårlige, men fordi hele sitets synlighed er undertrykt. MANGLENDE TRAFIK ER IKKE BEVIS FOR, AT ET INDLÆG ER DÅRLIGT. Emnet afgør; udførelsen kan altid forbedres. Din opgave er at REDDE og STYRKE indhold — ikke at rydde ud.\n\n";

        $prompt .= "KONCEPTET (bedøm efter dette, IKKE efter trafik):\n";
        $prompt .= "Eksperiential luksusrejse efter vores kvalitetsdefinition — inkl. sport, kultur, gastronomi og natur knyttet til et sted. IKKE charter, budget, masseturisme eller rent transaktionelt indhold.\n\n";

        $prompt .= "INDHOLDSREVISION — vurder hvert indlæg:\n\n";
        $prompt .= $list;

        $prompt .= "Klassificer hvert indlæg som ÉT af — altid med en konkret begrundelse:\n";
        $prompt .= "- behold: on-concept og har blivende (evergreen) værdi. STANDARDVALGET for alt, der passer til konceptet.\n";
        $prompt .= "- forbedring: godt, on-concept emne der er tyndt eller forældet. Dækker BÅDE at uddybe/opdatere OG at 'reframe' — omskrive en kedelig indpakning (fx en 'bliv klogere på…'-vinkel eller en forkert titel), mens substansen bevares. Slet ALDRIG et sådant indlæg — red det.\n";
        $prompt .= "- viderestil: ægte dublet af en STÆRKERE side — flet ind i den og omdiriger.\n";
        $prompt .= "- slet: KUN i tre tilfælde, og begrundelsen SKAL nævne hvilket: (1) off-concept (charter/budget/masse/rent transaktionelt), (2) ægte dublet uden unik værdi hvor en bedre tvilling allerede findes, (3) reelt ødelagt uden noget reddeligt indhold. ALDRIG 'slet' alene på grund af manglende trafik.\n\n";

        $prompt .= "VIGTIGE REGLER:\n";
        $prompt .= "- I tvivl → vælg forbedring eller behold, ALDRIG slet. Red altid først.\n";
        $prompt .= "- 'slet' skal være sjælden. Foreslår du at slette en stor andel af indlæggene, har du misforstået opgaven — det er et rødt flag, ikke en anbefaling.\n";
        $prompt .= "- Ingen masseoprydning. Hvert indlæg vurderes for sig med sin egen konkrete begrundelse.\n\n";

        $prompt .= "KRITISK: Svar KUN med JSON-array. Ingen tekst. Start med [ og slut med ].\n\n";
        $prompt .= "[\n  {\n    \"post_id\": 123,\n    \"action\": \"forbedring\",\n    \"reason\": \"Kort, konkret begrundelse (1 sætning)\"\n  }\n]\n";

        return $prompt;
    }

    /**
     * Get audit classifications from Claude for a batch of posts.
     */
    public function get_audit_classifications($posts) {
        $prompt  = $this->build_audit_prompt($posts);
        $decoded = $this->call_api($prompt, 2048, '[');
        if (is_wp_error($decoded)) return $decoded;

        $text = '[' . trim($decoded['content'][0]['text'] ?? '');
        return $this->parse_json_array($text);
    }

    /**
     * Persona Inference — infers current audience from GSC queries + clusters,
     * then builds structured target persona profile from user's description.
     * Uses Sonnet (writer model) for richer reasoning.
     */
    public function get_persona_inference($clusters, $queries, $primary_persona_desc) {
        $cluster_summary = '';
        foreach (array_slice($clusters, 0, 12) as $i => $c) {
            $tops = implode(', ', array_map(fn($p) => $p['title'], array_slice($c['top_posts'] ?? [], 0, 2)));
            $cluster_summary .= ($i + 1) . ". {$c['category_name']} (score {$c['cluster_score']}/10, {$c['total_clicks']} klik) — {$tops}\n";
        }

        $query_list = '';
        foreach (array_slice($queries, 0, 40) as $q) {
            $query_list .= "  \"{$q->query}\" ({$q->clicks} klik, pos " . round($q->avg_position, 1) . ")\n";
        }

        $prompt  = $this->get_output_language_instruction();
        $prompt .= "Du er publikums- og strategianalytiker for {$site_description}.\n\n";
        $prompt .= "SITEDATA — hvad folk faktisk søger og klikker på:\n";
        $prompt .= "Top søgeforespørgsler:\n{$query_list}\n";
        $prompt .= "Stærkeste indholdklynger:\n{$cluster_summary}\n";
        $prompt .= "REDAKTØRENS BESKRIVELSE AF MÅLGRUPPEN:\n\"{$primary_persona_desc}\"\n\n";
        $prompt .= "Baseret på søgedata og klyngedata: hvem ER den faktiske nuværende læser? Sammenlign med målgruppen.\n";
        $prompt .= "Byg BEGGE profiler ud med:\n";
        $prompt .= "- Hvem de er (mindset, værdier, livsfase)\n";
        $prompt .= "- Hvordan de rejser I DAG (frekvens, format, ledsagere, bookingadfærd)\n";
        $prompt .= "- Hvor de bruger rejsepengene (overnatning, oplevelser, transport, mad)\n";
        $prompt .= "- Adfærdsmæssige signaler (hvad antyder rejsemønstret om resten af deres liv)\n\n";
        $prompt .= "KRITISK: Svar KUN med JSON. Ingen tekst. Start med {, slut med }.\n\n";
        $prompt .= "{\n";
        $prompt .= "  \"persona_name\": \"Et godt navn til målgruppen (2-4 ord, {$this->lang_name()})\",\n";
        $prompt .= "  \"target_persona\": {\n";
        $prompt .= "    \"who\": \"Hvem er de — mindset og værdier\",\n";
        $prompt .= "    \"how_they_travel\": \"Hvordan rejser de i dag — format, frekvens, ledsagere\",\n";
        $prompt .= "    \"wallet\": [\"Overnatning: boutique hotels\", \"Oplevelser: private guides\", \"Transport: business class lejlighedsvist\"],\n";
        $prompt .= "    \"behavioral_signals\": [\"Kører sandsynligvis elbil\", \"Køber kvalitetsfødevarer\", \"Læser kvalitetsmedier\"]\n";
        $prompt .= "  },\n";
        $prompt .= "  \"current_audience\": {\n";
        $prompt .= "    \"who\": \"Hvem læser faktisk sitet nu — baseret på søgedata\",\n";
        $prompt .= "    \"how_they_travel\": \"Hvad søgedataene antyder om deres rejsemønster\",\n";
        $prompt .= "    \"wallet\": [\"Hvad de bruger penge på\"],\n";
        $prompt .= "    \"behavioral_signals\": [\"Adfærdssignaler baseret på søgemønstre\"]\n";
        $prompt .= "  },\n";
        $prompt .= "  \"alignment_score\": 7,\n";
        $prompt .= "  \"gap_analysis\": \"Hvad er forskellen mellem nuværende læser og målgruppen?\",\n";
        $prompt .= "  \"recommendation\": \"Konkret indholdsstrategisk anbefaling for at lukke gabet\"\n";
        $prompt .= "}\n";

        $writer_model = get_option('li_writer_model', 'claude-sonnet-4-6');
        // No prefill: the writer model (Sonnet 4.6) rejects assistant-message prefill.
        $decoded = $this->call_api($prompt, 3000, '', $writer_model);
        if (is_wp_error($decoded)) return $decoded;

        $text  = trim($decoded['content'][0]['text'] ?? '');
        $start = strpos($text, '{');
        $end   = strrpos($text, '}');
        $json  = ($start !== false && $end !== false && $end > $start) ? substr($text, $start, $end - $start + 1) : $text;
        $obj   = json_decode($json, true);
        if (!is_array($obj)) {
            return new WP_Error('li_parse_error', 'Invalid JSON in persona inference response.');
        }
        return $obj;
    }

    /**
     * Audience Resonance — scores each cluster against primary + comparison personas.
     * Returns array of per-cluster resonance scores.
     */
    public function get_audience_resonance($clusters, $primary_persona_desc, $comparison_personas) {
        $cluster_list = '';
        foreach ($clusters as $i => $c) {
            $tops = implode(', ', array_map(fn($p) => $p['title'], array_slice($c['top_posts'] ?? [], 0, 3)));
            $cluster_list .= ($i + 1) . ". {$c['category_name']} ({$c['post_count']} indlæg, {$c['total_clicks']} klik, score {$c['cluster_score']}/10)\n";
            if ($tops) $cluster_list .= "   Top: {$tops}\n";
        }

        $comp_list = '';
        foreach ($comparison_personas as $key => $desc) {
            $comp_list .= "- {$key}: {$desc}\n";
        }
        $comp_keys = array_keys($comparison_personas);

        $prompt  = $this->get_output_language_instruction();
        $prompt .= "Du er publikumsanalytiker. Vurder hvor godt hvert indholdklynge resonerer med hvert publikumssegment.\n\n";
        $prompt .= "PRIMÆR MÅLGRUPPE:\n\"{$primary_persona_desc}\"\n\n";
        $prompt .= "SAMMENLIGNINGSSEGMENTER:\n{$comp_list}\n";
        $prompt .= "KLYNGER:\n{$cluster_list}\n";
        $prompt .= "For hvert klynge: score 1-10 for primary fit og hvert sammenligningssegment.\n";
        $prompt .= "mismatch=true hvis primary_fit < 6 OG mindst ét sammenligningssegment scorer >= 6 (vi rammer forkert målgruppe).\n\n";
        $prompt .= "KRITISK: Svar KUN med JSON-array. Ingen tekst. Start med [, slut med ].\n\n";
        $prompt .= "[\n  {\n";
        $prompt .= "    \"cluster\": \"Kategorinavn\",\n";
        $prompt .= "    \"primary_fit\": 8,\n";
        $prompt .= "    \"primary_reason\": \"1 sætning\",\n";
        $prompt .= "    \"comparisons\": [\n";
        foreach ($comp_keys as $k) {
            $prompt .= "      {\"key\": \"{$k}\", \"score\": 3, \"reason\": \"1 sætning\"},\n";
        }
        $prompt .= "    ],\n";
        $prompt .= "    \"mismatch\": false,\n";
        $prompt .= "    \"mismatch_reason\": \"\"\n";
        $prompt .= "  }\n]\n";

        $decoded = $this->call_api($prompt, 3000, '[');
        if (is_wp_error($decoded)) return $decoded;

        $text = '[' . trim($decoded['content'][0]['text'] ?? '');
        $arr  = json_decode(substr($text, 0, strrpos($text, ']') + 1), true);
        if (!is_array($arr)) {
            return new WP_Error('li_parse_error', 'Invalid JSON in audience resonance response.');
        }
        return $arr;
    }

    /**
     * Shared Claude API call.
     */
    private function call_api($prompt, $max_tokens = 4096, $prefill = '', $model = null) {
        if (empty($this->api_key)) {
            return new WP_Error('li_api_error', 'Claude API key not configured.');
        }

        $messages = [['role' => 'user', 'content' => $prompt]];
        if ($prefill) {
            $messages[] = ['role' => 'assistant', 'content' => $prefill];
        }

        $body = json_encode([
            'model'      => $model ?? $this->model,
            'max_tokens' => $max_tokens,
            'system'     => 'You are a JSON API. Always respond with raw JSON only — no markdown, no code fences, no explanations, no text before or after. Start your response directly with { or [.',
            'messages'   => $messages,
        ]);

        $response = wp_remote_post($this->api_url, [
            'timeout' => 90,
            'headers' => [
                'Content-Type'      => 'application/json',
                'x-api-key'         => $this->api_key,
                'anthropic-version' => '2023-06-01',
            ],
            'body' => $body,
        ]);

        if (is_wp_error($response)) {
            return new WP_Error('li_api_error', 'Claude API request failed: ' . $response->get_error_message());
        }

        $code    = wp_remote_retrieve_response_code($response);
        $raw     = wp_remote_retrieve_body($response);
        $decoded = json_decode($raw, true);

        if ($code !== 200) {
            $msg = $decoded['error']['message'] ?? $raw;
            return new WP_Error('li_api_error', "Claude API HTTP {$code}: {$msg}");
        }

        if (empty($decoded['content'][0]['text'])) {
            return new WP_Error('li_parse_error', 'Empty response from Claude API.');
        }

        return $decoded;
    }

    /**
     * Extract and parse a JSON array from Claude's text response.
     */
    private function parse_json_array($text) {
        $start = strpos($text, '[');
        $end   = strrpos($text, ']');

        if ($start === false || $end === false || $end <= $start) {
            return new WP_Error('li_parse_error', 'No JSON array in Claude response. Raw: ' . substr($text, 0, 300));
        }

        $json = substr($text, $start, $end - $start + 1);
        $arr  = json_decode($json, true);

        if (!is_array($arr)) {
            return new WP_Error('li_parse_error', 'Invalid JSON from Claude. Raw: ' . substr($json, 0, 300));
        }

        return $arr;
    }

    /**
     * Analyse topic clusters and recommend new category expansions.
     * Returns structured object with insights + expansion recommendations.
     */
    public function get_cluster_insights($clusters) {
        $site_description = get_option('li_site_description', 'Danmarks ældste uafhængige digitale rejsemedie — luksus og oplevelsesrejser');

        $list = '';
        foreach ($clusters as $i => $c) {
            $pos      = $c['avg_position'] !== null ? $c['avg_position'] : 'ingen data';
            $momentum = $c['momentum'] > 0.1 ? '+' . round($c['momentum'] * 100) . '% trend' : ($c['momentum'] < -0.1 ? round($c['momentum'] * 100) . '% aftagende' : 'stabil');
            $session  = $c['avg_session'] !== null ? round($c['avg_session']) . 's' : 'n/a';
            $bounce   = $c['avg_bounce']  !== null ? $c['avg_bounce'] . '%' : 'n/a';

            $list .= ($i + 1) . ". [{$c['signal']}] {$c['category_name']} (score {$c['cluster_score']}/10)\n";
            $list .= "   Indlæg: {$c['post_count']} | Klik: {$c['total_clicks']} | Visninger: {$c['total_impressions']} | Pos: {$pos}\n";
            $list .= "   GA4: {$c['total_pageviews']} sidevisninger | {$session} session | {$bounce} bounce | Trend: {$momentum}\n";
            if (!empty($c['top_posts'])) {
                $tops = array_map(fn($p) => $p['title'] . " ({$p['clicks']} klik)", array_slice($c['top_posts'], 0, 2));
                $list .= "   Top: " . implode(' · ', $tops) . "\n";
            }
            $list .= "\n";
        }

        $prompt  = $this->get_output_language_instruction();
        $prompt .= "Du er content-strateg for {$site_description}.\n\n";
        $prompt .= "TOPIC KLYNGER — alle publicerede indlæg grupperet efter kategori:\n\n{$list}";
        $prompt .= "Signaler: strong=dominerende autoritet, growing=stærk positiv trend, untapped=visninger uden klik, moderate=mellemklasse, weak=underperformer.\n\n";
        $prompt .= "Giv:\n";
        $prompt .= "1. En analyse af de 3 stærkeste klynger (hvad gør dem stærke, hvad skal der til for at udvide)\n";
        $prompt .= "2. En analyse af de 3 mest lovende vækstmuligheder (herunder 'untapped' klynger)\n";
        $prompt .= "3. 5 anbefalinger til NYE emnekateg./topicklynger TravelTalk bør bygge — baseret på målgruppe (luksus, oplevelsesrejser, Nordic readers) og gaps i nuværende dækning\n\n";
        $prompt .= "KRITISK: Svar KUN med JSON-objekt. Ingen tekst før eller efter. Start med { og slut med }.\n\n";
        $prompt .= "{\n";
        $prompt .= "  \"strongest_clusters\": [\n";
        $prompt .= "    {\"name\": \"Kategorinavn\", \"why_strong\": \"Forklaring\", \"expand_action\": \"Hvad skal til\"}\n";
        $prompt .= "  ],\n";
        $prompt .= "  \"growth_opportunities\": [\n";
        $prompt .= "    {\"name\": \"Kategorinavn\", \"opportunity\": \"Hvad er potentialet\", \"action\": \"Konkret handling\"}\n";
        $prompt .= "  ],\n";
        $prompt .= "  \"new_categories\": [\n";
        $prompt .= "    {\n";
        $prompt .= "      \"topic\": \"Nyt emne\",\n";
        $prompt .= "      \"rationale\": \"Hvorfor passer det til TravelTalk og målgruppen\",\n";
        $prompt .= "      \"audience_fit\": \"Hvem i målgruppen vil dette ramme\",\n";
        $prompt .= "      \"competition\": \"lav\",\n";
        $prompt .= "      \"first_articles\": [\"Første artikelidé\", \"Anden artikelidé\"]\n";
        $prompt .= "    }\n";
        $prompt .= "  ],\n";
        $prompt .= "  \"summary\": \"2-3 sætninger: det vigtigste strategiske billede af TravelTalk.dk's nuværende klyngestyrke\"\n";
        $prompt .= "}\n";
        $prompt .= "\"competition\" er én af: \"lav\", \"middel\", \"høj\".\n";

        $decoded = $this->call_api($prompt, 3000, '{');
        if (is_wp_error($decoded)) return $decoded;

        $text = '{' . trim($decoded['content'][0]['text'] ?? '');
        $obj  = json_decode(substr($text, 0, strrpos($text, '}') + 1), true);
        if (!is_array($obj)) {
            return new WP_Error('li_parse_error', 'Invalid JSON in cluster insights response.');
        }

        return $obj;
    }

    /**
     * Partner Intelligence — maps clusters to named real-world partners with data-backed pitches.
     * Returns structured partner recommendations or WP_Error.
     */
    public function get_partner_suggestions($clusters) {
        $site_description = get_option('li_site_description', 'Danmarks ældste uafhængige digitale rejsemedie — luksus og oplevelsesrejser');

        $cluster_list = '';
        foreach ($clusters as $i => $c) {
            $pos     = $c['avg_position'] !== null ? $c['avg_position'] : '—';
            $session = $c['avg_session'] !== null ? round($c['avg_session']) . 's' : 'n/a';
            $tops    = [];
            foreach (array_slice($c['top_posts'] ?? [], 0, 3) as $p) {
                $tops[] = $p['title'] . ' (' . $p['clicks'] . ' klik)';
            }
            $cluster_list .= ($i + 1) . ". [{$c['signal']}] {$c['category_name']}\n";
            $cluster_list .= "   Score: {$c['cluster_score']}/10 | Indlæg: {$c['post_count']} | Klik: {$c['total_clicks']} | Visninger: {$c['total_impressions']} | Pos: {$pos}\n";
            $cluster_list .= "   GA4: {$c['total_pageviews']} sidevisninger | {$session} session\n";
            if ($tops) $cluster_list .= "   Top: " . implode(' · ', $tops) . "\n";
            $cluster_list .= "\n";
        }

        $agencies = $this->get_approved_agencies();
        $agency_list = '';
        foreach ($agencies as $a) {
            $type_label = $a['type'] !== 'travel_agency' ? " [{$a['type']}]" : '';
            $agency_list .= "- {$a['name']}{$type_label} ({$a['domain']}): {$a['note']}\n";
        }
        $exclude = $this->get_exclude_brands();

        $prompt  = $this->get_output_language_instruction();
        $prompt .= "Du er partner- og kommercialiseringsstrateg for {$site_description}.\n";
        $prompt .= "Målgruppe: Velhavende rejsende (40–65 år), oplevelsesorienterede, ikke charter/budget.\n\n";
        $prompt .= "GODKENDTE LUKSUS REJSEPARTNERE — brug KUN disse som travel_agency/cruise/train partnere:\n";
        $prompt .= $agency_list . "\n";
        $prompt .= "Må ALDRIG anbefales (massemarkeds): {$exclude}.\n\n";
        $prompt .= "VORES TOPIC KLYNGER (med reelle trafiktal fra Google Search Console + GA4):\n\n{$cluster_list}";
        $prompt .= "OPGAVE: Identificér konkrete, navngivne partnerskabsmuligheder baseret på vores faktiske indholdsposition.\n";
        $prompt .= "Brug de reelle tal i pitches — f.eks. 'Vi driver X klik/måned på [emne] med gennemsnitsposition Y på Google.'\n\n";
        $prompt .= "Partnertyper: tourism_board, airline, cruise, hotel_group, dmo, travel_agency, train, other.\n";
        $prompt .= "Fokus på luksus og oplevelsesrejser — IKKE budget, charter, all-inclusive.\n";
        $prompt .= "Flyselskaber: fokus på Nordic-afgangsruter (CPH, ARN, HEL, OSL) til vores stærkeste destinationer.\n\n";
        $prompt .= "KRITISK: Svar KUN med JSON-objekt. Ingen tekst. Start med { og slut med }.\n\n";
        $prompt .= "{\n";
        $prompt .= "  \"cluster_partners\": [\n";
        $prompt .= "    {\n";
        $prompt .= "      \"cluster\": \"Kategorinavn\",\n";
        $prompt .= "      \"cluster_clicks\": 1200,\n";
        $prompt .= "      \"partners\": [\n";
        $prompt .= "        {\n";
        $prompt .= "          \"name\": \"Konkret organisationsnavn\",\n";
        $prompt .= "          \"type\": \"tourism_board\",\n";
        $prompt .= "          \"country\": \"Land\",\n";
        $prompt .= "          \"relevance\": 9,\n";
        $prompt .= "          \"why\": \"Hvorfor dette partnerskab passer\",\n";
        $prompt .= "          \"pitch\": \"Datadrevet pitch på {$this->lang_name()} — brug de faktiske klik/position-tal\",\n";
        $prompt .= "          \"contact_type\": \"content_partnership\"\n";
        $prompt .= "        }\n";
        $prompt .= "      ]\n";
        $prompt .= "    }\n";
        $prompt .= "  ],\n";
        $prompt .= "  \"airline_routes\": [\n";
        $prompt .= "    {\n";
        $prompt .= "      \"route\": \"CPH → Bangkok\",\n";
        $prompt .= "      \"airline\": \"Thai Airways\",\n";
        $prompt .= "      \"cluster\": \"Relateret klynge\",\n";
        $prompt .= "      \"pitch\": \"Datadrevet pitch til flyselskabet\"\n";
        $prompt .= "    }\n";
        $prompt .= "  ],\n";
        $prompt .= "  \"top_opportunities\": [\n";
        $prompt .= "    {\n";
        $prompt .= "      \"partner\": \"Organisationsnavn\",\n";
        $prompt .= "      \"type\": \"tourism_board\",\n";
        $prompt .= "      \"cluster\": \"Klynge\",\n";
        $prompt .= "      \"priority\": \"høj\",\n";
        $prompt .= "      \"reason\": \"Én sætning: hvorfor dette er den bedste mulighed nu\"\n";
        $prompt .= "    }\n";
        $prompt .= "  ],\n";
        $prompt .= "  \"summary\": \"2-3 sætninger om TravelTalks samlede kommercielle partnerskabspotentiale\"\n";
        $prompt .= "}\n";
        $prompt .= "\"contact_type\" er én af: content_partnership, sponsored_content, press_trip, affiliate, advertising.\n";
        $prompt .= "\"priority\" er én af: høj, middel, lav.\n";
        $prompt .= "Giv 2-4 partnere per klynge. Giv 5 top_opportunities. Giv 4-6 airline_routes.\n";
        $prompt .= "Brug kun virkelige organisationer med rigtige navne (TAT, Visit Norway, SAS, Hurtigruten, Four Seasons, osv.).\n";

        $decoded = $this->call_api($prompt, 8000, '{'); // headroom: partner JSON (per-cluster + routes + opps) overflows 4096
        if (is_wp_error($decoded)) return $decoded;

        $text = '{' . trim($decoded['content'][0]['text'] ?? '');
        $obj  = json_decode(substr($text, 0, strrpos($text, '}') + 1), true);
        if (!is_array($obj)) {
            return new WP_Error('li_parse_error', 'Invalid JSON in partner suggestions response.');
        }

        return $obj;
    }

    /**
     * Competitive gap analysis: share-of-voice framing — not direct competition,
     * but which destination keywords do mass-market sites dominate that upper-market
     * readers search before they find us (or don't).
     * Returns structured wins/battlegrounds/cede/open_fields/sov_gaps/tourism_board_targets or WP_Error.
     */
    public function get_competitive_analysis($clusters, $competitors) {
        $site_description = get_option('li_site_description', 'Danmarks ældste uafhængige digitale rejsemedie — luksus og oplevelsesrejser');

        // Build our cluster summary
        $our_clusters = '';
        foreach ($clusters as $i => $c) {
            $our_clusters .= ($i + 1) . ". [{$c['signal']}] {$c['category_name']} (score {$c['cluster_score']}/10, {$c['post_count']} indlæg, {$c['total_clicks']} klik, {$c['total_impressions']} visninger)\n";
        }

        // Build competitor summary
        $comp_summary = '';
        foreach ($competitors as $c) {
            $comp_summary .= "### {$c['name']} ({$c['domain']})\n";
            if (!empty($c['content_signals'])) {
                $comp_summary .= "Signaler: " . implode(', ', $c['content_signals']) . "\n";
            }
            if (!empty($c['nav_topics'])) {
                $urls = array_slice($c['nav_topics'], 0, 8);
                $slugs = array_map(fn($u) => basename(rtrim(parse_url($u, PHP_URL_PATH), '/')), $urls);
                $comp_summary .= "Nav: " . implode(' · ', array_filter($slugs)) . "\n";
            }
            if (!empty($c['article_topics'])) {
                $comp_summary .= "Emner: " . implode(' · ', array_slice($c['article_topics'], 0, 20)) . "\n";
            }
            $comp_summary .= "\n";
        }

        $prompt  = $this->get_output_language_instruction();
        $prompt .= "Du er strategisk content-rådgiver for {$site_description}.\n\n";
        $prompt .= "VIGTIG KONTEKST — SHARE OF VOICE, IKKE DIREKTE KONKURRENCE:\n";
        $prompt .= "Disse sites sælger IKKE til den samme kunde som TravelTalk. De er massemarkeds-rejsemedier/-bureauer.\n";
        $prompt .= "Problemet er at de dominerer de destinationssøgeord (f.eks. 'rejse til Japan', 'safari Afrika') som vores\n";
        $prompt .= "øvre-markeds-læsere bruger i deres research-fase — og derfor finder de ikke TravelTalk.\n";
        $prompt .= "Opgaven er IKKE at slå dem på budget-rejse-indhold. Det er at vinde synlighed på de søgeord hvor\n";
        $prompt .= "intent'en kan være luksus/oplevelse, og producere øvre-markeds-indhold der rangerer ved siden af dem.\n\n";
        $prompt .= "VORES KLYNGER (topic clusters, sorteret efter klyngekraft):\n{$our_clusters}\n";
        $prompt .= "SITES DER DOMINERER SØGERESULTATERNE (share-of-voice-konkurrenter):\n{$comp_summary}";
        $prompt .= "Analyser share-of-voice-situationen og identificer:\n";
        $prompt .= "1. Vores stærkeste positioner — destination-keywords vi allerede rangerer godt på\n";
        $prompt .= "2. Kamppladser — destinationer hvor vi har visninger men lave klik (vi er synlige men taber klikket til massemarkeds-indhold)\n";
        $prompt .= "3. Søgeord vi bør lade ligge — lavere-markeds intent, ikke vores målgruppe\n";
        $prompt .= "4. Åbne felter — destination-keywords med luksus-intent hvor hverken vi eller konkurrenterne dækker det godt\n";
        $prompt .= "5. Destination-SOV-gaps — konkrete destinationssøgeord vi mister til de store sites, og den øvre-markeds vinkel vi kan bruge for at vinde dem tilbage\n";
        $prompt .= "6. Turistbureauer/DMO-partnere der passer til vores styrker og mangler konkurrentdækning\n\n";
        $prompt .= "KRITISK: Svar KUN med JSON-objekt. Ingen tekst. Start med { og slut med }.\n\n";
        $prompt .= "{\n";
        $prompt .= "  \"wins\": [{\"cluster\": \"Kategorinavn\", \"reason\": \"Hvorfor vi dominerer denne destinations-SOV\", \"action\": \"Sådan udvider vi forspringet\"}],\n";
        $prompt .= "  \"battlegrounds\": [{\"cluster\": \"Kategorinavn\", \"competitors\": [\"domain.dk\"], \"our_edge\": \"Vores øvre-markeds fordel\", \"action\": \"Konkret indholdsvinkel for at vinde SOV\"}],\n";
        $prompt .= "  \"cede\": [{\"cluster\": \"Kategorinavn\", \"competitors\": [\"domain.dk\"], \"reason\": \"Lavere-markeds intent — ikke vores målgruppe\"}],\n";
        $prompt .= "  \"open_fields\": [{\"topic\": \"Emnenavn\", \"rationale\": \"Luksus/oplevelsesvinkel der endnu ikke er taget\", \"action\": \"Første artikelidé der tager pladsen\"}],\n";
        $prompt .= "  \"destination_sov_gaps\": [\n";
        $prompt .= "    {\n";
        $prompt .= "      \"destination\": \"F.eks. Japan\",\n";
        $prompt .= "      \"keyword\": \"F.eks. rejse til japan\",\n";
        $prompt .= "      \"dominated_by\": \"domain.dk\",\n";
        $prompt .= "      \"upper_market_angle\": \"Den eksklusive vinkel vi bør tage — f.eks. privat sake-smagning i Kyoto\",\n";
        $prompt .= "      \"cluster\": \"Relateret klynge\"\n";
        $prompt .= "    }\n";
        $prompt .= "  ],\n";
        $prompt .= "  \"tourism_board_targets\": [{\"destination\": \"Turistbureau/destination\", \"rationale\": \"Hvorfor passer det til TravelTalk\", \"cluster\": \"Relateret klynge\", \"contact_approach\": \"Pitchvinkel til turistbureau\"}],\n";
        $prompt .= "  \"summary\": \"2-3 sætninger: TravelTalks share-of-voice-position og den vigtigste mulighed for at nå øvre-markeds læserne der nu finder massemarkeds-sites\"\n";
        $prompt .= "}\n";
        $prompt .= "Giv 3-5 destination_sov_gaps. Fokus på destinationer med potentiale for luksus/oplevelsesvinkel.\n";

        $decoded = $this->call_api($prompt, 3500, '{');
        if (is_wp_error($decoded)) return $decoded;

        $text = '{' . trim($decoded['content'][0]['text'] ?? '');
        $obj  = json_decode(substr($text, 0, strrpos($text, '}') + 1), true);
        if (!is_array($obj)) {
            return new WP_Error('li_parse_error', 'Invalid JSON in competitive analysis response.');
        }

        return $obj;
    }

    /**
     * On-demand topic analysis — answers a free-text query in the context of the site's GSC/GA4 data.
     * Returns a structured object or WP_Error.
     */
    public function get_on_demand_analysis($query, $dataset) {
        $site_description = get_option('li_site_description', 'Danmarks ældste uafhængige digitale rejsemedie — luksus og oplevelsesrejser');

        // Build a compact GSC/GA4 context summary (top 15 rows)
        $context = '';
        foreach (array_slice($dataset, 0, 15) as $i => $item) {
            $title    = !empty($item['title']) ? $item['title'] : '(ingen titel)';
            $pos      = $item['avg_position'] ?? '?';
            $clicks   = $item['total_clicks'] ?? 0;
            $conf     = $item['confidence'] ?? '?';
            $season   = !empty($item['season_signal']) ? ' [' . strtoupper($item['season_signal']) . ']' : '';
            $context .= ($i + 1) . ". {$title} — pos {$pos}, {$clicks} klik, score {$conf}/10{$season}\n";
        }

        $prompt  = $this->get_output_language_instruction();
        $prompt .= "Du er content-strateg og SEO-rådgiver for {$site_description}.\n\n";
        $prompt .= "SITETS AKTUELLE PERFORMANCE (top 15 sider, GSC + GA4):\n{$context}\n";
        $prompt .= "SPØRGSMÅL FRA REDAKTØREN:\n\"{$query}\"\n\n";
        $prompt .= "Analyser spørgsmålet i forhold til sitedata og giv en præcis, handlingsorienteret vurdering.\n\n";
        $prompt .= "KRITISK: Svar KUN med et JSON-objekt. Ingen tekst før eller efter. Start med { og slut med }.\n\n";
        $prompt .= "{\n";
        $prompt .= "  \"opportunity_score\": 8,\n";
        $prompt .= "  \"verdict\": \"En sætning: er dette en god idé for TravelTalk?\",\n";
        $prompt .= "  \"search_intent\": \"Hvad søger folk egentlig efter?\",\n";
        $prompt .= "  \"audience_fit\": \"Passer det til luksus-oplevelsesrejse-målgruppen? Hvordan?\",\n";
        $prompt .= "  \"recommended_angle\": \"Den specifikke vinkel TravelTalk bør tage\",\n";
        $prompt .= "  \"differentiation\": \"Hvad skal artiklen gøre anderledes end hvad der allerede findes?\",\n";
        $prompt .= "  \"timing\": \"nu\",\n";
        $prompt .= "  \"target_keywords\": [\"primært søgeord\", \"sekundært søgeord\"],\n";
        $prompt .= "  \"related_opportunities\": [\"Relateret emneidé 1\", \"Relateret emneidé 2\"],\n";
        $prompt .= "  \"caution\": \"Eventuel advarsel eller begrænsning — tom streng hvis ingen\"\n";
        $prompt .= "}\n";
        $prompt .= "\"timing\" er én af: \"nu\", \"næste_sæson\", \"evergreen\", \"lav_prioritet\".\n";
        $prompt .= "opportunity_score er 1–10 baseret på søgevolumen, konkurrence og målgruppefit.\n";

        $decoded = $this->call_api($prompt, 1500, '{');
        if (is_wp_error($decoded)) return $decoded;

        $text = '{' . trim($decoded['content'][0]['text'] ?? '');
        $obj  = json_decode(substr($text, 0, strrpos($text, '}') + 1), true);
        if (!is_array($obj)) {
            return new WP_Error('li_parse_error', 'Invalid JSON object from Claude.');
        }

        return $obj;
    }

    /**
     * Topic-scoped partner suggestions — for the Muligheder flow: given one
     * topic/headline, name 2–3 concrete organisations to pitch, with a ready
     * pitch, Nordic-focused and luxury-filtered. Small response → fast.
     */
    public function get_topic_partners($term) {
        $site_description = get_option('li_site_description', 'Danmarks ældste uafhængige digitale rejsemedie — luksus og oplevelsesrejser');
        $scope    = get_option('li_lead_scope', 'Nordic');
        $agencies = $this->get_approved_agencies();
        $agency_list = '';
        foreach ($agencies as $a) {
            $type_label = $a['type'] !== 'travel_agency' ? " [{$a['type']}]" : '';
            $agency_list .= "- {$a['name']}{$type_label} ({$a['domain']})\n";
        }
        $exclude = $this->get_exclude_brands();

        $prompt  = $this->get_output_language_instruction();
        $prompt .= "Du er partner- og kommercialiseringsstrateg for {$site_description}.\n";
        $prompt .= "MÅLGRUPPE: kvalitetsbevidste, velhavende rejsende ({$scope}) — folk der KAN og VIL betale for den ekstraordinære oplevelse (fx hvaler ved Arktis), uanset om selve oplevelsen er dyr eller billig. Det afgørende er ikke pris, men ekstraordinær, oplevelsesbåren værdi til et publikum med ressourcer til at rejse, som de har lyst.\n\n";
        $prompt .= "PARTNERTYPER — to klasser:\n";
        $prompt .= "• KERNE (core): oplevelses- og premium-rejsepartnere — tourism boards, DMO'er, premium-hotelkæder (store OG mindre), flyselskaber, tog, oplevelses-cruise, gastronomi, kultur og events. Foreslå frit, når de er relevante for emnet.\n";
        $prompt .= "• TILSTØDENDE (adjacent): bredere premium (ikke kun luksus) og ancillary/enablers — motororganisationer (fx FDM), forsikring, udstyr og bagage, apps, færger, biludlejning. MÅ KUN foreslås, når der er en konkret, dokumenterbar grund til at netop VORES publikum for dette emne matcher dem (de har et publikum for vores interesse). Er audience-overlappet ikke klart → udelad dem helt (afstå). Bland aldrig ren charter eller budget ind.\n\n";
        $prompt .= "GODKENDTE rejsepartnere (brug KUN disse som travel_agency/cruise/train):\n{$agency_list}\n";
        $prompt .= "Må ALDRIG anbefales (ren massemarked): {$exclude}.\n\n";
        $prompt .= "EMNE / ARTIKELIDÉ:\n\"{$term}\"\n\n";
        $prompt .= "Foreslå 2–3 KONKRETE, navngivne organisationer, vi bør pitche om netop dette emne — rigtige navne (fx Visit Norway, Four Seasons, SAS, en konkret premium-hotelkæde, evt. en tilstødende partner HVIS audience-overlappet er klart).\n";
        $prompt .= "For hver partner: angiv partner_class (core eller adjacent), fit_score (0–10 for hvor stærkt VORES publikum for dette emne matcher dem) og fit_basis (den konkrete audience- eller interesse-overlap, der begrunder partneren). En adjacent-partner uden stærk fit_basis skal udelades.\n";
        $prompt .= "Hver partner skal have BÅDE en datadrevet pitch (konkret tal/indsigt) OG en inspirerende åbningslinje (den varme, menneskelige krog) — databaseret OG inspirerende på samme tid.\n\n";
        $prompt .= "KRITISK: Svar KUN med et JSON-objekt. Ingen tekst før/efter. Start med { og slut med }.\n\n";
        $prompt .= "{\n";
        $prompt .= "  \"partners\": [\n";
        $prompt .= "    {\n";
        $prompt .= "      \"name\": \"Konkret organisationsnavn\",\n";
        $prompt .= "      \"type\": \"tourism_board\",\n";
        $prompt .= "      \"partner_class\": \"core\",\n";
        $prompt .= "      \"country\": \"Land\",\n";
        $prompt .= "      \"relevance\": 8,\n";
        $prompt .= "      \"fit_score\": 8,\n";
        $prompt .= "      \"fit_basis\": \"Konkret audience/interesse-overlap der begrunder partneren for dette emne\",\n";
        $prompt .= "      \"why\": \"Én sætning: hvorfor partnerskabet passer til emnet og målgruppen\",\n";
        $prompt .= "      \"pitch\": \"Kort datadrevet pitch på {$this->lang_name()} (tal/indsigt der beviser værdien)\",\n";
        $prompt .= "      \"inspiration\": \"Én varm, inspirerende åbningslinje på {$this->lang_name()} — den menneskelige krog, der komplementerer tallene\",\n";
        $prompt .= "      \"contact_type\": \"content_partnership\"\n";
        $prompt .= "    }\n";
        $prompt .= "  ]\n";
        $prompt .= "}\n";
        $prompt .= "type: tourism_board, airline, cruise, hotel_group, dmo, travel_agency, train, motoring, insurance, ferry, gear, ancillary, other.\n";
        $prompt .= "partner_class: core (oplevelses/premium-rejse) eller adjacent (bredere/ancillary — kun med klar fit_basis).\n";
        $prompt .= "contact_type: content_partnership, sponsored_content, press_trip, affiliate, advertising.\n";

        $decoded = $this->call_api($prompt, 1500, '{');
        if (is_wp_error($decoded)) return $decoded;
        $text = '{' . trim($decoded['content'][0]['text'] ?? '');
        $obj  = json_decode(substr($text, 0, strrpos($text, '}') + 1), true);
        if (!is_array($obj)) return new WP_Error('li_parse_error', 'Invalid JSON in topic partners response.');

        // ⭐ DILUTION GATE (G 2026-07-19): wide aperture, real threshold.
        // Core partners pass freely; adjacent (FDM-type / ancillary / premium-not-luxury) survive
        // ONLY with an evidenced fit — fit_score >= 7 AND a stated fit_basis. No evidence → abstain.
        if (!empty($obj['partners']) && is_array($obj['partners'])) {
            $obj['partners'] = array_values(array_filter($obj['partners'], function ($p) {
                $class = strtolower($p['partner_class'] ?? 'core');
                if ($class !== 'adjacent') return true;
                $fit = isset($p['fit_score']) ? (float) $p['fit_score'] : 0;
                return $fit >= 7 && trim((string) ($p['fit_basis'] ?? '')) !== '';
            }));
        }
        return $obj;
    }

    /**
     * Reverse partner search (G 2026-07-19): given a NAMED company, assess whether and how
     * THEY should partner with US — data-based outreach brief. Feeds our real market strengths.
     */
    public function get_partner_fit($company, $our_markets = []) {
        $site_description = get_option('li_site_description', 'Danmarks ældste uafhængige digitale rejsemedie — luksus og oplevelsesrejser');
        $scope       = get_option('li_lead_scope', 'Nordic');
        $markets_txt = $our_markets ? implode(', ', array_slice($our_markets, 0, 20)) : '(ikke angivet)';

        $prompt  = $this->get_output_language_instruction();
        $prompt .= "Du er partner- og kommercialiseringsstrateg for {$site_description}.\n";
        $prompt .= "Vi er et {$scope}-rejsemedie for kvalitetsbevidste, velhavende rejsende — folk der kan OG vil betale for den ekstraordinære oplevelse (dyr eller billig).\n";
        $prompt .= "VORES STÆRKE MARKEDER/EMNER (vores rækkevidde): {$markets_txt}.\n\n";
        $prompt .= "OPGAVE: Vurdér OM og HVORDAN virksomheden nedenfor bør indgå partnerskab med OS — set fra DERES perspektiv (omvendt partner-fit).\n";
        $prompt .= "VIRKSOMHED: \"{$company}\"\n\n";
        $prompt .= "Svar databaseret og konkret. Overvej: hvilke af VORES markeder/emner er vi relevante for dem i; matcher deres kunder vores publikum; den skarpeste partnerskabsvinkel; værdien FOR DEM (vores rækkevidde/autoritet i deres segment — inkl. muligheden for pan-nordisk rækkevidde, ~22 mio. på tværs af DK/SE/NO/FI); og hele spektret af muligheder (ét land vs. flere vs. eksklusivitet).\n\n";
        $prompt .= "KRITISK: Svar KUN med ét JSON-objekt. Start med { og slut med }.\n\n";
        $prompt .= "{\n";
        $prompt .= "  \"company\": \"{$company}\",\n";
        $prompt .= "  \"fit_score\": 8,\n";
        $prompt .= "  \"verdict\": \"Én linje: bør vi pitche dem, og hvorfor (eller hvorfor ikke)\",\n";
        $prompt .= "  \"market_overlap\": [\"marked/emne hvor vi er stærke OG relevante for dem\"],\n";
        $prompt .= "  \"audience_fit\": \"Hvor godt deres kunder matcher vores publikum\",\n";
        $prompt .= "  \"best_article_topic\": \"Det emne hos os, vi bør pege dem på\",\n";
        $prompt .= "  \"archetype\": \"content_partnership | sponsored_content | affiliate | data_sharing | co_marketing | ancillary_bundle | press_trip\",\n";
        $prompt .= "  \"value_to_them\": \"Databaseret fordel for dem ved at nå vores segment (inkl. pan-nordisk hvis relevant)\",\n";
        $prompt .= "  \"spectrum\": [\"mulighed 1 (fx ét land)\", \"mulighed 2 (fx alle 4 nordiske markeder / eksklusivitet)\"],\n";
        $prompt .= "  \"data_hook\": \"Én datadreven åbningslinje til henvendelsen\"\n";
        $prompt .= "}\n";

        $decoded = $this->call_api($prompt, 1500, '{');
        if (is_wp_error($decoded)) return $decoded;
        $text = '{' . trim($decoded['content'][0]['text'] ?? '');
        $obj  = json_decode(substr($text, 0, strrpos($text, '}') + 1), true);
        if (!is_array($obj)) return new WP_Error('li_parse_error', 'Invalid JSON in partner fit response.');
        return $obj;
    }

    /**
     * Hub suggestions — given an idea (title + keyword) and the curated pillar
     * list (grouped by axis), pick the 2–3 best-fitting pillars, using the EXACT
     * names from the allowed list. Favours thematic (high-value lateral) pillars
     * plus the right geographic anchor. Small + fast (Haiku).
     * Returns ['hubs' => ['Name1','Name2', ...]] or WP_Error.
     */
    public function get_hub_suggestions($title, $keyword, $names_by_axis) {
        $labels = ['geo' => 'Geografi', 'region' => 'Regioner', 'theme' => 'Temaer'];
        $list = '';
        foreach ($names_by_axis as $axis => $names) {
            if (empty($names)) continue;
            $label = $labels[$axis] ?? $axis;
            $list .= "{$label}: " . implode(', ', $names) . "\n";
        }

        $prompt  = $this->get_output_language_instruction();
        $prompt .= "Du er indholdsarkitekt. En artikelidé skal placeres under 2–3 søjler (hubs) valgt UDELUKKENDE fra listen nedenfor.\n\n";
        $prompt .= "TILLADTE SØJLER (vælg KUN herfra — brug det NØJAGTIGE navn, opfind aldrig nye):\n{$list}\n";
        $prompt .= "ARTIKELIDÉ:\nTitel: \"{$title}\"\n";
        if ($keyword !== '') $prompt .= "Søgeord: \"{$keyword}\"\n";
        $prompt .= "\nVælg de 2–3 søjler der passer bedst. Prioritér de tematiske søjler (høj-værdi laterals) når de er relevante, og medtag den rette geografiske/regionale søjle. Kun navne fra listen.\n\n";
        $prompt .= "KRITISK: Svar KUN med et JSON-objekt. Ingen tekst før/efter. Start med { og slut med }.\n\n";
        $prompt .= "{\n  \"hubs\": [\"Nøjagtigt søjlenavn 1\", \"Nøjagtigt søjlenavn 2\"]\n}\n";

        $decoded = $this->call_api($prompt, 400, '{');
        if (is_wp_error($decoded)) return $decoded;
        $text = '{' . trim($decoded['content'][0]['text'] ?? '');
        $obj  = json_decode(substr($text, 0, strrpos($text, '}') + 1), true);
        if (!is_array($obj)) return new WP_Error('li_parse_error', 'Invalid JSON in hub suggestions response.');
        return $obj;
    }

    /**
     * AInna — the reader-facing travel advisor at the door. Given a reader's
     * free-text travel wish + real candidate posts from our own site, she
     * replies in her voice (the personal friendly travel advisor: warm,
     * been-there, underplays, never boasts) and picks 2–4 to recommend.
     * NEVER invents trips or links — only the candidates given.
     * Returns ['reply'=>..., 'picks'=>[['title','url','why'], ...]] or WP_Error.
     */
    public function get_ainna_reply($wish, $candidates, $history = []) {
        $site = get_option('li_site_description', 'Danmarks ældste uafhængige digitale rejsemedie');
        $list = '';
        foreach ($candidates as $i => $c) {
            $list .= ($i + 1) . ". \"{$c['title']}\" [{$c['category']}]\n   {$c['excerpt']}\n   {$c['url']}\n";
        }

        $prompt  = $this->get_output_language_instruction();
        $prompt .= "Du er AInna, en personlig og venlig rejserådgiver for {$site}. Du taler som en ven, der selv har rejst meget og gerne deler et godt tip – varm, jordnær, aldrig belærende og aldrig pralende. Du sælger ikke \"luksus\" eller \"premium\"; du kan bare lide steder og oplevelser af kvalitet, og du underspiller det. Aldrig kedelig, ingen gentagelser. Skriv perfekt, naturligt dansk – ingen mærkelige eller ulogiske billeder (man sidder fx \"under et figentræ\", ikke \"i skyggen af en figen\").\n\n";

        // Multi-turn: prior conversation so a refinement ("nu kun det Ægæiske") narrows the last answer.
        if (!empty($history) && is_array($history)) {
            $thread = '';
            foreach (array_slice($history, -6) as $h) {
                $who = (($h['role'] ?? '') === 'ainna') ? 'AInna' : 'Læser';
                $thread .= "{$who}: " . trim((string)($h['text'] ?? '')) . "\n";
            }
            if ($thread !== '') $prompt .= "SAMTALEN INDTIL NU:\n{$thread}\nLæseren FORFINER nu ønsket — byg videre på samtalen, gentag ikke dig selv:\n\"{$wish}\"\n\n";
            else $prompt .= "En læser fortæller, hvad de drømmer om:\n\"{$wish}\"\n\n";
        } else {
            $prompt .= "En læser fortæller, hvad de drømmer om:\n\"{$wish}\"\n\n";
        }
        $prompt .= "Artikler fra VORES eget site, der kan passe (brug KUN disse – find ALDRIG på rejser eller links):\n{$list}\n";
        $prompt .= "Svar som AInna: en kort, varm åbning, der møder ønsket; anbefal 2–4 af artiklerne med én sætning om hvorfor hver især passer; slut med ét lille spørgsmål, der inviterer læseren tættere på (smallere geografi, en bestemt stemning eller sæson).\n\n";
        $prompt .= "KRITISK: Svar KUN med et JSON-objekt. Ingen tekst før/efter. Start med { og slut med }.\n\n";
        $prompt .= "{\n  \"reply\": \"AInnas svar som sammenhængende tekst (uden links – kortene vises separat)\",\n  \"picks\": [\n    {\"title\": \"Nøjagtig titel fra listen\", \"url\": \"Nøjagtig url fra listen\", \"why\": \"én kort sætning\"}\n  ]\n}\n";
        $prompt .= "picks SKAL være blandt de viste artikler (samme url). Vælg 2–4.\n";

        $writer  = get_option('li_writer_model', 'claude-sonnet-4-6'); // voice matters → writer model
        $decoded = $this->call_api($prompt, 1200, '', $writer);
        if (is_wp_error($decoded)) return $decoded;

        $text = trim($decoded['content'][0]['text'] ?? '');
        $s = strpos($text, '{'); $e = strrpos($text, '}');
        $json = ($s !== false && $e !== false && $e > $s) ? substr($text, $s, $e - $s + 1) : $text;
        $obj  = json_decode($json, true);
        if (!is_array($obj)) return new WP_Error('li_parse_error', 'Invalid JSON in AInna reply.');
        return $obj;
    }
}
