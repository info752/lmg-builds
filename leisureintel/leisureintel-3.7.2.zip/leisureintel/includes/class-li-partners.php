<?php
if (!defined('ABSPATH')) exit;

class LI_Partners {

    const CACHE_KEY = 'li_partner_analysis';
    const CACHE_TTL = 86400; // 24 hours

    public function get_cached() {
        return get_transient(self::CACHE_KEY);
    }

    public function save($data) {
        set_transient(self::CACHE_KEY, $data, self::CACHE_TTL);
    }

    public function clear() {
        delete_transient(self::CACHE_KEY);
    }

    public function partner_type_label($type) {
        $labels = [
            'tourism_board'  => 'Turistbureau',
            'airline'        => 'Flyselskab',
            'cruise'         => 'Krydstogt',
            'hotel_group'    => 'Hotelkæde',
            'dmo'            => 'DMO',
            'travel_agency'  => 'Rejsebureau',
            'train'          => 'Togrejser',
            'other'          => 'Partner',
        ];
        return $labels[$type] ?? ucfirst($type);
    }
}
