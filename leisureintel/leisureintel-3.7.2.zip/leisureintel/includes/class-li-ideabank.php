<?php
if (!defined('ABSPATH')) exit;

/**
 * LeisureIntel — Idébank (Idea Bank).
 *
 * Persistent store of the weekly analysis suggestions (option li_ideas) + a
 * MULTI-HUB pillar picker: each idea can carry several hubs, chosen ONLY from
 * the curated 43 pillars (categories flagged _li_pillar = geo|region|theme),
 * grouped by axis — not the 128-category dump.
 *
 * save_ideas() is called from LI_Cron::run_analysis().
 */
class LI_Ideabank {

    const OPTION = 'li_ideas';
    const CAP    = 300;

    public static function boot() {
        add_action('admin_post_li_idea_add_hub',        [__CLASS__, 'handle_add_hub']);
        add_action('admin_post_li_idea_remove_hub',     [__CLASS__, 'handle_remove_hub']);
        add_action('admin_post_li_idea_toggle_written', [__CLASS__, 'handle_toggle_written']);
        add_action('wp_ajax_li_idea_suggest_hubs',      [__CLASS__, 'ajax_suggest_hubs']);
        add_action('admin_notices',                     [__CLASS__, 'admin_notice']);
    }

    public static function admin_notice() {
        if (empty($_GET['page']) || $_GET['page'] !== 'leisureintel' || empty($_GET['li_notice'])) return;
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html(rawurldecode(wp_unslash($_GET['li_notice']))) . '</p></div>';
    }

    public static function lead_scope() { return get_option('li_lead_scope', ''); }

    /** Ideas, with hub_term(int, legacy) migrated to hub_terms(array). */
    public static function get_ideas() {
        $a = get_option(self::OPTION, []);
        if (!is_array($a)) return [];
        foreach ($a as &$it) {
            if (!isset($it['hub_terms'])) {
                $ht = intval($it['hub_term'] ?? 0);
                $it['hub_terms'] = $ht ? [$ht] : [];
            }
        }
        unset($it);
        return $a;
    }

    public static function save_ideas($suggestions, $run_date) {
        if (!is_array($suggestions) || !$suggestions) return 0;
        $ideas    = get_option(self::OPTION, []);
        if (!is_array($ideas)) $ideas = [];
        $existing = array_column($ideas, 'title');
        $new = [];
        foreach ($suggestions as $s) {
            $title = isset($s['title']) ? wp_strip_all_tags($s['title']) : '';
            if ($title === '' || in_array($title, $existing, true)) continue;
            $new[] = [
                'id'          => substr(md5($title . $run_date), 0, 12),
                'title'       => $title,
                'angle'       => sanitize_text_field($s['angle'] ?? ''),
                'keyword'     => sanitize_text_field($s['target_keyword'] ?? ''),
                'intent'      => sanitize_text_field($s['intent'] ?? ''),
                'confidence'  => intval($s['confidence'] ?? 0),
                'timing'      => sanitize_text_field($s['timing'] ?? 'evergreen'),
                'run_date'    => $run_date,
                'hub_terms'   => [],
                'written'     => false,
            ];
            $existing[] = $title;
        }
        if ($new) {
            $ideas = array_merge($new, $ideas);
            if (count($ideas) > self::CAP) $ideas = array_slice($ideas, 0, self::CAP);
            update_option(self::OPTION, $ideas, false);
        }
        return count($new);
    }

    private static function update_idea($id, callable $mutator) {
        $ideas = get_option(self::OPTION, []);
        if (!is_array($ideas)) return;
        foreach ($ideas as &$it) {
            if (($it['id'] ?? '') === $id) {
                if (!isset($it['hub_terms'])) { $ht = intval($it['hub_term'] ?? 0); $it['hub_terms'] = $ht ? [$ht] : []; }
                $mutator($it);
                break;
            }
        }
        unset($it);
        update_option(self::OPTION, $ideas, false);
    }

    /** Curated pillars grouped by axis (geo/region/theme), alpha within group. */
    private static function pillars() {
        $terms = get_terms(['taxonomy' => 'category', 'hide_empty' => false, 'meta_key' => '_li_pillar']);
        $g = ['geo' => [], 'region' => [], 'theme' => []];
        if (is_array($terms)) foreach ($terms as $t) {
            $ax = get_term_meta($t->term_id, '_li_pillar', true);
            if (isset($g[$ax])) $g[$ax][] = $t;
        }
        foreach ($g as &$arr) usort($arr, fn($a, $b) => strcasecmp($a->name, $b->name));
        unset($arr);
        return $g;
    }

    /* ------------------------------------------------------------- Handlers */

    public static function handle_add_hub() {
        if (!current_user_can('manage_options')) wp_die('Denied');
        check_admin_referer('li_idea_add_hub');
        $id   = sanitize_text_field(wp_unslash($_POST['id'] ?? ''));
        $term = intval($_POST['hub_term'] ?? 0);
        if ($term) self::update_idea($id, function (&$it) use ($term) {
            $it['hub_terms'] = array_values(array_unique(array_merge($it['hub_terms'] ?? [], [$term])));
        });
        self::redirect();
    }

    public static function handle_remove_hub() {
        if (!current_user_can('manage_options')) wp_die('Denied');
        check_admin_referer('li_idea_remove_hub');
        $id   = sanitize_text_field(wp_unslash($_POST['id'] ?? ''));
        $term = intval($_POST['hub_term'] ?? 0);
        self::update_idea($id, function (&$it) use ($term) {
            $it['hub_terms'] = array_values(array_diff($it['hub_terms'] ?? [], [$term]));
        });
        self::redirect();
    }

    public static function handle_toggle_written() {
        if (!current_user_can('manage_options')) wp_die('Denied');
        check_admin_referer('li_idea_toggle_written');
        $id = sanitize_text_field(wp_unslash($_POST['id'] ?? ''));
        self::update_idea($id, function (&$it) { $it['written'] = empty($it['written']); });
        self::redirect();
    }

    /** AJAX — AI-suggest 2–3 hubs for one idea (favours thematic pillars). */
    public static function ajax_suggest_hubs() {
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Ingen adgang']);
        check_ajax_referer('li_suggest_hubs', 'nonce');

        $id   = sanitize_text_field(wp_unslash($_POST['id'] ?? ''));
        $idea = null;
        foreach (self::get_ideas() as $it) { if (($it['id'] ?? '') === $id) { $idea = $it; break; } }
        if (!$idea) wp_send_json_error(['message' => 'Idé ikke fundet']);

        // Curated pillar names by axis + a lowercase-name → term lookup.
        $names_by_axis = ['geo' => [], 'region' => [], 'theme' => []];
        $by_name = [];
        foreach (self::pillars() as $ax => $terms) {
            foreach ($terms as $t) {
                if (!isset($names_by_axis[$ax])) $names_by_axis[$ax] = [];
                $names_by_axis[$ax][] = $t->name;
                $by_name[mb_strtolower($t->name)] = $t;
            }
        }
        if (!$by_name) wp_send_json_error(['message' => 'Ingen kuraterede søjler fundet']);

        $res = (new LI_Claude())->get_hub_suggestions($idea['title'] ?? '', $idea['keyword'] ?? '', $names_by_axis);
        if (is_wp_error($res)) wp_send_json_error(['message' => $res->get_error_message()]);

        $current = array_map('intval', $idea['hub_terms'] ?? []);
        $out = [];
        $seen = [];
        foreach (($res['hubs'] ?? []) as $name) {
            $key = mb_strtolower(trim((string) $name));
            if ($key === '' || !isset($by_name[$key])) continue;
            $tid = (int) $by_name[$key]->term_id;
            if (in_array($tid, $current, true) || isset($seen[$tid])) continue;
            $seen[$tid] = 1;
            $out[] = ['term_id' => $tid, 'name' => $by_name[$key]->name];
        }
        wp_send_json_success(['hubs' => $out]);
    }

    private static function redirect() {
        wp_safe_redirect(add_query_arg(['page' => 'leisureintel', 'li_active' => 'ideabank'], admin_url('admin.php')));
        exit;
    }

    /* ---------------------------------------------------------------- Render */

    public static function render_pane() {
        $filter  = isset($_GET['li_idea_filter']) ? sanitize_key($_GET['li_idea_filter']) : 'all';
        $scope   = self::lead_scope();
        $ideas   = self::get_ideas();
        $pillars = self::pillars();
        $post    = esc_url(admin_url('admin-post.php'));

        $stats = ['total' => 0, 'unwritten' => 0, 'unnamed' => 0];
        $show  = [];
        foreach ($ideas as $it) {
            $written = !empty($it['written']);
            $unnamed = empty($it['hub_terms']);
            if ($filter === 'unwritten' && $written) continue;
            if ($filter === 'unnamed'   && !$unnamed) continue;
            $show[] = $it;
            $stats['total']++;
            if (!$written) $stats['unwritten']++;
            if ($unnamed)  $stats['unnamed']++;
        }
        ?>
        <h2>Idébank <span style="font-size:12px;color:#787c82;font-weight:normal;">— indholdsforslag med multi-hub (vælg blandt de kuraterede søjler)</span></h2>

        <div style="display:flex;gap:14px;flex-wrap:wrap;align-items:center;margin:10px 0 14px;">
            <div style="background:#f6f7f7;border:1px solid #dde;border-radius:6px;padding:8px 14px;">
                <strong>Lead-scope:</strong> <?php echo $scope ? '<span style="color:#2271b1;font-weight:600;">' . esc_html($scope) . '</span>' : '<em style="color:#b32d2e;">ikke sat</em>'; ?>
            </div>
            <div style="color:#787c82;"><?php echo (int) $stats['total']; ?> forslag · <?php echo (int) $stats['unwritten']; ?> ikke skrevet · <?php echo (int) $stats['unnamed']; ?> uden hub</div>
        </div>

        <p style="margin:0 0 14px;">
            <?php
            $base = admin_url('admin.php?page=leisureintel&li_active=ideabank');
            foreach (['all' => 'Alle', 'unwritten' => 'Kun ikke-skrevne', 'unnamed' => 'Uden hub'] as $k => $label) {
                $on = $filter === $k;
                echo '<a href="' . esc_url($base . '&li_idea_filter=' . $k) . '" style="margin-right:12px;' . ($on ? 'font-weight:700;color:#1d2327;text-decoration:none;' : '') . '">' . esc_html($label) . '</a>';
            }
            ?>
        </p>

        <?php if (empty($show)): ?>
            <div style="background:#fff;border:1px solid #ccd0d4;padding:16px 18px;"><p style="margin:0;"><em>Ingen forslag her endnu.</em> Kør <strong>“Kør analyse nu”</strong> under Analyse — ugens forslag lander automatisk i banken.</p></div>
        <?php else: ?>
            <table class="widefat striped">
                <thead><tr><th style="width:46px;">Score</th><th>Forslag</th><th style="width:110px;">Søgeord</th><th style="width:300px;">Hubs (søjler)</th><th style="width:110px;">Status</th></tr></thead>
                <tbody>
                <?php foreach ($show as $it) self::render_row($it, $pillars, $post); ?>
                </tbody>
            </table>
        <?php endif; ?>

        <select id="li-hub-tpl" style="display:none;">
            <?php $axl = ['geo' => 'Geografi', 'region' => 'Regioner', 'theme' => 'Temaer'];
            foreach ($pillars as $ax => $terms_list): if (!$terms_list) continue; ?>
                <optgroup label="<?php echo esc_attr($axl[$ax] ?? $ax); ?>">
                    <?php foreach ($terms_list as $pt): ?><option value="<?php echo (int) $pt->term_id; ?>"><?php echo esc_html($pt->name); ?></option><?php endforeach; ?>
                </optgroup>
            <?php endforeach; ?>
        </select>

        <script>
        (function(){
            var tpl = document.getElementById('li-hub-tpl');
            if (tpl) document.querySelectorAll('.li-hub-add').forEach(function(sel){
                var ex = (sel.getAttribute('data-exclude') || '').split(',').filter(Boolean);
                Array.prototype.forEach.call(tpl.children, function(node){
                    if (node.tagName !== 'OPTGROUP') return;
                    var og = document.createElement('optgroup'); og.label = node.label; var any = false;
                    Array.prototype.forEach.call(node.children, function(o){ if (ex.indexOf(o.value) === -1) { og.appendChild(o.cloneNode(true)); any = true; } });
                    if (any) sel.appendChild(og);
                });
            });
        })();
        document.addEventListener('DOMContentLoaded', function(){
            if (location.search.indexOf('li_active=ideabank') === -1) return;
            var b = document.querySelector('.li-tab-btn[data-tab="ideabank"]'); if (b) b.click();
        });
        </script>

        <script>
        (function(){
            var liIdeaNonce = <?php echo wp_json_encode(wp_create_nonce('li_suggest_hubs')); ?>;

            function renderPills(box, hubs){
                box.innerHTML = '';
                if (!hubs || !hubs.length){
                    box.innerHTML = '<em style="color:#787c82;font-size:12px;">ingen nye forslag</em>';
                    return;
                }
                var lbl = document.createElement('span');
                lbl.textContent = 'Forslag: ';
                lbl.style.cssText = 'font-size:12px;color:#787c82;';
                box.appendChild(lbl);
                hubs.forEach(function(h){
                    var pill = document.createElement('button');
                    pill.type = 'button';
                    pill.textContent = '+ ' + h.name;
                    pill.style.cssText = 'background:#e6f4ea;border:1px solid #9dcfae;color:#1a6b34;border-radius:12px;padding:1px 9px;margin:2px 4px 2px 0;font-size:12px;cursor:pointer;';
                    pill.addEventListener('click', function(){
                        var td = box.closest('td');
                        var sel = td ? td.querySelector('.li-hub-add') : null;
                        if (!sel){ return; }
                        sel.value = String(h.term_id);
                        if (sel.value === String(h.term_id) && sel.form){ sel.form.submit(); }
                        else { alert('Denne søjle er allerede tilføjet.'); }
                    });
                    box.appendChild(pill);
                });
            }

            document.addEventListener('click', function(e){
                var btn = e.target.closest ? e.target.closest('.li-suggest-btn') : null;
                if (!btn) return;
                e.preventDefault();
                var td  = btn.closest('td');
                var box = td ? td.querySelector('.li-suggest-out') : null;
                if (!box) return;
                var orig = btn.textContent;
                btn.disabled = true; btn.textContent = 'Tænker…';
                box.innerHTML = '';
                var fd = new FormData();
                fd.append('action', 'li_idea_suggest_hubs');
                fd.append('nonce', liIdeaNonce);
                fd.append('id', btn.getAttribute('data-id'));
                fetch(ajaxurl, { method:'POST', body:fd, credentials:'same-origin' })
                    .then(function(r){ return r.json(); })
                    .then(function(j){
                        btn.disabled = false; btn.textContent = orig;
                        if (j && j.success && j.data){ renderPills(box, j.data.hubs); }
                        else { box.innerHTML = '<em style="color:#b32d2e;font-size:12px;">' + ((j && j.data && j.data.message) || 'fejl') + '</em>'; }
                    })
                    .catch(function(){
                        btn.disabled = false; btn.textContent = orig;
                        box.innerHTML = '<em style="color:#b32d2e;font-size:12px;">netværksfejl</em>';
                    });
            });
        })();
        </script>
        <?php
    }

    private static function render_row($it, $pillars, $post) {
        $conf    = intval($it['confidence'] ?? 0);
        $badge   = $conf >= 8 ? '#46b450' : ($conf >= 6 ? '#dba617' : '#787c82');
        $id      = esc_attr($it['id'] ?? '');
        $written = !empty($it['written']);
        $terms   = $it['hub_terms'] ?? [];
        $axis_labels = ['geo' => 'Geografi', 'region' => 'Regioner', 'theme' => 'Temaer'];
        ?>
        <tr>
            <td><span style="display:inline-block;min-width:26px;text-align:center;background:<?php echo $badge; ?>;color:#fff;border-radius:3px;padding:1px 4px;font-weight:600;"><?php echo $conf ?: '–'; ?></span></td>
            <td><strong><?php echo esc_html($it['title'] ?? ''); ?></strong>
                <?php if (!empty($it['timing'])): ?><br><span class="description"><?php echo esc_html($it['timing']); ?></span><?php endif; ?>
            </td>
            <td><?php echo esc_html($it['keyword'] ?? '') ?: '—'; ?></td>
            <td>
                <?php // current hub chips (removable)
                foreach ($terms as $tid) {
                    $t = get_term((int) $tid);
                    if (!$t || is_wp_error($t)) continue;
                    echo '<span style="display:inline-flex;align-items:center;gap:3px;background:#eef;border:1px solid #ccd;border-radius:12px;padding:1px 4px 1px 9px;margin:2px 4px 2px 0;font-size:12px;">' . esc_html($t->name);
                    echo '<form method="post" action="' . $post . '" style="display:inline;margin:0;">';
                    wp_nonce_field('li_idea_remove_hub');
                    echo '<input type="hidden" name="action" value="li_idea_remove_hub"><input type="hidden" name="id" value="' . $id . '"><input type="hidden" name="hub_term" value="' . (int) $tid . '">';
                    echo '<button title="Fjern" style="border:0;background:none;cursor:pointer;color:#b32d2e;font-weight:700;padding:0 2px;">×</button></form></span>';
                }
                ?>
                <form method="post" action="<?php echo $post; ?>" style="display:inline-flex;gap:3px;margin:2px 0;">
                    <?php wp_nonce_field('li_idea_add_hub'); ?>
                    <input type="hidden" name="action" value="li_idea_add_hub">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <select name="hub_term" class="li-hub-add" data-exclude="<?php echo esc_attr(implode(',', array_map('intval', $terms))); ?>" style="max-width:150px;font-size:12px;">
                        <option value="0">+ tilføj hub…</option>
                    </select>
                    <button class="button button-small">+</button>
                </form>
                <div style="margin-top:4px;">
                    <button type="button" class="button-link li-suggest-btn" data-id="<?php echo $id; ?>" style="font-size:12px;color:#2271b1;text-decoration:none;">🔮 Foreslå hubs</button>
                    <span class="li-suggest-out" style="margin-left:6px;"></span>
                </div>
            </td>
            <td>
                <form method="post" action="<?php echo $post; ?>" style="margin:0;">
                    <?php wp_nonce_field('li_idea_toggle_written'); ?>
                    <input type="hidden" name="action" value="li_idea_toggle_written"><input type="hidden" name="id" value="<?php echo $id; ?>">
                    <button class="button-link" style="<?php echo $written ? 'color:#46b450;' : 'color:#787c82;'; ?>"><?php echo $written ? '✔ skrevet' : 'markér skrevet'; ?></button>
                </form>
            </td>
        </tr>
        <?php
    }
}
