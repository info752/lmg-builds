<?php
if (!defined('ABSPATH')) exit;

class LI_Generator {

    /**
     * Create draft posts from Claude suggestions array.
     */
    public function create_drafts($suggestions) {
        $run_date = current_time('mysql');
        $created  = 0;
        $post_ids = [];
        $titles   = [];

        $tag_id = $this->ensure_tag('leisureintel');

        foreach ($suggestions as $suggestion) {
            if (empty($suggestion['title'])) continue;

            $title      = sanitize_text_field($suggestion['title']);
            $angle      = isset($suggestion['angle']) ? sanitize_textarea_field($suggestion['angle']) : '';
            $structure  = isset($suggestion['structure']) && is_array($suggestion['structure']) ? $suggestion['structure'] : [];
            $keyword    = isset($suggestion['target_keyword']) ? sanitize_text_field($suggestion['target_keyword']) : '';
            $intent     = isset($suggestion['intent']) ? sanitize_text_field($suggestion['intent']) : '';
            $inspired   = isset($suggestion['inspired_by']) ? esc_url_raw($suggestion['inspired_by']) : '';
            $confidence = isset($suggestion['confidence']) ? intval($suggestion['confidence']) : 0;
            $timing     = isset($suggestion['timing']) ? sanitize_text_field($suggestion['timing']) : 'evergreen';

            $content = $this->build_brief_content($angle, $keyword, $intent, $confidence, $inspired, $timing, $structure);

            $post_id = wp_insert_post([
                'post_title'   => $title,
                'post_content' => $content,
                'post_status'  => 'draft',
                'post_type'    => 'post',
                'post_author'  => 1,
            ], true);

            if (is_wp_error($post_id)) continue;

            if ($tag_id) wp_set_post_tags($post_id, [$tag_id], false);

            update_post_meta($post_id, '_li_target_keyword', $keyword);
            update_post_meta($post_id, '_li_intent', $intent);
            update_post_meta($post_id, '_li_confidence', $confidence);
            update_post_meta($post_id, '_li_inspired_by', $inspired);
            update_post_meta($post_id, '_li_timing', $timing);
            update_post_meta($post_id, '_li_run_date', $run_date);
            update_post_meta($post_id, '_li_written', 0);

            $post_ids[] = $post_id;
            $titles[]   = ['id' => $post_id, 'title' => $title, 'confidence' => $confidence, 'timing' => $timing];
            $created++;
        }

        return [
            'created'  => $created,
            'post_ids' => $post_ids,
            'titles'   => $titles,
        ];
    }

    /**
     * Create an audit report as a draft post.
     */
    public function create_audit_report($results) {
        $date = current_time('d. F Y');

        $content  = "<!-- wp:paragraph -->\n<p><strong>LeisureIntel Indholdsrevision — {$date}</strong></p>\n<!-- /wp:paragraph -->\n\n";
        $content .= "<!-- wp:paragraph -->\n<p>" . count($results) . " indlæg analyseret.</p>\n<!-- /wp:paragraph -->\n\n";

        $sections = [
            'slet'       => ['label' => 'Slet', 'desc' => 'Ingen trafik — overvej at slette'],
            'viderestil' => ['label' => 'Viderestil', 'desc' => 'Redundant indhold — omdiriger til stærkere side'],
            'forbedring' => ['label' => 'Kræver forbedring', 'desc' => 'Godt emne, underperformer — opdater indholdet'],
            'behold'     => ['label' => 'Behold', 'desc' => 'Performer godt eller har evergreen-værdi'],
        ];

        foreach ($sections as $action => $meta) {
            $group = array_filter($results, fn($r) => $r['action'] === $action);
            if (empty($group)) continue;

            $content .= "<!-- wp:heading -->\n<h2>{$meta['label']} (" . count($group) . ") — {$meta['desc']}</h2>\n<!-- /wp:heading -->\n\n";

            foreach ($group as $item) {
                $edit  = get_edit_post_link($item['post_id'], 'raw');
                $title = esc_html($item['title']);
                $reason = esc_html($item['reason']);
                $gsc    = "GSC: {$item['clicks']} klik · pos " . ($item['position'] ?? 'n/a');
                $ga4    = isset($item['pageviews']) ? " · GA4: {$item['pageviews']} visninger" : '';

                $content .= "<!-- wp:paragraph -->\n";
                $content .= "<p><strong><a href=\"{$edit}\">{$title}</a></strong><br>";
                $content .= "<em>{$reason}</em><br>";
                $content .= "<small>{$gsc}{$ga4}</small></p>\n";
                $content .= "<!-- /wp:paragraph -->\n\n";
            }
        }

        $post_id = wp_insert_post([
            'post_title'   => 'LeisureIntel Revision — ' . current_time('d/m/Y'),
            'post_content' => $content,
            'post_status'  => 'draft',
            'post_type'    => 'post',
            'post_author'  => 1,
        ], true);

        if (is_wp_error($post_id)) return null;

        $tag_id = $this->ensure_tag('leisureintel-audit');
        if ($tag_id) wp_set_post_tags($post_id, [$tag_id], false);

        update_post_meta($post_id, '_li_audit_report', 1);
        update_post_meta($post_id, '_li_run_date', current_time('mysql'));

        return $post_id;
    }

    private function build_brief_content($angle, $keyword, $intent, $confidence, $inspired, $timing, $structure) {
        $timing_labels = ['nu' => 'Publicer nu', 'næste_sæson' => 'Næste sæson', 'evergreen' => 'Evergreen'];
        $timing_label  = $timing_labels[$timing] ?? $timing;

        $content  = "<!-- wp:paragraph -->\n<p><strong>Vinkel:</strong> " . esc_html($angle) . "</p>\n<!-- /wp:paragraph -->\n\n";
        $content .= "<!-- wp:paragraph -->\n<p><strong>Primært søgeord:</strong> " . esc_html($keyword) . "</p>\n<!-- /wp:paragraph -->\n\n";
        $content .= "<!-- wp:paragraph -->\n<p><strong>Intent:</strong> " . esc_html($intent) . " &nbsp;|&nbsp; <strong>Timing:</strong> " . esc_html($timing_label) . " &nbsp;|&nbsp; <strong>Score:</strong> {$confidence}/10</p>\n<!-- /wp:paragraph -->\n\n";
        $content .= "<!-- wp:paragraph -->\n<p><strong>Inspireret af:</strong> " . esc_html($inspired) . "</p>\n<!-- /wp:paragraph -->\n\n";

        if (!empty($structure)) {
            $content .= "<!-- wp:heading -->\n<h2>Foreslået struktur</h2>\n<!-- /wp:heading -->\n\n";
            foreach ($structure as $h2) {
                $content .= "<!-- wp:heading {\"level\":2} -->\n<h2>" . esc_html($h2) . "</h2>\n<!-- /wp:heading -->\n\n";
                $content .= "<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n";
            }
        }

        return $content;
    }

    private function ensure_tag($slug) {
        $tag = get_term_by('slug', $slug, 'post_tag');
        if ($tag) return $tag->term_id;
        $result = wp_insert_term($slug, 'post_tag', ['slug' => $slug]);
        return is_wp_error($result) ? null : $result['term_id'];
    }
}
