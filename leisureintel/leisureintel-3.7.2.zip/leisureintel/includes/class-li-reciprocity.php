<?php
if (!defined('ABSPATH')) exit;

/**
 * LeisureIntel — Cluster reciprocity check ("Klynge-links").
 *
 * For each HUB (a page/post marked Rank Math Pillar Content), find its cluster —
 * the published posts in the category whose name matches the hub's title — and
 * check the two-way internal linking:
 *   hub → spoke   (does the hub link DOWN to each spoke?)
 *   spoke → hub   (does each spoke link BACK UP to the hub?)
 * Reports the gaps so the editor can place the missing in-text links.
 * FINDS ONLY — never edits content. Fast: pure content string-match, no HTTP.
 */
class LI_Reciprocity {

    public static function boot() {
        add_action('wp_ajax_li_reciprocity', [__CLASS__, 'ajax_scan']);
    }

    public static function ajax_scan() {
        check_ajax_referer('li_reciprocity', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Ingen adgang']);
        wp_send_json_success(['html' => self::report_html()]);
    }

    private static function report_html() {
        $hubs = get_posts([
            'post_type'      => ['page', 'post'],
            'post_status'    => 'publish',
            'meta_key'       => 'rank_math_pillar_content',
            'meta_value'     => 'on',
            'posts_per_page' => -1,
        ]);
        if (!$hubs) return '<p><em>Ingen hubs fundet — markér sider som <strong>Pillar Content</strong> i Rank Math først.</em></p>';

        // Links in/out per hub from Rank Math's Link Counter (rank_math_internal_meta).
        global $wpdb;
        $counts = [];
        $ids = array_map(fn($h) => (int) $h->ID, $hubs);
        if ($ids) {
            $tbl = $wpdb->prefix . 'rank_math_internal_meta';
            $inlist = implode(',', $ids);
            foreach ($wpdb->get_results("SELECT object_id, internal_link_count, incoming_link_count FROM {$tbl} WHERE object_id IN ({$inlist})") as $r) {
                $counts[(int) $r->object_id] = ['out' => (int) $r->internal_link_count, 'in' => (int) $r->incoming_link_count];
            }
        }

        $rows = '';
        $scanned = 0;
        $no_cluster = [];
        foreach ($hubs as $hub) {
            $cat = get_term_by('name', $hub->post_title, 'category');
            if (!$cat) { $no_cluster[] = $hub->post_title; continue; }
            $scanned++;
            $lc = $counts[$hub->ID] ?? ['in' => 0, 'out' => 0];
            $wc = str_word_count(wp_strip_all_tags(strip_shortcodes($hub->post_content)));
            $wcol = $wc >= 2000 ? '#46b450' : ($wc >= 800 ? '#dba617' : '#b32d2e');

            $hub_path = untrailingslashit((string) parse_url(get_permalink($hub->ID), PHP_URL_PATH));
            $spokes = get_posts([
                'post_type'      => 'post',
                'post_status'    => 'publish',
                'category'       => $cat->term_id,
                'posts_per_page' => 150,
                'exclude'        => [$hub->ID],
            ]);
            $total = count($spokes);
            $back = 0; $down = 0; $missing = [];
            $hub_content = $hub->post_content;

            foreach ($spokes as $sp) {
                $sp_path = untrailingslashit((string) parse_url(get_permalink($sp->ID), PHP_URL_PATH));
                if ($sp_path && strpos($hub_content, $sp_path) !== false) $down++;
                if ($hub_path && strpos($sp->post_content, $hub_path) !== false) $back++;
                else $missing[] = ['t' => $sp->post_title, 'e' => admin_url('post.php?post=' . $sp->ID . '&action=edit')];
            }

            $health = $total ? (int) round(($back / $total) * 100) : 100;
            $col = $health >= 80 ? '#46b450' : ($health >= 50 ? '#dba617' : '#b32d2e');
            $miss_html = '';
            if ($missing) {
                $links = array_map(fn($m) => "<a href='" . esc_url($m['e']) . "'>" . esc_html(mb_substr($m['t'], 0, 38)) . "</a>", array_slice($missing, 0, 12));
                $miss_html = implode(' · ', $links) . (count($missing) > 12 ? ' … +' . (count($missing) - 12) : '');
            } else {
                $miss_html = '<span style="color:#46b450;">alle linker tilbage ✓</span>';
            }

            $rows .= "<tr>"
                . "<td><strong>" . esc_html($hub->post_title) . "</strong><br><a href='" . esc_url(admin_url('post.php?post=' . $hub->ID . '&action=edit')) . "' style='font-size:11px;'>redigér hub</a></td>"
                . "<td><span style='color:{$wcol};font-weight:600;'>{$wc}</span></td>"
                . "<td><strong>{$lc['in']}</strong></td>"
                . "<td>{$lc['out']}</td>"
                . "<td>{$total}</td>"
                . "<td>{$down}/{$total}</td>"
                . "<td><span style='color:{$col};font-weight:600;'>{$back}/{$total} ({$health}%)</span></td>"
                . "<td style='font-size:12px;'>{$miss_html}</td>"
                . "</tr>";
        }

        $h  = "<p>For hver <strong>hub</strong> (side markeret Pillar Content i Rank Math) tjekkes tovejs-links til klyngen (posts i kategorien med samme navn): <em>hub → spoke</em> og <em>spoke → hub</em>. Manglerne linker direkte til redigering — du placerer selv in-text-linket.</p>";
        $h .= "<table class='widefat striped'><thead><tr><th>Hub / pillar</th><th>Ord (mål 3000)</th><th>Links ind</th><th>Links ud</th><th>Spokes</th><th>Hub → spoke</th><th>Spoke → hub</th><th>Mangler tilbage-link</th></tr></thead><tbody>{$rows}</tbody></table>";
        $h .= "<p class='description'>Scannede {$scanned} hubs.";
        if ($no_cluster) $h .= " Ingen matchende kategori (klynge ukendt) for: " . esc_html(implode(', ', array_slice($no_cluster, 0, 20))) . (count($no_cluster) > 20 ? ' …' : '') . " — disse hubs har ikke en kategori med samme navn.";
        $h .= "</p>";
        return $h;
    }

    public static function render_pane() {
        $nonce = wp_create_nonce('li_reciprocity');
        ?>
        <h2>Klynge-links <span style="font-size:12px;color:#787c82;font-weight:normal;">— hub↔spoke reciprocitet: linker spokes tilbage til deres hub, og hubben ned til dem?</span></h2>
        <p>
            <button id="li-recip-run" class="button button-primary" data-nonce="<?php echo esc_attr($nonce); ?>">Tjek klynge-links</button>
            <span id="li-recip-spin" style="display:none;color:#787c82;"><span class="spinner is-active" style="float:none;margin:0 6px 0 0;"></span> Tjekker klynger…</span>
        </p>
        <div id="li-recip-result" style="margin-top:12px;"></div>
        <script>
        (function(){
            var b = document.getElementById('li-recip-run'); if(!b) return;
            b.addEventListener('click', function(){
                b.disabled=true; document.getElementById('li-recip-spin').style.display='inline';
                document.getElementById('li-recip-result').innerHTML='';
                var fd=new FormData(); fd.append('action','li_reciprocity'); fd.append('nonce',b.getAttribute('data-nonce'));
                fetch(ajaxurl,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();}).then(function(j){
                    b.disabled=false; document.getElementById('li-recip-spin').style.display='none';
                    document.getElementById('li-recip-result').innerHTML=(j&&j.success)?j.data.html:'<div class="notice notice-warning inline"><p>'+((j&&j.data&&j.data.message)||'Fejl')+'</p></div>';
                }).catch(function(){ b.disabled=false; document.getElementById('li-recip-spin').style.display='none'; document.getElementById('li-recip-result').innerHTML='<div class="notice notice-warning inline"><p>Netværksfejl.</p></div>'; });
            });
            if(location.search.indexOf('li_active=reciprocity')!==-1){ document.addEventListener('DOMContentLoaded',function(){ var t=document.querySelector('.li-tab-btn[data-tab="reciprocity"]'); if(t)t.click(); }); }
        })();
        </script>
        <?php
    }
}
