<?php
if (!defined('ABSPATH')) exit;

/**
 * LeisureIntel — async job runner.
 *
 * ROOT-CAUSE FIX for the "AJAX fejlede" errors: the heavy Claude operations
 * (analysis 35s, competitor 60–120s, …) exceed the browser/proxy ~30s timeout,
 * so a *synchronous* AJAX call always fails even though the work completes.
 *
 * This runs the work in a detached background request and lets the browser poll
 * for the result — no request ever blocks past the timeout.
 *
 * Flow:
 *   1. li_async_start  → registers a job (transient), fires a non-blocking
 *      loopback to li_async_run, returns the job id instantly.
 *   2. li_async_run    → (detached) executes the registered runner, stores the
 *      result on the job. Token-gated; ignores client disconnect.
 *   3. li_async_poll   → browser polls every few seconds until status=done/error.
 *
 * Add a new long operation by registering a runner in runner().
 */
class LI_Async {

    const TTL = 1200; // 20 min

    public static function boot() {
        add_action('wp_ajax_li_async_start',      [__CLASS__, 'ajax_start']);
        add_action('wp_ajax_li_async_poll',       [__CLASS__, 'ajax_poll']);
        add_action('wp_ajax_li_async_run',        [__CLASS__, 'run']);   // logged-in loopback
        add_action('wp_ajax_nopriv_li_async_run', [__CLASS__, 'run']);   // token-gated loopback (no cookies needed)
    }

    /** Registry: job type → callable returning result (array) or WP_Error. */
    private static function runner($type, $args = []) {
        switch ($type) {
            case 'analysis':
                return function () { return (new LI_Cron())->run_analysis(); };

            case 'partners':
                return function () {
                    $clusters = (new LI_Clusters())->get_cluster_data();
                    if (empty($clusters)) return new WP_Error('li_async', 'Ingen klyngedata — kontrollér at der er publicerede indlæg med kategorier.');
                    // Cap to the strongest clusters — the full set (100+) overflows the token
                    // budget and truncates the JSON. Partnerships belong to your strongest topics.
                    $clusters = array_slice($clusters, 0, 8);
                    $result = (new LI_Claude())->get_partner_suggestions($clusters);
                    if (is_wp_error($result)) return $result;
                    (new LI_Partners())->save($result);
                    return $result;
                };

            case 'competitors':
                return function () {
                    $competitors = (new LI_Competitors())->get_scraped_data(true);
                    if (empty($competitors)) return new WP_Error('li_async', 'Ingen konkurrentdata — tilføj konkurrenter først.');
                    $clusters = (new LI_Clusters())->get_cluster_data();
                    if (empty($clusters)) return new WP_Error('li_async', 'Ingen klyngedata — tjek at indlæg har kategorier.');
                    $clusters = array_slice($clusters, 0, 10); // same overflow guard as partners
                    return (new LI_Claude())->get_competitive_analysis($clusters, $competitors);
                };

            case 'audience':
                return function () use ($args) {
                    $persona = sanitize_textarea_field($args['persona_desc'] ?? '');
                    if ($persona === '') return new WP_Error('li_async', 'Beskriv målgruppen først.');
                    $comp_keys = array_map('sanitize_text_field', (array)($args['comparison_personas'] ?? []));
                    update_option('li_primary_persona', $persona);
                    update_option('li_comparison_personas', $comp_keys);

                    $clusters = (new LI_Clusters())->get_cluster_data();
                    if (empty($clusters)) return new WP_Error('li_async', 'Ingen klyngedata — kør klyngeanalyse først.');
                    $queries  = (new LI_Data())->get_top_queries(60, 30);

                    $audience = new LI_Audience();
                    $all_types = $audience->all_persona_types();
                    $comparison = [];
                    foreach ($comp_keys as $k) if (isset($all_types[$k])) $comparison[$k] = $all_types[$k];

                    $claude  = new LI_Claude();
                    $profile = $claude->get_persona_inference($clusters, $queries, $persona);
                    if (is_wp_error($profile)) return $profile;
                    $resonance = !empty($comparison) ? $claude->get_audience_resonance($clusters, $persona, $comparison) : [];
                    if (is_wp_error($resonance)) $resonance = [];

                    $audience->save_profile($profile);
                    $audience->save_resonance($resonance);
                    return ['profile' => $profile, 'resonance' => $resonance];
                };

            case 'clusters':
                return function () {
                    $clusters = (new LI_Clusters())->get_cluster_data();
                    if (empty($clusters)) return new WP_Error('li_async', 'Ingen klyngedata — tjek at indlæg har kategorier.');
                    // Return ALL clusters for display; send only the top slice to Claude (token guard).
                    $insights = (new LI_Claude())->get_cluster_insights(array_slice($clusters, 0, 15));
                    if (is_wp_error($insights)) {
                        return ['clusters' => $clusters, 'insights' => [], 'insights_error' => $insights->get_error_message()];
                    }
                    return ['clusters' => $clusters, 'insights' => $insights];
                };

            default:
                return null;
        }
    }

    private static function token($job) { return wp_hash('li_async|' . $job); }

    /* ------------------------------------------------------------ 1) start */

    public static function ajax_start() {
        check_ajax_referer('li_async', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Adgang nægtet.']);

        $type = sanitize_key($_POST['type'] ?? '');
        if (!self::runner($type)) wp_send_json_error(['message' => 'Ukendt jobtype.']);

        $args = (isset($_POST['args']) && is_array($_POST['args'])) ? wp_unslash($_POST['args']) : [];

        $job = 'li_job_' . wp_generate_password(16, false);
        set_transient($job, ['status' => 'running', 'type' => $type, 'args' => $args, 'started' => time()], self::TTL);

        // Fire-and-forget loopback: starts the real work in a separate request.
        wp_remote_post(admin_url('admin-ajax.php'), [
            'blocking'   => false,
            'timeout'    => 0.5,
            'sslverify'  => false,
            'body'       => ['action' => 'li_async_run', 'job' => $job, 'token' => self::token($job)],
        ]);

        wp_send_json_success(['job' => $job]);
    }

    /* -------------------------------------------------------------- 2) run */

    public static function run() {
        $job   = isset($_POST['job']) ? sanitize_text_field(wp_unslash($_POST['job'])) : '';
        $token = isset($_POST['token']) ? (string) wp_unslash($_POST['token']) : '';
        if ($job === '' || !hash_equals(self::token($job), $token)) { status_header(403); wp_die('bad token'); }

        $data = get_transient($job);
        if (!$data || ($data['status'] ?? '') !== 'running') wp_die('no job');

        ignore_user_abort(true);
        @set_time_limit(300);

        $runner = self::runner($data['type'], $data['args'] ?? []);
        try {
            $result = $runner ? $runner() : new WP_Error('li_async', 'No runner.');
            if (is_wp_error($result)) {
                set_transient($job, ['status' => 'error', 'message' => $result->get_error_message()], self::TTL);
            } else {
                set_transient($job, ['status' => 'done', 'result' => $result, 'finished' => time()], self::TTL);
            }
        } catch (\Throwable $e) {
            set_transient($job, ['status' => 'error', 'message' => $e->getMessage()], self::TTL);
        }
        wp_die('ok');
    }

    /* ------------------------------------------------------------- 3) poll */

    public static function ajax_poll() {
        check_ajax_referer('li_async', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Adgang nægtet.']);

        $job  = isset($_POST['job']) ? sanitize_text_field(wp_unslash($_POST['job'])) : '';
        $data = get_transient($job);
        if (!$data) wp_send_json_error(['message' => 'Job udløbet — prøv igen.']);
        wp_send_json_success($data);
    }
}
