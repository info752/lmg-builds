<?php
if (!defined('ABSPATH')) exit;

/**
 * LI_Flow — weekly visitor flow ("Besøgsflow") for traveltalk.dk (G 2026-09-24).
 * User experience, not SEO: where do people go, and after a while, for what and why.
 * Four questions per finished week (Mon–Sun, site timezone), from GA4 only:
 *   1. Hero — clicks per slide position and per post (event hero_click from tt-front-hero), CTR vs front-page views.
 *   2. From the front page — top next pages (proxy: pageReferrer = front page; GA4 has no true next-page).
 *   3. Returning vs new — which landing pages each group comes in on.
 *   4. What converts — pages where newsletter signups happen, and the page before.
 * Five runReport calls per build (six if the hero fallback is needed). Built weekly by cron, cached in an option;
 * "Opdatér nu" rebuilds on demand (throttled). Raises LI_Alerts on dead hero slots or a front-page drop-off.
 */
class LI_Flow {

    const HOOK           = 'leisureintel_flow_weekly';
    const OPTION         = 'li_flow_report';
    const LOCK           = 'li_flow_refresh_lock';
    const SIGNUP_EVENTS  = ['concierge_signup', 'match_signup']; // the GA4 signup events LMG actually sends (lmg-concierge, lmg-match)
    const HERO_SLOTS     = 8;     // fallback when tt-front-hero's TT_HERO_LIMIT isn't loaded
    const MIN_FRONT      = 100;   // front-page views a week needs before we alert on it (thin weeks are noise)
    const SHARE_DROP     = 0.25;  // alert when front → next-page share falls more than this week over week
    const TOP            = 10;

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'menu'], 22);
        add_action('admin_init', [__CLASS__, 'schedule']);
        add_action(self::HOOK,   [__CLASS__, 'run']);
        add_action('wp_ajax_li_flow_refresh', [__CLASS__, 'ajax_refresh']);
    }

    public static function menu() {
        add_submenu_page('leisureintel', 'Besøgsflow', 'Besøgsflow', 'manage_options', 'li-flow', [__CLASS__, 'render']);
    }

    /**
     * Self-heal schedule (the plugin is already active, so an activation hook would never fire).
     * Tuesday 06:00 UTC — GA4 needs ~24–48h to settle, so Sunday is complete by then.
     */
    public static function schedule() {
        if (!wp_next_scheduled(self::HOOK)) {
            wp_schedule_event(strtotime('next tuesday 06:00 UTC'), 'weekly', self::HOOK);
        }
    }

    public static function deactivate() {
        wp_clear_scheduled_hook(self::HOOK);
    }

    /** Build, cache and alert. Used by cron and by "Opdatér nu". */
    public static function run() {
        $ga4 = new LI_GA4();
        if (!$ga4->is_configured()) {
            return new WP_Error('li_flow', 'GA4 er ikke konfigureret — se LeisureIntel → Indstillinger.');
        }
        $report = self::build($ga4);
        update_option(self::OPTION, $report, false);
        self::alert($report);
        return $report;
    }

    /** Last finished Mon–Sun week and the one before, in the site timezone (= GA4 property timezone). */
    public static function weeks() {
        $mon = new DateTimeImmutable('monday this week', wp_timezone());
        $cs  = $mon->modify('-7 days');
        $ce  = $mon->modify('-1 day');
        $ps  = $mon->modify('-14 days');
        $pe  = $mon->modify('-8 days');
        return [
            'cur'   => ['startDate' => $cs->format('Y-m-d'), 'endDate' => $ce->format('Y-m-d'), 'name' => 'cur'],
            'prev'  => ['startDate' => $ps->format('Y-m-d'), 'endDate' => $pe->format('Y-m-d'), 'name' => 'prev'],
            'label' => 'Uge ' . $cs->format('W') . ' (' . $cs->format('j/n') . '–' . $ce->format('j/n Y') . ')',
            'key'   => $cs->format('o-\uW'),
        ];
    }

    /** All GA4 calls for one week. Each section fails on its own — one bad query never blanks the page. */
    public static function build($ga4) {
        $w      = self::weeks();
        $both   = [$w['cur'], $w['prev']];
        $calls  = 0;
        $errors = [];
        $report = [
            'built' => current_time('mysql'),
            'week'  => $w['label'],
            'key'   => $w['key'],
            'host'  => wp_parse_url(home_url('/'), PHP_URL_HOST),
        ];

        // 1a. Front-page exposure — the denominator for hero CTR and next-page share.
        $front = ['cur' => ['views' => 0, 'sessions' => 0], 'prev' => ['views' => 0, 'sessions' => 0]];
        $calls++;
        $raw = $ga4->run_report([
            'dateRanges'      => $both,
            'dimensions'      => [['name' => 'pagePath']],
            'metrics'         => [['name' => 'screenPageViews'], ['name' => 'sessions']],
            'dimensionFilter' => self::str_filter('pagePath', '/'),
        ]);
        if (is_wp_error($raw)) {
            $errors['front'] = $raw->get_error_message();
        } else {
            foreach (self::rows($raw) as $r) {
                $k = self::range_key($r);
                $front[$k]['views']    += (int) $r['screenPageViews'];
                $front[$k]['sessions'] += (int) $r['sessions'];
            }
        }
        $report['front'] = $front;

        // 1b. Hero clicks. slide_position is a custom event param — it needs an event-scoped custom
        // dimension in GA4. linkUrl is built in (reads link_url). If slide_position isn't registered,
        // fall back to per-post only and say so.
        $hero_req = [
            'dateRanges'      => $both,
            'dimensions'      => [['name' => 'customEvent:slide_position'], ['name' => 'linkUrl']],
            'metrics'         => [['name' => 'eventCount']],
            'dimensionFilter' => self::str_filter('eventName', 'hero_click'),
            'limit'           => 200,
        ];
        $calls++;
        $raw  = $ga4->run_report($hero_req);
        $note = '';
        if (is_wp_error($raw) && stripos($raw->get_error_message(), 'customEvent') !== false) {
            $note = 'slide_position er ikke registreret som custom dimension i GA4 (Admin → Custom definitions, event-scope, parameter "slide_position") — viser kun klik pr. artikel.';
            $hero_req['dimensions'] = [['name' => 'linkUrl']];
            $calls++;
            $raw = $ga4->run_report($hero_req);
        }
        if (is_wp_error($raw)) {
            $errors['hero'] = $raw->get_error_message();
            $report['hero'] = null;
        } else {
            $report['hero'] = self::shape_hero(self::rows($raw), $front, $note);
        }

        // 2. Next page after the front page. GA4 has no true "next page" dimension; page views whose
        // referrer is the front page are the proxy (tabs, back-button and bfcache can skew it).
        $calls++;
        $raw = $ga4->run_report([
            'dateRanges'      => $both,
            'dimensions'      => [['name' => 'pagePath']],
            'metrics'         => [['name' => 'screenPageViews']],
            'dimensionFilter' => self::str_filter('pageReferrer', self::front_regex(), 'FULL_REGEXP'),
            'orderBys'        => [['metric' => ['metricName' => 'screenPageViews'], 'desc' => true]],
            'limit'           => 100,
        ]);
        if (is_wp_error($raw)) {
            $errors['next'] = $raw->get_error_message();
            $report['next'] = null;
        } else {
            $report['next'] = self::shape_next(self::rows($raw), $front);
        }

        // 3. What returning visitors come back for vs what brings new ones in (landing pages, this week).
        $calls++;
        $raw = $ga4->run_report([
            'dateRanges' => [$w['cur']],
            'dimensions' => [['name' => 'newVsReturning'], ['name' => 'landingPage']],
            'metrics'    => [['name' => 'sessions'], ['name' => 'engagementRate']],
            'orderBys'   => [['metric' => ['metricName' => 'sessions'], 'desc' => true]],
            'limit'      => 250,
        ]);
        if (is_wp_error($raw)) {
            $errors['returning'] = $raw->get_error_message();
            $report['returning'] = null;
        } else {
            $report['returning'] = self::shape_returning(self::rows($raw));
        }

        // 4. What converts: the page a newsletter signup happened on, and the page before it.
        $calls++;
        $raw = $ga4->run_report([
            'dateRanges'      => [$w['cur']],
            'dimensions'      => [['name' => 'eventName'], ['name' => 'pagePath'], ['name' => 'pageReferrer']],
            'metrics'         => [['name' => 'eventCount']],
            'dimensionFilter' => ['filter' => ['fieldName' => 'eventName', 'inListFilter' => ['values' => self::SIGNUP_EVENTS]]],
            'limit'           => 200,
        ]);
        if (is_wp_error($raw)) {
            $errors['converts'] = $raw->get_error_message();
            $report['converts'] = null;
        } else {
            $report['converts'] = self::shape_converts(self::rows($raw));
        }

        $report['errors'] = $errors;
        $report['calls']  = $calls;
        return $report;
    }

    // ── Shaping ────────────────────────────────────────────────────────────────

    private static function shape_hero($rows, $front, $note) {
        $slots = defined('TT_HERO_LIMIT') ? (int) TT_HERO_LIMIT : self::HERO_SLOTS;
        $has_pos = !$note;
        $pos   = [];
        $posts = [];
        $total = ['cur' => 0, 'prev' => 0];
        if ($has_pos) {
            for ($i = 1; $i <= $slots; $i++) $pos[$i] = ['cur' => 0, 'prev' => 0];
        }
        foreach ($rows as $r) {
            $k = self::range_key($r);
            $n = (int) $r['eventCount'];
            $total[$k] += $n;
            if ($has_pos) {
                $p = (int) ($r['customEvent:slide_position'] ?? 0);
                if ($p > 0) {
                    if (!isset($pos[$p])) $pos[$p] = ['cur' => 0, 'prev' => 0];
                    $pos[$p][$k] += $n;
                }
            }
            $path = self::to_path($r['linkUrl'] ?? '');
            if ($path === '') continue;
            if (!isset($posts[$path])) $posts[$path] = ['path' => $path, 'title' => self::title($path), 'cur' => 0, 'prev' => 0];
            $posts[$path][$k] += $n;
        }
        ksort($pos);
        $views = (int) $front['cur']['views'];
        foreach ($pos as $p => &$x) {
            $x['ctr'] = $views > 0 ? round($x['cur'] / $views * 100, 2) : null;
        }
        unset($x);
        uasort($posts, function ($a, $b) { return $b['cur'] <=> $a['cur']; });
        $zero = $has_pos ? array_keys(array_filter($pos, function ($x) { return $x['cur'] === 0; })) : [];
        return [
            'positions' => $pos,
            'posts'     => array_slice(array_values($posts), 0, self::TOP * 2),
            'zero'      => $zero,
            'total'     => $total,
            'note'      => $note,
        ];
    }

    private static function shape_next($rows, $front) {
        $pages = [];
        $sum   = ['cur' => 0, 'prev' => 0];
        foreach ($rows as $r) {
            $path = $r['pagePath'] ?? '';
            if ($path === '' || $path === '/') continue; // reloads of the front page aren't "going somewhere"
            $k = self::range_key($r);
            $n = (int) $r['screenPageViews'];
            $sum[$k] += $n;
            if (!isset($pages[$path])) $pages[$path] = ['path' => $path, 'cur' => 0, 'prev' => 0];
            $pages[$path][$k] += $n;
        }
        uasort($pages, function ($a, $b) { return $b['cur'] <=> $a['cur']; });
        $pages = array_slice(array_values($pages), 0, self::TOP * 2);
        foreach ($pages as &$p) $p['title'] = self::title($p['path']);
        unset($p);

        $sc = $front['cur']['views']  > 0 ? $sum['cur']  / $front['cur']['views']  : null;
        $sp = $front['prev']['views'] > 0 ? $sum['prev'] / $front['prev']['views'] : null;
        return [
            'rows'       => $pages,
            'total'      => $sum,
            'share_cur'  => $sc === null ? null : round($sc * 100, 1),
            'share_prev' => $sp === null ? null : round($sp * 100, 1),
            'change'     => ($sc !== null && $sp) ? round(($sc - $sp) / $sp * 100, 1) : null,
        ];
    }

    private static function shape_returning($rows) {
        $out = ['returning' => [], 'new' => [], 'totals' => ['returning' => 0, 'new' => 0]];
        foreach ($rows as $r) {
            $type = $r['newVsReturning'] ?? '';
            $page = $r['landingPage'] ?? '';
            if (!isset($out[$type]) || $type === 'totals') continue;
            $out['totals'][$type] += (int) $r['sessions'];
            if ($page === '' || $page === '(not set)' || count($out[$type]) >= self::TOP) continue;
            $out[$type][] = [
                'path'       => $page,
                'title'      => self::title($page),
                'sessions'   => (int) $r['sessions'],
                'engagement' => round((float) $r['engagementRate'] * 100),
            ];
        }
        return $out;
    }

    private static function shape_converts($rows) {
        $events = array_fill_keys(self::SIGNUP_EVENTS, 0);
        $pages  = [];
        $refs   = [];
        $total  = 0;
        foreach ($rows as $r) {
            $n = (int) $r['eventCount'];
            $total += $n;
            $events[$r['eventName']] = ($events[$r['eventName']] ?? 0) + $n;
            $path = $r['pagePath'] ?? '';
            if ($path !== '') $pages[$path] = ($pages[$path] ?? 0) + $n;
            $ref = self::ref_label($r['pageReferrer'] ?? '');
            $refs[$ref] = ($refs[$ref] ?? 0) + $n;
        }
        arsort($pages);
        arsort($refs);
        $to_rows = function ($list) {
            $o = [];
            foreach (array_slice($list, 0, self::TOP, true) as $path => $n) {
                $o[] = ['path' => $path, 'title' => self::title($path), 'count' => $n];
            }
            return $o;
        };
        return ['events' => $events, 'total' => $total, 'pages' => $to_rows($pages), 'referrers' => $to_rows($refs)];
    }

    // ── Alerts ─────────────────────────────────────────────────────────────────

    /** Dead hero slots and a front-page drop-off — once per week (the week key is in the title → LI_Alerts dedup). */
    private static function alert($report) {
        if (!class_exists('LI_Alerts')) return;
        $url   = admin_url('admin.php?page=li-flow');
        $week  = $report['key'];
        $front = $report['front'];

        $hero = $report['hero'] ?? null;
        if ($hero && $front['cur']['views'] >= self::MIN_FRONT) {
            if ($hero['total']['cur'] === 0) {
                LI_Alerts::push('flow',
                    "Hero ({$week}): 0 klik på hele forsidens hero",
                    number_format_i18n($front['cur']['views']) . ' forsidevisninger, men ingen hero_click i GA4. Enten virker sliderne ikke, eller målingen er faldet ud — tjek tt-front-hero.',
                    null, $url);
            } elseif (!empty($hero['zero'])) {
                LI_Alerts::push('flow',
                    "Hero ({$week}): " . count($hero['zero']) . ' slide-position(er) uden klik',
                    'Position ' . implode(', ', $hero['zero']) . ' fik 0 klik i ugen trods ' . number_format_i18n($front['cur']['views']) . ' forsidevisninger. Stærkere billede/rubrik — eller færre slides.',
                    null, $url);
            }
        }

        $next = $report['next'] ?? null;
        if ($next && $next['change'] !== null && $front['prev']['views'] >= self::MIN_FRONT
            && $next['change'] < -self::SHARE_DROP * 100) {
            LI_Alerts::push('flow',
                "Forside-flow ({$week}): videre-klik faldet " . number_format_i18n(abs($next['change']), 1) . '% på en uge',
                'Videre-klik pr. 100 forsidevisninger: ' . number_format_i18n($next['share_prev'], 1) . ' → ' . number_format_i18n($next['share_cur'], 1) . '. Forsiden holder ikke på folk — se hvad der har ændret sig.',
                null, $url);
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private static function str_filter($field, $value, $match = 'EXACT') {
        return ['filter' => ['fieldName' => $field, 'stringFilter' => ['matchType' => $match, 'value' => $value]]];
    }

    /** RE2 full-match for the front page as a referrer: http(s), with/without www, optional query/fragment. */
    private static function front_regex() {
        $host = preg_replace('/^www\./', '', (string) wp_parse_url(home_url('/'), PHP_URL_HOST));
        return 'https?://(www\.)?' . preg_quote($host, '') . '/?([?#].*)?';
    }

    /** Response rows → assoc arrays keyed by header name. With 2+ date ranges GA4 appends a "dateRange" value. */
    private static function rows($raw) {
        $dims = array_map(function ($h) { return $h['name']; }, $raw['dimensionHeaders'] ?? []);
        $mets = array_map(function ($h) { return $h['name']; }, $raw['metricHeaders'] ?? []);
        $out  = [];
        foreach ($raw['rows'] ?? [] as $r) {
            $row = [];
            foreach ($r['dimensionValues'] ?? [] as $i => $v) $row[$dims[$i] ?? 'dateRange'] = $v['value'] ?? '';
            foreach ($mets as $i => $n) $row[$n] = (float) ($r['metricValues'][$i]['value'] ?? 0);
            $out[] = $row;
        }
        return $out;
    }

    private static function range_key($row) {
        return (($row['dateRange'] ?? 'cur') === 'prev') ? 'prev' : 'cur';
    }

    private static function to_path($url) {
        $path = (string) wp_parse_url($url, PHP_URL_PATH);
        return $path === '' ? '' : '/' . ltrim($path, '/');
    }

    /** Referrer → our path, or "(ekstern: host)" / "(direkte)" for anything outside the site. */
    private static function ref_label($ref) {
        if ($ref === '' || $ref === '(not set)') return '(direkte)';
        $host = (string) wp_parse_url($ref, PHP_URL_HOST);
        $ours = preg_replace('/^www\./', '', (string) wp_parse_url(home_url('/'), PHP_URL_HOST));
        if (preg_replace('/^www\./', '', $host) !== $ours) return '(ekstern: ' . $host . ')';
        return self::to_path($ref) ?: '/';
    }

    private static function title($path) {
        if ($path === '/') return 'Forsiden';
        if ($path === '' || $path[0] !== '/') return '';
        $id = url_to_postid(home_url($path));
        return $id ? get_the_title($id) : '';
    }

    // ── Admin ──────────────────────────────────────────────────────────────────

    public static function ajax_refresh() {
        check_ajax_referer('li_flow_refresh', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Adgang nægtet.']);
        // Quota guard: one manual rebuild per 5 minutes — each costs 5–6 GA4 runReport calls.
        if (get_transient(self::LOCK)) wp_send_json_error(['message' => 'Rapporten er lige hentet — vent et par minutter.']);
        set_transient(self::LOCK, 1, 5 * MINUTE_IN_SECONDS);
        $res = self::run();
        if (is_wp_error($res)) wp_send_json_error(['message' => $res->get_error_message()]);
        wp_send_json_success(['built' => $res['built']]);
    }

    public static function render() {
        if (!current_user_can('manage_options')) return;
        $r     = get_option(self::OPTION, []);
        $nonce = wp_create_nonce('li_flow_refresh');
        $next  = wp_next_scheduled(self::HOOK);
        $err   = (is_array($r) && !empty($r['errors'])) ? $r['errors'] : [];
        $muted = 'color:#646970;font-size:12px;';
        $box   = 'background:#fff;border:1px solid #ccd0d4;border-radius:8px;padding:14px 18px;margin:16px 0;max-width:980px;';

        echo '<div class="wrap"><h1>Besøgsflow' . (!empty($r['week']) ? ' — ' . esc_html($r['week']) : '') . '</h1>';
        echo '<p><em>Hvor går folk hen — og når de kommer igen: efter hvad, og hvorfor.</em> Brugeroplevelse, ikke SEO. Kilde: GA4, sidste hele uge (man–søn).</p>';
        echo '<p><button class="button button-primary" id="li-flow-refresh" data-nonce="' . esc_attr($nonce) . '">Opdatér nu</button> ';
        echo '<span style="' . $muted . '">';
        echo !empty($r['built']) ? 'Sidst hentet ' . esc_html($r['built']) . ' · ' . (int) $r['calls'] . ' GA4-kald' : 'Ikke hentet endnu';
        echo $next ? ' · næste automatiske kørsel ' . esc_html(wp_date('j/n H:i', $next)) : '';
        echo '</span> <span id="li-flow-msg" style="margin-left:8px;"></span></p>';

        if (empty($r['built'])) {
            echo '<p>Ingen rapport endnu — klik <strong>Opdatér nu</strong>.</p>';
            self::script();
            echo '</div>';
            return;
        }
        $front = $r['front'];

        // 1. Hero
        echo '<div style="' . $box . '"><h2 style="margin-top:0;">1. Hero — hvad klikker folk på?</h2>';
        echo '<p style="' . $muted . '">Forsidevisninger: <strong>' . number_format_i18n($front['cur']['views']) . '</strong> (forrige uge ' . number_format_i18n($front['prev']['views']) . '). '
           . 'CTR = klik ÷ forsidevisninger. Slide N vises først efter ca. (N−1)×5 sek., så lavere CTR på sene positioner er forventet — 0 er det ikke.</p>';
        self::error($err, 'hero');
        $hero = $r['hero'] ?? null;
        if ($hero) {
            if ($hero['note']) echo '<p style="color:#996800;">&#9888; ' . esc_html($hero['note']) . '</p>';
            echo '<p>Klik i alt: <strong>' . number_format_i18n($hero['total']['cur']) . '</strong> (forrige uge ' . number_format_i18n($hero['total']['prev']) . ')</p>';
            if (!empty($hero['positions'])) {
                echo '<table class="widefat striped" style="max-width:640px;"><thead><tr><th>Position</th><th>Klik</th><th>Forrige uge</th><th>CTR</th><th>Status</th></tr></thead><tbody>';
                foreach ($hero['positions'] as $p => $x) {
                    $dead = $x['cur'] === 0;
                    echo '<tr><td><strong>' . (int) $p . '</strong></td><td>' . number_format_i18n($x['cur']) . '</td><td>' . number_format_i18n($x['prev']) . '</td>'
                       . '<td>' . ($x['ctr'] === null ? '—' : esc_html(number_format_i18n($x['ctr'], 2)) . '%') . '</td>'
                       . '<td style="font-weight:600;color:' . ($dead ? '#d63638' : '#1a7f37') . ';">' . ($dead ? '0 KLIK' : 'OK') . '</td></tr>';
                }
                echo '</tbody></table>';
            }
            if (!empty($hero['posts'])) {
                echo '<h3>Pr. artikel</h3>';
                self::table(['Artikel', 'Klik', 'Forrige uge'], array_map(function ($x) {
                    return [self::link($x), number_format_i18n($x['cur']), number_format_i18n($x['prev'])];
                }, $hero['posts']));
            }
        }
        echo '</div>';

        // 2. Next page from the front page
        echo '<div style="' . $box . '"><h2 style="margin-top:0;">2. Hvor går folk hen fra forsiden?</h2>';
        echo '<p style="' . $muted . '"><strong>Tilnærmelse:</strong> GA4 kan ikke give den ægte "næste side". Vi tæller sidevisninger, hvor henvisningen (pageReferrer) er forsiden. '
           . 'Nye faner, tilbage-knap og browser-cache kan skævvride tallene — brug dem til retning og udvikling, ikke som eksakt sti.</p>';
        self::error($err, 'next');
        $next = $r['next'] ?? null;
        if ($next) {
            $chg = $next['change'];
            $col = $chg === null ? '#646970' : ($chg < -self::SHARE_DROP * 100 ? '#d63638' : ($chg < 0 ? '#996800' : '#1a7f37'));
            echo '<p>Videre-klik pr. 100 forsidevisninger: <strong>' . ($next['share_cur'] === null ? '—' : esc_html(number_format_i18n($next['share_cur'], 1))) . '</strong>'
               . ' (forrige uge ' . ($next['share_prev'] === null ? '—' : esc_html(number_format_i18n($next['share_prev'], 1))) . ')'
               . ($chg === null ? '' : ' <span style="font-weight:600;color:' . $col . ';">' . ($chg > 0 ? '+' : '') . esc_html(number_format_i18n($chg, 1)) . '%</span>') . '</p>';
            $tot = max(1, $next['total']['cur']);
            self::table(['Næste side', 'Visninger', 'Forrige uge', 'Andel'], array_map(function ($x) use ($tot) {
                return [self::link($x), number_format_i18n($x['cur']), number_format_i18n($x['prev']), number_format_i18n($x['cur'] / $tot * 100, 1) . '%'];
            }, $next['rows']));
        }
        echo '</div>';

        // 3. Returning vs new
        echo '<div style="' . $box . '"><h2 style="margin-top:0;">3. Hvad kommer de tilbagevendende for?</h2>';
        echo '<p style="' . $muted . '">Landingssider (første side i besøget) for tilbagevendende vs. nye brugere. Engagement = andel engagerede sessioner.</p>';
        self::error($err, 'returning');
        $ret = $r['returning'] ?? null;
        if ($ret) {
            echo '<div style="display:flex;flex-wrap:wrap;gap:18px;">';
            foreach (['returning' => 'Tilbagevendende', 'new' => 'Nye'] as $k => $lbl) {
                echo '<div style="flex:1 1 420px;min-width:0;"><h3>' . $lbl . ' <span style="' . $muted . '">(' . number_format_i18n($ret['totals'][$k]) . ' sessioner)</span></h3>';
                self::table(['Landingsside', 'Sessioner', 'Engagement'], array_map(function ($x) {
                    return [self::link($x), number_format_i18n($x['sessions']), (int) $x['engagement'] . '%'];
                }, $ret[$k]));
                echo '</div>';
            }
            echo '</div>';
        }
        echo '</div>';

        // 4. What converts
        echo '<div style="' . $box . '"><h2 style="margin-top:0;">4. Hvad konverterer?</h2>';
        echo '<p style="' . $muted . '">Nyhedsbrevstilmeldinger (GA4-events: ' . esc_html(implode(', ', self::SIGNUP_EVENTS)) . ' — fra AInna/concierge og Match). '
           . '"Siden før" er henvisningen på den side, hvor tilmeldingen skete.</p>';
        self::error($err, 'converts');
        $conv = $r['converts'] ?? null;
        if ($conv) {
            $parts = [];
            foreach ($conv['events'] as $e => $n) $parts[] = esc_html($e) . ': ' . number_format_i18n($n);
            echo '<p>Tilmeldinger i alt: <strong>' . number_format_i18n($conv['total']) . '</strong> <span style="' . $muted . '">(' . implode(' · ', $parts) . ')</span></p>';
            if ($conv['total'] > 0) {
                echo '<div style="display:flex;flex-wrap:wrap;gap:18px;">';
                foreach (['pages' => 'Side hvor tilmeldingen skete', 'referrers' => 'Siden før'] as $k => $lbl) {
                    echo '<div style="flex:1 1 420px;min-width:0;"><h3>' . $lbl . '</h3>';
                    self::table(['Side', 'Tilmeldinger'], array_map(function ($x) {
                        return [self::link($x), number_format_i18n($x['count'])];
                    }, $conv[$k]));
                    echo '</div>';
                }
                echo '</div>';
            }
        }
        echo '</div>';

        if (!empty($err['front'])) {
            echo '<div class="notice notice-error inline"><p>Forsidevisninger kunne ikke hentes (CTR og andele mangler): ' . esc_html($err['front']) . '</p></div>';
        }
        self::script();
        echo '</div>';
    }

    private static function error($errors, $key) {
        if (!empty($errors[$key])) {
            echo '<div class="notice notice-error inline"><p>GA4-fejl: ' . esc_html($errors[$key]) . '</p></div>';
        }
    }

    /** Title (or path) linked to the live page. Cells passed to table() are pre-escaped HTML. */
    private static function link($x) {
        $path = $x['path'];
        $text = $x['title'] !== '' ? $x['title'] : $path;
        if ($path === '' || $path[0] !== '/') return esc_html($text);
        $sub = $x['title'] !== '' ? ' <span style="color:#646970;font-size:11px;">' . esc_html($path) . '</span>' : '';
        return '<a href="' . esc_url(home_url($path)) . '" target="_blank" rel="noopener">' . esc_html($text) . '</a>' . $sub;
    }

    private static function table($head, $rows) {
        if (empty($rows)) { echo '<p style="color:#646970;">Ingen data for ugen.</p>'; return; }
        echo '<table class="widefat striped"><thead><tr>';
        foreach ($head as $h) echo '<th>' . esc_html($h) . '</th>';
        echo '</tr></thead><tbody>';
        foreach ($rows as $row) {
            echo '<tr>';
            foreach ($row as $cell) echo '<td>' . $cell . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    private static function script() {
        echo '<script>(function($){$("#li-flow-refresh").on("click",function(){var b=$(this),m=$("#li-flow-msg");b.prop("disabled",true).text("Henter fra GA4…");m.text("");'
           . '$.post(ajaxurl,{action:"li_flow_refresh",nonce:b.data("nonce")},function(r){if(r.success){location.reload();return;}'
           . 'b.prop("disabled",false).text("Opdatér nu");m.css("color","#d63638").text((r.data&&r.data.message)||"Fejl");})'
           . '.fail(function(){b.prop("disabled",false).text("Opdatér nu");m.css("color","#d63638").text("Netværksfejl — prøv igen.");});});})(jQuery);</script>';
    }
}
