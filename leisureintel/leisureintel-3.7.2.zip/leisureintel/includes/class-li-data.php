<?php
if (!defined('ABSPATH')) exit;

class LI_Data {

    /**
     * Pull top performing pages from RankMath GSC data for N days.
     */
    public function get_top_gsc_pages($limit = 20, $days = 30) {
        global $wpdb;

        $sql = $wpdb->prepare(
            "SELECT page,
                    SUM(clicks) as total_clicks,
                    SUM(impressions) as total_impressions,
                    AVG(position) as avg_position
             FROM {$wpdb->prefix}rank_math_analytics_gsc
             WHERE created >= DATE_SUB(NOW(), INTERVAL %d DAY)
             GROUP BY page
             ORDER BY total_clicks DESC
             LIMIT %d",
            $days,
            $limit
        );

        return $wpdb->get_results($sql) ?: [];
    }

    /**
     * Build a URL → GSC row lookup for all indexed pages (last 30 days).
     * Used by content audit.
     */
    public function get_gsc_lookup_all() {
        global $wpdb;

        $rows = $wpdb->get_results(
            "SELECT page,
                    SUM(clicks) as total_clicks,
                    SUM(impressions) as total_impressions,
                    AVG(position) as avg_position
             FROM {$wpdb->prefix}rank_math_analytics_gsc
             WHERE created >= DATE_SUB(NOW(), INTERVAL 30 DAY)
             GROUP BY page"
        );

        $lookup = [];
        foreach ($rows as $row) {
            $lookup[$row->page] = $row;
        }
        return $lookup;
    }

    /**
     * Get position averages for the 90-day window (for momentum calculation).
     * Returns array keyed by page URL.
     */
    private function get_90d_positions($limit = 50) {
        global $wpdb;

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT page, AVG(position) as avg_position
             FROM {$wpdb->prefix}rank_math_analytics_gsc
             WHERE created >= DATE_SUB(NOW(), INTERVAL 90 DAY)
               AND created < DATE_SUB(NOW(), INTERVAL 30 DAY)
             GROUP BY page
             LIMIT %d",
            $limit
        ));

        $result = [];
        foreach ($rows as $row) {
            $result[$row->page] = round((float)$row->avg_position, 1);
        }
        return $result;
    }

    /**
     * Calculate a predictive confidence score (1–10) from data signals.
     */
    public function calculate_confidence($item) {
        $score       = 5.0;
        $pos         = (float)($item['avg_position'] ?? 0);
        $impressions = (int)($item['total_impressions'] ?? 0);
        $clicks      = (int)($item['total_clicks'] ?? 0);
        $momentum    = (float)($item['momentum'] ?? 0);
        $session     = isset($item['avg_session_duration']) ? (float)$item['avg_session_duration'] : null;
        $bounce      = isset($item['bounce_rate']) ? (float)$item['bounce_rate'] : null;

        // Position bonus: sweet spot 4–20 (room to climb)
        if ($pos >= 4 && $pos <= 10)  $score += 1.5;
        elseif ($pos >= 11 && $pos <= 20) $score += 1.0;
        elseif ($pos <= 3)            $score += 0.5;

        // CTR gap: impressions without clicks = untapped intent
        if ($impressions > 0) {
            $expected = $this->expected_ctr($pos);
            $actual   = $clicks / $impressions;
            $ratio    = $expected > 0 ? $actual / $expected : 1;
            if ($ratio < 0.5)  $score += 1.5;
            elseif ($ratio < 0.75) $score += 0.75;
        }

        // Momentum: position improved in 30d vs prior 60d window
        if ($momentum > 3)       $score += 1.0;
        elseif ($momentum > 1)   $score += 0.5;
        elseif ($momentum < -3)  $score -= 0.5;

        // GA4 engagement quality
        if ($session !== null && $bounce !== null) {
            if ($session > 180 || $bounce < 40) $score += 1.0;
            elseif ($session > 90 || $bounce < 60) $score += 0.5;
        }

        // Volume floor: low impression pages are speculative
        if ($impressions < 20)  $score = min($score, 6.0);
        elseif ($impressions < 50) $score = min($score, 7.5);

        return (int)max(1, min(10, round($score)));
    }

    private function expected_ctr($pos) {
        $table = [1 => 0.28, 2 => 0.15, 3 => 0.11, 4 => 0.08, 5 => 0.07,
                  6 => 0.05, 7 => 0.04, 8 => 0.03, 9 => 0.03, 10 => 0.03];
        $p = (int)round($pos);
        if (isset($table[$p]))  return $table[$p];
        if ($p > 10 && $p <= 20) return 0.01;
        return 0.005;
    }

    /**
     * Detect seasonal/trending signals: compare 30d click rate vs 90d baseline.
     * Returns 'trending', 'seasonal_peak', 'seasonal_trough', or '' (neutral).
     */
    private function detect_season_signal($item_30d, $item_90d_clicks) {
        $clicks_30d = (int)($item_30d['total_clicks'] ?? 0);
        $impr_30d   = (int)($item_30d['total_impressions'] ?? 0);

        if ($impr_30d < 10 || $item_90d_clicks === null) return '';

        // Annualise: 30d rate × 3 vs 90d total
        $rate_30d_annualised = $clicks_30d * 3;
        $diff = $rate_30d_annualised - $item_90d_clicks;
        $pct  = $item_90d_clicks > 0 ? ($diff / $item_90d_clicks) : 0;

        if ($pct > 0.5)   return 'trending';
        if ($pct > 0.25)  return 'seasonal_peak';
        if ($pct < -0.25) return 'seasonal_trough';
        return '';
    }

    /**
     * Enrich GSC rows with post title, categories, GA4 data, momentum, season signal.
     */
    public function enrich_with_post_data($gsc_rows, $ga4_metrics = [], $positions_90d = []) {
        $enriched = [];

        foreach ($gsc_rows as $row) {
            $item = [
                'page'              => $row->page,
                'total_clicks'      => (int)$row->total_clicks,
                'total_impressions' => (int)$row->total_impressions,
                'avg_position'      => round((float)$row->avg_position, 1),
                'title'             => '',
                'categories'        => '',
                'momentum'          => 0,
                'season_signal'     => '',
            ];

            // Momentum: position_90d - position_30d (positive = gaining rank)
            $pos_90d = $positions_90d[$row->page] ?? null;
            if ($pos_90d !== null) {
                $item['momentum'] = round($pos_90d - $item['avg_position'], 1);
            }

            // GA4 enrichment — match by path
            $path = $this->url_to_path($row->page);
            $path_key = '/' . ltrim($path, '/');
            $ga4 = $ga4_metrics[$path_key] ?? $ga4_metrics[rtrim($path_key, '/')] ?? null;
            if ($ga4) {
                $item['pageviews']            = $ga4['pageviews'];
                $item['users']                = $ga4['users'];
                $item['avg_session_duration'] = $ga4['avg_session_duration'];
                $item['bounce_rate']          = $ga4['bounce_rate'];
            }

            // Seasonal detection (needs 90d click data)
            // We'll pass 90d total clicks via positions_90d array under a parallel key — handled in get_analysis_dataset
            $item['season_signal'] = ''; // set below in get_analysis_dataset

            // WordPress post data
            if ($path) {
                global $wpdb;
                $slug = basename(untrailingslashit($path));
                $post = $wpdb->get_row($wpdb->prepare(
                    "SELECT ID, post_title FROM {$wpdb->posts} WHERE post_name = %s AND post_status = 'publish' LIMIT 1",
                    $slug
                ));

                if (!$post) {
                    $post = get_page_by_path($path, OBJECT, 'post');
                }

                if ($post) {
                    $item['title']      = $post->post_title;
                    $cats               = wp_get_post_categories($post->ID, ['fields' => 'names']);
                    $item['categories'] = implode(', ', $cats);
                }
            }

            // Calculate predictive confidence
            $item['confidence'] = $this->calculate_confidence($item);

            $enriched[] = $item;
        }

        return $enriched;
    }

    /**
     * Full enriched dataset ready for Claude analysis.
     */
    public function get_analysis_dataset($limit = 20) {
        $gsc_30d = $this->get_top_gsc_pages($limit, 30);
        if (empty($gsc_30d)) return [];

        // 90-day positions for momentum
        $positions_90d = $this->get_90d_positions($limit * 2);

        // GA4 enrichment (non-blocking — skip if not configured)
        $ga4_metrics = [];
        $ga4 = new LI_GA4();
        if ($ga4->is_configured()) {
            $result = $ga4->get_page_metrics(30);
            if (!is_wp_error($result)) {
                $ga4_metrics = $result;
            }
        }

        $enriched = $this->enrich_with_post_data($gsc_30d, $ga4_metrics, $positions_90d);

        // Seasonal signal: compare 30d clicks vs 90d total for same pages
        $gsc_90d_lookup = [];
        $rows_90d = $this->get_top_gsc_pages($limit * 3, 90);
        foreach ($rows_90d as $row) {
            $gsc_90d_lookup[$row->page] = (int)$row->total_clicks;
        }

        foreach ($enriched as &$item) {
            $clicks_90d = $gsc_90d_lookup[$item['page']] ?? null;
            if ($clicks_90d !== null) {
                $clicks_30d = $item['total_clicks'];
                $rate_30d_x3 = $clicks_30d * 3;
                $diff = $clicks_90d > 0 ? ($rate_30d_x3 - $clicks_90d) / $clicks_90d : 0;
                if ($diff > 0.5)      $item['season_signal'] = 'trending';
                elseif ($diff > 0.25) $item['season_signal'] = 'seasonal_peak';
                elseif ($diff < -0.25) $item['season_signal'] = 'seasonal_trough';
            }
        }
        unset($item);

        return $enriched;
    }

    private function url_to_path($url) {
        $site_url = trailingslashit(get_site_url());
        if (strpos($url, $site_url) === 0) {
            return substr($url, strlen($site_url));
        }
        $parsed = parse_url($url);
        return isset($parsed['path']) ? ltrim($parsed['path'], '/') : '';
    }

    /**
     * Top search queries from GSC — used for persona inference.
     */
    public function get_top_queries($limit = 60, $days = 30) {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT query, SUM(clicks) as clicks, SUM(impressions) as impressions, AVG(position) as avg_position
             FROM {$wpdb->prefix}rank_math_analytics_gsc
             WHERE created >= DATE_SUB(NOW(), INTERVAL %d DAY)
             AND query != ''
             GROUP BY query
             ORDER BY clicks DESC
             LIMIT %d",
            $days, $limit
        )) ?: [];
    }
}
