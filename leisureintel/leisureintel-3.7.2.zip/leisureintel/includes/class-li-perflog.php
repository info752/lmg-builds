<?php
if (!defined('ABSPATH')) exit;

/**
 * LeisureIntel — Performance Log (Module 2 of the Search-Intent loop).
 *
 * Closes LeisureIntel's loop: predict (Analyse) -> produce (Writer) -> PROVE.
 * Logs every headline version an article carries and measures the REAL
 * before/after search performance of each rewrite, read from the same
 * Rank Math GSC table LI_Data already uses ({prefix}rank_math_analytics_gsc).
 * No new GSC connection — Rank Math holds the per-property OAuth.
 *
 * HARD RULE: a delta is NEVER reported off a sample too small to trust.
 * compare() always computes the raw before/after numbers (shown as diagnostics)
 * but only fills `delta` when the validity gate passes: enough time elapsed
 * AND enough clicks/impressions in BOTH windows. Otherwise it says exactly
 * what is still missing — diagnostic, not hidden.
 */
class LI_Perflog {

    const TABLE      = 'li_headline_versions';
    const DB_VERSION = '1';

    /* ------------------------------------------------------------- Bootstrap */

    public static function boot() {
        // Table DDL only ever runs in admin context — never on a front-end request.
        add_action('admin_init', [__CLASS__, 'ensure_table']);
        add_action('admin_post_li_perflog_add',        [__CLASS__, 'handle_add']);
        add_action('admin_post_li_perflog_delete',     [__CLASS__, 'handle_delete']);
        add_action('admin_post_li_perflog_thresholds', [__CLASS__, 'handle_thresholds']);
        add_action('admin_notices',                    [__CLASS__, 'admin_notice']);
    }

    /** Shows the li_notice confirmation after any Search-Intent admin-post redirect. */
    public static function admin_notice() {
        if (empty($_GET['page']) || $_GET['page'] !== 'leisureintel' || empty($_GET['li_notice'])) return;
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html(rawurldecode(wp_unslash($_GET['li_notice']))) . '</p></div>';
    }

    private static function table() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE;
    }

    /** Idempotent — survives file-overwrite deploys (runs once per DB_VERSION). Hooked on admin_init. */
    public static function ensure_table() {
        if (get_option('li_perflog_db_version') === self::DB_VERSION) return;
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE " . self::table() . " (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            url VARCHAR(500) NOT NULL DEFAULT '',
            version_number INT NOT NULL DEFAULT 1,
            headline TEXT NOT NULL,
            effective_date DATE NOT NULL,
            note TEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY post_id (post_id),
            KEY url (url(191))
        ) {$charset};";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
        update_option('li_perflog_db_version', self::DB_VERSION);
    }

    /* ------------------------------------------------------------- Log (CRUD) */

    public static function add_version($post_id, $headline, $effective_date, $note = '') {
        global $wpdb;
        $post_id = (int) $post_id;
        $url = $post_id ? esc_url_raw(get_permalink($post_id)) : '';
        $next = 1 + (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(MAX(version_number),0) FROM " . self::table() . " WHERE post_id = %d", $post_id
        ));
        $ok = $wpdb->insert(self::table(), [
            'post_id'        => $post_id,
            'url'            => $url,
            'version_number' => $next,
            'headline'       => wp_strip_all_tags($headline),
            'effective_date' => $effective_date,
            'note'           => sanitize_text_field($note),
            'created_at'     => current_time('mysql'),
        ], ['%d','%s','%d','%s','%s','%s','%s']);
        return $ok ? $wpdb->insert_id : false;
    }

    public static function get_versions($post_id) {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . self::table() . " WHERE post_id = %d ORDER BY version_number ASC", (int) $post_id
        )) ?: [];
    }

    public static function get_tracked_post_ids() {
        global $wpdb;
        return $wpdb->get_col("SELECT DISTINCT post_id FROM " . self::table() . " ORDER BY post_id DESC") ?: [];
    }

    public static function delete_version($id) {
        global $wpdb;
        return $wpdb->delete(self::table(), ['id' => (int) $id], ['%d']);
    }

    /* --------------------------------------------------------------- GSC read */

    private static function gsc_table() {
        global $wpdb;
        return $wpdb->prefix . 'rank_math_analytics_gsc';
    }

    public static function gsc_available() {
        global $wpdb;
        $t = self::gsc_table();
        return $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $t)) === $t;
    }

    /** Aggregate metrics over [$start,$end) (dates 'Y-m-d', end exclusive). Position impression-weighted. */
    private static function window_metrics($url, $start, $end) {
        global $wpdb;
        $variants = self::url_variants($url);
        $ph = implode(',', array_fill(0, count($variants), '%s'));
        $sql = "SELECT COALESCE(SUM(clicks),0) AS clicks,
                       COALESCE(SUM(impressions),0) AS impressions,
                       CASE WHEN SUM(impressions) > 0 THEN SUM(position*impressions)/SUM(impressions) ELSE AVG(position) END AS position
                FROM " . self::gsc_table() . "
                WHERE page IN ($ph) AND created >= %s AND created < %s";
        $row = $wpdb->get_row($wpdb->prepare($sql, array_merge($variants, [$start, $end])), ARRAY_A);
        $clicks = (int) ($row['clicks'] ?? 0);
        $impr   = (int) ($row['impressions'] ?? 0);
        return [
            'clicks'      => $clicks,
            'impressions' => $impr,
            'position'    => (isset($row['position']) && $row['position'] !== null) ? round((float)$row['position'], 1) : null,
            'ctr'         => $impr > 0 ? $clicks / $impr : 0.0,
        ];
    }

    private static function url_variants($url) {
        $url = trim((string) $url);
        if ($url === '') return [''];
        // Rank Math GSC stores relative PATHS — match on path first, full URL as fallback.
        $path = parse_url($url, PHP_URL_PATH);
        $variants = [];
        if ($path) {
            $noslash = rtrim($path, '/');
            $variants[] = $path;
            $variants[] = $noslash;
            $variants[] = $noslash . '/';
        }
        $variants[] = $url;
        $variants[] = rtrim($url, '/');
        return array_values(array_unique(array_filter($variants, fn($v) => $v !== '')));
    }

    /* ---------------------------------------------------- Compare + the gate */

    public static function thresholds() {
        return [
            'window_days'     => max(7, (int) get_option('li_perflog_window_days', 28)),
            'min_clicks'      => max(1, (int) get_option('li_perflog_min_clicks', 15)),
            'min_impressions' => max(1, (int) get_option('li_perflog_min_impressions', 300)),
        ];
    }

    public static function compare($url, $effective_date) {
        $t = self::thresholds();
        $window = $t['window_days'];
        $day = DAY_IN_SECONDS;
        $split = strtotime($effective_date . ' 00:00:00');
        $today = strtotime(current_time('Y-m-d') . ' 00:00:00');

        $before_start = date('Y-m-d', $split - $window * $day);
        $before_end   = date('Y-m-d', $split);
        $after_start  = date('Y-m-d', $split);
        $after_end    = date('Y-m-d', min($split + $window * $day, $today + $day));

        $before = self::window_metrics($url, $before_start, $before_end);
        $after  = self::window_metrics($url, $after_start, $after_end);
        $elapsed = (int) floor(($today - $split) / $day);

        $reasons = [];
        if ($elapsed < $window) {
            $reasons[] = sprintf('Only %d of %d days elapsed since the rewrite — needs %d more day(s) for a full after-window.',
                max(0, $elapsed), $window, $window - $elapsed);
        }
        self::sample_reasons($before, 'before', $t, $reasons);
        if ($elapsed >= $window) self::sample_reasons($after, 'after', $t, $reasons);

        $status = empty($reasons) ? 'ok' : 'insufficient';
        return [
            'status'       => $status,
            'reasons'      => $reasons,
            'window_days'  => $window,
            'elapsed_days' => $elapsed,
            'before'       => $before,
            'after'        => $after,
            'before_range' => [$before_start, $before_end],
            'after_range'  => [$after_start, $after_end],
            'delta'        => ($status === 'ok') ? self::delta($before, $after) : null,
        ];
    }

    private static function sample_reasons($m, $label, $t, &$reasons) {
        if ($m['clicks'] < $t['min_clicks'])
            $reasons[] = sprintf('%s window has %d clicks — needs %d (%d short).',
                ucfirst($label), $m['clicks'], $t['min_clicks'], $t['min_clicks'] - $m['clicks']);
        if ($m['impressions'] < $t['min_impressions'])
            $reasons[] = sprintf('%s window has %d impressions — needs %d (%d short).',
                ucfirst($label), $m['impressions'], $t['min_impressions'], $t['min_impressions'] - $m['impressions']);
    }

    private static function delta($b, $a) {
        $ctr_b = $b['ctr'] * 100; $ctr_a = $a['ctr'] * 100;
        return [
            'clicks_rel'      => self::rel($b['clicks'], $a['clicks']),
            'impressions_rel' => self::rel($b['impressions'], $a['impressions']),
            'ctr_before_pct'  => round($ctr_b, 2),
            'ctr_after_pct'   => round($ctr_a, 2),
            'ctr_pp'          => round($ctr_a - $ctr_b, 2),
            'position_before' => $b['position'],
            'position_after'  => $a['position'],
            'position_gain'   => ($b['position'] !== null && $a['position'] !== null) ? round($b['position'] - $a['position'], 1) : null,
        ];
    }

    private static function rel($b, $a) {
        if ($b == 0) return null;
        return round((($a - $b) / $b) * 100, 1);
    }

    /* ------------------------------------------------------- Form handlers */

    private static function redirect($notice) {
        wp_safe_redirect(add_query_arg(
            ['page' => 'leisureintel', 'li_active' => 'perflog', 'li_notice' => rawurlencode($notice)],
            admin_url('admin.php')
        ));
        exit;
    }

    public static function handle_add() {
        if (!current_user_can('manage_options')) wp_die('Denied');
        check_admin_referer('li_perflog_add');
        $post_id  = (int) ($_POST['post_id'] ?? 0);
        $headline = trim(wp_unslash($_POST['headline'] ?? ''));
        $date     = trim($_POST['effective_date'] ?? '');
        $note     = trim(wp_unslash($_POST['note'] ?? ''));

        if (!$post_id || !get_post($post_id))                self::redirect('Unknown post ID.');
        if ($headline === '')                                self::redirect('Headline is required.');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date))     self::redirect('Effective date must be YYYY-MM-DD.');

        self::add_version($post_id, $headline, $date, $note);
        self::redirect('Version logged.');
    }

    public static function handle_delete() {
        if (!current_user_can('manage_options')) wp_die('Denied');
        check_admin_referer('li_perflog_delete');
        self::delete_version((int) ($_POST['id'] ?? 0));
        self::redirect('Version deleted.');
    }

    public static function handle_thresholds() {
        if (!current_user_can('manage_options')) wp_die('Denied');
        check_admin_referer('li_perflog_thresholds');
        update_option('li_perflog_window_days',     max(7, (int) ($_POST['window_days'] ?? 28)));
        update_option('li_perflog_min_clicks',       max(1, (int) ($_POST['min_clicks'] ?? 15)));
        update_option('li_perflog_min_impressions',  max(1, (int) ($_POST['min_impressions'] ?? 300)));
        self::redirect('Thresholds saved.');
    }

    /* --------------------------------------------------------------- Render */

    public static function render_pane() {
        $t = self::thresholds();
        $post_url = esc_url(admin_url('admin-post.php'));
        ?>
        <h2>Performance Log <span style="font-size:12px;color:#666;font-weight:normal;">— proves what a rewrite actually did</span></h2>
        <p>Real before/after search performance from your Rank Math GSC data. A delta only appears once the sample is big enough and enough time has passed — otherwise you see exactly what's still missing. Thresholds are per site.</p>

        <?php if (!self::gsc_available()): ?>
            <div class="notice notice-error inline"><p><strong>Rank Math GSC analytics table not found.</strong> Connect Search Console in Rank Math → Analytics; this reads that data.</p></div>
        <?php endif; ?>

        <!-- Log a version -->
        <form method="post" action="<?php echo $post_url; ?>" style="background:#fff;border:1px solid #ccd0d4;padding:12px 16px;max-width:820px;margin-bottom:18px;">
            <?php wp_nonce_field('li_perflog_add'); ?>
            <input type="hidden" name="action" value="li_perflog_add">
            <h3 style="margin-top:0;">Log a headline version</h3>
            <p><label><strong>Post ID</strong><br><input type="number" name="post_id" class="small-text" required> <span class="description">URL is resolved automatically.</span></label></p>
            <p><label><strong>Headline</strong><br><input type="text" name="headline" class="large-text" required placeholder="The exact headline this version carries"></label></p>
            <p><label><strong>Effective date</strong><br><input type="date" name="effective_date" value="<?php echo esc_attr(current_time('Y-m-d')); ?>" required></label> <span class="description">Version 1 = original; later entries are rewrites, compared against this date.</span></p>
            <p><label><strong>Note</strong><br><input type="text" name="note" class="large-text" placeholder="Optional — why you changed it"></label></p>
            <button class="button button-primary">Log version</button>
        </form>

        <?php self::render_tracked(); ?>

        <!-- Thresholds -->
        <form method="post" action="<?php echo $post_url; ?>" style="background:#f6f7f7;border:1px solid #ccd0d4;padding:12px 16px;max-width:820px;margin-top:22px;">
            <?php wp_nonce_field('li_perflog_thresholds'); ?>
            <input type="hidden" name="action" value="li_perflog_thresholds">
            <h3 style="margin-top:0;">Validity thresholds</h3>
            <p>Window (days each side): <input type="number" name="window_days" value="<?php echo esc_attr($t['window_days']); ?>" class="small-text" min="7">
               &nbsp; Min clicks/window: <input type="number" name="min_clicks" value="<?php echo esc_attr($t['min_clicks']); ?>" class="small-text" min="1">
               &nbsp; Min impressions/window: <input type="number" name="min_impressions" value="<?php echo esc_attr($t['min_impressions']); ?>" class="small-text" min="1">
               &nbsp; <button class="button">Save thresholds</button></p>
        </form>

        <script>
        // Re-open this tab after an admin-post redirect (reuses LeisureIntel's tab buttons).
        // Deferred to DOMContentLoaded so the tab click-handler is bound first.
        document.addEventListener('DOMContentLoaded', function(){
            if (location.search.indexOf('li_active=perflog') === -1) return;
            var b = document.querySelector('.li-tab-btn[data-tab="perflog"]');
            if (b) b.click();
        });
        </script>
        <?php
    }

    private static function render_tracked() {
        $ids = self::get_tracked_post_ids();
        if (!$ids) { echo '<p><em>No articles tracked yet. Log the original headline above to start.</em></p>'; return; }
        foreach ($ids as $pid) {
            $versions = self::get_versions($pid);
            if (!$versions) continue;
            $title = get_the_title($pid) ?: '(missing post)';
            $url   = $versions[count($versions) - 1]->url;

            echo '<div style="background:#fff;border:1px solid #ccd0d4;padding:14px 18px;margin-bottom:16px;">';
            echo '<h3 style="margin-top:0;">' . esc_html($title) . ' <span style="font-weight:normal;color:#666;">(ID ' . (int)$pid . ')</span></h3>';
            if ($url) echo '<p style="margin:0 0 10px;"><a href="' . esc_url($url) . '" target="_blank">' . esc_html($url) . '</a></p>';

            echo '<table class="widefat striped" style="margin-bottom:10px;"><thead><tr><th>#</th><th>Headline</th><th>Effective</th><th>Note</th><th></th></tr></thead><tbody>';
            foreach ($versions as $v) {
                echo '<tr><td>' . ($v->version_number == 1 ? 'orig' : 'rw' . ($v->version_number - 1)) . '</td>';
                echo '<td>' . esc_html($v->headline) . '</td><td>' . esc_html($v->effective_date) . '</td><td>' . esc_html($v->note) . '</td><td>';
                echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" onsubmit="return confirm(\'Delete this version?\');" style="margin:0;">';
                wp_nonce_field('li_perflog_delete');
                echo '<input type="hidden" name="action" value="li_perflog_delete"><input type="hidden" name="id" value="' . (int)$v->id . '">';
                echo '<button class="button-link-delete" style="color:#b32d2e;">delete</button></form></td></tr>';
            }
            echo '</tbody></table>';

            for ($i = 1; $i < count($versions); $i++) {
                self::render_comparison($versions[$i], self::compare($url ?: $versions[$i]->url, $versions[$i]->effective_date));
            }
            echo '</div>';
        }
    }

    private static function render_comparison($to, $cmp) {
        echo '<div style="border-left:4px solid #2271b1;padding:8px 14px;margin:0 0 12px;background:#f6f7f7;">';
        echo '<strong>Rewrite ' . ($to->version_number - 1) . ' — split ' . esc_html($to->effective_date)
           . ' (window ' . (int)$cmp['window_days'] . ' days each side)</strong>';

        if ($cmp['status'] === 'insufficient') {
            echo '<div style="margin:6px 0;padding:6px 10px;background:#fcf3cd;border:1px solid #dba617;"><strong>Insufficient data yet</strong> — no delta reported (by design). Still needed:<ul style="margin:6px 0 0 18px;list-style:disc;">';
            foreach ($cmp['reasons'] as $r) echo '<li>' . esc_html($r) . '</li>';
            echo '</ul></div>';
        } else {
            $d = $cmp['delta'];
            echo '<div style="margin:6px 0;padding:6px 10px;background:#edfaef;border:1px solid #46b450;"><strong>Validated comparison</strong> — sample and time thresholds cleared.</div>';
            echo '<table class="widefat"><thead><tr><th>Metric</th><th>Before</th><th>After</th><th>Change</th></tr></thead><tbody>';
            self::row('Clicks', $cmp['before']['clicks'], $cmp['after']['clicks'], self::pct($d['clicks_rel']));
            self::row('Impressions', $cmp['before']['impressions'], $cmp['after']['impressions'], self::pct($d['impressions_rel']));
            self::row('CTR', $d['ctr_before_pct'] . '%', $d['ctr_after_pct'] . '%', ($d['ctr_pp'] >= 0 ? '+' : '') . $d['ctr_pp'] . ' pp');
            $pos = ($d['position_gain'] === null) ? '—' : (($d['position_gain'] >= 0 ? 'up ' : 'down ') . abs($d['position_gain']) . ' pos');
            self::row('Avg position', $d['position_before'] ?? '—', $d['position_after'] ?? '—', $pos);
            echo '</tbody></table>';
        }
        echo '<p class="description" style="margin:6px 0 0;">Before ' . esc_html($cmp['before_range'][0]) . ' → ' . esc_html($cmp['before_range'][1])
           . ' · After ' . esc_html($cmp['after_range'][0]) . ' → ' . esc_html($cmp['after_range'][1])
           . ' · ' . (int)$cmp['elapsed_days'] . ' days since rewrite.</p></div>';
    }

    private static function row($m, $b, $a, $c) {
        echo '<tr><td><strong>' . esc_html($m) . '</strong></td><td>' . esc_html($b) . '</td><td>' . esc_html($a) . '</td><td>' . esc_html($c) . '</td></tr>';
    }
    private static function pct($v) { return $v === null ? '—' : (($v >= 0 ? '+' : '') . $v . '%'); }
}
