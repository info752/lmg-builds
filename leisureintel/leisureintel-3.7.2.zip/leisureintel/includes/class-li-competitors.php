<?php
if (!defined('ABSPATH')) exit;

class LI_Competitors {

    const CACHE_KEY = 'li_competitor_scrape';
    const CACHE_TTL = 86400; // 24 hours

    public function default_competitors() {
        $locale = get_option('li_prompt_locale', 'da');
        $defaults = [
            'da' => [
                ['domain' => 'rejsrejsrejs.dk', 'name' => 'RejsRejsRejs'],
                ['domain' => 'travelmore.dk',   'name' => 'Travelmore'],
            ],
            'sv' => [
                ['domain' => 'vagabond.se',     'name' => 'Vagabond'],
                ['domain' => 'reseguiden.se',   'name' => 'Reseguiden'],
            ],
            'no' => [
                ['domain' => 'ving.no',         'name' => 'Ving Norge'],
                ['domain' => 'apollo.no',       'name' => 'Apollo Norge'],
            ],
            'fi' => [
                ['domain' => 'aurinkomatkat.fi','name' => 'Aurinkomatkat'],
                ['domain' => 'finnmatkat.fi',   'name' => 'Finnmatkat'],
            ],
        ];
        return $defaults[$locale] ?? $defaults['da'];
    }

    public function get_competitors() {
        $stored = get_option('li_competitors', null);
        return $stored !== null ? $stored : $this->default_competitors();
    }

    public function add_competitor($domain, $name = '') {
        $domain = $this->clean_domain($domain);
        if (!$domain) return false;

        $list = $this->get_competitors();
        foreach ($list as $c) {
            if ($c['domain'] === $domain) return false;
        }

        $list[] = ['domain' => $domain, 'name' => $name ?: ucfirst(explode('.', $domain)[0])];
        update_option('li_competitors', $list);
        delete_transient(self::CACHE_KEY);
        return true;
    }

    public function remove_competitor($domain) {
        $list = array_filter($this->get_competitors(), fn($c) => $c['domain'] !== $domain);
        update_option('li_competitors', array_values($list));
        delete_transient(self::CACHE_KEY);
    }

    /**
     * Scrape all competitors. Returns cached data if fresh.
     */
    public function get_scraped_data($force = false) {
        if (!$force) {
            $cached = get_transient(self::CACHE_KEY);
            if ($cached !== false) return $cached;
        }

        $results = [];
        foreach ($this->get_competitors() as $comp) {
            $results[] = $this->scrape($comp);
        }

        set_transient(self::CACHE_KEY, $results, self::CACHE_TTL);
        return $results;
    }

    private function scrape($comp) {
        $domain   = $comp['domain'];
        $base     = 'https://www.' . $domain;

        $data = [
            'domain'          => $domain,
            'name'            => $comp['name'],
            'title'           => '',
            'nav_topics'      => [],
            'article_topics'  => [],
            'content_signals' => [],
        ];

        // Homepage
        $html = $this->fetch($base);
        if ($html) {
            $data['title']          = $this->extract_title($html);
            $data['nav_topics']     = $this->extract_nav($html, $base);
            $data['article_topics'] = $this->extract_headings($html);
        }

        // Sitemap — get more article slugs as topic signals
        $sitemap_topics = $this->try_sitemap($base);
        if (!empty($sitemap_topics)) {
            $data['article_topics'] = array_unique(array_slice(
                array_merge($data['article_topics'], $sitemap_topics), 0, 80
            ));
        }

        // Fetch up to 2 nav pages for deeper topic coverage
        foreach (array_slice($data['nav_topics'], 0, 2) as $nav_url) {
            $page = $this->fetch($nav_url);
            if ($page) {
                $more = $this->extract_headings($page);
                $data['article_topics'] = array_unique(array_slice(
                    array_merge($data['article_topics'], $more), 0, 80
                ));
            }
        }

        $data['content_signals'] = $this->infer_signals($data);
        return $data;
    }

    private function fetch($url) {
        $r = wp_remote_get($url, [
            'timeout'    => 12,
            'user-agent' => 'Mozilla/5.0 (compatible; LeisureIntel/2.3; content research)',
            'headers'    => ['Accept-Language' => 'da-DK,da;q=0.9,en;q=0.8'],
        ]);
        if (is_wp_error($r) || wp_remote_retrieve_response_code($r) !== 200) return null;
        return wp_remote_retrieve_body($r);
    }

    private function extract_title($html) {
        preg_match('/<title[^>]*>([^<]{3,120})<\/title>/i', $html, $m);
        return isset($m[1]) ? trim(strip_tags($m[1])) : '';
    }

    private function extract_nav($html, $base) {
        $urls = [];
        // Pull links from <nav> blocks
        if (preg_match_all('/<nav[^>]*>(.*?)<\/nav>/si', $html, $navs)) {
            foreach ($navs[1] as $nav) {
                preg_match_all('/href="([^"#?]{4,})"/', $nav, $links);
                foreach ($links[1] as $link) {
                    $abs = $this->to_absolute($link, $base);
                    if ($abs && strpos($abs, $base) !== false) $urls[] = $abs;
                }
            }
        }
        return array_unique(array_slice($urls, 0, 12));
    }

    private function extract_headings($html) {
        preg_match_all('/<h[123][^>]*>\s*([^<]{12,120})\s*<\/h[123]>/i', $html, $m);
        $titles = [];
        foreach ($m[1] as $t) {
            $clean = trim(strip_tags($t));
            if (strlen($clean) >= 12 && strlen($clean) <= 120) $titles[] = $clean;
        }
        return array_unique($titles);
    }

    private function try_sitemap($base) {
        $paths = ['/sitemap.xml', '/sitemap_index.xml', '/post-sitemap.xml', '/sitemap-posts-post-1.xml'];
        $topics = [];

        foreach ($paths as $path) {
            $body = $this->fetch($base . $path);
            if (!$body || strpos($body, '<loc>') === false) continue;

            preg_match_all('/<loc>([^<]+)<\/loc>/i', $body, $locs);
            $urls = $locs[1] ?? [];

            // Sitemap index — recurse into first 2 child sitemaps
            if (strpos($body, 'sitemapindex') !== false) {
                $children = array_filter($urls, fn($u) => strpos($u, 'sitemap') !== false);
                $urls = [];
                foreach (array_slice($children, 0, 2) as $child) {
                    $cb = $this->fetch($child);
                    if ($cb) {
                        preg_match_all('/<loc>([^<]+)<\/loc>/i', $cb, $cm);
                        $urls = array_merge($urls, $cm[1] ?? []);
                    }
                }
            }

            foreach (array_slice($urls, 0, 120) as $url) {
                $p = parse_url($url, PHP_URL_PATH);
                if (!$p || $p === '/') continue;
                $slug = str_replace(['-', '_'], ' ', basename(rtrim($p, '/')));
                if (mb_strlen($slug) >= 6) $topics[] = $slug;
            }

            if (!empty($topics)) break;
        }

        return array_unique($topics);
    }

    private function infer_signals($data) {
        $text  = mb_strtolower(implode(' ', array_merge(
            [$data['title']], $data['nav_topics'], $data['article_topics']
        )));

        $map = [
            'budget'     => ['budget', 'billig', 'billige', 'gratis', 'tilbud'],
            'luxury'     => ['luksus', 'luxury', 'eksklusiv', 'premium', '5-stjernet', 'boutique'],
            'family'     => ['familie', 'børn', 'kids', 'familievenligi'],
            'camping'    => ['camping', 'campingplads', 'autocamper', 'teltplads'],
            'ski'        => ['ski', 'skiferie', 'snowboard', 'alperne', 'piste'],
            'city_break' => ['citybreak', 'byferie', 'weekendtur', 'city break'],
            'beach'      => ['strand', 'sol og strand', 'beach', 'sydeuropa'],
            'adventure'  => ['eventyr', 'vandring', 'trekking', 'backpacker'],
            'nordic'     => ['norden', 'skandinavien', 'nordic', 'sverige', 'norge', 'finland'],
            'asia'       => ['asien', 'thailand', 'bali', 'japan', 'vietnam', 'dubai'],
            'commercial' => ['annoncørbetalt', 'webshop', 'køb', 'book nu', 'rejsetilbud'],
            'editorial'  => ['rejsemagasin', 'reportage', 'essay', 'anmeldelse', 'guide'],
        ];

        $signals = [];
        foreach ($map as $signal => $keywords) {
            foreach ($keywords as $kw) {
                if (strpos($text, $kw) !== false) { $signals[] = $signal; break; }
            }
        }
        return $signals;
    }

    private function to_absolute($url, $base) {
        if (preg_match('/^https?:\/\//', $url)) return $url;
        if (str_starts_with($url, '/'))         return rtrim($base, '/') . $url;
        return null;
    }

    private function clean_domain($domain) {
        $domain = strtolower(trim($domain));
        $domain = preg_replace('/^https?:\/\/(www\.)?/', '', $domain);
        return rtrim($domain, '/') ?: null;
    }
}
