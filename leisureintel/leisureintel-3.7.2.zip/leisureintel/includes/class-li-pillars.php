<?php
if (!defined('ABSPATH')) exit;

/**
 * LeisureIntel — Søjler / Pillars view.
 *
 * The two-signal strategy map. Reads the curated pillar set (categories flagged
 * with _li_pillar = geo|region|theme) and ranks each on TWO live signals from the
 * (now-fixed) GSC/GA4 join: search visibility (impressions) × reader engagement
 * (GA4 pageviews), plus average position. Each pillar is bucketed into a strategic
 * action group so it's obvious where to invest.
 *
 * Computed on demand (AJAX) + cached 15 min — never runs on page load.
 */
class LI_Pillars {

    const CACHE = 'li_pillar_matrix';
    const MIN_PILLAR_WORDS = 800;  // below this, a Pillar-Content page may NOT be published (mål ~3000)

    public static function boot() {
        add_action('wp_ajax_li_pillars_matrix', [__CLASS__, 'ajax_matrix']);

        // ---- Guard: never publish an EMPTY pillar (thin Pillar-Content page → bounced to draft). ----
        add_action('transition_post_status', [__CLASS__, 'guard_empty_pillar'], 10, 3);
        add_action('admin_notices',          [__CLASS__, 'empty_pillar_notice']);

        // ---- WP is the master: pillars are added in WP (category) or Rank Math (page). ----
        // LeisureIntel only READS + shows them. No add/manage UI inside Intel.
        // Categories screen: "Søjle" column + axis selector in add/edit form (masters _li_pillar in WP).
        add_filter('manage_edit-category_columns',  [__CLASS__, 'cat_column_head']);
        add_filter('manage_category_custom_column', [__CLASS__, 'cat_column_body'], 10, 3);
        add_action('category_add_form_fields',       [__CLASS__, 'cat_field_add']);
        add_action('category_edit_form_fields',      [__CLASS__, 'cat_field_edit']);
        add_action('created_category',               [__CLASS__, 'cat_field_save']);
        add_action('edited_category',                [__CLASS__, 'cat_field_save']);
        // Pages + Posts lists: "Pillar" column reading Rank Math's rank_math_pillar_content.
        add_filter('manage_pages_columns',        [__CLASS__, 'post_column_head']);
        add_action('manage_pages_custom_column',  [__CLASS__, 'post_column_body'], 10, 2);
        add_filter('manage_posts_columns',        [__CLASS__, 'post_column_head']);
        add_action('manage_posts_custom_column',  [__CLASS__, 'post_column_body'], 10, 2);
    }

    /* ------------------------------------------ WP-native pillar surfacing */

    private static function axis_label($ax) {
        return ['geo' => '🌍 Geografi', 'region' => '🗺️ Regioner', 'theme' => '✨ Temaer'][$ax] ?? '';
    }

    public static function cat_column_head($cols) { $cols['li_pillar'] = 'Søjle'; return $cols; }

    public static function cat_column_body($content, $column, $term_id) {
        if ($column !== 'li_pillar') return $content;
        $ax = get_term_meta($term_id, '_li_pillar', true);
        return $ax ? '<span style="font-size:12px;">' . esc_html(self::axis_label($ax)) . '</span>' : '<span style="color:#ccc;">—</span>';
    }

    public static function cat_field_add() {
        ?>
        <div class="form-field">
            <label for="li_pillar">Søjle (LeisureIntel)</label>
            <select name="li_pillar" id="li_pillar">
                <option value="">— ikke en søjle —</option>
                <option value="geo">Geografi</option>
                <option value="region">Regioner</option>
                <option value="theme">Temaer</option>
            </select>
            <p>Markér som strategisk søjle — bruges af LeisureIntel (Søjler-matrix, AInna, Idébank).</p>
        </div>
        <?php
    }

    public static function cat_field_edit($term) {
        $ax = get_term_meta($term->term_id, '_li_pillar', true);
        ?>
        <tr class="form-field">
            <th scope="row"><label for="li_pillar">Søjle (LeisureIntel)</label></th>
            <td>
                <select name="li_pillar" id="li_pillar">
                    <option value="" <?php selected($ax, ''); ?>>— ikke en søjle —</option>
                    <option value="geo" <?php selected($ax, 'geo'); ?>>Geografi</option>
                    <option value="region" <?php selected($ax, 'region'); ?>>Regioner</option>
                    <option value="theme" <?php selected($ax, 'theme'); ?>>Temaer</option>
                </select>
                <p class="description">Strategisk søjle for LeisureIntel — sættes her i WordPress; Søjler-fanen viser den.</p>
            </td>
        </tr>
        <?php
    }

    public static function cat_field_save($term_id) {
        if (!current_user_can('manage_categories') || !isset($_POST['li_pillar'])) return;
        $ax = sanitize_text_field(wp_unslash($_POST['li_pillar']));
        if (in_array($ax, ['geo', 'region', 'theme'], true)) update_term_meta($term_id, '_li_pillar', $ax);
        else delete_term_meta($term_id, '_li_pillar');
        delete_transient(self::CACHE);
    }

    public static function post_column_head($cols) { $cols['li_pillar_page'] = 'Pillar'; return $cols; }

    public static function post_column_body($column, $post_id) {
        if ($column !== 'li_pillar_page') return;
        $on = get_post_meta($post_id, 'rank_math_pillar_content', true) === 'on';
        echo $on
            ? '<span style="color:#2e7d32;font-weight:600;" title="Rank Math Pillar Content">🏛️ Pillar</span>'
            : '<span style="color:#ccc;">–</span>';
    }

    /* --------------------------------- Guard: never publish an empty pillar */

    public static function guard_empty_pillar($new_status, $old_status, $post) {
        if ($new_status !== 'publish' || $old_status === 'publish') return;
        if (!in_array($post->post_type, ['post', 'page'], true)) return;
        if (get_post_meta($post->ID, 'rank_math_pillar_content', true) !== 'on') return;
        $words = str_word_count(wp_strip_all_tags(strip_shortcodes($post->post_content)));
        if ($words >= self::MIN_PILLAR_WORDS) return;

        // Too thin — bounce back to draft (guard against recursion).
        remove_action('transition_post_status', [__CLASS__, 'guard_empty_pillar'], 10);
        wp_update_post(['ID' => $post->ID, 'post_status' => 'draft']);
        add_action('transition_post_status', [__CLASS__, 'guard_empty_pillar'], 10, 3);
        set_transient('li_empty_pillar_' . get_current_user_id(), (int) $words, 120);
    }

    public static function empty_pillar_notice() {
        $uid = get_current_user_id();
        $w = get_transient('li_empty_pillar_' . $uid);
        if ($w === false) return;
        delete_transient('li_empty_pillar_' . $uid);
        printf(
            '<div class="notice notice-error is-dismissible"><p><strong>Tom pillar blokeret.</strong> En pillar/hub må ikke publiceres tom — siden har kun %d ord (minimum %d, mål ~3000). Den er gemt som <strong>kladde</strong>. Fyld indhold på og publicér igen.</p></div>',
            (int) $w, self::MIN_PILLAR_WORDS
        );
    }

    public static function ajax_matrix() {
        check_ajax_referer('li_pillars', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Adgang nægtet.']);

        $refresh = !empty($_POST['refresh']);
        $cached  = get_transient(self::CACHE);
        if ($cached && !$refresh) wp_send_json_success(['html' => $cached, 'cached' => true]);

        $html = self::render_matrix_html();
        set_transient(self::CACHE, $html, 15 * MINUTE_IN_SECONDS);
        wp_send_json_success(['html' => $html, 'cached' => false]);
    }

    /* ---------------------------------------------------------------- Matrix */

    private static function get_matrix() {
        $clusters = (new LI_Clusters())->get_cluster_data();
        $by_id = [];
        foreach ($clusters as $c) $by_id[$c['category_id']] = $c;

        $terms = get_terms(['taxonomy' => 'category', 'hide_empty' => false, 'meta_key' => '_li_pillar']);
        $out = [];
        foreach ($terms as $t) {
            $c     = $by_id[$t->term_id] ?? null;
            $impr  = $c ? (int) $c['total_impressions'] : 0;
            $pv    = $c ? (int) $c['total_pageviews'] : 0;
            $pos   = ($c && $c['avg_position'] !== null) ? (int) round($c['avg_position']) : null;
            $posts = $c ? (int) $c['post_count'] : (int) $t->count;
            $out[] = [
                'name'   => $t->name,
                'axis'   => get_term_meta($t->term_id, '_li_pillar', true),
                'impr'   => $impr,
                'pv'     => $pv,
                'pos'    => $pos,
                'posts'  => $posts,
                'bucket' => self::bucket($impr, $pv, $pos),
            ];
        }
        return $out;
    }

    /** Strategic bucket from the two signals (first match wins). */
    private static function bucket($impr, $pv, $pos) {
        if ($impr >= 300 && $pv >= 90)  return 'flagship';   // strong on both
        if ($impr >= 250 && $pv < 90)   return 'visibility'; // seen a lot, not converting → CTR/position
        if ($pv >= 60 && $impr < 150)   return 'gem';        // engaged, low search visibility → SEO gold
        if ($pos !== null && $pos <= 45) return 'almost';    // close to page 1
        return 'build';                                      // low on both → foundational
    }

    private static function render_matrix_html() {
        $m = self::get_matrix();

        $buckets = [
            'flagship'   => ['🏆 Flagskibe', '#46b450', 'Stærke på begge signaler — doble ned: dybdeindhold + partnerskaber.'],
            'gem'        => ['💎 Skjulte perler', '#2271b1', 'Læserne elsker dem, men Google viser dem ikke — SEO-guldminen. Indholdet resonerer allerede; optimér så det ranker.'],
            'almost'     => ['🎯 Tæt på forsiden', '#7048e8', 'Bedste positioner — et skub konverterer visninger til klik hurtigst.'],
            'visibility' => ['👁️ Set, men ikke klikket', '#dba617', 'Høj søgesynlighed, lav engagement/ranking — fiks titler + løft position (CTR).'],
            'build'      => ['🔨 Byg synlighed', '#787c82', 'Lav på begge — grundlæggende: volumen + indeksering.'],
        ];

        $groups = [];
        foreach ($m as $p) $groups[$p['bucket']][] = $p;

        $h = '';
        foreach ($buckets as $key => [$label, $color, $desc]) {
            $items = $groups[$key] ?? [];
            if (!$items) continue;
            usort($items, fn($a, $b) => ($b['impr'] + $b['pv']) <=> ($a['impr'] + $a['pv']));

            $h .= "<div style='border:1px solid #ccd0d4;border-left:5px solid {$color};background:#fff;padding:12px 16px;margin-bottom:16px;'>";
            $h .= "<h3 style='margin:0 0 2px;'>" . esc_html($label) . " <span style='font-weight:normal;color:#787c82;font-size:.72em;'>(" . count($items) . ")</span></h3>";
            $h .= "<p class='description' style='margin:0 0 8px;'>" . esc_html($desc) . "</p>";
            $h .= "<table class='widefat striped'><thead><tr><th>Søjle</th><th>Akse</th><th>Visninger (søg)</th><th>Læsninger (GA4)</th><th>Position</th><th>Indlæg</th></tr></thead><tbody>";
            foreach ($items as $p) {
                $h .= "<tr><td><strong>" . esc_html($p['name']) . "</strong></td>"
                    . "<td>" . esc_html($p['axis']) . "</td>"
                    . "<td>" . (int) $p['impr'] . "</td>"
                    . "<td>" . (int) $p['pv'] . "</td>"
                    . "<td>" . ($p['pos'] !== null ? (int) $p['pos'] : '—') . "</td>"
                    . "<td>" . (int) $p['posts'] . "</td></tr>";
            }
            $h .= "</tbody></table></div>";
        }
        return $h ?: "<p><em>Ingen søjler markeret endnu (sæt _li_pillar på kategorier).</em></p>";
    }

    /* --------------------------------------------------------------- Render */

    public static function render_pane() {
        $nonce = wp_create_nonce('li_pillars');
        ?>
        <h2>Søjler <span style="font-size:12px;color:#787c82;font-weight:normal;">— pillars rangeret på to signaler: søgesynlighed (visninger) × læserengagement (GA4)</span></h2>
        <p class="description" style="margin:2px 0 10px;">Søjler <strong>viser</strong> pillars — de tilføjes i WordPress (kategori) eller Rank Math (side). Denne fane er kun visning.</p>
        <p>Hvor skal du investere? Flagskibe (stærke på begge), skjulte perler (læserne elsker dem, Google viser dem ikke — SEO-guldminen), dem tæt på forsiden, og dem der ses men ikke klikkes.</p>
        <p>
            <button id="li-pillars-load" class="button button-primary" data-nonce="<?php echo esc_attr($nonce); ?>">Vis søjle-matrix</button>
            <button id="li-pillars-refresh" class="button" style="display:none;">Opdatér (genberegn)</button>
            <span id="li-pillars-spin" style="display:none;color:#787c82;"><span class="spinner is-active" style="float:none;margin:0 6px 0 0;"></span> Beregner mod GSC + GA4… (ca. 5–10 sek)</span>
        </p>
        <div id="li-pillars-result" style="margin-top:12px;"></div>
        <script>
        (function($){
            function load(refresh){
                var n = $("#li-pillars-load").data("nonce");
                $("#li-pillars-spin").show(); $("#li-pillars-load,#li-pillars-refresh").prop("disabled", true);
                $.ajax({ url: ajaxurl, method:"POST", dataType:"json", timeout: 60000,
                    data:{ action:"li_pillars_matrix", nonce:n, refresh: refresh?1:0 } })
                .done(function(r){
                    if(r && r.success){ $("#li-pillars-result").html(r.data.html); $("#li-pillars-load").hide(); $("#li-pillars-refresh").show(); }
                    else { $("#li-pillars-result").html("<div class='notice notice-warning inline'><p>"+((r&&r.data&&r.data.message)||"Kunne ikke beregne.")+"</p></div>"); }
                })
                .fail(function(){ $("#li-pillars-result").html("<div class='notice notice-warning inline'><p>Kunne ikke hente — prøv igen.</p></div>"); })
                .always(function(){ $("#li-pillars-spin").hide(); $("#li-pillars-load,#li-pillars-refresh").prop("disabled", false); });
            }
            $(document).on("click", "#li-pillars-load",    function(){ load(false); });
            $(document).on("click", "#li-pillars-refresh", function(){ load(true); });
            document.addEventListener('DOMContentLoaded', function(){
                if (location.search.indexOf('li_active=pillars') === -1) return;
                var b = document.querySelector('.li-tab-btn[data-tab="pillars"]'); if (b) b.click();
            });
        })(jQuery);
        </script>
        <?php
    }
}
