<?php
/**
 * LeisureIntel — Image Finder (Wikimedia + Unsplash)
 *
 * Per Plan Directeur Document 05 IMAGE-POLICY (2026-04-28).
 *
 * Scope of THIS file (v2 — 2026-04-28 small build):
 *   • Search Wikimedia Commons (no API key required)
 *   • Search Unsplash (requires lmg_unsplash_access_key wp_option)
 *   • Verify licenses + format attribution per doc 05
 *   • Return candidate list
 *   • upload_and_attach() — download a candidate, upload to media library,
 *     set alt text + caption + description per doc 05, attach to post,
 *     set as featured image. Returns attachment ID.
 *
 * Source hierarchy from doc 05:
 *   1. Tourism board press portals — NOT IMPLEMENTED (requires registered access)
 *   2. Hotel/operator press kits   — NOT IMPLEMENTED (requires registered access)
 *   3. Wikimedia Commons           — IMPLEMENTED HERE
 *   4. Unsplash / Pexels / Pixabay — Unsplash IMPLEMENTED HERE; Pexels + Pixabay deferred
 *   5. AI-generated                — NOT IMPLEMENTED (last resort)
 *
 * Candidate shape:
 *   [
 *     'source'           => 'wikimedia' | 'unsplash',
 *     'page_url'         => string,   // human-viewable URL
 *     'image_url'        => string,   // direct image URL (largest available)
 *     'thumb_url'        => string,   // small preview URL
 *     'title'            => string,   // file/page title
 *     'photographer'     => string,   // attribution name
 *     'license'          => string,   // license short name (CC BY-SA 4.0, etc.)
 *     'license_url'      => string,   // human-viewable license page
 *     'width'            => int,
 *     'height'           => int,
 *     'attribution_alt'  => string,   // ready-to-paste alt text per doc 05
 *     'attribution_caption' => string,// ready-to-paste caption per doc 05
 *   ]
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class LI_Image_Finder {

    /**
     * Search Wikimedia Commons for images matching a query.
     * Returns up to $limit candidates.
     */
    public static function search_wikimedia( $query, $limit = 5 ) {
        $query = trim( $query );
        if ( $query === '' ) return [];

        // Step 1: search the file namespace (ns 6) for matching files
        $search_url = add_query_arg( [
            'action'   => 'query',
            'list'     => 'search',
            'srsearch' => $query,
            'srnamespace' => 6,           // File: namespace
            'srlimit'  => max( 1, (int) $limit ),
            'format'   => 'json',
            'origin'   => '*',
        ], 'https://commons.wikimedia.org/w/api.php' );

        $resp = wp_remote_get( $search_url, [ 'timeout' => 15 ] );
        if ( is_wp_error( $resp ) ) return [];
        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        $hits = $body['query']['search'] ?? [];
        if ( empty( $hits ) ) return [];

        // Step 2: bulk-fetch imageinfo + extmetadata for the matching titles
        $titles = wp_list_pluck( $hits, 'title' );
        $titles_param = implode( '|', $titles );

        $info_url = add_query_arg( [
            'action'   => 'query',
            'titles'   => $titles_param,
            'prop'     => 'imageinfo',
            'iiprop'   => 'url|size|extmetadata',
            'iiurlwidth' => 1920,
            'format'   => 'json',
            'origin'   => '*',
        ], 'https://commons.wikimedia.org/w/api.php' );

        $resp2 = wp_remote_get( $info_url, [ 'timeout' => 20 ] );
        if ( is_wp_error( $resp2 ) ) return [];
        $body2 = json_decode( wp_remote_retrieve_body( $resp2 ), true );
        $pages = $body2['query']['pages'] ?? [];

        $candidates = [];
        foreach ( $pages as $page ) {
            $info = $page['imageinfo'][0] ?? null;
            if ( ! $info ) continue;

            $extmeta = $info['extmetadata'] ?? [];

            $license_short = $extmeta['LicenseShortName']['value'] ?? '';
            $license_url   = $extmeta['LicenseUrl']['value']      ?? '';
            $artist_html   = $extmeta['Artist']['value']          ?? '';
            $description_field = $extmeta['ImageDescription']['value'] ?? '';

            // Clean photographer: strip HTML, then take just the name part
            // (Wikimedia Artist field often contains full disclaimer/contact info)
            $photographer = trim( wp_strip_all_tags( $artist_html ) );
            $photographer = preg_replace( '/\s+/u', ' ', $photographer );
            // Strip leading "This Photo was taken by " etc. patterns BEFORE truncating
            $photographer = preg_replace( '/^(This Photo|Picture|Photo|Image)\s+(was\s+)?taken\s+by\s+/iu', '', $photographer );
            $photographer = preg_replace( '/^by\s+/iu', '', $photographer );
            // Truncate: stop at sentence break (period followed by space + capital letter)
            // OR at " . " (period as full stop) but NOT at periods inside abbreviations like "A. Gonsalves"
            // Strategy: take everything up to first ". " (period + space) OR first comma + space
            if ( preg_match( '/^(.{2,80}?)(?:\.\s|\s\(|,\s|<\/|$)/u', $photographer, $pm ) ) {
                $photographer = trim( $pm[1], " \t\n\r\0\x0B." );
            } else {
                $photographer = mb_substr( $photographer, 0, 80 );
            }
            // Trailing period is fine (e.g. "Timothy A. Gonsalves" stays intact)
            $photographer = trim( $photographer );

            // Description: prefer ImageDescription extmeta over filename
            $description_clean = trim( wp_strip_all_tags( $description_field ) );
            $description_clean = preg_replace( '/\s+/u', ' ', $description_clean );
            $description_clean = mb_substr( $description_clean, 0, 120 );

            // Skip if license cannot be confirmed
            if ( $license_short === '' && $license_url === '' ) continue;

            // Filter to commercial-permissible licenses
            $license_lower = strtolower( $license_short );
            $allowed = false;
            foreach ( [ 'cc0', 'cc by', 'cc-by', 'public domain' ] as $needle ) {
                if ( strpos( $license_lower, $needle ) !== false ) { $allowed = true; break; }
            }
            // Skip Non-Commercial (NC) and No-Derivatives (ND) variants
            if ( strpos( $license_lower, 'nc' ) !== false ) $allowed = false;
            if ( ! $allowed ) continue;

            $title = preg_replace( '/^File:/', '', $page['title'] ?? '' );
            $page_url = 'https://commons.wikimedia.org/wiki/' . str_replace( ' ', '_', $page['title'] ?? '' );

            // Pick best descriptive text: ImageDescription if available, otherwise clean filename
            $best_description = $description_clean !== '' ? $description_clean : preg_replace( '/\.(jpg|jpeg|png|webp)$/i', '', $title );

            $candidates[] = [
                'source'           => 'wikimedia',
                'page_url'         => $page_url,
                'image_url'        => $info['thumburl'] ?? $info['url'] ?? '',
                'thumb_url'        => $info['thumburl'] ?? $info['url'] ?? '',
                'title'            => $title,
                'description'      => $best_description,
                'photographer'     => $photographer ?: 'unknown',
                'license'          => $license_short ?: 'see license URL',
                'license_url'      => $license_url,
                'width'            => (int) ( $info['thumbwidth'] ?? $info['width'] ?? 0 ),
                'height'           => (int) ( $info['thumbheight'] ?? $info['height'] ?? 0 ),
                'attribution_alt'  => self::format_alt( $best_description, 'wikimedia', $photographer, $license_short ),
                'attribution_caption' => self::format_caption( $best_description, 'wikimedia', $photographer ),
            ];
        }
        return $candidates;
    }

    /**
     * Search Unsplash for images matching a query.
     * Requires lmg_unsplash_access_key wp_option.
     * Returns up to $limit candidates.
     */
    public static function search_unsplash( $query, $limit = 5 ) {
        $query = trim( $query );
        if ( $query === '' ) return [];

        $access_key = get_option( 'lmg_unsplash_access_key', '' );
        if ( $access_key === '' ) return [];

        $url = add_query_arg( [
            'query'    => $query,
            'per_page' => max( 1, (int) $limit ),
            'orientation' => 'landscape',
        ], 'https://api.unsplash.com/search/photos' );

        $resp = wp_remote_get( $url, [
            'timeout' => 15,
            'headers' => [
                'Authorization' => 'Client-ID ' . $access_key,
                'Accept-Version' => 'v1',
            ],
        ] );
        if ( is_wp_error( $resp ) ) return [];
        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        $results = $body['results'] ?? [];

        $candidates = [];
        foreach ( $results as $r ) {
            $photographer = $r['user']['name'] ?? 'Unsplash photographer';
            $title = $r['description'] ?: ( $r['alt_description'] ?: ( 'Unsplash image by ' . $photographer ) );
            $candidates[] = [
                'source'           => 'unsplash',
                'page_url'         => $r['links']['html'] ?? '',
                'image_url'        => $r['urls']['regular'] ?? $r['urls']['full'] ?? '',
                'thumb_url'        => $r['urls']['small'] ?? $r['urls']['thumb'] ?? '',
                'title'            => $title,
                'photographer'     => $photographer,
                'license'          => 'Unsplash License (commercial+editorial OK)',
                'license_url'      => 'https://unsplash.com/license',
                'width'            => (int) ( $r['width'] ?? 0 ),
                'height'           => (int) ( $r['height'] ?? 0 ),
                'attribution_alt'  => self::format_alt( $title, 'unsplash', $photographer, '' ),
                'attribution_caption' => self::format_caption( $title, 'unsplash', $photographer ),
            ];
        }
        return $candidates;
    }

    /**
     * Build the alt-text attribution string per doc 05.
     */
    private static function format_alt( $description, $source, $photographer, $license_short ) {
        $description = trim( wp_strip_all_tags( (string) $description ) );
        $description = preg_replace( '/\s+/', ' ', $description );
        if ( mb_strlen( $description ) > 120 ) {
            $description = mb_substr( $description, 0, 117 ) . '…';
        }
        if ( $description === '' ) $description = 'Image';
        if ( substr( $description, -1 ) !== '.' ) $description .= '.';

        $source_label = $source === 'wikimedia' ? 'Wikimedia Commons' : 'Unsplash';
        $bits = [ $source_label ];
        if ( $photographer !== '' && $photographer !== 'unknown' ) $bits[] = $photographer;
        $by = implode( ' / ', $bits );

        $tail = "Image: $by";
        if ( $license_short !== '' ) $tail .= ', ' . $license_short;
        $tail .= '.';

        return "$description $tail";
    }

    private static function format_caption( $description, $source, $photographer ) {
        $description = trim( wp_strip_all_tags( (string) $description ) );
        if ( mb_strlen( $description ) > 100 ) {
            $description = mb_substr( $description, 0, 97 ) . '…';
        }
        $source_label = $source === 'wikimedia' ? 'Wikimedia Commons' : 'Unsplash';
        $bits = [ $source_label ];
        if ( $photographer !== '' && $photographer !== 'unknown' ) $bits[] = $photographer;
        return "$description Photo: " . implode( ' / ', $bits ) . '.';
    }

    /**
     * Download a candidate image, upload to WP media library with full
     * attribution per doc 05, attach to the post, and set as featured image.
     *
     * @param array  $candidate One of the items returned by search_wikimedia/search_unsplash
     * @param int    $post_id   The post to attach the image to
     * @param bool   $set_featured True (default) sets it as featured image
     * @return int|WP_Error attachment ID on success
     */
    public static function upload_and_attach( $candidate, $post_id, $set_featured = true ) {
        if ( empty( $candidate['image_url'] ) ) {
            return new WP_Error( 'lmg_image_no_url', 'Candidate has no image_url' );
        }
        $post = get_post( $post_id );
        if ( ! $post ) {
            return new WP_Error( 'lmg_image_no_post', 'Post not found' );
        }

        // Required when called outside admin context
        if ( ! function_exists( 'media_handle_sideload' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        // Download to temp file
        $tmp = download_url( $candidate['image_url'], 60 );
        if ( is_wp_error( $tmp ) ) return $tmp;

        // Build a sensible filename from candidate title (keep extension from URL)
        $url_basename = wp_basename( parse_url( $candidate['image_url'], PHP_URL_PATH ) );
        $ext = pathinfo( $url_basename, PATHINFO_EXTENSION );
        if ( ! $ext || strlen( $ext ) > 5 ) $ext = 'jpg';
        // Strip any pre-existing extension from title before slugging (avoids "name-jpg.jpg")
        $title_for_filename = preg_replace( '/\.(jpg|jpeg|png|webp|gif)$/i', '', (string) ( $candidate['title'] ?? 'image' ) );
        $base = sanitize_title( mb_substr( $title_for_filename, 0, 60 ) );
        // Strip trailing -jpg / -jpeg / -png that sanitize_title may produce from weird titles
        $base = preg_replace( '/-(jpg|jpeg|png|webp|gif)$/', '', $base );
        if ( $base === '' ) $base = 'attached-image';
        $filename = "$base.$ext";

        $file_array = [
            'name'     => $filename,
            'tmp_name' => $tmp,
        ];

        $attachment_id = media_handle_sideload( $file_array, $post_id, $candidate['attribution_caption'] ?? '' );

        if ( is_wp_error( $attachment_id ) ) {
            @unlink( $tmp );
            return $attachment_id;
        }

        // Set alt text (per doc 05 — most important field)
        $alt = $candidate['attribution_alt'] ?? '';
        if ( $alt !== '' ) {
            update_post_meta( $attachment_id, '_wp_attachment_image_alt', $alt );
        }

        // Set caption (post_excerpt of attachment)
        // Set description (post_content of attachment) — full license details
        $desc_lines = [];
        if ( ! empty( $candidate['source'] ) )       $desc_lines[] = 'Source: ' . $candidate['source'];
        if ( ! empty( $candidate['page_url'] ) )     $desc_lines[] = 'Source page: ' . $candidate['page_url'];
        if ( ! empty( $candidate['photographer'] ) ) $desc_lines[] = 'Photographer: ' . $candidate['photographer'];
        if ( ! empty( $candidate['license'] ) )      $desc_lines[] = 'License: ' . $candidate['license'];
        if ( ! empty( $candidate['license_url'] ) )  $desc_lines[] = 'License URL: ' . $candidate['license_url'];
        $description = implode( "\n", $desc_lines );

        wp_update_post( [
            'ID'           => $attachment_id,
            'post_excerpt' => $candidate['attribution_caption'] ?? '',
            'post_content' => $description,
        ] );

        // Set as featured image
        if ( $set_featured ) {
            set_post_thumbnail( $post_id, $attachment_id );
        }

        // Tag the post so we can audit which posts have Code-suggested images
        update_post_meta( $post_id, '_lmg_image_source', $candidate['source'] );
        update_post_meta( $post_id, '_lmg_image_attribution', $alt );
        update_post_meta( $post_id, '_lmg_image_set_at', current_time( 'mysql' ) );

        return (int) $attachment_id;
    }

    /**
     * Build a list of candidate search queries from a WordPress post.
     * Returns 1-3 queries, ordered most→least specific. Caller can try each.
     */
    public static function build_queries_from_post( $post_id ) {
        $post = get_post( $post_id );
        if ( ! $post ) return [];

        $queries = [];
        $clean = function( $s ) {
            $s = trim( $s );
            $s = preg_replace( '/\s+/u', ' ', $s );
            return $s;
        };
        $first_n_words = function( $s, $n ) {
            $words = preg_split( '/\s+/u', trim( $s ), -1, PREG_SPLIT_NO_EMPTY );
            return implode( ' ', array_slice( $words, 0, $n ) );
        };

        // Pull both keyword sources, split on commas, dedupe
        $sources = [];
        $sources[] = (string) get_post_meta( $post_id, 'rank_math_focus_keyword', true );
        $sources[] = (string) get_post_meta( $post_id, '_li_target_keyword', true );
        foreach ( $sources as $raw ) {
            foreach ( array_filter( array_map( 'trim', explode( ',', $raw ) ) ) as $part ) {
                if ( $part !== '' ) {
                    $queries[] = $clean( $part );
                    // Also a tighter version: first 2 words
                    $tight = $first_n_words( $part, 2 );
                    if ( $tight !== $part ) $queries[] = $tight;
                }
            }
        }

        // Title: take first 2-3 words after stripping punctuation
        $title = preg_replace( '/[:;—–|.,!?]/u', ' ', strip_tags( $post->post_title ) );
        $queries[] = $first_n_words( $title, 3 );
        $queries[] = $first_n_words( $title, 2 );

        // Dedupe + drop empties + cap length
        $out = [];
        foreach ( $queries as $q ) {
            $q = $clean( $q );
            if ( $q === '' || mb_strlen( $q ) > 50 ) continue;
            if ( in_array( $q, $out, true ) ) continue;
            $out[] = $q;
        }
        return $out;
    }

    /**
     * Backwards-compat: returns just the first query.
     */
    public static function build_query_from_post( $post_id ) {
        $qs = self::build_queries_from_post( $post_id );
        return $qs ? $qs[0] : '';
    }

    /**
     * Try each candidate query against Wikimedia until one returns hits.
     * Returns [query_used, candidates].
     */
    public static function search_wikimedia_with_fallback( $post_id, $limit = 5 ) {
        $queries = self::build_queries_from_post( $post_id );
        foreach ( $queries as $q ) {
            $hits = self::search_wikimedia( $q, $limit );
            if ( ! empty( $hits ) ) return [ $q, $hits ];
        }
        return [ $queries[0] ?? '', [] ];
    }

    /**
     * Try each candidate query against Unsplash until one returns hits.
     */
    public static function search_unsplash_with_fallback( $post_id, $limit = 5 ) {
        if ( get_option( 'lmg_unsplash_access_key', '' ) === '' ) return [ '', [] ];
        $queries = self::build_queries_from_post( $post_id );
        foreach ( $queries as $q ) {
            $hits = self::search_unsplash( $q, $limit );
            if ( ! empty( $hits ) ) return [ $q, $hits ];
        }
        return [ $queries[0] ?? '', [] ];
    }
}
