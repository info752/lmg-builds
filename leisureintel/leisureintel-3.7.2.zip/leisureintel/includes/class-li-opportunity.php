<?php
if (!defined('ABSPATH')) exit;

/**
 * LeisureIntel — Muligheder / Opportunity Score (Module 1).
 *
 * Real AI scoring: enter a topic → opportunity_score (1–10) + why + geo scope,
 * grounded in the site's own GSC/GA4 data. Reuses LI_Claude::get_on_demand_analysis
 * (the same engine behind "Spørg LeisureIntel") — no change to that engine; the
 * geo scope is injected via the query and shown from the li_lead_scope option.
 *
 * The call is ~15s (under the ~30s browser timeout), run over AJAX with a spinner,
 * a 60s client timeout, and graceful failure (no scary red error).
 *
 * Manual-assist checklist (zero-cost external checks) stays below as a complement.
 * DataForSEO (hard search volume) is still a later phase — creds field at the end.
 */
class LI_Opportunity {

    public static function boot() {
        add_action('admin_post_li_opportunity_creds', [__CLASS__, 'handle_creds']);
        add_action('wp_ajax_li_opp_score',            [__CLASS__, 'ajax_score']);
        add_action('wp_ajax_li_topic_partners',       [__CLASS__, 'ajax_topic_partners']);
    }

    /** Phase 3: given a scored topic, suggest 2–3 partners to pitch (fast, focused). */
    public static function ajax_topic_partners() {
        check_ajax_referer('li_opp_score', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Adgang nægtet.']);
        $term = sanitize_text_field(wp_unslash($_POST['term'] ?? ''));
        if ($term === '') wp_send_json_error(['message' => 'Intet emne.']);
        $res = (new LI_Claude())->get_topic_partners($term);
        if (is_wp_error($res)) wp_send_json_error(['message' => $res->get_error_message()]);
        wp_send_json_success($res);
    }

    public static function is_configured() {
        return get_option('li_dataforseo_login', '') !== '' && get_option('li_dataforseo_password', '') !== '';
    }

    public static function lead_scope() { return get_option('li_lead_scope', ''); }

    /* ------------------------------------------------------- AJAX: real score */

    public static function ajax_score() {
        check_ajax_referer('li_opp_score', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Adgang nægtet.']);

        $term = sanitize_text_field(wp_unslash($_POST['term'] ?? ''));
        if ($term === '') wp_send_json_error(['message' => 'Skriv et emne først.']);

        $scope = self::lead_scope();

        $data    = new LI_Data();
        $dataset = $data->get_analysis_dataset(20);
        if (empty($dataset)) {
            $gsc     = $data->get_top_gsc_pages(20, 30);
            $dataset = $data->enrich_with_post_data($gsc);
        }

        // Inject geo scope into the query so the verdict/fit reflect our audience/geo.
        $query = $term;
        if ($scope !== '') {
            $query .= " — vurdér muligheden specifikt for {$scope}-læsere (rejsende fra Norden/Danmark): rækkevidde, intent og relevans for netop den målgruppe.";
        }

        $claude = new LI_Claude();
        $res    = $claude->get_on_demand_analysis($query, $dataset);
        if (is_wp_error($res)) wp_send_json_error(['message' => $res->get_error_message()]);

        $res['term']       = $term;
        $res['lead_scope'] = $scope;
        wp_send_json_success($res);
    }

    /* --------------------------------------------------------------- Creds */

    public static function handle_creds() {
        if (!current_user_can('manage_options')) wp_die('Denied');
        check_admin_referer('li_opportunity_creds');
        update_option('li_dataforseo_login',    sanitize_text_field(wp_unslash($_POST['login'] ?? '')));
        update_option('li_dataforseo_password', sanitize_text_field(wp_unslash($_POST['password'] ?? '')));
        wp_safe_redirect(add_query_arg(
            ['page' => 'leisureintel', 'li_active' => 'opportunity', 'li_notice' => rawurlencode('DataForSEO credentials saved.')],
            admin_url('admin.php')
        ));
        exit;
    }

    /* --------------------------------------------------------------- Render */

    public static function render_pane() {
        $scope = self::lead_scope();
        $nonce = wp_create_nonce('li_opp_score');
        $term  = isset($_GET['li_term']) ? sanitize_text_field(wp_unslash($_GET['li_term'])) : '';
        ?>
        <h2>Muligheder <span style="font-size:12px;background:#2271b1;color:#fff;padding:2px 8px;border-radius:3px;vertical-align:middle;">Opportunity score</span></h2>
        <p>Vurdér et emne <em>før</em> du skriver det: en score (1–10), hvorfor den lander der, søgeintent, målgruppefit og den vinkel vi bør tage — forankret i sitets egne GSC/GA4-data.</p>

        <div style="background:#f6f7f7;border:1px solid #dde;border-radius:6px;padding:8px 14px;display:inline-block;margin-bottom:12px;">
            <strong>Geo-scope for dette site:</strong>
            <?php echo $scope ? '<span style="color:#2271b1;font-weight:600;">' . esc_html($scope) . '</span>'
                              : '<em style="color:#b32d2e;">ikke sat</em>'; ?>
        </div>

        <div style="background:#fff;border:1px solid #ccd0d4;padding:14px 16px;max-width:820px;">
            <div style="display:flex;gap:8px;">
                <input type="text" id="li-opp-term" class="large-text" value="<?php echo esc_attr($term); ?>"
                       placeholder="F.eks. Beach resorts i Maldiverne">
                <button id="li-opp-btn" class="button button-primary" data-nonce="<?php echo esc_attr($nonce); ?>">Score det</button>
            </div>
            <div id="li-opp-spinner" style="display:none;margin-top:10px;color:#787c82;">
                <span class="spinner is-active" style="float:none;margin:0 6px 0 0;"></span> Vurderer mod sitedata… (ca. 15 sek)
            </div>
            <div id="li-opp-result" style="margin-top:14px;"></div>
        </div>

        <script>
        (function($){
            function badge(s){ var c = s>=8?'#46b450':(s>=6?'#dba617':(s>=4?'#e08a00':'#b32d2e'));
                return '<span style="display:inline-block;min-width:64px;text-align:center;background:'+c+';color:#fff;font-size:26px;font-weight:700;border-radius:6px;padding:8px 10px;">'+(s||'?')+'/10</span>'; }
            function row(label,val){ if(!val) return ''; return '<tr><td style="width:150px;vertical-align:top;color:#555;"><strong>'+label+'</strong></td><td>'+$('<div>').text(val).html()+'</td></tr>'; }
            function chips(arr){ if(!arr||!arr.length) return ''; return arr.map(function(x){return '<span style="display:inline-block;background:#eef;border:1px solid #ccd;border-radius:12px;padding:2px 10px;margin:2px 4px 2px 0;font-size:12px;">'+$('<div>').text(x).html()+'</span>';}).join(''); }

            function score(){
                var term = $('#li-opp-term').val().trim();
                if(!term){ $('#li-opp-term').focus(); return; }
                var btn = $('#li-opp-btn');
                btn.prop('disabled',true);
                $('#li-opp-result').empty();
                $('#li-opp-spinner').show();
                $.ajax({ url: ajaxurl, method:'POST', dataType:'json', timeout: 60000,
                    data: { action:'li_opp_score', term:term, nonce: btn.data('nonce') } })
                .done(function(r){
                    if(!r || !r.success){ $('#li-opp-result').html('<div class="notice notice-warning inline"><p>'+((r&&r.data&&r.data.message)||'Kunne ikke score — prøv igen.')+'</p></div>'); return; }
                    var d = r.data;
                    var html = '<div style="border:1px solid #ccd0d4;border-left:5px solid #2271b1;background:#fff;padding:14px 16px;">'
                        + '<div style="display:flex;gap:16px;align-items:center;">'+badge(d.opportunity_score)
                        + '<div><div style="font-size:15px;font-weight:600;">'+$('<div>').text(d.term||term).html()+'</div>'
                        + '<div style="color:#333;margin-top:2px;">'+$('<div>').text(d.verdict||'').html()+'</div>'
                        + (d.lead_scope?'<div style="color:#2271b1;font-size:12px;margin-top:2px;">Scope: '+$('<div>').text(d.lead_scope).html()+'</div>':'')
                        + '</div></div>'
                        + '<table class="widefat" style="margin-top:12px;border:none;"><tbody>'
                        + row('Søgeintent', d.search_intent)
                        + row('Målgruppefit', d.audience_fit)
                        + row('Anbefalet vinkel', d.recommended_angle)
                        + row('Differentiering', d.differentiation)
                        + row('Timing', d.timing)
                        + (d.caution?row('⚠️ Forbehold', d.caution):'')
                        + '</tbody></table>'
                        + (d.target_keywords&&d.target_keywords.length?'<p style="margin:10px 0 2px;"><strong>Søgeord:</strong> '+chips(d.target_keywords)+'</p>':'')
                        + (d.related_opportunities&&d.related_opportunities.length?'<p style="margin:8px 0 2px;"><strong>Relaterede idéer:</strong> '+chips(d.related_opportunities)+'</p>':'')
                        + '<div style="margin-top:12px;border-top:1px solid #eee;padding-top:12px;"><button class="button" id="li-opp-suggest">🤝 Foreslå partnere til dette emne</button><div id="li-opp-partners" style="margin-top:10px;"></div></div>'
                        + '</div>';
                    lastTerm = d.term || term;
                    $('#li-opp-result').html(html);
                })
                .fail(function(x,status){
                    var msg = status==='timeout' ? 'Vurderingen tog for lang tid — prøv igen.' : 'Kunne ikke hente score — prøv igen om et øjeblik.';
                    $('#li-opp-result').html('<div class="notice notice-warning inline"><p>'+msg+'</p></div>');
                })
                .always(function(){ $('#li-opp-spinner').hide(); btn.prop('disabled',false); });
            }
            var lastTerm = '', oppPartners = [];
            var pushNonce = "<?php echo esc_js( wp_create_nonce('li_push_partner') ); ?>";
            function suggestPartners(){
                if(!lastTerm) return;
                var wrap = $('#li-opp-partners').html('<span class="spinner is-active" style="float:none;margin:0 6px 0 0;"></span> Finder partnere…');
                $.ajax({ url:ajaxurl, method:'POST', dataType:'json', timeout:45000,
                    data:{ action:'li_topic_partners', term:lastTerm, nonce:$('#li-opp-btn').data('nonce') } })
                .done(function(r){
                    if(!r.success || !r.data.partners || !r.data.partners.length){ wrap.html('<em>'+((r.data&&r.data.message)||'Ingen partnerforslag.')+'</em>'); return; }
                    oppPartners = r.data.partners;
                    var h = '<strong>Hvem skal vi pitche?</strong>';
                    $.each(oppPartners, function(i,p){
                        h += '<div style="border:1px solid #ccd0d4;border-left:4px solid #46b450;padding:8px 12px;margin:8px 0;">'
                          + '<strong>'+$('<span>').text(p.name||'').html()+'</strong> <span style="color:#787c82;font-size:12px;">('+$('<span>').text(p.type||'').html()+(p.country?' · '+$('<span>').text(p.country).html():'')+')'+(p.relevance?' '+p.relevance+'/10':'')+'</span>'
                          + '<div style="color:#555;margin:3px 0;">'+$('<span>').text(p.why||'').html()+'</div>'
                          + (p.pitch?'<div style="background:#f6f7f7;padding:6px 8px;border-radius:3px;margin:4px 0;"><strong>Pitch:</strong> '+$('<span>').text(p.pitch).html()+'</div>':'')
                          + '<button class="button button-small li-opp-push" data-idx="'+i+'" style="margin-top:4px;">Send til LeisureRelate</button> <span class="li-opp-push-status" style="font-size:12px;margin-left:6px;"></span>'
                          + '</div>';
                    });
                    wrap.html(h);
                })
                .fail(function(){ wrap.html('<em>Kunne ikke hente partnere — prøv igen.</em>'); });
            }
            $(document).on('click','#li-opp-suggest', suggestPartners);
            $(document).on('click','.li-opp-push', function(){
                var b=$(this), st=b.siblings('.li-opp-push-status'), p=oppPartners[b.data('idx')];
                if(!p) return;
                b.prop('disabled',true); st.text('Sender…');
                $.post(ajaxurl, { action:'li_push_partner_lead', nonce:pushNonce,
                    name:p.name, type:p.type, cluster:lastTerm, cluster_clicks:0,
                    relevance:p.relevance||0, why:p.why||'', pitch:p.pitch||'', contact_type:p.contact_type||'' },
                    function(r){ if(r.success){ b.hide(); st.html('<span style="color:#46b450;">✓ Sendt → LeisureRelate-kø</span>'); }
                                 else { b.prop('disabled',false); st.html('<span style="color:#b32d2e;">'+((r.data&&r.data.message)||'Fejl')+'</span>'); } })
                .fail(function(){ b.prop('disabled',false); st.text('Netværksfejl.'); });
            });
            $(document).on('click','#li-opp-btn', score);
            $(document).on('keypress','#li-opp-term', function(e){ if(e.which===13){ e.preventDefault(); score(); } });
            document.addEventListener('DOMContentLoaded', function(){
                if (location.search.indexOf('li_active=opportunity') === -1) return;
                var b = document.querySelector('.li-tab-btn[data-tab="opportunity"]'); if (b) b.click();
            });
        })(jQuery);
        </script>

        <details style="margin-top:22px;max-width:820px;">
            <summary style="cursor:pointer;font-weight:600;">Manuel tjekliste (gratis eksterne checks) — klik for at folde ud</summary>
            <?php self::render_manual_check($term !== '' ? $term : 'dit emne'); ?>
        </details>

        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="background:#f6f7f7;border:1px solid #ccd0d4;padding:12px 16px;max-width:820px;margin-top:18px;">
            <?php wp_nonce_field('li_opportunity_creds'); ?>
            <input type="hidden" name="action" value="li_opportunity_creds">
            <h3 style="margin-top:0;">DataForSEO (hård søgevolumen — senere fase)</h3>
            <p class="description">Valgfrit. AI-scoren ovenfor virker uden dette. Tilføj kun når vi vil have faktiske volumen/SERP-tal oveni.</p>
            <p>Login: <input type="text" name="login" value="<?php echo esc_attr(get_option('li_dataforseo_login', '')); ?>" class="regular-text" autocomplete="off">
               &nbsp; Password: <input type="password" name="password" value="<?php echo esc_attr(get_option('li_dataforseo_password', '')); ?>" class="regular-text" autocomplete="off">
               &nbsp; <button class="button">Gem</button></p>
        </form>
        <?php
    }

    /** Zero-cost manual worksheet: exact live checks + rubric. */
    private static function render_manual_check($term) {
        $q = rawurlencode($term);
        $links = [
            ['Søgeefterspørgsel + hvem rangerer (top 10)', "https://www.google.com/search?q={$q}&gl=dk&hl=da", 'Scan top 10: store autoritetsdomæner (Forbes/BBC-niveau) = svært; mindre/niche = slåbart. Notér om der ligger en AI-oversigt/featured snippet øverst.'],
            ['Folk spørger også / relaterede', "https://www.google.com/search?q={$q}&gl=dk&hl=da", 'Læs "Folk spørger også om" + relaterede søgninger — den faktiske formulering at ramme.'],
            ['Trend-retning', "https://trends.google.com/trends/explore?geo=DK&q={$q}", 'Stigende, fladt eller faldende betyder mere end rå volumen.'],
            ['Konkurrencedybde (allintitle)', "https://www.google.com/search?q=" . rawurlencode('allintitle:' . $term) . "&gl=dk&hl=da", 'Groft antal sider der målretter præcis denne frase i titlen.'],
        ];
        ?>
        <div style="padding:8px 4px;">
            <ol style="line-height:1.7;">
                <?php foreach ($links as $l): ?>
                    <li><a href="<?php echo esc_url($l[1]); ?>" target="_blank" rel="noopener"><strong><?php echo esc_html($l[0]); ?></strong></a><br>
                        <span class="description"><?php echo esc_html($l[2]); ?></span></li>
                <?php endforeach; ?>
            </ol>
        </div>
        <?php
    }
}
