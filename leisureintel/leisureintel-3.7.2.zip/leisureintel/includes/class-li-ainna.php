<?php
if (!defined('ABSPATH')) exit;

/**
 * LeisureIntel — AInna.
 *
 * The travel agent / bot at the door: reader-facing AI travel advisor.
 * She takes a free-text travel wish, retrieves REAL posts from our own site
 * (the pamphlets), and replies in her voice (the personal friendly travel
 * advisor). v1 = pitch + pamphlets, testable in the admin before any public
 * widget. HARD RULE: only ever recommends real, live content — never invents.
 */
class LI_Ainna {

    public static function boot() {
        add_action('wp_ajax_li_ainna_ask', [__CLASS__, 'ajax_ask']);
        add_shortcode('ainna', [__CLASS__, 'shortcode']);
    }

    /**
     * Front-end door: [ainna] shortcode.
     * v1 stays gated to logged-in admins (same as ajax_ask), so we can drop it on a
     * PRIVATE page and play with the real front-end pane before any public launch.
     * Non-admins see a placeholder — no anonymous Claude calls yet.
     */
    public static function shortcode($atts = []) {
        if (!is_user_logged_in() || !current_user_can('manage_options')) {
            return '<p><em>AInna er under opbygning — kig forbi snart.</em></p>';
        }
        ob_start();
        // admin-ajax.php isn't auto-exposed on the front-end — define it for the pane's fetch().
        echo '<script>window.ajaxurl = window.ajaxurl || ' . wp_json_encode(admin_url('admin-ajax.php')) . ';</script>';
        self::render_pane();
        return ob_get_clean();
    }

    /** Retrieve the best real posts for a free-text wish (title/url/image/excerpt/category). */
    public static function retrieve($wish, $limit = 6) {
        $q = new WP_Query([
            'post_type'      => ['post', 'page'],
            'post_status'    => 'publish',
            's'              => $wish,
            'posts_per_page' => $limit,
            'orderby'        => 'relevance',
            'no_found_rows'  => true,
            'ignore_sticky_posts' => true,
        ]);
        $out = [];
        foreach ($q->posts as $p) {
            $img  = has_post_thumbnail($p->ID) ? get_the_post_thumbnail_url($p->ID, 'large') : '';
            $cats = wp_get_post_categories($p->ID, ['fields' => 'names']);
            $out[] = [
                'id'       => $p->ID,
                'title'    => get_the_title($p->ID),
                'url'      => get_permalink($p->ID),
                'image'    => $img,
                'category' => $cats ? implode(', ', array_slice($cats, 0, 2)) : '',
                'excerpt'  => wp_trim_words(wp_strip_all_tags(strip_shortcodes($p->post_content)), 32),
            ];
        }
        return $out;
    }

    public static function ajax_ask() {
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Ingen adgang']);
        check_ajax_referer('li_ainna', 'nonce');

        $wish = sanitize_text_field(wp_unslash($_POST['wish'] ?? ''));
        if ($wish === '') wp_send_json_error(['message' => 'Fortæl mig, hvad du drømmer om.']);

        // Conversation thread (prior turns) for multi-turn refine.
        $thread = [];
        $raw = wp_unslash($_POST['thread'] ?? '');
        if ($raw) { $d = json_decode($raw, true); if (is_array($d)) $thread = $d; }
        $hist = [];
        $prior = [];
        foreach ($thread as $h) {
            $role = (($h['role'] ?? '') === 'ainna') ? 'ainna' : 'user';
            $text = sanitize_text_field((string)($h['text'] ?? ''));
            $hist[] = ['role' => $role, 'text' => $text];
            if ($role === 'user') $prior[] = $text;
        }

        // Blend the last couple of user wishes with the new one so a refinement still retrieves real content.
        $query = trim(implode(' ', array_slice($prior, -2)) . ' ' . $wish);
        $cands = self::retrieve($query, 6);
        if (!$cands) $cands = self::retrieve($wish, 6);
        if (!$cands) {
            wp_send_json_success(['reply' => 'Hmm — jeg fandt ikke lige noget, der rammer det. Prøv at sige det på en anden måde, eller nævn en del af verden?', 'cards' => []]);
        }

        $res = (new LI_Claude())->get_ainna_reply($wish, $cands, $hist);
        if (is_wp_error($res)) wp_send_json_error(['message' => $res->get_error_message()]);

        // Match AInna's picks back to the retrieved posts to attach real images.
        $by = [];
        foreach ($cands as $c) $by[untrailingslashit($c['url'])] = $c;
        $cards = [];
        foreach (($res['picks'] ?? []) as $pk) {
            $c = $by[untrailingslashit($pk['url'] ?? '')] ?? null;
            if ($c) $cards[] = ['title' => $c['title'], 'url' => $c['url'], 'image' => $c['image'], 'why' => $pk['why'] ?? ''];
        }
        wp_send_json_success(['reply' => $res['reply'] ?? '', 'cards' => $cards]);
    }

    public static function render_pane() {
        $nonce = wp_create_nonce('li_ainna');
        ?>
        <h2>AInna <span style="font-size:12px;color:#787c82;font-weight:normal;">— rejseagenten ved døren. Fortæl en drøm og forfin undervejs ("nu kun det Ægæiske"); hun husker samtalen og henter rigtige artikler fra sitet. (Test — endnu ikke offentlig.)</span></h2>

        <?php $vid = get_option('li_ainna_video', ''); if ($vid): ?>
        <div style="text-align:center;margin:8px 0 18px;">
            <video src="<?php echo esc_url($vid); ?>" autoplay muted loop playsinline
                   style="width:220px;height:auto;border-radius:16px;box-shadow:0 8px 30px rgba(0,0,0,.15);"></video>
            <div style="font-size:12px;color:#787c82;margin-top:6px;">AInna — hun vender sig og hilser 🎬</div>
        </div>
        <?php endif; ?>

        <div style="max-width:720px;">
            <div id="li-ainna-thread" style="display:flex;flex-direction:column;gap:12px;min-height:60px;max-height:460px;overflow-y:auto;padding:8px 2px;"></div>
            <div id="li-ainna-spinner" style="display:none;color:#555;font-size:13px;margin:6px 0;"><span class="spinner is-active" style="float:none;margin:0 6px 0 0;"></span>AInna tænker…</div>
            <div style="display:flex;gap:8px;margin-top:10px;">
                <input type="text" id="li-ainna-wish" class="large-text" placeholder="F.eks. &quot;fantastiske øer i Middelhavet&quot; — og bagefter &quot;nu kun det Ægæiske&quot;" />
                <button id="li-ainna-ask" class="button button-primary" data-nonce="<?php echo esc_attr($nonce); ?>">Send</button>
                <button id="li-ainna-reset" class="button" title="Ny samtale">↺</button>
            </div>
        </div>

        <script>
        (function(){
            var btn = document.getElementById('li-ainna-ask'); if (!btn) return;
            var input = document.getElementById('li-ainna-wish');
            var threadEl = document.getElementById('li-ainna-thread');
            var thread = []; // {role, text}
            function esc(s){ var d=document.createElement('span'); d.textContent = s==null?'':s; return d.innerHTML; }
            function scroll(){ threadEl.scrollTop = threadEl.scrollHeight; }
            function bubbleUser(t){
                var d=document.createElement('div');
                d.style.cssText='align-self:flex-end;max-width:80%;background:#2a9d8f;color:#fff;border-radius:14px;border-bottom-right-radius:3px;padding:8px 12px;font-size:14px;';
                d.textContent=t; threadEl.appendChild(d); scroll();
            }
            function bubbleAinna(t, cards){
                var wrap=document.createElement('div'); wrap.style.cssText='align-self:flex-start;max-width:88%;';
                var b=document.createElement('div');
                b.style.cssText='background:#f6f7ff;border:1px solid #dcdcf5;border-radius:14px;border-bottom-left-radius:3px;padding:10px 13px;font-size:14px;line-height:1.55;';
                b.textContent=t; wrap.appendChild(b);
                if (cards && cards.length){
                    var grid=document.createElement('div');
                    grid.style.cssText='display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:9px;margin-top:9px;';
                    cards.forEach(function(c){
                        var a=document.createElement('a'); a.href=c.url; a.target='_blank'; a.rel='noopener';
                        a.style.cssText='display:block;border:1px solid #e2e4e7;border-radius:8px;overflow:hidden;text-decoration:none;color:#1d2327;background:#fff;';
                        var im=c.image?'<div style="height:92px;background:#eee url(\''+encodeURI(c.image)+'\') center/cover;"></div>':'<div style="height:92px;background:#eef;"></div>';
                        a.innerHTML=im+'<div style="padding:7px 9px;"><strong style="font-size:12px;line-height:1.25;display:block;">'+esc(c.title)+'</strong><span style="font-size:11px;color:#666;display:block;margin-top:3px;">'+esc(c.why)+'</span></div>';
                        grid.appendChild(a);
                    });
                    wrap.appendChild(grid);
                }
                threadEl.appendChild(wrap); scroll();
            }
            function ask(){
                var wish=(input.value||'').trim(); if(!wish){ input.focus(); return; }
                var prior=thread.slice(); // send prior turns, not the new one
                bubbleUser(wish); input.value='';
                btn.disabled=true; document.getElementById('li-ainna-spinner').style.display='block';
                var fd=new FormData();
                fd.append('action','li_ainna_ask'); fd.append('nonce',btn.getAttribute('data-nonce'));
                fd.append('wish',wish); fd.append('thread',JSON.stringify(prior));
                fetch(ajaxurl,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();}).then(function(j){
                    btn.disabled=false; document.getElementById('li-ainna-spinner').style.display='none';
                    if(!j||!j.success){ bubbleAinna((j&&j.data&&j.data.message)||'Noget gik galt.',[]); return; }
                    thread.push({role:'user',text:wish});
                    thread.push({role:'ainna',text:j.data.reply||''});
                    bubbleAinna(j.data.reply||'', j.data.cards||[]);
                }).catch(function(){ btn.disabled=false; document.getElementById('li-ainna-spinner').style.display='none'; bubbleAinna('Netværksfejl.',[]); });
            }
            btn.addEventListener('click',ask);
            input.addEventListener('keydown',function(e){ if(e.key==='Enter') ask(); });
            document.getElementById('li-ainna-reset').addEventListener('click',function(){ thread=[]; threadEl.innerHTML=''; input.focus(); });
            if (location.search.indexOf('li_active=ainna')!==-1){
                document.addEventListener('DOMContentLoaded',function(){ var b=document.querySelector('.li-tab-btn[data-tab="ainna"]'); if(b) b.click(); });
            }
        })();
        </script>
        <?php
    }
}
