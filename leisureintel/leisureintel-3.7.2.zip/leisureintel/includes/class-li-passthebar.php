<?php
if (!defined('ABSPATH')) exit;

/**
 * LeisureIntel — Pass the Bar.
 *
 * Site-health scanner: does the site clear the basic quality bar before we worry
 * about anything clever? Finds broken images, dead links (internal + external),
 * NAKED URLs (raw links pasted as text — bot/import artifact), free AGENCY
 * publicity (non-partner travel-agency names), hotlinked-image risk, dead-end
 * posts (no onward internal link), and extremely short posts (Candidate for
 * rescue — the bridge to the Raise-the-Bar triage).
 *
 * FINDS ONLY — never fixes, never deletes. A dead image is restored from the
 * Image Bank by a human; the machine only reports.
 *
 * Two runners share one per-post scanner:
 *  - ajax_scan(): browser-batched full-site scan with a progress bar (re-runs).
 *  - run_cli():   server-side bounded pass (CLI) to populate an initial report.
 */
class LI_PassTheBar {

    const OPT_RUN      = 'li_ptb_run';       // {ids,total,counts,started}
    const OPT_FINDINGS = 'li_ptb_findings';  // capped display list
    const OPT_SUMMARY  = 'li_ptb_summary';   // {scanned,defects,by,finished,shown,scope}
    const TR_URLCACHE  = 'li_ptb_urlcache';  // url => http code (per run)
    const BATCH        = 20;
    const FIND_CAP     = 2500;
    const SHORT_WORDS  = 300;   // < this = Candidate (thin)
    const VSHORT_WORDS = 120;   // < this = severe

    public static function boot() {
        add_action('wp_ajax_li_ptb_scan',  [__CLASS__, 'ajax_scan']);
        add_action('wp_ajax_li_ptb_reset', [__CLASS__, 'ajax_reset']);
    }

    private static function site_host() {
        return parse_url(home_url(), PHP_URL_HOST);
    }

    /** Check a URL once per run (cached). Returns final HTTP code (int) or 0 on network error. */
    private static function check_url($url, &$cache) {
        if (isset($cache[$url])) return $cache[$url];
        $args = ['timeout'=>6, 'redirection'=>3, 'sslverify'=>false, 'user-agent'=>'LeisureIntel-PassTheBar/1.0'];
        $r = wp_remote_head($url, $args);
        $code = is_wp_error($r) ? 0 : (int) wp_remote_retrieve_response_code($r);
        if ($code === 0 || $code === 405 || $code === 501 || $code >= 500) {
            $r2 = wp_remote_get($url, $args); // some servers reject HEAD
            $c2 = is_wp_error($r2) ? 0 : (int) wp_remote_retrieve_response_code($r2);
            if ($c2) $code = $c2;
        }
        $cache[$url] = $code;
        return $code;
    }

    /** True if the code means a genuinely broken resource (vs bot-block / access). */
    private static function is_broken($code, $external) {
        if ($code === 200 || $code === 206 || $code === 304) return false;
        // external hosts often bot-block — inconclusive, not "broken"
        if ($external && in_array($code, [401,403,429,999], true)) return false;
        return true;
    }

    /**
     * Scan ONE post. Appends to $findings (capped) and tallies $counts (full).
     * Returns nothing; mutates by reference.
     */
    public static function scan_post($pid, &$cache, &$counts, &$findings, $host, $skip_external = false) {
        $post = get_post($pid);
        if (!$post) return;
        $title = get_the_title($pid) ?: '(ingen titel)';
        $edit  = admin_url('post.php?post=' . $pid . '&action=edit');
        $content = (string) $post->post_content;

        $record = function($type, $url, $code, $note) use (&$counts, &$findings, $pid, $title, $edit) {
            $counts[$type] = ($counts[$type] ?? 0) + 1;
            if (count($findings) < self::FIND_CAP) {
                $findings[] = ['pid'=>$pid,'title'=>$title,'edit'=>$edit,'type'=>$type,'url'=>$url,'code'=>$code,'note'=>$note];
            }
        };

        // ---- IMAGES: featured + inline ----
        $imgs = [];
        if (has_post_thumbnail($pid)) { $u = get_the_post_thumbnail_url($pid, 'full'); if ($u) $imgs[$u] = 'featured'; }
        if (preg_match_all('/<img[^>]+src=["\\\']([^"\\\']+)["\\\']/i', $content, $m)) {
            foreach ($m[1] as $u) if (!isset($imgs[$u])) $imgs[$u] = 'inline';
        }
        foreach ($imgs as $u => $kind) {
            if (strpos($u, 'http') !== 0) continue;
            $ext  = (parse_url($u, PHP_URL_HOST) !== $host);
            $code = self::check_url($u, $cache);
            if (self::is_broken($code, $ext)) {
                $record('broken_image', $u, $code, $kind);
            } elseif ($ext) {
                $record('hotlink_image', $u, $code, $kind); // works, but fragile — should be Image Bank
            }
        }

        // ---- LINKS: anchors ----
        $internal_links = 0;
        if (preg_match_all('/<a[^>]+href=["\\\']([^"\\\']+)["\\\']/i', $content, $ma)) {
            $seen = [];
            foreach ($ma[1] as $u) {
                if (isset($seen[$u])) continue; $seen[$u] = 1;
                if ($u === '' || $u[0] === '#' || stripos($u,'mailto:')===0 || stripos($u,'tel:')===0 || stripos($u,'javascript:')===0) continue;
                $abs = $u;
                if (strpos($u, 'http') !== 0) {
                    if (strpos($u, '//') === 0)      $abs = 'https:' . $u;
                    elseif (strpos($u, '/') === 0)   $abs = home_url($u);
                    else continue;
                }
                $ext = (parse_url($abs, PHP_URL_HOST) !== $host);
                if (!$ext) $internal_links++;
                if ($ext && $skip_external) continue;
                $code = self::check_url($abs, $cache);
                if (self::is_broken($code, $ext)) {
                    $record($ext ? 'broken_link_external' : 'broken_link_internal', $abs, $code, '');
                }
            }
        }

        // ---- NAKED URLS: raw http(s) that survive tag-stripping = links pasted as TEXT ----
        // (daily-bot / old-import artifact; renders as an ugly bare URL in body + excerpt).
        // href="" and src="" URLs live in attributes → stripped by wp_strip_all_tags → not flagged.
        $text_only = wp_strip_all_tags($content);
        if (preg_match_all('#https?://[^\s<]+#i', $text_only, $mn)) {
            $record('naked_url', $mn[0][0], count($mn[0]), count($mn[0]) . ' rå URL(er) i teksten');
        }

        // ---- AGENCY PUBLICITY: free promo for a non-partner travel agency ----
        // Rule: we give NO free publicity to agencies unless it's earned (partnership),
        // tactical, or a genuine save-the-whale purpose. Flag for human review (some are legit).
        $hay = ' ' . $title . ' ' . $text_only . ' ';
        $agencies = apply_filters('li_ptb_agency_names', [
            'Højmark','Primo Tours','Bravo Tours','Spies','TUI','Sunweb','Detur',
            'Nazar','Star Tour','Nyhavn Rejser','Kilroy','Falk Lauritsen','Afbud.dk',
        ]);
        $ahits = [];
        foreach ($agencies as $a) {
            if (preg_match('/(?<![A-Za-zÀ-ÿ])' . preg_quote($a, '/') . '(?![A-Za-zÀ-ÿ])/ui', $hay)) $ahits[] = $a;
        }
        if ($ahits) $record('agency_mention', get_permalink($pid), implode(', ', array_slice($ahits, 0, 4)), 'gratis bureau-reklame?');

        // ---- DEAD-END: no onward internal link (still water) ----
        if ($internal_links === 0) {
            $record('dead_end', get_permalink($pid), 0, '');
        }

        // ---- EXTREMELY SHORT: Candidate for rescue (bridge to editorial triage) ----
        $words = str_word_count(wp_strip_all_tags(strip_shortcodes($content)));
        if ($words < self::SHORT_WORDS) {
            $record('short_candidate', get_permalink($pid), $words, $words < self::VSHORT_WORDS ? 'meget kort' : 'kort');
        }
    }

    /* ------------------------------------------------------------- AJAX (browser) */

    public static function ajax_scan() {
        if (!current_user_can('manage_options')) wp_send_json_error(['message'=>'Ingen adgang']);
        check_ajax_referer('li_ptb', 'nonce');
        $offset = max(0, intval($_POST['offset'] ?? 0));

        if ($offset === 0) {
            $ids = get_posts(['post_type'=>['post','page'],'post_status'=>'publish','posts_per_page'=>-1,'fields'=>'ids','orderby'=>'ID','order'=>'ASC']);
            update_option(self::OPT_RUN, ['ids'=>$ids,'total'=>count($ids),'counts'=>[],'started'=>time(),'scope'=>'browser'], false);
            update_option(self::OPT_FINDINGS, [], false);
            set_transient(self::TR_URLCACHE, [], 3 * HOUR_IN_SECONDS);
        }

        $run = get_option(self::OPT_RUN, []);
        $ids = $run['ids'] ?? [];
        $total = count($ids);
        $counts = $run['counts'] ?? [];
        $findings = get_option(self::OPT_FINDINGS, []); if (!is_array($findings)) $findings = [];
        $cache = get_transient(self::TR_URLCACHE); if (!is_array($cache)) $cache = [];
        $host = self::site_host();

        foreach (array_slice($ids, $offset, self::BATCH) as $pid) {
            self::scan_post($pid, $cache, $counts, $findings, $host, false);
        }

        $run['counts'] = $counts;
        update_option(self::OPT_RUN, $run, false);
        update_option(self::OPT_FINDINGS, $findings, false);
        set_transient(self::TR_URLCACHE, $cache, 3 * HOUR_IN_SECONDS);

        $processed = min($offset + self::BATCH, $total);
        $done = $processed >= $total;
        if ($done) self::finalize($total, $counts, $findings, 'browser');

        wp_send_json_success(['processed'=>$processed, 'total'=>$total, 'done'=>$done, 'defects'=>array_sum($counts)]);
    }

    private static function finalize($scanned, $counts, $findings, $scope) {
        update_option(self::OPT_SUMMARY, [
            'scanned'=>$scanned, 'defects'=>array_sum($counts), 'by'=>$counts,
            'shown'=>count($findings), 'finished'=>time(), 'scope'=>$scope,
        ], false);
    }

    public static function ajax_reset() {
        if (!current_user_can('manage_options')) wp_send_json_error();
        check_ajax_referer('li_ptb', 'nonce');
        delete_option(self::OPT_RUN); delete_option(self::OPT_FINDINGS); delete_option(self::OPT_SUMMARY);
        delete_transient(self::TR_URLCACHE);
        wp_send_json_success();
    }

    /* ------------------------------------------------------------- CLI (server-side) */

    /** Bounded server-side scan to populate an initial report. $args: limit, order, skip_external, post_type. */
    public static function run_cli($args = []) {
        $limit  = $args['limit']  ?? -1;
        $order  = $args['order']  ?? 'ASC';   // ASC = oldest first (where the rot is)
        $ptype  = $args['post_type'] ?? ['post','page'];
        $skip_x = !empty($args['skip_external']);

        $ids = get_posts(['post_type'=>$ptype,'post_status'=>'publish','posts_per_page'=>$limit,'fields'=>'ids','orderby'=>'ID','order'=>$order]);
        $total = count($ids);
        $counts = []; $findings = []; $cache = [];
        $host = self::site_host();
        $i = 0;
        foreach ($ids as $pid) {
            self::scan_post($pid, $cache, $counts, $findings, $host, $skip_x);
            $i++;
            if ($i % 100 === 0) {
                update_option(self::OPT_FINDINGS, $findings, false);
                update_option(self::OPT_RUN, ['total'=>$total,'processed'=>$i,'counts'=>$counts,'started'=>time(),'scope'=>'cli'], false);
                echo "  {$i}/{$total} scanned, " . array_sum($counts) . " findings\n";
            }
        }
        update_option(self::OPT_FINDINGS, $findings, false);
        self::finalize($total, $counts, $findings, 'cli' . ($skip_x ? '-noext' : ''));
        echo "DONE — scanned {$total}, findings " . array_sum($counts) . "\n";
        foreach ($counts as $t=>$n) echo "  {$t}: {$n}\n";
    }

    /* ------------------------------------------------------------- Render */

    private static function meta($type) {
        // label, severity (lower=worse), colour
        $map = [
            'broken_image'         => ['Billede 404', 1, '#b32d2e'],
            'broken_link_internal' => ['Dødt internt link', 1, '#b32d2e'],
            'broken_link_external' => ['Dødt eksternt link', 2, '#d63638'],
            'naked_url'            => ['Rå URL i tekst (bot-levn)', 2, '#d63638'],
            'agency_mention'       => ['Gratis bureau-reklame? (tjek)', 2, '#8250df'],
            'hotlink_image'        => ['Hotlinket billede (skrøbeligt)', 3, '#dba617'],
            'short_candidate'      => ['Meget kort → Kandidat', 4, '#8250df'],
            'dead_end'             => ['Blindgyde (intet videre-link)', 5, '#787c82'],
        ];
        return $map[$type] ?? [$type, 9, '#787c82'];
    }

    public static function render_pane() {
        $summary  = get_option(self::OPT_SUMMARY, []);
        $findings = get_option(self::OPT_FINDINGS, []);
        if (!is_array($findings)) $findings = [];
        usort($findings, fn($a,$b) => self::meta($a['type'])[1] <=> self::meta($b['type'])[1]);
        $nonce = wp_create_nonce('li_ptb');
        $by = $summary['by'] ?? [];
        $critical = ($by['broken_image'] ?? 0) + ($by['broken_link_internal'] ?? 0);
        $passed = ($summary && $critical === 0);
        ?>
        <h2>Pass the Bar <span style="font-size:12px;color:#787c82;font-weight:normal;">— klarer sitet den basale kvalitetsbar? Døde billeder, døde links, blindgyder og alt for korte indlæg.</span></h2>

        <div class="li-grid">
            <div class="li-col-main">
                <button id="li-ptb-run" class="button button-primary button-hero" data-nonce="<?php echo esc_attr($nonce); ?>">Kør Pass the Bar (hele sitet)</button>
                <button id="li-ptb-reset" class="button" data-nonce="<?php echo esc_attr($nonce); ?>" style="margin-left:6px;">Nulstil</button>
                <div id="li-ptb-progress" style="display:none;margin-top:14px;">
                    <div style="background:#e2e4e7;border-radius:6px;height:16px;overflow:hidden;max-width:520px;">
                        <div id="li-ptb-bar" style="background:#2271b1;height:100%;width:0;transition:width .3s;"></div>
                    </div>
                    <p id="li-ptb-progress-txt" style="font-size:13px;color:#555;margin:6px 0 0;"></p>
                </div>
            </div>
            <div class="li-col-side">
                <div class="li-info-box">
                    <h3>Golden rule</h3>
                    <p style="font-size:12px;">Pass the Bar <strong>finder kun</strong> — retter og sletter aldrig. Et dødt billede genskabes fra Image Banken af et menneske.</p>
                </div>
            </div>
        </div>

        <?php if ($summary): ?>
            <div style="margin:18px 0;padding:14px 18px;border-radius:8px;<?php echo $passed ? 'background:#edfaef;border:1px solid #46b450;' : 'background:#fcf3cd;border:1px solid #dba617;'; ?>">
                <strong style="font-size:15px;"><?php echo $passed ? '✓ Består (ingen kritiske fejl)' : '⚠ Består ikke — ' . (int)$critical . ' kritiske fejl'; ?></strong>
                — scannede <?php echo (int)($summary['scanned'] ?? 0); ?> indlæg, <?php echo (int)($summary['defects'] ?? 0); ?> fund
                <span style="color:#787c82;">(<?php echo isset($summary['finished']) ? date('d/m H:i', $summary['finished']) : ''; ?>)</span>
                <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;">
                    <?php foreach ($by as $t=>$n): [$label,,$col] = self::meta($t); ?>
                        <span style="background:<?php echo $col; ?>;color:#fff;border-radius:12px;padding:1px 10px;font-size:12px;"><?php echo esc_html($label); ?>: <?php echo (int)$n; ?></span>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($findings): ?>
            <table class="widefat striped">
                <thead><tr><th style="width:180px;">Type</th><th>Indlæg</th><th>URL / detalje</th></tr></thead>
                <tbody>
                <?php foreach ($findings as $f): [$label,,$col] = self::meta($f['type']); ?>
                    <tr>
                        <td><span style="background:<?php echo $col; ?>;color:#fff;border-radius:3px;padding:1px 6px;font-size:11px;white-space:nowrap;"><?php echo esc_html($label); ?></span>
                            <?php if ($f['code']): ?><span style="color:#787c82;font-size:11px;"> <?php echo esc_html($f['type']==='short_candidate' ? $f['code'].' ord' : $f['code']); ?></span><?php endif; ?></td>
                        <td><a href="<?php echo esc_url($f['edit']); ?>"><?php echo esc_html(mb_substr($f['title'],0,60)); ?></a></td>
                        <td style="word-break:break-all;font-size:12px;"><a href="<?php echo esc_url($f['url']); ?>" target="_blank" rel="noopener"><?php echo esc_html(mb_substr($f['url'],0,90)); ?></a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php if (($summary['shown'] ?? 0) < ($summary['defects'] ?? 0)): ?>
                <p style="color:#787c82;font-size:12px;">Viser <?php echo (int)$summary['shown']; ?> af <?php echo (int)$summary['defects']; ?> fund (resten talt i totalerne ovenfor).</p>
            <?php endif; ?>
        <?php elseif ($summary): ?>
            <p>🎉 Ingen fund — sitet består baren.</p>
        <?php else: ?>
            <p style="color:#787c82;">Endnu ingen scanning. Klik <strong>Kør Pass the Bar</strong> — det gennemgår alle publicerede indlæg (kan tage nogle minutter; en fremdriftslinje viser status).</p>
        <?php endif; ?>

        <script>
        (function(){
            if (location.search.indexOf('li_active=passthebar') !== -1) {
                document.addEventListener('DOMContentLoaded', function(){ var b=document.querySelector('.li-tab-btn[data-tab="passthebar"]'); if(b) b.click(); });
            }
            var run = document.getElementById('li-ptb-run');
            var reset = document.getElementById('li-ptb-reset');
            if (!run) return;
            var nonce = run.getAttribute('data-nonce');

            function scan(offset, total){
                var fd = new FormData();
                fd.append('action','li_ptb_scan'); fd.append('nonce',nonce); fd.append('offset',offset);
                fetch(ajaxurl,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();}).then(function(j){
                    if(!j || !j.success){ document.getElementById('li-ptb-progress-txt').textContent='Fejl under scanning.'; run.disabled=false; return; }
                    var d=j.data, pct = d.total? Math.round(d.processed/d.total*100):100;
                    document.getElementById('li-ptb-bar').style.width = pct+'%';
                    document.getElementById('li-ptb-progress-txt').textContent = d.processed+' / '+d.total+' indlæg · '+d.defects+' fund';
                    if(d.done){ location.reload(); } else { scan(d.processed, d.total); }
                }).catch(function(){ document.getElementById('li-ptb-progress-txt').textContent='Netværksfejl.'; run.disabled=false; });
            }
            run.addEventListener('click', function(){
                run.disabled=true; document.getElementById('li-ptb-progress').style.display='block';
                document.getElementById('li-ptb-bar').style.width='0'; document.getElementById('li-ptb-progress-txt').textContent='Starter…';
                scan(0, 0);
            });
            reset.addEventListener('click', function(){
                var fd=new FormData(); fd.append('action','li_ptb_reset'); fd.append('nonce',nonce);
                fetch(ajaxurl,{method:'POST',body:fd,credentials:'same-origin'}).then(function(){ location.reload(); });
            });
        })();
        </script>
        <?php
    }
}
