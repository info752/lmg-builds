<?php
if (!defined('ABSPATH')) exit;

/**
 * LI_PartnerFit — reverse partner search (G 2026-07-19).
 * Type a company → assess whether/how THEY should partner with US: which of our markets
 * we're relevant to them in, our best real articles to point at, the partnership archetype,
 * the data-based value-to-them (incl. pan-Nordic reach), and the spectrum of options.
 * Self-contained submenu under LeisureIntel. Builds on the gated partner brain, doesn't change it.
 */
class LI_PartnerFit {

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'menu'], 20);
        add_action('wp_ajax_li_partner_fit', [__CLASS__, 'ajax']);
    }

    public static function menu() {
        add_submenu_page('leisureintel', 'Partner-fit', 'Partner-fit', 'manage_options', 'li-partner-fit', [__CLASS__, 'render']);
    }

    /** Our real content strengths/markets = top categories by post count. Grounds the fit assessment. */
    public static function our_markets() {
        $cats = get_categories(['orderby' => 'count', 'order' => 'DESC', 'number' => 20, 'hide_empty' => true]);
        return array_map(function ($c) { return $c->name; }, $cats);
    }

    public static function ajax() {
        check_ajax_referer('li_partner_fit', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Adgang nægtet.']);
        $company = isset($_POST['company']) ? sanitize_text_field(wp_unslash($_POST['company'])) : '';
        if ($company === '' || !class_exists('LI_Claude')) wp_send_json_error(['message' => 'Mangler virksomhed.']);

        $fit = (new LI_Claude())->get_partner_fit($company, self::our_markets());
        if (is_wp_error($fit)) wp_send_json_error(['message' => $fit->get_error_message()]);

        // Point at our BEST REAL articles (real URLs only). Overlap terms are usually CATEGORY names,
        // so match a category and pull its posts first; fall back to text search (AInna) for free-text topics.
        $fit['articles'] = [];
        $candidates = array_merge((array) ($fit['market_overlap'] ?? []), [$fit['best_article_topic'] ?? '']);
        foreach ($candidates as $t) {
            $t = trim((string) $t);
            if ($t === '') continue;
            $posts = [];
            $cat = get_term_by('name', $t, 'category');
            if ($cat && !is_wp_error($cat)) {
                $q = new WP_Query([
                    'category__in'   => [$cat->term_id],
                    'post_status'    => 'publish',
                    'posts_per_page' => 3,
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                    'no_found_rows'  => true,
                    'ignore_sticky_posts' => true,
                ]);
                foreach ($q->posts as $p) $posts[] = ['title' => get_the_title($p->ID), 'url' => get_permalink($p->ID)];
            } elseif (class_exists('LI_Ainna')) {
                foreach (LI_Ainna::retrieve($t, 3) as $p) $posts[] = ['title' => $p['title'] ?? '', 'url' => $p['url'] ?? ''];
            }
            if (!empty($posts)) { $fit['articles'] = $posts; break; }
        }

        // Relate deep-link for the company.
        $s = get_option('lrs_settings', []);
        $hub = (is_array($s) && !empty($s['hub_url'])) ? rtrim($s['hub_url'], '/') : '';
        $fit['relate_url'] = $hub ? $hub . '/wp-admin/admin.php?page=lr-master&lr_find=' . rawurlencode($company) : '';

        wp_send_json_success($fit);
    }

    public static function render() {
        $nonce = wp_create_nonce('li_partner_fit');
        ?>
        <div class="wrap">
          <h1>Partner-fit — omvendt partnersøgning</h1>
          <p>Skriv en virksomhed (fx Kuoni, FDM, en hotelkæde). Intel vurderer databaseret, om og hvordan <em>de</em> bør indgå partnerskab med <em>os</em> — hvilke markeder vi er relevante for dem i, vores bedste artikler, vinklen og værdien for dem.</p>
          <input type="text" id="lpf-company" class="regular-text" placeholder="Fx Kuoni" style="max-width:360px;">
          <button class="button button-primary" id="lpf-go" data-nonce="<?php echo esc_attr($nonce); ?>">Vurdér fit</button>
          <span id="lpf-spin" style="display:none;margin-left:8px;"><span class="spinner is-active" style="float:none;"></span> Vurderer…</span>
          <div id="lpf-out" style="margin-top:16px;max-width:840px;"></div>
        </div>
        <script>(function($){
          function esc(s){ return $("<div>").text(s==null?"":s).html(); }
          $("#lpf-go").on("click", function(){
            var c = $("#lpf-company").val().trim(); if(!c) return;
            var b = $(this); b.prop("disabled", true); $("#lpf-spin").show(); $("#lpf-out").empty();
            $.post(ajaxurl, {action:"li_partner_fit", nonce:b.data("nonce"), company:c}, function(r){
              b.prop("disabled", false); $("#lpf-spin").hide();
              if(!r.success){ $("#lpf-out").html("<div class='notice notice-error'><p>"+esc((r.data&&r.data.message)||"Fejl")+"</p></div>"); return; }
              var d = r.data, h = "<div style='background:#fff;border:1px solid #ccd0d4;border-radius:8px;padding:16px 18px;'>";
              h += "<h2 style='margin-top:0;'>"+esc(d.company||c)+" <span style='color:#1a7f37;'>("+esc(d.fit_score||"?")+"/10)</span>";
              if(d.relate_url) h += " <a href='"+d.relate_url+"' target='_blank' rel='noopener' style='font-size:13px;'>&#8599;&#65039; Åbn i Relate</a>";
              h += "</h2>";
              if(d.verdict) h += "<p><strong>"+esc(d.verdict)+"</strong></p>";
              if(d.market_overlap&&d.market_overlap.length) h += "<p>&#127758; <strong>Markeder vi er relevante for dem i:</strong> "+esc(d.market_overlap.join(", "))+"</p>";
              if(d.audience_fit) h += "<p>&#128101; <strong>Audience-fit:</strong> "+esc(d.audience_fit)+"</p>";
              if(d.archetype) h += "<p>&#129309; <strong>Partnerskabstype:</strong> "+esc(d.archetype)+"</p>";
              if(d.value_to_them) h += "<p>&#128176; <strong>Værdi for dem:</strong> "+esc(d.value_to_them)+"</p>";
              if(d.spectrum&&d.spectrum.length) h += "<p>&#127929; <strong>Spektrum af muligheder:</strong> "+esc(d.spectrum.join("  ·  "))+"</p>";
              if(d.data_hook) h += "<p>&#10024; <strong>Åbningslinje:</strong> "+esc(d.data_hook)+"</p>";
              if(d.articles&&d.articles.length){ h += "<p>&#128196; <strong>Vores bedste artikler at pege dem på:</strong></p><ul style='margin-left:6px;'>"; d.articles.forEach(function(a){ h += "<li><a href='"+a.url+"' target='_blank' rel='noopener'>"+esc(a.title)+"</a></li>"; }); h += "</ul>"; }
              h += "</div>";
              $("#lpf-out").html(h);
            }).fail(function(){ b.prop("disabled", false); $("#lpf-spin").hide(); $("#lpf-out").html("<div class='notice notice-error'><p>AJAX fejlede.</p></div>"); });
          });
          $("#lpf-company").on("keydown", function(e){ if(e.key==="Enter") $("#lpf-go").click(); });
        })(jQuery);</script>
        <?php
    }
}
