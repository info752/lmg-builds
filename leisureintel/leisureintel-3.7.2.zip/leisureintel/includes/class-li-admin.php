<?php
if (!defined('ABSPATH')) exit;

class LI_Admin {

    public function __construct() {
        add_action('admin_menu',            [$this, 'add_menu']);
        add_action('admin_init',            [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_ajax_li_run_now',    [$this, 'ajax_run_now']);
        add_action('wp_ajax_li_run_audit',  [$this, 'ajax_run_audit']);
        add_action('wp_ajax_li_write_brief',[$this, 'ajax_write_brief']);
        add_action('wp_ajax_li_ask',          [$this, 'ajax_ask']);
        add_action('wp_ajax_li_run_clusters',          [$this, 'ajax_run_clusters']);
        add_action('wp_ajax_li_run_partners',          [$this, 'ajax_run_partners']);
        add_action('wp_ajax_li_seed_partners',         [$this, 'ajax_seed_partners']);
        add_action('wp_ajax_li_push_partner_lead',     [$this, 'ajax_push_partner_lead']);
        add_action('wp_ajax_li_save_persona',          [$this, 'ajax_save_persona']);
        add_action('wp_ajax_li_run_audience',          [$this, 'ajax_run_audience']);
        add_action('wp_ajax_li_cluster_prescription',  [$this, 'ajax_cluster_prescription']);
        add_action('wp_ajax_li_grant_access',          [$this, 'ajax_grant_access']);
        add_action('wp_ajax_li_revoke_access',         [$this, 'ajax_revoke_access']);
        add_action('wp_ajax_li_add_competitor',        [$this, 'ajax_add_competitor']);
        add_action('wp_ajax_li_remove_competitor',     [$this, 'ajax_remove_competitor']);
        add_action('wp_ajax_li_run_competitive',       [$this, 'ajax_run_competitive']);
        add_action('admin_footer',                     [$this, 'sortable_columns_script']);
    }

    private function can_access() {
        return current_user_can('manage_options') || current_user_can('li_access');
    }

    public function add_menu() {
        add_menu_page('LeisureIntel', 'LeisureIntel', 'manage_options', 'leisureintel',
            [$this, 'render_page'], 'dashicons-chart-area', 80);
    }

    public function register_settings() {
        $fields = [
            'li_site_description'     => 'sanitize_textarea_field',
            'li_num_suggestions'      => 'intval',
            'li_admin_email'          => 'sanitize_email',
            'li_claude_api_key'       => 'sanitize_text_field',
            'li_claude_model'         => 'sanitize_text_field',
            'li_writer_model'         => 'sanitize_text_field',
            'li_prompt_locale'        => 'sanitize_text_field',
            'li_ga4_credentials_path' => 'sanitize_text_field',
            'li_ga4_property_id'      => 'sanitize_text_field',
        ];
        foreach ($fields as $key => $cb) {
            register_setting('li_settings_group', $key, ['sanitize_callback' => $cb]);
        }
    }

    public function enqueue_assets($hook) {
        if ($hook !== 'toplevel_page_leisureintel') return;
        wp_enqueue_style('li-admin', LI_PLUGIN_URL . 'admin/css/admin.css', [], LI_VERSION);
    }

    /** Make every LeisureIntel data table sortable by clicking its column headers. */
    public function sortable_columns_script() {
        $screen = get_current_screen();
        if (!$screen || $screen->id !== 'toplevel_page_leisureintel') return;
        ?>
        <script>
        (function(){
            function parseNum(s){ var m=(s||'').replace(/\s/g,'').replace(/\.(?=\d{3}\b)/g,'').replace(',','.').match(/-?\d+(?:\.\d+)?/); return m?parseFloat(m[0]):null; }
            function cellText(row,i){ var c=row.children[i]; return c?(c.innerText||c.textContent||'').trim():''; }
            function make(table){
                if(table.dataset.liSortable) return; table.dataset.liSortable='1';
                var head=table.querySelector('thead'); if(!head) return;
                var ths=head.querySelectorAll('th');
                ths.forEach(function(th,idx){
                    if(th.dataset.noSort) return;
                    th.style.cursor='pointer'; if(!th.title) th.title='Klik for at sortere';
                    th.addEventListener('click',function(){
                        var tb=table.querySelector('tbody'); if(!tb) return;
                        var rows=Array.prototype.slice.call(tb.querySelectorAll(':scope > tr'));
                        var dir=th.getAttribute('data-dir')==='asc'?'desc':'asc';
                        ths.forEach(function(o){ o.removeAttribute('data-dir'); var s=o.querySelector('.li-sind'); if(s)s.remove(); });
                        th.setAttribute('data-dir',dir);
                        var ind=document.createElement('span'); ind.className='li-sind'; ind.style.opacity='.55'; ind.textContent=dir==='asc'?' ▲':' ▼'; th.appendChild(ind);
                        rows.sort(function(a,b){
                            var x=cellText(a,idx), y=cellText(b,idx), nx=parseNum(x), ny=parseNum(y), cmp;
                            if(nx!==null&&ny!==null) cmp=nx-ny; else cmp=x.localeCompare(y,'da',{numeric:true,sensitivity:'base'});
                            return dir==='asc'?cmp:-cmp;
                        });
                        rows.forEach(function(r){ tb.appendChild(r); });
                    });
                });
            }
            document.querySelectorAll('.li-wrap table.widefat').forEach(make);
        })();
        </script>
        <?php
    }

    public function render_page() {
        if (!$this->can_access()) return;

        $run_log   = get_option('li_run_log', []);
        $audit_log = get_option('li_audit_log', []);
        $nonce_run   = wp_create_nonce('li_run_now');
        $nonce_audit = wp_create_nonce('li_run_audit');

        // Settings values
        $site_desc   = get_option('li_site_description', 'Danmarks ældste uafhængige digitale rejsemedie — luksus og oplevelsesrejser');
        $num_sugg    = intval(get_option('li_num_suggestions', 10));
        $admin_email = get_option('li_admin_email', '');
        $api_key     = get_option('li_claude_api_key', '');
        $claude_model  = get_option('li_claude_model', 'claude-haiku-4-5-20251001');
        $writer_model  = get_option('li_writer_model', 'claude-sonnet-4-6');
        $prompt_locale = get_option('li_prompt_locale', 'da');
        $ga4_path    = get_option('li_ga4_credentials_path', '');
        $ga4_prop    = get_option('li_ga4_property_id', '445373117');

        $ga4 = new LI_GA4();
        $ga4_status = $ga4->is_configured() ? '<span class="li-badge li-badge-ok">GA4 aktiv</span>' : '<span class="li-badge li-badge-warn">GA4 ikke konfigureret</span>';

        $next_analysis = wp_next_scheduled(LI_Cron::HOOK);
        $next_audit    = wp_next_scheduled(LI_Cron::AUDIT_HOOK);
        ?>
        <div class="wrap li-wrap">
        <h1><span class="dashicons dashicons-chart-area"></span> LeisureIntel <span class="li-version">v<?php echo LI_VERSION; ?></span> <?php echo $ga4_status; ?></h1>

        <nav class="li-tabs-nav">
            <button class="li-tab-btn active" data-tab="analyse">Analyse</button>
            <button class="li-tab-btn" data-tab="ideabank">Idébank</button>
            <button class="li-tab-btn" data-tab="pillars">Søjler</button>
            <button class="li-tab-btn" data-tab="opportunity">Muligheder</button>
            <button class="li-tab-btn" data-tab="perflog">Effektmåling</button>
            <button class="li-tab-btn" data-tab="clusters">Klynger</button>
            <button class="li-tab-btn" data-tab="competitors">Konkurrenter</button>
            <button class="li-tab-btn" data-tab="audience">Målgruppe</button>
            <button class="li-tab-btn" data-tab="partners">Partnere</button>
            <button class="li-tab-btn" data-tab="publishing">Publicering</button>
            <button class="li-tab-btn" data-tab="ainna">AInna</button>
            <button class="li-tab-btn" data-tab="passthebar">Pass the Bar</button>
            <button class="li-tab-btn" data-tab="reciprocity">Klynge-links</button>
            <button class="li-tab-btn" data-tab="hubreco">Hub-forslag</button>
            <button class="li-tab-btn" data-tab="audit">Indholdsrevision</button>
            <button class="li-tab-btn" data-tab="settings">Indstillinger</button>
        </nav>

        <!-- ===== ANALYSE TAB ===== -->
        <div id="li-tab-analyse" class="li-tab-pane active">
            <div class="li-grid">
                <div class="li-col-main">
                    <h2>Manuel analyse</h2>
                    <p>Henter GSC + GA4-data, beregner opportunity scores og opretter indholdssforslag som kladder.</p>
                    <button id="li-run-now" class="button button-primary button-hero" data-nonce="<?php echo esc_attr($nonce_run); ?>">
                        Kør analyse nu
                    </button>
                    <div id="li-run-spinner" class="li-spinner" style="display:none;">
                        <span class="spinner is-active"></span> Analyserer... (30–90 sek)
                    </div>
                    <div id="li-run-result" class="li-result" style="display:none;"></div>
                </div>
                <div class="li-col-side">
                    <div class="li-info-box">
                        <h3>Schedule</h3>
                        <p>Analyse: Mandag 07:00 UTC<br>
                        Næste: <?php echo $next_analysis ? date('d/m H:i', $next_analysis) : 'Ikke planlagt'; ?></p>
                    </div>
                </div>
            </div>

            <!-- Ask LeisureIntel -->
            <div class="li-ask-section">
                <h2>Spørg LeisureIntel</h2>
                <p>Stil et spørgsmål om et emne eller en artikelidé — LeisureIntel vurderer det mod din sites aktuelle GSC- og GA4-data.</p>
                <div class="li-ask-row">
                    <input type="text" id="li-ask-input" class="large-text" placeholder="F.eks. &quot;Borge i Østrig, luksusvinkel&quot; eller &quot;Vil en artikel om vinterskisport i Japan virke?&quot;" />
                    <button id="li-ask-btn" class="button button-primary" data-nonce="<?php echo wp_create_nonce('li_ask'); ?>">Analysér</button>
                </div>
                <div id="li-ask-spinner" class="li-spinner" style="display:none;">
                    <span class="spinner is-active"></span> Analyserer... (10–20 sek)
                </div>
                <div id="li-ask-result" style="display:none;"></div>
            </div>

            <div class="li-log-section">
                <details>
                    <summary style="cursor:pointer;font-size:1.3em;font-weight:600;">Analysehistorik <span style="font-weight:normal;font-size:.6em;color:#787c82;">(<?php echo count($run_log); ?> kørsler — klik for at folde ud)</span></summary>
                    <?php if (empty($run_log)): ?>
                        <p>Ingen kørsler endnu.</p>
                    <?php else: ?>
                        <table class="widefat striped" style="margin-top:10px;">
                            <thead><tr><th>Dato</th><th>Sider analyseret</th><th>Forslag oprettet</th><th>Status</th></tr></thead>
                            <tbody>
                            <?php foreach ($run_log as $e): ?>
                                <tr>
                                    <td><?php echo esc_html($e['date']); ?></td>
                                    <td><?php echo esc_html($e['analysed']); ?></td>
                                    <td><?php echo esc_html($e['created']); ?></td>
                                    <td><?php echo esc_html($e['status']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </details>
            </div>
        </div>

        <!-- ===== OPPORTUNITY TAB (Module 1 — Search-Intent loop) ===== -->
        <div id="li-tab-opportunity" class="li-tab-pane" style="display:none;">
            <?php LI_Opportunity::render_pane(); ?>
        </div>

        <!-- ===== PERFORMANCE LOG TAB (Module 2 — Search-Intent loop) ===== -->
        <div id="li-tab-perflog" class="li-tab-pane" style="display:none;">
            <?php LI_Perflog::render_pane(); ?>
        </div>

        <!-- ===== IDÉBANK TAB (Tier 2) ===== -->
        <div id="li-tab-ideabank" class="li-tab-pane" style="display:none;">
            <?php LI_Ideabank::render_pane(); ?>
        </div>

        <!-- ===== SØJLER TAB (two-signal pillar map) ===== -->
        <div id="li-tab-pillars" class="li-tab-pane" style="display:none;">
            <?php LI_Pillars::render_pane(); ?>
        </div>

        <!-- ===== CLUSTERS TAB ===== -->
        <div id="li-tab-clusters" class="li-tab-pane" style="display:none;">
            <div class="li-grid">
                <div class="li-col-main">
                    <h2>Klyngeanalyse</h2>
                    <p>Grupperer alle publicerede indlæg efter kategori, beregner klyngekraft med GSC + GA4-data, og anbefaler nye emneområder baseret på din målgruppe og aktuelle gaps.</p>
                    <button id="li-run-clusters" class="button button-primary button-hero" data-nonce="<?php echo wp_create_nonce('li_run_clusters'); ?>">
                        Analysér klynger nu
                    </button>
                    <div id="li-clusters-spinner" class="li-spinner" style="display:none;">
                        <span class="spinner is-active"></span> Analyserer alle klynger... (30–60 sek)
                    </div>
                </div>
                <div class="li-col-side">
                    <div class="li-info-box">
                        <h3>Signaler</h3>
                        <p>
                            <span class="li-signal-dot signal-strong"></span> <strong>Strong</strong> — dominerende autoritet<br>
                            <span class="li-signal-dot signal-growing"></span> <strong>Growing</strong> — positiv trend<br>
                            <span class="li-signal-dot signal-untapped"></span> <strong>Untapped</strong> — visninger uden klik<br>
                            <span class="li-signal-dot signal-moderate"></span> <strong>Moderate</strong> — mellemklasse<br>
                            <span class="li-signal-dot signal-weak"></span> <strong>Weak</strong> — underperformer
                        </p>
                    </div>
                </div>
            </div>
            <div id="li-clusters-result" style="display:none;"></div>
        </div>

        <!-- ===== COMPETITORS TAB ===== -->
        <div id="li-tab-competitors" class="li-tab-pane" style="display:none;">
            <?php
            $comp_class  = new LI_Competitors();
            $comp_list   = $comp_class->get_competitors();
            $cached_data = get_transient(LI_Competitors::CACHE_KEY);
            $cache_age   = $cached_data ? 'Scrapet data tilgængeligt' : 'Ingen scrapet data — kør scrape først';
            ?>
            <div class="li-grid">
                <div class="li-col-main">
                    <h2>Konkurrentanalyse</h2>
                    <p>Scraper konkurrenters indhold, sammenligner med dine klynger og identificerer wins, kamppladser og åbne felter.</p>
                    <button id="li-run-competitive" class="button button-primary button-hero"
                        data-nonce="<?php echo wp_create_nonce('li_run_competitive'); ?>">
                        Kør konkurrentanalyse
                    </button>
                    <div id="li-competitive-spinner" class="li-spinner" style="display:none;">
                        <span class="spinner is-active"></span> Scraper konkurrenter + analyserer... (60–120 sek)
                    </div>
                </div>
                <div class="li-col-side">
                    <div class="li-info-box">
                        <h3>Cache-status</h3>
                        <p><?php echo esc_html($cache_age); ?><br>Data gemmes 24 timer.</p>
                    </div>
                </div>
            </div>

            <!-- Competitor list management -->
            <div class="li-comp-manage">
                <h3>Konkurrenter</h3>
                <table class="widefat striped" id="li-comp-table">
                    <thead><tr><th>Domæne</th><th>Navn</th><th></th></tr></thead>
                    <tbody>
                    <?php foreach ($comp_list as $c): ?>
                        <tr id="li-comp-row-<?php echo esc_attr(md5($c['domain'])); ?>">
                            <td><?php echo esc_html($c['domain']); ?></td>
                            <td><?php echo esc_html($c['name']); ?></td>
                            <td><button class="button button-small li-remove-comp"
                                data-domain="<?php echo esc_attr($c['domain']); ?>"
                                data-nonce="<?php echo wp_create_nonce('li_remove_competitor'); ?>">Fjern</button></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="li-comp-add-row">
                    <input type="text" id="li-comp-domain" placeholder="rejseklubben.dk" style="width:200px" />
                    <input type="text" id="li-comp-name" placeholder="Navn (valgfrit)" style="width:150px" />
                    <button id="li-add-comp" class="button"
                        data-nonce="<?php echo wp_create_nonce('li_add_competitor'); ?>">Tilføj konkurrent</button>
                    <span id="li-comp-add-status" style="margin-left:8px;font-size:13px;"></span>
                </div>
            </div>

            <div id="li-competitive-result" style="display:none;margin-top:24px;"></div>
        </div>

        <!-- ===== AUDIENCE TAB ===== -->
        <div id="li-tab-audience" class="li-tab-pane" style="display:none;">
            <?php
            $audience        = new LI_Audience();
            $primary_persona = $audience->get_primary_persona();
            $selected_comp   = $audience->get_selected_comparison_keys();
            $all_types       = $audience->all_persona_types();
            $cached_profile  = $audience->get_cached_profile();
            $cached_res      = $audience->get_cached_resonance();
            ?>
            <div class="li-grid">
                <div class="li-col-main">
                    <h2>Målgruppeanalyse</h2>
                    <p>Definer din primære målgruppe. LeisureIntel sammenligner med den faktiske nuværende læser (baseret på dine GSC søgedata) og scorer hvert klynge for resonans med din målgruppe vs. andre segmenter.</p>

                    <div class="li-audience-form">
                        <label><strong>Din primære målgruppe</strong></label>
                        <p class="description" style="margin-bottom:6px;">Beskriv den rejsende du vil nå — mindset, hvad de værdsætter, hvad de IKKE er. Jo mere specifik jo bedre.</p>
                        <textarea id="li-persona-desc" rows="5" class="large-text" placeholder="F.eks.: En moderne dansker med overskud til at rejse, motiveret af oplevelse og nysgerrighed snarere end status. Ikke charter, ikke first class som standard, men heller ikke budget. Rejser alene eller med partner, gerne off-season. Vælger destination efter oplevelse, ikke pris..."><?php echo esc_textarea($primary_persona); ?></textarea>

                        <div style="margin-top:14px;">
                            <label><strong>Sammenligningssegmenter</strong> <span class="description">(vælg 1-2)</span></label>
                            <div class="li-comp-checks">
                            <?php foreach ($all_types as $key => $desc): ?>
                                <label class="li-comp-check-label">
                                    <input type="checkbox" class="li-comp-check" value="<?php echo esc_attr($key); ?>"
                                        <?php checked(in_array($key, $selected_comp)); ?> />
                                    <strong><?php echo esc_html(explode(' —', $desc)[0]); ?></strong>
                                    <span class="description"><?php echo esc_html(explode(' — ', $desc)[1] ?? ''); ?></span>
                                </label>
                            <?php endforeach; ?>
                            </div>
                        </div>

                        <div style="margin-top:14px;display:flex;gap:10px;align-items:center;">
                            <button id="li-save-persona" class="button"
                                data-nonce="<?php echo wp_create_nonce('li_save_persona'); ?>">Gem målgruppe</button>
                            <button id="li-run-audience" class="button button-primary button-hero"
                                data-nonce="<?php echo wp_create_nonce('li_run_audience'); ?>">Analysér målgruppe nu</button>
                            <span id="li-persona-save-status" style="font-size:13px;"></span>
                        </div>
                        <div id="li-audience-spinner" class="li-spinner" style="display:none;margin-top:12px;">
                            <span class="spinner is-active"></span> Analyserer målgruppe + resonans... (30–60 sek)
                        </div>
                    </div>
                </div>
                <div class="li-col-side">
                    <div class="li-info-box">
                        <h3>Hvad du får</h3>
                        <p>
                            <strong>Persona-profil</strong> — hvem er din målgruppe, hvordan rejser de i dag, hvad bruger de penge på, hvad antyder det om deres liv generelt.<br><br>
                            <strong>Nuværende læser</strong> — hvem læser faktisk TravelTalk.dk nu baseret på dine søgedata.<br><br>
                            <strong>Resonansscore</strong> — hvert klynge scoret: rammer vi målgruppen, eller tiltrækker vi de forkerte?
                        </p>
                    </div>
                </div>
            </div>
            <div id="li-audience-result" style="display:none;margin-top:8px;"></div>

            <?php if ($cached_profile || $cached_res): ?>
            <div id="li-audience-cached" style="margin-top:16px;">
                <p class="description">Seneste analyse er cachet. Klik "Analysér målgruppe nu" for at opdatere.</p>
            </div>
            <?php endif; ?>
        </div>

        <!-- ===== PARTNERS TAB ===== -->
        <div id="li-tab-partners" class="li-tab-pane" style="display:none;">
            <?php
            $partners_class = new LI_Partners();
            $cached_partners = $partners_class->get_cached();
            $partner_cache_age = $cached_partners ? 'Cachedata tilgængeligt (24 timer)' : 'Ingen data — kør analyse først';
            ?>
            <div class="li-grid">
                <div class="li-col-main">
                    <h2>Partner Intelligence</h2>
                    <p>Identificerer konkrete, navngivne partnerskabsmuligheder per klynge — turistbureauer, flyselskaber, krydstogtselskaber, hotelkæder og DMO'er — med datadrevne pitches baseret på dine faktiske GSC-tal.</p>
                    <button id="li-run-partners" class="button button-primary button-hero"
                        data-nonce="<?php echo wp_create_nonce('li_run_partners'); ?>">
                        Kør partneranalyse
                    </button>
                    <?php
                    $cpt = new LI_Partner_CPT();
                    $partner_count = wp_count_posts('partner')->publish ?? 0;
                    ?>
                    <p style="margin-top:12px">
                        <strong><?php echo intval($partner_count); ?> partnere</strong> i databasen.
                        <button id="li-seed-partners" class="button button-secondary"
                            data-nonce="<?php echo wp_create_nonce('li_seed_partners'); ?>"
                            style="margin-left:8px">
                            <?php echo $partner_count > 0 ? 'Synkroniser standardpartnere' : 'Importér standardpartnere (DK + SE + NO + FI)'; ?>
                        </button>
                        <span id="li-seed-status" style="margin-left:8px;font-size:13px;"></span>
                    </p>
                    <p class="description">Partnere administreres under <a href="<?php echo admin_url('edit.php?post_type=partner'); ?>">Partnere →</a> i WordPress. Tilføj, rediger eller slet frit. Brug <code>[li_partners locale="dk"]</code> som shortcode på frontendsider.</p>
                    <div id="li-partners-spinner" class="li-spinner" style="display:none;">
                        <span class="spinner is-active"></span> Analyserer partnerskabsmuligheder... (30–60 sek)
                    </div>
                </div>
                <div class="li-col-side">
                    <div class="li-info-box">
                        <h3>Partnertyper</h3>
                        <p>
                            <span class="li-ptype-dot ptype-tourism_board"></span> Turistbureau<br>
                            <span class="li-ptype-dot ptype-airline"></span> Flyselskab<br>
                            <span class="li-ptype-dot ptype-cruise"></span> Krydstogt<br>
                            <span class="li-ptype-dot ptype-hotel_group"></span> Hotelkæde<br>
                            <span class="li-ptype-dot ptype-dmo"></span> DMO<br>
                            <span class="li-ptype-dot ptype-train"></span> Togrejser
                        </p>
                        <p style="margin-top:8px;font-size:12px;color:#888;"><?php echo esc_html($partner_cache_age); ?></p>
                    </div>
                </div>
            </div>
            <div id="li-partners-result" style="display:none;margin-top:8px;"></div>
        </div>

        <!-- ===== AUDIT TAB ===== -->
        <div id="li-tab-audit" class="li-tab-pane" style="display:none;">
            <div class="li-grid">
                <div class="li-col-main">
                    <h2>Indholdsrevision</h2>
                    <p>Kør på anmodning. Vurderer <strong>alle publicerede indlæg</strong> mod konceptet (ikke trafik) og foreslår, hvordan de <strong>reddes og styrkes</strong>: behold / forbedring / viderestil / slet. Manglende trafik alene fører aldrig til "slet", og en massesletning blokeres. Opretter en revisionsrapport som kladde — intet udføres automatisk.</p>
                    <button id="li-run-audit" class="button button-primary button-hero" data-nonce="<?php echo esc_attr($nonce_audit); ?>">
                        Kør indholdsrevision nu
                    </button>
                    <div id="li-audit-spinner" class="li-spinner" style="display:none;">
                        <span class="spinner is-active"></span> Analyserer indhold... (kan tage 2–5 min)
                    </div>
                    <div id="li-audit-result" class="li-result" style="display:none;"></div>
                </div>
                <div class="li-col-side">
                    <div class="li-info-box">
                        <h3>Kør-tilstand</h3>
                        <p><strong>Call-on</strong> — revisionen kører kun, når du trykker på knappen. Ingen automatisk ugentlig kørsel, ingen delete-lister på mail.</p>
                    </div>
                </div>
            </div>

            <?php if (!empty($audit_log)): ?>
            <div class="li-log-section">
                <h2>Revisionshistorik</h2>
                <table class="widefat striped">
                    <thead><tr><th>Dato</th><th>Analyseret</th><th>Behold</th><th>Forbedring</th><th>Viderestil</th><th>Slet</th><th>Rapport</th></tr></thead>
                    <tbody>
                    <?php foreach ($audit_log as $e): ?>
                        <tr>
                            <td><?php echo esc_html($e['date']); ?></td>
                            <td><?php echo esc_html($e['posts_audited']); ?></td>
                            <td><?php echo esc_html($e['behold'] ?? 0); ?></td>
                            <td><?php echo esc_html($e['forbedring'] ?? 0); ?></td>
                            <td><?php echo esc_html($e['viderestil'] ?? 0); ?></td>
                            <td><?php echo esc_html($e['slet'] ?? 0); ?></td>
                            <td><?php if (!empty($e['report_id'])): ?><a href="<?php echo esc_url(get_edit_post_link($e['report_id'], 'raw')); ?>">Åbn rapport</a><?php endif; ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>

        <!-- ===== SETTINGS TAB ===== -->
        <div id="li-tab-settings" class="li-tab-pane" style="display:none;">
            <h2>Indstillinger</h2>
            <form method="post" action="options.php">
                <?php settings_fields('li_settings_group'); ?>
                <table class="form-table">
                    <tr><th><label for="li_site_description">Sitebeskrivelse</label></th>
                        <td><textarea id="li_site_description" name="li_site_description" rows="3" class="large-text"><?php echo esc_textarea($site_desc); ?></textarea>
                        <p class="description">Kontekst til Claude-prompten.</p></td></tr>

                    <tr><th><label for="li_num_suggestions">Antal forslag per kørsel</label></th>
                        <td><input type="number" id="li_num_suggestions" name="li_num_suggestions" value="<?php echo esc_attr($num_sugg); ?>" min="1" max="20" class="small-text" />
                        <p class="description">Standard: 10. Maks: 20.</p></td></tr>

                    <tr><th><label for="li_admin_email">Notifikations-email</label></th>
                        <td><input type="email" id="li_admin_email" name="li_admin_email" value="<?php echo esc_attr($admin_email); ?>" class="regular-text" /></td></tr>

                    <tr><th><label for="li_claude_api_key">Claude API Key</label></th>
                        <td><input type="text" id="li_claude_api_key" name="li_claude_api_key" value="<?php echo esc_attr($api_key); ?>" class="large-text" /></td></tr>

                    <tr><th><label for="li_claude_model">Analyse-model (Claude)</label></th>
                        <td><input type="text" id="li_claude_model" name="li_claude_model" value="<?php echo esc_attr($claude_model); ?>" class="regular-text" />
                        <p class="description">Standard: claude-haiku-4-5-20251001 (hurtig + billig)</p></td></tr>

                    <tr><th><label for="li_writer_model">Skrivemodel (Claude)</label></th>
                        <td><input type="text" id="li_writer_model" name="li_writer_model" value="<?php echo esc_attr($writer_model); ?>" class="regular-text" />
                        <p class="description">Standard: claude-sonnet-4-6 (bedre kvalitet til artikler)</p></td></tr>

                    <tr><th><label for="li_prompt_locale">Marked / outputsprog</label></th>
                        <td>
                        <select id="li_prompt_locale" name="li_prompt_locale">
                            <option value="da" <?php selected($prompt_locale, 'da'); ?>>🇩🇰 Dansk (Danmark)</option>
                            <option value="sv" <?php selected($prompt_locale, 'sv'); ?>>🇸🇪 Svenska (Sverige)</option>
                            <option value="no" <?php selected($prompt_locale, 'no'); ?>>🇳🇴 Norsk (Norge)</option>
                            <option value="fi" <?php selected($prompt_locale, 'fi'); ?>>🇫🇮 Suomi (Finland)</option>
                        </select>
                        <p class="description">Styrer outputsprog, rejsebureauliste og standard SOV-konkurrenter. Skift ved deployment til ny marked.</p>
                        </td></tr>

                    <tr><th colspan="2"><h3 style="margin:0">GA4 Integration</h3></th></tr>

                    <tr><th><label for="li_ga4_credentials_path">Service Account JSON-sti</label></th>
                        <td><input type="text" id="li_ga4_credentials_path" name="li_ga4_credentials_path" value="<?php echo esc_attr($ga4_path); ?>" class="large-text" />
                        <p class="description">Legacy felt — bruges ikke længere. Aktive credentials læses fra DB-optionen tt_gsc_credentials.</p></td></tr>

                    <tr><th><label for="li_ga4_property_id">GA4 Property ID</label></th>
                        <td><input type="text" id="li_ga4_property_id" name="li_ga4_property_id" value="<?php echo esc_attr($ga4_prop); ?>" class="regular-text" />
                        <p class="description">TravelTalk.dk: 445373117</p></td></tr>
                </table>
                <?php submit_button('Gem indstillinger'); ?>
            </form>

            <hr style="margin:24px 0;">
            <h3>Adgangsstyring</h3>
            <p class="description">Giv redaktører eller samarbejdspartnere adgang til LeisureIntel uden fuld WordPress admin-adgang.</p>
            <?php
            $li_users = get_users(['capability' => 'li_access', 'fields' => ['ID', 'user_email', 'display_name']]);
            ?>
            <?php if (!empty($li_users)): ?>
            <table class="widefat striped" style="max-width:600px;margin-bottom:12px;">
                <thead><tr><th>Bruger</th><th>Email</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($li_users as $u): ?>
                    <tr>
                        <td><?php echo esc_html($u->display_name); ?></td>
                        <td><?php echo esc_html($u->user_email); ?></td>
                        <td><button class="button button-small li-revoke-access"
                            data-user-id="<?php echo esc_attr($u->ID); ?>"
                            data-nonce="<?php echo wp_create_nonce('li_revoke_access'); ?>">Fjern adgang</button></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
            <div style="display:flex;gap:8px;align-items:center;">
                <input type="email" id="li-grant-email" placeholder="bruger@email.dk" class="regular-text" />
                <button id="li-grant-access" class="button"
                    data-nonce="<?php echo wp_create_nonce('li_grant_access'); ?>">Giv adgang</button>
                <span id="li-grant-status" style="font-size:13px;"></span>
            </div>
        </div>

        <!-- ===== PUBLISHING TAB ===== -->
        <div id="li-tab-publishing" class="li-tab-pane" style="display:none;">
        <?php
        // Reuse helper functions from lmg-publishing-stats if active, otherwise inline
        if ( function_exists('lmg_ps_count_posts') ) {
            $ps_pub_today = lmg_ps_count_posts('publish', 1);
            $ps_pub_7d    = lmg_ps_count_posts('publish', 7);
            $ps_pub_30d   = lmg_ps_count_posts('publish', 30);
            $ps_pub_total = lmg_ps_count_posts('publish');
            $ps_drafts    = lmg_ps_count_posts('draft');
            $ps_monthly   = lmg_ps_monthly_counts(6);
            $ps_recent    = lmg_ps_recent_posts(10);
            $ps_crons     = lmg_ps_cron_rows();
        } else {
            global $wpdb;
            $ps_pub_today = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='post' AND post_status='publish' AND post_date >= DATE_SUB(NOW(),INTERVAL 1 DAY)");
            $ps_pub_7d    = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='post' AND post_status='publish' AND post_date >= DATE_SUB(NOW(),INTERVAL 7 DAY)");
            $ps_pub_30d   = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='post' AND post_status='publish' AND post_date >= DATE_SUB(NOW(),INTERVAL 30 DAY)");
            $ps_pub_total = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='post' AND post_status='publish'");
            $ps_drafts    = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='post' AND post_status='draft'");
            $ps_monthly   = [];
            foreach($wpdb->get_results("SELECT DATE_FORMAT(post_date,'%Y-%m') AS ym,COUNT(*) AS n FROM {$wpdb->posts} WHERE post_type='post' AND post_status='publish' AND post_date>=DATE_SUB(NOW(),INTERVAL 6 MONTH) GROUP BY ym ORDER BY ym ASC") as $r) $ps_monthly[$r->ym]=(int)$r->n;
            $ps_recent = get_posts(['numberposts'=>10,'post_status'=>['publish','draft'],'orderby'=>'date','order'=>'DESC']);
            $ps_known_crons = ['ttt_bot_daily_run'=>'TravelTalk.travel bot','wst_bot_daily_run'=>'WorldSportTalk bot','leisureintel_weekly_run'=>'LI Analyse','leisureintel_weekly_audit'=>'LI Revision','tt_dk_bot_daily_run'=>'TravelTalk.dk bot'];
            $ps_crons = [];
            foreach($ps_known_crons as $hook=>$label){$next=wp_next_scheduled($hook);if($next!==false)$ps_crons[]=['label'=>$label,'next'=>$next];}
        }
        $ps_max = $ps_monthly ? max(array_values($ps_monthly)) : 1;
        ?>
        <div class="li-grid">
            <div class="li-col-main">

                <?php
                $floor    = (int) get_option('li_cadence_floor_weekly', 2); // traveltalk.dk floor = 2/uge
                $week     = (int) $ps_pub_7d;
                $deficit  = max(0, $floor - $week);
                $on_track = $week >= $floor;
                ?>
                <!-- Cadence measurement -->
                <div style="border-radius:8px;padding:15px 20px;margin-bottom:24px;display:flex;align-items:center;gap:18px;flex-wrap:wrap;<?php echo $on_track ? 'background:#edfaef;border:1px solid #46b450;' : 'background:#fcf3cd;border:1px solid #dba617;'; ?>">
                    <div style="font-size:2.1em;font-weight:800;line-height:1;<?php echo $on_track ? 'color:#2e7d32;' : 'color:#b8860b;'; ?>"><?php echo $week; ?><span style="font-size:.42em;color:#787c82;font-weight:600;"> / <?php echo $floor; ?> pr. uge</span></div>
                    <div style="flex:1;min-width:240px;line-height:1.55;">
                        <?php if ($on_track): ?>
                            <strong style="color:#2e7d32;">På kadence ✓</strong> — <?php echo $week; ?> indlæg de sidste 7 dage. Målet er <?php echo $floor; ?>/uge for at konkurrere på Google.
                        <?php else: ?>
                            <strong style="color:#b8860b;">Under kadence</strong> — kun <?php echo $week; ?> af <?php echo $floor; ?> indlæg sidste uge. <strong>Du mangler <?php echo $deficit; ?> indlæg</strong> for at ramme den kadence der skal til for at konkurrere.
                        <?php endif; ?>
                    </div>
                    <?php if (!$on_track): ?>
                        <button type="button" class="button button-primary li-goto-tab" data-goto="ideabank" style="white-space:nowrap;">→ Find <?php echo $deficit; ?> emne<?php echo $deficit == 1 ? '' : 'r'; ?> i Idébanken</button>
                    <?php endif; ?>
                </div>

                <!-- Summary stats -->
                <div style="display:flex;gap:16px;flex-wrap:wrap;margin-bottom:30px;">
                    <?php foreach([
                        [$ps_pub_today, 'I dag'],
                        [$ps_pub_7d,    '7 dage'],
                        [$ps_pub_30d,   '30 dage'],
                        [$ps_pub_total, 'Total'],
                        [$ps_drafts,    'Kladder'],
                    ] as [$n,$l]) : ?>
                    <div style="background:#fff;border:1px solid #e2e4e7;border-radius:8px;padding:16px 24px;text-align:center;min-width:88px;box-shadow:0 1px 3px rgba(0,0,0,.05);">
                        <div style="font-size:2em;font-weight:700;color:#1d2327;line-height:1.1;"><?php echo $n; ?></div>
                        <div style="font-size:.72em;color:#787c82;margin-top:6px;text-transform:uppercase;letter-spacing:.05em;"><?php echo $l; ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- Monthly bars -->
                <h3 style="margin:0 0 12px;font-size:.9em;text-transform:uppercase;letter-spacing:.05em;color:#787c82;">Publiceret per måned</h3>
                <?php if($ps_monthly) : foreach($ps_monthly as $ym=>$cnt) :
                    $w = $ps_max > 0 ? round(($cnt/$ps_max)*300) : 0; ?>
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:7px;font-size:.88em;">
                    <span style="width:54px;color:#444;"><?php echo esc_html($ym); ?></span>
                    <div style="height:16px;background:#2271b1;border-radius:3px;width:<?php echo $w; ?>px;min-width:2px;"></div>
                    <span style="color:#666;"><?php echo $cnt; ?></span>
                </div>
                <?php endforeach; else: ?><p style="color:#888;font-size:.88em;">Ingen publicerede indlæg.</p><?php endif; ?>

                <!-- Recent posts -->
                <h3 style="margin:20px 0 10px;font-size:.9em;text-transform:uppercase;letter-spacing:.05em;color:#787c82;">Seneste 10 indlæg</h3>
                <table style="width:100%;border-collapse:collapse;font-size:.88em;">
                    <tr style="border-bottom:2px solid #eee;">
                        <th style="text-align:left;padding:5px 10px 5px 0;color:#444;">Titel</th>
                        <th style="text-align:left;padding:5px 10px 5px 0;color:#444;">Status</th>
                        <th style="text-align:left;padding:5px 0;color:#444;">Dato</th>
                    </tr>
                    <?php foreach($ps_recent as $p) :
                        $badge = $p->post_status==='publish'
                            ? '<span style="background:#d1fadf;color:#166534;border-radius:4px;padding:1px 7px;font-size:.78em;">publiceret</span>'
                            : '<span style="background:#fef9c3;color:#854d0e;border-radius:4px;padding:1px 7px;font-size:.78em;">kladde</span>';
                    ?>
                    <tr style="border-bottom:1px solid #f0f0f0;">
                        <td style="padding:6px 10px 6px 0;"><a href="<?php echo esc_url(get_edit_post_link($p->ID)); ?>"><?php echo esc_html($p->post_title ?: '(ingen titel)'); ?></a></td>
                        <td style="padding:6px 10px 6px 0;"><?php echo $badge; ?></td>
                        <td style="padding:6px 0;white-space:nowrap;color:#666;"><?php echo date('d M', strtotime($p->post_date)); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </table>
                <p style="margin:10px 0 0;font-size:.83em;">
                    <a href="<?php echo admin_url('edit.php'); ?>">Alle indlæg →</a>
                    &nbsp; <a href="<?php echo admin_url('edit.php?post_status=draft'); ?>">Alle kladder →</a>
                </p>
            </div><!-- .li-col-main -->

            <div class="li-col-side">
                <div class="li-info-box">
                    <h3>Bot / cron</h3>
                    <?php if($ps_crons) : foreach($ps_crons as $c) : ?>
                    <div style="display:flex;align-items:flex-start;gap:8px;margin-bottom:8px;font-size:.85em;">
                        <span style="color:#22c55e;font-size:1.2em;line-height:1.1;">●</span>
                        <div>
                            <strong><?php echo esc_html($c['label']); ?></strong><br>
                            <span style="color:#888;">næste <?php echo date('d M H:i', $c['next']); ?> UTC</span>
                        </div>
                    </div>
                    <?php endforeach; else : ?>
                    <p style="color:#888;font-size:.85em;">Ingen kendte LMG bots aktive på dette site.</p>
                    <?php endif; ?>
                </div>
            </div><!-- .li-col-side -->
        </div><!-- .li-grid -->
        </div><!-- #li-tab-publishing -->

        <!-- ===== AINNA TAB (reader-facing travel advisor — test) ===== -->
        <div id="li-tab-ainna" class="li-tab-pane" style="display:none;">
            <?php LI_Ainna::render_pane(); ?>
        </div>

        <!-- ===== PASS THE BAR TAB (site-health scanner) ===== -->
        <div id="li-tab-passthebar" class="li-tab-pane" style="display:none;">
            <?php LI_PassTheBar::render_pane(); ?>
        </div>

        <!-- ===== KLYNGE-LINKS TAB (hub↔spoke reciprocity) ===== -->
        <div id="li-tab-reciprocity" class="li-tab-pane" style="display:none;">
            <?php LI_Reciprocity::render_pane(); ?>
        </div>

        <!-- ===== HUB-FORSLAG TAB (which hubs to build next) ===== -->
        <div id="li-tab-hubreco" class="li-tab-pane" style="display:none;">
            <?php LI_HubRecommender::render_pane(); ?>
        </div>

        </div><!-- .li-wrap -->

        <script type="text/javascript">
        (function($){
            // Tab switching
            $(".li-tab-btn").on("click", function(){
                var tab = $(this).data("tab");
                $(".li-tab-btn").removeClass("active");
                $(this).addClass("active");
                $(".li-tab-pane").hide();
                $("#li-tab-" + tab).show();
            });

            // Run analysis
            $("#li-run-now").on("click", function(){
                var btn = $(this), anonce = "<?php echo esc_js( wp_create_nonce('li_async') ); ?>";
                btn.prop("disabled", true);
                $("#li-run-spinner").show();
                $("#li-run-result").hide().removeClass("li-result-success li-result-error");

                function fail(msg){
                    $("#li-run-spinner").hide(); btn.prop("disabled", false);
                    $("#li-run-result").show().removeClass("li-result-success").addClass("li-result-error").html("<strong>" + msg + "</strong>");
                }

                // Start the analysis in the background (no timeout), then poll for the result.
                $.post(ajaxurl, {action:"li_async_start", type:"analysis", nonce:anonce}, function(s){
                    if (!s.success || !s.data.job) { fail("Kunne ikke starte analysen — prøv igen."); return; }
                    var job = s.data.job, tries = 0;
                    var iv = setInterval(function(){
                        tries++;
                        $.post(ajaxurl, {action:"li_async_poll", job:job, nonce:anonce}, function(p){
                            if (!p.success) { clearInterval(iv); fail(p.data ? p.data.message : "Poll-fejl."); return; }
                            if (p.data.status === "running") {
                                if (tries > 80) { clearInterval(iv); fail("Analysen tager usædvanligt lang tid — tjek Idébanken om lidt."); }
                                return;
                            }
                            clearInterval(iv);
                            $("#li-run-spinner").hide(); btn.prop("disabled", false);
                            if (p.data.status === "done") {
                                var n = (p.data.result && p.data.result.suggested) || 0;
                                $("#li-run-result").show().removeClass("li-result-error").addClass("li-result-success")
                                  .html("<strong>Analyse fuldført!</strong> " + n + " forslag ligger nu i <strong>Idébanken</strong> — skift til fanen Idébank for at se dem.");
                            } else {
                                fail(p.data.message || "Analysen fejlede.");
                            }
                        }).fail(function(){ if (tries > 80) { clearInterval(iv); fail("Forbindelsen svigtede."); } });
                    }, 3000);
                }).fail(function(){ fail("Kunne ikke starte analysen — prøv igen."); });
            });

            // Run audit
            $("#li-run-audit").on("click", function(){
                var btn = $(this), nonce = btn.data("nonce");
                btn.prop("disabled", true);
                $("#li-audit-spinner").show();
                $("#li-audit-result").hide().removeClass("li-result-success li-result-error");
                $.post(ajaxurl, {action:"li_run_audit", nonce:nonce}, function(r){
                    $("#li-audit-spinner").hide();
                    btn.prop("disabled", false);
                    var el = $("#li-audit-result").show();
                    if (r.success) {
                        el.addClass("li-result-success");
                        var s = r.data.summary || {};
                        var h = "<strong>Revision fuldført!</strong><br>" + r.data.posts_audited + " indlæg analyseret.<br><br>";
                        h += "<strong>Behold:</strong> " + (s.behold||0) + " &nbsp; <strong>Forbedring:</strong> " + (s.forbedring||0);
                        h += " &nbsp; <strong>Viderestil:</strong> " + (s.viderestil||0) + " &nbsp; <strong>Slet:</strong> " + (s.slet||0) + "<br><br>";
                        if (r.data.guardrail) {
                            h += "<div style='margin:8px 0 14px;padding:10px 12px;border-left:4px solid #d33;background:#fff4f4;color:#7a1f1f;'>&#9888; " + r.data.guardrail + "</div>";
                        }
                        if (r.data.report_id) {
                            h += "<a href='" + r.data.edit_link + "' class='button'>Åbn revisionsrapport</a>";
                        }
                        el.html(h);
                    } else {
                        el.addClass("li-result-error").html("<strong>Fejl:</strong> " + (r.data ? r.data.message : "Ukendt fejl."));
                    }
                }).fail(function(){
                    $("#li-audit-spinner").hide();
                    btn.prop("disabled", false);
                    $("#li-audit-result").show().addClass("li-result-error").html("<strong>AJAX fejlede.</strong>");
                });
            });

            // Cluster analysis
            $("#li-run-clusters").on("click", function(){
                var btn = $(this), nonce = btn.data("nonce");
                btn.prop("disabled", true);
                $("#li-clusters-spinner").show();
                $("#li-clusters-result").hide();
                function renderClustersResult(r){
                    $("#li-clusters-spinner").hide();
                    btn.prop("disabled", false);
                    var el = $("#li-clusters-result").show();
                    if (!r.success) {
                        el.html("<div class='li-result li-result-error'><strong>Fejl:</strong> " + (r.data ? r.data.message : "Ukendt fejl") + "</div>");
                        return;
                    }
                    var clusters = r.data.clusters || [];
                    var insights = r.data.insights || {};

                    // Summary banner
                    var html = "";
                    if (insights.summary) {
                        html += "<div class='li-cluster-summary'>" + $("<span>").text(insights.summary).html() + "</div>";
                    }

                    // Store cluster data for prescription lookups
                    liClusterData = {};

                    // Cluster cards
                    html += "<div class='li-cluster-grid'>";
                    $.each(clusters, function(i, c) {
                        liClusterData[c.category_name] = c;
                        var signalLabels = {strong:"Strong",growing:"Growing",untapped:"Untapped",moderate:"Moderate",weak:"Weak"};
                        var pos = c.avg_position ? c.avg_position : "—";
                        var session = c.avg_session ? Math.round(c.avg_session) + "s" : "n/a";
                        var bounce  = c.avg_bounce  ? c.avg_bounce + "%" : "n/a";
                        var momentum_txt = c.momentum > 0.1 ? "+" + Math.round(c.momentum*100) + "% trend"
                                         : c.momentum < -0.1 ? Math.round(c.momentum*100) + "% aftagende" : "Stabil";

                        html += "<div class='li-cluster-card signal-" + c.signal + "'>";
                        html += "<div class='li-cluster-head'>";
                        html += "<span class='li-cluster-name'>" + $("<span>").text(c.category_name).html() + "</span>";
                        html += "<span class='li-signal-badge signal-" + c.signal + "'>" + (signalLabels[c.signal]||c.signal) + "</span>";
                        html += "<span class='li-cluster-score'>" + c.cluster_score + "<small>/10</small></span>";
                        html += "</div>";
                        html += "<div class='li-cluster-stats'>";
                        html += "<div><strong>" + c.post_count + "</strong><small>indlæg</small></div>";
                        html += "<div><strong>" + c.total_clicks + "</strong><small>klik</small></div>";
                        html += "<div><strong>" + pos + "</strong><small>pos</small></div>";
                        html += "<div><strong>" + c.total_pageviews + "</strong><small>GA4 views</small></div>";
                        html += "</div>";
                        html += "<div class='li-cluster-meta'>" + session + " session · " + bounce + " bounce · " + momentum_txt + "</div>";
                        if (c.top_posts && c.top_posts.length) {
                            html += "<div class='li-cluster-tops'>";
                            $.each(c.top_posts, function(j, p){
                                html += "<a href='" + p.url + "' target='_blank' class='li-cluster-post'>" + $("<span>").text(p.title).html() + " <small>(" + p.clicks + " klik)</small></a>";
                            });
                            html += "</div>";
                        }
                        html += "<div class='li-cluster-footer'>";
                        html += "<button class='button button-small li-prescribe-btn' data-cluster='" + $("<span>").text(c.category_name).html() + "' data-nonce='<?php echo wp_create_nonce('li_cluster_prescription'); ?>'>Hvad mangler?</button>";
                        html += "</div>";
                        html += "<div class='li-prescription-box' style='display:none;'></div>";
                        html += "</div>";
                    });
                    html += "</div>";

                    // AI Insights
                    if (insights.strongest_clusters && insights.strongest_clusters.length) {
                        html += "<div class='li-insights-section'><h2>Stærkeste klynger</h2><div class='li-insights-grid'>";
                        $.each(insights.strongest_clusters, function(i, s){
                            html += "<div class='li-insight-card li-insight-strong'>";
                            html += "<strong>" + $("<span>").text(s.name).html() + "</strong>";
                            html += "<p>" + $("<span>").text(s.why_strong).html() + "</p>";
                            html += "<div class='li-insight-action'>Handling: " + $("<span>").text(s.expand_action).html() + "</div>";
                            html += "</div>";
                        });
                        html += "</div></div>";
                    }

                    if (insights.growth_opportunities && insights.growth_opportunities.length) {
                        html += "<div class='li-insights-section'><h2>Vækstmuligheder</h2><div class='li-insights-grid'>";
                        $.each(insights.growth_opportunities, function(i, g){
                            html += "<div class='li-insight-card li-insight-grow'>";
                            html += "<strong>" + $("<span>").text(g.name).html() + "</strong>";
                            html += "<p>" + $("<span>").text(g.opportunity).html() + "</p>";
                            html += "<div class='li-insight-action'>" + $("<span>").text(g.action).html() + "</div>";
                            html += "</div>";
                        });
                        html += "</div></div>";
                    }

                    // New category recommendations
                    if (insights.new_categories && insights.new_categories.length) {
                        html += "<div class='li-insights-section'><h2>Anbefalede nye emneområder</h2><div class='li-newcat-grid'>";
                        var compColors = {lav:"li-comp-low", middel:"li-comp-mid", høj:"li-comp-high"};
                        $.each(insights.new_categories, function(i, nc){
                            var cc = compColors[nc.competition] || "li-comp-mid";
                            html += "<div class='li-newcat-card'>";
                            html += "<div class='li-newcat-head'><span class='li-newcat-topic'>" + $("<span>").text(nc.topic).html() + "</span>";
                            html += "<span class='li-comp-badge " + cc + "'>Konkurrence: " + $("<span>").text(nc.competition).html() + "</span></div>";
                            html += "<p class='li-newcat-rationale'>" + $("<span>").text(nc.rationale).html() + "</p>";
                            html += "<p class='li-newcat-audience'><em>" + $("<span>").text(nc.audience_fit).html() + "</em></p>";
                            if (nc.first_articles && nc.first_articles.length) {
                                html += "<div class='li-newcat-articles'><strong>Første artikler:</strong><ul>";
                                $.each(nc.first_articles, function(j, a){ html += "<li>" + $("<span>").text(a).html() + "</li>"; });
                                html += "</ul></div>";
                            }
                            html += "</div>";
                        });
                        html += "</div></div>";
                    }

                    el.html(html);
                }
                var anonce = "<?php echo esc_js( wp_create_nonce('li_async') ); ?>";
                function klfail(msg){ $("#li-clusters-spinner").hide(); btn.prop("disabled", false); $("#li-clusters-result").show().html("<div class='li-result li-result-error'>"+msg+"</div>"); }
                $.post(ajaxurl, {action:"li_async_start", type:"clusters", nonce:anonce}, function(s){
                    if(!s.success || !s.data.job){ klfail("Kunne ikke starte klyngeanalysen — prøv igen."); return; }
                    var job=s.data.job, tries=0;
                    var iv=setInterval(function(){
                        tries++;
                        $.post(ajaxurl, {action:"li_async_poll", job:job, nonce:anonce}, function(p){
                            if(!p.success){ clearInterval(iv); klfail(p.data?p.data.message:"Poll-fejl."); return; }
                            if(p.data.status==="running"){ if(tries>120){ clearInterval(iv); klfail("Tager usædvanlig lang tid — prøv igen."); } return; }
                            clearInterval(iv);
                            if(p.data.status==="done"){ renderClustersResult({success:true, data:(p.data.result||{})}); }
                            else { klfail(p.data.message||"Klyngeanalysen fejlede."); }
                        }).fail(function(){ if(tries>120){ clearInterval(iv); klfail("Forbindelsen svigtede."); } });
                    }, 3000);
                }).fail(function(){ klfail("Kunne ikke starte klyngeanalysen — prøv igen."); });
            });

            // Ask LeisureIntel
            function liAsk() {
                var query = $("#li-ask-input").val().trim();
                if (!query) { $("#li-ask-input").focus(); return; }
                var nonce = $("#li-ask-btn").data("nonce");
                $("#li-ask-btn").prop("disabled", true);
                $("#li-ask-spinner").show();
                $("#li-ask-result").hide();
                $.post(ajaxurl, { action: "li_ask", query: query, nonce: nonce }, function(r) {
                    $("#li-ask-spinner").hide();
                    $("#li-ask-btn").prop("disabled", false);
                    var el = $("#li-ask-result").show();
                    if (r.success) {
                        var d = r.data;
                        var s = d.opportunity_score || 0;
                        var bcol = s>=8?'#46b450':(s>=6?'#dba617':(s>=4?'#e08a00':'#b32d2e'));
                        var timingMap = { "nu":"Publicér nu", "næste_sæson":"Næste sæson", "evergreen":"Evergreen", "lav_prioritet":"Lav prioritet" };
                        function askEsc(x){ return $("<span>").text(x==null?"":x).html(); }
                        function askRow(label,val){ return val ? "<tr><td style='width:150px;vertical-align:top;color:#555;'><strong>"+label+"</strong></td><td>"+askEsc(val)+"</td></tr>" : ""; }
                        function askChips(arr){ return (arr||[]).map(function(x){ return "<span style='display:inline-block;background:#eef;border:1px solid #ccd;border-radius:12px;padding:2px 10px;margin:2px 4px 2px 0;font-size:12px;'>"+askEsc(x)+"</span>"; }).join(""); }
                        el.html(
                            "<div style='border:1px solid #ccd0d4;border-left:5px solid #2271b1;background:#fff;padding:14px 16px;'>"
                            + "<div style='display:flex;gap:16px;align-items:center;'>"
                            + "<span style='display:inline-block;min-width:64px;text-align:center;background:"+bcol+";color:#fff;font-size:26px;font-weight:700;border-radius:6px;padding:8px 10px;'>"+(s||"?")+"/10</span>"
                            + "<div><div style='color:#333;font-size:15px;'>"+askEsc(d.verdict)+"</div>"
                            + "<div style='color:#2271b1;font-size:12px;margin-top:2px;'>Timing: "+(timingMap[d.timing]||askEsc(d.timing))+"</div></div></div>"
                            + "<table class='widefat' style='margin-top:12px;border:none;'><tbody>"
                            + askRow("Søgeintent", d.search_intent)
                            + askRow("Målgruppefit", d.audience_fit)
                            + askRow("Anbefalet vinkel", d.recommended_angle)
                            + askRow("Differentiering", d.differentiation)
                            + (d.caution ? askRow("⚠️ Forbehold", d.caution) : "")
                            + "</tbody></table>"
                            + ((d.target_keywords&&d.target_keywords.length) ? "<p style='margin:10px 0 2px;'><strong>Søgeord:</strong> "+askChips(d.target_keywords)+"</p>" : "")
                            + ((d.related_opportunities&&d.related_opportunities.length) ? "<p style='margin:8px 0 2px;'><strong>Relaterede idéer:</strong> "+askChips(d.related_opportunities)+"</p>" : "")
                            + "</div>"
                        );
                    } else {
                        el.html("<div class='li-result li-result-error'><strong>Fejl:</strong> " + (r.data ? r.data.message : "Ukendt fejl") + "</div>");
                    }
                }).fail(function(){
                    $("#li-ask-spinner").hide();
                    $("#li-ask-btn").prop("disabled", false);
                    $("#li-ask-result").show().html("<div class='li-result li-result-error'>AJAX fejlede.</div>");
                });
            }
            $("#li-ask-btn").on("click", liAsk);
            $("#li-ask-input").on("keydown", function(e){ if (e.key === "Enter") liAsk(); });

            // Audience Intelligence
            $("#li-save-persona").on("click", function(){
                var btn   = $(this);
                var desc  = $("#li-persona-desc").val().trim();
                var comps = [];
                $(".li-comp-check:checked").each(function(){ comps.push($(this).val()); });
                btn.prop("disabled", true);
                $("#li-persona-save-status").text("Gemmer...");
                $.post(ajaxurl, {
                    action: "li_save_persona",
                    nonce:  btn.data("nonce"),
                    persona_desc: desc,
                    comparison_personas: comps
                }, function(r){
                    btn.prop("disabled", false);
                    if (r.success) {
                        $("#li-persona-save-status").html("<span class='li-badge li-badge-ok'>Gemt</span>");
                    } else {
                        $("#li-persona-save-status").text(r.data ? r.data.message : "Fejl");
                    }
                });
            });

            $("#li-run-audience").on("click", function(){
                var btn  = $(this);
                var desc = $("#li-persona-desc").val().trim();
                if (!desc) { alert("Beskriv din målgruppe først."); return; }
                var comps = [];
                $(".li-comp-check:checked").each(function(){ comps.push($(this).val()); });
                btn.prop("disabled", true);
                $("#li-audience-spinner").show();
                $("#li-audience-result").hide();
                function renderAudienceResult(r){
                    $("#li-audience-spinner").hide();
                    btn.prop("disabled", false);
                    var el = $("#li-audience-result").show();
                    if (!r.success) {
                        el.html("<div class='li-result li-result-error'><strong>Fejl:</strong> " + (r.data ? r.data.message : "Ukendt fejl") + "</div>");
                        return;
                    }
                    var p  = r.data.profile  || {};
                    var rs = r.data.resonance || [];
                    var html = "";

                    // Alignment score banner
                    var score = p.alignment_score || 0;
                    var scoreClass = score >= 8 ? "li-score-high" : score >= 6 ? "li-score-mid" : "li-score-low";
                    html += "<div class='li-ask-card' style='margin-bottom:24px;'>";
                    html += "<div class='li-ask-header'>";
                    html += "<span class='li-ask-score " + scoreClass + "'>" + score + "<small>/10</small></span>";
                    html += "<span class='li-ask-verdict'>" + $("<span>").text(p.persona_name || "Din målgruppe").html() + " — " + $("<span>").text(p.gap_analysis || "").html() + "</span>";
                    html += "</div>";
                    html += "<div class='li-ask-grid' style='grid-template-columns:1fr;'>";
                    html += "<div><strong>Anbefaling</strong><p>" + $("<span>").text(p.recommendation || "").html() + "</p></div>";
                    html += "</div></div>";

                    // Two-column persona comparison
                    function renderPersona(data, title, cls) {
                        if (!data) return "";
                        var s = "<div class='li-persona-col " + cls + "'>";
                        s += "<h3 class='li-persona-col-title'>" + title + "</h3>";
                        s += "<div class='li-persona-section'><strong>Hvem de er</strong><p>" + $("<span>").text(data.who || "").html() + "</p></div>";
                        s += "<div class='li-persona-section'><strong>Hvordan de rejser i dag</strong><p>" + $("<span>").text(data.how_they_travel || "").html() + "</p></div>";
                        if (data.wallet && data.wallet.length) {
                            s += "<div class='li-persona-section'><strong>Rejsepung</strong><ul class='li-persona-list'>";
                            $.each(data.wallet, function(i, w){ s += "<li>" + $("<span>").text(w).html() + "</li>"; });
                            s += "</ul></div>";
                        }
                        if (data.behavioral_signals && data.behavioral_signals.length) {
                            s += "<div class='li-persona-section'><strong>Adfærdssignaler</strong><ul class='li-persona-list'>";
                            $.each(data.behavioral_signals, function(i, b){ s += "<li>" + $("<span>").text(b).html() + "</li>"; });
                            s += "</ul></div>";
                        }
                        s += "</div>";
                        return s;
                    }

                    html += "<div class='li-persona-grid'>";
                    html += renderPersona(p.target_persona,  "Din målgruppe",        "li-persona-target");
                    html += renderPersona(p.current_audience, "Nuværende læser",     "li-persona-current");
                    html += "</div>";

                    // Cluster resonance
                    if (rs.length) {
                        html += "<div class='li-insights-section' style='margin-top:28px;'><h2>Resonans per klynge</h2>";
                        html += "<div class='li-resonance-grid'>";
                        $.each(rs, function(i, item){
                            var fitClass = item.primary_fit >= 8 ? "res-high" : item.primary_fit >= 5 ? "res-mid" : "res-low";
                            html += "<div class='li-resonance-card" + (item.mismatch ? " li-resonance-mismatch" : "") + "'>";
                            html += "<div class='li-resonance-head'>";
                            html += "<span class='li-resonance-name'>" + $("<span>").text(item.cluster).html() + "</span>";
                            if (item.mismatch) html += "<span class='li-mismatch-flag'>⚠ Mismatch</span>";
                            html += "</div>";
                            html += "<div class='li-resonance-primary " + fitClass + "'>";
                            html += "<strong>Primær fit: " + item.primary_fit + "/10</strong><br>";
                            html += "<small>" + $("<span>").text(item.primary_reason || "").html() + "</small>";
                            html += "</div>";
                            if (item.comparisons && item.comparisons.length) {
                                html += "<div class='li-resonance-comps'>";
                                $.each(item.comparisons, function(j, c){
                                    var cClass = c.score >= 7 ? "res-high" : c.score >= 4 ? "res-mid" : "res-low";
                                    html += "<div class='li-resonance-comp " + cClass + "'>";
                                    html += "<span class='li-resonance-comp-name'>" + $("<span>").text(c.key).html() + "</span>";
                                    html += "<span class='li-resonance-comp-score'>" + c.score + "/10</span>";
                                    html += "</div>";
                                });
                                html += "</div>";
                            }
                            if (item.mismatch_reason) {
                                html += "<p class='li-mismatch-reason'>" + $("<span>").text(item.mismatch_reason).html() + "</p>";
                            }
                            html += "</div>";
                        });
                        html += "</div></div>";
                    }

                    el.html(html);
                }
                var anonce = "<?php echo esc_js( wp_create_nonce('li_async') ); ?>";
                function afail(msg){ $("#li-audience-spinner").hide(); btn.prop("disabled", false); $("#li-audience-result").show().html("<div class='li-result li-result-error'>"+msg+"</div>"); }
                $.post(ajaxurl, {action:"li_async_start", type:"audience", nonce:anonce, args:{persona_desc:desc, comparison_personas:comps}}, function(s){
                    if(!s.success || !s.data.job){ afail("Kunne ikke starte målgruppeanalysen — prøv igen."); return; }
                    var job=s.data.job, tries=0;
                    var iv=setInterval(function(){
                        tries++;
                        $.post(ajaxurl, {action:"li_async_poll", job:job, nonce:anonce}, function(p){
                            if(!p.success){ clearInterval(iv); afail(p.data?p.data.message:"Poll-fejl."); return; }
                            if(p.data.status==="running"){ if(tries>120){ clearInterval(iv); afail("Tager usædvanlig lang tid — prøv igen."); } return; }
                            clearInterval(iv);
                            if(p.data.status==="done"){ renderAudienceResult({success:true, data:(p.data.result||{})}); }
                            else { afail(p.data.message||"Målgruppeanalysen fejlede."); }
                        }).fail(function(){ if(tries>120){ clearInterval(iv); afail("Forbindelsen svigtede."); } });
                    }, 3000);
                }).fail(function(){ afail("Kunne ikke starte målgruppeanalysen — prøv igen."); });
            });

            // Prescription button handler
            $(document).on("click", ".li-prescribe-btn", function(){
                var btn     = $(this);
                var cluster = btn.data("cluster");
                var box     = btn.siblings(".li-prescription-box");
                if (box.is(":visible")) { box.slideUp(150); return; }
                var c = liClusterData[cluster];
                if (!c) { box.html("<div style='padding:8px 12px;color:#b32d2e;'>Ingen klyngedata for denne klynge — kør klyngeanalysen igen.</div>").slideDown(150); return; }
                btn.prop("disabled", true);
                $.post(ajaxurl, {
                    action: "li_cluster_prescription",
                    nonce:  btn.data("nonce"),
                    cluster_score:   c.cluster_score,
                    post_count:      c.post_count,
                    avg_position:    c.avg_position,
                    total_clicks:    c.total_clicks,
                    momentum:        c.momentum,
                    avg_session:     c.avg_session,
                    avg_bounce:      c.avg_bounce
                }, function(r){
                    btn.prop("disabled", false);
                    if (!r.success) return;
                    var d = r.data;
                    var h = "<div style='background:#f6f7f7;border:1px solid #ccd0d4;border-radius:4px;padding:10px 14px;margin-top:8px;'>";
                    h += "<div style='font-weight:600;margin-bottom:6px;'>Score " + d.current + " → potentielt <span style='color:#46b450;'>" + d.potential + "/10</span></div>";
                    h += "<ol style='margin:0 0 0 18px;line-height:1.7;'>";
                    $.each(d.actions, function(i, a){
                        h += "<li>" + $("<span>").text(a.text).html() + " <span style='background:#46b450;color:#fff;border-radius:3px;padding:0 5px;font-size:11px;font-weight:600;white-space:nowrap;'>+" + a.gain + "</span></li>";
                    });
                    h += "</ol></div>";
                    box.html(h).slideDown(200);
                });
            });

            // Access management
            $("#li-grant-access").on("click", function(){
                var btn   = $(this);
                var email = $("#li-grant-email").val().trim();
                if (!email) return;
                btn.prop("disabled", true);
                $.post(ajaxurl, {action:"li_grant_access", email:email, nonce:btn.data("nonce")}, function(r){
                    btn.prop("disabled", false);
                    if (r.success) {
                        $("#li-grant-status").html("<span class='li-badge li-badge-ok'>Adgang givet til " + $("<span>").text(r.data.name).html() + "</span>");
                        $("#li-grant-email").val("");
                    } else {
                        $("#li-grant-status").text(r.data ? r.data.message : "Fejl");
                    }
                });
            });

            $(document).on("click", ".li-revoke-access", function(){
                var btn = $(this), uid = btn.data("user-id");
                btn.prop("disabled", true);
                $.post(ajaxurl, {action:"li_revoke_access", user_id:uid, nonce:btn.data("nonce")}, function(r){
                    if (r.success) btn.closest("tr").fadeOut(300, function(){ $(this).remove(); });
                    else btn.prop("disabled", false);
                });
            });

            // Partner Intelligence
            var liPartnerData = {};
            var liClusterData = {};
            $(document).on("click", ".li-goto-tab", function(){ var b=document.querySelector('.li-tab-btn[data-tab="'+$(this).data("goto")+'"]'); if(b) b.click(); });
            var ptypeLabels = {
                tourism_board:"Turistbureau", airline:"Flyselskab", cruise:"Krydstogt",
                hotel_group:"Hotelkæde", dmo:"DMO", travel_agency:"Rejsebureau",
                train:"Togrejser", other:"Partner"
            };
            var contactLabels = {
                content_partnership:"Indholdssamarbejde", sponsored_content:"Sponsoreret indhold",
                press_trip:"Presserejse", affiliate:"Affiliate", advertising:"Annoncering"
            };
            var priorityLabels = { "høj":"Høj", "middel":"Middel", "lav":"Lav" };

            $("#li-seed-partners").on("click", function(){
                var btn = $(this), nonce = btn.data("nonce"), status = $("#li-seed-status");
                btn.prop("disabled", true);
                status.html('<span class="spinner is-active" style="float:none;margin:0 4px"></span> Importerer...');
                $.post(ajaxurl, {action:"li_seed_partners", nonce:nonce}, function(r){
                    btn.prop("disabled", false);
                    if (r.success) {
                        status.html('<strong style="color:#27ae60">✓ ' + r.data.created + ' oprettet, ' + r.data.skipped + ' fandtes i forvejen.</strong> <a href="' + r.data.url + '">Se alle partnere →</a>');
                        btn.text("Synkroniser standardpartnere");
                    } else {
                        status.html('<span style="color:#c0392b">Fejl: ' + (r.data ? r.data.message : '?') + '</span>');
                    }
                }).fail(function(){ btn.prop("disabled", false); status.html('<span style="color:#c0392b">AJAX fejl</span>'); });
            });

            $("#li-run-partners").on("click", function(){
                var btn = $(this), nonce = btn.data("nonce");
                btn.prop("disabled", true);
                $("#li-partners-spinner").show();
                $("#li-partners-result").hide();
                function renderPartnersResult(r){
                    $("#li-partners-spinner").hide();
                    btn.prop("disabled", false);
                    var el = $("#li-partners-result").show();
                    if (!r.success) {
                        el.html("<div class='li-result li-result-error'><strong>Fejl:</strong> " + (r.data ? r.data.message : "Ukendt fejl") + "</div>");
                        return;
                    }
                    var d = r.data;
                    var html = "";

                    // Summary banner
                    if (d.summary) {
                        html += "<div class='li-cluster-summary'>" + $("<span>").text(d.summary).html() + "</div>";
                    }

                    // Top opportunities
                    if (d.top_opportunities && d.top_opportunities.length) {
                        html += "<div class='li-partners-section'><h2>Top partnerskabsmuligheder</h2><div class='li-partner-top-grid'>";
                        $.each(d.top_opportunities, function(i, op){
                            var prio = op.priority || "middel";
                            html += "<div class='li-partner-top-card prio-" + prio + "'>";
                            html += "<div class='li-partner-top-head'>";
                            html += "<span class='li-ptype-badge ptype-" + op.type + "'>" + (ptypeLabels[op.type]||op.type) + "</span>";
                            html += "<span class='li-prio-badge prio-" + prio + "'>" + (priorityLabels[prio]||prio) + "</span>";
                            html += "</div>";
                            html += "<strong>" + $("<span>").text(op.partner).html() + "</strong>";
                            html += "<p class='li-partner-cluster-tag'>" + $("<span>").text(op.cluster).html() + "</p>";
                            html += "<p>" + $("<span>").text(op.reason).html() + "</p>";
                            html += "</div>";
                        });
                        html += "</div></div>";
                    }

                    // Airline routes
                    if (d.airline_routes && d.airline_routes.length) {
                        html += "<div class='li-partners-section'><h2>Flyrutemuligheder — Nordiske afgange</h2><div class='li-airline-grid'>";
                        $.each(d.airline_routes, function(i, ar){
                            html += "<div class='li-airline-card'>";
                            html += "<div class='li-airline-head'>";
                            html += "<span class='li-airline-route'>" + $("<span>").text(ar.route).html() + "</span>";
                            html += "<span class='li-airline-name'>" + $("<span>").text(ar.airline).html() + "</span>";
                            html += "</div>";
                            html += "<p class='li-partner-cluster-tag'>" + $("<span>").text(ar.cluster).html() + "</p>";
                            html += "<p class='li-partner-pitch'>" + $("<span>").text(ar.pitch).html() + "</p>";
                            html += "<button class='button button-small li-copy-pitch' data-pitch='" + $("<span>").text(ar.pitch).html() + "'>Kopiér pitch</button>";
                            html += "</div>";
                        });
                        html += "</div></div>";
                    }

                    // Per-cluster partner cards
                    if (d.cluster_partners && d.cluster_partners.length) {
                        html += "<div class='li-partners-section'><h2>Partnere per klynge</h2>";
                        $.each(d.cluster_partners, function(i, cp){
                            if (!cp.partners || !cp.partners.length) return;
                            html += "<div class='li-cluster-partner-block'>";
                            html += "<h3 class='li-cluster-partner-title'>" + $("<span>").text(cp.cluster).html();
                            if (cp.cluster_clicks) html += " <small class='li-cluster-traffic'>" + cp.cluster_clicks + " klik/md</small>";
                            html += "</h3>";
                            html += "<div class='li-partner-grid'>";
                            $.each(cp.partners, function(j, p){
                                var btnId = "li-push-" + i + "-" + j;
                                liPartnerData[btnId] = {
                                    name: p.name, type: p.type,
                                    cluster: cp.cluster, cluster_clicks: cp.cluster_clicks || 0,
                                    relevance: p.relevance || 0, why: p.why || "",
                                    pitch: p.pitch || "", contact_type: p.contact_type || ""
                                };
                                html += "<div class='li-partner-card ptype-border-" + p.type + "'>";
                                html += "<div class='li-partner-card-head'>";
                                html += "<span class='li-ptype-badge ptype-" + p.type + "'>" + (ptypeLabels[p.type]||p.type) + "</span>";
                                if (p.relevance) html += "<span class='li-partner-relevance'>" + p.relevance + "<small>/10</small></span>";
                                html += "</div>";
                                html += "<strong class='li-partner-name'>" + $("<span>").text(p.name).html() + "</strong>";
                                if (p.country) html += "<span class='li-partner-country'>" + $("<span>").text(p.country).html() + "</span>";
                                html += "<p class='li-partner-why'>" + $("<span>").text(p.why).html() + "</p>";
                                if (p.pitch) {
                                    html += "<div class='li-partner-pitch-box'>";
                                    html += "<strong>Pitch:</strong> <span class='li-partner-pitch'>" + $("<span>").text(p.pitch).html() + "</span>";
                                    html += "<button class='button button-small li-copy-pitch' style='margin-top:6px;display:block' data-pitch='" + $("<span>").text(p.pitch).html() + "'>Kopiér pitch</button>";
                                    html += "</div>";
                                }
                                if (p.contact_type) {
                                    html += "<span class='li-contact-badge'>" + (contactLabels[p.contact_type]||p.contact_type) + "</span> ";
                                }
                                html += "<button class='button button-small li-push-partner' id='" + btnId + "' data-nonce='<?php echo wp_create_nonce('li_push_partner'); ?>' style='margin-top:8px;display:block'>Send til LeisureRelate</button>";
                                html += "<span class='li-push-status' style='font-size:12px;display:block;margin-top:4px;'></span>";
                                html += "</div>";
                            });
                            html += "</div></div>";
                        });
                        html += "</div>";
                    }

                    el.html(html);
                }
                // Run the partner engine in the background (it's a long Claude op) + poll.
                var anonce = "<?php echo esc_js( wp_create_nonce('li_async') ); ?>";
                function pfail(msg){ $("#li-partners-spinner").hide(); btn.prop("disabled", false); $("#li-partners-result").show().html("<div class='li-result li-result-error'>"+msg+"</div>"); }
                $.post(ajaxurl, {action:"li_async_start", type:"partners", nonce:anonce}, function(s){
                    if(!s.success || !s.data.job){ pfail("Kunne ikke starte partner-analysen — prøv igen."); return; }
                    var job=s.data.job, tries=0;
                    var iv=setInterval(function(){
                        tries++;
                        $.post(ajaxurl, {action:"li_async_poll", job:job, nonce:anonce}, function(p){
                            if(!p.success){ clearInterval(iv); pfail(p.data?p.data.message:"Poll-fejl."); return; }
                            if(p.data.status==="running"){ if(tries>120){ clearInterval(iv); pfail("Tager usædvanlig lang tid — prøv igen."); } return; }
                            clearInterval(iv);
                            if(p.data.status==="done"){ renderPartnersResult({success:true, data:(p.data.result||{})}); }
                            else { pfail(p.data.message||"Partner-analysen fejlede."); }
                        }).fail(function(){ if(tries>120){ clearInterval(iv); pfail("Forbindelsen svigtede."); } });
                    }, 3000);
                }).fail(function(){ pfail("Kunne ikke starte partner-analysen — prøv igen."); });
            });

            // Push partner to LeisureRelate CRM
            $(document).on("click", ".li-push-partner", function(){
                var btn    = $(this);
                var btnId  = btn.attr("id");
                var status = btn.siblings(".li-push-status");
                var d      = liPartnerData[btnId];
                if (!d) return;
                btn.prop("disabled", true);
                status.text("Sender...");
                $.post(ajaxurl, {
                    action: "li_push_partner_lead",
                    nonce:  btn.data("nonce"),
                    name:           d.name,
                    type:           d.type,
                    cluster:        d.cluster,
                    cluster_clicks: d.cluster_clicks,
                    relevance:      d.relevance,
                    why:            d.why,
                    pitch:          d.pitch,
                    contact_type:   d.contact_type
                }, function(r){
                    if (r.success) {
                        btn.hide();
                        status.html("<span class='li-badge li-badge-ok'>Sendt → LeisureRelate-kø ✓</span>");
                    } else {
                        btn.prop("disabled", false);
                        status.html("<span class='li-badge li-badge-warn'>" + (r.data ? r.data.message : "Fejl") + "</span>");
                    }
                }).fail(function(){
                    btn.prop("disabled", false);
                    status.text("AJAX fejl");
                });
            });

            // Copy pitch to clipboard
            $(document).on("click", ".li-copy-pitch", function(){
                var btn   = $(this);
                var pitch = btn.data("pitch");
                if (navigator.clipboard) {
                    navigator.clipboard.writeText(pitch).then(function(){
                        btn.text("Kopieret!").prop("disabled", true);
                        setTimeout(function(){ btn.text("Kopiér pitch").prop("disabled", false); }, 2000);
                    });
                }
            });

            // Add competitor
            $("#li-add-comp").on("click", function(){
                var domain = $("#li-comp-domain").val().trim();
                var name   = $("#li-comp-name").val().trim();
                var nonce  = $(this).data("nonce");
                if (!domain) { $("#li-comp-add-status").text("Indtast et domæne."); return; }
                $(this).prop("disabled", true);
                $("#li-comp-add-status").text("Tilføjer...");
                $.post(ajaxurl, {action:"li_add_competitor", domain:domain, name:name, nonce:nonce}, function(r){
                    $("#li-add-comp").prop("disabled", false);
                    if (r.success) {
                        $("#li-comp-domain").val("");
                        $("#li-comp-name").val("");
                        var md5 = r.data.hash;
                        $("#li-comp-table tbody").append(
                            "<tr id='li-comp-row-" + md5 + "'>" +
                            "<td>" + $("<span>").text(r.data.domain).html() + "</td>" +
                            "<td>" + $("<span>").text(r.data.name).html() + "</td>" +
                            "<td><button class='button button-small li-remove-comp' data-domain='" + $("<span>").text(r.data.domain).html() + "' data-nonce='<?php echo wp_create_nonce('li_remove_competitor'); ?>'>Fjern</button></td>" +
                            "</tr>"
                        );
                        $("#li-comp-add-status").html("<span class='li-badge li-badge-ok'>Tilføjet</span>");
                    } else {
                        $("#li-comp-add-status").text(r.data ? r.data.message : "Fejl.");
                    }
                });
            });

            // Remove competitor
            $(document).on("click", ".li-remove-comp", function(){
                var btn    = $(this);
                var domain = btn.data("domain");
                var nonce  = btn.data("nonce");
                btn.prop("disabled", true);
                $.post(ajaxurl, {action:"li_remove_competitor", domain:domain, nonce:nonce}, function(r){
                    if (r.success) {
                        btn.closest("tr").fadeOut(300, function(){ $(this).remove(); });
                    } else {
                        btn.prop("disabled", false);
                    }
                });
            });

            // Run competitive analysis
            $("#li-run-competitive").on("click", function(){
                var btn   = $(this), nonce = btn.data("nonce");
                btn.prop("disabled", true);
                $("#li-competitive-spinner").show();
                $("#li-competitive-result").hide();
                function renderCompetitiveResult(r){
                    $("#li-competitive-spinner").hide();
                    btn.prop("disabled", false);
                    var el = $("#li-competitive-result").show();
                    if (!r.success) {
                        el.html("<div class='li-result li-result-error'><strong>Fejl:</strong> " + (r.data ? r.data.message : "Ukendt fejl") + "</div>");
                        return;
                    }
                    var d = r.data;
                    var html = "";

                    if (d.summary) {
                        html += "<div class='li-cluster-summary'>" + $("<span>").text(d.summary).html() + "</div>";
                    }

                    function compSection(title, items, fields, cls) {
                        if (!items || !items.length) return "";
                        var s = "<div class='li-comp-section'><h2>" + title + "</h2><div class='li-comp-grid'>";
                        $.each(items, function(i, item){
                            s += "<div class='li-comp-card " + cls + "'>";
                            $.each(fields, function(j, f){
                                if (f.key === "competitors" && item[f.key]) {
                                    s += "<div class='li-comp-field'><strong>" + f.label + "</strong> " + $("<span>").text(item[f.key].join(", ")).html() + "</div>";
                                } else if (item[f.key]) {
                                    s += "<div class='li-comp-field'><strong>" + f.label + "</strong> " + $("<span>").text(item[f.key]).html() + "</div>";
                                }
                            });
                            s += "</div>";
                        });
                        s += "</div></div>";
                        return s;
                    }

                    html += compSection("Vores styrkepositioner", d.wins, [
                        {key:"cluster", label:"Klynge:"}, {key:"reason", label:"Hvorfor:"}, {key:"action", label:"Handling:"}
                    ], "li-comp-win");

                    html += compSection("Kamppladser", d.battlegrounds, [
                        {key:"cluster", label:"Klynge:"}, {key:"competitors", label:"Mod:"}, {key:"our_edge", label:"Vores kant:"}, {key:"action", label:"Handling:"}
                    ], "li-comp-battle");

                    html += compSection("Kan overlades til konkurrenter", d.cede, [
                        {key:"cluster", label:"Klynge:"}, {key:"competitors", label:"Domineret af:"}, {key:"reason", label:"Årsag:"}
                    ], "li-comp-cede");

                    html += compSection("Åbne felter — ingen dominerer", d.open_fields, [
                        {key:"topic", label:"Emne:"}, {key:"rationale", label:"Potentiale:"}, {key:"action", label:"Første skridt:"}
                    ], "li-comp-open");

                    if (d.destination_sov_gaps && d.destination_sov_gaps.length) {
                        html += compSection("Destinations-SOV gaps — vi taber søgesynlighed her", d.destination_sov_gaps, [
                            {key:"destination", label:"Destination:"}, {key:"keyword", label:"Søgeord:"}, {key:"dominated_by", label:"Domineret af:"}, {key:"upper_market_angle", label:"Vores vinkel:"}, {key:"cluster", label:"Klynge:"}
                        ], "li-comp-sov");
                    }

                    html += compSection("Turistbureau-mål (v3.4 Partner Intelligence)", d.tourism_board_targets, [
                        {key:"destination", label:"Destination:"}, {key:"cluster", label:"Vores klynge:"}, {key:"rationale", label:"Fit:"}, {key:"contact_approach", label:"Pitch:"}
                    ], "li-comp-tourism");

                    el.html(html);
                }
                var anonce = "<?php echo esc_js( wp_create_nonce('li_async') ); ?>";
                function cfail(msg){ $("#li-competitive-spinner").hide(); btn.prop("disabled", false); $("#li-competitive-result").show().html("<div class='li-result li-result-error'>"+msg+"</div>"); }
                $.post(ajaxurl, {action:"li_async_start", type:"competitors", nonce:anonce}, function(s){
                    if(!s.success || !s.data.job){ cfail("Kunne ikke starte konkurrentanalysen — prøv igen."); return; }
                    var job=s.data.job, tries=0;
                    var iv=setInterval(function(){
                        tries++;
                        $.post(ajaxurl, {action:"li_async_poll", job:job, nonce:anonce}, function(p){
                            if(!p.success){ clearInterval(iv); cfail(p.data?p.data.message:"Poll-fejl."); return; }
                            if(p.data.status==="running"){ if(tries>120){ clearInterval(iv); cfail("Tager usædvanlig lang tid — prøv igen."); } return; }
                            clearInterval(iv);
                            if(p.data.status==="done"){ renderCompetitiveResult({success:true, data:(p.data.result||{})}); }
                            else { cfail(p.data.message||"Konkurrentanalysen fejlede."); }
                        }).fail(function(){ if(tries>120){ clearInterval(iv); cfail("Forbindelsen svigtede."); } });
                    }, 3000);
                }).fail(function(){ cfail("Kunne ikke starte konkurrentanalysen — prøv igen."); });
            });

            // Write brief → article
            $(document).on("click", ".li-write-btn", function(){
                var btn = $(this), post_id = btn.data("id"), status = btn.siblings(".li-write-status");
                btn.prop("disabled", true);
                status.html('<span class="spinner is-active" style="float:none;margin:0 4px"></span> Skriver...');
                $.post(ajaxurl, {action:"li_write_brief", post_id:post_id, nonce:"<?php echo wp_create_nonce('li_write_brief'); ?>"}, function(r){
                    if (r.success) {
                        status.html('<a href="' + r.data.edit_link + '" class="li-badge li-badge-ok">Artikel klar →</a>');
                        btn.hide();
                    } else {
                        btn.prop("disabled", false);
                        status.html('<span class="li-badge li-badge-warn">Fejl: ' + (r.data ? r.data.message : '?') + '</span>');
                    }
                }).fail(function(){
                    btn.prop("disabled", false);
                    status.html('<span class="li-badge li-badge-warn">AJAX fejl</span>');
                });
            });
        })(jQuery);
        </script>
        <?php
    }

    public function ajax_run_now() {
        check_ajax_referer('li_run_now', 'nonce');
        if (!$this->can_access()) wp_send_json_error(['message' => 'Adgang nægtet.']);
        $cron   = new LI_Cron();
        $result = $cron->run_analysis();
        if ($result['success']) wp_send_json_success($result);
        else                    wp_send_json_error($result);
    }

    public function ajax_run_audit() {
        check_ajax_referer('li_run_audit', 'nonce');
        if (!$this->can_access()) wp_send_json_error(['message' => 'Adgang nægtet.']);

        $ga4_metrics = [];
        $ga4 = new LI_GA4();
        if ($ga4->is_configured()) {
            $r = $ga4->get_page_metrics(30);
            if (!is_wp_error($r)) $ga4_metrics = $r;
        }

        $audit  = new LI_Audit();
        $result = $audit->run($ga4_metrics);

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        $result['edit_link'] = !empty($result['report_id']) ? get_edit_post_link($result['report_id'], 'raw') : '';
        wp_send_json_success($result);
    }

    public function ajax_write_brief() {
        check_ajax_referer('li_write_brief', 'nonce');
        if (!$this->can_access()) wp_send_json_error(['message' => 'Adgang nægtet.']);

        $post_id = intval($_POST['post_id'] ?? 0);
        if (!$post_id) wp_send_json_error(['message' => 'Intet post ID.']);

        $writer = new LI_Writer();
        $result = $writer->write_from_brief($post_id);

        if (is_wp_error($result)) wp_send_json_error(['message' => $result->get_error_message()]);
        else                      wp_send_json_success($result);
    }

    public function ajax_run_clusters() {
        check_ajax_referer('li_run_clusters', 'nonce');
        if (!$this->can_access()) wp_send_json_error(['message' => 'Adgang nægtet.']);

        $clusters_class = new LI_Clusters();
        $clusters       = $clusters_class->get_cluster_data();

        if (empty($clusters)) {
            wp_send_json_error(['message' => 'Ingen klyngedata fundet. Kontrollér at der er publicerede indlæg med kategorier.']);
        }

        $claude   = new LI_Claude();
        $insights = $claude->get_cluster_insights($clusters);

        if (is_wp_error($insights)) {
            // Return cluster data without insights rather than failing entirely
            wp_send_json_success(['clusters' => $clusters, 'insights' => [], 'insights_error' => $insights->get_error_message()]);
        }

        wp_send_json_success(['clusters' => $clusters, 'insights' => $insights]);
    }

    public function ajax_push_partner_lead() {
        check_ajax_referer('li_push_partner', 'nonce');
        if (!$this->can_access()) wp_send_json_error(['message' => 'Adgang nægtet.']);

        if (!class_exists('LRS_API')) {
            wp_send_json_error(['message' => 'LeisureRelate Satellite ikke aktiv på dette site.']);
        }
        if (!LRS_API::is_configured()) {
            wp_send_json_error(['message' => 'LeisureRelate hub ikke konfigureret — se LeisureRelate → Indstillinger.']);
        }

        $name           = sanitize_text_field($_POST['name'] ?? '');
        $type           = sanitize_text_field($_POST['type'] ?? '');
        $cluster        = sanitize_text_field($_POST['cluster'] ?? '');
        $cluster_clicks = intval($_POST['cluster_clicks'] ?? 0);
        $relevance      = intval($_POST['relevance'] ?? 0);
        $why            = sanitize_textarea_field($_POST['why'] ?? '');
        $pitch          = sanitize_textarea_field($_POST['pitch'] ?? '');
        $contact_type   = sanitize_text_field($_POST['contact_type'] ?? '');

        if (!$name) wp_send_json_error(['message' => 'Mangler partnernavn.']);

        $priority = $relevance >= 8 ? 'high' : ($relevance >= 5 ? 'medium' : 'low');

        $notes  = "Partner Intelligence — identificeret via LeisureIntel v3.5\n";
        $notes .= "Partnertype: {$type}\n";
        $notes .= "Klynge: {$cluster}" . ($cluster_clicks ? " ({$cluster_clicks} klik/md på Google)" : '') . "\n";
        $notes .= "Relevans: {$relevance}/10\n";
        if ($why)          $notes .= "Fit: {$why}\n";
        if ($pitch)        $notes .= "Pitch: {$pitch}\n";
        if ($contact_type) $notes .= "Anbefalet kontaktform: {$contact_type}\n";

        // Push as a prospect into LeisureRelate's queue (via the satellite's configured hub link).
        $prospect = [
            'name'     => $name,
            'org'      => $name,
            'website'  => '',
            'market'   => 'dk',
            'type'     => $type ?: 'other',
            'priority' => $priority,
            'notes'    => $notes,
            'source'   => 'leisureintel-partner',
        ];

        $res = LRS_API::post('queue', ['prospects' => [$prospect]]);
        if (is_wp_error($res)) {
            wp_send_json_error(['message' => 'Hub-fejl: ' . $res->get_error_message()]);
        }

        $saved = is_array($res) ? intval($res['saved'] ?? 0) : 0;
        if (!$saved) {
            wp_send_json_error(['message' => 'Hub gemte ikke prospektet.']);
        }

        wp_send_json_success(['name' => $name, 'saved' => $saved]);
    }

    public function ajax_cluster_prescription() {
        check_ajax_referer('li_cluster_prescription', 'nonce');
        if (!$this->can_access()) wp_send_json_error(['message' => 'Adgang nægtet.']);

        $data = [
            'cluster_score'  => floatval($_POST['cluster_score'] ?? 0),
            'post_count'     => intval($_POST['post_count'] ?? 0),
            'avg_position'   => $_POST['avg_position'] !== '' ? floatval($_POST['avg_position']) : null,
            'total_clicks'   => intval($_POST['total_clicks'] ?? 0),
            'momentum'       => floatval($_POST['momentum'] ?? 0),
            'avg_session'    => $_POST['avg_session'] !== '' && $_POST['avg_session'] !== 'null' ? floatval($_POST['avg_session']) : null,
            'avg_bounce'     => $_POST['avg_bounce'] !== '' && $_POST['avg_bounce'] !== 'null' ? floatval($_POST['avg_bounce']) : null,
        ];

        $clusters = new LI_Clusters();
        $result   = $clusters->get_prescription($data);
        wp_send_json_success($result);
    }

    public function ajax_grant_access() {
        check_ajax_referer('li_grant_access', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Kun administratorer kan give adgang.']);

        $email = sanitize_email($_POST['email'] ?? '');
        $user  = get_user_by('email', $email);
        if (!$user) wp_send_json_error(['message' => 'Ingen bruger fundet med den email.']);

        $user->add_cap('li_access');
        wp_send_json_success(['name' => $user->display_name]);
    }

    public function ajax_revoke_access() {
        check_ajax_referer('li_revoke_access', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Kun administratorer kan fjerne adgang.']);

        $uid  = intval($_POST['user_id'] ?? 0);
        $user = get_user_by('id', $uid);
        if ($user) $user->remove_cap('li_access');
        wp_send_json_success();
    }

    public function ajax_save_persona() {
        check_ajax_referer('li_save_persona', 'nonce');
        if (!$this->can_access()) wp_send_json_error(['message' => 'Adgang nægtet.']);

        $desc  = sanitize_textarea_field($_POST['persona_desc'] ?? '');
        $comps = array_map('sanitize_text_field', (array)($_POST['comparison_personas'] ?? []));

        update_option('li_primary_persona', $desc);
        update_option('li_comparison_personas', $comps);

        $audience = new LI_Audience();
        $audience->clear_cache();

        wp_send_json_success();
    }

    public function ajax_run_audience() {
        check_ajax_referer('li_run_audience', 'nonce');
        if (!$this->can_access()) wp_send_json_error(['message' => 'Adgang nægtet.']);

        $persona_desc = sanitize_textarea_field($_POST['persona_desc'] ?? '');
        $comp_keys    = array_map('sanitize_text_field', (array)($_POST['comparison_personas'] ?? []));

        if (empty($persona_desc)) {
            wp_send_json_error(['message' => 'Beskriv din målgruppe først.']);
        }

        // Save immediately
        update_option('li_primary_persona', $persona_desc);
        update_option('li_comparison_personas', $comp_keys);

        // Get cluster data
        $clusters_class = new LI_Clusters();
        $clusters       = $clusters_class->get_cluster_data();
        if (empty($clusters)) {
            wp_send_json_error(['message' => 'Ingen klyngedata — kør klyngeanalyse først.']);
        }

        // Get top GSC queries
        $data_class = new LI_Data();
        $queries    = $data_class->get_top_queries(60, 30);

        // Build comparison personas
        $audience          = new LI_Audience();
        $all_types         = $audience->all_persona_types();
        $comparison_personas = [];
        foreach ($comp_keys as $k) {
            if (isset($all_types[$k])) $comparison_personas[$k] = $all_types[$k];
        }

        $claude = new LI_Claude();

        // Run persona inference (Sonnet)
        $profile = $claude->get_persona_inference($clusters, $queries, $persona_desc);
        if (is_wp_error($profile)) {
            wp_send_json_error(['message' => 'Persona inference fejlede: ' . $profile->get_error_message()]);
        }

        // Run resonance scoring (Haiku)
        $resonance = [];
        if (!empty($comparison_personas)) {
            $resonance = $claude->get_audience_resonance($clusters, $persona_desc, $comparison_personas);
            if (is_wp_error($resonance)) $resonance = [];
        }

        // Cache results
        $audience->save_profile($profile);
        $audience->save_resonance($resonance);

        wp_send_json_success(['profile' => $profile, 'resonance' => $resonance]);
    }

    public function ajax_run_partners() {
        check_ajax_referer('li_run_partners', 'nonce');
        if (!$this->can_access()) wp_send_json_error(['message' => 'Adgang nægtet.']);

        $clusters_class = new LI_Clusters();
        $clusters       = $clusters_class->get_cluster_data();

        if (empty($clusters)) {
            wp_send_json_error(['message' => 'Ingen klyngedata — kontrollér at der er publicerede indlæg med kategorier.']);
        }

        $claude  = new LI_Claude();
        $result  = $claude->get_partner_suggestions($clusters);

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        $partners_class = new LI_Partners();
        $partners_class->save($result);

        wp_send_json_success($result);
    }

    public function ajax_seed_partners() {
        check_ajax_referer('li_seed_partners', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Adgang nægtet.']);

        $cpt    = new LI_Partner_CPT();
        $result = $cpt->seed_default_partners();

        wp_send_json_success([
            'created' => $result['created'],
            'skipped' => $result['skipped'],
            'url'     => admin_url('edit.php?post_type=partner'),
        ]);
    }

    public function ajax_add_competitor() {
        check_ajax_referer('li_add_competitor', 'nonce');
        if (!$this->can_access()) wp_send_json_error(['message' => 'Adgang nægtet.']);

        $domain = sanitize_text_field($_POST['domain'] ?? '');
        $name   = sanitize_text_field($_POST['name'] ?? '');

        $comp = new LI_Competitors();
        if (!$comp->add_competitor($domain, $name)) {
            wp_send_json_error(['message' => 'Kunne ikke tilføje — allerede på listen eller ugyldigt domæne.']);
        }

        $clean = strtolower(trim(preg_replace('/^https?:\/\/(www\.)?/', '', $domain)));
        wp_send_json_success([
            'domain' => $clean,
            'name'   => $name ?: ucfirst(explode('.', $clean)[0]),
            'hash'   => md5($clean),
        ]);
    }

    public function ajax_remove_competitor() {
        check_ajax_referer('li_remove_competitor', 'nonce');
        if (!$this->can_access()) wp_send_json_error(['message' => 'Adgang nægtet.']);

        $domain = sanitize_text_field($_POST['domain'] ?? '');
        $comp   = new LI_Competitors();
        $comp->remove_competitor($domain);
        wp_send_json_success();
    }

    public function ajax_run_competitive() {
        check_ajax_referer('li_run_competitive', 'nonce');
        if (!$this->can_access()) wp_send_json_error(['message' => 'Adgang nægtet.']);

        // Scrape competitors (force fresh)
        $comp_class  = new LI_Competitors();
        $competitors = $comp_class->get_scraped_data(true);

        if (empty($competitors)) {
            wp_send_json_error(['message' => 'Ingen konkurrentdata — kontrollér at der er tilføjet konkurrenter.']);
        }

        // Get cluster data
        $clusters_class = new LI_Clusters();
        $clusters       = $clusters_class->get_cluster_data();

        if (empty($clusters)) {
            wp_send_json_error(['message' => 'Ingen klyngedata — kør venligst klyngeanalyse først eller tjek at indlæg har kategorier.']);
        }

        // Run Claude competitive analysis
        $claude = new LI_Claude();
        $result = $claude->get_competitive_analysis($clusters, $competitors);

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success($result);
    }

    public function ajax_ask() {
        check_ajax_referer('li_ask', 'nonce');
        if (!$this->can_access()) wp_send_json_error(['message' => 'Adgang nægtet.']);

        $query = sanitize_textarea_field($_POST['query'] ?? '');
        if (empty($query)) wp_send_json_error(['message' => 'Intet spørgsmål modtaget.']);

        // Get current dataset for context (non-blocking GA4)
        $data_class = new LI_Data();
        $dataset    = $data_class->get_analysis_dataset(20);

        // Fall back to basic GSC if dataset is empty
        if (empty($dataset)) {
            $gsc = $data_class->get_top_gsc_pages(20, 30);
            $dataset = $data_class->enrich_with_post_data($gsc);
        }

        $claude = new LI_Claude();
        $result = $claude->get_on_demand_analysis($query, $dataset);

        if (is_wp_error($result)) wp_send_json_error(['message' => $result->get_error_message()]);
        else                      wp_send_json_success($result);
    }
}
