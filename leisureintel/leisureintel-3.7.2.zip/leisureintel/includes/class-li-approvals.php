<?php
if (!defined('ABSPATH')) exit;

/**
 * LI_Approvals — Approval gate for all LeisureIntel content actions.
 *
 * Workflow:
 *  1. LI_Audit::run() saves structured results to li_pending_actions option.
 *  2. Admin reviews actions in LeisureIntel → Afventende handlinger tab.
 *  3. Each action requires an individual "Godkend" (approve) click.
 *  4. Every execution is logged permanently in li_action_log.
 *  5. Nothing is permanently deleted — "slet" means set to draft only.
 */
class LI_Approvals {

    const PENDING_OPTION = 'li_pending_actions';
    const LOG_OPTION     = 'li_action_log';

    // ── Save pending actions after audit run ─────────────────────────────────

    public static function save_pending( array $results, int $report_id ) {
        $pending = [];
        foreach ( $results as $item ) {
            if ( empty( $item['post_id'] ) || $item['action'] === 'behold' ) continue;
            $pending[] = [
                'post_id'   => (int) $item['post_id'],
                'title'     => $item['title'],
                'action'    => $item['action'],   // slet | viderestil | forbedring
                'reason'    => $item['reason'],
                'clicks'    => $item['clicks'] ?? 0,
                'position'  => $item['position'] ?? null,
                'pageviews' => $item['pageviews'] ?? 0,
                'report_id' => $report_id,
                'queued_at' => current_time('mysql'),
                'status'    => 'pending',         // pending | approved | skipped
            ];
        }
        update_option( self::PENDING_OPTION, $pending );
    }

    // ── Execute a single approved action ─────────────────────────────────────

    public static function apply_action( int $post_id, string $action, int $admin_id ): array {
        $post = get_post( $post_id );
        if ( ! $post ) return [ 'success' => false, 'message' => 'Post ikke fundet.' ];

        $result_msg = '';

        switch ( $action ) {

            case 'slet':
                // NEVER permanently delete — move to draft only
                wp_update_post([ 'ID' => $post_id, 'post_status' => 'draft' ]);
                $result_msg = 'Sat til kladde (aldrig permanent slettet).';
                break;

            case 'viderestil':
                // Flag for redirect review — set draft + meta, human sets redirect URL
                wp_update_post([ 'ID' => $post_id, 'post_status' => 'draft' ]);
                update_post_meta( $post_id, '_li_redirect_pending', 1 );
                $result_msg = 'Sat til kladde + markeret til omdirigering. Tilføj redirect URL manuelt.';
                break;

            case 'forbedring':
                // Just flag for improvement — do NOT change status
                update_post_meta( $post_id, '_li_needs_improvement', 1 );
                update_post_meta( $post_id, '_li_improvement_date', current_time('mysql') );
                $result_msg = 'Markeret til forbedring. Status uændret.';
                break;

            default:
                return [ 'success' => false, 'message' => 'Ukendt handling: ' . esc_html($action) ];
        }

        // Log permanently
        self::log_action( $post_id, $post->post_title, $action, $result_msg, $admin_id );

        // Mark as approved in pending queue
        self::mark_pending_status( $post_id, 'approved' );

        return [ 'success' => true, 'message' => $result_msg ];
    }

    public static function skip_action( int $post_id, int $admin_id ): array {
        $post = get_post( $post_id );
        $title = $post ? $post->post_title : "(ID $post_id)";
        self::log_action( $post_id, $title, 'skip', 'Oversprunget af administrator.', $admin_id );
        self::mark_pending_status( $post_id, 'skipped' );
        return [ 'success' => true, 'message' => 'Oversprunget.' ];
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static function log_action( int $post_id, string $title, string $action, string $result, int $admin_id ) {
        $log = get_option( self::LOG_OPTION, [] );
        array_unshift( $log, [
            'timestamp' => current_time('mysql'),
            'post_id'   => $post_id,
            'title'     => $title,
            'action'    => $action,
            'result'    => $result,
            'admin_id'  => $admin_id,
            'admin'     => get_userdata($admin_id) ? get_userdata($admin_id)->user_login : 'unknown',
        ]);
        update_option( self::LOG_OPTION, array_slice( $log, 0, 500 ) ); // keep last 500
    }

    private static function mark_pending_status( int $post_id, string $status ) {
        $pending = get_option( self::PENDING_OPTION, [] );
        foreach ( $pending as &$item ) {
            if ( (int)$item['post_id'] === $post_id ) {
                $item['status'] = $status;
                break;
            }
        }
        update_option( self::PENDING_OPTION, $pending );
    }

    public static function get_pending(): array {
        return get_option( self::PENDING_OPTION, [] );
    }

    public static function get_log( int $limit = 100 ): array {
        return array_slice( get_option( self::LOG_OPTION, [] ), 0, $limit );
    }

    public static function clear_pending() {
        delete_option( self::PENDING_OPTION );
    }
}
