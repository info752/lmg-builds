<?php
/**
 * LeisureIntel — Think-Smarter Source Verification Layer
 * Runs as a second API call after content generation.
 * Returns verification report array or WP_Error.
 * Only executes when li_site_id === 'think_smarter'.
 */
if (!defined('ABSPATH')) exit;

function get_think_smarter_verification_prompt() {
    return "
You are a rigorous fact-checking editor for Think-Smarter.net, an independent intellectual platform where accuracy and source integrity are non-negotiable.

You will receive a draft article. Your job is to audit it before it is published.

STEP 1 — IDENTIFY ALL FACTUAL CLAIMS
Extract every claim that is:
- A statistic or percentage (e.g. '70% of companies...')
- A named study, report, or survey (e.g. 'according to McKinsey...')
- A named organisation with a claim attached
- A historical fact presented as verified
- Any sentence containing: 'research shows', 'studies suggest', 'data from', 'according to', 'survey by', 'a report by', 'evidence shows'

STEP 2 — ASSESS EACH CLAIM
For each claim, assess:
- VERIFIED: Claim is well-established, widely documented, and specific enough to be trusted
- UNVERIFIED: Claim is specific (named study, exact figure) but no source is provided or linkable
- VAGUE: Claim is too general to verify or falsify — flag for rewriting with specificity or removal
- INVENTION RISK: Claim looks like it may have been generated without a real source — flag immediately

STEP 3 — CHECK FOR COMPETING AI PRODUCT NAMES
Scan the entire article for any mention of: GPT, ChatGPT, Gemini, Copilot, Grok, Mistral, LLaMA, Perplexity, or any other named AI product or company that is not Anthropic or Claude.
If found: FLAG AS CRITICAL VIOLATION. These must be removed and replaced with neutral language ('AI models', 'language models', 'AI tools').

STEP 4 — OUTPUT A VERIFICATION REPORT

Return your report in this exact format:

---
THINK-SMARTER VERIFICATION REPORT
---

COMPETING AI PRODUCT CHECK:
[ PASS / CRITICAL VIOLATION — list any violations ]

FLAGGED CLAIMS:
[ List each flagged claim with its assessment: VERIFIED / UNVERIFIED / VAGUE / INVENTION RISK ]
[ If UNVERIFIED or INVENTION RISK: suggest either a verifiable replacement or recommend removal ]

RECOMMENDED ACTIONS:
[ Numbered list of specific changes required before publication ]

OVERALL STATUS:
[ CLEAR FOR PUBLICATION / REQUIRES REVISION ]
---

Be direct. Be specific. Do not approve an article that contains invention-risk claims or named competing AI products under any circumstances.
";
}

/**
 * Run verification on a generated article.
 *
 * @param string $article_text  Raw Markdown article text from primary generation.
 * @param string $api_key       Claude API key.
 * @param string $model         Model to use (defaults to claude-opus-4-5).
 * @return array|WP_Error {
 *   'passed'  => bool,
 *   'report'  => string (full verification report),
 *   'blocked' => bool,
 * }
 */
function li_verify_think_smarter_article($article_text, $api_key, $model = 'claude-opus-4-5-20251101') {
    if (empty($api_key)) {
        return new WP_Error('li_verify_error', 'Claude API key not configured for verification.');
    }

    $body = json_encode([
        'model'      => $model,
        'max_tokens' => 2000,
        'system'     => get_think_smarter_verification_prompt(),
        'messages'   => [[
            'role'    => 'user',
            'content' => "Please verify this article:\n\n" . $article_text,
        ]],
    ]);

    $response = wp_remote_post('https://api.anthropic.com/v1/messages', [
        'timeout' => 60,
        'headers' => [
            'Content-Type'      => 'application/json',
            'x-api-key'         => $api_key,
            'anthropic-version' => '2023-06-01',
        ],
        'body' => $body,
    ]);

    if (is_wp_error($response)) {
        return new WP_Error('li_verify_error', 'Verification API call failed: ' . $response->get_error_message());
    }

    $code    = wp_remote_retrieve_response_code($response);
    $decoded = json_decode(wp_remote_retrieve_body($response), true);

    if ($code !== 200) {
        $msg = $decoded['error']['message'] ?? wp_remote_retrieve_body($response);
        return new WP_Error('li_verify_error', "Verification API HTTP {$code}: {$msg}");
    }

    $report = trim($decoded['content'][0]['text'] ?? '');
    if (empty($report)) {
        return new WP_Error('li_verify_error', 'Empty verification response from Claude.');
    }

    $passed = (strpos($report, 'CLEAR FOR PUBLICATION') !== false);

    return [
        'passed'  => $passed,
        'report'  => $report,
        'blocked' => !$passed,
    ];
}

/**
 * Log a failed verification to a WordPress draft post for editorial review.
 *
 * @param string $article_title  Title of the article that failed.
 * @param string $report         Full verification report text.
 * @param int    $brief_post_id  ID of the brief post that triggered writing.
 */
function li_log_verification_failure($article_title, $report, $brief_post_id = 0) {
    $log_title = '[BLOCKED] ' . $article_title . ' — ' . current_time('d M Y H:i');

    $content  = "<!-- wp:paragraph -->\n";
    $content .= "<p><strong>Article blocked by Think-Smarter verification layer.</strong></p>\n";
    $content .= "<!-- /wp:paragraph -->\n\n";

    if ($brief_post_id) {
        $edit_url = get_edit_post_link($brief_post_id, 'raw');
        $content .= "<!-- wp:paragraph -->\n";
        $content .= "<p>Brief post: <a href=\"{$edit_url}\">#{$brief_post_id}</a></p>\n";
        $content .= "<!-- /wp:paragraph -->\n\n";
    }

    $content .= "<!-- wp:preformatted -->\n";
    $content .= "<pre>" . esc_html($report) . "</pre>\n";
    $content .= "<!-- /wp:preformatted -->";

    wp_insert_post([
        'post_title'   => $log_title,
        'post_content' => $content,
        'post_status'  => 'draft',
        'post_type'    => 'post',
        'post_author'  => 1,
        'meta_input'   => [
            '_li_verification_blocked' => 1,
            '_li_verification_report'  => $report,
            '_li_brief_post_id'        => $brief_post_id,
        ],
    ]);

    error_log('LeisureIntel: Think-Smarter article blocked — ' . $article_title);
}
