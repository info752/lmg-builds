<?php
if (!defined('ABSPATH')) exit;

class LI_GA4 {

    private $credentials_path;
    private $property_id;
    private $access_token  = null;
    private $token_expiry  = 0;
    private $token_api_url = 'https://oauth2.googleapis.com/token';
    private $data_api_base = 'https://analyticsdata.googleapis.com/v1beta/properties';

    public function __construct() {
        $this->credentials_path = get_option(
            'li_ga4_credentials_path',
            '/home/u348443041/domains/traveltalk.dk/public_html/wp-content/scripts/ga_credentials.json'
        );
        $this->property_id = get_option('li_ga4_property_id', '445373117');
    }

    public function is_configured() {
        return file_exists($this->credentials_path) && !empty($this->property_id);
    }

    private function get_access_token() {
        if ($this->access_token && time() < $this->token_expiry - 60) {
            return $this->access_token;
        }

        if (!file_exists($this->credentials_path)) {
            return new WP_Error('li_ga4_error', 'GA4 credentials file not found: ' . $this->credentials_path);
        }

        $creds = json_decode(file_get_contents($this->credentials_path), true);
        if (!$creds || empty($creds['private_key']) || empty($creds['client_email'])) {
            return new WP_Error('li_ga4_error', 'Invalid GA4 credentials file — missing private_key or client_email.');
        }

        $now = time();
        $exp = $now + 3600;

        $header  = rtrim(strtr(base64_encode(json_encode(['alg' => 'RS256', 'typ' => 'JWT'])), '+/', '-_'), '=');
        $payload = rtrim(strtr(base64_encode(json_encode([
            'iss'   => $creds['client_email'],
            'scope' => 'https://www.googleapis.com/auth/analytics.readonly',
            'aud'   => $this->token_api_url,
            'exp'   => $exp,
            'iat'   => $now,
        ])), '+/', '-_'), '=');

        $to_sign  = $header . '.' . $payload;
        $sig_raw  = '';
        $ok       = openssl_sign($to_sign, $sig_raw, $creds['private_key'], 'SHA256');

        if (!$ok) {
            return new WP_Error('li_ga4_error', 'Failed to sign JWT with service account key.');
        }

        $sig = rtrim(strtr(base64_encode($sig_raw), '+/', '-_'), '=');
        $jwt = $to_sign . '.' . $sig;

        $response = wp_remote_post($this->token_api_url, [
            'timeout' => 30,
            'body'    => [
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion'  => $jwt,
            ],
        ]);

        if (is_wp_error($response)) {
            return new WP_Error('li_ga4_error', 'Token exchange failed: ' . $response->get_error_message());
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (empty($body['access_token'])) {
            return new WP_Error('li_ga4_error', 'No access_token in response: ' . wp_remote_retrieve_body($response));
        }

        $this->access_token = $body['access_token'];
        $this->token_expiry = $now + ($body['expires_in'] ?? 3600);

        return $this->access_token;
    }

    /**
     * Fetch page-level metrics from GA4 for the last N days.
     * Returns array keyed by page path: pageviews, users, avg_session_duration, bounce_rate.
     */
    public function get_page_metrics($days = 30) {
        $body = [
            'dateRanges' => [
                ['startDate' => "{$days}daysAgo", 'endDate' => 'today'],
            ],
            'dimensions' => [
                ['name' => 'pagePath'],
            ],
            'metrics' => [
                ['name' => 'screenPageViews'],
                ['name' => 'activeUsers'],
                ['name' => 'averageSessionDuration'],
                ['name' => 'bounceRate'],
            ],
            'limit'     => 500,
            'orderBys'  => [['metric' => ['metricName' => 'screenPageViews'], 'desc' => true]],
        ];

        $raw = $this->run_report($body);
        if (is_wp_error($raw)) return $raw;

        $metrics = [];
        if (!empty($raw['rows'])) {
            foreach ($raw['rows'] as $row) {
                $path = $row['dimensionValues'][0]['value'] ?? '';
                $metrics[$path] = [
                    'pageviews'            => (int)($row['metricValues'][0]['value'] ?? 0),
                    'users'                => (int)($row['metricValues'][1]['value'] ?? 0),
                    'avg_session_duration' => round((float)($row['metricValues'][2]['value'] ?? 0), 1),
                    'bounce_rate'          => round((float)($row['metricValues'][3]['value'] ?? 0) * 100, 1),
                ];
            }
        }

        return $metrics;
    }

    /**
     * One GA4 Data API runReport call. $request is the report body as an array.
     * Returns the decoded response (dimensionHeaders, metricHeaders, rows, …) or WP_Error.
     * Shared by get_page_metrics() and LI_Flow — every caller costs one request against the property quota.
     */
    public function run_report($request) {
        $token = $this->get_access_token();
        if (is_wp_error($token)) return $token;

        $response = wp_remote_post(
            "{$this->data_api_base}/{$this->property_id}:runReport",
            [
                'timeout' => 30,
                'headers' => [
                    'Authorization' => 'Bearer ' . $token,
                    'Content-Type'  => 'application/json',
                ],
                'body' => json_encode($request),
            ]
        );

        if (is_wp_error($response)) {
            return new WP_Error('li_ga4_error', 'GA4 API request failed: ' . $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $raw  = json_decode(wp_remote_retrieve_body($response), true);

        if ($code !== 200) {
            $msg = isset($raw['error']['message']) ? $raw['error']['message'] : wp_remote_retrieve_body($response);
            return new WP_Error('li_ga4_error', "GA4 API HTTP {$code}: {$msg}");
        }

        return is_array($raw) ? $raw : [];
    }
}
