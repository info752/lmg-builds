<?php
if (!defined('ABSPATH')) exit;

class LI_Audience {

    const PROFILE_KEY   = 'li_persona_profile';
    const RESONANCE_KEY = 'li_audience_resonance';
    const CACHE_TTL     = 86400;

    public function get_primary_persona() {
        return get_option('li_primary_persona', '');
    }

    public function get_selected_comparison_keys() {
        return get_option('li_comparison_personas', ['budget', 'pure_luxury']);
    }

    public function get_comparison_personas() {
        $selected = $this->get_selected_comparison_keys();
        $all      = $this->all_persona_types();
        return array_intersect_key($all, array_flip($selected));
    }

    public function all_persona_types() {
        return [
            'budget'      => 'Prisbevidste rejsende — pakkerejser, tilbud, value-first, sammenligner priser, Charter og all-inclusive',
            'family'      => 'Familieferierende — børn, sikkerhed, bekvemmelighed, underholdning til alle aldre',
            'pure_luxury' => 'Ren luksusrejsende — udelukkende 5-stjernet, first class, privat jet, prestige og statussymboler',
            'adventure'   => 'Eventyrrejsende — aktiv, natur, trekking, off-the-beaten-path, fysiske udfordringer',
            'cultural'    => 'Kulturrejsende — storbyer, museer, lokal mad, historie, kunstscene',
            'backpacker'  => 'Backpacker — langtidsrejser, hostels, spontanitet, minimal budget',
        ];
    }

    public function get_cached_profile() {
        return get_transient(self::PROFILE_KEY);
    }

    public function save_profile($data) {
        set_transient(self::PROFILE_KEY, $data, self::CACHE_TTL);
    }

    public function get_cached_resonance() {
        return get_transient(self::RESONANCE_KEY);
    }

    public function save_resonance($data) {
        set_transient(self::RESONANCE_KEY, $data, self::CACHE_TTL);
    }

    public function clear_cache() {
        delete_transient(self::PROFILE_KEY);
        delete_transient(self::RESONANCE_KEY);
    }
}
