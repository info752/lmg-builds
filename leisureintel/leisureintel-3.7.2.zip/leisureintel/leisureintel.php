<?php
/*
Plugin Name: LeisureIntel
Description: Content intelligence platform — GSC + GA4 analysis, predictive opportunity scoring, content audit, competitor intelligence, and AI article writing.
Version: 3.7.2
Author: Leisure Media Group Ltd
*/

if (!defined('ABSPATH')) exit;

define('LI_VERSION', '3.7.2');
define('LI_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('LI_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once LI_PLUGIN_DIR . 'includes/class-li-ga4.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-data.php';
require_once LI_PLUGIN_DIR . 'includes/li-editorial-standards.php';
require_once LI_PLUGIN_DIR . 'includes/li-think-smarter-verifier.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-claude.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-generator.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-writer.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-clusters.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-competitors.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-partners.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-partner-cpt.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-audience.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-approvals.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-audit.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-cron.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-perflog.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-opportunity.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-ideabank.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-pillars.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-async.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-passthebar.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-ainna.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-reciprocity.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-hubrecommender.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-alerts.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-cadence.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-partnerfit.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-flow.php';
require_once LI_PLUGIN_DIR . 'includes/class-li-admin.php';

register_activation_hook(__FILE__, ['LI_Cron', 'activate']);
register_deactivation_hook(__FILE__, ['LI_Cron', 'deactivate']);
register_deactivation_hook(__FILE__, ['LI_Flow', 'deactivate']);

function leisureintel_init() {
    new LI_Admin();
    new LI_Cron();
    new LI_Partner_CPT();
    LI_Perflog::boot();      // Module 2 — Performance Log (table + handlers)
    LI_Opportunity::boot();  // Module 1 — Opportunity Score (manual-assist now)
    LI_Ideabank::boot();     // Idébank — suggestion store + hub assignment handlers
    LI_Pillars::boot();      // Søjler — two-signal pillar strategy map
    LI_Async::boot();        // async job runner — long ops run in background + poll
    LI_PassTheBar::boot();   // Pass the Bar — site-health scanner (finds only, never fixes)
    LI_Ainna::boot();        // AInna — reader-facing travel advisor (v1: pitch + pamphlets, admin test)
    LI_Reciprocity::boot();  // Klynge-links — hub↔spoke reciprocity check (finds gaps, never edits)
    LI_HubRecommender::boot(); // Hub-forslag — ranks which hubs to build next (demand×depth×gap + partner-fit)
    LI_Alerts::init();       // plugin-native top-relevance alerts (admin-bar badge + panel; replaces delete-mail)
    LI_Cadence::init();      // universal cross-site publishing-rhythm monitor + stagnation alert
    LI_PartnerFit::init();   // reverse partner search — type a company, assess whether/how they should partner with us
    LI_Flow::init();         // Besøgsflow — weekly GA4 visitor flow: hero clicks, next page, returning vs new, what converts
}
add_action('plugins_loaded', 'leisureintel_init');

// Hide internal tracking tags from front-end display
add_filter( 'get_the_terms', function( $terms, $post, $taxonomy ) {
    if ( is_admin() || $taxonomy !== 'post_tag' || ! is_array( $terms ) ) return $terms;
    $hidden = [ 'leisureintel', 'leisureintel-audit' ];
    return array_values( array_filter( $terms, fn( $t ) => ! in_array( $t->slug, $hidden, true ) ) );
}, 10, 3 );
