(function () {
    'use strict';

    var COOKIE_NAME = (typeof liLocale !== 'undefined') ? liLocale.cookie : 'li_locale';
    var EXPIRES_DAYS = 365;

    function setCookie(name, value, days) {
        var expires = new Date();
        expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000);
        document.cookie = name + '=' + encodeURIComponent(value) +
            '; expires=' + expires.toUTCString() +
            '; path=/; SameSite=Lax';
    }

    function init() {
        // Flag/tab links
        document.querySelectorAll('.li-locale-link').forEach(function (link) {
            link.addEventListener('click', function (e) {
                e.preventDefault();
                var locale = this.getAttribute('data-locale');
                if (!locale) return;
                setCookie(COOKIE_NAME, locale, EXPIRES_DAYS);

                // Update active state immediately (before reload)
                document.querySelectorAll('.li-locale-link').forEach(function (l) {
                    l.classList.remove('li-locale-active');
                });
                this.classList.add('li-locale-active');

                window.location.reload();
            });
        });

        // Dropdown
        var select = document.getElementById('li-locale-select');
        if (select) {
            select.addEventListener('change', function () {
                setCookie(COOKIE_NAME, this.value, EXPIRES_DAYS);
                window.location.reload();
            });
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
