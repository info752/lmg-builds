<?php
if (!defined('ABSPATH')) exit;

class LI_Cron {

    const HOOK       = 'leisureintel_weekly_run';
    const AUDIT_HOOK = 'leisureintel_weekly_audit';

    public function __construct() {
        add_action(self::HOOK,       [$this, 'run_analysis']);
        add_action(self::AUDIT_HOOK, [$this, 'run_audit']);
        add_filter('cron_schedules', [$this, 'add_weekly_schedule']);

        // CALL-ON, NOT PUSH (G 2026-07-19): the content audit must never auto-run.
        // Self-heal — if a weekly audit event is scheduled (from an old activation or anything
        // that re-adds it), clear it. The audit runs ONLY on demand via the admin button.
        add_action('admin_init', function () {
            if (wp_next_scheduled(self::AUDIT_HOOK)) {
                wp_clear_scheduled_hook(self::AUDIT_HOOK);
            }
        });
    }

    public function add_weekly_schedule($schedules) {
        if (!isset($schedules['weekly'])) {
            $schedules['weekly'] = ['interval' => WEEK_IN_SECONDS, 'display' => 'Once Weekly'];
        }
        return $schedules;
    }

    public static function activate() {
        // Register 'weekly' schedule in case WP version predates 5.4
        if (!in_array('weekly', array_keys(wp_get_schedules()))) {
            add_filter('cron_schedules', function($s) {
                $s['weekly'] = ['interval' => WEEK_IN_SECONDS, 'display' => 'Once Weekly'];
                return $s;
            });
        }

        // Analysis: Monday 07:00 UTC (weekly Idébank suggestions — kept)
        if (!wp_next_scheduled(self::HOOK)) {
            wp_schedule_event(strtotime('next monday 07:00 UTC'), 'weekly', self::HOOK);
        }

        // CALL-ON, NOT PUSH (G 2026-07-19): the content audit is NO LONGER scheduled.
        // It runs only on demand via the admin button. Clear any stale event on (re)activation.
        if (wp_next_scheduled(self::AUDIT_HOOK)) {
            wp_clear_scheduled_hook(self::AUDIT_HOOK);
        }

        $defaults = [
            'li_site_description' => 'Danmarks ældste uafhængige digitale rejsemedie — luksus og oplevelsesrejser',
            'li_num_suggestions'  => 10,
            'li_admin_email'      => 'info@leisuretalk.net',
            'li_claude_model'     => 'claude-haiku-4-5-20251001',
            'li_writer_model'     => 'claude-sonnet-4-6',
        ];

        foreach ($defaults as $key => $value) {
            if (!get_option($key)) update_option($key, $value);
        }
    }

    public static function deactivate() {
        foreach ([self::HOOK, self::AUDIT_HOOK] as $hook) {
            $ts = wp_next_scheduled($hook);
            if ($ts) wp_unschedule_event($ts, $hook);
        }
    }

    /**
     * Weekly content analysis — runs Monday 07:00 UTC.
     */
    public function run_analysis() {
        $num_suggestions = intval(get_option('li_num_suggestions', 10));
        $admin_email     = get_option('li_admin_email', '');

        $data_class = new LI_Data();
        $dataset    = $data_class->get_analysis_dataset(20);

        if (empty($dataset)) {
            $this->log_run(0, 0, 'No GSC data found.');
            return ['success' => false, 'message' => 'Ingen GSC-data fundet. Kontrollér at RankMath er konfigureret.'];
        }

        $claude      = new LI_Claude();
        $suggestions = $claude->get_suggestions($dataset, $num_suggestions);

        if (is_wp_error($suggestions)) {
            $msg = $suggestions->get_error_message();
            $this->log_run(count($dataset), 0, 'Claude error: ' . $msg);
            return ['success' => false, 'message' => 'Claude API fejl: ' . $msg];
        }

        // 2026-05-22 (G): NO draft creation — forslag leveres kun via mail.
        // Drafts klutrede workflow; mail er nu eneste output for ugentlig analyse.
        $count = is_array($suggestions) ? count($suggestions) : 0;

        // Persist suggestions to the Idébank — a clean store, NOT drafts (keeps the
        // mail-only decision intact while making the ideas browsable/manageable).
        if ($count > 0 && class_exists('LI_Ideabank')) {
            LI_Ideabank::save_ideas($suggestions, current_time('mysql'));
        }

        // Plugin-native alert: raise a badge ONLY for genuinely top-relevance finds (score >= threshold).
        // Replaces the old push-mail — the insight now lives in the plugin, not the inbox.
        if ($count > 0 && class_exists('LI_Alerts')) {
            LI_Alerts::scan_ideabank();
        }

        $this->log_run(count($dataset), $count, 'OK (mail only)');

        if (!empty($admin_email) && $count > 0) {
            $this->send_analysis_notification($admin_email, $suggestions, $dataset);
        }

        return [
            'success'    => true,
            'analysed'   => count($dataset),
            'created'    => 0,
            'suggested'  => $count,
            'message'    => "{$count} indholdssforslag sendt pr. mail (ingen kladder oprettet).",
            'ga4_active' => !empty($dataset[0]['pageviews']),
        ];
    }

    /**
     * Weekly content audit — runs Wednesday 07:00 UTC.
     */
    public function run_audit() {
        $admin_email = get_option('li_admin_email', '');

        // Fetch GA4 metrics (non-blocking)
        $ga4_metrics = [];
        $ga4 = new LI_GA4();
        if ($ga4->is_configured()) {
            $result = $ga4->get_page_metrics(30);
            if (!is_wp_error($result)) $ga4_metrics = $result;
        }

        $audit  = new LI_Audit();
        $result = $audit->run($ga4_metrics);

        if (is_wp_error($result)) {
            return ['success' => false, 'message' => $result->get_error_message()];
        }

        if (!empty($admin_email)) {
            $this->send_audit_notification($admin_email, $result);
        }

        return array_merge(['success' => true], $result);
    }

    private function log_run($analysed, $created, $status) {
        $log = get_option('li_run_log', []);
        if (!is_array($log)) $log = [];
        array_unshift($log, [
            'date'     => current_time('mysql'),
            'analysed' => $analysed,
            'created'  => $created,
            'status'   => $status,
        ]);
        update_option('li_run_log', array_slice($log, 0, 20));
    }

    private function send_analysis_notification($email, $suggestions, $dataset) {
        $n       = is_array($suggestions) ? count($suggestions) : 0;
        $ga4_txt = !empty($dataset[0]['pageviews']) ? ' (inkl. GA4-data)' : '';
        $subject = "LeisureIntel: {$n} indholdssforslag til TravelTalk.dk{$ga4_txt}";

        $body  = "LeisureIntel har afsluttet en ugentlig analyse og foreslår {$n} nye artikler.\n";
        $body .= "Forslagene leveres KUN her i mailen — der oprettes ingen kladder.\n\n";
        $body .= str_repeat('=', 70) . "\n\n";

        foreach ($suggestions as $i => $s) {
            $title      = $s['title']           ?? '(uden titel)';
            $angle      = $s['angle']           ?? '';
            $keyword    = $s['target_keyword']  ?? '';
            $intent     = $s['intent']          ?? '';
            $inspired   = $s['inspired_by']     ?? '';
            $confidence = isset($s['confidence']) ? intval($s['confidence']) : 0;
            $timing_raw = $s['timing']          ?? 'evergreen';
            $structure  = isset($s['structure']) && is_array($s['structure']) ? $s['structure'] : [];

            $timing_lbl = match($timing_raw) {
                'nu'           => '[NU]',
                'næste_sæson'  => '[NÆSTE SÆSON]',
                default        => '[EVERGREEN]',
            };

            $body .= ($i + 1) . ". {$timing_lbl} {$title}\n";
            $body .= "   Score: {$confidence}/10";
            if ($keyword) $body .= "  ·  Keyword: {$keyword}";
            if ($intent)  $body .= "  ·  Intent: {$intent}";
            $body .= "\n";

            if ($angle) {
                $body .= "\n   Vinkel: {$angle}\n";
            }

            if (!empty($structure)) {
                $body .= "\n   Foreslået struktur:\n";
                foreach ($structure as $h) {
                    $body .= "    · {$h}\n";
                }
            }

            if ($inspired) {
                $body .= "\n   Inspireret af: {$inspired}\n";
            }

            $body .= "\n" . str_repeat('-', 70) . "\n\n";
        }

        $body .= "Ingen action kræves. Brug forslagene som du finder relevant.\n";
        $body .= "-- LeisureIntel v" . LI_VERSION . " (mail-only mode)\n";

        wp_mail($email, $subject, $body);
    }

    private function send_audit_notification($email, $result) {
        $s       = $result['summary'];
        $n       = $result['posts_audited'];
        $subject = "LeisureIntel: Indholdsrevision — {$n} indlæg analyseret";

        $edit_link = $result['report_id'] ? get_edit_post_link($result['report_id'], 'raw') : '';

        $body  = "LeisureIntel har gennemført en fuld indholdsrevision.\n\n";
        $body .= "OVERSIGT:\n---\n";
        $body .= "Behold:      " . ($s['behold'] ?? 0) . "\n";
        $body .= "Forbedring:  " . ($s['forbedring'] ?? 0) . "\n";
        $body .= "Viderestil:  " . ($s['viderestil'] ?? 0) . "\n";
        $body .= "Slet:        " . ($s['slet'] ?? 0) . "\n";

        if ($edit_link) $body .= "\nFull rapport: {$edit_link}\n";

        $body .= "\n-- LeisureIntel v" . LI_VERSION . "\n";

        wp_mail($email, $subject, $body);
    }
}
