<?php
if (!defined('ABSPATH')) exit;

class LI_Partner_CPT {

    const LOCALE_COOKIE   = 'li_locale';
    const LOCALE_FALLBACK = 'dk';

    public function __construct() {
        add_action('init',              [$this, 'register_post_type']);
        add_action('init',              [$this, 'register_taxonomies']);
        add_action('add_meta_boxes',    [$this, 'add_meta_boxes']);
        add_action('save_post_partner', [$this, 'save_meta']);
        add_action('wp_enqueue_scripts',[$this, 'enqueue_frontend_assets']);
        add_action('widgets_init',      [$this, 'register_widget']);
        add_shortcode('li_partners',    [$this, 'shortcode']);
        add_shortcode('li_locale_picker',[$this, 'locale_picker_shortcode']);
    }

    public function register_post_type() {
        register_post_type('partner', [
            'labels' => [
                'name'          => 'Partnere',
                'singular_name' => 'Partner',
                'add_new_item'  => 'Tilføj partner',
                'edit_item'     => 'Rediger partner',
                'search_items'  => 'Søg partnere',
                'not_found'     => 'Ingen partnere fundet',
            ],
            'public'       => true,
            'has_archive'  => true,
            'show_in_rest' => true,
            'supports'     => ['title', 'editor', 'thumbnail', 'excerpt'],
            'menu_icon'    => 'dashicons-groups',
            'rewrite'      => ['slug' => 'partner'],
            'menu_position'=> 6,
        ]);
    }

    public function register_taxonomies() {
        register_taxonomy('partner_type', 'partner', [
            'labels' => [
                'name'          => 'Partnertype',
                'singular_name' => 'Partnertype',
                'all_items'     => 'Alle typer',
                'edit_item'     => 'Rediger type',
                'add_new_item'  => 'Tilføj type',
            ],
            'hierarchical'      => true,
            'show_in_rest'      => true,
            'show_admin_column' => true,
            'rewrite'           => ['slug' => 'partner-type'],
        ]);

        register_taxonomy('partner_locale', 'partner', [
            'labels' => [
                'name'          => 'Marked',
                'singular_name' => 'Marked',
                'all_items'     => 'Alle markeder',
                'edit_item'     => 'Rediger marked',
                'add_new_item'  => 'Tilføj marked',
            ],
            'hierarchical'      => true,
            'show_in_rest'      => true,
            'show_admin_column' => true,
            'rewrite'           => ['slug' => 'partner-marked'],
        ]);
    }

    public function add_meta_boxes() {
        add_meta_box('li_partner_meta', 'Partnerdetaljer', [$this, 'render_meta_box'], 'partner', 'normal', 'high');
    }

    public function render_meta_box($post) {
        wp_nonce_field('li_partner_meta', 'li_partner_nonce');
        $domain      = get_post_meta($post->ID, 'partner_domain', true);
        $booking_url = get_post_meta($post->ID, 'partner_booking_url', true);
        $note        = get_post_meta($post->ID, 'partner_note', true);
        ?>
        <table class="form-table" style="margin:0">
            <tr>
                <th style="width:160px"><label for="partner_domain">Website domain</label></th>
                <td><input type="text" id="partner_domain" name="partner_domain"
                    value="<?php echo esc_attr($domain); ?>" class="regular-text"
                    placeholder="example.dk" /></td>
            </tr>
            <tr>
                <th><label for="partner_booking_url">Booking URL</label></th>
                <td><input type="url" id="partner_booking_url" name="partner_booking_url"
                    value="<?php echo esc_attr($booking_url); ?>" class="regular-text"
                    placeholder="https://..." />
                <p class="description">Udfyld kun hvis forskellig fra domain</p></td>
            </tr>
            <tr>
                <th><label for="partner_note">Positionering</label></th>
                <td><input type="text" id="partner_note" name="partner_note"
                    value="<?php echo esc_attr($note); ?>" class="large-text"
                    placeholder="Kort beskrivelse til Claude-prompten og frontend" /></td>
            </tr>
        </table>
        <?php
    }

    public function save_meta($post_id) {
        if (!isset($_POST['li_partner_nonce']) || !wp_verify_nonce($_POST['li_partner_nonce'], 'li_partner_meta')) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;

        foreach (['partner_domain', 'partner_booking_url', 'partner_note'] as $field) {
            if (isset($_POST[$field])) {
                update_post_meta($post_id, $field, sanitize_text_field($_POST[$field]));
            }
        }
    }

    /**
     * Query published partners for a locale. Used by LeisureIntel Claude prompts.
     */

    // -------------------------------------------------------------------------
    // Locale detection
    // -------------------------------------------------------------------------

    public function get_current_locale() {
        if (!empty($_COOKIE[self::LOCALE_COOKIE])) {
            $v = sanitize_text_field($_COOKIE[self::LOCALE_COOKIE]);
            if (in_array($v, ['dk', 'sv', 'no', 'fi'], true)) return $v;
        }
        return get_option('li_prompt_locale', self::LOCALE_FALLBACK);
    }

    private function locale_meta() {
        return [
            'dk' => ['flag' => '🇩🇰', 'label' => 'Danmark', 'lang' => 'da'],
            'sv' => ['flag' => '🇸🇪', 'label' => 'Sverige', 'lang' => 'sv'],
            'no' => ['flag' => '🇳🇴', 'label' => 'Norge',   'lang' => 'no'],
            'fi' => ['flag' => '🇫🇮', 'label' => 'Finland', 'lang' => 'fi'],
        ];
    }

    // -------------------------------------------------------------------------
    // Frontend assets
    // -------------------------------------------------------------------------

    public function enqueue_frontend_assets() {
        wp_enqueue_style(
            'li-partner-frontend',
            LI_PLUGIN_URL . 'admin/css/partner-frontend.css',
            [],
            LI_VERSION
        );
        wp_enqueue_script(
            'li-locale-picker',
            LI_PLUGIN_URL . 'admin/js/locale-picker.js',
            [],
            LI_VERSION,
            true
        );
        wp_localize_script('li-locale-picker', 'liLocale', [
            'cookie'  => self::LOCALE_COOKIE,
            'current' => $this->get_current_locale(),
        ]);
    }

    // -------------------------------------------------------------------------
    // Locale picker shortcode: [li_locale_picker labels="yes" style="flags"]
    // -------------------------------------------------------------------------

    public function locale_picker_shortcode($atts) {
        $atts    = shortcode_atts(['labels' => 'yes', 'style' => 'flags'], $atts);
        $current = $this->get_current_locale();
        $metas   = $this->locale_meta();

        if ($atts['style'] === 'dropdown') {
            $html  = '<div class="li-locale-picker li-locale-picker--dropdown">';
            $html .= '<select class="li-locale-select" id="li-locale-select">';
            foreach ($metas as $slug => $m) {
                $sel   = $slug === $current ? ' selected' : '';
                $html .= '<option value="' . esc_attr($slug) . '"' . $sel . '>' . $m['flag'] . ' ' . esc_html($m['label']) . '</option>';
            }
            $html .= '</select></div>';
            return $html;
        }

        $cls  = $atts['style'] === 'tabs' ? 'li-locale-picker li-locale-picker--tabs' : 'li-locale-picker li-locale-picker--flags';
        $html = '<nav class="' . $cls . '" aria-label="Vælg land">';
        foreach ($metas as $slug => $m) {
            $active = $slug === $current ? ' li-locale-active' : '';
            $html  .= '<a href="#" class="li-locale-link' . $active . '" data-locale="' . esc_attr($slug) . '" lang="' . esc_attr($m['lang']) . '">';
            $html  .= '<span class="li-locale-flag" aria-hidden="true">' . $m['flag'] . '</span>';
            if ($atts['labels'] === 'yes') {
                $html .= '<span class="li-locale-label">' . esc_html($m['label']) . '</span>';
            }
            $html .= '</a>';
        }
        $html .= '</nav>';
        return $html;
    }

    // -------------------------------------------------------------------------
    // WordPress Widget
    // -------------------------------------------------------------------------

    public function register_widget() {
        register_widget('LI_Locale_Picker_Widget');
    }

    // -------------------------------------------------------------------------

    public function get_partners_for_locale($locale) {
        $posts = get_posts([
            'post_type'   => 'partner',
            'post_status' => 'publish',
            'numberposts' => -1,
            'orderby'     => 'title',
            'order'       => 'ASC',
            'tax_query'   => [[
                'taxonomy' => 'partner_locale',
                'field'    => 'slug',
                'terms'    => $locale,
            ]],
        ]);

        if (empty($posts)) return [];

        $result = [];
        foreach ($posts as $post) {
            $type_terms = wp_get_post_terms($post->ID, 'partner_type', ['fields' => 'slugs']);
            $result[] = [
                'name'   => $post->post_title,
                'domain' => get_post_meta($post->ID, 'partner_domain', true),
                'type'   => !empty($type_terms) ? $type_terms[0] : 'travel_agency',
                'note'   => get_post_meta($post->ID, 'partner_note', true) ?: $post->post_excerpt,
                'url'    => get_permalink($post->ID),
            ];
        }
        return $result;
    }

    /**
     * Shortcode: [li_partners locale="dk" type="travel_agency"]
     * locale and type accept comma-separated values.
     */
    public function shortcode($atts) {
        $atts = shortcode_atts(['locale' => '', 'type' => '', 'columns' => '3'], $atts);

        // Auto-detect from cookie when locale not explicitly set
        if (!$atts['locale']) {
            $atts['locale'] = $this->get_current_locale();
        }

        $tax_query = ['relation' => 'AND'];
        if ($atts['locale']) {
            $tax_query[] = [
                'taxonomy' => 'partner_locale',
                'field'    => 'slug',
                'terms'    => array_map('trim', explode(',', $atts['locale'])),
                'operator' => 'IN',
            ];
        }
        if ($atts['type']) {
            $tax_query[] = [
                'taxonomy' => 'partner_type',
                'field'    => 'slug',
                'terms'    => array_map('trim', explode(',', $atts['type'])),
                'operator' => 'IN',
            ];
        }

        $posts = get_posts([
            'post_type'   => 'partner',
            'post_status' => 'publish',
            'numberposts' => -1,
            'orderby'     => 'title',
            'order'       => 'ASC',
            'tax_query'   => count($tax_query) > 1 ? $tax_query : null,
        ]);

        if (empty($posts)) return '';

        $cols = max(1, min(4, intval($atts['columns'])));
        $html = '<div class="li-partner-grid li-partner-grid--' . $cols . 'col">';
        foreach ($posts as $post) {
            $domain      = get_post_meta($post->ID, 'partner_domain', true);
            $booking_url = get_post_meta($post->ID, 'partner_booking_url', true) ?: ($domain ? 'https://' . $domain : '');
            $note        = get_post_meta($post->ID, 'partner_note', true) ?: $post->post_excerpt;
            $page_url    = get_permalink($post->ID);
            $type_terms  = wp_get_post_terms($post->ID, 'partner_type', ['fields' => 'names']);
            $type        = !empty($type_terms) ? $type_terms[0] : '';
            $thumb       = get_the_post_thumbnail($post->ID, 'thumbnail');

            $html .= '<div class="li-partner-card">';
            if ($thumb) $html .= '<div class="li-partner-thumb">' . $thumb . '</div>';
            if ($type)  $html .= '<div class="li-partner-type-badge">' . esc_html($type) . '</div>';
            $html .= '<h3 class="li-partner-name"><a href="' . esc_url($page_url) . '">' . esc_html($post->post_title) . '</a></h3>';
            if ($note)        $html .= '<p class="li-partner-note">' . esc_html($note) . '</p>';
            if ($booking_url) $html .= '<a href="' . esc_url($booking_url) . '" class="li-partner-link" target="_blank" rel="noopener">Besøg →</a>';
            $html .= '</div>';
        }
        $html .= '</div>';
        return $html;
    }

    /**
     * Seed all default partners. Skips existing (matched by domain).
     * Returns ['created' => int, 'skipped' => int].
     */
    public function seed_default_partners() {
        $this->ensure_terms();

        $created = 0;
        $skipped = 0;

        foreach ($this->get_seed_data() as $p) {
            $existing = get_posts([
                'post_type'   => 'partner',
                'post_status' => 'any',
                'numberposts' => 1,
                'meta_key'    => 'partner_domain',
                'meta_value'  => $p['domain'],
            ]);

            if (!empty($existing)) {
                // Merge locales onto existing post
                $pid = $existing[0]->ID;
                foreach ($p['locales'] as $locale) {
                    $term = get_term_by('slug', $locale, 'partner_locale');
                    if ($term) wp_set_post_terms($pid, [$term->term_id], 'partner_locale', true);
                }
                $skipped++;
                continue;
            }

            $pid = wp_insert_post([
                'post_type'    => 'partner',
                'post_status'  => 'publish',
                'post_title'   => $p['name'],
                'post_excerpt' => $p['note'],
            ]);

            if (is_wp_error($pid)) continue;

            update_post_meta($pid, 'partner_domain', $p['domain']);
            update_post_meta($pid, 'partner_note',   $p['note']);

            $type_term = get_term_by('slug', $p['type'], 'partner_type');
            if ($type_term) wp_set_post_terms($pid, [$type_term->term_id], 'partner_type');

            $locale_ids = [];
            foreach ($p['locales'] as $locale) {
                $term = get_term_by('slug', $locale, 'partner_locale');
                if ($term) $locale_ids[] = $term->term_id;
            }
            if ($locale_ids) wp_set_post_terms($pid, $locale_ids, 'partner_locale');

            $created++;
        }

        return ['created' => $created, 'skipped' => $skipped];
    }

    private function ensure_terms() {
        foreach ([
            'travel_agency' => 'Rejsebureau',
            'train'         => 'Togrejser',
            'cruise'        => 'Krydstogt',
            'hotel_group'   => 'Hotelkæde',
            'dmo'           => 'DMO',
            'tourism_board' => 'Turistbureau',
            'airline'       => 'Flyselskab',
            'other'         => 'Andet',
        ] as $slug => $name) {
            if (!get_term_by('slug', $slug, 'partner_type')) {
                wp_insert_term($name, 'partner_type', ['slug' => $slug]);
            }
        }

        foreach ([
            'dk' => 'Danmark',
            'sv' => 'Sverige',
            'no' => 'Norge',
            'fi' => 'Finland',
        ] as $slug => $name) {
            if (!get_term_by('slug', $slug, 'partner_locale')) {
                wp_insert_term($name, 'partner_locale', ['slug' => $slug]);
            }
        }
    }

    private function get_seed_data() {
        return [
            // ── DENMARK ──────────────────────────────────────────────────────
            ['name'=>'Lords Travel',        'domain'=>'lordstravel.dk',       'type'=>'travel_agency','locales'=>['dk'],'note'=>'Luksus skræddersyede rejser siden 1986'],
            ['name'=>'Peacock Travel',       'domain'=>'peacocktravel.dk',     'type'=>'travel_agency','locales'=>['dk'],'note'=>'Eksklusiv luksus, safari, F1, bryllup'],
            ['name'=>'Blixen Tours',         'domain'=>'blixentours.dk',       'type'=>'travel_agency','locales'=>['dk'],'note'=>'Ren luksus safari + Indisk Ocean specialist'],
            ['name'=>'Abundance Travel',     'domain'=>'abundance-travel.dk',  'type'=>'travel_agency','locales'=>['dk'],'note'=>'30+ år, VIP adgang, eksklusivt'],
            ['name'=>'The Collection',       'domain'=>'the-collection.dk',    'type'=>'travel_agency','locales'=>['dk'],'note'=>'Boutique, partner med Four Seasons, Aman, One&Only, Belmond'],
            ['name'=>'Voya Travel',          'domain'=>'voya.dk',              'type'=>'travel_agency','locales'=>['dk'],'note'=>'Luksus du ikke kan finde andre steder, yachts og villas'],
            ['name'=>'BECH Travel',          'domain'=>'bechtravel.dk',        'type'=>'travel_agency','locales'=>['dk'],'note'=>'Indisk Ocean specialist, Maldiverne, Mauritius'],
            ['name'=>'80days',               'domain'=>'80days.dk',            'type'=>'travel_agency','locales'=>['dk'],'note'=>'Eksklusiv skræddersyet, par, familier, multi-generational'],
            ['name'=>'Livingstone Safari',   'domain'=>'livingstone.dk',       'type'=>'travel_agency','locales'=>['dk'],'note'=>'Dansk-ejet, næsten 30 år bespoke Afrika safari'],
            ['name'=>'NYATI Safari',         'domain'=>'nyati-safari.dk',      'type'=>'travel_agency','locales'=>['dk'],'note'=>'Ejer egne eksklusive lodges i Sydafrika'],
            ['name'=>'Panorama Travel',      'domain'=>'panoramatravel.dk',    'type'=>'travel_agency','locales'=>['dk'],'note'=>'Eksotiske destinationer: Bhutan, Borneo, Namibia'],
            ['name'=>'Vilholdt Rejser',      'domain'=>'vilholdt.dk',          'type'=>'travel_agency','locales'=>['dk'],'note'=>'Eneste dansk bureau med lokal operatørstatus på Island'],
            ['name'=>'Vores Afrika',         'domain'=>'voresafrika.dk',       'type'=>'travel_agency','locales'=>['dk'],'note'=>'100% dansk-ejet Afrika specialist, fuldt personaliseret'],
            ['name'=>'GG Tours',             'domain'=>'ggtours.dk',           'type'=>'travel_agency','locales'=>['dk'],'note'=>'Luksus spa + resort, slotophold Skandinavien, gastronomi'],
            ['name'=>'Drømmerejser',         'domain'=>'drommerejser.dk',      'type'=>'travel_agency','locales'=>['dk'],'note'=>'Skræddersyede kvalitetsrejser, 100+ samlet erfaring'],
            ['name'=>'Nyhavn Rejser',        'domain'=>'nyhavnrejser.dk',      'type'=>'travel_agency','locales'=>['dk'],'note'=>'Dansk klassiker, premium rejser'],
            ['name'=>'Benns Rejser',         'domain'=>'benns.dk',             'type'=>'travel_agency','locales'=>['dk'],'note'=>'Premium, stærk på fjernrejser'],
            ['name'=>'Topas Rejser',         'domain'=>'topas.dk',             'type'=>'travel_agency','locales'=>['dk'],'note'=>'Kulturrejser og natur, oplevelsesfokus'],
            ['name'=>'Albatros Travel',      'domain'=>'albatros-travel.dk',   'type'=>'travel_agency','locales'=>['dk'],'note'=>'Ekspeditioner og naturrejser, Arktis, Antarktis'],
            ['name'=>'Politiken Plus',       'domain'=>'politikenplus.dk',     'type'=>'travel_agency','locales'=>['dk'],'note'=>'Kulturrejser, medieknyttet kvalitetspublikum'],
            ['name'=>'Risskov Rejser',       'domain'=>'risskovrejser.dk',     'type'=>'travel_agency','locales'=>['dk'],'note'=>'Jysk premium bureau'],
            ['name'=>'Gislinge Rejser',      'domain'=>'gislingerejser.dk',    'type'=>'travel_agency','locales'=>['dk'],'note'=>'Boutique, bespoke, skandinavisk fokus'],

            // ── SWEDEN ───────────────────────────────────────────────────────
            ['name'=>'Luxury Travel Sweden',             'domain'=>'luxurytravelsweden.com',          'type'=>'travel_agency','locales'=>['sv'],'note'=>'Stockholm DMC, bespoke skräddarsydda resor, Lapland + arkipelag'],
            ['name'=>'Invita Sweden',                    'domain'=>'invitasweden.com',                'type'=>'travel_agency','locales'=>['sv'],'note'=>'Stockholm boutique DMC, arkipelag, incentive och high-end leisure'],
            ['name'=>'Ecolyx',                           'domain'=>'ecolyx.com',                      'type'=>'travel_agency','locales'=>['sv','no'],'note'=>'Eco-lyx Skandinavien, handplockade boutique-lodges, privat guide-access'],
            ['name'=>'Inlandsbanan AB',                  'domain'=>'res.inlandsbanan.se',             'type'=>'train',        'locales'=>['sv'],'note'=>'Direktoperatör 1 288 km järnväg Kristinehamn–Gällivare, egna hotellpaket'],
            ['name'=>'Great Rail Journeys',              'domain'=>'greatrail.com',                   'type'=>'train',        'locales'=>['sv','no'],'note'=>'Escorterade tågresor, Inlandsbanan + Bergen-rutter, premium smågrupp'],
            ['name'=>'Tailor Made Rail',                 'domain'=>'tailormaderail.com',              'type'=>'train',        'locales'=>['sv'],'note'=>'Bespoke tåg-itinerarium, Sverige + bredare Skandinavien'],
            ['name'=>'Sailing Sweden',                   'domain'=>'sailingsweden.com',               'type'=>'cruise',       'locales'=>['sv'],'note'=>'Privata besättningscharters i Stockholms skärgård, lyxbåtar'],
            ['name'=>'XperienceSweden',                  'domain'=>'xperiencesweden.com',             'type'=>'cruise',       'locales'=>['sv'],'note'=>'Premium yachtcharter med gourmetmiddag, Stockholms skärgård'],

            // ── NORWAY ───────────────────────────────────────────────────────
            ['name'=>'50 Degrees North',     'domain'=>'fiftydegreesnorth.com',  'type'=>'travel_agency','locales'=>['no','sv','fi'],'note'=>'B Corp, Virtuoso-listet, Lillehammer, bespoke grupper max 18 pers'],
            ['name'=>'Expa Reiser',          'domain'=>'expareiser.no',          'type'=>'travel_agency','locales'=>['no'],'note'=>'Norsk boutique, skreddersydde reiser, aktiv + opplevelsesfokus'],
            ['name'=>'Get Norway Travel',    'domain'=>'getnorwaytravel.com',    'type'=>'travel_agency','locales'=>['no'],'note'=>'Oslo-basert boutique DMC, bespoke for internasjonale gjester'],
            ['name'=>'Nordiva Tours',        'domain'=>'nordivatours.com',       'type'=>'travel_agency','locales'=>['no'],'note'=>'Boutique Nord-Europa, bespoke itinerary-design for kresne reisende'],
            ['name'=>'Norway Adventures',    'domain'=>'norway-adventures.com',  'type'=>'travel_agency','locales'=>['no'],'note'=>'Private luksusfjordturer, wellness + fjordopplevelse, boutique-lodges'],
            ['name'=>'Fjord Tours',          'domain'=>'fjordtours.com',         'type'=>'travel_agency','locales'=>['no'],'note'=>'Bergenbanen + Flåmsbana + Nærøyfjord, premium FIT-pakker'],
            ['name'=>"Norway's Best",        'domain'=>'norwaysbest.com',        'type'=>'travel_agency','locales'=>['no'],'note'=>'Kurerte opplevelser, Flåmsbana-pakker, håndplukkede overnattingssteder'],
            ['name'=>'Hurtigruten',          'domain'=>'hurtigruten.com',        'type'=>'cruise',       'locales'=>['no'],'note'=>'Kystruten Bergen–Kirkenes 34 havner, Signature premium all-inclusive tier'],
            ['name'=>'HX Hurtigruten Expeditions','domain'=>'travelhx.com',     'type'=>'cruise',       'locales'=>['no','fi'],'note'=>'Ekspedisjonsprodukt, Svalbard + Arktis + Antarktis, eventyrluksus'],
            ['name'=>'Havila Kystruten',     'domain'=>'havilavoyages.com',      'type'=>'cruise',       'locales'=>['no'],'note'=>'Ny aktør 2021, identisk rute som Hurtigruten, nyere skip, batteri-hybrid'],
            ['name'=>'Railbookers',          'domain'=>'railbookers.com',        'type'=>'train',        'locales'=>['no','sv'],'note'=>'Bergen + Flåm + Oslo pakker, Norway in a Nutshell, Sverige Inlandsbanan'],

            // ── FINLAND ──────────────────────────────────────────────────────
            ['name'=>'Aventura',             'domain'=>'aventura.fi',            'type'=>'travel_agency','locales'=>['fi'],'note'=>'Helsinki boutique, täysin yksilölliset luksusmatkaohjelmat, safarit + yksityissaaret'],
            ['name'=>'Private Skies',        'domain'=>'privateskies.fi',        'type'=>'travel_agency','locales'=>['fi'],'note'=>'Huipputason Helsinki-toimisto, yksityislentokoneet + helikopterit'],
            ['name'=>'Project Matka',        'domain'=>'projectmatka.com',       'type'=>'travel_agency','locales'=>['fi'],'note'=>'Suomalainen luksusmatkasuunnittelija, räätälöidyt matkat vaativille matkailijoille'],
            ['name'=>'JeeTravels',           'domain'=>'jeetravels.com',         'type'=>'travel_agency','locales'=>['fi'],'note'=>'Yksilölliset luksuspaketit, parit + perheet, ESQR-sertifioitu laatu 2025'],
            ['name'=>'Lapland Private',      'domain'=>'laplandprivate.com',     'type'=>'travel_agency','locales'=>['fi'],'note'=>'Rovaniemi DMC, arkkitehtisuunnitellut huviloita ja lasivilloja, Biosphere-sertifioitu'],
            ['name'=>'Lapland Luxury DMC',   'domain'=>'laplandluxury.com',      'type'=>'travel_agency','locales'=>['fi'],'note'=>'Perheyritys 25+ vuotta, yksityishuvilat + kaikki sisältyvä Arktis, yksityiskokit'],
            ['name'=>'Arctra DMC',           'domain'=>'arctradmc.fi',           'type'=>'travel_agency','locales'=>['fi'],'note'=>'Rovaniemi Nordic Luxury DMC, yksityiset loma-asunnot syrjäisillä alueilla'],
            ['name'=>'Aurora Safaris',       'domain'=>'aurorasafaris.com',      'type'=>'travel_agency','locales'=>['fi'],'note'=>'Ainutlaatuiset Arktis-majoitukset: kelluva safariyleiri, lasikattilakopit, outpost-lodge'],
            ['name'=>'Arctic GM',            'domain'=>'arcticgm.com',           'type'=>'travel_agency','locales'=>['fi'],'note'=>'Rovaniemi + Levi + Tromsø + Kiruna, Original Aurora Hunters, premium 4x4-kalusto'],
            ['name'=>'DMC Lapland',          'domain'=>'dmclapland.fi',          'type'=>'travel_agency','locales'=>['fi'],'note'=>'Omistettu Lappi-DMC, FIT + incentive-matkat, Rovaniemi-asiantuntija'],

            // ── CROSS-NORDIC ─────────────────────────────────────────────────
            ['name'=>'Best Served Scandinavia',          'domain'=>'best-served.co.uk',               'type'=>'travel_agency','locales'=>['dk','sv','no','fi'],'note'=>'Virtuoso-affilieret, skræddersydde Norden-rejser, stærk på Lapland + nordlys'],
            ['name'=>'Authentic Scandinavia',            'domain'=>'authentic-scandinavia.com',        'type'=>'travel_agency','locales'=>['dk','sv','no'],'note'=>'Premium FIT Skandinavien, naturresor, Oslo–Bergen + fjord'],
            ['name'=>'The Luxury Arctic Travel Company', 'domain'=>'theluxuryarctictravelcompany.com', 'type'=>'travel_agency','locales'=>['sv','no','fi'],'note'=>'Premium Arktis: Abisko, Icehotel, Lapland på tværs af Norden'],
            ['name'=>'Off The Map Travel',               'domain'=>'offthemap.travel',                 'type'=>'travel_agency','locales'=>['sv','no','fi'],'note'=>'15+ år Nordic expertise, UK boutique med skandinavisk fokus'],
            ['name'=>'Ker & Downey',                     'domain'=>'kerdowney.com',                    'type'=>'travel_agency','locales'=>['sv','no','fi'],'note'=>'US luksusoperatør, kureret Skandinavien-program'],
            ['name'=>'Nordic Visitor',                   'domain'=>'nordicvisitor.com',                'type'=>'travel_agency','locales'=>['sv','no','fi'],'note'=>'Reykjavik HQ, personlig 1-til-1 service, FIT selvkørsel + guidede rejser'],
        ];
    }
}

// =============================================================================
// Widget: Locale Picker
// =============================================================================

class LI_Locale_Picker_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'li_locale_picker_widget',
            'LeisureIntel — Landvælger',
            ['description' => 'Flag-picker der sætter besøgssprog (DK/SE/NO/FI)']
        );
    }

    public function widget($args, $instance) {
        $style  = !empty($instance['style'])  ? $instance['style']  : 'flags';
        $labels = !empty($instance['labels']) ? $instance['labels'] : 'yes';

        echo $args['before_widget'];
        if (!empty($instance['title'])) {
            echo $args['before_title'] . esc_html($instance['title']) . $args['after_title'];
        }
        echo do_shortcode('[li_locale_picker style="' . esc_attr($style) . '" labels="' . esc_attr($labels) . '"]');
        echo $args['after_widget'];
    }

    public function form($instance) {
        $title  = !empty($instance['title'])  ? $instance['title']  : '';
        $style  = !empty($instance['style'])  ? $instance['style']  : 'flags';
        $labels = !empty($instance['labels']) ? $instance['labels'] : 'yes';
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">Titel:</label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>"
                name="<?php echo $this->get_field_name('title'); ?>"
                type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('style'); ?>">Stil:</label>
            <select class="widefat" id="<?php echo $this->get_field_id('style'); ?>"
                name="<?php echo $this->get_field_name('style'); ?>">
                <option value="flags"    <?php selected($style, 'flags'); ?>>Flag-links</option>
                <option value="tabs"     <?php selected($style, 'tabs'); ?>>Tabs</option>
                <option value="dropdown" <?php selected($style, 'dropdown'); ?>>Dropdown</option>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('labels'); ?>">Vis landnavne:</label>
            <select class="widefat" id="<?php echo $this->get_field_id('labels'); ?>"
                name="<?php echo $this->get_field_name('labels'); ?>">
                <option value="yes" <?php selected($labels, 'yes'); ?>>Ja</option>
                <option value="no"  <?php selected($labels, 'no'); ?>>Nej (kun flag)</option>
            </select>
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        return [
            'title'  => sanitize_text_field($new_instance['title']),
            'style'  => in_array($new_instance['style'], ['flags','tabs','dropdown']) ? $new_instance['style'] : 'flags',
            'labels' => $new_instance['labels'] === 'no' ? 'no' : 'yes',
        ];
    }
}
