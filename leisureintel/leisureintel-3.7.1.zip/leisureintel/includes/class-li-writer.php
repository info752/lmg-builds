<?php
if (!defined('ABSPATH')) exit;

class LI_Writer {

    private $api_url = 'https://api.anthropic.com/v1/messages';

    /**
     * Write a full article from a brief post ID.
     * Reads meta from the existing draft, generates content, updates the post.
     * Returns WP_Error or ['post_id' => N, 'edit_link' => url].
     */
    public function write_from_brief($post_id) {
        $post = get_post($post_id);
        if (!$post) {
            return new WP_Error('li_writer_error', 'Brief post not found.');
        }

        $title    = $post->post_title;
        $keyword  = get_post_meta($post_id, '_li_target_keyword', true);
        $intent   = get_post_meta($post_id, '_li_intent', true);
        $inspired = get_post_meta($post_id, '_li_inspired_by', true);
        $angle    = $this->extract_angle_from_content($post->post_content);
        $h2s      = $this->extract_h2s_from_content($post->post_content);

        $api_key = get_option('li_claude_api_key', '');
        $model   = get_option('li_writer_model', 'claude-sonnet-4-6');

        if (empty($api_key)) {
            return new WP_Error('li_writer_error', 'Claude API key not configured.');
        }

        $prompt = $this->build_writing_prompt($title, $keyword, $angle, $h2s, $intent, $inspired);

        $body = json_encode([
            'model'      => $model,
            'max_tokens' => 6000,
            'messages'   => [
                ['role' => 'user', 'content' => $prompt],
            ],
        ]);

        $response = wp_remote_post($this->api_url, [
            'timeout' => 120,
            'headers' => [
                'Content-Type'      => 'application/json',
                'x-api-key'         => $api_key,
                'anthropic-version' => '2023-06-01',
            ],
            'body' => $body,
        ]);

        if (is_wp_error($response)) {
            return new WP_Error('li_writer_error', 'Claude API failed: ' . $response->get_error_message());
        }

        $code    = wp_remote_retrieve_response_code($response);
        $decoded = json_decode(wp_remote_retrieve_body($response), true);

        if ($code !== 200) {
            $msg = $decoded['error']['message'] ?? wp_remote_retrieve_body($response);
            return new WP_Error('li_writer_error', "Claude API HTTP {$code}: {$msg}");
        }

        $text = trim($decoded['content'][0]['text'] ?? '');
        if (empty($text)) {
            return new WP_Error('li_writer_error', 'Claude returned empty content.');
        }

        $gutenberg_content = $this->convert_to_gutenberg($text);

        $updated = wp_update_post([
            'ID'           => $post_id,
            'post_content' => $gutenberg_content,
            'post_status'  => 'draft',
        ], true);

        if (is_wp_error($updated)) {
            return $updated;
        }

        update_post_meta($post_id, '_li_written', 1);
        update_post_meta($post_id, '_li_written_date', current_time('mysql'));
        update_post_meta($post_id, '_li_writer_model', $model);

        return [
            'post_id'   => $post_id,
            'edit_link' => get_edit_post_link($post_id, 'raw'),
        ];
    }

    private function build_writing_prompt($title, $keyword, $angle, $h2s, $intent, $inspired) {
        $structure_text = '';
        if (!empty($h2s)) {
            $structure_text = "\nFORESLÅET STRUKTUR (brug som udgangspunkt, tilpas frit):\n";
            foreach ($h2s as $i => $h2) {
                $structure_text .= ($i + 1) . ". {$h2}\n";
            }
        }

        $inspired_text = $inspired ? "\nInspieret af dette eksisterende indhold: {$inspired}" : '';

        return <<<PROMPT
Du er senior rejseskribent for TravelTalk.dk — Danmarks ældste uafhængige digitale rejsemedie. Personlig, oplevelsesbaseret stemme. Luksus og oplevelsesrejser. Ingen charter, budget eller all-inclusive.

SKRIV FØLGENDE ARTIKEL:
Titel: {$title}
Primært søgeord: {$keyword}
Søgeintent: {$intent}
Vinkel: {$angle}{$structure_text}{$inspired_text}

INDHOLDSKRAV:
- Længde: 1.200–1.500 ord
- Mindst 4–6 H2-overskrifter (fordelt jævnt i teksten)
- Inkluder én "Undgå:"-advarsel (konkret, praktisk, ikke generisk)
- Afslut med en faktaboks: Faktaboks | [Destination] | [3–5 bullets med praktiske detaljer]
- Personlig stemme: skriv i vi/man, ikke "rejsende" eller "turister"
- Eksplicit luksus-tone: fokus på oplevelse, rum, mad, service, atmosfære
- Ingen mention af pris medmindre relevant for kontekst

COPYRIGHT:
Slut artiklen med: © 2026 TravelTalk.dk / Leisure Media Group Ltd. All rights reserved.

FORMAT:
Returner KUN ren tekst med Markdown-formatering (# for H1, ## for H2, **fed** for faktaboks headers). Ingen HTML. Ingen forklaringer. Ingen kommentarer. Start direkte med artiklen.
PROMPT;
    }

    /**
     * Convert Markdown text from Claude to Gutenberg blocks.
     */
    private function convert_to_gutenberg($text) {
        $lines  = explode("\n", $text);
        $blocks = [];
        $buffer = [];

        $flush_paragraph = function() use (&$buffer, &$blocks) {
            $para = implode(' ', array_filter(array_map('trim', $buffer)));
            if ($para !== '') {
                $blocks[] = "<!-- wp:paragraph -->\n<p>{$para}</p>\n<!-- /wp:paragraph -->";
            }
            $buffer = [];
        };

        foreach ($lines as $line) {
            $line = trim($line);

            if ($line === '') {
                if (!empty($buffer)) $flush_paragraph();
                continue;
            }

            // H1
            if (preg_match('/^#\s+(.+)$/', $line, $m)) {
                if (!empty($buffer)) $flush_paragraph();
                $text_node = esc_html($m[1]);
                $blocks[]  = "<!-- wp:heading {\"level\":1} -->\n<h1>{$text_node}</h1>\n<!-- /wp:heading -->";
                continue;
            }

            // H2
            if (preg_match('/^##\s+(.+)$/', $line, $m)) {
                if (!empty($buffer)) $flush_paragraph();
                $text_node = esc_html($m[1]);
                $blocks[]  = "<!-- wp:heading -->\n<h2>{$text_node}</h2>\n<!-- /wp:heading -->";
                continue;
            }

            // H3
            if (preg_match('/^###\s+(.+)$/', $line, $m)) {
                if (!empty($buffer)) $flush_paragraph();
                $text_node = esc_html($m[1]);
                $blocks[]  = "<!-- wp:heading {\"level\":3} -->\n<h3>{$text_node}</h3>\n<!-- /wp:heading -->";
                continue;
            }

            // Bullet list item — collect into list block
            if (preg_match('/^[-*]\s+(.+)$/', $line, $m)) {
                if (!empty($buffer)) $flush_paragraph();
                $item = '<li>' . $this->inline_format($m[1]) . '</li>';
                // Peek ahead / collect consecutive bullets handled by buffering into list
                // Simple: just wrap each as standalone list for now
                $blocks[] = "<!-- wp:list -->\n<ul>{$item}</ul>\n<!-- /wp:list -->";
                continue;
            }

            // Regular paragraph line — accumulate
            $buffer[] = $this->inline_format($line);
        }

        if (!empty($buffer)) $flush_paragraph();

        return implode("\n\n", $blocks);
    }

    private function inline_format($text) {
        // **bold**
        $text = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $text);
        // *italic*
        $text = preg_replace('/\*(.+?)\*/', '<em>$1</em>', $text);
        return $text;
    }

    private function extract_angle_from_content($content) {
        if (preg_match('/<strong>Vinkel:<\/strong>\s*(.+?)<\/p>/s', $content, $m)) {
            return trim(strip_tags($m[1]));
        }
        return '';
    }

    private function extract_h2s_from_content($content) {
        preg_match_all('/<h2[^>]*>([^<]+)<\/h2>/i', $content, $matches);
        $h2s = array_filter($matches[1], function($h) {
            return stripos($h, 'foreslået') === false && stripos($h, 'struktur') === false;
        });
        return array_values($h2s);
    }
}
