<?php
/**
 * Plugin Name:  LeisureSocial
 * Description:  Manual one-click sharing of posts to Facebook, Instagram, Pinterest, YouTube and X — with auto-generated captions per platform.
 * Version:      2.0.4
 * Author:       Leisure Media Group Ltd
 *
 * HOW IT WORKS
 * ─────────────
 * A "Share to Social" meta box appears on every published post.
 * Click a platform button → it opens that platform's native share dialog
 * (or copies the caption for Instagram/YouTube which can't be opened via URL).
 * Every share is logged as post meta so you can see what was shared and when.
 *
 * PLATFORMS
 * ─────────
 *  Facebook   – Opens Facebook share dialog with post URL (or API post to Page if token set)
 *  Instagram  – Copies image URL + caption to clipboard (Instagram has no web share URL)
 *  Pinterest  – Opens Pinterest Pin creator pre-filled with image + description
 *  YouTube    – Copies description for YouTube Community post / video description
 *  X          – Opens X (Twitter) compose with title + URL
 *
 * SETTINGS
 * ────────
 * WP Admin → LeisureSocial → Settings
 * Optional: add Facebook Page ID + Page Access Token for direct Graph API posting.
 *
 * HASHTAGS
 * ────────
 * Set per-post hashtags in the meta box, or use the default tag from Settings.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'LS2_VERSION', '2.0.4' );

// 2.0.4 (G, 25 Nov 2026): caption words follow the site's language – Danish on Danish sites, English elsewhere.
function ls2_is_danish() {
    return strpos( get_locale(), 'da' ) === 0;
}
function ls2_default_tags() {
    return ls2_is_danish() ? '#rejser #traveltalk' : '#travel #traveltalk';
}

// ── Admin menu ────────────────────────────────────────────────────

add_action( 'admin_menu', 'ls2_admin_menu' );
function ls2_admin_menu() {
    add_menu_page(
        'LeisureSocial',
        'LeisureSocial',
        'manage_options',
        'leisuresocial',
        'ls2_settings_page',
        'dashicons-share',
        31
    );
}

// ── Settings page ─────────────────────────────────────────────────

function ls2_settings_page() {
    if ( isset( $_POST['ls2_save'] ) && check_admin_referer( 'ls2_save' ) ) {
        update_option( 'ls2_default_hashtags',  sanitize_text_field( $_POST['ls2_default_hashtags'] ?? '' ) );
        update_option( 'ls2_fb_page_id',        sanitize_text_field( $_POST['ls2_fb_page_id'] ?? '' ) );
        update_option( 'ls2_fb_page_token',     sanitize_text_field( $_POST['ls2_fb_page_token'] ?? '' ) );
        update_option( 'ls2_x_handle',          sanitize_text_field( $_POST['ls2_x_handle'] ?? '' ) );
        update_option( 'ls2_instagram_handle',  sanitize_text_field( $_POST['ls2_instagram_handle'] ?? '' ) );
        update_option( 'ls2_pinterest_handle',  sanitize_text_field( $_POST['ls2_pinterest_handle'] ?? '' ) );
        update_option( 'ls2_youtube_channel',   sanitize_text_field( $_POST['ls2_youtube_channel'] ?? '' ) );
        echo '<div class="notice notice-success is-dismissible"><p>Settings saved.</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>LeisureSocial <span style="font-size:13px;color:#888;font-weight:400;">v<?php echo LS2_VERSION; ?></span></h1>
        <p style="color:#666;max-width:680px;">Configure your social profiles and default hashtags. API credentials are optional — without them, sharing opens the platform's native dialog which you complete manually.</p>

        <form method="post" style="max-width:680px;">
            <?php wp_nonce_field( 'ls2_save' ); ?>
            <h2 style="border-bottom:1px solid #eee;padding-bottom:8px;">Default settings</h2>
            <table class="form-table">
                <tr>
                    <th>Default hashtags</th>
                    <td>
                        <input type="text" name="ls2_default_hashtags" value="<?php echo esc_attr( get_option( 'ls2_default_hashtags', ls2_default_tags() ) ); ?>" class="regular-text" placeholder="<?php echo esc_attr( ls2_default_tags() ); ?>" />
                        <p class="description">Added to every post caption. Can be overridden per post.</p>
                    </td>
                </tr>
            </table>

            <h2 style="border-bottom:1px solid #eee;padding-bottom:8px;margin-top:24px;">Platform handles</h2>
            <table class="form-table">
                <tr><th>X (Twitter) handle</th><td><input type="text" name="ls2_x_handle" value="<?php echo esc_attr( get_option( 'ls2_x_handle', '' ) ); ?>" class="regular-text" placeholder="@traveltalk_dk" /></td></tr>
                <tr><th>Instagram handle</th><td><input type="text" name="ls2_instagram_handle" value="<?php echo esc_attr( get_option( 'ls2_instagram_handle', '' ) ); ?>" class="regular-text" placeholder="@traveltalk_dk" /></td></tr>
                <tr><th>Pinterest handle</th><td><input type="text" name="ls2_pinterest_handle" value="<?php echo esc_attr( get_option( 'ls2_pinterest_handle', '' ) ); ?>" class="regular-text" placeholder="traveltalkdk" /></td></tr>
                <tr><th>YouTube channel</th><td><input type="text" name="ls2_youtube_channel" value="<?php echo esc_attr( get_option( 'ls2_youtube_channel', '' ) ); ?>" class="regular-text" placeholder="@traveltalkdk" /></td></tr>
            </table>

            <h2 style="border-bottom:1px solid #eee;padding-bottom:8px;margin-top:24px;">Facebook — direct posting (optional)</h2>
            <p style="color:#666;font-size:13px;">Leave blank to use the standard Facebook share dialog. Fill in to post directly to your Facebook Page without leaving WordPress.</p>
            <table class="form-table">
                <tr>
                    <th>Page ID</th>
                    <td><input type="text" name="ls2_fb_page_id" value="<?php echo esc_attr( get_option( 'ls2_fb_page_id', '' ) ); ?>" class="regular-text" placeholder="123456789" /></td>
                </tr>
                <tr>
                    <th>Page Access Token</th>
                    <td>
                        <input type="password" name="ls2_fb_page_token" value="<?php echo esc_attr( get_option( 'ls2_fb_page_token', '' ) ); ?>" class="large-text" />
                        <p class="description">Generate a never-expiring Page token via <a href="https://developers.facebook.com/tools/explorer/" target="_blank">Graph API Explorer</a>.</p>
                    </td>
                </tr>
            </table>

            <p><input type="submit" name="ls2_save" class="button button-primary" value="Save Settings" /></p>
        </form>

        <h2 style="border-bottom:1px solid #eee;padding-bottom:8px;margin-top:32px;">How to use</h2>
        <ol style="color:#555;max-width:680px;line-height:1.8;">
            <li>Open any published post in the WordPress editor.</li>
            <li>Find the <strong>Share to Social</strong> meta box (below the editor or in the sidebar).</li>
            <li>Edit the caption if needed, then click a platform button.</li>
            <li><strong>Facebook / X / Pinterest</strong> → opens a pre-filled share dialog in a new tab.</li>
            <li><strong>Instagram / YouTube</strong> → copies the caption + image URL to clipboard. Paste into the app.</li>
            <li>Every click is logged with timestamp in the post's share history.</li>
        </ol>
    </div>
    <?php
}

// ── Meta box ──────────────────────────────────────────────────────

add_action( 'add_meta_boxes', 'ls2_add_meta_box' );
function ls2_add_meta_box() {
    add_meta_box(
        'ls2_social_share',
        '📣 Share to Social',
        'ls2_meta_box_html',
        'post',
        'normal',
        'high'
    );
}

function ls2_meta_box_html( $post ) {
    // Only useful for published posts
    $published = $post->post_status === 'publish';
    $post_url  = get_permalink( $post->ID );
    $title     = $post->post_title;
    $excerpt   = has_excerpt( $post->ID )
        ? get_the_excerpt( $post->ID )
        : wp_trim_words( strip_shortcodes( $post->post_content ), 30 );
    $image_url = get_the_post_thumbnail_url( $post->ID, 'large' ) ?: '';

    $default_tags = get_option( 'ls2_default_hashtags', ls2_default_tags() );
    $saved_tags   = get_post_meta( $post->ID, '_ls2_hashtags', true ) ?: $default_tags;
    $share_log    = get_post_meta( $post->ID, '_ls2_share_log', true ) ?: [];

    if ( ! $published ) {
        echo '<p style="color:#888;padding:8px 0;">Publish this post first — sharing is only available for published posts.</p>';
        return;
    }

    // Build platform captions
    $captions = ls2_build_captions( $title, $excerpt, $post_url, $image_url, $saved_tags );

    wp_nonce_field( 'ls2_share', 'ls2_nonce' );
    ?>
    <style>
    #ls2-wrap { font-size:13px; }
    .ls2-hashtag-row { margin-bottom:14px; }
    .ls2-hashtag-row label { font-weight:600; display:block; margin-bottom:4px; }
    .ls2-hashtag-row input { width:100%; }
    .ls2-platforms { display:flex; gap:10px; flex-wrap:wrap; margin-bottom:18px; }
    .ls2-btn {
        display:inline-flex; align-items:center; gap:6px;
        padding:9px 16px; border:none; border-radius:6px;
        font-size:13px; font-weight:600; cursor:pointer; color:#fff;
        text-decoration:none; transition:opacity .15s;
    }
    .ls2-btn:hover { opacity:.88; color:#fff; }
    .ls2-btn.ls2-fb   { background:#1877F2; }
    .ls2-btn.ls2-ig   { background:linear-gradient(135deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888); }
    .ls2-btn.ls2-pin  { background:#E60023; }
    .ls2-btn.ls2-yt   { background:#FF0000; }
    .ls2-btn.ls2-x    { background:#000; }
    .ls2-caption-area { margin-bottom:16px; }
    .ls2-caption-area label { font-weight:600; display:block; margin-bottom:4px; }
    .ls2-caption-area textarea { width:100%; font-size:12px; line-height:1.5; font-family:inherit; border-radius:4px; border:1px solid #ddd; padding:8px; resize:vertical; }
    .ls2-tabs { display:flex; gap:4px; margin-bottom:0; border-bottom:2px solid #eee; }
    .ls2-tab { padding:6px 12px; background:none; border:none; border-radius:4px 4px 0 0; cursor:pointer; font-size:12px; font-weight:600; color:#666; border:1px solid transparent; border-bottom:none; }
    .ls2-tab.active { background:#fff; border-color:#ddd; color:#000; margin-bottom:-2px; border-bottom:2px solid #fff; }
    .ls2-tab-panel { display:none; }
    .ls2-tab-panel.active { display:block; }
    .ls2-log { max-height:200px; overflow-y:auto; }
    .ls2-log-item { display:flex; gap:8px; padding:5px 0; border-bottom:1px solid #f0f0f0; font-size:12px; align-items:center; }
    .ls2-log-item .ls2-log-icon { font-size:16px; width:20px; flex-shrink:0; }
    .ls2-log-item .ls2-log-time { color:#888; flex-shrink:0; }
    .ls2-copy-msg { display:none; color:#16a34a; font-size:12px; margin-left:8px; }
    .ls2-btn-wrap { display:inline-flex; flex-direction:column; align-items:center; gap:4px; }
    .ls2-btn-hint { font-size:11px; color:#888; text-align:center; max-width:130px; line-height:1.3; }
    </style>

    <div id="ls2-wrap">

        <div class="ls2-hashtag-row">
            <label for="ls2-hashtags">Hashtags for this post</label>
            <input type="text" id="ls2-hashtags" name="ls2_hashtags" value="<?php echo esc_attr( $saved_tags ); ?>" placeholder="<?php echo esc_attr( $default_tags ); ?>" />
        </div>

        <div class="ls2-tabs">
            <button class="ls2-tab active" data-tab="ls2-share-tab">Share</button>
            <button class="ls2-tab" data-tab="ls2-captions-tab">Captions</button>
            <button class="ls2-tab" data-tab="ls2-log-tab">Log <?php if ( $share_log ) echo '(' . count( $share_log ) . ')'; ?></button>
        </div>

        <div id="ls2-share-tab" class="ls2-tab-panel active" style="padding-top:14px;">
            <p style="margin-top:0;color:#555;">Click a platform — the share dialog or caption copy is ready instantly.</p>
            <div class="ls2-platforms">
                <?php
                $fb_page_id    = get_option( 'ls2_fb_page_id', '' );
                $fb_page_token = get_option( 'ls2_fb_page_token', '' );
                $has_fb_api    = $fb_page_id && $fb_page_token;

                $fb_url = add_query_arg( 'u', rawurlencode( $post_url ), 'https://www.facebook.com/sharer/sharer.php' );
                $x_text = rawurlencode( $title . ' ' . $post_url );
                $pin_url = add_query_arg( [
                    'url'         => rawurlencode( $post_url ),
                    'media'       => rawurlencode( $image_url ),
                    'description' => rawurlencode( $captions['pinterest'] ),
                ], 'https://www.pinterest.com/pin/create/button/' );
                ?>
                <div class="ls2-btn-wrap">
                    <a class="ls2-btn ls2-fb" href="<?php echo esc_url( $fb_url ); ?>" target="_blank" rel="noopener"
                       onclick="ls2LogShare(<?php echo $post->ID; ?>, 'facebook', '<?php echo esc_js( wp_create_nonce('ls2_log') ); ?>')">
                        📘 Facebook
                    </a>
                    <a class="ls2-btn-hint" style="text-decoration:none;color:#1877F2;" href="https://developers.facebook.com/tools/debug/?q=<?php echo rawurlencode( $post_url ); ?>" target="_blank" rel="noopener" title="First-share only — click 'Scrape Again' so FB picks up the title + image">🔧 FB Debugger</a>
                </div>

                <a class="ls2-btn ls2-x" href="https://twitter.com/intent/tweet?text=<?php echo $x_text; ?>" target="_blank" rel="noopener"
                   onclick="ls2LogShare(<?php echo $post->ID; ?>, 'x', '<?php echo esc_js( wp_create_nonce('ls2_log') ); ?>')">
                    𝕏 X / Twitter
                </a>

                <a class="ls2-btn ls2-pin" href="<?php echo esc_url( $pin_url ); ?>" target="_blank" rel="noopener"
                   onclick="ls2LogShare(<?php echo $post->ID; ?>, 'pinterest', '<?php echo esc_js( wp_create_nonce('ls2_log') ); ?>')">
                    📌 Pinterest
                </a>

                <div class="ls2-btn-wrap">
                    <button type="button" class="ls2-btn ls2-ig" onclick="ls2CopyAndLog('ls2-caption-instagram', <?php echo $post->ID; ?>, 'instagram', '<?php echo esc_js( wp_create_nonce('ls2_log') ); ?>')">
                        📷 Copy for Instagram
                    </button>
                    <span class="ls2-btn-hint">Copies caption — open the app and paste<?php if ( $image_url ) : ?> · <a href="<?php echo esc_url( $image_url ); ?>" download target="_blank" rel="noopener">⬇ Download the picture</a><?php endif; ?></span>
                </div>

                <div class="ls2-btn-wrap">
                    <button type="button" class="ls2-btn ls2-yt" onclick="ls2CopyAndLog('ls2-caption-youtube', <?php echo $post->ID; ?>, 'youtube', '<?php echo esc_js( wp_create_nonce('ls2_log') ); ?>')">
                        ▶ Copy for YouTube
                    </button>
                    <span class="ls2-btn-hint">Copies description — paste in YouTube Studio</span>
                </div>

                <span class="ls2-copy-msg" id="ls2-copy-msg">✅ Copied to clipboard!</span>
            </div>
        </div>

        <div id="ls2-captions-tab" class="ls2-tab-panel" style="padding-top:14px;">
            <p style="margin-top:0;color:#555;font-size:12px;">Auto-generated captions — edit freely before sharing. Changes are applied when you click the platform button.</p>

            <?php foreach ( [
                'facebook'  => [ '📘 Facebook', 2200 ],
                'instagram' => [ '📷 Instagram', 2200 ],
                'pinterest' => [ '📌 Pinterest', 500 ],
                'youtube'   => [ '▶ YouTube Community', 1000 ],
                'x'         => [ '𝕏 X / Twitter', 280 ],
            ] as $key => [$label, $maxlen] ) : ?>
            <div class="ls2-caption-area">
                <label><?php echo $label; ?> <span style="font-weight:normal;color:#888;">(max <?php echo $maxlen; ?> chars)</span></label>
                <textarea id="ls2-caption-<?php echo $key; ?>" rows="<?php echo $key === 'x' ? 3 : 5; ?>" maxlength="<?php echo $maxlen; ?>"><?php echo esc_textarea( $captions[ $key ] ); ?></textarea>
            </div>
            <?php endforeach; ?>

            <?php if ( $image_url ) : ?>
            <div class="ls2-caption-area">
                <label>Featured image URL <span style="font-weight:normal;color:#888;">(for Instagram — copy and paste into app)</span></label>
                <input type="text" value="<?php echo esc_attr( $image_url ); ?>" readonly onclick="this.select();" style="width:100%;font-size:12px;padding:6px 8px;border:1px solid #ddd;border-radius:4px;" />
            </div>
            <?php endif; ?>
        </div>

        <div id="ls2-log-tab" class="ls2-tab-panel" style="padding-top:14px;">
            <?php if ( empty( $share_log ) ) : ?>
                <p style="color:#888;margin-top:0;">No shares logged yet for this post.</p>
            <?php else : ?>
                <div class="ls2-log">
                    <?php
                    $icons = [
                        'facebook'  => '📘',
                        'instagram' => '📷',
                        'pinterest' => '📌',
                        'youtube'   => '▶',
                        'x'         => '𝕏',
                    ];
                    foreach ( array_reverse( $share_log ) as $entry ) :
                        $platform = $entry['platform'] ?? '';
                        $icon = $icons[ $platform ] ?? '📣';
                    ?>
                    <div class="ls2-log-item">
                        <span class="ls2-log-icon"><?php echo $icon; ?></span>
                        <span><?php echo esc_html( ucfirst( $platform ) ); ?></span>
                        <span class="ls2-log-time"><?php echo esc_html( $entry['time'] ?? '' ); ?></span>
                        <?php if ( ! empty( $entry['note'] ) ) : ?>
                            <span style="color:#888;">— <?php echo esc_html( $entry['note'] ); ?></span>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

    </div>

    <script>
    // Tab switching
    document.querySelectorAll('.ls2-tab').forEach(function(btn) {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.ls2-tab').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.ls2-tab-panel').forEach(p => p.classList.remove('active'));
            this.classList.add('active');
            document.getElementById(this.dataset.tab).classList.add('active');
        });
    });

    // Update X share link when caption changes
    document.getElementById('ls2-caption-x') && document.getElementById('ls2-caption-x').addEventListener('input', function() {
        // X link is pre-built — inform user to use caption tab
    });

    // Copy caption to clipboard and log
    function ls2CopyAndLog(textareaId, postId, platform, nonce) {
        // 2.0.2: never let the click save the post; work when the caption tab is closed; say when copying fails.
        if (window.event) { window.event.preventDefault(); }
        // 2.0.3: the buttons asked for 'ls2-caption-ig' / '-yt', but the caption boxes are named after the platform.
        var ta = document.getElementById(textareaId) || document.getElementById('ls2-caption-' + platform);
        var text = ta ? ta.value : '';
        var done = function() {
            var msg = document.getElementById('ls2-copy-msg');
            if (msg) { msg.textContent = '✅ Copied – open ' + (platform === 'instagram' ? 'Instagram' : 'YouTube') + ' and paste'; msg.style.display = 'inline'; setTimeout(function() { msg.style.display = 'none'; }, 3500); }
            ls2LogShare(postId, platform, nonce, 'caption copied');
        };
        var fallback = function() {
            var tmp = document.createElement('textarea');
            tmp.value = text; tmp.setAttribute('readonly', '');
            tmp.style.position = 'fixed'; tmp.style.top = '-1000px'; tmp.style.opacity = '0';
            document.body.appendChild(tmp); tmp.select(); tmp.setSelectionRange(0, text.length);
            var ok = false;
            try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
            document.body.removeChild(tmp);
            if (ok) { done(); } else { window.prompt('Copying was blocked by the browser. Select all (Ctrl/Cmd+A), copy (Ctrl/Cmd+C), then press OK:', text); ls2LogShare(postId, platform, nonce, 'caption shown to copy by hand'); }
        };
        if (!text) { alert('The caption is empty. Open the Captions tab and write one.'); return false; }
        try {
            if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(text).then(done, fallback); } else { fallback(); }
        } catch (e) { fallback(); }
        return false;
    }

    // Log share via AJAX
    function ls2LogShare(postId, platform, nonce, note) {
        note = note || '';
        fetch(ajaxurl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action:   'ls2_log_share',
                post_id:  postId,
                platform: platform,
                note:     note,
                _nonce:   nonce
            })
        });
    }

    <?php if ( $has_fb_api ) : ?>
    // Facebook direct API posting
    document.getElementById('ls2-post-fb') && document.getElementById('ls2-post-fb').addEventListener('click', function() {
        var btn = this;
        btn.disabled = true;
        btn.textContent = '⏳ Posting…';
        var caption = document.getElementById('ls2-caption-facebook') ? document.getElementById('ls2-caption-facebook').value : '';
        fetch(ajaxurl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action:   'ls2_fb_post',
                post_id:  <?php echo $post->ID; ?>,
                caption:  caption,
                _nonce:   btn.dataset.nonce
            })
        })
        .then(r => r.json())
        .then(function(data) {
            if (data.success) {
                btn.textContent = '✅ Posted!';
                btn.style.background = '#16a34a';
            } else {
                btn.textContent = '❌ ' + (data.data || 'Failed');
                btn.disabled = false;
            }
        })
        .catch(function() {
            btn.textContent = '❌ Error';
            btn.disabled = false;
        });
    });
    <?php endif; ?>
    </script>
    <?php
}

// ── Build captions ────────────────────────────────────────────────

function ls2_build_captions( $title, $excerpt, $url, $image_url, $hashtags ) {
    $tags    = trim( $hashtags );
    $da      = ls2_is_danish();
    $excerpt = trim( $excerpt );

    return [

        'facebook' => trim( $title ) . "\n\n"
            . $excerpt . "\n\n"
            . ( $da ? '👉 Læs hele artiklen: ' : '👉 Read the full article: ' ) . $url . "\n\n"
            . $tags,

        'instagram' => trim( $title ) . "\n\n"
            . $excerpt . "\n\n"
            . $tags . "\n\n"
            . ( $da ? '🔗 Link i bio — eller søg på: ' : '🔗 Link in bio — or search for: ' ) . parse_url( $url, PHP_URL_HOST ),

        'pinterest' => trim( $title ) . ' — ' . $excerpt
            . ' ' . $tags,

        'youtube' => trim( $title ) . "\n\n"
            . $excerpt . "\n\n"
            . ( $da ? 'Læs mere: ' : 'Read more: ' ) . $url . "\n\n"
            . $tags,

        'x' => mb_substr( trim( $title ), 0, 200 )
            . ' ' . $url
            . ( $tags ? ' ' . mb_substr( $tags, 0, 60 ) : '' ),
    ];
}

// ── Save hashtags on post save ────────────────────────────────────

add_action( 'save_post', 'ls2_save_meta' );
function ls2_save_meta( $post_id ) {
    if ( ! isset( $_POST['ls2_nonce'] ) || ! wp_verify_nonce( $_POST['ls2_nonce'], 'ls2_share' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    update_post_meta( $post_id, '_ls2_hashtags', sanitize_text_field( $_POST['ls2_hashtags'] ?? '' ) );
}

// ── AJAX: log share ───────────────────────────────────────────────

add_action( 'wp_ajax_ls2_log_share', 'ls2_ajax_log_share' );
function ls2_ajax_log_share() {
    $nonce    = sanitize_text_field( $_POST['_nonce'] ?? '' );
    $post_id  = intval( $_POST['post_id'] ?? 0 );
    $platform = sanitize_text_field( $_POST['platform'] ?? '' );
    $note     = sanitize_text_field( $_POST['note'] ?? '' );

    if ( ! wp_verify_nonce( $nonce, 'ls2_log' ) || ! current_user_can( 'edit_post', $post_id ) ) {
        wp_send_json_error( 'Forbidden' );
    }

    $log   = get_post_meta( $post_id, '_ls2_share_log', true ) ?: [];
    $log[] = [
        'platform' => $platform,
        'time'     => current_time( 'mysql' ),
        'note'     => $note,
    ];
    if ( count( $log ) > 100 ) $log = array_slice( $log, -100 );
    update_post_meta( $post_id, '_ls2_share_log', $log );

    wp_send_json_success();
}

// ── AJAX: Facebook Graph API direct post ──────────────────────────

add_action( 'wp_ajax_ls2_fb_post', 'ls2_ajax_fb_post' );
function ls2_ajax_fb_post() {
    $nonce   = sanitize_text_field( $_POST['_nonce'] ?? '' );
    $post_id = intval( $_POST['post_id'] ?? 0 );
    $caption = sanitize_textarea_field( $_POST['caption'] ?? '' );

    if ( ! wp_verify_nonce( $nonce, 'ls2_api_share' ) || ! current_user_can( 'edit_post', $post_id ) ) {
        wp_send_json_error( 'Forbidden' );
    }

    $page_id    = get_option( 'ls2_fb_page_id', '' );
    $page_token = get_option( 'ls2_fb_page_token', '' );

    if ( ! $page_id || ! $page_token ) {
        wp_send_json_error( 'Facebook Page not configured in Settings.' );
    }

    $image_url = get_the_post_thumbnail_url( $post_id, 'large' ) ?: '';
    $post_url  = get_permalink( $post_id );

    // Post to Facebook Page feed
    $api_url = "https://graph.facebook.com/v21.0/{$page_id}/feed";
    $payload = [
        'message'      => $caption,
        'link'         => $post_url,
        'access_token' => $page_token,
    ];

    // If we have an image, post as photo instead
    if ( $image_url ) {
        $api_url = "https://graph.facebook.com/v21.0/{$page_id}/photos";
        $payload['url']     = $image_url;
        $payload['caption'] = $caption;
        unset( $payload['link'] );
    }

    $response = wp_remote_post( $api_url, [
        'timeout' => 20,
        'body'    => $payload,
    ] );

    if ( is_wp_error( $response ) ) {
        wp_send_json_error( $response->get_error_message() );
    }

    $body = json_decode( wp_remote_retrieve_body( $response ), true );
    $code = wp_remote_retrieve_response_code( $response );

    if ( $code !== 200 || empty( $body['id'] ) ) {
        $err = $body['error']['message'] ?? 'Unknown Facebook API error';
        wp_send_json_error( $err );
    }

    // Log it
    $log   = get_post_meta( $post_id, '_ls2_share_log', true ) ?: [];
    $log[] = [
        'platform' => 'facebook',
        'time'     => current_time( 'mysql' ),
        'note'     => 'Direct API post — FB ID: ' . $body['id'],
    ];
    update_post_meta( $post_id, '_ls2_share_log', $log );

    wp_send_json_success( [ 'fb_id' => $body['id'] ] );
}

// ── Post list column: quick share buttons ─────────────────────────

add_filter( 'manage_post_posts_columns', 'ls2_add_list_column' );
function ls2_add_list_column( $cols ) {
    $cols['ls2_shared'] = '📣 Shared';
    return $cols;
}

add_action( 'manage_post_posts_custom_column', 'ls2_render_list_column', 10, 2 );
function ls2_render_list_column( $col, $post_id ) {
    if ( $col !== 'ls2_shared' ) return;

    $log   = get_post_meta( $post_id, '_ls2_share_log', true ) ?: [];
    $platforms_shared = array_unique( array_column( $log, 'platform' ) );

    $icons = [
        'facebook'  => '📘',
        'instagram' => '📷',
        'pinterest' => '📌',
        'youtube'   => '▶',
        'x'         => '𝕏',
    ];

    if ( empty( $platforms_shared ) ) {
        echo '<span style="color:#ccc;font-size:12px;">Not shared</span>';
        return;
    }

    foreach ( $platforms_shared as $platform ) {
        echo '<span title="' . esc_attr( ucfirst( $platform ) ) . '" style="font-size:16px;">' . ( $icons[ $platform ] ?? '📣' ) . '</span> ';
    }
}
