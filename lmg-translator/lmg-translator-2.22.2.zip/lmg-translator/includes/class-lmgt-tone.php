<?php
/**
 * 2.19.5 (G, 22 Nov 2026, briefs/translator-tone-check-brief.md): the Tone step, after Structure.
 *
 * Claude reads the text against the house-style tone rules (§9A5 "Tone: what rings true") and flags
 * passages: the words, the rule broken, why in one line, and a rewrite that keeps the meaning and adds
 * nothing that is not in the text. Where the fix needs a fact the text does not have, it says
 * "needs a concrete detail" instead of inventing one. Shown like the other proposals: tick or untick
 * each, then Accept; the text only changes on Accept. Advice only: never blocks publishing.
 *
 * Runs by itself on new articles (first publication of a post published after this version was
 * installed, and the automatic translations of those); on older texts when clicked.
 * Not on service pages (agency pages, the Travel Services section): Settings → Tone → Leave alone.
 *
 * Options: lmgt_tone_rules (the rules, editable; empty = the starter list), lmgt_tone_auto ('1'|'0'),
 *          lmgt_tone_skip (address parts or page IDs, one per line), lmgt_tone_since (install time).
 * Meta:    _lmgt_tone      waiting proposal [list, at, hash]
 *          _lmgt_tone_done [hash, at, found, put, left] – the text as it was when Tone was last settled
 *          _lmgt_tone_auto time, so a text is checked by itself once
 *          _lmgt_tone_err  the last automatic run's error, shown in the step
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class LMGT_Tone {

	const HOOK = 'lmgt_tone_auto';
	const MAX  = 12;

	const RULES = "The test: would a well-travelled friend say this out loud? If it sounds like a brochure, a wellness app or a consultant, rewrite it. Humanise: one person, one place, one moment before any general claim. We write to inspire travel, not a manual: wordplay, puns, alliteration and a headline with a twist that land are craft, and they stay (\"Schweiz står for kvalitet fra ure til urlaub\" is gold). The enemy is mediocre writing, not selling.\n\n"
		. "1. Never announce the article. Start with the content. \"Her får du et indblik i …\", \"I denne artikel …\", \"Læs med, hvis …\" go.\n"
		. "2. No unsupported superlatives. \"De bedste\", \"unik\", \"perle\", \"verdens smukkeste\" only with a named source or criterion.\n"
		. "3. Concrete before abstract. A place, a time, a number, a body. Show it, don't name it: not \"bevægelse uden præstationspres\" but \"40 minutter i olivenlundene før morgenmaden, ingen pulsure\".\n"
		. "4. No buzzwords as content. autenticitet, nærvær, holistisk, rejse (as metaphor), oplevelse (as filler), bæredygtig (as an adjective with nothing behind it), \"magisk\", \"skjult perle\".\n"
		. self::RULE5 . "\n"
		. self::RULE6 . "\n"
		. "7. No small digs at the reader (Instagram, \"turisterne\", \"masseturisme\"). We never talk down.\n"
		. "8. No claims we cannot document. Health, healing, \"forvandler dig\" only with a source.\n"
		. "9. Idiomatic Danish, not translated Danish. Things don't \"see\", \"work with\" or \"invite\"; people do.\n"
		. "10. A Danish text speaks to Danish readers. Departures, prices and practical details are Danish unless the article is explicitly about another country's departures. Norwegian references in a Danish text are an error.\n"
		. "11. Name people, or leave them out. \"En fodboldspiller\", \"en kendt kok\", \"en lokal guide\" without a name is worse than nothing: it sounds like filler and proves nothing. A name with clout, or a named local with a role and a place, carries the point; an anonymous one does not.";

	const SKIP = "travel-services";

	/** 2.22.1 (G, 28 Nov 2026): rule 5 judges the use, it no longer bans "Oplev". "Rejseoplevelser" is what we deliver. */
	/** 2.22.2 (G, 28 Nov 2026): wordplay that lands is craft; only tired formulas and limp half-puns are flagged. */
	const RULE6_OLD = "6. No formulas. No \"ikke X, men Y\", no half-puns (\"blive bedre … se bedre ud\"), no triplets of abstract nouns.";
	const RULE6     = "6. No tired formulas: \"ikke X, men Y\" on autopilot, triplets of abstract nouns, half-puns that fall flat (\"blive bedre … se bedre ud\"). Wordplay that lands is not a formula: leave it (\"Schweiz står for kvalitet fra ure til urlaub\").";
	const RULE5_OLD = "5. No sales voice in editorial text. \"Oplev\", \"Lad dig forføre\", \"Læs med\", \"Glæd dig til\".";
	const RULE5     = "5. No sales voice in editorial text: pushy calls to the reader, ad copy and hype (\"Lad dig forføre\", \"Glæd dig til\", \"Gå ikke glip af\", \"Book nu\"). \"Oplev\" and \"oplevelse\" are not sales voice when they say what the reader actually does or meets there (\"oplev byens skuespilhus\", \"oplev Schweiz' teatre og musicals\"): leave those alone. Flag them only when they stand in for content (\"oplev magien\", \"en oplevelse for livet\") or come with hype.";

	public static function boot() {
		if ( get_option( 'lmgt_tone_since', '' ) === '' ) update_option( 'lmgt_tone_since', time(), false );
		add_action( 'admin_post_lmgt_tone', array( __CLASS__, 'handle_propose' ) );
		add_action( 'admin_post_lmgt_tone_apply', array( __CLASS__, 'handle_apply' ) );
		add_action( self::HOOK, array( __CLASS__, 'auto_run' ) );
		add_action( 'transition_post_status', array( __CLASS__, 'on_transition' ), 30, 3 );
		// The automatic translations of new articles (LMGT_Auto marks each one when it lands).
		add_action( 'added_post_meta', function ( $mid, $pid, $key ) {
			if ( $key === '_lmgt_autopub' ) LMGT_Tone::schedule( (int) $pid );
		}, 10, 3 );
	}

	// ---- Settings ----------------------------------------------------------------------

	public static function rules() {
		$t = trim( (string) get_option( 'lmgt_tone_rules', '' ) );
		if ( $t !== '' && ( strpos( $t, self::RULE5_OLD ) !== false || strpos( $t, self::RULE6_OLD ) !== false ) ) { // 2.22.1: a saved copy of the old rule 5 gets the new one; an edited rule 5 is left as G wrote it.
			$t = str_replace( array( self::RULE5_OLD, self::RULE6_OLD ), array( self::RULE5, self::RULE6 ), $t );
			update_option( 'lmgt_tone_rules', $t, false );
		}
		return $t === '' ? str_replace( 'a well-travelled friend', LMGT_Subject::w( 'friend' ), self::RULES ) : $t;
	}

	public static function auto_on() {
		return get_option( 'lmgt_tone_auto', '1' ) === '1';
	}

	public static function skip_list() {
		$t = get_option( 'lmgt_tone_skip', false );
		if ( $t === false ) $t = self::SKIP;
		return array_values( array_filter( array_map( 'trim', preg_split( '/[\r\n,]+/', strtolower( (string) $t ) ) ) ) );
	}

	/** The rows for Translator → Settings. */
	public static function settings_rows() {
		$skip = get_option( 'lmgt_tone_skip', false );
		return '<tr><th>Tone</th><td><input type="hidden" name="lmgt_tone_form" value="1">'
			. '<p class="description">The rules the Tone step checks every text against (house style "Tone: what rings true"). One rule per line, numbered; the number is what the step shows. Add, change or remove rules here; no new version is needed. Empty = the starter list of 11 rules.</p>'
			. '<textarea name="lmgt_tone_rules" rows="16" class="large-text">' . esc_textarea( self::rules() ) . '</textarea>'
			. '<p><label><input type="checkbox" name="lmgt_tone_auto" value="1" ' . checked( self::auto_on(), true, false ) . '> Check new articles by themselves (the first time they are published, and their automatic translations). Older texts: click "Check the tone" in the steps.</label></p>'
			. '<p>Leave these pages alone (service pages: agency pages, the Travel Services section). One per line: a page ID, or a word from the address. Their subpages are left alone too.<br><textarea name="lmgt_tone_skip" rows="3" class="regular-text code">' . esc_textarea( $skip === false ? self::SKIP : (string) $skip ) . '</textarea></p></td></tr>';
	}

	public static function save_settings() {
		if ( empty( $_POST['lmgt_tone_form'] ) ) return;
		$r = isset( $_POST['lmgt_tone_rules'] ) ? trim( sanitize_textarea_field( wp_unslash( $_POST['lmgt_tone_rules'] ) ) ) : '';
		update_option( 'lmgt_tone_rules', $r === trim( self::RULES ) ? '' : $r, false );
		update_option( 'lmgt_tone_auto', empty( $_POST['lmgt_tone_auto'] ) ? '0' : '1', false );
		update_option( 'lmgt_tone_skip', isset( $_POST['lmgt_tone_skip'] ) ? sanitize_textarea_field( wp_unslash( $_POST['lmgt_tone_skip'] ) ) : '', false );
	}

	/** [number => the rule's first sentence], from the settings field. */
	public static function rule_names() {
		$out = array();
		foreach ( preg_split( '/\r?\n/', self::rules() ) as $line ) {
			if ( preg_match( '/^\s*(\d+)[.)]\s*(.+)$/u', $line, $m ) ) {
				$first = preg_split( '/(?<=[.!?])\s/u', trim( $m[2] ), 2 );
				$out[ (int) $m[1] ] = $first[0];
			}
		}
		return $out;
	}

	// ---- Which texts -------------------------------------------------------------------

	/** A service page (agency pages, Travel Services): an ID or address word on the list, for the page or one above it. */
	public static function skipped( $post ) {
		$post = get_post( $post );
		if ( ! $post ) return true;
		$list = self::skip_list();
		if ( ! $list ) return false;
		$ids  = array_merge( array( (int) $post->ID ), array_map( 'intval', get_post_ancestors( $post ) ) );
		if ( $post->post_type === LMGT_CPT ) {
			$src = (int) get_post_meta( $post->ID, '_lmgt_source', true );
			if ( $src && get_post( $src ) && ! LMGT_Bridge::is_target() ) $ids = array_merge( $ids, array( $src ), array_map( 'intval', get_post_ancestors( $src ) ) );
		}
		$path = strtolower( (string) wp_parse_url( (string) get_permalink( $post ), PHP_URL_PATH ) );
		foreach ( $ids as $i ) $path .= ' ' . get_post_field( 'post_name', $i );
		foreach ( $list as $s ) {
			if ( is_numeric( $s ) ) { if ( in_array( (int) $s, $ids, true ) ) return true; continue; }
			if ( strpos( $path, $s ) !== false ) return true;
		}
		return false;
	}

	private static function lang( $post ) {
		return $post->post_type === LMGT_CPT ? (string) get_post_meta( $post->ID, '_lmgt_lang', true ) : LMGT_Langs::source();
	}

	private static function hash( $post ) {
		return md5( preg_replace( '/\s+/', ' ', trim( (string) $post->post_content ) ) );
	}

	// ---- The step in the panel ---------------------------------------------------------

	public static function step_row( $n, $post ) {
		$id = $post->ID;
		if ( self::skipped( $post ) ) {
			LMGT_Steps::row( $n, 'Tone', 'none', 'Service page: Tone leaves it alone (Translator → Settings → Tone).' );
			return;
		}
		$ai   = LMGT_Engines::ai_available();
		$p    = get_post_meta( $id, '_lmgt_tone', true );
		$run  = $ai ? self::btn( self::url( 'lmgt_tone', $id ), 'Check the tone', true ) : '';
		if ( is_array( $p ) && isset( $p['list'] ) && $p['list'] ) {
			$names = self::rule_names();
			$can   = 0;
			$li    = '<ul style="list-style:none;margin:6px 0 0 0">';
			foreach ( $p['list'] as $i => $x ) {
				$rules = array_map( 'intval', (array) $x['rules'] );
				$rt    = implode( ', ', array_map( function ( $r ) use ( $names ) { return '<abbr title="' . esc_attr( isset( $names[ $r ] ) ? $names[ $r ] : '' ) . '">' . (int) $r . '</abbr>'; }, $rules ) );
				$li   .= '<li style="margin:0 0 10px;padding:6px 8px;background:#f6f7f7;border-left:3px solid #b26200">';
				if ( $x['rewrite'] !== '' && empty( $x['hand'] ) ) {
					$can++;
					$li .= '<label><input type="checkbox" class="lmgt-tonepick" value="' . (int) $i . '" checked> ';
				} else {
					$li .= '<label><input type="checkbox" disabled> ';
				}
				$li .= '<em>"' . esc_html( $x['passage'] ) . '"</em></label><br><span class="description">Rule ' . $rt . ': ' . esc_html( $x['why'] ) . '</span>';
				if ( $x['rewrite'] !== '' ) $li .= '<br>→ <strong>' . esc_html( $x['rewrite'] ) . '</strong>';
				if ( ! empty( $x['hand'] ) ) $li .= '<br><span class="description" style="color:#996800">This passage runs across a link or bold text, so it cannot be put in by itself: change it by hand in the editor.</span>';
				if ( $x['detail'] !== '' ) $li .= '<br><span style="color:#996800"><strong>Needs a concrete detail:</strong> ' . esc_html( $x['detail'] ) . ' Add it by hand if you know it; Translator never makes one up.</span>';
				$li .= '</li>';
			}
			$li  .= '</ul>';
			$n_all = count( $p['list'] );
			$acc   = self::url( 'lmgt_tone_apply', $id, '&do=apply' );
			$js    = '<script>(function(){document.addEventListener("change",function(e){if(!e.target.classList||!e.target.classList.contains("lmgt-tonepick"))return;var p=[].slice.call(document.querySelectorAll(".lmgt-tonepick"));var on=p.filter(function(x){return x.checked}).map(function(x){return x.value});[].forEach.call(document.querySelectorAll(".lmgt-toneacc"),function(b){var base=b.getAttribute("data-base");b.href=on.length<p.length?base+"&only="+(on.length?on.join("-"):"none"):base;b.textContent=on.length?"Accept: put the "+on.length+" ticked in the text":"Nothing ticked: Reject instead";});});})();</script>';
			$txt   = '<strong>Tone: ' . $n_all . ' passage' . ( $n_all === 1 ? '' : 's' ) . ' to look at.</strong> Advice only: publishing is never held up. Untick the rewrites you do not want; the untouched ones are rejected.' . $li . $js;
			$btns  = $can ? '<a class="button button-primary lmgt-toneacc" data-base="' . esc_url( $acc ) . '" href="' . esc_url( $acc ) . '">Accept: put the ticked in the text</a> ' : '';
			$btns .= self::btn( self::url( 'lmgt_tone_apply', $id, '&do=drop' ), $can ? 'Reject all' : 'Seen: clear the list' );
			LMGT_Steps::row( $n, 'Tone', 'wait', $txt, $btns );
			return;
		}
		$d   = get_post_meta( $id, '_lmgt_tone_done', true );
		$err = (string) get_post_meta( $id, '_lmgt_tone_err', true );
		if ( is_array( $d ) && isset( $d['hash'] ) && $d['hash'] === self::hash( $post ) ) {
			$t = ! empty( $d['found'] ) ? '<strong>Tone: OK.</strong> ' . (int) $d['put'] . ' of ' . (int) $d['found'] . ' rewrite(s) put in; the rest kept as you chose.' : '<strong>Tone: OK.</strong> Nothing found against the rules.';
			LMGT_Steps::row( $n, 'Tone', 'done', $t, $ai ? self::btn( self::url( 'lmgt_tone', $id ), 'Check again' ) : '' );
			return;
		}
		$queued = wp_next_scheduled( self::HOOK, array( (int) $id ) );
		$t = is_array( $d ) && isset( $d['hash'] ) ? '<strong>Tone: not checked since the text changed.</strong>' : '<strong>Tone: not checked yet.</strong>';
		if ( $queued ) $t .= ' A check is queued and runs by itself within a few minutes.';
		if ( $err !== '' ) $t .= ' <span style="color:#b32d2e">The automatic check stopped: ' . esc_html( $err ) . '</span>';
		$t .= ' <span class="description">Click <em>Check the tone</em> (about a minute): Claude reads the text against the house-style tone rules and proposes rewrites passage by passage; you tick the ones to put in. Advice only: publishing is never held up by it.</span>';
		LMGT_Steps::row( $n, 'Tone', 'todo', $t, $run );
	}

	private static function url( $action, $id, $extra = '' ) {
		return wp_nonce_url( admin_url( 'admin-post.php?action=' . $action . '&post=' . (int) $id . $extra ), 'lmgt_tone_' . (int) $id );
	}

	private static function btn( $url, $label, $primary = false ) {
		return '<a class="button' . ( $primary ? ' button-primary' : '' ) . '" href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a> ';
	}

	// ---- Automatic runs ----------------------------------------------------------------

	/** First publication of a post written after 2.19.5 was installed. */
	public static function on_transition( $new, $old, $post ) {
		if ( $new !== 'publish' || $old === 'publish' || ! $post || $post->post_type !== 'post' ) return;
		if ( strtotime( $post->post_date_gmt . ' UTC' ) < (int) get_option( 'lmgt_tone_since', 0 ) ) return;
		self::schedule( (int) $post->ID );
	}

	public static function schedule( $id ) {
		if ( ! $id || ! self::auto_on() || get_post_meta( $id, '_lmgt_tone_auto', true ) ) return;
		if ( ! LMGT_Engines::ai_available() || self::skipped( $id ) ) return;
		update_post_meta( $id, '_lmgt_tone_auto', time() );
		if ( ! wp_next_scheduled( self::HOOK, array( (int) $id ) ) ) wp_schedule_single_event( time() + 120, self::HOOK, array( (int) $id ) );
	}

	public static function auto_run( $id ) {
		$post = get_post( (int) $id );
		if ( ! $post || ! self::auto_on() || self::skipped( $post ) || get_post_meta( $id, '_lmgt_tone', true ) ) return;
		$r = self::propose( $post );
		if ( is_wp_error( $r ) ) update_post_meta( $id, '_lmgt_tone_err', $r->get_error_message() . ' Click "Check the tone" to try again.' );
	}

	// ---- Propose -----------------------------------------------------------------------

	private static function outline( $html ) {
		$html = preg_replace_callback( '#<h([1-6])[^>]*>(.*?)</h\1>#is', function ( $m ) { return "\n\n" . str_repeat( '#', (int) $m[1] ) . ' ' . wp_strip_all_tags( $m[2] ) . "\n"; }, (string) $html );
		$html = preg_replace( '#</(p|li|ul|ol|div|table|tr|blockquote)>#i', "$0\n", $html );
		return trim( preg_replace( "/\n{3,}/", "\n\n", html_entity_decode( wp_strip_all_tags( strip_shortcodes( $html ) ), ENT_QUOTES, 'UTF-8' ) ) );
	}

	public static function prompt( $lang, $title, $text ) {
		$l    = LMGT_Langs::get( $lang );
		$name = $l ? $l['name'] : 'Danish';
		$sub  = class_exists( 'LMGT_Boxes' ) ? LMGT_Boxes::subject() : 'travel';
		$house = LMGT_Subject::w( 'house' );
		$other = $lang === 'da' ? '' : "RULES are written for Danish texts. ARTICLE is in {$name}: apply each rule to the same kind of phrase in {$name}, and read \"Danish\" in a rule as {$name} and its readers.\n";
		return "You are the tone editor of {$house}. ARTICLE is a {$name} text titled \"{$title}\"; headings are marked with #. RULES are the house rules for tone, numbered.\n{$other}"
			. "Find the passages in ARTICLE that break a rule, most important first, at most " . self::MAX . ". For each:\n"
			. "- passage: copied exactly from ARTICLE, letter for letter, same case and punctuation: one sentence, a part of one, or a heading. Never more than one sentence. Never across a heading.\n"
			. "- rules: the numbers of the rules it breaks.\n"
			. "- why: one short line in English saying what is wrong.\n"
			. "- rewrite: the passage rewritten in {$name}, to stand in its place so the text around it still reads. Keep the meaning. Use only facts, places, names, times and numbers that ARTICLE already states; add nothing else. Plain, concrete words " . LMGT_Subject::w( 'friend' ) . " would say. No exclamation marks.\n"
			. "- needs_detail: when a good fix needs a fact ARTICLE does not give (a place, a time, a number, a person's name, a source), say in one short English line which detail is missing, and give rewrite \"\" unless a fair rewrite is possible without it. Never invent the detail. Otherwise \"\".\n"
			. "This is creative travel writing meant to make people want to go. Never flag wordplay, puns, alliteration, rhythm or a headline or slogan with a twist that works (\"Schweiz står for kvalitet fra ure til urlaub\" stays exactly as it is). Flag only clear errors and genuinely mediocre writing, never a creative choice. A bold or playful line is not a claim that needs a source.\n"
			. "Flag only clear breaks. A word a rule names as an example is not a break by itself: judge how it is used. When a passage can be read either way, leave it.\n"
			. "Only propose a rewrite that is clearly better than the passage: plainer, more concrete, and correct, unambiguous {$name}. Never a vaguer or ambiguous word (\"se stykker\" for \"oplev byens skuespilhus\" is worse: stykker of what?). Swapping one verb for another is not a fix. If you cannot write a clearly better rewrite and no missing detail is the problem, do not list the passage at all.\n"
			. "Do not flag: words inside quotation marks that a named person said, names of places, businesses or products, plain practical facts (prices, times, addresses). Never rewrite the whole text. If nothing breaks a rule, return an empty list.\n"
			. "Return JSON: {\"passages\":[{\"passage\":\"…\",\"rules\":[1],\"why\":\"…\",\"rewrite\":\"…\",\"needs_detail\":\"\"}]}.\n\n"
			. "RULES:\n" . self::rules() . "\n\nARTICLE:\n{$text}";
	}

	/** Words in a rewrite that the text does not have: digits, and capitalised words not at the start of a sentence. */
	public static function invented( $rewrite, $plain ) {
		$have = mb_strtolower( $plain );
		$out  = array();
		if ( preg_match_all( '/\d+(?:[.,]\d+)?/u', $rewrite, $m ) ) {
			foreach ( $m[0] as $d ) if ( mb_strpos( $have, $d ) === false ) $out[] = $d;
		}
		$words = preg_split( '/(\s+)/u', $rewrite, -1, PREG_SPLIT_DELIM_CAPTURE );
		$start = true;
		foreach ( $words as $w ) {
			if ( trim( $w ) === '' ) continue;
			$core = trim( $w, " \t\"'“”„«»‘’()[]–—-.,:;!?…" );
			if ( $core !== '' && ! $start && preg_match( '/^\p{Lu}/u', $core ) && mb_strpos( $have, mb_strtolower( $core ) ) === false ) $out[] = $core;
			$start = (bool) preg_match( '/[.!?:]["”»’]?$/u', $w );
		}
		return array_values( array_unique( $out ) );
	}

	/** Ask Claude, keep what can be found in the text, save the proposal. Returns the message, or WP_Error. */
	public static function propose( $post ) {
		$id   = $post->ID;
		$html = (string) $post->post_content;
		$text = mb_substr( self::outline( class_exists( 'LMGT_Structure' ) ? LMGT_Structure::without_boxes( $html ) : $html ), 0, 30000 );
		if ( mb_strlen( trim( $text ) ) < 80 ) return new WP_Error( 'lmgt_tone', 'The text is too short to check.' );
		$schema = array(
			'type'       => 'object',
			'properties' => array(
				'passages' => array(
					'type'  => 'array',
					'items' => array(
						'type'                 => 'object',
						'properties'           => array(
							'passage'      => array( 'type' => 'string' ),
							'rules'        => array( 'type' => 'array', 'items' => array( 'type' => 'integer' ) ),
							'why'          => array( 'type' => 'string' ),
							'rewrite'      => array( 'type' => 'string' ),
							'needs_detail' => array( 'type' => 'string' ),
						),
						'required'             => array( 'passage', 'rules', 'why', 'rewrite', 'needs_detail' ),
						'additionalProperties' => false,
					),
				),
			),
			'required'             => array( 'passages' ),
			'additionalProperties' => false,
		);
		@set_time_limit( 200 );
		$r = LMGT_Engines::ai_json( self::prompt( self::lang( $post ), $post->post_title, $text ), $schema );
		LMGT_Meter::charge( $id );
		if ( is_wp_error( $r ) ) return $r;
		delete_post_meta( $id, '_lmgt_tone_err' );
		$plain = LMGT_Text::plain( $html );
		$list  = array();
		$seen  = array();
		foreach ( (array) ( isset( $r['passages'] ) ? $r['passages'] : array() ) as $x ) {
			$pas = trim( (string) ( isset( $x['passage'] ) ? $x['passage'] : '' ) );
			if ( $pas === '' || isset( $seen[ $pas ] ) || mb_strlen( $pas ) > 600 ) continue;
			// Only what really stands in the text: a passage Claude did not copy exactly is dropped.
			if ( mb_strpos( $plain, $pas ) === false ) continue;
			$seen[ $pas ] = 1;
			$rw  = trim( wp_strip_all_tags( (string) ( isset( $x['rewrite'] ) ? $x['rewrite'] : '' ) ) );
			$det = trim( sanitize_text_field( (string) ( isset( $x['needs_detail'] ) ? $x['needs_detail'] : '' ) ) );
			// Never invents facts: a rewrite that names a number or a name the text does not have is held back.
			$new = $rw !== '' ? self::invented( $rw, $plain ) : array();
			if ( $new ) {
				$det = trim( ( $det !== '' ? $det . ' ' : '' ) . 'The rewrite named ' . implode( ', ', array_slice( $new, 0, 4 ) ) . ', which the text does not have, so it is left out.' );
				$rw  = '';
			}
			if ( $rw === $pas ) $rw = '';
			if ( $rw === '' && $det === '' ) $det = 'No rewrite proposed.';
			$list[] = array(
				'passage' => $pas,
				'rules'   => array_values( array_filter( array_map( 'intval', (array) ( isset( $x['rules'] ) ? $x['rules'] : array() ) ) ) ),
				'why'     => sanitize_text_field( (string) ( isset( $x['why'] ) ? $x['why'] : '' ) ),
				'rewrite' => $rw,
				'detail'  => $det,
				'hand'    => $rw !== '' && self::replace_once( $html, $pas, $rw ) === null ? 1 : 0,
			);
			if ( count( $list ) >= self::MAX ) break;
		}
		if ( ! $list ) {
			delete_post_meta( $id, '_lmgt_tone' );
			update_post_meta( $id, '_lmgt_tone_done', array( 'hash' => self::hash( $post ), 'at' => current_time( 'mysql', true ), 'found' => 0, 'put' => 0 ) );
			return 'Tone: OK. Nothing found against the rules.';
		}
		update_post_meta( $id, '_lmgt_tone', wp_slash( array( 'list' => $list, 'at' => current_time( 'mysql', true ) ) ) );
		return 'Tone: ' . count( $list ) . ' passage(s) to look at. Read them in the Tone step, untick what you do not want, then Accept.';
	}

	public static function handle_propose() {
		$id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
		check_admin_referer( 'lmgt_tone_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$post = get_post( $id );
		if ( ! $post ) wp_die( 'Not found.' );
		if ( self::skipped( $post ) ) self::back( $id, 'Tone leaves service pages alone (Translator → Settings → Tone).' );
		$r = self::propose( $post );
		self::back( $id, is_wp_error( $r ) ? 'Tone not checked: ' . $r->get_error_message() : $r );
	}

	// ---- Accept or reject --------------------------------------------------------------

	/**
	 * The first place $find stands in running text (not inside a tag), replaced by $with (plain text).
	 * Tries the text as stored, then with HTML entities read as characters. null when not found in one piece.
	 */
	public static function replace_once( $html, $find, $with ) {
		$parts = preg_split( '/(<[^>]+>)/', (string) $html, -1, PREG_SPLIT_DELIM_CAPTURE );
		$safe  = esc_html( $with );
		foreach ( $parts as $i => $p ) {
			if ( $p === '' || $p[0] === '<' ) continue;
			$at = strpos( $p, $find );
			if ( $at !== false ) {
				$parts[ $i ] = substr( $p, 0, $at ) . $safe . substr( $p, $at + strlen( $find ) );
				return implode( '', $parts );
			}
			$e = esc_html( $find );
			if ( $e !== $find && ( $at = strpos( $p, $e ) ) !== false ) {
				$parts[ $i ] = substr( $p, 0, $at ) . $safe . substr( $p, $at + strlen( $e ) );
				return implode( '', $parts );
			}
			$dec = html_entity_decode( $p, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
			if ( $dec !== $p && ( $at = strpos( $dec, $find ) ) !== false ) {
				$parts[ $i ] = esc_html( substr( $dec, 0, $at ) ) . $safe . esc_html( substr( $dec, $at + strlen( $find ) ) );
				return implode( '', $parts );
			}
		}
		return null;
	}

	public static function handle_apply() {
		$id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
		check_admin_referer( 'lmgt_tone_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$p    = get_post_meta( $id, '_lmgt_tone', true );
		$post = get_post( $id );
		$all  = is_array( $p ) && ! empty( $p['list'] ) ? $p['list'] : array();
		delete_post_meta( $id, '_lmgt_tone' );
		if ( ! isset( $_GET['do'] ) || $_GET['do'] !== 'apply' || ! $all ) {
			update_post_meta( $id, '_lmgt_tone_done', array( 'hash' => self::hash( $post ), 'at' => current_time( 'mysql', true ), 'found' => count( $all ), 'put' => 0 ) );
			self::back( $id, 'Tone: proposals rejected. The text is unchanged.' );
		}
		$pick = array_keys( $all );
		if ( isset( $_GET['only'] ) ) $pick = array_map( 'intval', array_filter( explode( '-', (string) $_GET['only'] ), 'is_numeric' ) );
		// Built again on the text as it is now, passage by passage: what is no longer there is left alone.
		$html = (string) $post->post_content;
		$put  = 0;
		$gone = 0;
		foreach ( $pick as $i ) {
			if ( ! isset( $all[ $i ] ) || $all[ $i ]['rewrite'] === '' || ! empty( $all[ $i ]['hand'] ) ) continue;
			$new = self::replace_once( $html, $all[ $i ]['passage'], $all[ $i ]['rewrite'] );
			if ( $new === null ) { $gone++; continue; }
			$html = $new;
			$put++;
		}
		if ( ! $put ) {
			update_post_meta( $id, '_lmgt_tone_done', array( 'hash' => self::hash( $post ), 'at' => current_time( 'mysql', true ), 'found' => count( $all ), 'put' => 0 ) );
			self::back( $id, $gone ? 'Tone: nothing put in. The ticked passages are no longer in the text (it was edited since). Check the tone again.' : 'Tone: nothing ticked, so nothing put in. The text is unchanged.' );
		}
		$r = LMGT_Store::update_content( $id, array( 'post_content' => $html ), true );
		if ( is_wp_error( $r ) || ! $r ) self::back( $id, 'Tone: the rewrites could not be saved: ' . ( is_wp_error( $r ) ? $r->get_error_message() : 'unknown error' ) . '. The text is unchanged.' );
		clean_post_cache( $id );
		update_post_meta( $id, '_lmgt_tone_done', array( 'hash' => self::hash( get_post( $id ) ), 'at' => current_time( 'mysql', true ), 'found' => count( $all ), 'put' => $put ) );
		self::back( $id, 'Tone: ' . $put . ' rewrite(s) put in the text' . ( $gone ? ', ' . $gone . ' left out (no longer in the text)' : '' ) . '. The previous version is under Revisions.' );
	}

	private static function back( $id, $msg ) {
		wp_safe_redirect( add_query_arg( 'lmgt_smsg', rawurlencode( $msg ), get_edit_post_link( $id, 'url' ) ) );
		exit;
	}
}
