<?php
/**
 * Plugin Name: LMG Translator
 * Description: Translates the site's own articles into other languages as separate, reviewable pages with their own addresses (/sv/, /no/, /de/ …) and correct hreflang, canonical and page language. Claude writes and translates; a back-translation into the source language checks meaning and numbers. On traveltalk.dk: Danish with Swedish, Norwegian and Finnish (Traveltalk Nordic); English on traveltalk.travel.
 * Version:     2.17.7
 * Author:      Leisure Media Group Ltd
 * License:     Proprietary — © Leisure Media Group Ltd. All rights reserved.
 *
 * Replaces "Traveltalk AI Translator" (6.1.0). Deactivate that plugin first: it
 * printed nine ?lang= hreflang tags on every page, including pages that were
 * never translated, and it saved the Danish original as the "translation"
 * whenever both engines failed — which is where the mixed languages came from.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'LMGT_VERSION', '2.17.7' );
define( 'LMGT_DIR', plugin_dir_path( __FILE__ ) );
define( 'LMGT_CPT', 'lmgt_translation' );

require_once LMGT_DIR . 'includes/class-lmgt-parts.php';
require_once LMGT_DIR . 'includes/class-lmgt-langs.php';
require_once LMGT_DIR . 'includes/class-lmgt-text.php';
require_once LMGT_DIR . 'includes/class-lmgt-engines.php';
require_once LMGT_DIR . 'includes/class-lmgt-store.php';
require_once LMGT_DIR . 'includes/class-lmgt-jobs.php';
require_once LMGT_DIR . 'includes/class-lmgt-front.php';
require_once LMGT_DIR . 'includes/class-lmgt-langfront.php';
require_once LMGT_DIR . 'includes/class-lmgt-admin.php';
require_once LMGT_DIR . 'includes/class-lmgt-checker.php';
require_once LMGT_DIR . 'includes/class-lmgt-legacy.php';
require_once LMGT_DIR . 'includes/class-lmgt-bridge.php';
require_once LMGT_DIR . 'includes/class-lmgt-upgrade.php';
require_once LMGT_DIR . 'includes/class-lmgt-meter.php';
require_once LMGT_DIR . 'includes/class-lmgt-improve.php';
require_once LMGT_DIR . 'includes/class-lmgt-sync.php';
require_once LMGT_DIR . 'includes/class-lmgt-notes.php';
require_once LMGT_DIR . 'includes/class-lmgt-media.php';
require_once LMGT_DIR . 'includes/class-lmgt-alts.php';
require_once LMGT_DIR . 'includes/class-lmgt-pictures.php';
require_once LMGT_DIR . 'includes/class-lmgt-finder.php';
require_once LMGT_DIR . 'includes/class-lmgt-structure.php';
require_once LMGT_DIR . 'includes/class-lmgt-top.php';
require_once LMGT_DIR . 'includes/class-lmgt-trail.php';
require_once LMGT_DIR . 'includes/class-lmgt-localpics.php';
require_once LMGT_DIR . 'includes/class-lmgt-migrate.php';
require_once LMGT_DIR . 'includes/class-lmgt-catchup.php';
require_once LMGT_DIR . 'includes/class-lmgt-auto.php';
require_once LMGT_DIR . 'includes/class-lmgt-plan.php';
require_once LMGT_DIR . 'includes/class-lmgt-headfix.php';
require_once LMGT_DIR . 'includes/class-lmgt-clusters.php';
require_once LMGT_DIR . 'includes/class-lmgt-steps.php';
require_once LMGT_DIR . 'includes/class-lmgt-outreach.php';
require_once LMGT_DIR . 'includes/class-lmgt-oneplace.php';
require_once LMGT_DIR . 'includes/class-lmgt-stamps.php';
require_once LMGT_DIR . 'includes/class-lmgt-more.php';
require_once LMGT_DIR . 'includes/class-lmgt-worklist.php';
require_once LMGT_DIR . 'includes/class-lmgt-boxes.php';
require_once LMGT_DIR . 'includes/class-lmgt-nordic.php';

/**
 * The old plugin and this one must never run together: both would answer the
 * same pages with different hreflang sets, and Google drops a set it cannot
 * reconcile. Detected by its function names, which are unique to it.
 */
function lmgt_legacy_active() {
	return function_exists( 'tt_translate_text' ) || function_exists( 'tt_process_post_translations_immediately' );
}

LMGT_Store::boot();
LMGT_Front::boot();
LMGT_LangFront::boot();
LMGT_Admin::boot();
LMGT_Jobs::boot();
LMGT_Checker::boot();
if ( LMGT_Parts::on( 'legacy' ) ) LMGT_Legacy::boot();
LMGT_Bridge::boot();
LMGT_Upgrade::boot();
if ( LMGT_Parts::on( 'meter' ) ) LMGT_Meter::boot();
if ( LMGT_Parts::on( 'improve' ) ) LMGT_Improve::boot();
LMGT_Sync::boot();
LMGT_Notes::boot();
if ( LMGT_Parts::on( 'media' ) ) LMGT_Media::boot();
if ( LMGT_Parts::on( 'media' ) ) LMGT_Alts::boot();
if ( LMGT_Parts::on( 'pictures' ) ) LMGT_Pictures::boot();
if ( LMGT_Parts::on( 'finder' ) ) LMGT_Finder::boot();
if ( LMGT_Parts::on( 'trail' ) ) LMGT_Trail::boot();
if ( LMGT_Parts::on( 'localpics' ) ) LMGT_LocalPics::boot();
LMGT_Migrate::boot();
LMGT_Catchup::boot();
LMGT_Auto::boot();
LMGT_Headfix::boot();
if ( LMGT_Parts::on( 'plan' ) ) LMGT_Plan::boot();
if ( LMGT_Parts::on( 'readmore' ) ) LMGT_Structure::boot();
if ( LMGT_Parts::on( 'top' ) ) LMGT_Top::boot();
if ( LMGT_Parts::on( 'clusters' ) ) LMGT_Clusters::boot();
if ( LMGT_Parts::on( 'steps' ) ) LMGT_Steps::boot();
if ( LMGT_Parts::on( 'outreach' ) ) LMGT_Outreach::boot();
if ( LMGT_Parts::on( 'oneplace' ) ) LMGT_OnePlace::boot();
if ( LMGT_Parts::on( 'steps' ) ) LMGT_Stamps::boot();
if ( LMGT_Parts::on( 'more' ) ) LMGT_More::boot();
if ( LMGT_Parts::on( 'worklist' ) ) LMGT_Worklist::boot();
if ( LMGT_Parts::on( 'boxes' ) ) LMGT_Boxes::boot();
LMGT_Nordic::boot();
LMGT_Parts::boot();

register_activation_hook( __FILE__, function () {
	LMGT_Store::register_type();
	flush_rewrite_rules( false );
} );
