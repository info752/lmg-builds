<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.2.16: the rest of the catch-up screen (brief 4.19), on .dk.
 *
 * Overview: the translations on .travel counted by the version that made them,
 * and what later versions say they need (the "Older translations" heading of
 * each release note), each pointing to its section below.
 *
 * Focus keyword on destination guides (2.2.13 changed it for new ones only):
 * Claude proposes the destination's name in the translation's language from
 * the Danish original; a person ticks and applies. Only the keyword changes;
 * meta description and address stay as they are, and the result names the
 * pages whose meta description does not contain the new keyword.
 */
class LMGT_Catchup {

	const PROPOSALS = 'lmgt_kw_proposals';

	/** Later releases whose catch-up applies to translations made before them; the anchor is its section below. */
	const NEEDS = array(
		array( '2.2.0', 'Featured-image texts in their language', 'Featured-image texts' ),
		array( '2.2.0', 'The glossary: only by re-translating (Re-translate on the translation, which costs review time)', '' ),
		array( '2.2.7', 'Related-articles grid with pictures', 'Related articles' ),
		array( '2.2.13', 'The country name as focus keyword on destination guides', 'Focus keyword on destination guides' ),
		array( '2.2.16', 'Breadcrumbs in their language', 'Breadcrumbs' ),
		array( '2.2.19', 'Focus keyword proposals in each page\'s own language (ask again)', 'Focus keyword on destination guides' ),
		array( '2.2.20', 'Pictures saved on traveltalk.travel (on traveltalk.travel: Translator → Save pictures)', '' ),
	);

	public static function boot() {
		if ( ! LMGT_Bridge::on() ) return;
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		if ( ! LMGT_Bridge::is_source() ) return;
		add_action( 'lmgt_catchup_top', array( __CLASS__, 'overview' ), 1 );
		add_action( 'lmgt_catchup_sections', array( __CLASS__, 'keyword_section' ), 20 );
		add_action( 'wp_ajax_lmgt_kw_propose', array( __CLASS__, 'ajax_propose' ) );
		add_action( 'admin_post_lmgt_kw_apply', array( __CLASS__, 'handle_apply' ) );
	}

	public static function routes() {
		if ( ! LMGT_Bridge::is_target() ) return;
		$can = function () { return current_user_can( 'edit_others_posts' ); };
		register_rest_route( LMGT_Bridge::NS, '/made', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_made' ), 'permission_callback' => $can ) );
		register_rest_route( LMGT_Bridge::NS, '/keyword', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_keyword' ), 'permission_callback' => $can ) );
	}

	// ---- .travel ----------------------------------------------------------------------

	/** Target: every .dk translation here: [id, sid, lang, made, status, guide, keyword, title, url]. */
	public static function rest_made() {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT p.ID, p.post_status, s.meta_value AS sid FROM {$wpdb->posts} p
			JOIN {$wpdb->postmeta} s ON s.post_id = p.ID AND s.meta_key = '_lmgt_remote_source'
			WHERE p.post_type = %s AND p.post_status IN ('publish','draft','pending','future','private')", LMGT_CPT ) );
		update_meta_cache( 'post', wp_list_pluck( $rows, 'ID' ) );
		$out = array();
		foreach ( $rows as $r ) {
			if ( get_post_meta( $r->ID, '_lmgt_adopted', true ) ) continue;
			$out[] = array(
				'id'      => (int) $r->ID,
				'sid'     => (int) $r->sid,
				'lang'    => (string) get_post_meta( $r->ID, '_lmgt_lang', true ),
				'made'    => (string) get_post_meta( $r->ID, '_lmgt_made_with', true ),
				'status'  => $r->post_status,
				'guide'   => get_post_meta( $r->ID, '_lmgt_source_type', true ) === 'page',
				'keyword' => (string) get_post_meta( $r->ID, 'rank_math_focus_keyword', true ),
				'title'   => html_entity_decode( get_the_title( $r->ID ), ENT_QUOTES, 'UTF-8' ),
				'url'     => get_permalink( $r->ID ),
			);
		}
		return $out;
	}

	/** Target: a new focus keyword, first in Rank Math's list; the others stay. Says whether the meta description holds it. */
	public static function rest_keyword( WP_REST_Request $req ) {
		$p  = $req->get_json_params();
		$id = isset( $p['id'] ) ? (int) $p['id'] : 0;
		$kw = isset( $p['keyword'] ) ? trim( sanitize_text_field( $p['keyword'] ) ) : '';
		if ( get_post_type( $id ) !== LMGT_CPT || $kw === '' ) return new WP_Error( 'lmgt_bad', 'No such translation, or no keyword.', array( 'status' => 400 ) );
		$old  = array_filter( array_map( 'trim', explode( ',', (string) get_post_meta( $id, 'rank_math_focus_keyword', true ) ) ), 'strlen' );
		$rest = array_filter( $old, function ( $k ) use ( $kw ) { return mb_strtolower( $k ) !== mb_strtolower( $kw ); } );
		update_post_meta( $id, 'rank_math_focus_keyword', implode( ',', array_merge( array( $kw ), array_slice( array_values( $rest ), 0, 4 ) ) ) );
		do_action( 'litespeed_purge_post', $id );
		$meta = (string) get_post_meta( $id, 'rank_math_description', true );
		return array( 'id' => $id, 'meta_has_keyword' => $meta !== '' && mb_stripos( $meta, $kw ) !== false );
	}

	// ---- .dk: overview -----------------------------------------------------------------

	private static function made() {
		static $made = null;
		if ( $made === null ) $made = LMGT_Bridge::call( 'GET', '/made', array(), false );
		return $made;
	}

	/** "before 2.2.2" and empty: made by any earlier version, so everything later may apply. */
	private static function version( $made ) {
		return strpos( (string) $made, 'before' ) !== 0 && preg_match( '/(\d+\.\d+\.\d+)/', (string) $made, $m ) ? $m[1] : '0';
	}

	public static function overview() {
		$made = self::made();
		echo '<h2>Overview</h2>';
		if ( is_wp_error( $made ) ) {
			echo '<p>traveltalk.travel could not be asked: ' . esc_html( $made->get_error_message() ) . '</p>';
			return;
		}
		$by = array();
		foreach ( $made as $t ) {
			$v = $t['made'] !== '' ? $t['made'] : 'before 2.2.2';
			if ( ! isset( $by[ $v ] ) ) $by[ $v ] = array();
			$by[ $v ][ $t['lang'] ] = ( isset( $by[ $v ][ $t['lang'] ] ) ? $by[ $v ][ $t['lang'] ] : 0 ) + 1;
		}
		uksort( $by, function ( $a, $b ) { return version_compare( self::version( $a ), self::version( $b ) ) ?: strcmp( $a, $b ); } );
		echo '<p><strong>' . count( $made ) . '</strong> translation(s) from traveltalk.dk on traveltalk.travel, by the Translator version that made them:</p>';
		echo '<table class="widefat striped" style="max-width:900px"><thead><tr><th>Made with</th><th>Translations</th><th>What later versions may add (each section below lists the actual gaps)</th></tr></thead><tbody>';
		foreach ( $by as $v => $langs ) {
			$need = array();
			foreach ( self::NEEDS as $n ) {
				if ( version_compare( self::version( $v ), $n[0], '<' ) ) $need[] = esc_html( $n[1] ) . ( $n[2] ? ' – <em>' . esc_html( $n[2] ) . '</em>' : '' );
			}
			$parts = array();
			foreach ( $langs as $l => $c ) $parts[] = $c . ' ' . esc_html( $l );
			echo '<tr><td>' . esc_html( $v ) . '</td><td>' . implode( ', ', $parts ) . '</td><td>' . ( $need ? implode( '<br>', $need ) : 'Nothing' ) . '</td></tr>';
		}
		echo '</tbody></table><p class="description">Each section below brings older translations up to date without touching the article text, so no new review is needed. Order: one section at a time, top to bottom.</p>';
	}

	// ---- .dk: focus keyword on destination guides -----------------------------------------

	public static function keyword_section() {
		echo '<h2>Focus keyword on destination guides</h2>';
		$made = self::made();
		if ( is_wp_error( $made ) ) return;
		$guides = array_values( array_filter( $made, function ( $t ) { return $t['guide']; } ) );
		echo '<p><strong>' . count( $guides ) . '</strong> destination guide(s) on traveltalk.travel (translations of .dk pages). Since 2.2.13 a new one gets the destination\'s name alone as focus keyword (Österreich, Autriche, Austria); older ones kept theirs. "Propose" asks Claude for the name in each language, one short call each; nothing changes until you tick and apply.</p>';
		if ( ! $guides ) return;
		$nonce = wp_create_nonce( 'lmgt_kw_propose' );
		echo '<p><button class="button" id="lmgt-kw">Propose keywords</button> <span id="lmgt-kw-st"></span></p>';
		echo "<script>(function(){var b=document.getElementById('lmgt-kw'),s=document.getElementById('lmgt-kw-st');"
			. "function go(d){var f=new FormData();f.append('action','lmgt_kw_propose');f.append('do',d);f.append('_ajax_nonce','" . esc_js( $nonce ) . "');"
			. "fetch(ajaxurl,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){"
			. "if(!r.success){s.textContent='Stopped: '+r.data;b.disabled=false;return}s.textContent=r.data.left+' left';"
			. "if(r.data.left>0)go('step');else location.reload()}).catch(function(e){s.textContent='Stopped: '+e;b.disabled=false})}"
			. "b.addEventListener('click',function(){b.disabled=true;go('start')})})();</script>";
		$props = (array) get_option( self::PROPOSALS, array() );
		$rows  = array_filter( $props, function ( $p ) { return isset( $p['proposed'] ); } );
		if ( ! $rows ) return;
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="lmgt_kw_apply">' . wp_nonce_field( 'lmgt_kw_apply', '_wpnonce', true, false );
		echo '<table class="widefat striped" style="max-width:900px"><thead><tr><th></th><th>Guide</th><th>Language</th><th>Keyword now</th><th>Proposed</th></tr></thead><tbody>';
		foreach ( $rows as $k => $p ) {
			$same = mb_strtolower( trim( explode( ',', $p['keyword'] )[0] ) ) === mb_strtolower( $p['proposed'] );
			$sure = self::in_title( $p );
			echo '<tr><td><input type="checkbox" name="kw[' . esc_attr( $k ) . ']" value="1"' . ( $same || $p['proposed'] === '' ? ' disabled' : ( $sure ? ' checked' : '' ) ) . '></td>'
				. '<td><a href="' . esc_url( $p['url'] ) . '" target="_blank">' . esc_html( $p['title'] ) . '</a></td><td>' . esc_html( $p['lang'] ) . '</td>'
				. '<td>' . esc_html( $p['keyword'] !== '' ? $p['keyword'] : '(none)' ) . '</td>'
				. '<td>' . ( $p['proposed'] === '' ? '<em>no proposal</em>' : '<input type="text" name="kwv[' . esc_attr( $k ) . ']" value="' . esc_attr( $p['proposed'] ) . '"' . ( $same ? ' disabled' : '' ) . '>' . ( $same ? ' already set' : ( $sure ? '' : ' <span style="color:#b32d2e">not in the page\'s title – check</span>' ) ) ) . '</td></tr>';
		}
		echo '</tbody></table><p><button class="button button-primary">Apply ticked keywords</button></p></form>';
	}

	/** Source: start (list the guides) or one step (four proposals). */
	public static function ajax_propose() {
		check_ajax_referer( 'lmgt_kw_propose' );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_send_json_error( 'Not allowed.' );
		if ( isset( $_POST['do'] ) && $_POST['do'] === 'start' ) {
			$made = self::made();
			if ( is_wp_error( $made ) ) wp_send_json_error( $made->get_error_message() );
			$props = array();
			foreach ( $made as $t ) {
				if ( $t['guide'] ) $props[ $t['sid'] . '-' . $t['lang'] ] = $t;
			}
			update_option( self::PROPOSALS, $props, false );
			wp_send_json_success( array( 'left' => count( $props ) ) );
		}
		$props = (array) get_option( self::PROPOSALS, array() );
		$done  = 0;
		foreach ( $props as $k => $p ) {
			if ( isset( $p['proposed'] ) ) continue;
			if ( $done++ >= 4 ) break;
			$props[ $k ]['proposed'] = self::destination_name( $p );
		}
		update_option( self::PROPOSALS, $props, false );
		wp_send_json_success( array( 'left' => count( array_filter( $props, function ( $p ) { return ! isset( $p['proposed'] ); } ) ) ) );
	}

	/**
	 * 2.2.19: the name is asked from the translation's own title, in its language. Shown only
	 * the Danish text, the model often answered with the Danish name (Østrig for Norwegian,
	 * Ungarn for English: G, 31 Oct). A page about no single place gets no proposal.
	 */
	private static function destination_name( array $p ) {
		$l  = LMGT_Langs::get( $p['lang'] );
		$da = html_entity_decode( get_the_title( (int) $p['sid'] ), ENT_QUOTES, 'UTF-8' );
		if ( ! $l || ! LMGT_Engines::ai_available() ) return '';
		$prompt = "A page on a travel website, written in {$l['name']}, has the title: «{$p['title']}». It is a translation of the Danish page «{$da}».\n"
			. "- If the page is a guide to one destination (a continent, country, region, island or city): keyword = that destination's name exactly as {$l['name']} speakers write it, with nothing added (no \"travel\", no \"guide\"). Usually it is the name as the title writes it. Never the Danish name, unless {$l['name']} writes it the same way.\n"
			. "- If the page is about no single destination (a theme, a list, the website itself): keyword = an empty string.\n"
			. 'Return JSON: {"keyword":"…"}.';
		$r  = LMGT_Engines::ai_json( $prompt, LMGT_Engines::schema_strings( array( 'keyword' ) ) );
		$kw = ! is_wp_error( $r ) && ! empty( $r['keyword'] ) ? trim( sanitize_text_field( $r['keyword'] ) ) : '';
		return mb_strlen( $kw ) <= 60 ? $kw : '';
	}

	/** A proposal the page's own title does not contain is shown unticked, to be checked. */
	private static function in_title( array $p ) {
		return $p['proposed'] !== '' && mb_stripos( $p['title'], $p['proposed'] ) !== false;
	}

	public static function handle_apply() {
		if ( ! current_user_can( 'edit_others_posts' ) || ! check_admin_referer( 'lmgt_kw_apply' ) ) wp_die( 'Not allowed.' );
		$props = (array) get_option( self::PROPOSALS, array() );
		$set   = 0;
		$check = array();
		$fail  = array();
		foreach ( array_keys( (array) ( isset( $_POST['kw'] ) ? $_POST['kw'] : array() ) ) as $k ) {
			if ( ! isset( $props[ $k ] ) ) continue;
			$kw = isset( $_POST['kwv'][ $k ] ) ? sanitize_text_field( wp_unslash( $_POST['kwv'][ $k ] ) ) : '';
			if ( $kw === '' ) continue;
			$r = LMGT_Bridge::call( 'POST', '/keyword', array( 'id' => (int) $props[ $k ]['id'], 'keyword' => $kw ), false );
			if ( is_wp_error( $r ) ) {
				$fail[] = $props[ $k ]['title'];
				continue;
			}
			$set++;
			$props[ $k ]['keyword'] = $kw;
			if ( empty( $r['meta_has_keyword'] ) ) $check[] = $props[ $k ]['title'] . ' (' . $props[ $k ]['lang'] . ')';
		}
		update_option( self::PROPOSALS, $props, false );
		$msg = $set . ' keyword(s) set.' . ( $check ? ' Meta description without the new keyword (use Set SEO there, or edit it): ' . implode( '; ', $check ) . '.' : '' ) . ( $fail ? ' Failed: ' . implode( '; ', $fail ) . '.' : '' );
		LMGT_Bridge::log( 'catch-up: ' . $msg );
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $msg ), admin_url( 'admin.php?page=lmgt-catchup' ) ) );
		exit;
	}
}
