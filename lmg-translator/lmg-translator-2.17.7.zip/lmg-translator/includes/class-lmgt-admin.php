<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * wp-admin: Translator menu (queue, settings, cleanup), the box on every
 * original, the review box on every translation, bulk actions and columns.
 */
class LMGT_Admin {

	public static function boot() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notices' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'boxes' ) );
		add_action( 'save_post_' . LMGT_CPT, array( __CLASS__, 'save_review' ) );
		add_action( 'save_post', array( __CLASS__, 'save_as_written' ), 10, 2 );
		add_action( 'admin_post_lmgt_queue', array( __CLASS__, 'handle_queue' ) );
		add_action( 'admin_post_lmgt_queue_ids', array( __CLASS__, 'handle_queue_ids' ) );
		add_action( 'admin_post_lmgt_job', array( __CLASS__, 'handle_job' ) );
		add_action( 'admin_post_lmgt_apply', array( __CLASS__, 'handle_apply' ) );
		add_action( 'admin_post_lmgt_discard', array( __CLASS__, 'handle_discard' ) );
		add_action( 'admin_post_lmgt_fix', array( __CLASS__, 'handle_fix' ) );
		add_action( 'admin_post_lmgt_numbers_ok', array( __CLASS__, 'handle_numbers_ok' ) );
		add_action( 'admin_post_lmgt_suggest', array( __CLASS__, 'handle_suggest' ) );
		add_action( 'admin_post_lmgt_gaps', array( __CLASS__, 'handle_gaps' ) );
		add_action( 'admin_post_lmgt_en_extra', array( __CLASS__, 'handle_en_extra' ) );
		add_action( 'admin_post_lmgt_gap_draft', array( __CLASS__, 'handle_gap_draft' ) );
		add_action( 'admin_post_lmgt_seo', array( __CLASS__, 'handle_seo' ) );
		add_action( 'admin_post_lmgt_gap_insert', array( __CLASS__, 'handle_gap_insert' ) );
		add_action( 'admin_post_lmgt_settings', array( __CLASS__, 'handle_settings' ) );
		add_action( 'admin_post_lmgt_cleanup', array( __CLASS__, 'handle_cleanup' ) );
		add_action( 'admin_post_lmgt_tag', array( __CLASS__, 'handle_tag' ) );
		add_action( 'wp_ajax_lmgt_reviewed', array( __CLASS__, 'ajax_reviewed' ) );
		foreach ( array( 'post', 'page' ) as $t ) {
			add_filter( 'bulk_actions-edit-' . $t, array( __CLASS__, 'bulk_actions' ) );
			add_filter( 'handle_bulk_actions-edit-' . $t, array( __CLASS__, 'bulk_handle' ), 10, 3 );
			add_filter( 'manage_' . $t . 's_columns', function ( $c ) { $c['lmgt_words'] = 'Words'; $c['lmgt_langs'] = 'Translations'; $c['lmgt_id'] = 'ID'; return $c; } );
			add_action( 'manage_' . $t . 's_custom_column', array( __CLASS__, 'words_column' ), 10, 2 );
		}
		add_action( 'admin_init', function () {
			foreach ( LMGT_Store::extra() as $t ) {
				add_filter( 'bulk_actions-edit-' . $t, array( __CLASS__, 'bulk_actions' ) );
				add_filter( 'handle_bulk_actions-edit-' . $t, array( __CLASS__, 'bulk_handle' ), 10, 3 );
			}
		} );
		add_filter( 'manage_' . LMGT_CPT . '_posts_columns', function ( $c ) { $c = self::columns( $c ); $c['lmgt_id'] = 'ID'; return $c; } );
		// The ID itself is printed by words_column(): WordPress runs the posts hook for translations too (2.2.17: it showed twice).
		add_action( 'manage_' . LMGT_CPT . '_posts_custom_column', array( __CLASS__, 'column' ), 10, 2 );
		// 2.2.22: the Translations list already had a Words column (WordPress adds the posts columns to it); it now sorts, shortest first, to work the thin ones.
		add_filter( 'manage_edit-' . LMGT_CPT . '_sortable_columns', function ( $c ) { $c['lmgt_words'] = 'lmgt_words'; return $c; } );
		add_action( 'pre_get_posts', function ( $q ) {
			if ( ! is_admin() || ! $q->is_main_query() || $q->get( 'post_type' ) !== LMGT_CPT || $q->get( 'orderby' ) !== 'lmgt_words' ) return;
			$q->set( 'meta_key', '_lmgt_words' );
			$q->set( 'orderby', 'meta_value_num' );
		} );
		add_action( 'save_post_' . LMGT_CPT, function ( $id ) { if ( ! wp_is_post_revision( $id ) ) update_post_meta( $id, '_lmgt_words', LMGT_Store::words( $id ) ); }, 20 );
		add_action( 'admin_footer', array( __CLASS__, 'run_indicator' ) );
		add_action( 'admin_footer', array( __CLASS__, 'busy_and_done' ) ); // 2.6.4
	}

	/**
	 * 2.2.9: a spinner beside every run button on the Translator pages while it
	 * works (G: you could not see whether it was running). It stops when the
	 * status says Finished or Stopped, or the button is enabled again; the
	 * Alt texts and Image texts pages then reload to show their proposals.
	 */
	public static function run_indicator() {
		if ( empty( $_GET['page'] ) || strpos( (string) $_GET['page'], 'lmgt' ) !== 0 ) return;
		$runs = array( 'lmgt-al' => array( 'lmgt-al-st', 1 ), 'lmgt-im' => array( 'lmgt-im-st', 1 ), 'lmgt-cu' => array( 'lmgt-cu-left', 0 ), 'lmgt-as' => array( 'lmgt-as-st', 0 ), 'lmgt-rel' => array( 'lmgt-rel-st', 0 ) );
		echo "<script>(function(){var R=" . wp_json_encode( $runs ) . ";Object.keys(R).forEach(function(id){var b=document.getElementById(id);if(!b)return;"
			. "var st=document.getElementById(R[id][0]),sp=document.createElement('span');sp.className='spinner';sp.style.cssText='float:none;margin:0 4px 0 8px;vertical-align:middle';b.parentNode.insertBefore(sp,b.nextSibling);"
			. "var on=false,stop=function(){on=false;sp.classList.remove('is-active')};"
			. "b.addEventListener('click',function(){on=true;sp.classList.add('is-active');if(st&&!st.textContent.trim())st.textContent='Working…'});"
			. "new MutationObserver(function(){if(on&&!b.disabled)stop()}).observe(b,{attributes:true,attributeFilter:['disabled']});"
			. "if(st)new MutationObserver(function(){var t=st.textContent;if(/Finished|finished|Stopped|Nothing left/.test(t)){stop();if(R[id][1]&&/Finished|finished/.test(t))setTimeout(function(){location.reload()},1200)}}).observe(st,{childList:true,characterData:true,subtree:true});"
			. "})})();</script>";
	}

	/**
	 * 2.6.4 (G, 8 Nov: "is something done or spinning? Nothing happens while you wait, so you
	 * try again"). Every Translator button that works on the server now shows a bar at the top:
	 * what it is doing, roughly how long, and not to click again; other buttons are locked until
	 * the page comes back. When it comes back, the result is shown in a green bar that stays
	 * until closed, also in the block editor, which hides ordinary notices.
	 */
	public static function busy_and_done() {
		$done = isset( $_GET['lmgt_msg'] ) ? (string) wp_unslash( $_GET['lmgt_msg'] ) : ( isset( $_GET['lmgt_smsg'] ) ? (string) wp_unslash( $_GET['lmgt_smsg'] ) : '' );
		echo '<style>#lmgt-busy,#lmgt-done{position:fixed;left:50%;transform:translateX(-50%);top:40px;z-index:100000;max-width:720px;padding:12px 18px;border-radius:6px;font-size:14px;box-shadow:0 4px 18px rgba(0,0,0,.2)}#lmgt-busy{background:#1d2327;color:#fff}#lmgt-done{background:#edfaef;border:2px solid #00a32a;color:#1d2327}#lmgt-done button{margin-left:12px}.lmgt-locked{pointer-events:none;opacity:.5}</style>';
		if ( $done !== '' ) {
			echo '<div id="lmgt-done"><strong>Done:</strong> ' . esc_html( $done ) . ' <button type="button" class="button" onclick="this.parentNode.remove()">Close</button></div>';
		}
		echo "<script>(function(){function busy(label){if(document.getElementById('lmgt-busy'))return false;var d=document.createElement('div');d.id='lmgt-busy';d.innerHTML='<span class=\"spinner is-active\" style=\"float:none;margin:0 8px 0 0;vertical-align:middle\"></span><strong>Working: '+label.replace(/[<>&]/g,'')+'</strong><br>This usually takes 20–60 seconds. Do not click again; the page reloads by itself and shows the result.';document.body.appendChild(d);document.querySelectorAll('a[href*=\"action=lmgt_\"],button[form^=\"lmgt-\"],form[action*=\"admin-post.php\"] button').forEach(function(b){b.classList.add('lmgt-locked')});var t=0;setInterval(function(){t+=5;var s=d.querySelector('strong');if(t===90)d.insertAdjacentHTML('beforeend','<br><em>Still working. Long texts can take up to two minutes.</em>')},5000);return true}"
			. "function dirty(){try{if(window.wp&&wp.data&&wp.data.select('core/editor'))return wp.data.select('core/editor').isEditedPostDirty()}catch(x){}try{if(window.tinymce&&tinymce.activeEditor&&tinymce.activeEditor.isDirty())return true}catch(x){}return !!window.lmgtDirty}function saveThen(go,label){try{if(window.wp&&wp.data&&wp.data.select('core/editor')){busy('Saving your edits first, then: '+label);wp.data.dispatch('core/editor').savePost();var w=setInterval(function(){var ed=wp.data.select('core/editor');if(!ed.isSavingPost()&&!ed.isAutosavingPost()){clearInterval(w);go()}},500);return}}catch(x){}var sv=document.getElementById('save-post')||document.getElementById('publish');if(sv&&go.lmgtHref){try{sessionStorage.setItem('lmgtAfterSave',go.lmgtHref)}catch(x){}window.lmgtDirty=false;busy('Saving your edits first (keyword, text, settings), then: '+label);sv.click();return}if(confirm('You have unsaved changes (text, categories, tags, SEO keyword or other settings).\\n\\nCancel: stay, press Update (or Save draft), then click the Translator button again.\\nOK: go on now; your unsaved changes are lost.')){window.lmgtDirty=false;try{if(window.tinymce&&tinymce.activeEditor)tinymce.activeEditor.setDirty(false)}catch(x){}go()}}document.addEventListener('input',function(e){var t=e.target;if(!t.closest||!t.closest('#post'))return;if(t.closest('#lmgt_steps,[id^=lmgt_],.lmgt-box-admin'))return;window.lmgtDirty=true},true);document.addEventListener('keydown',function(e){var t=e.target;if(!t.closest||!t.closest('#post'))return;if(t.closest('#lmgt_steps,[id^=lmgt_],.lmgt-box-admin'))return;if(t.isContentEditable||/^(INPUT|TEXTAREA)$/.test(t.tagName))window.lmgtDirty=true},true);try{var pend=sessionStorage.getItem('lmgtAfterSave');if(pend){sessionStorage.removeItem('lmgtAfterSave');var pid=(location.search.match(/[?&]post=(\\d+)/)||[])[1];if(pid&&pend.indexOf('post='+pid)>-1&&/[?&]message=\\d/.test(location.search)){busy('Saved. Now running the Translator step');location.href=pend}}}catch(x){}document.addEventListener('change',function(e){var t=e.target;if(!t.closest||!t.closest('#post'))return;if(t.closest('#lmgt_steps,[id^=lmgt_],.lmgt-box-admin'))return;if(/^(post_category|tax_input|newcategory|tags_input|post_format|menu_order|parent_id|page_template|comment_status|ping_status|sticky)/.test(t.name||'')||(t.type==='checkbox'&&/categor|tag/.test((t.closest('.postbox')||{}).id||'')))window.lmgtDirty=true},true);document.addEventListener('click',function(e){var a=e.target.closest('a[href*=\"admin-post.php?action=lmgt_\"]');if(!a)return;if(document.getElementById('lmgt-busy')){e.preventDefault();return}if(a.getAttribute('onclick')&&/confirm/.test(a.getAttribute('onclick')))return;if(dirty()){e.preventDefault();var h=a.href;var g=function(){location.href=h};g.lmgtHref=h;saveThen(g,a.textContent.trim());return}busy(a.textContent.trim())},true);"
			. "document.addEventListener('submit',function(e){var f=e.target,act=f.querySelector('input[name=action]');if(!act||act.value.indexOf('lmgt_')!==0)return;if(document.getElementById('lmgt-busy')){e.preventDefault();return}if(dirty()&&f.id!=='post'){e.preventDefault();var b0=e.submitter;saveThen(function(){if(b0){var h=document.createElement('input');h.type='hidden';h.name=b0.name;h.value=b0.value;f.appendChild(h)}f.submit()},b0?b0.textContent.trim():'Translator');return}var b=e.submitter;busy(b?b.textContent.trim():'Translator')},true);"
			. "})();</script>";
	}

	private static function cap() {
		return current_user_can( 'edit_others_posts' );
	}

	public static function menu() {
		add_menu_page( 'Translator', 'Translator', 'edit_others_posts', 'lmgt', array( __CLASS__, 'page_queue' ), 'dashicons-translation', 26 );
		add_submenu_page( 'lmgt', 'Queue', 'Queue', 'edit_others_posts', 'lmgt', array( __CLASS__, 'page_queue' ) );
		add_submenu_page( 'lmgt', 'Check Google tags', 'Check Google tags', 'edit_others_posts', 'lmgt-check', array( 'LMGT_Checker', 'page' ) );
		add_submenu_page( 'lmgt', 'Settings', 'Settings', 'manage_options', 'lmgt-settings', array( __CLASS__, 'page_settings' ) );
		add_submenu_page( 'lmgt', 'Clean up old plugin', 'Clean up old plugin', 'manage_options', 'lmgt-cleanup', array( __CLASS__, 'page_cleanup' ) );
	}

	public static function notices() {
		if ( lmgt_legacy_active() && current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-error"><p><strong>LMG Translator is paused:</strong> deactivate the old "Traveltalk AI Translator" plugin first. Both running together would give Google two different language sets for the same pages.</p></div>';
		}
		$gate = get_transient( 'lmgt_gate_' . get_current_user_id() );
		if ( $gate ) {
			delete_transient( 'lmgt_gate_' . get_current_user_id() );
			echo '<div class="notice notice-warning"><p><strong>Kept as draft:</strong> this translation has open flags from the check. Read them in the "Translation check" box, tick "I have read the check", then publish.</p></div>';
		}
		if ( isset( $_GET['lmgt_msg'] ) ) {
			echo '<div class="notice notice-info is-dismissible"><p>' . esc_html( wp_unslash( $_GET['lmgt_msg'] ) ) . '</p></div>';
		}
	}

	// ---- Queue page --------------------------------------------------------------

	public static function page_queue() {
		$ids   = LMGT_Jobs::ids();
		$nonce = wp_create_nonce( 'lmgt_step' );
		$usage = LMGT_Engines::deepl_available() ? LMGT_Engines::deepl_usage() : null;
		echo '<div class="wrap"><h1>Translator</h1>';
		echo '<p>Translations are saved as <strong>drafts</strong> under <a href="' . esc_url( admin_url( 'edit.php?post_type=' . LMGT_CPT ) ) . '">Translations</a>. Nothing is published until you publish it.</p>';
		if ( $usage && ! is_wp_error( $usage ) ) {
			printf( '<p>DeepL this month: %s of %s characters used (%s left).</p>', number_format( $usage['count'] ), number_format( $usage['limit'] ), number_format( max( 0, $usage['limit'] - $usage['count'] ) ) );
		}
		echo '<p><button class="button button-primary" id="lmgt-run">Run queue</button> <button class="button" id="lmgt-stop" disabled>Pause</button> <span id="lmgt-status" style="margin-left:10px"></span></p>';
		echo '<p class="description">Keep this page open while it runs, or let it work in the background: <a href="' . esc_url( admin_url( 'admin.php?page=lmgt-plan' ) ) . '">Translate everything</a> and new articles run without the page open' . ( LMGT_Jobs::busy( 'lmgt_slot_' ) ? ' (' . (int) LMGT_Jobs::busy( 'lmgt_slot_' ) . ' background worker(s) busy now)' : '' ) . '. Each article goes through: prepare → translate → polish → check → back-translate → compare → save.</p>';

		echo '<table class="widefat striped"><thead><tr><th>Article</th><th>Language</th><th>Stage</th><th>Status</th><th>Engine cost</th><th></th></tr></thead><tbody>';
		if ( ! $ids ) echo '<tr><td colspan="6">Queue empty. Queue articles from the Posts or Pages list (Bulk actions → Translate) or from the box on an article.</td></tr>';
		foreach ( array_reverse( $ids ) as $id ) {
			$j = LMGT_Jobs::get( $id );
			if ( ! $j ) continue;
			$l = LMGT_Langs::get( $j['lang'] );
			$actions = '';
			if ( $j['status'] === 'failed' ) $actions .= self::job_link( $id, 'retry', 'Retry' ) . ' · ';
			// On the bridge source the result is a post ID on the other site.
			// 2.14.1: Swedish, Norwegian and Finnish drafts are saved here on .dk (2.11.0); their link pointed to .travel.
			$edit = LMGT_Bridge::is_source() && ! LMGT_Nordic::is( $j['lang'] ) ? LMGT_Bridge::peer() . '/wp-admin/post.php?post=' . (int) $j['result'] . '&action=edit' : get_edit_post_link( $j['result'] );
			if ( $j['status'] === 'done' && ! empty( $j['result'] ) ) $actions .= '<a href="' . esc_url( $edit ) . '">Review draft</a> · ';
			$actions .= self::job_link( $id, 'remove', $j['status'] === 'done' ? 'Clear' : 'Remove from queue' );
			printf(
				'<tr><td><a href="%s">%s</a></td><td>%s</td><td>%s</td><td>%s%s</td><td>%s</td><td>%s</td></tr>',
				esc_url( get_edit_post_link( $j['post'] ) ), esc_html( get_the_title( $j['post'] ) ),
				esc_html( $l ? $l['name'] : $j['lang'] ), esc_html( $j['stage'] ),
				esc_html( $j['status'] ), $j['error'] ? '<br><span style="color:#b32d2e">' . esc_html( $j['error'] ) . '</span>' : '',
				esc_html( LMGT_Meter::cost_label( isset( $j['meter'] ) ? $j['meter'] : array() ) ),
				$actions
			);
		}
		echo '</tbody></table>';
		// Many articles at once, e.g. a list of country pages pasted from a spreadsheet (2.1.5).
		echo '<h2>Queue by ID</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'lmgt_queue_ids' );
		echo '<input type="hidden" name="action" value="lmgt_queue_ids"><p><textarea name="ids" rows="3" style="width:100%" placeholder="Post or page IDs, separated by commas, spaces or new lines"></textarea></p><p>Language <select name="lang">';
		foreach ( LMGT_Langs::enabled() as $code ) echo '<option value="' . esc_attr( $code ) . '">' . esc_html( LMGT_Langs::get( $code )['name'] ) . '</option>';
		echo '</select> <button class="button">Queue</button> <span class="description">Only published originals in the site language; an article that already has a version in that language is skipped.</span></p></form></div>';
		?>
		<script>
		(function(){
			var run=document.getElementById('lmgt-run'),stop=document.getElementById('lmgt-stop'),st=document.getElementById('lmgt-status'),on=false;
			function step(){
				if(!on) return;
				var f=new FormData();f.append('action','lmgt_step');f.append('_ajax_nonce','<?php echo esc_js( $nonce ); ?>');
				fetch(ajaxurl,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json();}).then(function(r){
					var d=r&&r.data||{};
					if(!r.success){st.textContent='Error: '+(r.data||'unknown');on=false;return;}
					if(d.state==='idle'||d.state==='blocked'){st.textContent=d.message+' Reloading…';on=false;setTimeout(function(){location.reload();},800);return;}
					if(d.state==='busy'){st.textContent=d.message;setTimeout(step,4000);return;}
					st.textContent=(d.title||'')+' → '+(d.lang||'')+': '+d.message;
					setTimeout(step,d.status==='failed'?1500:400);
				}).catch(function(){st.textContent='Network error — paused.';on=false;run.disabled=false;stop.disabled=true;});
			}
			run.onclick=function(){on=true;run.disabled=true;stop.disabled=false;step();};
			stop.onclick=function(){on=false;run.disabled=false;stop.disabled=true;st.textContent='Paused after the current step.';};
		})();
		</script>
		<?php
	}

	private static function job_link( $id, $do, $label ) {
		$url = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_job&do=' . $do . '&job=' . $id ), 'lmgt_job' );
		return '<a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
	}

	public static function handle_job() {
		if ( ! self::cap() ) wp_die( 'Not allowed.' );
		check_admin_referer( 'lmgt_job' );
		$id = sanitize_key( $_GET['job'] );
		if ( $_GET['do'] === 'retry' ) LMGT_Jobs::retry( $id );
		if ( $_GET['do'] === 'remove' ) LMGT_Jobs::remove( $id );
		wp_safe_redirect( admin_url( 'admin.php?page=lmgt' ) );
		exit;
	}

	// ---- Queueing --------------------------------------------------------------

	public static function bulk_actions( $actions ) {
		if ( ! self::cap() ) return $actions;
		$langs = LMGT_Langs::enabled();
		if ( count( $langs ) > 1 ) $actions['lmgt_all'] = 'Translate → all switched-on languages';
		foreach ( $langs as $code ) $actions[ 'lmgt_' . $code ] = 'Translate → ' . LMGT_Langs::get( $code )['name'];
		return $actions;
	}

	public static function bulk_handle( $redirect, $action, $ids ) {
		if ( strpos( $action, 'lmgt_' ) !== 0 || ! self::cap() ) return $redirect;
		$code  = substr( $action, 5 );
		$langs = $code === 'all' ? LMGT_Langs::enabled() : array( $code );
		$n = 0;
		$skipped = 0;
		foreach ( (array) $ids as $pid ) {
			foreach ( $langs as $l ) {
				$r = LMGT_Jobs::add( (int) $pid, $l );
				is_wp_error( $r ) ? $skipped++ : $n++;
			}
		}
		$msg = sprintf( '%d translation(s) queued.%s Open Translator → Queue and press "Run queue".', $n, $skipped ? " $skipped skipped (not published, not in the site language, already a translation, or language switched off)." : '' );
		return add_query_arg( 'lmgt_msg', rawurlencode( $msg ), $redirect );
	}

	public static function handle_queue_ids() {
		if ( ! self::cap() ) wp_die( 'Not allowed.' );
		check_admin_referer( 'lmgt_queue_ids' );
		$lang = isset( $_POST['lang'] ) ? sanitize_key( $_POST['lang'] ) : '';
		$ids  = array_unique( array_filter( array_map( 'intval', preg_split( '/[^0-9]+/', isset( $_POST['ids'] ) ? (string) $_POST['ids'] : '' ) ) ) );
		$n = $have = $bad = 0;
		foreach ( $ids as $pid ) {
			$remote = LMGT_Bridge::is_source() ? LMGT_Bridge::remote( $pid ) : array();
			if ( isset( $remote[ $lang ] ) || isset( LMGT_Store::of( $pid )[ $lang ] ) ) { $have++; continue; }
			is_wp_error( LMGT_Jobs::add( $pid, $lang ) ) ? $bad++ : $n++;
		}
		$msg = sprintf( '%d queued, %d skipped (already have this language), %d not possible (not published, not in the site language, or the language is switched off). Press "Run queue".', $n, $have, $bad );
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $msg ), admin_url( 'admin.php?page=lmgt' ) ) );
		exit;
	}

	public static function handle_queue() {
		$pid = (int) $_POST['post_id'];
		if ( ! self::cap() ) wp_die( 'Not allowed.' );
		check_admin_referer( 'lmgt_queue_' . $pid );
		$n = 0;
		foreach ( (array) ( isset( $_POST['lmgt_langs'] ) ? $_POST['lmgt_langs'] : array() ) as $l ) {
			$l = sanitize_key( $l );
			if ( ! is_wp_error( LMGT_Jobs::add( $pid, $l ) ) ) $n++;
		}
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( "$n translation(s) queued." ), admin_url( 'admin.php?page=lmgt' ) ) );
		exit;
	}

	// ---- Boxes -----------------------------------------------------------------

	public static function boxes() {
		foreach ( LMGT_Store::types() as $t ) {
			add_meta_box( 'lmgt_box', 'Translations', array( __CLASS__, 'box_original' ), $t, 'side', 'default' );
		}
		add_meta_box( 'lmgt_review', 'Translation check', array( __CLASS__, 'box_review' ), LMGT_CPT, 'normal', 'high' );
		add_meta_box( 'lmgt_actions', 'Translation: what to do now', array( __CLASS__, 'box_actions' ), LMGT_CPT, 'side', 'high' );
		add_meta_box( 'lmgt_meta', 'Translation of', array( __CLASS__, 'box_meta' ), LMGT_CPT, 'side', 'high' );
	}

	/** 2.2.27: the "Translate as written" tick in the Translations box. */
	public static function save_as_written( $id, $post ) {
		if ( wp_is_post_revision( $id ) || empty( $_POST['lmgt_as_written_box'] ) || ! current_user_can( 'edit_post', $id ) ) return;
		if ( ! empty( $_POST['lmgt_as_written'] ) ) update_post_meta( $id, '_lmgt_as_written', '1' );
		else delete_post_meta( $id, '_lmgt_as_written' );
	}

	public static function box_original( $post ) {
		if ( ! self::cap() ) return;
		if ( LMGT_Store::is_tagged( $post->ID ) ) {
			self::box_tagged( $post );
			return;
		}
		$have = LMGT_Store::of( $post->ID );
		echo '<table style="width:100%">';
		foreach ( LMGT_Langs::enabled() as $code ) {
			$l = LMGT_Langs::get( $code );
			$state = '—';
			if ( isset( $have[ $code ] ) ) {
				$tid   = $have[ $code ];
				$state = get_post_status( $tid ) === 'publish' ? 'Published' : 'Draft';
				if ( get_post_meta( $tid, '_lmgt_source_modified', true ) !== $post->post_modified_gmt ) $state .= ', original changed since';
				$state = '<a href="' . esc_url( get_edit_post_link( $tid ) ) . '">' . esc_html( $state ) . '</a>';
			}
			echo '<tr><td><label><input type="checkbox" form="lmgt-q" name="lmgt_langs[]" value="' . esc_attr( $code ) . '"> ' . esc_html( $l['name'] ) . '</label></td><td>' . $state . '</td></tr>';
		}
		echo '</table>';
		$auto = ! get_post_meta( $post->ID, '_lmgt_as_written', true ) && LMGT_Store::as_written( $post->ID );
		echo '<input type="hidden" name="lmgt_as_written_box" value="1"><p><label><input type="checkbox" name="lmgt_as_written" value="1" ' . checked( LMGT_Store::as_written( $post->ID ), true, false ) . ( $auto ? ' disabled' : '' ) . '> Translate as written</label><br><span class="description">' . ( $auto ? 'On by itself: this is news.' : 'For news and editorial texts: no length mark, no suggestions, every language.' ) . '</span></p>';
		if ( $post->post_status === 'publish' ) {
			echo '<p><button class="button" form="lmgt-q">Queue ticked languages</button></p>';
		} else {
			echo '<p class="description">Publish the original first.</p>';
		}
		// The form lives outside the post form, attached by the form="" attribute.
		add_action( 'admin_footer', function () use ( $post ) {
			echo '<form id="lmgt-q" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
				. '<input type="hidden" name="action" value="lmgt_queue"><input type="hidden" name="post_id" value="' . (int) $post->ID . '">'
				. wp_nonce_field( 'lmgt_queue_' . $post->ID, '_wpnonce', true, false ) . '</form>';
		} );
		self::box_length( $post );
		self::box_en_extra( $post );
		$notes = get_post_meta( $post->ID, '_lmgt_original_notes', true );
		if ( is_array( $notes ) && $notes ) {
			echo '<hr><p><strong>Possible errors in this original</strong>, found while checking translations:</p>';
			echo '<p><label><input type="checkbox" onclick="document.querySelectorAll(\'.lmgt-sg\').forEach(function(c){c.checked=this.checked}.bind(this))"> Tick all</label></p><ul>';
			foreach ( $notes as $code => $list ) {
				foreach ( (array) $list as $n => $s ) {
					if ( ! LMGT_Store::real_suggestions( array( $s ) ) ) continue;
					echo '<li><label><input type="checkbox" class="lmgt-sg" form="lmgt-sg" name="lmgt_sg[]" value="' . esc_attr( $code . ':' . $n ) . '"> <em>' . esc_html( isset( $s['text'] ) ? $s['text'] : '' ) . '</em> → ' . esc_html( isset( $s['suggestion'] ) ? $s['suggestion'] : '' ) . ( ! empty( $s['why'] ) ? ' <span class="description">(' . esc_html( $s['why'] ) . ')</span>' : '' ) . '</label></li>';
				}
			}
			echo '</ul><p><button class="button" form="lmgt-sg">Apply ticked to this article</button></p>';
			echo '<p class="description">Only ticked suggestions are written in. Save your own edits first. WordPress keeps the previous version under Revisions.</p>';
			add_action( 'admin_footer', function () use ( $post ) {
				echo '<form id="lmgt-sg" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
					. '<input type="hidden" name="action" value="lmgt_suggest"><input type="hidden" name="post_id" value="' . (int) $post->ID . '">'
					. wp_nonce_field( 'lmgt_suggest_' . $post->ID, '_wpnonce', true, false ) . '</form>';
			} );
		}
		$live = LMGT_Store::of( $post->ID, array( 'publish' ) );
		if ( $live && $post->post_status !== 'publish' ) {
			echo '<div class="notice notice-warning inline"><p>This original is not published, but ' . count( $live ) . ' translation(s) of it are. They no longer carry hreflang. Nothing was unpublished automatically.</p></div>';
		}
		if ( ! $have ) self::tag_form( $post );
	}

	/** On an ordinary post that is a hand-written translation: what it is, and undo. */
	private static function box_tagged( $post ) {
		$src = (int) get_post_meta( $post->ID, '_lmgt_source', true );
		$l   = LMGT_Langs::get( get_post_meta( $post->ID, '_lmgt_lang', true ) );
		echo '<p>Hand-written <strong>' . esc_html( $l ? $l['name'] : '?' ) . '</strong> version of <a href="' . esc_url( get_edit_post_link( $src ) ) . '">' . esc_html( get_the_title( $src ) ) . '</a>.</p>';
		echo '<p class="description">Keeps its address. Hidden from the ' . esc_html( LMGT_Langs::get( LMGT_Langs::source() )['name'] ) . ' listings, linked to the original by hreflang and the language switcher.</p>';
		echo '<p><button class="button" form="lmgt-t" name="do" value="untag">Remove language tag</button></p>';
		self::tag_form_element( $post );
	}

	/** On an ordinary post: mark it as the hand-written translation of another post. */
	private static function tag_form( $post ) {
		echo '<hr><p><strong>Is this post a translation?</strong></p>';
		echo '<p><select form="lmgt-t" name="lang"><option value="">Language…</option>';
		foreach ( LMGT_Langs::all() as $code => $l ) {
			if ( $code !== LMGT_Langs::source() ) echo '<option value="' . esc_attr( $code ) . '">' . esc_html( $l['name'] ) . '</option>';
		}
		echo '</select></p><p><input form="lmgt-t" type="text" name="source" placeholder="ID or address of the original" style="width:100%"></p>';
		echo '<p><button class="button" form="lmgt-t" name="do" value="tag">Tag as translation</button></p>';
		echo '<p class="description">Nothing is unpublished and the address stays. The post leaves the listings and joins the original\'s hreflang set.</p>';
		self::tag_form_element( $post );
	}

	private static function tag_form_element( $post ) {
		add_action( 'admin_footer', function () use ( $post ) {
			echo '<form id="lmgt-t" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
				. '<input type="hidden" name="action" value="lmgt_tag"><input type="hidden" name="post_id" value="' . (int) $post->ID . '">'
				. wp_nonce_field( 'lmgt_tag_' . $post->ID, '_wpnonce', true, false ) . '</form>';
		} );
	}

	public static function handle_tag() {
		$pid = (int) $_POST['post_id'];
		if ( ! current_user_can( 'edit_post', $pid ) || ! self::cap() ) wp_die( 'Not allowed.' );
		check_admin_referer( 'lmgt_tag_' . $pid );
		if ( isset( $_POST['do'] ) && $_POST['do'] === 'untag' ) {
			LMGT_Store::untag( $pid );
			$msg = 'Language tag removed. The post is back in the listings.';
		} else {
			$ref = trim( wp_unslash( isset( $_POST['source'] ) ? $_POST['source'] : '' ) );
			$src = ctype_digit( $ref ) ? (int) $ref : url_to_postid( $ref );
			$r   = LMGT_Store::tag( $pid, $src, sanitize_key( isset( $_POST['lang'] ) ? $_POST['lang'] : '' ) );
			$msg = is_wp_error( $r ) ? 'Not tagged: ' . $r->get_error_message() : 'Tagged. The post keeps its address and has left the listings.';
		}
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $msg ), get_edit_post_link( $pid, 'url' ) ) );
		exit;
	}

	public static function handle_seo() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_seo_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$back = get_edit_post_link( $id, 'url' );
		$post = get_post( $id );
		if ( ! $post ) self::back( $back, 'Not found.' );
		$first = trim( (string) strtok( (string) get_post_meta( $id, 'rank_math_focus_keyword', true ), ',' ) );
		$seo = LMGT_Store::seo_basics( get_post_meta( $id, '_lmgt_lang', true ), $post->post_title, $post->post_content, get_post_meta( $id, '_lmgt_source_type', true ) === 'page', $first );
		LMGT_Meter::charge( $id );
		if ( $seo['keyword'] === '' && $seo['meta'] === '' ) self::back( $back, 'Nothing usable came back. Try again.' );
		// A keyword already there stays first (G, 27 Oct: the suggestion had replaced the agreed country name); the suggestion is added after it (2.2.13).
		$had = array_filter( array_map( 'trim', explode( ',', (string) get_post_meta( $id, 'rank_math_focus_keyword', true ) ) ), 'strlen' );
		$sug = $seo['keyword'];
		if ( $had && $sug !== '' ) {
			if ( ! in_array( mb_strtolower( $sug ), array_map( 'mb_strtolower', $had ), true ) ) $had[] = $sug;
			$seo['keyword'] = implode( ',', $had );
		}
		LMGT_Store::apply_seo( $id, $seo );
		$msg = $had && $sug !== '' ? 'Focus keyword kept: "' . reset( $had ) . '"' . ( count( $had ) > 1 ? '; suggestion "' . $sug . '" added after it' : '' ) . '. Meta description set.' : 'Focus keyword "' . $seo['keyword'] . '" and meta description set.';
		// Only a draft's address may change; a published one is known to Google already.
		if ( $post->post_status !== 'publish' && $seo['slug'] !== '' ) {
			LMGT_Store::update_content( $id, array( 'post_name' => $seo['slug'] ) );
			$msg .= ' Address: /' . $seo['slug'] . '/.';
		}
		self::back( $back, $msg . ' Reload to see it in Rank Math.' );
	}

	public static function box_meta( $post ) {
		$src = (int) get_post_meta( $post->ID, '_lmgt_source', true );
		$l   = LMGT_Langs::get( get_post_meta( $post->ID, '_lmgt_lang', true ) );
		$remote = get_post_meta( $post->ID, '_lmgt_remote_url', true );
		if ( $remote ) echo '<p><strong>' . esc_html( $l ? $l['name'] : '?' ) . '</strong> version of<br><a href="' . esc_url( $remote ) . '" target="_blank">' . esc_html( $remote ) . '</a></p>';
		else echo '<p><strong>' . esc_html( $l ? $l['name'] : '?' ) . '</strong> version of<br><a href="' . esc_url( get_edit_post_link( $src ) ) . '">' . esc_html( get_the_title( $src ) ) . '</a></p>';
		if ( $post->post_status === 'publish' ) echo '<p><a href="' . esc_url( get_permalink( $post ) ) . '" target="_blank">' . esc_html( get_permalink( $post ) ) . '</a></p>';
		if ( LMGT_Engines::ai_available() ) {
			$u = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_seo&post=' . $post->ID ), 'lmgt_seo_' . $post->ID );
			// 2.6.2 (G, 8 Nov): show what is set, so the button is not the only sign it worked.
			$kw = trim( (string) get_post_meta( $post->ID, 'rank_math_focus_keyword', true ) );
			$md = trim( (string) get_post_meta( $post->ID, 'rank_math_description', true ) );
			if ( $kw !== '' || $md !== '' ) {
				echo '<p style="margin-bottom:2px"><strong>Keyword:</strong> ' . ( $kw !== '' ? esc_html( $kw ) : '<span style="color:#b32d2e">none</span>' ) . '</p>';
				echo '<p><strong>Meta (' . (int) mb_strlen( $md ) . '):</strong> ' . ( $md !== '' ? esc_html( $md ) : '<span style="color:#b32d2e">none</span>' ) . '</p>';
			}
			echo '<p><a class="button" href="' . esc_url( $u ) . '">' . ( $kw !== '' || $md !== '' ? 'Set SEO again' : 'Set SEO: keyword, meta' . ( $post->post_status !== 'publish' ? ', address' : '' ) ) . '</a></p>';
		}
		echo '<p class="description">To remove this translation, move it to Trash. The original is not affected.</p>';
	}

	/**
	 * 2.6.3 (G, 8 Nov): the buttons that change the text sat at the bottom of a long box. The
	 * next step now sits beside Update: a waiting version to apply, flags to fix, or nothing.
	 */
	public static function box_actions( $post ) {
		$p = get_post_meta( $post->ID, '_lmgt_pending', true );
		if ( is_array( $p ) && ! empty( $p['translation'] ) ) {
			$url  = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_apply&post=' . $post->ID ), 'lmgt_apply_' . $post->ID );
			$drop = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_discard&post=' . $post->ID ), 'lmgt_discard_' . $post->ID );
			echo '<p><strong>' . ( isset( $p['kind'] ) && $p['kind'] === 'fix' ? 'Corrected version waiting' : 'New version waiting' ) . '</strong></p>';
			echo '<p><a class="button button-primary button-large" style="width:100%;text-align:center" href="' . esc_url( $url ) . '">Accept: put it in the text</a></p><p><a href="' . esc_url( $drop ) . '">Reject: keep my text</a></p>';
			echo '<p class="description">Save your own edits first. The current text stays under Revisions.</p>';
			return;
		}
		$n = LMGT_Store::open_issues( $post->ID );
		if ( ! $n ) { echo '<p style="color:#008a20"><strong>No flags.</strong> Nothing to fix.</p>'; return; }
		echo '<p><strong>' . (int) $n . ' flag(s)</strong> from the check (listed under "Translation check").</p>';
		if ( LMGT_Engines::ai_available() ) {
			$fix = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_fix&post=' . $post->ID ), 'lmgt_fix_' . $post->ID );
			$nn = LMGT_Store::open_numbers( $post->ID );
			if ( $nn ) echo '<p><a class="button button-large" style="width:100%;text-align:center" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_numbers_ok&post=' . $post->ID ), 'lmgt_numbers_ok_' . $post->ID ) ) . '">Numbers are right – clear (' . (int) $nn . ')</a></p>';
			if ( $n > $nn ) echo '<p><a class="button button-primary button-large" style="width:100%;text-align:center" href="' . esc_url( $fix ) . '">Fix the flags</a></p><p class="description">Makes a corrected version; nothing changes until you press Accept here.</p>';
		}
	}

	public static function box_review( $post ) {
		$r = get_post_meta( $post->ID, '_lmgt_report', true );
		$pending = get_post_meta( $post->ID, '_lmgt_pending', true );
		if ( is_array( $pending ) && ! empty( $pending['translation'] ) ) {
			$url  = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_apply&post=' . $post->ID ), 'lmgt_apply_' . $post->ID );
			$drop = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_discard&post=' . $post->ID ), 'lmgt_discard_' . $post->ID );
			$what = isset( $pending['kind'] ) && $pending['kind'] === 'fix' ? 'A version with the flagged passages corrected' : 'A new machine translation from the queue';
			// Applying replaces the whole text, so edits made after the version was
			// made would be lost. Say so when that is the case.
			$late = strtotime( $post->post_modified_gmt . ' UTC' ) > strtotime( $pending['at'] . ' UTC' );
			echo '<div class="notice ' . ( $late ? 'notice-warning' : 'notice-info' ) . ' inline"><p>' . $what . ' is waiting (made ' . esc_html( $pending['at'] ) . ' UTC). Nothing changes until you choose. '
				. '<a href="' . esc_url( $url ) . '">Accept: put it in the text</a> (replaces the whole text) or <a href="' . esc_url( $drop ) . '">discard it</a>.'
				. ( $late ? '<br><strong>You have edited this text since then. Applying would undo those edits.</strong>' : '' ) . '</p></div>';
		}
		$src = (int) get_post_meta( $post->ID, '_lmgt_source', true );
		// 2.6.2 (G, 8 Nov): a translation that came from traveltalk.dk has its original on the other
		// site, so the gap check found nothing to read here and the box stayed empty. It now checks
		// the translation itself, and the sections are written for this translation only.
		if ( ! $src && get_post_meta( $post->ID, '_lmgt_remote_source', true ) && ! LMGT_Store::as_written( $post->ID ) ) {
			$g = get_post_meta( $post->ID, '_lmgt_gaps', true );
			echo '<p><strong>More depth</strong> (' . (int) LMGT_Store::words( $post ) . ' words)</p>';
			if ( is_array( $g ) && ! empty( $g['gaps'] ) ) self::gap_picker( $post, $g['gaps'], false );
			elseif ( is_array( $g ) ) echo '<p style="color:#008a20">No content gaps found (' . esc_html( $g['at'] ) . ' UTC).</p>';
			if ( LMGT_Engines::ai_available() ) {
				$gu = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_gaps&post=' . $post->ID ), 'lmgt_gaps_' . $post->ID );
				echo '<p><a class="button" href="' . esc_url( $gu ) . '">' . ( is_array( $g ) ? 'Check gaps again' : 'Find content gaps' ) . '</a></p>';
			}
			self::box_gap_draft( $post );
		}
		if ( $src ) {
			$n   = LMGT_Store::words( $src );
			$min = LMGT_Store::min_words( $src );
			$g   = get_post_meta( $src, '_lmgt_gaps', true );
			$gn  = is_array( $g ) && ! empty( $g['gaps'] ) ? count( $g['gaps'] ) : 0;
			if ( LMGT_Store::as_written( $src ) ) {
				echo '<p class="description">News: translated as written. No length mark and no suggestions.</p>';
			} elseif ( $n < $min || $gn ) {
				echo '<div class="notice notice-warning inline"><p><strong>The original is ' . ( $n < $min ? 'thin: ' . (int) $n . ' words (minimum ' . (int) $min . ')' : (int) $n . ' words' ) . '.</strong> '
					. ( $gn ? $gn . ' content gap(s) found. Tick the ones to fill.' : '' ) . '</p>';
				if ( $gn ) self::gap_picker( $post, $g['gaps'], true );
				echo '</div>';
			}
			self::box_gap_draft( $post );
		}
		if ( ! is_array( $r ) ) { echo '<p>No check stored.</p>'; return; }
		echo '<p>Engine: ' . esc_html( $r['engine'] ) . '.';
		if ( ! empty( $r['detected']['code'] ) ) echo ' Language check: reads as <strong>' . esc_html( $r['detected']['code'] ) . '</strong>.';
		echo '</p>';

		$num = isset( $r['numbers'] ) ? $r['numbers'] : array();
		if ( ! empty( $num['missing'] ) || ! empty( $num['extra'] ) ) {
			echo '<h4>Numbers that differ from the original</h4><ul style="list-style:disc;margin-left:18px">';
			foreach ( (array) $num['missing'] as $n ) echo '<li>In the original, not in the translation: <code>' . esc_html( $n ) . '</code></li>';
			foreach ( (array) $num['extra'] as $n ) echo '<li>In the translation, not in the original: <code>' . esc_html( $n ) . '</code></li>';
			echo '</ul>';
			echo '<p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_numbers_ok&post=' . $post->ID ), 'lmgt_numbers_ok_' . $post->ID ) ) . '">Numbers are right – clear</a> <span class="description">Fix cannot change numbers (often a converted price or a written-out number). Check them in the text, then clear.</span></p>';
		}
		$real = LMGT_Store::real_issues( $r );
		if ( $real ) {
			echo '<h4>Meaning that changed in translation</h4><p class="description">Found by translating back into the original language and comparing.</p><table class="widefat striped"><thead><tr><th title="Ticked = fix it">Fix</th><th>Type</th><th>Original</th><th>Back-translated</th><th>Note</th></tr></thead><tbody>';
			foreach ( $real as $k => $i ) {
				// 2.17.3 (G, 14 Nov): choose which flags to fix.
				printf( '<tr><td><input type="checkbox" class="lmgt-fixpick" value="%d" checked autocomplete="off"></td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>', (int) $k,
					esc_html( isset( $i['type'] ) ? $i['type'] : '' ), esc_html( isset( $i['original'] ) ? $i['original'] : '' ),
					esc_html( isset( $i['back'] ) ? $i['back'] : '' ), esc_html( isset( $i['note'] ) ? $i['note'] : '' ) );
			}
			echo '</tbody></table>';
			if ( LMGT_Engines::ai_available() ) {
				$fix = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_fix&post=' . $post->ID ), 'lmgt_fix_' . $post->ID );
				echo '<p><a class="button" id="lmgt-fixbtn" href="' . esc_url( $fix ) . '" onclick="var p=[].slice.call(document.querySelectorAll(\'.lmgt-fixpick\'));var on=p.filter(function(x){return x.checked}).map(function(x){return x.value});if(!on.length){alert(\'Tick at least one flag to fix, or publish as it is.\');return false}if(on.length<p.length)this.href+=\'&only=\'+on.join(\'-\');">Fix the ticked passages with ' . esc_html( LMGT_Engines::ai_name() ) . '</a> '
					. '<span class="description">Save your own edits first. The corrected version waits here until you apply it.</span></p>';
			}
		}
		$open = LMGT_Store::open_issues( $post->ID );
		if ( ! $open ) {
			echo '<p style="color:#008a20"><strong>No flags.</strong> Numbers match and the back-translation says the same as the original.</p>';
		} else {
			$done = LMGT_Store::is_reviewed( $post->ID );
			echo '<p><label><input type="checkbox" name="lmgt_reviewed" value="1" id="lmgt-reviewed" autocomplete="off" ' . checked( $done, true, false ) . '> <strong>I have read the check</strong> – publish as it is. ' . $open . ' flag(s) open.</label></p>';
			echo '<p class="description">You do not have to fix anything: tick this and Publish. Fix only the flags you choose (tick them under Fix above). The tick is the one thing Publish waits for, so a person has read the check (G, 10 Nov).</p>';
			wp_nonce_field( 'lmgt_review_' . $post->ID, 'lmgt_review_nonce' );
			$ajax = wp_create_nonce( 'lmgt_reviewed_' . $post->ID );
			// The block editor saves boxes after the post itself, so the tick is
			// also stored the moment it is clicked.
			echo "<script>document.getElementById('lmgt-reviewed').addEventListener('change',function(e){var f=new FormData();f.append('action','lmgt_reviewed');f.append('post'," . (int) $post->ID . ");f.append('on',e.target.checked?'1':'0');f.append('_ajax_nonce','" . esc_js( $ajax ) . "');fetch(ajaxurl,{method:'POST',body:f,credentials:'same-origin'});});</script>";
		}
		if ( ! empty( $r['back']['text'] ) ) {
			echo '<details><summary>Show the back-translation</summary><p><strong>' . esc_html( $r['back']['title'] ) . '</strong></p><div style="max-height:320px;overflow:auto;white-space:pre-wrap">' . esc_html( $r['back']['text'] ) . '</div></details>';
		}
	}

	public static function save_review( $id ) {
		if ( ! isset( $_POST['lmgt_review_nonce'] ) || ! wp_verify_nonce( $_POST['lmgt_review_nonce'], 'lmgt_review_' . $id ) ) return;
		if ( ! current_user_can( 'edit_post', $id ) ) return;
		LMGT_Store::mark_reviewed( $id, ! empty( $_POST['lmgt_reviewed'] ) );
	}

	public static function ajax_reviewed() {
		$id = (int) $_POST['post'];
		check_ajax_referer( 'lmgt_reviewed_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_send_json_error();
		LMGT_Store::mark_reviewed( $id, $_POST['on'] === '1' );
		wp_send_json_success();
	}

	public static function words_column( $col, $id ) {
		if ( $col === 'lmgt_id' ) { echo (int) $id; return; }
		if ( $col === 'lmgt_langs' ) {
			// EN = published, en = draft; each links to the translation.
			$out = array();
			foreach ( LMGT_Store::of( $id ) as $code => $tid ) {
				$l = LMGT_Langs::get( $code );
				if ( ! $l ) continue;
				$pub   = get_post_status( $tid ) === 'publish';
				$out[] = '<a href="' . esc_url( get_edit_post_link( $tid ) ) . '" title="' . esc_attr( $l['name'] . ( $pub ? ', published' : ', draft' ) ) . '" style="' . ( $pub ? 'font-weight:600' : 'color:#8a8a8f' ) . '">' . esc_html( $pub ? strtoupper( $l['hreflang'] ) : $l['hreflang'] ) . '</a>';
			}
			echo $out ? implode( ' ', $out ) : '—';
			return;
		}
		if ( $col !== 'lmgt_words' ) return;
		$n = LMGT_Store::words( $id );
		$p = LMGT_Store::is_pillar( $id );
		echo $n < LMGT_Store::min_words( $id ) ? '<span style="color:#b32d2e">' . (int) $n . ' · thin' . ( $p ? ' pillar' : '' ) . '</span>' : (int) $n . ( $p ? ' · pillar' : '' );
	}

	/** Length against the minimum, and the content gaps found so far, on the original. */
	private static function box_length( $post ) {
		if ( LMGT_Store::as_written( $post->ID ) ) {
			echo '<hr><p><strong>Length:</strong> ' . (int) LMGT_Store::words( $post ) . ' words. News: translated as written, no length mark and no suggestions.</p>';
			return;
		}
		$n   = LMGT_Store::words( $post );
		$min = LMGT_Store::min_words( $post->ID );
		$kind = LMGT_Store::is_pillar( $post->ID ) ? 'pillar' : 'article';
		echo '<hr><p><strong>Length:</strong> ' . ( $n < $min ? '<span style="color:#b32d2e">' . (int) $n . ' words, thin for a ' . $kind . ' (minimum ' . (int) $min . ')</span>' : (int) $n . ' words (' . $kind . ', minimum ' . (int) $min . ')' ) . '</p>';
		$g = get_post_meta( $post->ID, '_lmgt_gaps', true );
		self::box_gap_draft( $post );
		if ( is_array( $g ) && ! empty( $g['gaps'] ) ) {
			echo '<p><strong>What readers will miss</strong> (' . esc_html( $g['at'] ) . ' UTC):</p>';
			self::gap_picker( $post, $g['gaps'], false );
		} elseif ( is_array( $g ) ) {
			echo '<p style="color:#008a20">No content gaps found (' . esc_html( $g['at'] ) . ' UTC).</p>';
		}
		if ( LMGT_Engines::ai_available() ) {
			$url = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_gaps&post=' . $post->ID ), 'lmgt_gaps_' . $post->ID );
			echo '<p><a class="button" href="' . esc_url( $url ) . '">' . ( is_array( $g ) ? 'Check gaps again' : 'Find content gaps' ) . '</a></p>';
		}
	}

	/**
	 * The gaps as a checklist with one button: the sections are written for the
	 * ticked gaps and shown for reading. On a translation the reader chooses
	 * between the translation itself and the original (which then goes to every
	 * language).
	 */
	/** 2.4.2 (G, 7 Nov): the line under a list of named providers, in the text's language. */
	public static function link_notice( $lang ) {
		$t = array(
			'da' => 'Er din virksomhed indforstået med et direkte link, så giv os besked.',
			'en' => 'If your company is happy for us to link to it directly, let us know.',
			'de' => 'Wenn Ihr Unternehmen mit einem direkten Link einverstanden ist, lassen Sie es uns wissen.',
			'sv' => 'Om ert företag går med på en direktlänk, hör av er till oss.',
			'nb' => 'Hvis bedriften din er med på en direkte lenke, gi oss beskjed.',
		);
		return isset( $t[ $lang ] ) ? $t[ $lang ] : $t['en'];
	}

	private static function gap_picker( $post, array $gaps, $on_translation ) {
		echo '<ul style="list-style:none;margin-left:0">';
		foreach ( array_values( $gaps ) as $n => $x ) {
			echo '<li><label><input type="checkbox" form="lmgt-gp" name="lmgt_gp[]" value="' . (int) $n . '" checked> <strong>' . esc_html( $x['topic'] ) . '</strong>'
				. ( ! empty( $x['add'] ) ? ': ' . esc_html( $x['add'] ) : '' ) . '</label></li>';
		}
		echo '</ul>';
		// 2.4.2: named providers are suggestions, not facts. None is ticked until a person has checked it.
		$src = $post->post_type === LMGT_CPT ? (int) get_post_meta( $post->ID, '_lmgt_source', true ) : $post->ID;
		if ( ! $src ) $src = $post->ID;
		$g   = get_post_meta( $src, '_lmgt_gaps', true );
		$pv  = is_array( $g ) && ! empty( $g['providers'] ) ? array_values( $g['providers'] ) : array();
		if ( $pv ) {
			$kept = array_map( function ( $w ) { return untrailingslashit( (string) $w['web'] ); }, (array) get_post_meta( $post->ID, '_lmgt_who', true ) );
			echo '<p><strong>Who takes you there</strong> – suggestions, <span style="color:#b32d2e">not verified</span>. Open the website, check the fit, tick those you want on the page, and press <em>Put them in the box</em>. They go into the "Who takes you there" box, each linked to its website, and onto Translator → Outreach. Companies already in the box are ticked.</p><ul style="list-style:none;margin-left:0">';
			foreach ( $pv as $n => $x ) {
				$web = ! empty( $x['web'] ) ? ' · <a href="' . esc_url( $x['web'] ) . '" target="_blank">' . esc_html( preg_replace( '#^https?://(www\.)?#', '', untrailingslashit( $x['web'] ) ) ) . '</a> ' . ( ! empty( $x['live'] ) ? '<span style="color:#008a20">✓ website answers</span>' : '<span style="color:#b32d2e">✗ website does not answer</span>' ) : ' · <span class="description">no website found</span>';
				$on  = ! empty( $x['web'] ) && in_array( untrailingslashit( $x['web'] ), $kept, true );
				echo '<li><label><input type="checkbox" form="lmgt-who" name="lmgt_pv[]" value="' . (int) $n . '"' . checked( $on, true, false ) . '> <strong>' . esc_html( $x['name'] ) . '</strong>'
					. ' <span class="description">(' . esc_html( LMGT_Boxes::kind_label( isset( $x['kind'] ) ? $x['kind'] : 'local', 'en' ) ) . ( ! empty( $x['what'] ) ? ', ' . esc_html( $x['what'] ) : '' ) . ')</span></label>' . $web . '</li>';
			}
			echo '</ul><p><button class="button button-primary" form="lmgt-who">Put them in the box</button></p>';
			add_action( 'admin_footer', function () use ( $post ) {
				echo '<form id="lmgt-who" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="lmgt_who_box"><input type="hidden" name="post_id" value="' . (int) $post->ID . '">' . wp_nonce_field( 'lmgt_who_box_' . $post->ID, '_wpnonce', true, false ) . '</form>';
			} );
		}
		if ( ! LMGT_Engines::ai_available() ) return;
		if ( $on_translation ) {
			echo '<p><button class="button button-primary" form="lmgt-gp" name="target" value="original">Write the ticked sections for the original</button> '
				. '<button class="button" form="lmgt-gp" name="target" value="self">Write them for this translation only</button></p>'
				. '<p class="description">Original: added there, then every language is translated again. You read the sections before anything is added.</p>';
		} else {
			echo '<p><button class="button button-primary" form="lmgt-gp" name="target" value="self">Write the ticked sections</button></p>'
				. '<p class="description">You read them before anything is added.</p>';
		}
		add_action( 'admin_footer', function () use ( $post ) {
			echo '<form id="lmgt-gp" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
				. '<input type="hidden" name="action" value="lmgt_gap_draft"><input type="hidden" name="post_id" value="' . (int) $post->ID . '">'
				. wp_nonce_field( 'lmgt_gap_draft_' . $post->ID, '_wpnonce', true, false ) . '</form>';
		} );
	}

	/** The written sections, for reading: tick what goes in, one button adds it in place. */
	private static function box_gap_draft( $post ) {
		$d = get_post_meta( $post->ID, '_lmgt_gap_draft', true );
		if ( ! is_array( $d ) || empty( $d['sections'] ) ) return;
		echo '<div style="border-left:4px solid #2271b1;padding:4px 12px;margin:12px 0;background:#f6f7f7"><p><strong>New sections to read</strong> (' . esc_html( $d['at'] ) . ' UTC). Untick any you do not want.</p>';
		foreach ( $d['sections'] as $n => $s ) {
			echo '<p style="margin-bottom:2px"><label><input type="checkbox" form="lmgt-gd" name="lmgt_gd[]" value="' . (int) $n . '" checked> <strong>' . esc_html( $s['heading'] ) . '</strong></label>'
				. ( ! empty( $s['after'] ) ? ' <span class="description">goes after "' . esc_html( $s['after'] ) . '"</span>' : ' <span class="description">goes at the end</span>' ) . '</p>';
			echo '<div style="margin:0 0 12px 24px">' . wp_kses_post( $s['html'] ) . '</div>';
		}
		$langs = LMGT_Store::is_tagged( $post->ID ) || $post->post_type === LMGT_CPT ? array() : array_keys( LMGT_Store::of( $post->ID ) );
		echo '<p><button class="button button-primary" form="lmgt-gd" name="do" value="add">Add the ticked sections' . ( $langs ? ' and translate again' : '' ) . '</button> '
			. '<button class="button" form="lmgt-gd" name="do" value="drop">Discard all</button></p>';
		if ( $langs ) echo '<p class="description">Every language is translated again; the new version then waits on each translation for "Apply it".</p>';
		echo '</div>';
		add_action( 'admin_footer', function () use ( $post ) {
			echo '<form id="lmgt-gd" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
				. '<input type="hidden" name="action" value="lmgt_gap_insert"><input type="hidden" name="post_id" value="' . (int) $post->ID . '">'
				. wp_nonce_field( 'lmgt_gap_insert_' . $post->ID, '_wpnonce', true, false ) . '</form>';
		} );
	}

	/** Headings of an article, as text, in order. */
	public static function headings( $html ) {
		preg_match_all( '#<h([1-6])[^>]*>(.*?)</h\1>#is', $html, $m );
		return array_values( array_filter( array_map( function ( $h ) { return trim( html_entity_decode( wp_strip_all_tags( $h ), ENT_QUOTES, 'UTF-8' ) ); }, $m[2] ) ) );
	}

	/** 2.7.1: up to 40 published articles on this site, in the text's language, that share words with its title. [title => url] */
	public static function link_candidates( $post, $lang ) {
		// 2.7.4 (G, 9 Nov: "Propose links was empty" on .travel): a translation in the site's own language
		// also links to the site's own articles (on traveltalk.travel most English articles are its own posts).
		$ids = array();
		$base = array( 'post_status' => 'publish', 'posts_per_page' => 600, 'fields' => 'ids', 'post__not_in' => array( $post->ID ), 'lmgt_all' => true, 'no_found_rows' => true );
		if ( $post->post_type === LMGT_CPT ) $ids = get_posts( $base + array( 'post_type' => LMGT_CPT, 'meta_query' => array( array( 'key' => '_lmgt_lang', 'value' => $lang ) ) ) );
		if ( $post->post_type !== LMGT_CPT || $lang === LMGT_Langs::source() ) $ids = array_merge( $ids, get_posts( $base + array( 'post_type' => array( 'post', 'page' ) ) ) );
		$words = array_filter( preg_split( '/[^\p{L}\p{N}]+/u', mb_strtolower( $post->post_title . ' ' . LMGT_Text::plain( mb_substr( $post->post_content, 0, 3000 ) ) ) ), function ( $w ) { return mb_strlen( $w ) >= 5; } );
		$words = array_slice( array_keys( array_count_values( $words ) ), 0, 60 );
		$score = array();
		foreach ( array_unique( $ids ) as $pid ) {
			$t = mb_strtolower( get_the_title( $pid ) );
			$n = 0;
			foreach ( $words as $w ) if ( mb_strpos( $t, $w ) !== false ) $n++;
			if ( $n ) $score[ $pid ] = $n;
		}
		arsort( $score );
		$out = array();
		foreach ( array_slice( array_keys( $score ), 0, 40 ) as $pid ) $out[ html_entity_decode( get_the_title( $pid ), ENT_QUOTES, 'UTF-8' ) ] = get_permalink( $pid );
		return $out;
	}

	public static function handle_gap_draft() {
		$id = (int) $_POST['post_id'];
		check_admin_referer( 'lmgt_gap_draft_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$here   = get_post( $id );
		$is_tr  = $here && $here->post_type === LMGT_CPT;
		$src_id = $is_tr ? (int) get_post_meta( $id, '_lmgt_source', true ) : $id;
		if ( ! $src_id ) $src_id = $id; // 2.6.2: translation from the other site works on itself
		$target = $is_tr && isset( $_POST['target'] ) && $_POST['target'] === 'self' ? $id : $src_id;
		$back   = get_edit_post_link( $target, 'url' );
		$post   = get_post( $target );
		$g      = get_post_meta( $src_id, '_lmgt_gaps', true );
		$all    = is_array( $g ) && ! empty( $g['gaps'] ) ? array_values( $g['gaps'] ) : array();
		$gaps   = array();
		foreach ( (array) ( isset( $_POST['lmgt_gp'] ) ? $_POST['lmgt_gp'] : array() ) as $n ) {
			if ( isset( $all[ (int) $n ] ) ) $gaps[] = $all[ (int) $n ];
		}
		// 2.4.2: providers the editor ticked as checked, for a "who takes you there" section.
		$pall = is_array( $g ) && ! empty( $g['providers'] ) ? array_values( $g['providers'] ) : array();
		$prov = array();
		foreach ( (array) ( isset( $_POST['lmgt_pv'] ) ? $_POST['lmgt_pv'] : array() ) as $n ) {
			if ( isset( $pall[ (int) $n ] ) ) $prov[] = $pall[ (int) $n ];
		}
		if ( ! $post || ( ! $gaps && ! $prov ) ) self::back( get_edit_post_link( $id, 'url' ), 'Tick at least one gap.' );
		$lang = get_post_type( $target ) === LMGT_CPT ? (string) get_post_meta( $target, '_lmgt_lang', true ) : LMGT_Langs::source();
		$head = self::headings( $post->post_content );
		@set_time_limit( 200 );
		$links = self::link_candidates( $post, $lang );
		$r = LMGT_Engines::ai_json( LMGT_Engines::prompt_gap_sections( $lang, $post->post_title, mb_substr( LMGT_Text::plain( $post->post_content ), 0, 40000 ), $gaps, $head, $prov, $links ) );
		LMGT_Meter::charge( $id );
		if ( is_wp_error( $r ) ) self::back( get_edit_post_link( $id, 'url' ), $r->get_error_message() );
		$out = array();
		foreach ( (array) ( isset( $r['sections'] ) ? $r['sections'] : array() ) as $s ) {
			if ( empty( $s['heading'] ) || empty( $s['html'] ) ) continue;
			$after = isset( $s['after'] ) ? sanitize_text_field( $s['after'] ) : '';
			$html  = wp_kses( (string) $s['html'], array( 'p' => array(), 'ul' => array(), 'li' => array(), 'strong' => array(), 'em' => array(), 'a' => array( 'href' => true ) ) );
			// 2.7.1: only links to the site's own articles that were offered survive; any other link keeps its words.
			$ok   = array_map( 'untrailingslashit', array_values( $links ) );
			$html = preg_replace_callback( '#<a href="([^"]*)">(.*?)</a>#s', function ( $m ) use ( $ok ) { return in_array( untrailingslashit( $m[1] ), $ok, true ) ? $m[0] : $m[2]; }, $html );
			// 2.8.0 (G, 9 Nov): providers are linked to their own checked websites; the follow-up happens by mail (Translator → Outreach), not by a line on the page.
			$webs = array();
			foreach ( $prov as $pv ) if ( ! empty( $pv['web'] ) && ! empty( $pv['live'] ) ) $webs[] = untrailingslashit( $pv['web'] );
			if ( $webs ) $html = wp_kses( (string) $s['html'], array( 'p' => array(), 'ul' => array(), 'li' => array(), 'strong' => array(), 'em' => array(), 'a' => array( 'href' => true ) ) );
			$html = preg_replace_callback( '#<a href="([^"]*)">(.*?)</a>#s', function ( $m ) use ( $links, $webs ) { $u = untrailingslashit( $m[1] ); return in_array( $u, array_map( 'untrailingslashit', array_values( $links ) ), true ) || in_array( $u, $webs, true ) ? $m[0] : $m[2]; }, $html );
			$out[] = array(
				'heading' => sanitize_text_field( $s['heading'] ),
				'after'   => LMGT_Structure::match_heading( $after, $head ),
				'html'    => $html,
			);
		}
		if ( ! $out ) self::back( get_edit_post_link( $id, 'url' ), 'No sections came back. Try again.' );
		update_post_meta( $target, '_lmgt_gap_draft', wp_slash( array( 'sections' => $out, 'providers' => $prov, 'at' => current_time( 'mysql', true ) ) ) );
		self::back( $back, count( $out ) . ' section(s) written. Read them under "New sections to read"; nothing is added yet.' );
	}

	/**
	 * Where a section goes: before the next heading of the same or a higher level
	 * after the heading named in "after" (matched loosely, 2.2.29). With no usable
	 * heading, after the section whose words overlap most with the new one; else
	 * just before a practical part that closes the text, never after it. A heading
	 * inside a layout block takes the section inside that block, beside its own text.
	 */
	public static function place( $content, $after, $add_fn, array $section = array() ) {
		$blocks = strpos( $content, '<!-- wp:' ) !== false;
		$norm   = function ( $t ) { return mb_strtolower( trim( html_entity_decode( wp_strip_all_tags( $t ), ENT_QUOTES, 'UTF-8' ) ) ); };
		$heads  = self::headings( $content );
		$after  = LMGT_Structure::match_heading( (string) $after, $heads );
		if ( $after === '' && $section ) $after = LMGT_Structure::best_after( $content, $section );
		if ( $after !== '' && $section && LMGT_Structure::is_practical( $after ) && ! LMGT_Structure::is_practical( isset( $section['heading'] ) ? $section['heading'] : '' ) ) $after = '';
		if ( $after !== '' && preg_match_all( '#<h([1-6])[^>]*>(.*?)</h\1>#is', $content, $m, PREG_OFFSET_CAPTURE ) ) {
			foreach ( $m[0] as $i => $h ) {
				if ( $norm( $m[2][ $i ][0] ) !== $norm( $after ) ) continue;
				$level = (int) $m[1][ $i ][0];
				$end   = $h[1] + strlen( $h[0] );
				$at    = LMGT_Structure::end_point( $content, isset( $section['heading'] ) ? $section['heading'] : '' );
				if ( $at < $end ) $at = strlen( rtrim( $content ) );
				if ( preg_match( '#<h([1-' . $level . '])[\s>]#i', $content, $nx, PREG_OFFSET_CAPTURE, $end ) && $nx[0][1] < $at ) {
					$at = $nx[0][1];
					if ( $blocks && preg_match( '#<!-- wp:[a-z0-9/-]+(?: \{[^\n]*?\})? -->\s*$#', substr( $content, 0, $at ), $op, PREG_OFFSET_CAPTURE ) ) $at = $op[0][1];
				}
				if ( $blocks ) $at = LMGT_Structure::safe_point( $content, $end, $at );
				return rtrim( substr( $content, 0, $at ) ) . $add_fn( $level ) . "\n\n" . ltrim( substr( $content, $at ) );
			}
		}
		$at = LMGT_Structure::end_point( $content, isset( $section['heading'] ) ? $section['heading'] : '' );
		return rtrim( substr( $content, 0, $at ) ) . $add_fn( 2 ) . ( $at < strlen( rtrim( $content ) ) ? "\n\n" . ltrim( substr( $content, $at ) ) : '' );
	}

	/** A new section (heading + html), as blocks when the text uses blocks. */
	public static function section_markup( array $s, $blocks, $level ) {
		$level = max( 2, min( 4, (int) $level ) );
		if ( ! $blocks ) return "\n\n<h{$level}>" . esc_html( $s['heading'] ) . "</h{$level}>\n" . $s['html'];
		$out = "\n\n<!-- wp:heading" . ( $level !== 2 ? ' {"level":' . $level . '}' : '' ) . " -->\n<h{$level} class=\"wp-block-heading\">" . esc_html( $s['heading'] ) . "</h{$level}>\n<!-- /wp:heading -->";
		foreach ( preg_split( '#(?<=</p>|</ul>)\s*#', trim( $s['html'] ), -1, PREG_SPLIT_NO_EMPTY ) as $part ) {
			$out .= stripos( $part, '<ul' ) === 0 ? "\n\n<!-- wp:list -->\n" . $part . "\n<!-- /wp:list -->" : "\n\n<!-- wp:paragraph -->\n" . $part . "\n<!-- /wp:paragraph -->";
		}
		return $out;
	}

	public static function handle_gap_insert() {
		$id = (int) $_POST['post_id'];
		check_admin_referer( 'lmgt_gap_insert_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$back = get_edit_post_link( $id, 'url' );
		if ( isset( $_POST['do'] ) && $_POST['do'] === 'drop' ) {
			delete_post_meta( $id, '_lmgt_gap_draft' );
			self::back( $back, 'Sections discarded. Nothing was added.' );
		}
		$post = get_post( $id );
		$d    = get_post_meta( $id, '_lmgt_gap_draft', true );
		$pick = array_map( 'intval', (array) ( isset( $_POST['lmgt_gd'] ) ? $_POST['lmgt_gd'] : array() ) );
		if ( ! $post || ! is_array( $d ) || ! $pick ) self::back( $back, 'Nothing ticked.' );
		$blocks  = strpos( $post->post_content, '<!-- wp:' ) !== false;
		$content = $post->post_content;
		$added   = 0;
		foreach ( $pick as $n ) {
			if ( ! isset( $d['sections'][ $n ] ) ) continue;
			$s = $d['sections'][ $n ];
			$content = self::place( $content, isset( $s['after'] ) ? $s['after'] : '', function ( $level ) use ( $s, $blocks ) {
				return self::section_markup( $s, $blocks, $level );
			}, $s );
			$added++;
		}
		if ( ! $added ) self::back( $back, 'Nothing ticked.' );
		LMGT_Store::update_content( $id, array( 'post_content' => $content ) );
		delete_post_meta( $id, '_lmgt_reviewed' ); // 2.6.2: added text has not been read yet
		// 2.8.0: providers now on the page go onto the outreach list.
		foreach ( (array) ( isset( $d['providers'] ) ? $d['providers'] : array() ) as $pv ) if ( ! empty( $pv['web'] ) && strpos( $content, untrailingslashit( $pv['web'] ) ) !== false ) LMGT_Outreach::add( $pv, $id );
		delete_post_meta( $id, '_lmgt_gap_draft' );
		$msg = $added . ' section(s) added in place. The previous version is under Revisions.';
		if ( $post->post_type !== LMGT_CPT ) {
			$queued = 0;
			foreach ( array_keys( LMGT_Store::of( $id ) ) as $lang ) {
				if ( ! is_wp_error( LMGT_Jobs::add( $id, $lang ) ) ) $queued++;
			}
			if ( $queued ) $msg .= ' ' . $queued . ' language(s) queued for translation again.';
			delete_post_meta( $id, '_lmgt_gaps' );
		}
		self::back( $back, $msg );
	}

	/** 2.4.2: on traveltalk.dk, what the English version on traveltalk.travel has that this original lacks. A list to write from. */
	private static function box_en_extra( $post ) {
		if ( ! LMGT_Bridge::is_source() || ! LMGT_Engines::ai_available() || LMGT_Store::as_written( $post->ID ) ) return;
		$x = get_post_meta( $post->ID, '_lmgt_en_extra', true );
		echo '<hr><p><strong>English version</strong></p>';
		if ( is_array( $x ) ) {
			if ( empty( $x['parts'] ) ) {
				echo '<p style="color:#008a20">Nothing missing: this text covers what the <a href="' . esc_url( $x['url'] ) . '" target="_blank">English version</a> says (' . esc_html( $x['at'] ) . ' UTC).</p>';
			} else {
				echo '<p>The <a href="' . esc_url( $x['url'] ) . '" target="_blank">English version</a> has ' . count( $x['parts'] ) . ' part(s) this text lacks (' . esc_html( $x['at'] ) . ' UTC). Write them in Danish if they belong here; nothing is added by itself.</p><ul style="list-style:disc;margin-left:16px">';
				foreach ( $x['parts'] as $pt ) {
					echo '<li><strong>' . esc_html( $pt['heading'] ) . '</strong><br>' . esc_html( $pt['what'] ) . ( $pt['facts'] !== '' ? '<br><span class="description">Facts: ' . esc_html( $pt['facts'] ) . '</span>' : '' ) . '</li>';
				}
				echo '</ul>';
			}
		}
		$url = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_en_extra&post=' . $post->ID ), 'lmgt_en_extra_' . $post->ID );
		echo '<p><a class="button" href="' . esc_url( $url ) . '">' . ( is_array( $x ) ? 'Compare again' : 'What the English version has that this lacks' ) . '</a></p>';
	}

	public static function handle_en_extra() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_en_extra_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$back = get_edit_post_link( $id, 'url' );
		$post = get_post( $id );
		if ( ! $post ) self::back( $back, 'Article not found.' );
		$en = LMGT_Bridge::call( 'GET', '/english', array( 'source' => $id ), false );
		if ( is_wp_error( $en ) ) self::back( $back, $en->get_error_message() );
		if ( empty( $en['content'] ) ) self::back( $back, 'The English version is empty.' );
		@set_time_limit( 200 );
		$r = LMGT_Engines::ai_json( LMGT_Engines::prompt_en_extra(
			$post->post_title, mb_substr( LMGT_Text::plain( $post->post_content ), 0, 30000 ),
			(string) $en['title'], mb_substr( LMGT_Text::plain( $en['content'] ), 0, 30000 )
		) );
		if ( is_wp_error( $r ) ) self::back( $back, $r->get_error_message() );
		$parts = array();
		foreach ( (array) ( isset( $r['parts'] ) ? $r['parts'] : array() ) as $pt ) {
			if ( ! is_array( $pt ) || empty( $pt['heading'] ) ) continue;
			$parts[] = array( 'heading' => sanitize_text_field( $pt['heading'] ), 'what' => sanitize_text_field( isset( $pt['what'] ) ? $pt['what'] : '' ), 'facts' => sanitize_text_field( isset( $pt['facts'] ) ? $pt['facts'] : '' ) );
		}
		update_post_meta( $id, '_lmgt_en_extra', wp_slash( array( 'parts' => $parts, 'url' => esc_url_raw( (string) $en['url'] ), 'at' => current_time( 'mysql', true ) ) ) );
		self::back( $back, $parts ? count( $parts ) . ' part(s) in the English version that this text lacks. See "English version" in the Translations box.' : 'Nothing missing compared with the English version.' );
	}

	public static function handle_gaps() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_gaps_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$back = get_edit_post_link( $id, 'url' );
		$post = get_post( $id );
		if ( ! $post ) self::back( $back, 'Article not found.' );
		@set_time_limit( 200 );
		$r = LMGT_Engines::ai_json( LMGT_Engines::prompt_gaps( $post->post_type === LMGT_CPT ? (string) get_post_meta( $id, '_lmgt_lang', true ) : LMGT_Langs::source(), $post->post_title, mb_substr( LMGT_Text::plain( $post->post_content ), 0, 40000 ), LMGT_Engines::gap_context( $id ) ) );
		if ( is_wp_error( $r ) ) self::back( $back, $r->get_error_message() );
		LMGT_Store::set_gaps( $id, (array) ( isset( $r['gaps'] ) ? $r['gaps'] : array() ), (array) ( isset( $r['providers'] ) ? $r['providers'] : array() ) );
		self::back( $back, 'Content check done. See "What readers will miss" in the Translations box.' );
	}

	public static function handle_apply() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_apply_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		// 2.7.1: accepting replaces the whole text. If the text was edited after the waiting version
		// was made, stop and say so; "Accept anyway" goes through.
		$pd = get_post_meta( $id, '_lmgt_pending', true );
		if ( empty( $_GET['anyway'] ) && is_array( $pd ) && ! empty( $pd['at'] ) && LMGT_Stamps::edited_since( $id, '_lmgt_pending', $pd['at'] ) ) {
			$any = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_apply&anyway=1&post=' . $id ), 'lmgt_apply_' . $id );
			wp_die( '<h2>Not accepted – your edits would be lost</h2><p>You have edited this text after the waiting version was made (' . esc_html( $pd['at'] ) . ' UTC). Accepting would replace the whole text, and your additions (names, links, sections) would be gone.</p><p><a class="button button-primary" href="' . esc_url( get_edit_post_link( $id, 'url' ) ) . '">Back: keep my text</a> &nbsp; <a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_discard&post=' . $id ), 'lmgt_discard_' . $id ) ) . '">Reject the waiting version</a> &nbsp; <a class="button" href="' . esc_url( $any ) . '">Accept anyway</a></p><p class="description">Reject: your text stays as it is. Accept anyway: the waiting version replaces it; your text stays under Revisions.</p>', 'Not accepted', array( 'response' => 200 ) );
		}
		LMGT_Store::apply_pending( $id );
		delete_post_meta( $id, '_lmgt_reviewed' );
		wp_safe_redirect( get_edit_post_link( $id, 'url' ) );
		exit;
	}

	/** Drop the waiting version; the current text stays as it is. */
	public static function handle_discard() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_discard_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		delete_post_meta( $id, '_lmgt_pending' );
		self::back( get_edit_post_link( $id, 'url' ), 'Waiting version discarded. Your text is unchanged.' );
	}

	/**
	 * One AI call returns find/replace pairs for the flagged passages. Only pairs
	 * whose find text occurs exactly once, and whose tags are unchanged, are used.
	 * The result waits as a pending version; the live text is not touched.
	 */
	/** 2.17.4: the person has checked the numbers; the number flags leave the list (kept in the report as checked). */
	public static function handle_numbers_ok() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_numbers_ok_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$r = get_post_meta( $id, '_lmgt_report', true );
		if ( is_array( $r ) && ! empty( $r['numbers'] ) ) {
			$r['numbers_checked'] = array( 'numbers' => $r['numbers'], 'by' => get_current_user_id(), 'at' => current_time( 'mysql', true ) );
			$r['numbers'] = array( 'missing' => array(), 'extra' => array() );
			update_post_meta( $id, '_lmgt_report', wp_slash( $r ) );
		}
		self::back( get_edit_post_link( $id, 'url' ), 'Numbers marked as checked. ' . LMGT_Store::open_issues( $id ) . ' flag(s) left.' );
	}

	public static function handle_fix() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_fix_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$back   = get_edit_post_link( $id, 'url' );
		$post   = get_post( $id );
		$src    = get_post( (int) get_post_meta( $id, '_lmgt_source', true ) );
		$r      = get_post_meta( $id, '_lmgt_report', true );
		$issues = LMGT_Store::real_issues( $r );
		$all_issues = $issues;
		// 2.17.3: only the flags ticked under "Fix" (all when none were unticked).
		if ( ! empty( $_GET['only'] ) ) $issues = array_intersect_key( $issues, array_flip( array_map( 'intval', explode( '-', (string) $_GET['only'] ) ) ) );
		$orig   = $src ? $src->post_content : '';
		// 2.6.3: a translation that came from traveltalk.dk has its original there. Fetch it, or
		// the fix stopped at "Nothing to fix" and the flags stayed (G, 8 Nov).
		if ( ! $src && ( $rs = (int) get_post_meta( $id, '_lmgt_remote_source', true ) ) && class_exists( 'LMGT_Bridge' ) ) {
			$o = LMGT_Bridge::call( 'GET', '/original', array( 'id' => $rs ), false );
			if ( is_wp_error( $o ) ) self::back( $back, 'Could not read the original on traveltalk.dk: ' . $o->get_error_message() );
			$orig = isset( $o['content'] ) ? (string) $o['content'] : '';
		}
		// 2.17.4 (G, 14 Nov, Canada: "Nothing to fix" while 1 flag stayed): Fix only rewrites meaning, never numbers.
		if ( ! $issues && LMGT_Store::open_numbers( $id ) ) self::back( $back, 'The flag left is a number that differs from the original. Fix cannot change numbers: check it under Translation check, correct the text if needed, then press "Numbers are right – clear".' );
		if ( $post && $issues && $orig === '' ) self::back( $back, 'The original text could not be found, so Fix has nothing to compare with. Correct the flagged passages by hand, or tick "I have read the check – publish as it is".' );
		if ( ! $post || $orig === '' || ! $issues ) self::back( $back, 'Nothing to fix.' );

		@set_time_limit( 200 );
		$res = LMGT_Engines::ai_json( LMGT_Engines::prompt_fix(
			LMGT_Langs::source(), get_post_meta( $id, '_lmgt_lang', true ),
			LMGT_Text::plain( $orig ), $post->post_content, $issues
		) );
		LMGT_Meter::charge( $id );
		if ( is_wp_error( $res ) ) self::back( $back, $res->get_error_message() );

		$html = $post->post_content;
		$done = array();
		$miss = 0;
		$tags = 0;
		foreach ( (array) ( isset( $res['fixes'] ) ? $res['fixes'] : array() ) as $f ) {
			if ( ! isset( $f['issue'], $f['find'], $f['replace'] ) || ! isset( $issues[ (int) $f['issue'] ] ) ) continue;
			$find = (string) $f['find'];
			$rep  = (string) $f['replace'];
			$at   = self::locate( $html, $find );
			if ( ! $at && preg_match( '#^<p[^>]*>(.*)</p>$#s', $find, $m1 ) && preg_match( '#^<p[^>]*>(.*)</p>$#s', $rep, $m2 ) ) {
				// Classic-editor text has no <p> tags; the engine may have added them.
				$find = $m1[1];
				$rep  = $m2[1];
				$at   = self::locate( $html, $find );
			}
			if ( ! $at ) { $miss++; continue; }
			$span = substr( $html, $at[0], $at[1] );
			preg_match_all( '/<[^>]+>|<!--.*?-->/s', $span, $a );
			preg_match_all( '/<[^>]+>|<!--.*?-->/s', $rep, $b );
			if ( $a[0] !== $b[0] ) { $tags++; continue; }
			$html = substr_replace( $html, $rep, $at[0], $at[1] );
			$done[ (int) $f['issue'] ] = true;
		}
		// 2.6.3: passages the fix judged as wording only are not errors; they leave the list too.
		foreach ( (array) ( isset( $res['skipped'] ) ? $res['skipped'] : array() ) as $sk ) if ( isset( $issues[ (int) $sk ] ) ) $done[ (int) $sk ] = true;
		if ( $html === $post->post_content && $done ) {
			$r['issues'] = array_values( array_diff_key( $all_issues, $done ) );
			update_post_meta( $id, '_lmgt_report', wp_slash( $r ) );
			self::back( $back, count( $done ) . ' flag(s) judged as wording only and cleared. ' . count( $r['issues'] ) . ' left.' );
		}
		if ( ! $done ) {
			$skip = isset( $res['skipped'] ) ? count( (array) $res['skipped'] ) : 0;
			$why  = array();
			if ( $skip ) $why[] = $skip . ' judged as wording only';
			if ( $miss ) $why[] = $miss . ' not found in the text';
			if ( $tags ) $why[] = $tags . ' would have changed the layout';
			self::back( $back, 'No passage changed' . ( $why ? ' (' . implode( ', ', $why ) . ')' : '' ) . '. Fix any real errors by hand.' );
		}

		$report           = $r;
		$report['issues'] = array_values( array_diff_key( $all_issues, $done ) );
		$report['notes'][] = count( $done ) . ' flagged passage(s) corrected by ' . LMGT_Engines::ai_label() . ' on ' . current_time( 'mysql', true ) . ' UTC.';
		update_post_meta( $id, '_lmgt_pending', wp_slash( array(
			'translation' => array(
				'title'     => $post->post_title,
				'content'   => $html,
				'excerpt'   => $post->post_excerpt,
				'seo_title' => (string) get_post_meta( $id, 'rank_math_title', true ),
				'seo_desc'  => (string) get_post_meta( $id, 'rank_math_description', true ),
			),
			'report'          => $report,
			'source_modified' => get_post_meta( $id, '_lmgt_source_modified', true ),
			'at'              => current_time( 'mysql', true ),
			'kind'            => 'fix',
		) ) );
		self::back( $back, sprintf( '%d of %d flagged passages corrected. Apply the waiting version at the top of "Translation check"; the current text stays under Revisions.', count( $done ), count( $issues ) ) );
	}

	/** Write the ticked suggestions into the original; each only where its text occurs exactly once. */
	public static function handle_suggest() {
		$id = (int) $_POST['post_id'];
		check_admin_referer( 'lmgt_suggest_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$back  = get_edit_post_link( $id, 'url' );
		$post  = get_post( $id );
		$notes = get_post_meta( $id, '_lmgt_original_notes', true );
		$pick  = array_map( 'sanitize_text_field', (array) ( isset( $_POST['lmgt_sg'] ) ? wp_unslash( $_POST['lmgt_sg'] ) : array() ) );
		if ( ! $post || ! is_array( $notes ) || ! $pick ) self::back( $back, 'Nothing ticked.' );

		$html = $post->post_content;
		$ok   = 0;
		$miss = array();
		foreach ( $pick as $key ) {
			list( $code, $n ) = array_pad( explode( ':', $key, 2 ), 2, '' );
			if ( ! isset( $notes[ $code ][ (int) $n ] ) ) continue;
			$s    = $notes[ $code ][ (int) $n ];
			if ( ! LMGT_Store::real_suggestions( array( $s ) ) ) continue;
			$from = isset( $s['text'] ) ? (string) $s['text'] : '';
			$to   = isset( $s['suggestion'] ) ? (string) $s['suggestion'] : '';
			$hit  = false;
			// The check read plain text; the article stores HTML with typographic entities.
			foreach ( array_unique( array( $from, esc_html( $from ), str_replace( "'", '&#8217;', $from ) ) ) as $f ) {
				if ( $f !== '' && $to !== '' && substr_count( $html, $f ) === 1 ) {
					$html = str_replace( $f, $to, $html );
					$hit  = true;
					break;
				}
			}
			if ( $hit ) {
				$ok++;
				unset( $notes[ $code ][ (int) $n ] );
			} else {
				$miss[] = $from;
			}
		}
		if ( $ok ) {
			LMGT_Store::update_content( $id, array( 'post_content' => $html ) );
			$notes = array_filter( array_map( 'array_values', $notes ) );
			if ( $notes ) update_post_meta( $id, '_lmgt_original_notes', wp_slash( $notes ) );
			else delete_post_meta( $id, '_lmgt_original_notes' );
		}
		$msg = $ok . ' suggestion(s) written into the article.';
		if ( $miss ) $msg .= ' Not found exactly once, change by hand: "' . implode( '"; "', array_map( function ( $t ) { return mb_substr( $t, 0, 60 ); }, $miss ) ) . '".';
		self::back( $back, $msg );
	}

	/**
	 * Where $find occurs in $html: [offset, length], or null unless exactly once.
	 * Tolerates what an engine changes when it quotes: runs of spaces and line
	 * breaks, curly or straight quotes, dashes, and their HTML entities.
	 */
	public static function locate( $html, $find ) {
		if ( trim( $find ) === '' ) return null;
		if ( substr_count( $html, $find ) === 1 ) return array( strpos( $html, $find ), strlen( $find ) );
		$sq = "(?:'|’|‘|&#8217;|&#8216;|&#039;|&rsquo;|&lsquo;)";
		$dq = '(?:"|“|”|„|&#8220;|&#8221;|&quot;|&ldquo;|&rdquo;)';
		$da = '(?:-|–|—|&#8211;|&#8212;|&ndash;|&mdash;)';
		$re = '';
		foreach ( preg_split( '/(\s+|&nbsp;|&#8217;|&#8216;|&#039;|&#8220;|&#8221;|&quot;|&#8211;|&#8212;|&amp;)|/u', trim( $find ), -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY ) as $c ) {
			if ( preg_match( '/^(\s+|&nbsp;)$/u', $c ) )                                      $re .= '(?:\s|&nbsp;)+';
			elseif ( in_array( $c, array( "'", '’', '‘', '&#8217;', '&#8216;', '&#039;' ), true ) ) $re .= $sq;
			elseif ( in_array( $c, array( '"', '“', '”', '„', '&#8220;', '&#8221;', '&quot;' ), true ) ) $re .= $dq;
			elseif ( in_array( $c, array( '-', '–', '—', '&#8211;', '&#8212;' ), true ) )        $re .= $da;
			elseif ( $c === '&' || $c === '&amp;' )                                             $re .= '(?:&|&amp;)';
			else                                                                               $re .= preg_quote( $c, '/' );
		}
		if ( ! preg_match_all( '/' . $re . '/u', $html, $m, PREG_OFFSET_CAPTURE ) || count( $m[0] ) !== 1 ) return null;
		return array( $m[0][0][1], strlen( $m[0][0][0] ) );
	}

	private static function back( $url, $msg ) {
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $msg ), $url ) );
		exit;
	}

	// ---- Translation list columns ------------------------------------------------

	public static function columns( $c ) {
		$new = array();
		foreach ( $c as $k => $v ) {
			$new[ $k ] = $v;
			if ( $k === 'title' ) {
				$new['lmgt_lang']   = 'Language';
				$new['lmgt_source'] = 'Original';
				$new['lmgt_flags']  = 'Flags';
			}
		}
		return $new;
	}

	public static function column( $col, $id ) {
		if ( $col === 'lmgt_lang' ) {
			$l = LMGT_Langs::get( get_post_meta( $id, '_lmgt_lang', true ) );
			echo esc_html( $l ? $l['name'] : '?' );
		}
		if ( $col === 'lmgt_source' ) {
			$remote = get_post_meta( $id, '_lmgt_remote_url', true );
			if ( $remote ) {
				echo '<a href="' . esc_url( $remote ) . '" target="_blank">' . esc_html( wp_parse_url( $remote, PHP_URL_PATH ) ) . '</a>';
				$c = get_post_meta( $id, '_lmgt_mother_changed', true );
				if ( is_array( $c ) ) echo '<br><span style="color:#996800">Mother text changed ' . esc_html( substr( $c['at'], 0, 10 ) ) . '</span>';
				// 2.2.17: a newer version that waits on the edit screen is easy to miss.
				$w = get_post_meta( $id, '_lmgt_pending', true );
				if ( is_array( $w ) && ! empty( $w['translation'] ) ) echo '<br><span style="color:#b32d2e">Newer version waiting – open to apply</span>';
				return;
			}
			$s = (int) get_post_meta( $id, '_lmgt_source', true );
			echo '<a href="' . esc_url( get_edit_post_link( $s ) ) . '">' . esc_html( get_the_title( $s ) ) . '</a>';
			$p = get_post( $s );
			if ( $p && get_post_meta( $id, '_lmgt_source_modified', true ) !== $p->post_modified_gmt ) echo '<br><span style="color:#996800">original changed since</span>';
		}
		if ( $col === 'lmgt_flags' ) {
			$n = LMGT_Store::open_issues( $id );
			echo $n ? '<span style="color:#b32d2e">' . (int) $n . '</span>' . ( LMGT_Store::is_reviewed( $id ) ? ' (read)' : '' ) : '0';
		}
	}

	// ---- Settings ----------------------------------------------------------------

	public static function page_settings() {
		$on = (array) get_option( 'lmgt_languages', array( 'sv' ) );
		$o  = function ( $k, $d ) { return get_option( $k, $d ); };
		echo '<div class="wrap"><h1>Translator settings</h1><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'lmgt_settings' );
		echo '<input type="hidden" name="action" value="lmgt_settings"><table class="form-table">';
		echo '<tr><th>Source language</th><td>' . esc_html( LMGT_Langs::get( LMGT_Langs::source() )['name'] ) . ' <span class="description">(the site\'s own language; originals are never changed)</span></td></tr>';
		echo '<tr><th>Translate into</th><td>';
		foreach ( LMGT_Langs::all() as $code => $l ) {
			if ( $code === LMGT_Langs::source() ) continue;
			echo '<label style="display:inline-block;min-width:150px"><input type="checkbox" name="lmgt_languages[]" value="' . esc_attr( $code ) . '" ' . checked( in_array( $code, $on, true ), true, false ) . '> ' . esc_html( $l['name'] ) . ' <code>/' . esc_html( $l['prefix'] ) . '/</code></label> ';
		}
		echo '</td></tr>';
		$cands = LMGT_Store::candidates();
		if ( $cands ) {
			$ex = LMGT_Store::extra();
			echo '<tr><th>Post types</th><td><input type="hidden" name="lmgt_extra_types_box" value="1"><span class="description">Posts and pages always. Also:</span><br>';
			foreach ( $cands as $name => $ob ) echo '<label style="display:inline-block;min-width:200px"><input type="checkbox" name="lmgt_extra_types[]" value="' . esc_attr( $name ) . '" ' . checked( in_array( $name, $ex, true ), true, false ) . '> ' . esc_html( $ob->label ) . ' <code>' . esc_html( $name ) . '</code></label> ';
			echo '<p class="description">Ticked types get the Translations box, Suggest extra content, Structure, Pictures, the correction function and the queue, and count as hubs (1500 words).</p></td></tr>';
		}
		echo '<tr><th>DeepL key</th><td><input type="password" name="lmgt_deepl_key" class="regular-text" autocomplete="off" placeholder="' . ( LMGT_Engines::deepl_available() ? 'saved — leave empty to keep' : 'not set' ) . '"></td></tr>';
		echo '<tr><th>Gemini key</th><td><input type="password" name="lmgt_gemini_key" class="regular-text" autocomplete="off" placeholder="' . ( trim( (string) get_option( 'lmgt_gemini_key', '' ) ) !== '' ? 'saved — leave empty to keep' : 'not set' ) . '"></td></tr>';
		echo '<tr><th>Gemini model</th><td><input type="text" name="lmgt_gemini_model" value="' . esc_attr( LMGT_Engines::gemini_model() ) . '" class="regular-text"><p class="description">If Google retires it, the queue stops with "model not found" — put the current model name here.</p></td></tr>';
		echo '<tr><th>Claude key</th><td><input type="password" name="lmgt_claude_key" class="regular-text" autocomplete="off" placeholder="' . ( get_option( 'lmgt_claude_key', '' ) !== '' ? 'saved — leave empty to keep' : ( LMGT_Engines::claude_key() !== '' ? 'using the LeisureIntel key' : 'not set' ) ) . '"></td></tr>';
		echo '<tr><th>Claude model</th><td><input type="text" name="lmgt_claude_model" value="' . esc_attr( LMGT_Engines::claude_model() ) . '" class="regular-text"><p class="description">Agreed 26 Oct 2026: Claude translates (Claude only, no DeepL), model claude-haiku-5-5. Change only by a new decision in briefs/STATUS.md.</p></td></tr>';
		echo '<tr><th>AI engine</th><td><select name="lmgt_ai">';
		foreach ( array( 'gemini' => 'Gemini', 'claude' => 'Claude' ) as $k => $v ) echo '<option value="' . $k . '" ' . selected( $o( 'lmgt_ai', 'claude' ), $k, false ) . '>' . esc_html( $v ) . '</option>';
		echo '</select><p class="description">Translates, polishes, back-translates and checks. Switch at any time; existing translations are kept.</p></td></tr>';
		$ai = LMGT_Engines::ai_name();
		echo '<tr><th>Translation engine</th><td><select name="lmgt_engine">';
		foreach ( array( 'auto' => "DeepL while the allowance lasts, then {$ai}", 'deepl' => 'DeepL only', 'gemini' => "{$ai} only" ) as $k => $v ) echo '<option value="' . $k . '" ' . selected( $o( 'lmgt_engine', 'gemini' ), $k, false ) . '>' . esc_html( $v ) . '</option>';
		echo '</select></td></tr>';
		echo '<tr><th>Polish with ' . $ai . '</th><td><label><input type="checkbox" name="lmgt_polish" value="1" ' . checked( $o( 'lmgt_polish', '1' ), '1', false ) . '> ' . $ai . ' edits DeepL\'s draft into natural language</label></td></tr>';
		echo '<tr><th>Back-translation check</th><td><label><input type="checkbox" name="lmgt_backcheck" value="1" ' . checked( $o( 'lmgt_backcheck', '1' ), '1', false ) . '> Translate back and compare with the original</label><br>';
		echo 'Back-translate with <select name="lmgt_back_engine"><option value="gemini" ' . selected( $o( 'lmgt_back_engine', 'gemini' ), 'gemini', false ) . '>' . $ai . ' (saves DeepL allowance)</option><option value="deepl" ' . selected( $o( 'lmgt_back_engine', 'gemini' ), 'deepl', false ) . '>DeepL (independent of the polish)</option></select></td></tr>';
		echo '<tr><th>Language switcher</th><td><label><input type="checkbox" name="lmgt_switcher" value="1" ' . checked( $o( 'lmgt_switcher', '1' ), '1', false ) . '> Show "Sprogvalg" in the lower-left corner on pages that have translations</label></td></tr>';
		echo '<tr><th>Between the two sites</th><td><label><input type="checkbox" name="lmgt_switcher_newwin" value="1" ' . checked( $o( 'lmgt_switcher_newwin', '1' ), '1', false ) . '> Open the language menu\'s links to the other site in a new window (both sites)</label><br>'
			. '<label><input type="checkbox" name="lmgt_english_offer" value="1" ' . checked( $o( 'lmgt_english_offer', '1' ), '1', false ) . '> traveltalk.dk: offer "Read this page in English" to visitors whose browser lists no Danish. They choose; nothing moves them</label><br>'
			. '<label><input type="checkbox" name="lmgt_back_chip" value="1" ' . checked( $o( 'lmgt_back_chip', '1' ), '1', false ) . '> traveltalk.travel: show "Back to traveltalk.dk" to visitors who came from traveltalk.dk</label><br>'
			. '<label><input type="checkbox" name="lmgt_welcome" value="1" ' . checked( $o( 'lmgt_welcome', '1' ), '1', false ) . '> traveltalk.travel: a short welcome note, once per visitor (60 days), on translated pages</label>'
			. '<p class="description">To look at a note without being the right visitor: add <code>#lmg-offer</code> to the end of any traveltalk.dk address, or <code>#lmg-back</code> to any traveltalk.travel address.</p></td></tr>';
		echo '<tr><th>New articles</th><td>'
			. '<label><input type="checkbox" name="lmgt_auto_new" value="1" ' . checked( $o( 'lmgt_auto_new', '1' ), '1', false ) . '> About 30 minutes after a new article is published, translate it into every language ticked above, in the background</label><br>'
			. '<label><input type="checkbox" name="lmgt_auto_publish" value="1" ' . checked( $o( 'lmgt_auto_publish', '1' ), '1', false ) . '> Publish those translations without waiting for review (they are listed under Auto-published until looked at)</label><br>'
			. '<label><input type="checkbox" name="lmgt_auto_hold" value="1" ' . checked( $o( 'lmgt_auto_hold', '1' ), '1', false ) . '> Hold back as a draft any the check flagged (language doubt, changed numbers, gaps)</label><br>'
			. 'E-mail about them to <input type="email" name="lmgt_notify_email" value="' . esc_attr( (string) get_option( 'lmgt_notify_email', '' ) ) . '" class="regular-text" placeholder="' . esc_attr( get_option( 'admin_email' ) ) . '"> (empty = the site administrator)'
			. '<p class="description">Applies to articles published from now on. The work runs on the site where the article is written; the list and the e-mail live on traveltalk.travel.</p></td></tr>';
		echo '<tr><th>Language front pages</th><td><label><input type="checkbox" name="lmgt_lang_front" value="1" ' . checked( $o( 'lmgt_lang_front', '1' ), '1', false ) . '> /en/, /sv/ … open with a front page: hero, translated guides, latest articles</label><br>'
			. 'Paired with the front page in hreflang from <input type="number" name="lmgt_front_min" min="1" step="1" value="' . esc_attr( max( 1, (int) get_option( 'lmgt_front_min', 3 ) ) ) . '" class="small-text"> published versions in that language</td></tr>';
		echo '<tr><th>Minimum words</th><td>Article <input type="number" name="lmgt_min_words" min="100" step="50" value="' . esc_attr( max( 100, (int) get_option( 'lmgt_min_words', 800 ) ) ) . '" class="small-text"> '
			. 'Pillar <input type="number" name="lmgt_min_words_pillar" min="100" step="100" value="' . esc_attr( max( 100, (int) get_option( 'lmgt_min_words_pillar', 1500 ) ) ) . '" class="small-text">'
			. '<p class="description">Below this, the Words column and the article say "thin". Pillar = every Page, and posts with Rank Math\'s "This post is Pillar Content".</p></td></tr>';
		if ( LMGT_Bridge::is_target() ) echo '<tr><th>Noindex thin translations</th><td>Under <input type="number" name="lmgt_noindex_under" min="0" step="50" value="' . esc_attr( (int) get_option( 'lmgt_noindex_under', 800 ) ) . '" class="small-text"> words<p class="description">Published translations under this are readable but carry noindex, stay out of the sitemap and out of hreflang until they reach it. <strong>0 switches it off: every translation is indexed</strong> (G, 31 Oct 2026). Changing it re-reports the affected translations to traveltalk.dk a few at a time' . ( ( $rq = count( (array) get_option( 'lmgt_rethin_queue', array() ) ) ) ? ' <em>(' . (int) $rq . ' still waiting)</em>' : '' ) . '.</p></td></tr>';
		echo '<tr><th>Find pictures</th><td><label><input type="checkbox" name="lmgt_find_strict" value="1" ' . checked( $o( 'lmgt_find_strict', '1' ), '1', false ) . '> When a heading gives three or more search words, a picture must match at least two of them</label><p class="description">Off: one matching word is enough (more suggestions, more of them off the mark). Words are matched whole either way (2.2.27).</p></td></tr>';
		echo '<tr><th>A picture at least every</th><td><input type="number" name="lmgt_picture_every" min="100" step="50" value="' . esc_attr( LMGT_Pictures::every() ) . '" class="small-text"> words<p class="description">Longer stretches without a picture are named in the Pictures box and the Pictures column (2.2.7).</p></td></tr>';
		echo '<tr><th>Read more block</th><td><input type="hidden" name="lmgt_struct_form" value="1"><label><input type="checkbox" name="lmgt_readmore" value="1"' . checked( get_option( 'lmgt_readmore', 1 ), 1, false ) . '> At the end of every article, page and translation: Read more about the place, its region and related travel interests (2.2.29)</label>'
			. '<p><label>Travel Interests page ID <input type="number" name="lmgt_rm_interests" value="' . esc_attr( get_option( 'lmgt_rm_interests', LMGT_Bridge::is_target() ? 84 : 0 ) ) . '" class="small-text"></label> <span class="description">Its subpages are the interests offered. 0 = none.</span></p>'
			. '<p><label>Travel Interests category ID <input type="number" name="lmgt_rm_interests_cat" value="' . esc_attr( get_option( 'lmgt_rm_interests_cat', 0 ) ) . '" class="small-text"></label> <span class="description">For a site where the interests are categories (traveltalk.dk: Rejseinteresser, 3053). Its sub-categories are offered, in the site\'s own language. 0 = none.</span></p>'
			. '<p><label><input type="checkbox" name="lmgt_top" value="1"' . checked( get_option( 'lmgt_top', 1 ), 1, false ) . '> Most read about the place, inside the block: the five related texts with the most readers in the last 30 days (2.3.0)</label></p>'
			. '<p><label>Destinations page ID <input type="number" name="lmgt_rm_hub" value="' . esc_attr( get_option( 'lmgt_rm_hub', LMGT_Bridge::is_target() ? 79 : 0 ) ) . '" class="small-text"></label> <span class="description">Linked as "Read more about …" by texts that have no place or region of their own (2.2.31). 0 = none.</span></p>'
			. '<p><label>Never link these page IDs <input type="text" name="lmgt_rm_skip" value="' . esc_attr( get_option( 'lmgt_rm_skip', LMGT_Bridge::is_target() ? '79,84' : '' ) ) . '"></label> <span class="description">Top pages that are not places, such as Travel Destinations.</span></p></td></tr>';
		if ( LMGT_Bridge::is_target() ) echo '<tr><th>Front page</th><td><label><input type="checkbox" name="lmgt_front_translations" value="1"' . checked( get_option( 'lmgt_front_translations', 1 ), 1, false ) . '> English translations of articles are listed with the site\'s own posts: front page, blog, feed and latest-posts blocks (2.2.29)</label></td></tr>';
		$gl = (array) get_option( 'lmgt_glossary', array() );
		echo '<tr><th>Glossary</th><td><p class="description">Fixed terms per language, one per line: <code>source term = term in that language</code>. Added to every translation and polish (brief 4.14).</p>';
		foreach ( LMGT_Langs::all() as $code => $l ) {
			if ( $code === LMGT_Langs::source() || ! in_array( $code, $on, true ) ) continue;
			echo '<p><label>' . esc_html( $l['name'] ) . '<br><textarea name="lmgt_glossary[' . esc_attr( $code ) . ']" rows="3" class="large-text code">' . esc_textarea( isset( $gl[ $code ] ) ? $gl[ $code ] : '' ) . '</textarea></label></p>';
		}
		echo '</td></tr>';
		if ( LMGT_Bridge::is_target() ) echo '<tr><th>Danish-only blocks</th><td><textarea name="lmgt_danish_only" rows="6" class="regular-text code">' . esc_textarea( get_option( 'lmgt_danish_only', LMGT_Sync::DANISH_ONLY ) ) . '</textarea><p class="description">Hidden on translations: shortcode names (the whole block goes) and link domains (the link goes, its text stays), one per line. Shortcodes this site does not have are hidden too. G, 27 Oct 2026: no GetYourGuide on translations; main clients first.</p></td></tr>';
		echo '<tr><th>Run without the page open</th><td><label><input type="checkbox" name="lmgt_cron" value="1" ' . checked( $o( 'lmgt_cron', '0' ), '1', false ) . '> Let WP-Cron work the whole queue in the background</label><p class="description">Off by default. Results are still only drafts. Translate everything and new articles run in the background without it; workers at a time: Translator → Translate everything.</p></td></tr>';
		echo '</table>';
		submit_button();
		echo '</form></div>';
	}

	public static function handle_settings() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Not allowed.' );
		check_admin_referer( 'lmgt_settings' );
		$langs = array_values( array_intersect( array_map( 'sanitize_key', (array) ( isset( $_POST['lmgt_languages'] ) ? $_POST['lmgt_languages'] : array() ) ), array_keys( LMGT_Langs::all() ) ) );
		update_option( 'lmgt_languages', $langs, false );
		foreach ( array( 'lmgt_deepl_key', 'lmgt_gemini_key', 'lmgt_claude_key' ) as $k ) {
			$v = isset( $_POST[ $k ] ) ? trim( wp_unslash( $_POST[ $k ] ) ) : '';
			if ( $v !== '' ) update_option( $k, sanitize_text_field( $v ), false );
		}
		update_option( 'lmgt_gemini_model', sanitize_text_field( wp_unslash( $_POST['lmgt_gemini_model'] ) ), false );
		update_option( 'lmgt_claude_model', sanitize_text_field( wp_unslash( $_POST['lmgt_claude_model'] ) ), false );
		update_option( 'lmgt_ai', isset( $_POST['lmgt_ai'] ) && $_POST['lmgt_ai'] === 'claude' ? 'claude' : 'gemini', false );
		update_option( 'lmgt_engine', in_array( $_POST['lmgt_engine'], array( 'auto', 'deepl', 'gemini' ), true ) ? $_POST['lmgt_engine'] : 'auto', false );
		update_option( 'lmgt_back_engine', $_POST['lmgt_back_engine'] === 'deepl' ? 'deepl' : 'gemini', false );
		update_option( 'lmgt_min_words', max( 100, (int) ( isset( $_POST['lmgt_min_words'] ) ? $_POST['lmgt_min_words'] : 800 ) ), false );
		update_option( 'lmgt_min_words_pillar', max( 100, (int) ( isset( $_POST['lmgt_min_words_pillar'] ) ? $_POST['lmgt_min_words_pillar'] : 1500 ) ), false );
		update_option( 'lmgt_front_min', max( 1, (int) ( isset( $_POST['lmgt_front_min'] ) ? $_POST['lmgt_front_min'] : 3 ) ), false );
		if ( isset( $_POST['lmgt_noindex_under'] ) ) {
			$old_min = (int) get_option( 'lmgt_noindex_under', 800 );
			$new_min = max( 0, (int) $_POST['lmgt_noindex_under'] );
			update_option( 'lmgt_noindex_under', $new_min, false );
			if ( $old_min !== $new_min ) LMGT_Bridge::threshold_changed( $old_min, $new_min );
		}
		if ( isset( $_POST['lmgt_picture_every'] ) ) update_option( 'lmgt_picture_every', max( 100, (int) $_POST['lmgt_picture_every'] ), false );
		if ( ! empty( $_POST['lmgt_struct_form'] ) ) {
			update_option( 'lmgt_readmore', empty( $_POST['lmgt_readmore'] ) ? 0 : 1, false );
			update_option( 'lmgt_rm_interests', max( 0, (int) $_POST['lmgt_rm_interests'] ), false );
			update_option( 'lmgt_top', empty( $_POST['lmgt_top'] ) ? 0 : 1, false );
			update_option( 'lmgt_rm_hub', max( 0, (int) $_POST['lmgt_rm_hub'] ), false );
			update_option( 'lmgt_rm_interests_cat', max( 0, (int) $_POST['lmgt_rm_interests_cat'] ), false );
			update_option( 'lmgt_rm_skip', implode( ',', array_filter( array_map( 'intval', preg_split( '/[\s,]+/', (string) wp_unslash( $_POST['lmgt_rm_skip'] ) ) ) ) ), false );
			if ( LMGT_Bridge::is_target() ) update_option( 'lmgt_front_translations', empty( $_POST['lmgt_front_translations'] ) ? 0 : 1, false );
			do_action( 'litespeed_purge_all' );
		}
		if ( ! empty( $_POST['lmgt_extra_types_box'] ) ) update_option( 'lmgt_extra_types', array_values( array_intersect( array_map( 'sanitize_key', (array) ( isset( $_POST['lmgt_extra_types'] ) ? wp_unslash( $_POST['lmgt_extra_types'] ) : array() ) ), array_keys( LMGT_Store::candidates() ) ) ), false );
		update_option( 'lmgt_notify_email', isset( $_POST['lmgt_notify_email'] ) ? sanitize_email( wp_unslash( $_POST['lmgt_notify_email'] ) ) : '', false );
		// Languages switched off keep their glossary.
		$gl = (array) get_option( 'lmgt_glossary', array() );
		foreach ( (array) ( isset( $_POST['lmgt_glossary'] ) ? wp_unslash( $_POST['lmgt_glossary'] ) : array() ) as $code => $text ) {
			if ( LMGT_Langs::get( $code ) ) $gl[ $code ] = sanitize_textarea_field( $text );
		}
		update_option( 'lmgt_glossary', $gl, false );
		if ( isset( $_POST['lmgt_danish_only'] ) ) update_option( 'lmgt_danish_only', sanitize_textarea_field( wp_unslash( $_POST['lmgt_danish_only'] ) ), false );
		foreach ( array( 'lmgt_polish', 'lmgt_backcheck', 'lmgt_switcher', 'lmgt_switcher_newwin', 'lmgt_english_offer', 'lmgt_back_chip', 'lmgt_welcome', 'lmgt_auto_new', 'lmgt_auto_publish', 'lmgt_auto_hold', 'lmgt_cron', 'lmgt_lang_front', 'lmgt_find_strict' ) as $k ) update_option( $k, empty( $_POST[ $k ] ) ? '0' : '1', false );
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( 'Settings saved.' ), admin_url( 'admin.php?page=lmgt-settings' ) ) );
		exit;
	}

	// ---- Cleanup of the old plugin's data ------------------------------------------

	private static function legacy_rows() {
		global $wpdb;
		return $wpdb->get_results( "SELECT post_id, COUNT(*) AS n FROM {$wpdb->postmeta} WHERE meta_key LIKE '\\_tt\\_translated\\_%' GROUP BY post_id" );
	}

	public static function page_cleanup() {
		$rows = self::legacy_rows();
		$n = 0;
		foreach ( $rows as $r ) $n += (int) $r->n;
		echo '<div class="wrap"><h1>Clean up the old translator</h1>';
		echo '<p>"Traveltalk AI Translator" stored its translations as hidden fields inside the originals (<code>_tt_translated_title_xx</code>, <code>_tt_translated_content_xx</code>). They are not pages, have no value to Google, and some hold the wrong language.</p>';
		if ( ! $rows ) { echo '<p><strong>Nothing to clean: no old translation fields found.</strong></p></div>'; return; }
		echo '<p><strong>' . (int) $n . ' old fields on ' . count( $rows ) . ' article(s):</strong></p><ul style="list-style:disc;margin-left:18px">';
		foreach ( $rows as $r ) echo '<li><a href="' . esc_url( get_edit_post_link( $r->post_id ) ) . '">' . esc_html( get_the_title( $r->post_id ) ) . '</a> — ' . (int) $r->n . ' field(s)</li>';
		echo '</ul><p>Deleting removes only these fields. The articles themselves, their text, title and everything else stay exactly as they are.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(\'Delete ' . (int) $n . ' old translation fields? Articles are not touched.\');">';
		wp_nonce_field( 'lmgt_cleanup' );
		echo '<input type="hidden" name="action" value="lmgt_cleanup"><input type="hidden" name="expect" value="' . (int) $n . '">';
		submit_button( 'Delete the ' . (int) $n . ' old fields', 'delete' );
		echo '</form></div>';
	}

	public static function handle_cleanup() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Not allowed.' );
		check_admin_referer( 'lmgt_cleanup' );
		global $wpdb;
		$like = $wpdb->esc_like( '_tt_translated_' ) . '%';
		$now  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key LIKE %s", $like ) );
		// The count shown must be the count deleted. If it moved, show the page again.
		if ( $now !== (int) $_POST['expect'] ) {
			wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( 'The number of old fields changed since the page was shown. Nothing deleted — check again.' ), admin_url( 'admin.php?page=lmgt-cleanup' ) ) );
			exit;
		}
		$deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE %s", $like ) );
		wp_cache_flush();
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( (int) $deleted . ' old translation fields deleted. No article was changed.' ), admin_url( 'admin.php?page=lmgt-cleanup' ) ) );
		exit;
	}
}
