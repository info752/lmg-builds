<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * The queue. One job = one article into one language, worked through in small
 * steps of one engine call each, so no single page load can time out halfway
 * and leave a half-updated article behind (the old bulk action ran 800 calls in
 * one request).
 *
 * Stages: prepare → translate → polish → check → back → compare → save.
 * Any stage can fail; a failed job saves nothing and says why.
 *
 * Runs while the Translator page is open in wp-admin, and in the background
 * for automatic jobs (new articles), plan jobs (Translate everything) and,
 * with "Run without the page open", everything.
 *
 * 2.2.26: several jobs at once. Each job has its own lock (a row in the
 * options table, taken with one atomic insert), so up to "Workers at a time"
 * background workers each take a different job. Every minute WP-Cron works
 * as worker 1 and wakes the others with a request to admin-ajax.php that it
 * does not wait for; a worker that finds more work wakes itself again.
 */
class LMGT_Jobs {

	const LIST_OPT = 'lmgt_jobs';

	public static function boot() {
		add_action( 'wp_ajax_lmgt_step', array( __CLASS__, 'ajax_step' ) );
		add_filter( 'cron_schedules', function ( $s ) {
			$s['lmgt_minute'] = array( 'interval' => 60, 'display' => 'Every minute (LMG Translator)' );
			return $s;
		} );
		add_action( 'lmgt_cron', array( __CLASS__, 'cron' ) );
		add_action( 'wp_ajax_lmgt_bg', array( __CLASS__, 'ajax_bg' ) );
		add_action( 'wp_ajax_nopriv_lmgt_bg', array( __CLASS__, 'ajax_bg' ) );
		// The minute schedule exists only while there is work: an idle queue costs
		// the site nothing, and admin pages do not share PHP workers with it.
		add_action( 'init', array( __CLASS__, 'ensure_schedule' ) );
	}

	/** 2.2.25: the minute schedule also runs while automatic jobs wait; 2.2.26: and while Translate everything is on. */
	public static function ensure_schedule() {
		$on = ( get_option( 'lmgt_cron', '0' ) === '1' && get_option( 'lmgt_work', '1' ) === '1' ) || get_option( 'lmgt_auto_work', '0' ) === '1' || LMGT_Plan::on();
		$at = wp_next_scheduled( 'lmgt_cron' );
		if ( $on && ! $at ) wp_schedule_event( time() + 60, 'lmgt_minute', 'lmgt_cron' );
		if ( ! $on && $at ) wp_clear_scheduled_hook( 'lmgt_cron' );
	}

	public static function workers() {
		return max( 1, min( 4, (int) get_option( 'lmgt_workers', 2 ) ) );
	}

	// ---- Locks (one row each in the options table; atomic across PHP workers and object caches) ----

	private static function claim( $name, $stale = 300 ) {
		global $wpdb;
		$now = time();
		if ( $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')", $name, $now ) ) ) return true;
		$t = (int) $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $name ) );
		if ( $now - $t < $stale ) return false;
		return (bool) $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s", $now, $name, $t ) );
	}

	private static function release( $name ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s", $name ) );
	}

	/** Lock rows held right now (younger than five minutes). */
	public static function busy( $prefix ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s AND option_value > %d", $wpdb->esc_like( $prefix ) . '%', time() - 300 ) );
	}

	// ---- Background workers ------------------------------------------------------

	private static function key() {
		$k = get_option( 'lmgt_bg_key', '' );
		if ( strlen( $k ) < 20 ) {
			$k = wp_generate_password( 32, false );
			update_option( 'lmgt_bg_key', $k, false );
		}
		return $k;
	}

	/** Wake worker $slot without waiting for it. */
	public static function kick( $slot ) {
		wp_remote_post( admin_url( 'admin-ajax.php' ), array(
			'timeout'   => 0.01,
			'blocking'  => false,
			'sslverify' => apply_filters( 'https_local_ssl_verify', false ),
			'body'      => array( 'action' => 'lmgt_bg', 'slot' => (int) $slot, 'key' => self::key() ),
		) );
	}

	public static function kick_all() {
		for ( $s = 1; $s <= self::workers(); $s++ ) self::kick( $s );
	}

	public static function ajax_bg() {
		$key = isset( $_POST['key'] ) ? (string) wp_unslash( $_POST['key'] ) : '';
		if ( $key === '' || ! hash_equals( self::key(), $key ) ) wp_die( '', '', array( 'response' => 403 ) );
		$slot = max( 1, (int) ( isset( $_POST['slot'] ) ? $_POST['slot'] : 1 ) );
		if ( $slot > self::workers() ) wp_die( '' );
		ignore_user_abort( true );
		if ( self::work( $slot, 45 ) && self::bg_on() ) self::kick( $slot );
		wp_die( '' );
	}

	/** Anything the background may work right now. */
	public static function bg_on() {
		return get_option( 'lmgt_cron', '0' ) === '1' || get_option( 'lmgt_auto_work', '0' ) === '1' || LMGT_Plan::on();
	}

	/** Worker $slot: steps until the queue has nothing for it or $budget seconds are used. @return bool more work waits */
	public static function work( $slot, $budget ) {
		$lock = 'lmgt_slot_' . (int) $slot;
		if ( ! self::claim( $lock ) ) return false;
		$t0   = time();
		$more = false;
		do {
			$r = self::step( 'bg' );
			if ( $r['state'] === 'worked' ) update_option( 'lmgt_bg_last', time(), false );
			$more = $r['state'] === 'worked';
		} while ( $more && time() - $t0 < $budget );
		self::release( $lock );
		return $more;
	}

	// ---- Queue storage ---------------------------------------------------------

	public static function ids() {
		return array_values( (array) get_option( self::LIST_OPT, array() ) );
	}

	public static function get( $id ) {
		$j = get_option( 'lmgt_job_' . $id );
		return is_array( $j ) ? $j : null;
	}

	private static function put( array $j ) {
		update_option( 'lmgt_job_' . $j['id'], $j, false );
	}

	public static function remove( $id ) {
		delete_option( 'lmgt_job_' . $id );
		update_option( self::LIST_OPT, array_values( array_diff( self::ids(), array( $id ) ) ), false );
	}

	/** @return string|WP_Error job id */
	/** Plain text cut into parts of at most $max characters, at sentence ends. */
	private static function split_text( $text, $max ) {
		$parts = array();
		$cur   = '';
		foreach ( preg_split( '/(?<=[.!?])\s+/u', $text ) as $s ) {
			if ( $cur !== '' && mb_strlen( $cur ) + mb_strlen( $s ) + 1 > $max ) {
				$parts[] = $cur;
				$cur     = '';
			}
			$cur .= ( $cur === '' ? '' : ' ' ) . $s;
		}
		if ( $cur !== '' || ! $parts ) $parts[] = $cur;
		return $parts;
	}

	public static function add( $post_id, $lang, $auto = false, $plan = false ) {
		$post = get_post( $post_id );
		if ( ! $post || ! in_array( $post->post_type, LMGT_Store::types(), true ) ) return new WP_Error( 'lmgt_type', 'This post type is not switched on under Translator settings → Post types.' );
		if ( $post->post_status !== 'publish' ) return new WP_Error( 'lmgt_status', 'Only published originals can be translated.' );
		if ( LMGT_Store::is_tagged( $post_id ) ) return new WP_Error( 'lmgt_tagged', 'This post is itself a translation.' );
		$read = LMGT_Store::reads_as( $post );
		if ( $read && $read !== LMGT_Langs::source() ) return new WP_Error( 'lmgt_source_lang', 'This post reads as ' . LMGT_Langs::get( $read )['name'] . ', not the site\'s own language.' );
		if ( ! in_array( $lang, LMGT_Langs::enabled(), true ) ) return new WP_Error( 'lmgt_lang', 'Language not switched on in settings.' );
		foreach ( self::ids() as $id ) {
			$j = self::get( $id );
			if ( $j && (int) $j['post'] === (int) $post_id && $j['lang'] === $lang && in_array( $j['status'], array( 'queued', 'running' ), true ) ) return $id;
		}
		$id = substr( md5( $post_id . $lang . microtime() ), 0, 10 );
		self::put( array(
			'id' => $id, 'post' => (int) $post_id, 'lang' => $lang, 'stage' => 'prepare', 'i' => 0,
			'status' => 'queued', 'error' => '', 'engine' => '', 'created' => time(), 'log' => array(), 'auto' => (bool) $auto, 'plan' => (bool) $plan,
		) );
		$list   = self::ids();
		$list[] = $id;
		update_option( self::LIST_OPT, $list, false );
		update_option( 'lmgt_work', '1', true );
		if ( $auto ) update_option( 'lmgt_auto_work', '1', true );
		return $id;
	}

	public static function retry( $id ) {
		$j = self::get( $id );
		if ( ! $j ) return;
		// 2.3.1: a job that failed at save keeps its paid translation and only saves again.
		if ( isset( $j['stage'] ) && $j['stage'] === 'save' && ! empty( $j['final'] ) && ! empty( $j['src'] ) ) {
			$j = array_merge( $j, array( 'status' => 'queued', 'error' => '' ) );
			unset( $j['tries'] );
			self::put( $j );
			update_option( 'lmgt_work', '1', true );
			return;
		}
		$j = array_merge( $j, array( 'stage' => 'prepare', 'i' => 0, 'status' => 'queued', 'error' => '', 'engine' => '' ) );
		unset( $j['src'], $j['tr'], $j['back'], $j['report'], $j['tries'], $j['back_parts'], $j['back_done'], $j['back_title'] );
		self::put( $j );
		LMGT_Plan::job_retried( $j );
		update_option( 'lmgt_work', '1', true );
	}

	// ---- Running ---------------------------------------------------------------

	public static function ajax_step() {
		check_ajax_referer( 'lmgt_step' );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_send_json_error( 'Not allowed.' );
		wp_send_json_success( self::step() );
	}

	/** Every minute: top up Translate everything, wake workers 2…n, and work as worker 1. */
	public static function cron() {
		LMGT_Plan::refill();
		for ( $s = 2; $s <= self::workers(); $s++ ) self::kick( $s );
		self::work( 1, 50 );
	}

	/** May the background take this job? Automatic jobs always; plan jobs while the plan is on; the rest with "Run without the page open". */
	private static function bg_may( array $j ) {
		if ( ! empty( $j['auto'] ) ) return true;
		if ( ! empty( $j['plan'] ) ) return LMGT_Plan::on();
		return get_option( 'lmgt_cron', '0' ) === '1';
	}

	/**
	 * Do one stage of the first unfinished job no other worker holds.
	 * $mode: 'all' (the Queue page), 'bg' (background workers); true = automatic jobs only (2.2.25 callers).
	 */
	public static function step( $mode = 'all' ) {
		if ( $mode === true ) $mode = 'auto';
		if ( $mode === false ) $mode = 'all';
		if ( lmgt_legacy_active() ) return array( 'state' => 'blocked', 'message' => 'Deactivate "Traveltalk AI Translator" first.' );
		$job  = null;
		$open = 0;
		foreach ( self::ids() as $id ) {
			$j = self::get( $id );
			if ( ! $j || ! in_array( $j['status'], array( 'queued', 'running' ), true ) ) continue;
			if ( $mode === 'auto' && empty( $j['auto'] ) ) continue;
			if ( $mode === 'bg' && ! self::bg_may( $j ) ) continue;
			$open++;
			if ( ! self::claim( 'lmgt_jl_' . $id ) ) continue;
			$j = self::get( $id );
			if ( ! $j || ! in_array( $j['status'], array( 'queued', 'running' ), true ) ) { self::release( 'lmgt_jl_' . $id ); continue; }
			$job = $j;
			break;
		}
		if ( ! $job ) {
			if ( $open ) return array( 'state' => 'busy', 'message' => 'Every waiting translation is being worked by another worker.' );
			if ( $mode === 'all' ) update_option( 'lmgt_work', '0', true );
			$auto_left = false;
			foreach ( self::ids() as $id ) { $j = self::get( $id ); if ( $j && ! empty( $j['auto'] ) && in_array( $j['status'], array( 'queued', 'running' ), true ) ) { $auto_left = true; break; } }
			if ( ! $auto_left ) update_option( 'lmgt_auto_work', '0', true );
			return array( 'state' => 'idle', 'message' => 'Queue empty.' );
		}
		$lock = 'lmgt_jl_' . $job['id'];
		@set_time_limit( 280 );
		$job['status'] = 'running';
		$before        = $job['stage'] . ':' . $job['i'];
		// A step the server kills (time limit) leaves no error behind. Count the
		// attempt before running, so a step that never finishes fails visibly.
		$job['tries'] = ( isset( $job['tries'][ $before ] ) ? array( $before => $job['tries'][ $before ] ) : array( $before => 0 ) );
		$job['tries'][ $before ]++;
		if ( $job['tries'][ $before ] > 3 ) {
			$job['status'] = 'failed';
			$job['error']  = 'The ' . $job['stage'] . ' step did not finish three times in a row (server time limit). Retry, or ask Claude to split it.';
			self::put( $job );
			LMGT_Plan::job_failed( $job );
			self::release( $lock );
			return array( 'state' => 'worked', 'job' => $job['id'], 'title' => get_the_title( $job['post'] ), 'lang' => $job['lang'], 'stage' => $job['stage'], 'status' => 'failed', 'message' => $job['error'] );
		}
		self::put( $job );
		LMGT_Meter::reset();
		$r = self::run_stage( $job );
		// Spent is spent: a failed step counts too, and a retry keeps the total.
		$job['meter'] = LMGT_Meter::sum( isset( $job['meter'] ) ? $job['meter'] : array(), LMGT_Meter::take() );
		if ( is_wp_error( $r ) ) {
			$job['status'] = 'failed';
			$job['error']  = $r->get_error_message();
			$job['log'][]  = gmdate( 'H:i:s' ) . ' ' . $before . ': ' . $job['error'];
			LMGT_Plan::job_failed( $job );
		} else {
			$job['log'][] = gmdate( 'H:i:s' ) . ' ' . $before . ' ok';
		}
		self::put( $job );
		self::release( $lock );

		return array(
			'state'   => 'worked',
			'job'     => $job['id'],
			'title'   => get_the_title( $job['post'] ),
			'lang'    => $job['lang'],
			'stage'   => $job['stage'],
			'status'  => $job['status'],
			'message' => $job['status'] === 'failed' ? $job['error'] : $before . ' done',
		);
	}

	/** @return true|WP_Error; advances $job['stage'] on success. */
	private static function run_stage( array &$job ) {
		$from = LMGT_Langs::source();
		$to   = $job['lang'];
		switch ( $job['stage'] ) {

			case 'prepare':
				$post = get_post( $job['post'] );
				if ( ! $post || $post->post_status !== 'publish' ) return new WP_Error( 'lmgt_source', 'Original is not published.' );
				list( $content, $map ) = LMGT_Text::protect( LMGT_Headfix::repair( $post->post_content ) );
				list( $content, $map, $alts ) = LMGT_Text::protect_media( $content, $map );
				list( $seo_t, $map_t ) = LMGT_Text::protect( (string) get_post_meta( $post->ID, 'rank_math_title', true ) );
				list( $seo_d, $map_d ) = LMGT_Text::protect( (string) get_post_meta( $post->ID, 'rank_math_description', true ) );
				$job['src'] = array(
					'fields' => array_merge( array( 'title' => $post->post_title, 'excerpt' => $post->post_excerpt, 'seo_title' => $seo_t, 'seo_desc' => $seo_d ), $alts ),
					'chunks' => LMGT_Text::chunks( $content ),
					'maps'   => array( 'content' => $map, 'seo_title' => $map_t, 'seo_desc' => $map_d ),
					'modified' => $post->post_modified_gmt,
				);
				$r = self::pick_engine( $job );
				if ( is_wp_error( $r ) ) return $r;
				$job['tr']    = array( 'fields' => array(), 'chunks' => array() );
				$job['stage'] = 'translate';
				$job['i']     = 0;
				return true;

			case 'translate':
				if ( $job['engine'] === 'deepl' ) {
					$texts = array_merge( array_values( $job['src']['fields'] ), $job['src']['chunks'] );
					$r = LMGT_Engines::deepl( $texts, $from, $to );
					if ( is_wp_error( $r ) && $r->get_error_code() === 'lmgt_quota' && self::may_fallback() ) {
						$job['engine'] = 'gemini';
						$job['log'][]  = 'DeepL allowance used up — switched this job to ' . LMGT_Engines::ai_name();
						return true;
					}
					if ( is_wp_error( $r ) ) return $r;
					$keys = array_keys( $job['src']['fields'] );
					foreach ( $keys as $n => $k ) $job['tr']['fields'][ $k ] = $r['texts'][ $n ];
					$job['tr']['chunks'] = array_slice( $r['texts'], count( $keys ) );
					$job['stage'] = self::polish_on() ? 'polish' : 'check';
					$job['i']     = 0;
					return true;
				}
				// Gemini: step 0 = the short fields, then one chunk per step.
				$r = self::ai_part( $job, LMGT_Engines::class . '::prompt_translate', $from, $to );
				if ( is_wp_error( $r ) ) return $r;
				if ( $job['i'] > count( $job['src']['chunks'] ) ) { $job['stage'] = 'check'; $job['i'] = 0; }
				return true;

			case 'polish':
				$r = self::ai_part( $job, 'polish', $from, $to );
				if ( is_wp_error( $r ) ) return $r;
				if ( $job['i'] > count( $job['src']['chunks'] ) ) { $job['stage'] = 'check'; $job['i'] = 0; }
				return true;

			case 'check':
				$content = LMGT_Text::restore( implode( '', $job['tr']['chunks'] ), LMGT_Text::apply_alts( $job['src']['maps']['content'], $job['tr']['fields'] ) );
				if ( is_wp_error( $content ) ) return $content;
				$f = $job['tr']['fields'];
				foreach ( array( 'seo_title', 'seo_desc' ) as $k ) {
					$v = LMGT_Text::restore( isset( $f[ $k ] ) ? $f[ $k ] : '', $job['src']['maps'][ $k ] );
					if ( is_wp_error( $v ) ) return $v;
					$f[ $k ] = $v;
				}
				$plain = LMGT_Text::plain( $content );
				$det   = LMGT_Text::detect( $plain );
				$want  = $to;
				if ( $det['code'] !== null && ( $det['code'] !== $want || $det['lead'] <= 0 ) ) {
					$l = LMGT_Langs::get( $det['code'] );
					return new WP_Error( 'lmgt_lang', sprintf( 'Language check failed: the body reads as %s, not %s. Nothing saved.', $l ? $l['name'] : $det['code'], LMGT_Langs::get( $to )['name'] ) );
				}
				$orig_plain = LMGT_Text::plain( implode( '', $job['src']['chunks'] ) );
				$job['final'] = array(
					'title'     => wp_strip_all_tags( $f['title'] ),
					'excerpt'   => isset( $f['excerpt'] ) ? $f['excerpt'] : '',
					'seo_title' => $f['seo_title'],
					'seo_desc'  => $f['seo_desc'],
					'content'   => $content,
				);
				$job['report'] = array(
					'engine'   => ( $job['engine'] === 'gemini' ? LMGT_Engines::ai_label() : $job['engine'] ) . ( self::polish_on() && $job['engine'] === 'deepl' ? ' + ' . LMGT_Engines::ai_label() . ' polish' : '' ),
					'detected' => $det,
					'numbers'  => LMGT_Text::number_diff( $job['src']['fields']['title'] . ' ' . $orig_plain, $job['final']['title'] . ' ' . $plain ),
					'issues'   => array(),
					'original_suggestions' => array(),
				);
				$job['stage'] = get_option( 'lmgt_backcheck', '1' ) === '1' ? 'back' : 'save';
				return true;

			case 'back':
				// Back-translated in parts of about 8,000 characters, one part per step,
				// so a long article (or a wordy language) never runs out of room.
				if ( ! isset( $job['back_parts'] ) ) {
					$job['back_parts'] = self::split_text( mb_substr( LMGT_Text::plain( $job['final']['content'] ), 0, 30000 ), 8000 );
					$job['back_done']  = array();
					$job['back_title'] = '';
					$job['i']          = 0;
				}
				$i      = (int) $job['i'];
				$fields = array( 'text' => isset( $job['back_parts'][ $i ] ) ? $job['back_parts'][ $i ] : '' );
				if ( $i === 0 ) $fields = array( 'title' => $job['final']['title'] ) + $fields;
				$use_deepl = false; // 2.13.0: Claude only
				if ( $use_deepl ) {
					$r = LMGT_Engines::deepl( array_values( $fields ), $to, $from );
					if ( is_wp_error( $r ) ) return $r;
					$out = array_combine( array_keys( $fields ), $r['texts'] );
				} else {
					$out = LMGT_Engines::ai_json( LMGT_Engines::prompt_back( $from, $to, $fields ), LMGT_Engines::schema_strings( array_keys( $fields ) ) );
					if ( is_wp_error( $out ) ) return $out;
					if ( ! isset( $out['text'] ) || ( $i === 0 && ! isset( $out['title'] ) ) ) return new WP_Error( 'lmgt_back', 'Back-translation came back incomplete. Nothing saved.' );
				}
				if ( $i === 0 ) $job['back_title'] = $out['title'];
				$job['back_done'][] = $out['text'];
				$job['i'] = $i + 1;
				if ( $job['i'] >= count( $job['back_parts'] ) ) {
					$job['back']  = array( 'title' => $job['back_title'], 'text' => implode( ' ', $job['back_done'] ) );
					unset( $job['back_parts'], $job['back_done'], $job['back_title'] );
					$job['i']     = 0;
					$job['stage'] = 'compare';
				}
				return true;

			case 'compare':
				if ( ! LMGT_Engines::ai_available() ) {
					$job['report']['notes'][] = 'No ' . LMGT_Engines::ai_name() . ' key: back-translation stored, not compared.';
					$job['report']['back'] = $job['back'];
					$job['stage'] = 'save';
					return true;
				}
				$orig = LMGT_Text::plain( implode( '', $job['src']['chunks'] ) );
				$tr   = LMGT_Text::plain( $job['final']['content'] );
				$r    = LMGT_Engines::ai_json( LMGT_Engines::prompt_compare(
					$from, $to,
					$job['src']['fields']['title'], mb_substr( $orig, 0, 25000 ),
					$job['back']['title'], mb_substr( $job['back']['text'], 0, 25000 ),
					$job['final']['title'], mb_substr( $tr, 0, 1500 ),
					LMGT_Engines::gap_context( $job['post'] )
				), LMGT_Engines::schema_compare() );
				if ( is_wp_error( $r ) ) return $r;
				$hl = $to; // our key: the verdict's no/nn are folded into nb below
				foreach ( array( 'title_lang' => 'title', 'body_lang' => 'body' ) as $k => $what ) {
					$got = isset( $r[ $k ] ) ? strtolower( substr( (string) $r[ $k ], 0, 2 ) ) : '';
					if ( $got === 'no' || $got === 'nn' ) $got = 'nb';
					if ( $got !== '' && $got !== $hl ) {
						// A title of place names often reads as any language; and when the word
						// check over the whole body already passed, a verdict on the opening sample
						// is a second opinion, not a veto. Both go to the reviewer as a flag.
						$whole_ok = isset( $job['report']['detected']['code'] ) && $job['report']['detected']['code'] === $hl;
						if ( $what === 'title' || $whole_ok ) {
							$job['report']['issues'][] = array( 'type' => 'language', 'original' => $what === 'title' ? $job['src']['fields']['title'] : '', 'back' => $what === 'title' ? $job['final']['title'] : '', 'note' => $what === 'title'
								? sprintf( 'The title may still be in "%s". Check it reads as "%s".', $got, $hl )
								: sprintf( 'The opening reads as "%s" to the AI check, while the whole text reads as "%s". Check the first paragraphs.', $got, $hl ) );
							continue;
						}
						return new WP_Error( 'lmgt_lang', sprintf( 'Language check failed: the %s reads as "%s", not "%s". Nothing saved.', $what, $got, $hl ) );
					}
				}
				$job['report']['issues']               = array_merge( isset( $job['report']['issues'] ) ? (array) $job['report']['issues'] : array(), array_values( (array) ( isset( $r['issues'] ) ? $r['issues'] : array() ) ) );
				$job['report']['original_suggestions'] = LMGT_Store::real_suggestions( isset( $r['original_suggestions'] ) ? $r['original_suggestions'] : array() );
				$job['report']['back']                 = $job['back'];
				$job['report']['gaps']                 = array_values( (array) ( isset( $r['gaps'] ) ? $r['gaps'] : array() ) );
				$job['stage'] = 'save';
				return true;

			case 'save':
				$post = get_post( $job['post'] );
				if ( ! $post || $post->post_modified_gmt !== $job['src']['modified'] ) {
					return new WP_Error( 'lmgt_changed', 'The original was edited while it was being translated. Retry to translate the new version.' );
				}
				$job['report']['meter'] = isset( $job['meter'] ) ? $job['meter'] : array();
				// 2.2.25: a translation of a new article (auto) is published by itself unless the check flagged it; the person reads it afterwards.
				// 2.2.26: Translate everything publishes the same way when "Publish what passes the check" is ticked.
				$plan_pub = ! empty( $job['plan'] ) && get_option( 'lmgt_plan_publish', '0' ) === '1';
				$auto     = ! empty( $job['auto'] ) || $plan_pub;
				$publish  = ( $plan_pub || ( ! empty( $job['auto'] ) && get_option( 'lmgt_auto_publish', '1' ) === '1' ) ) && ! LMGT_Auto::should_hold( $job['report'] );
				// 2.13.0 (G, 10 Nov): every translation is read by a person before it is published. Nothing publishes by itself.
				$publish  = false;
				// 2.11.0: Swedish, Norwegian and Finnish are saved here on .dk, never sent to .travel.
				if ( LMGT_Bridge::is_source() && ! LMGT_Nordic::is( $to ) ) {
					$id = LMGT_Bridge::send( $job['post'], $to, $job['final'], $job['report'], $publish ? 'publish' : 'draft', false, '', $auto ? array( 'autopub' => $publish ? 'published' : 'hold' ) : array() );
				} else {
					$id = LMGT_Store::save( $job['post'], $to, $job['final'], $job['report'] );
					if ( $auto ) LMGT_Auto::local( $id, $publish );
				}
				if ( is_wp_error( $id ) ) return $id;
				if ( ! empty( $job['report']['original_suggestions'] ) ) {
					$all = get_post_meta( $job['post'], '_lmgt_original_notes', true );
					if ( ! is_array( $all ) ) $all = array();
					$all[ $to ] = $job['report']['original_suggestions'];
					update_post_meta( $job['post'], '_lmgt_original_notes', wp_slash( $all ) );
				}
				if ( isset( $job['report']['gaps'] ) ) LMGT_Store::set_gaps( $job['post'], $job['report']['gaps'] );
				$job['result'] = $id;
				$job['status'] = 'done';
				$job['stage']  = 'done';
				// Keep the record small once done.
				unset( $job['src'], $job['tr'], $job['back'], $job['final'] );
				return true;
		}
		return new WP_Error( 'lmgt_stage', 'Unknown stage.' );
	}

	private static function polish_on() {
		return get_option( 'lmgt_polish', '1' ) === '1' && LMGT_Engines::ai_available();
	}

	private static function may_fallback() {
		return get_option( 'lmgt_engine', 'gemini' ) === 'auto' && LMGT_Engines::ai_available();
	}

	/** DeepL while its allowance lasts, Gemini after — unless settings force one. */
	private static function pick_engine( array &$job ) {
		// 2.13.0: one engine, the AI (Claude, agreed 26 Oct); DeepL is no longer used.
		$pref = 'gemini';
		if ( $pref === 'gemini' ) {
			if ( ! LMGT_Engines::ai_available() ) return new WP_Error( 'lmgt_engine', LMGT_Engines::ai_name() . ' chosen but no ' . LMGT_Engines::ai_name() . ' key saved.' );
			$job['engine'] = 'gemini';
			return true;
		}
		if ( ! LMGT_Engines::deepl_available() ) {
			if ( $pref === 'auto' && LMGT_Engines::ai_available() ) { $job['engine'] = 'gemini'; return true; }
			return new WP_Error( 'lmgt_engine', 'No translation engine key saved.' );
		}
		$need = 0;
		foreach ( $job['src']['fields'] as $v ) $need += mb_strlen( $v );
		foreach ( $job['src']['chunks'] as $v ) $need += mb_strlen( $v );
		$u = LMGT_Engines::deepl_usage();
		if ( ! is_wp_error( $u ) && $u['limit'] > 0 && $u['limit'] - $u['count'] < $need ) {
			if ( self::may_fallback() ) {
				$job['engine'] = 'gemini';
				$job['log'][]  = 'DeepL allowance too low for this article — using ' . LMGT_Engines::ai_name();
				return true;
			}
			return new WP_Error( 'lmgt_quota', sprintf( 'DeepL allowance left: %s characters, this article needs about %s.', number_format( $u['limit'] - $u['count'] ), number_format( $need ) ) );
		}
		$job['engine'] = 'deepl';
		return true;
	}

	/**
	 * One Gemini call for part i: i=0 is the short fields, i>=1 is chunk i-1.
	 * $mode is 'polish' or the translate prompt.
	 */
	private static function ai_part( array &$job, $mode, $from, $to ) {
		$i = (int) $job['i'];
		if ( $i === 0 ) {
			$src = array_filter( $job['src']['fields'], 'strlen' );
			if ( $src ) {
				$prompt = $mode === 'polish'
					? LMGT_Engines::prompt_polish( $from, $to, $src, array_intersect_key( $job['tr']['fields'], $src ) )
					: LMGT_Engines::prompt_translate( $from, $to, $src );
				$r = LMGT_Engines::ai_json( $prompt, LMGT_Engines::schema_strings( array_keys( $src ) ) );
				if ( is_wp_error( $r ) ) return $r;
				foreach ( $src as $k => $v ) {
					if ( ! isset( $r[ $k ] ) || ! is_string( $r[ $k ] ) ) return new WP_Error( 'lmgt_gemini', LMGT_Engines::ai_name() . ' left out the field "' . $k . '". Nothing saved.' );
					$job['tr']['fields'][ $k ] = $r[ $k ];
				}
			}
			foreach ( $job['src']['fields'] as $k => $v ) if ( ! isset( $job['tr']['fields'][ $k ] ) ) $job['tr']['fields'][ $k ] = '';
		} else {
			$n   = $i - 1;
			$src = $job['src']['chunks'][ $n ];
			if ( trim( $src ) !== '' ) {
				$prompt = $mode === 'polish'
					? LMGT_Engines::prompt_polish( $from, $to, array( 'html' => $src ), array( 'html' => $job['tr']['chunks'][ $n ] ) )
					: LMGT_Engines::prompt_translate( $from, $to, array( 'html' => $src ) );
				$r = LMGT_Engines::ai_json( $prompt, LMGT_Engines::schema_strings( array( 'html' ) ) );
				if ( is_wp_error( $r ) ) return $r;
				if ( ! isset( $r['html'] ) || ! is_string( $r['html'] ) ) return new WP_Error( 'lmgt_gemini', LMGT_Engines::ai_name() . ' returned no text for section ' . ( $n + 1 ) . '. Nothing saved.' );
				$job['tr']['chunks'][ $n ] = $r['html'];
			} else {
				$job['tr']['chunks'][ $n ] = $src;
			}
		}
		$job['i'] = $i + 1;
		return true;
	}
}
