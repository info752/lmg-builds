<?php
/**
 * 2.9.0 (G, 9 Nov 2026): the boxes. "Become the preferred travel partner: the first door, and
 * the one that takes you there – most reliable, most relevant, most updated, best related."
 *
 *   Box 1  Read more                (LMGT_Structure, unchanged)
 *   Box 2  Know before you go / Værd at vide om X før du rejser – questions and answers from
 *          the text, in the site's outlook; FAQPage schema.
 *   Box 3  Who takes you there / Hvem tager dig derhen – the companies G ticked after checking
 *          their website: local, airlines, agencies, getting around; linked; ItemList schema;
 *          each one onto Translator → Outreach. Only where something is ticked (G, 9 Nov).
 *   Box 4  Fact box / Fakta om X (2.9.4) – short rows from the text, every number checked against it.
 *   Box 5  Map / Kort over X (2.15.0, G, 13 Nov: "the green boxes … and hopefully maps too") – the places the
 *          text names, found on OpenStreetMap, shown on a map with a numbered list under it.
 *
 * A box sits in the text between <!-- lmgt:KEY --> and <!-- /lmgt:KEY -->, so it can be
 * replaced without touching anything else, and travels with the text to translations.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class LMGT_Boxes {

	public static function boot() {
		add_action( 'admin_post_lmgt_who_box', array( __CLASS__, 'handle_who' ) );
		add_action( 'admin_post_lmgt_faq_propose', array( __CLASS__, 'handle_faq_propose' ) );
		add_action( 'admin_post_lmgt_faq_apply', array( __CLASS__, 'handle_faq_apply' ) );
		add_action( 'admin_post_lmgt_box_remove', array( __CLASS__, 'handle_remove' ) );
		add_action( 'admin_post_lmgt_facts_propose', array( __CLASS__, 'handle_facts_propose' ) );
		add_action( 'admin_post_lmgt_facts_apply', array( __CLASS__, 'handle_facts_apply' ) );
		add_action( 'admin_post_lmgt_map_propose', array( __CLASS__, 'handle_map_propose' ) );
		add_action( 'admin_post_lmgt_map_apply', array( __CLASS__, 'handle_map_apply' ) );
		add_action( 'wp_footer', array( __CLASS__, 'map_script' ), 30 );
		add_filter( 'the_content', array( __CLASS__, 'heal_faq' ), 5 );
		// 2.9.1 (G, 9 Nov): a new translation without the box gets a proposal waiting in its panel.
		add_action( 'save_post_' . LMGT_CPT, array( __CLASS__, 'queue_auto' ), 30, 2 );
		add_action( 'lmgt_faq_auto', array( __CLASS__, 'run_auto' ) );
		add_action( 'wp_head', array( __CLASS__, 'schema' ), 30 );
		add_action( 'wp_head', array( __CLASS__, 'css' ), 31 );
	}

	private static function lang_of( $post ) {
		return $post->post_type === LMGT_CPT ? (string) get_post_meta( $post->ID, '_lmgt_lang', true ) : LMGT_Langs::source();
	}

	/**
	 * 2.16.0 (G, 13 Nov: winetalk.dk first, then worldsporttalk.com): what the site writes about, so the
	 * boxes ask the right questions. Set under Translator → Settings, else read from the address.
	 */
	public static function subject() {
		$o = (string) get_option( 'lmgt_subject', '' );
		if ( in_array( $o, array( 'travel', 'wine', 'sport' ), true ) ) return $o;
		$h = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		if ( strpos( $h, 'winetalk' ) !== false ) return 'wine';
		if ( strpos( $h, 'sporttalk' ) !== false ) return 'sport';
		return 'travel';
	}

	/** Words for the prompts and box titles, by subject. */
	private static function sub( $key ) {
		$w = array(
			'travel' => array( 'article' => 'travel article', 'qa' => 'questions a traveller asks before going', 'rows' => 'a traveller scans before planning', 'eg' => 'best time to go, budget per day, a simple meal, a night in a guesthouse, where to stay, getting around, flight time, visa', 'map' => 'regions, cities, towns, parks, lakes, sights' ),
			'wine'   => array( 'article' => 'wine article', 'qa' => 'questions a wine lover asks about this wine, grape or region', 'rows' => 'a wine lover scans before buying or opening a bottle', 'eg' => 'region, grapes, style, alcohol, price, serve at, drink with, keeps for, good vintages', 'map' => 'wine regions, villages, vineyards, estates, rivers' ),
			'sport'  => array( 'article' => 'sport article', 'qa' => 'questions a fan asks about this subject', 'rows' => 'a fan scans for the record', 'eg' => 'born, years active, team or club, titles, records, best season, the number that says it all', 'map' => 'venues, stadiums, circuits, courses, cities' ),
		);
		return $w[ self::subject() ][ $key ];
	}

	public static function kind_label( $kind, $lang ) {
		$da = $lang === 'da';
		$l  = array(
			'local'     => $da ? 'Lokale arrangører og guider' : 'Local operators and guides',
			'airline'   => $da ? 'Flyselskaber' : 'Airlines',
			'agency'    => $da ? 'Rejsebureauer' : 'Travel agencies',
			'transport' => $da ? 'Rundt på stedet' : 'Getting around',
		);
		return isset( $l[ $kind ] ) ? $l[ $kind ] : $l['local'];
	}

	private static function place_name( $post ) {
		if ( class_exists( 'LMGT_Structure' ) ) {
			$c = LMGT_Structure::cluster( $post->ID );
			if ( ! empty( $c['place'][0] ) ) return $c['place'][0];
		}
		return html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' );
	}

	/** Put a box into the text: replace the one already there, else add it at the end. */
	public static function put( $html, $key, $box ) {
		$open  = '<!-- lmgt:' . $key . ' -->';
		$close = '<!-- /lmgt:' . $key . ' -->';
		$pat   = '#\n*' . preg_quote( $open, '#' ) . '.*?' . preg_quote( $close, '#' ) . '#s';
		if ( $box === '' ) return preg_replace( $pat, '', $html );
		$blocks = strpos( $html, '<!-- wp:' ) !== false;
		$inner  = $blocks ? "<!-- wp:html -->\n" . $box . "\n<!-- /wp:html -->" : $box;
		$full   = $open . "\n" . $inner . "\n" . $close;
		if ( preg_match( $pat, $html ) ) return preg_replace( $pat, "\n\n" . str_replace( '$', '\$', $full ), $html, 1 );
		return rtrim( $html ) . "\n\n" . $full;
	}

	// ---- Box 3: who takes you there -------------------------------------------------------

	public static function handle_who() {
		$id = (int) $_POST['post_id'];
		check_admin_referer( 'lmgt_who_box_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$post = get_post( $id );
		$back = get_edit_post_link( $id, 'url' );
		$src  = $post->post_type === LMGT_CPT ? (int) get_post_meta( $id, '_lmgt_source', true ) : $id;
		if ( ! $src ) $src = $id;
		$g    = get_post_meta( $src, '_lmgt_gaps', true );
		$all  = is_array( $g ) && ! empty( $g['providers'] ) ? array_values( $g['providers'] ) : array();
		$pick = array();
		foreach ( (array) ( isset( $_POST['lmgt_pv'] ) ? $_POST['lmgt_pv'] : array() ) as $n ) {
			if ( isset( $all[ (int) $n ] ) && ! empty( $all[ (int) $n ]['web'] ) ) $pick[] = $all[ (int) $n ];
		}
		$lang = self::lang_of( $post );
		$box  = $pick ? self::who_html( $pick, $lang, self::place_name( $post ) ) : '';
		$html = self::put( $post->post_content, 'who', $box );
		LMGT_Store::update_content( $id, array( 'post_content' => $html ) );
		update_post_meta( $id, '_lmgt_who', wp_slash( $pick ) );
		delete_post_meta( $id, '_lmgt_reviewed' );
		foreach ( $pick as $pv ) LMGT_Outreach::add( $pv, $id );
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $pick ? count( $pick ) . ' companies in the "Who takes you there" box, and on Translator → Outreach.' : 'Box removed: nothing was ticked.' ), $back ) );
		exit;
	}

	private static function who_html( array $pick, $lang, $place ) {
		$da    = $lang === 'da';
		$title = $da ? 'Hvem tager dig til ' . $place : 'Who takes you to ' . $place;
		$h     = '<div class="lmgt-box lmgt-who" data-lmgt="who"><h2>' . esc_html( $title ) . '</h2>';
		foreach ( array( 'local', 'airline', 'agency', 'transport' ) as $k ) {
			$rows = array_filter( $pick, function ( $p ) use ( $k ) { return ( isset( $p['kind'] ) ? $p['kind'] : 'local' ) === $k; } );
			if ( ! $rows ) continue;
			$h .= '<h3>' . esc_html( self::kind_label( $k, $lang ) ) . '</h3><ul>';
			foreach ( $rows as $p ) {
				$h .= '<li><a href="' . esc_url( $p['web'] ) . '" target="_blank" rel="noopener">' . esc_html( $p['name'] ) . '</a>' . ( ! empty( $p['what'] ) ? ' – ' . esc_html( $p['what'] ) : '' ) . '</li>';
			}
			$h .= '</ul>';
		}
		return $h . '</div>';
	}

	// ---- Box 2: know before you go ---------------------------------------------------------

	/** 2.9.1: an FAQ the text already has, as a section of its own ("Ofte stillede spørgsmål", "Frequently asked questions", "FAQ"). [start, length] or null. */
	public static function old_faq_span( $html ) {
		$secs = class_exists( 'LMGT_Structure' ) ? LMGT_Structure::sections( $html ) : array();
		foreach ( $secs as $i => $s ) {
			if ( $s['level'] > 2 || ! preg_match( '/(spørgsmål|questions|\bfaq\b|fragen|preguntas|domande|frågor|spørsmål|kysymyk)/iu', $s['text'] ) ) continue;
			$start = $s['start'];
			$pre   = strrpos( substr( $html, 0, $start ), '<!-- wp:heading' );
			if ( $pre !== false && trim( substr( $html, $pre, $start - $pre ) ) !== '' && strpos( substr( $html, $pre, $start - $pre ), '<!-- /wp:' ) === false ) $start = $pre;
			$end = strlen( $html );
			for ( $k = $i + 1; $k < count( $secs ); $k++ ) {
				if ( $secs[ $k ]['level'] <= 2 ) {
					$end = $secs[ $k ]['start'];
					$p2  = strrpos( substr( $html, 0, $end ), '<!-- wp:heading' );
					if ( $p2 !== false && $p2 > $start ) $end = $p2;
					break;
				}
			}
			$mk = strpos( $html, '<!-- lmgt:', $start );
			if ( $mk !== false && $mk < $end ) $end = $mk;
			return array( $start, $end - $start );
		}
		return null;
	}

	/** Propose the questions; [count] or WP_Error. Used by the button and by the automatic run on new translations. */
	public static function propose( $id ) {
		$post  = get_post( $id );
		if ( ! $post ) return new WP_Error( 'lmgt', 'Not found.' );
		$lang  = self::lang_of( $post );
		$a     = LMGT_Langs::get( $lang );
		$place = self::place_name( $post );
		$view  = self::subject() !== 'travel' ? 'Answer for any reader; no national point of view unless ARTICLE has one.' : ( $lang === LMGT_Langs::source() && $lang === 'da'
			? 'The reader travels from Denmark or the Nordic countries: where the text has it, answer from there (flights from Copenhagen, Danish holidays).'
			: 'The reader can come from anywhere: no Danish or Nordic point of view, no "Danish citizens".' );
		$text  = preg_replace( '#<!-- lmgt:faq -->.*?<!-- /lmgt:faq -->#s', '', $post->post_content );
		$prompt = "ARTICLE is a {$a['name']} " . self::sub( 'article' ) . " about {$place}. Write 5 to 7 " . self::sub( 'qa' ) . ", with short answers (1 to 3 sentences), in {$a['name']}.\n"
			. "Use only facts in ARTICLE; never add a number, a price, a rule or a date that is not there. Where ARTICLE does not answer something, leave the question out. If ARTICLE already has a section of questions and answers, keep those questions (corrected where needed) and add to them.\n{$view}\n"
			. "Return JSON: {\"qa\":[{\"q\":\"…?\",\"a\":\"…\"}]}.\n\nARTICLE:\n" . mb_substr( LMGT_Text::plain( $text ), 0, 30000 );
		@set_time_limit( 200 );
		$r = LMGT_Engines::ai_json( $prompt );
		if ( is_wp_error( $r ) ) return $r;
		$qa = array();
		foreach ( (array) ( isset( $r['qa'] ) ? $r['qa'] : array() ) as $x ) {
			if ( ! empty( $x['q'] ) && ! empty( $x['a'] ) ) $qa[] = array( 'q' => sanitize_text_field( $x['q'] ), 'a' => sanitize_text_field( $x['a'] ) );
		}
		if ( ! $qa ) return new WP_Error( 'lmgt', 'No questions came back. Try again.' );
		update_post_meta( $id, '_lmgt_faq_pending', wp_slash( array( 'qa' => $qa, 'at' => current_time( 'mysql', true ), 'replaces_old' => self::old_faq_span( $post->post_content ) ? 1 : 0 ) ) );
		return array( count( $qa ) );
	}

	public static function handle_faq_propose() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_faq_propose_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$back = get_edit_post_link( $id, 'url' );
		$r    = self::propose( $id );
		if ( is_wp_error( $r ) ) self::back( $back, $r->get_error_message() );
		self::back( $back, $r[0] . ' questions proposed for the "Know before you go" box. Read them in the panel and press Accept.' );
	}

	/** New translations: propose the box a minute after they are saved, when there is none and none waiting. */
	public static function queue_auto( $id, $post ) {
		if ( wp_is_post_revision( $id ) || $post->post_status === 'auto-draft' || ! LMGT_Engines::ai_available() || LMGT_Store::as_written( $id ) ) return;
		if ( strpos( $post->post_content, '<!-- lmgt:faq -->' ) !== false || get_post_meta( $id, '_lmgt_faq_pending', true ) || get_post_meta( $id, '_lmgt_faq_auto_done', true ) ) return;
		if ( ! wp_next_scheduled( 'lmgt_faq_auto', array( (int) $id ) ) ) wp_schedule_single_event( time() + 60, 'lmgt_faq_auto', array( (int) $id ) );
	}

	public static function run_auto( $id ) {
		update_post_meta( (int) $id, '_lmgt_faq_auto_done', current_time( 'mysql', true ) ); // once per translation; the button stays for later
		$p = get_post( (int) $id );
		if ( ! $p || strpos( $p->post_content, '<!-- lmgt:faq -->' ) !== false ) return;
		self::propose( (int) $id );
	}

	/** 2.9.1 (G, 9 Nov: "a collective tick for the box as such"): take a whole box out of the text. */
	public static function handle_remove() {
		$id  = (int) $_GET['post'];
		$key = isset( $_GET['key'] ) && in_array( $_GET['key'], array( 'who', 'facts' ), true ) ? $_GET['key'] : 'faq';
		check_admin_referer( 'lmgt_box_remove_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$post = get_post( $id );
		LMGT_Store::update_content( $id, array( 'post_content' => self::put( $post->post_content, $key, '' ) ) );
		if ( $key === 'who' ) delete_post_meta( $id, '_lmgt_who' );
		$names = array( 'who' => '"Who takes you there"', 'faq' => '"Know before you go"', 'facts' => 'Fact', 'map' => 'Map' );
		self::back( get_edit_post_link( $id, 'url' ), $names[ $key ] . ' box removed. The previous version is under Revisions.' );
	}

	private static function faq_html( array $qa, $lang, $place ) {
		$travel = self::subject() === 'travel';
		$title  = $lang === 'da' ? 'Værd at vide om ' . $place . ( $travel ? ' før du rejser' : '' ) : ( $travel ? 'Know before you go: ' : 'Good to know: ' ) . $place;
		$h = '<div class="lmgt-box lmgt-faq" data-lmgt="faq"><h2>' . esc_html( $title ) . '</h2>';
		foreach ( $qa as $x ) $h .= '<h3>' . esc_html( $x['q'] ) . '</h3><p>' . esc_html( $x['a'] ) . '</p>';
		return $h . '</div>';
	}

	public static function handle_faq_apply() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_faq_apply_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$back = get_edit_post_link( $id, 'url' );
		$p    = get_post_meta( $id, '_lmgt_faq_pending', true );
		delete_post_meta( $id, '_lmgt_faq_pending' );
		if ( ! isset( $_GET['do'] ) || $_GET['do'] !== 'apply' || ! is_array( $p ) ) self::back( $back, 'Questions rejected. The text is unchanged.' );
		$post = get_post( $id );
		$box  = self::faq_html( $p['qa'], self::lang_of( $post ), self::place_name( $post ) );
		$old  = strpos( $post->post_content, '<!-- lmgt:faq -->' ) === false ? self::old_faq_span( $post->post_content ) : null;
		if ( $old ) {
			// 2.9.1: the old questions section is replaced by the box, where it stood; no second list.
			$blocks = strpos( $post->post_content, '<!-- wp:' ) !== false;
			$full   = "<!-- lmgt:faq -->\n" . ( $blocks ? "<!-- wp:html -->\n" . $box . "\n<!-- /wp:html -->" : $box ) . "\n<!-- /lmgt:faq -->\n\n";
			$html   = substr_replace( $post->post_content, $full, $old[0], $old[1] );
		} else {
			$html = self::put( $post->post_content, 'faq', $box );
		}
		LMGT_Store::update_content( $id, array( 'post_content' => $html ) );
		delete_post_meta( $id, '_lmgt_reviewed' );
		self::back( $back, '"Know before you go" box put in the text, with question markup for Google. The previous version is under Revisions.' );
	}

	/** One row in the steps panel for the two boxes. */
	public static function step_row( $n, $post ) {
		$id  = $post->ID;
		$pen = get_post_meta( $id, '_lmgt_faq_pending', true );
		$has_faq = strpos( $post->post_content, '<!-- lmgt:faq -->' ) !== false;
		$has_who = strpos( $post->post_content, '<!-- lmgt:who -->' ) !== false;
		$who = (array) get_post_meta( $id, '_lmgt_who', true );
		$has_facts = strpos( $post->post_content, '<!-- lmgt:facts -->' ) !== false;
		$fpen = get_post_meta( $id, '_lmgt_facts_pending', true );
		$has_map = strpos( $post->post_content, '<!-- lmgt:map -->' ) !== false;
		$mpen = get_post_meta( $id, '_lmgt_map_pending', true );
		$txt = 'Facts: ' . ( $has_facts ? '<strong>in the text</strong>' : 'not yet' ) . ' · Map: ' . ( $has_map ? '<strong>in the text</strong>' : 'not yet' ) . ' · Know before you go: ' . ( $has_faq ? '<strong>in the text</strong>' : 'not yet' ) . ' · Who takes you there: ' . ( $has_who ? '<strong>' . count( $who ) . ' companies</strong>' : 'none ticked (under Deepen → Who takes you there)' ) . '.';
		$u   = function ( $a, $extra = '' ) use ( $id ) { return wp_nonce_url( admin_url( 'admin-post.php?action=' . $a . '&post=' . $id . $extra ), $a . '_' . $id ); };
		if ( is_array( $mpen ) && ! empty( $mpen['points'] ) ) {
			$li = '<ol style="margin-left:18px">';
			foreach ( $mpen['points'] as $x ) $li .= '<li><strong>' . esc_html( $x['name'] ) . '</strong>' . ( $x['note'] !== '' ? ' – ' . esc_html( $x['note'] ) : '' ) . ' <span class="description">(' . esc_html( $x['found'] ) . ')</span></li>';
			$li .= '</ol>' . ( ! empty( $mpen['missed'] ) ? '<p class="description">Not found on the map, left out: ' . esc_html( implode( ', ', $mpen['missed'] ) ) . '.</p>' : '' );
			LMGT_Steps::row( $n, 'Boxes', 'wait', count( $mpen['points'] ) . ' places proposed for the map, all named in the text. Check that each one was found in the right place (in brackets):' . $li,
				'<a class="button button-primary" href="' . esc_url( $u( 'lmgt_map_apply', '&do=apply' ) ) . '">Accept: put the map in</a> <a class="button" href="' . esc_url( $u( 'lmgt_map_apply', '&do=drop' ) ) . '">Reject</a>' );
			return;
		}
		if ( is_array( $fpen ) && ! empty( $fpen['rows'] ) ) {
			$li = '<table class="widefat" style="max-width:640px;margin-top:6px"><tbody>';
			foreach ( $fpen['rows'] as $r ) $li .= '<tr><th style="width:35%">' . esc_html( $r['label'] ) . '</th><td>' . esc_html( $r['value'] ) . '</td></tr>';
			$li .= '</tbody></table>' . ( ! empty( $fpen['dropped'] ) ? '<p class="description">' . (int) $fpen['dropped'] . ' row(s) left out: a number in them is not in the text.</p>' : '' );
			LMGT_Steps::row( $n, 'Boxes', 'wait', count( $fpen['rows'] ) . ' rows proposed for the fact box, all taken from the text:' . $li,
				'<a class="button button-primary" href="' . esc_url( $u( 'lmgt_facts_apply', '&do=apply' ) ) . '">Accept: put the fact box in</a> <a class="button" href="' . esc_url( $u( 'lmgt_facts_apply', '&do=drop' ) ) . '">Reject</a>' );
			return;
		}
		if ( is_array( $pen ) && ! empty( $pen['qa'] ) ) {
			$li = '<ol style="margin-left:18px">';
			foreach ( $pen['qa'] as $x ) $li .= '<li><strong>' . esc_html( $x['q'] ) . '</strong> ' . esc_html( $x['a'] ) . '</li>';
			$li .= '</ol>';
			LMGT_Steps::row( $n, 'Boxes', 'wait', count( $pen['qa'] ) . ' questions proposed for "Know before you go"' . ( ! empty( $pen['replaces_old'] ) ? ' (they replace the questions section the text already has)' : '' ) . ':' . $li,
				'<a class="button button-primary" href="' . esc_url( $u( 'lmgt_faq_apply', '&do=apply' ) ) . '">Accept: put the box in</a> <a class="button" href="' . esc_url( $u( 'lmgt_faq_apply', '&do=drop' ) ) . '">Reject</a>' );
			return;
		}
		$rm  = function ( $k, $label ) use ( $id ) { return '<a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_box_remove&key=' . $k . '&post=' . $id ), 'lmgt_box_remove_' . $id ) ) . '" onclick="return confirm(\'Remove the whole box from the text?\')">× Remove ' . $label . '</a> '; };
		$btn = ( LMGT_Engines::ai_available() ? '<a class="button' . ( $has_faq ? '' : ' button-primary' ) . '" href="' . esc_url( $u( 'lmgt_faq_propose' ) ) . '">' . ( $has_faq ? 'Propose the questions again' : 'Propose "Know before you go"' ) . '</a> '
			. '<a class="button" href="' . esc_url( $u( 'lmgt_facts_propose' ) ) . '">' . ( $has_facts ? 'Propose the facts again' : 'Propose the fact box' ) . '</a> '
			. '<a class="button" href="' . esc_url( $u( 'lmgt_map_propose' ) ) . '">' . ( $has_map ? 'Propose the map again' : 'Propose the map' ) . '</a> ' : '' )
			. ( $has_facts ? $rm( 'facts', 'Facts' ) : '' ) . ( $has_map ? $rm( 'map', 'Map' ) : '' )
			. ( $has_faq ? $rm( 'faq', 'Know before you go' ) : '' ) . ( $has_who ? $rm( 'who', 'Who takes you there' ) : '' );
		LMGT_Steps::row( $n, 'Boxes', $has_faq ? 'done' : 'todo', $txt, $btn );
	}

	// ---- Box 4: the fact box (2.9.4, G, 9 Nov) ----------------------------------------------

	/** Every number in $value must be in the text, else the row goes (accuracy: nothing invented). */
	private static function numbers_ok( $value, $plain ) {
		if ( ! preg_match_all( '/\d+(?:[.,]\d+)?/u', $value, $m ) ) return true;
		$flat = preg_replace( '/(?<=\d)[ .\x{00A0}](?=\d{3}\b)/u', '', $plain );
		foreach ( $m[0] as $num ) {
			$n = preg_replace( '/(?<=\d)[.](?=\d{3}\b)/', '', $num );
			if ( strpos( $plain, $num ) === false && strpos( $flat, $n ) === false ) return false;
		}
		return true;
	}

	public static function propose_facts( $id ) {
		$post = get_post( $id );
		if ( ! $post ) return new WP_Error( 'lmgt', 'Not found.' );
		$lang  = self::lang_of( $post );
		$a     = LMGT_Langs::get( $lang );
		$place = self::place_name( $post );
		$plain = LMGT_Text::plain( preg_replace( '#<!-- lmgt:(facts|faq|who|map) -->.*?<!-- /lmgt:\1 -->#s', '', $post->post_content ) );
		$prompt = "ARTICLE is a {$a['name']} " . self::sub( 'article' ) . " about {$place}. Make a fact box: 4 to 8 short rows " . self::sub( 'rows' ) . ", in {$a['name']}.\n"
			. "Each row: label (2 to 4 words, e.g. " . self::sub( 'eg' ) . ") and value (at most 12 words).\n"
			. "Use only facts in ARTICLE. Copy every number, price, currency and date exactly as ARTICLE writes it; never convert, round or add one. Leave a row out when ARTICLE does not say it.\n"
			. "Return JSON: {\"rows\":[{\"label\":\"…\",\"value\":\"…\"}]}.\n\nARTICLE:\n" . mb_substr( $plain, 0, 30000 );
		@set_time_limit( 200 );
		$r = LMGT_Engines::ai_json( $prompt );
		if ( is_wp_error( $r ) ) return $r;
		$rows    = array();
		$dropped = 0;
		foreach ( (array) ( isset( $r['rows'] ) ? $r['rows'] : array() ) as $x ) {
			if ( empty( $x['label'] ) || empty( $x['value'] ) ) continue;
			$v = sanitize_text_field( $x['value'] );
			if ( ! self::numbers_ok( $v, $plain ) ) { $dropped++; continue; }
			$rows[] = array( 'label' => sanitize_text_field( $x['label'] ), 'value' => $v );
		}
		if ( ! $rows ) return new WP_Error( 'lmgt', 'No facts came back that the text supports. Add the facts to the text, then try again.' );
		update_post_meta( $id, '_lmgt_facts_pending', wp_slash( array( 'rows' => array_slice( $rows, 0, 8 ), 'dropped' => $dropped, 'at' => current_time( 'mysql', true ) ) ) );
		return array( count( $rows ) );
	}

	public static function handle_facts_propose() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_facts_propose_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$back = get_edit_post_link( $id, 'url' );
		$r    = self::propose_facts( $id );
		if ( is_wp_error( $r ) ) self::back( $back, $r->get_error_message() );
		self::back( $back, $r[0] . ' rows proposed for the fact box. Read them in the panel and press Accept.' );
	}

	private static function facts_html( array $rows, $lang, $place ) {
		$da    = $lang === 'da';
		$title = $da ? 'Fakta om ' . $place : $place . ' at a glance';
		$foot  = ( $da ? 'Fra artiklen. Tjekket ' : 'From this article. Checked ' ) . wp_date( $da ? 'j. F Y' : 'j F Y' ) . ( $da ? '. Priser er vejledende.' : '. Prices are a guide.' );
		$h = '<div class="lmgt-box lmgt-facts" data-lmgt="facts"><h2>' . esc_html( $title ) . '</h2><dl>';
		foreach ( $rows as $r ) $h .= '<dt>' . esc_html( $r['label'] ) . '</dt><dd>' . esc_html( $r['value'] ) . '</dd>';
		return $h . '</dl><p class="lmgt-facts-foot">' . esc_html( $foot ) . '</p></div>';
	}

	public static function handle_facts_apply() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_facts_apply_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$back = get_edit_post_link( $id, 'url' );
		$p    = get_post_meta( $id, '_lmgt_facts_pending', true );
		delete_post_meta( $id, '_lmgt_facts_pending' );
		if ( ! isset( $_GET['do'] ) || $_GET['do'] !== 'apply' || ! is_array( $p ) ) self::back( $back, 'Facts rejected. The text is unchanged.' );
		$post = get_post( $id );
		$box  = self::facts_html( $p['rows'], self::lang_of( $post ), self::place_name( $post ) );
		$html = $post->post_content;
		if ( strpos( $html, '<!-- lmgt:facts -->' ) !== false ) {
			$html = self::put( $html, 'facts', $box );
		} else {
			// After the intro: before the first main heading, else at the end.
			$blocks = strpos( $html, '<!-- wp:' ) !== false;
			$full   = "<!-- lmgt:facts -->\n" . ( $blocks ? "<!-- wp:html -->\n" . $box . "\n<!-- /wp:html -->" : $box ) . "\n<!-- /lmgt:facts -->\n\n";
			$at     = self::intro_end( $html ); // 2.17.7: after the real intro, also when the text opens with a heading
			$html   = $at === false ? self::put( $html, 'facts', $box ) : substr_replace( $html, $full, $at, 0 );
		}
		LMGT_Store::update_content( $id, array( 'post_content' => $html ) );
		delete_post_meta( $id, '_lmgt_reviewed' );
		self::back( $back, 'Fact box put in the text, after the intro. The previous version is under Revisions.' );
	}


	// ---- Box 5: the map (2.15.0, G, 13 Nov) -------------------------------------------------

	/** One place on OpenStreetMap (Nominatim), kept a month. [lat, lon, label] or null. */
	private static function geocode( $q ) {
		$key = 'lmgt_geo_' . md5( $q );
		$c   = get_transient( $key );
		if ( is_array( $c ) ) return $c ? $c : null;
		// Nominatim allows one request a second and asks for a name that identifies the caller.
		usleep( 1100000 );
		$r = wp_remote_get( add_query_arg( array( 'q' => $q, 'format' => 'jsonv2', 'limit' => 1 ), 'https://nominatim.openstreetmap.org/search' ), array(
			'timeout' => 20,
			'headers' => array( 'User-Agent' => 'LMG-Translator/' . LMGT_VERSION . ' (' . home_url() . ')', 'Accept-Language' => 'en' ),
		) );
		if ( is_wp_error( $r ) || wp_remote_retrieve_response_code( $r ) !== 200 ) return null;
		$j   = json_decode( wp_remote_retrieve_body( $r ), true );
		$hit = ( is_array( $j ) && ! empty( $j[0]['lat'] ) ) ? array( (float) $j[0]['lat'], (float) $j[0]['lon'], (string) $j[0]['display_name'] ) : array();
		set_transient( $key, $hit, MONTH_IN_SECONDS );
		return $hit ? $hit : null;
	}

	public static function propose_map( $id ) {
		$post = get_post( $id );
		if ( ! $post ) return new WP_Error( 'lmgt', 'Not found.' );
		$lang  = self::lang_of( $post );
		$a     = LMGT_Langs::get( $lang );
		$place = self::place_name( $post );
		$plain = LMGT_Text::plain( preg_replace( '#<!-- lmgt:(facts|faq|who|map) -->.*?<!-- /lmgt:\1 -->#s', '', $post->post_content ) );
		$prompt = "ARTICLE is a {$a['name']} " . self::sub( 'article' ) . " about {$place}. Pick 4 to 8 places ARTICLE names that a reader would want to see on a map: " . self::sub( 'map' ) . ". Spread them across the article; no two in the same spot.\n"
			. "For each: name (as ARTICLE writes it, in {$a['name']}), search (the place's name in English plus the country, so a map search finds it, e.g. \"Lake Louise, Alberta, Canada\") and note (at most 8 words, in {$a['name']}, taken from ARTICLE).\n"
			. "Only places ARTICLE names. Return JSON: {\"places\":[{\"name\":\"…\",\"search\":\"…\",\"note\":\"…\"}]}.\n\nARTICLE:\n" . mb_substr( $plain, 0, 30000 );
		@set_time_limit( 300 );
		$r = LMGT_Engines::ai_json( $prompt );
		if ( is_wp_error( $r ) ) return $r;
		$pts    = array();
		$missed = array();
		foreach ( array_slice( (array) ( isset( $r['places'] ) ? $r['places'] : array() ), 0, 8 ) as $x ) {
			if ( empty( $x['name'] ) || empty( $x['search'] ) ) continue;
			$name = sanitize_text_field( $x['name'] );
			// The place must be in the text: nothing invented.
			if ( mb_stripos( $plain, $name ) === false ) continue;
			$g = self::geocode( sanitize_text_field( $x['search'] ) );
			if ( ! $g ) { $missed[] = $name; continue; }
			$pts[] = array( 'name' => $name, 'note' => isset( $x['note'] ) ? sanitize_text_field( $x['note'] ) : '', 'lat' => round( $g[0], 5 ), 'lon' => round( $g[1], 5 ), 'found' => $g[2] );
		}
		if ( count( $pts ) < 2 ) return new WP_Error( 'lmgt', 'Fewer than two places named in the text were found on the map. Nothing proposed.' );
		update_post_meta( $id, '_lmgt_map_pending', wp_slash( array( 'points' => $pts, 'missed' => $missed, 'at' => current_time( 'mysql', true ) ) ) );
		return array( count( $pts ) );
	}

	public static function handle_map_propose() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_map_propose_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$back = get_edit_post_link( $id, 'url' );
		$r    = self::propose_map( $id );
		if ( is_wp_error( $r ) ) self::back( $back, $r->get_error_message() );
		self::back( $back, $r[0] . ' places proposed for the map. Check them in the panel and press Accept.' );
	}

	/**
	 * 2.17.0 (G, 13 Nov: "better, more private"): the map is one picture made on this server when the box is
	 * accepted, saved in the media library. Readers load only this site's own image: no outside server sees them,
	 * nothing for the cookie banner, no map script. $img = [url, width, height] or null (then the list stands alone).
	 */
	private static function map_html( array $pts, $lang, $place, $img = null ) {
		$da    = $lang === 'da';
		$title = $da ? 'Kort over ' . $place : $place . ' on the map';
		$names = implode( ', ', wp_list_pluck( $pts, 'name' ) );
		$h = '<div class="lmgt-box lmgt-map" data-lmgt="map"><h2>' . esc_html( $title ) . '</h2>';
		$uid = 'lmgt-m' . substr( md5( $place . $names ), 0, 6 );
		if ( $img ) $h .= '<div class="lmgt-map-wrap"><img class="lmgt-map-img" src="' . esc_url( $img[0] ) . '" width="' . (int) $img[1] . '" height="' . (int) $img[2] . '" loading="lazy" decoding="async" alt="' . esc_attr( ( $da ? 'Kort over ' . $place . ' med ' : 'Map of ' . $place . ' showing ' ) . $names ) . '">';
		// 2.17.1: a hotspot over each pin – the name on hover, a click jumps to the place in the list. Nothing loads from outside.
		if ( $img && ! empty( $img[3] ) ) foreach ( $img[3] as $i => $c ) $h .= '<a class="lmgt-map-hit" href="#' . $uid . '-' . ( $i + 1 ) . '" style="left:' . $c[0] . '%;top:' . $c[1] . '%" title="' . esc_attr( ( $i + 1 ) . '. ' . $pts[ $i ]['name'] ) . '" aria-label="' . esc_attr( $pts[ $i ]['name'] ) . '"></a>';
		if ( $img ) $h .= '</div>';
		$h .= '<ol class="lmgt-map-list">';
		foreach ( $pts as $i => $p ) $h .= '<li id="' . $uid . '-' . ( $i + 1 ) . '"><strong>' . esc_html( $p['name'] ) . '</strong>' . ( $p['note'] !== '' ? ' – ' . esc_html( $p['note'] ) : '' ) . '</li>';
		return $h . '</ol><p class="lmgt-facts-foot">' . ( $da ? 'Kort: ' : 'Map: ' ) . '© <a href="https://www.openstreetmap.org/copyright" rel="nofollow noopener" target="_blank">OpenStreetMap</a> contributors · relief © OpenTopoMap</p></div>';
	}

	const MAP_W = 1200;
	const MAP_H = 720;

	/** Web Mercator: world pixel position at zoom $z. */
	private static function px( $lat, $lon, $z ) {
		$n = 256 * pow( 2, $z );
		$s = sin( deg2rad( max( -85, min( 85, $lat ) ) ) );
		return array( ( $lon + 180 ) / 360 * $n, ( 0.5 - log( ( 1 + $s ) / ( 1 - $s ) ) / ( 4 * M_PI ) ) * $n );
	}

	private static function tile( $url ) {
		$r = wp_remote_get( $url, array( 'timeout' => 20, 'headers' => array( 'User-Agent' => 'LMG-Translator/' . LMGT_VERSION . ' (' . home_url() . ')' ) ) );
		if ( is_wp_error( $r ) || wp_remote_retrieve_response_code( $r ) !== 200 ) return null;
		$im = @imagecreatefromstring( wp_remote_retrieve_body( $r ) );
		return $im ? $im : null;
	}

	/** Make the map picture and save it in the media library; [url, w, h] or WP_Error. */
	public static function map_image( array $pts, $post_id, $title ) {
		if ( ! function_exists( 'imagecreatetruecolor' ) ) return new WP_Error( 'lmgt', 'This server has no image library (GD), so the map picture cannot be made.' );
		@set_time_limit( 300 );
		$W = self::MAP_W; $H = self::MAP_H; $pad = 90;
		// The closest zoom where every place fits inside the picture with a margin.
		$z = 12;
		for ( ; $z > 2; $z-- ) {
			$xy = array_map( function ( $p ) use ( $z ) { return self::px( $p['lat'], $p['lon'], $z ); }, $pts );
			$xs = wp_list_pluck( $xy, 0 ); $ys = wp_list_pluck( $xy, 1 );
			if ( max( $xs ) - min( $xs ) <= $W - 2 * $pad && max( $ys ) - min( $ys ) <= $H - 2 * $pad ) break;
		}
		$xy = array_map( function ( $p ) use ( $z ) { return self::px( $p['lat'], $p['lon'], $z ); }, $pts );
		$xs = wp_list_pluck( $xy, 0 ); $ys = wp_list_pluck( $xy, 1 );
		$x0 = ( min( $xs ) + max( $xs ) ) / 2 - $W / 2;
		$y0 = ( min( $ys ) + max( $ys ) ) / 2 - $H / 2;
		$im   = imagecreatetruecolor( $W, $H );
		$rel  = imagecreatetruecolor( $W, $H );
		imagefill( $im, 0, 0, imagecolorallocate( $im, 232, 228, 218 ) );
		imagefill( $rel, 0, 0, imagecolorallocate( $rel, 255, 255, 255 ) );
		$max  = pow( 2, $z );
		$got  = 0; $relief = $z <= 15;
		for ( $tx = (int) floor( $x0 / 256 ); $tx <= (int) floor( ( $x0 + $W ) / 256 ); $tx++ ) {
			for ( $ty = (int) floor( $y0 / 256 ); $ty <= (int) floor( ( $y0 + $H ) / 256 ); $ty++ ) {
				if ( $ty < 0 || $ty >= $max ) continue;
				$wx = ( ( $tx % $max ) + $max ) % $max;
				$dx = (int) round( $tx * 256 - $x0 ); $dy = (int) round( $ty * 256 - $y0 );
				// The OpenStreetMap tile policy asks for a clear name and few requests: one at a time, cached as the picture itself.
				$t = self::tile( "https://tile.openstreetmap.org/{$z}/{$wx}/{$ty}.png" );
				if ( $t ) { imagecopy( $im, $t, $dx, $dy, 0, 0, 256, 256 ); imagedestroy( $t ); $got++; }
				if ( $relief ) {
					$t = self::tile( 'https://' . 'abc'[ ( $wx + $ty ) % 3 ] . ".tile.opentopomap.org/{$z}/{$wx}/{$ty}.png" );
					if ( $t ) { imagecopy( $rel, $t, $dx, $dy, 0, 0, 256, 256 ); imagedestroy( $t ); }
				}
			}
		}
		if ( ! $got ) { imagedestroy( $im ); imagedestroy( $rel ); return new WP_Error( 'lmgt', 'The map pictures could not be fetched from OpenStreetMap. Try again in a minute.' ); }
		// The agreed look (G, 13 Nov): almost grey with a hint of blue water, faint grey mountains and contour lines.
		$grey = imagecreatetruecolor( $W, $H );
		imagecopy( $grey, $im, 0, 0, 0, 0, $W, $H );
		imagefilter( $grey, IMG_FILTER_GRAYSCALE );
		imagecopymerge( $im, $grey, 0, 0, 0, 0, $W, $H, 82 );
		imagedestroy( $grey );
		imagefilter( $im, IMG_FILTER_BRIGHTNESS, 14 );
		if ( $relief ) {
			imagefilter( $rel, IMG_FILTER_GRAYSCALE );
			imagefilter( $rel, IMG_FILTER_CONTRAST, -10 );
			imagecopymerge( $im, $rel, 0, 0, 0, 0, $W, $H, 30 );
		}
		imagedestroy( $rel );
		// 2.17.1 (G, 13 Nov): pins closer than a pin's width are nudged apart, a thin line back to the true spot.
		$pos = array();
		foreach ( $xy as $p ) $pos[] = array( $p[0] - $x0, $p[1] - $y0 );
		$true = $pos;
		for ( $k = 0; $k < 60; $k++ ) {
			$moved = false;
			foreach ( $pos as $i => $a ) foreach ( $pos as $j => $b ) {
				if ( $j <= $i ) continue;
				$dx = $b[0] - $a[0]; $dy = $b[1] - $a[1]; $d = sqrt( $dx * $dx + $dy * $dy );
				if ( $d >= 46 ) continue;
				if ( $d < 0.01 ) { $dx = 1; $dy = 0; $d = 1; }
				$push = ( 46 - $d ) / 2 + 0.5;
				$pos[ $i ][0] -= $dx / $d * $push; $pos[ $i ][1] -= $dy / $d * $push;
				$pos[ $j ][0] += $dx / $d * $push; $pos[ $j ][1] += $dy / $d * $push;
				$moved = true;
			}
			if ( ! $moved ) break;
		}
		// Numbered pins.
		imageantialias( $im, true );
		$green = imagecolorallocate( $im, 47, 107, 79 ); $white = imagecolorallocate( $im, 255, 255, 255 ); $shadow = imagecolorallocatealpha( $im, 0, 0, 0, 90 );
		$dark = imagecolorallocate( $im, 47, 107, 79 );
		foreach ( $pos as $i => $p ) {
			$tx = (int) round( $true[ $i ][0] ); $ty = (int) round( $true[ $i ][1] );
			$cx = (int) round( $p[0] ); $cy = (int) round( $p[1] );
			if ( abs( $cx - $tx ) + abs( $cy - $ty ) > 3 ) {
				imagesetthickness( $im, 2 ); imageline( $im, $tx, $ty, $cx, $cy, $dark ); imagesetthickness( $im, 1 );
				imagefilledellipse( $im, $tx, $ty, 8, 8, $dark );
			}
		}
		foreach ( $pos as $i => $p ) {
			$cx = (int) round( $p[0] ); $cy = (int) round( $p[1] );
			imagefilledellipse( $im, $cx + 1, $cy + 2, 40, 40, $shadow );
			imagefilledellipse( $im, $cx, $cy, 40, 40, $white );
			imagefilledellipse( $im, $cx, $cy, 34, 34, $green );
			$n = (string) ( $i + 1 ); $f = 5;
			imagestring( $im, $f, $cx - (int) ( strlen( $n ) * imagefontwidth( $f ) / 2 ), $cy - (int) ( imagefontheight( $f ) / 2 ), $n, $white );
		}
		// Credit on the picture too, as the tile licences ask.
		$c = '(c) OpenStreetMap contributors, (c) OpenTopoMap (CC-BY-SA)';
		$cw = strlen( $c ) * imagefontwidth( 2 ) + 10;
		imagefilledrectangle( $im, $W - $cw, $H - 16, $W, $H, imagecolorallocatealpha( $im, 255, 255, 255, 30 ) );
		imagestring( $im, 2, $W - $cw + 5, $H - 15, $c, imagecolorallocate( $im, 70, 70, 70 ) );
		ob_start(); imagejpeg( $im, null, 84 ); $jpg = ob_get_clean(); imagedestroy( $im );
		$up = wp_upload_bits( 'map-' . sanitize_title( $title ) . '-' . $post_id . '.jpg', null, $jpg );
		if ( ! empty( $up['error'] ) ) return new WP_Error( 'lmgt', 'The map picture could not be saved: ' . $up['error'] );
		$att = wp_insert_attachment( array( 'post_mime_type' => 'image/jpeg', 'post_title' => $title, 'post_status' => 'inherit' ), $up['file'], $post_id );
		if ( ! is_wp_error( $att ) && $att ) {
			require_once ABSPATH . 'wp-admin/includes/image.php';
			wp_update_attachment_metadata( $att, wp_generate_attachment_metadata( $att, $up['file'] ) );
			update_post_meta( $att, '_wp_attachment_image_alt', $title );
			update_post_meta( $post_id, '_lmgt_map_image', (int) $att );
		}
		$pins = array();
		foreach ( $pos as $p ) $pins[] = array( round( $p[0] / $W * 100, 2 ), round( $p[1] / $H * 100, 2 ) );
		return array( $up['url'], $W, $H, $pins );
	}

	/**
	 * 2.17.7: where the intro ends – the start of the first heading (h2–h3, or a heading block) with at least
	 * 25 words of text above it, not counting headings and our boxes. Without such a heading: after the first
	 * paragraph that ends past 25 words. false when the text is too short to say.
	 */
	public static function intro_end( $html ) {
		$words = function ( $chunk ) {
			$chunk = preg_replace( '#<!-- lmgt:(\w+) -->.*?<!-- /lmgt:\1 -->#s', ' ', $chunk );
			$chunk = preg_replace( '#<h[1-6][^>]*>.*?</h[1-6]>#is', ' ', $chunk );
			$t = trim( wp_strip_all_tags( $chunk ) );
			return $t === '' ? 0 : count( preg_split( '/\s+/u', $t ) );
		};
		if ( preg_match_all( '#(?:<!-- wp:heading[^>]*-->\s*)?<h[23][\s>]#i', $html, $hm, PREG_OFFSET_CAPTURE ) ) {
			foreach ( $hm[0] as $m ) if ( $words( substr( $html, 0, $m[1] ) ) >= 25 ) return $m[1];
		}
		if ( preg_match_all( '#</p>|\R\s*\R#', $html, $pm, PREG_OFFSET_CAPTURE ) ) {
			foreach ( $pm[0] as $m ) {
				$end = $m[1] + strlen( $m[0] );
				if ( $words( substr( $html, 0, $end ) ) >= 25 ) {
					// After a paragraph block's closing comment too.
					if ( preg_match( '#\G\s*<!-- /wp:paragraph -->#', $html, $c, 0, $end ) ) $end += strlen( $c[0] );
					return $end;
				}
			}
		}
		return false;
	}

	public static function handle_map_apply() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_map_apply_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$back = get_edit_post_link( $id, 'url' );
		$p    = get_post_meta( $id, '_lmgt_map_pending', true );
		delete_post_meta( $id, '_lmgt_map_pending' );
		if ( ! isset( $_GET['do'] ) || $_GET['do'] !== 'apply' || ! is_array( $p ) ) self::back( $back, 'Map rejected. The text is unchanged.' );
		$post = get_post( $id );
		$lang  = self::lang_of( $post );
		$place = self::place_name( $post );
		$img   = self::map_image( $p['points'], $id, ( $lang === 'da' ? 'Kort over ' : 'Map of ' ) . $place );
		// No picture: keep the proposal so Accept can be pressed again, and change nothing.
		if ( is_wp_error( $img ) ) { update_post_meta( $id, '_lmgt_map_pending', wp_slash( $p ) ); self::back( $back, $img->get_error_message() ); }
		$box   = self::map_html( $p['points'], $lang, $place, $img );
		// 2.17.5 (G, 14 Nov): the map goes high – right after the intro, before the first main heading (and before
		// the fact box). "canada map" is searched; the map is worth seeing first. An existing map moves up too.
		$html   = self::put( $post->post_content, 'map', '' );
		$html   = self::without_google_maps( $html, $gone );
		$blocks = strpos( $html, '<!-- wp:' ) !== false;
		$full   = "<!-- lmgt:map -->\n" . ( $blocks ? "<!-- wp:html -->\n" . $box . "\n<!-- /wp:html -->" : $box ) . "\n<!-- /lmgt:map -->\n\n";
		// 2.17.7 (G, 14 Nov, Roman wine bar on traveltalk.dk): many texts open with a heading, so "before the first heading"
		// put the map at the very top. Now: after the intro – the first heading that has real text above it.
		$fx     = strpos( $html, '<!-- lmgt:facts -->' );
		$at     = self::intro_end( $html );
		// A fact box sitting at the end of the intro: the map goes right before it (map, then facts).
		if ( $fx !== false && $at !== false && abs( $fx - $at ) < 200 ) $at = min( $fx, $at );
		$html   = $at === false ? self::put( $html, 'map', $box ) : substr_replace( $html, $full, $at, 0 );
		LMGT_Store::update_content( $id, array( 'post_content' => $html ) );
		delete_post_meta( $id, '_lmgt_reviewed' );
		self::back( $back, 'Map put in the text, after the intro.' . ( $gone ? ' ' . $gone . ' Google map(s) taken out of the text.' : '' ) . ' The previous version is under Revisions.' );
	}

	/** 2.17.5 (G, 14 Nov): our map replaces Google maps embedded by hand; $n = how many were taken out. */
	public static function without_google_maps( $html, &$n = 0 ) {
		$n = 0;
		$html = preg_replace( '#<iframe[^>]*(?:google\.[a-z.]+/maps|maps\.google\.)[^>]*>\s*</iframe>#is', '', $html, -1, $n );
		if ( $n ) {
			$html = preg_replace( '#<!-- wp:html -->\s*<!-- /wp:html -->\s*#', '', $html );
			$html = preg_replace( '#<p>\s*(?:&nbsp;|\xC2\xA0)?\s*</p>\s*#', '', $html );
			$html = preg_replace( '#<figure[^>]*>\s*(?:<div[^>]*>\s*</div>)?\s*</figure>\s*#', '', $html );
		}
		return $html;
	}

	/**
	 * Leaflet only on pages that still carry a 2.15–2.16 live map (lmgt-map-canvas); 2.17.0 maps are pictures and load nothing; no cookies. 2.15.1 (G, 13 Nov: "keep the grey and lines, add some
	 * mountains and lakes"). 2.16.1: CARTO now wants a key (its tiles said "API KEY REQUIRED"), so the base is
	 * OpenStreetMap's own map, almost grey with a hint of blue water, under OpenTopoMap's faint grey relief.
	 */
	public static function map_script() {
		if ( ! is_singular() ) return;
		$post = get_queried_object();
		if ( ! $post || strpos( (string) $post->post_content, 'lmgt-map-canvas' ) === false ) return;
		echo '<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="">'
			. '<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>'
			. "<script>(function(){if(!window.L)return;document.querySelectorAll('.lmgt-map-canvas').forEach(function(el){var p;try{p=JSON.parse(el.getAttribute('data-points'))}catch(e){return}if(!p||!p.length)return;var m=L.map(el,{scrollWheelZoom:false});L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:18,className:'lmgt-base',attribution:'&copy; OpenStreetMap'}).addTo(m);L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',{maxZoom:15,subdomains:'abc',opacity:.35,className:'lmgt-relief',attribution:'&copy; OpenTopoMap'}).addTo(m);var b=[];p.forEach(function(x){var ic=L.divIcon({className:'lmgt-pin',html:'<span>'+x[0]+'</span>',iconSize:[26,26]});L.marker([x[1],x[2]],{icon:ic,title:x[3]}).addTo(m).bindPopup(String(x[3]).replace(/[<>&]/g,''));b.push([x[1],x[2]])});m.fitBounds(b,{padding:[30,30],maxZoom:10})})})();</script>\n";
	}

	/**
	 * 2.17.5 (G, 14 Nov, Canada): the questions box came back with its tags broken – heading never closed,
	 * every answer saved as a large heading – so answers showed in heading letters. Read the box as
	 * title, then question (h3) and answer (whatever follows until the next question), and draw it again.
	 * Done when the page is shown, so any damage to the saved text is repaired without touching it.
	 */
	public static function faq_parts( $inner ) {
		if ( ! preg_match_all( '#<h3[^>]*>(.*?)</h3>#is', $inner, $q, PREG_OFFSET_CAPTURE ) || ! $q[0] ) return null;
		$title = trim( wp_strip_all_tags( substr( $inner, 0, $q[0][0][1] ) ) );
		$qa    = array();
		foreach ( $q[0] as $i => $m ) {
			$from = $m[1] + strlen( $m[0] );
			$to   = isset( $q[0][ $i + 1 ] ) ? $q[0][ $i + 1 ][1] : strlen( $inner );
			$a    = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( html_entity_decode( substr( $inner, $from, $to - $from ), ENT_QUOTES, 'UTF-8' ) ) ) );
			$qq   = trim( wp_strip_all_tags( html_entity_decode( $q[1][ $i ][0], ENT_QUOTES, 'UTF-8' ) ) );
			if ( $qq !== '' && $a !== '' ) $qa[] = array( 'q' => $qq, 'a' => $a );
		}
		return $qa ? array( html_entity_decode( $title, ENT_QUOTES, 'UTF-8' ), $qa ) : null;
	}

	public static function heal_faq( $content ) {
		if ( strpos( $content, 'lmgt-faq' ) === false ) return $content;
		// Up to the box's end marker; without one, only up to the box's own closing </div> – never the rest of the article.
		$pat = strpos( $content, '<!-- /lmgt:faq -->' ) !== false ? '#<div class="lmgt-box lmgt-faq"[^>]*>(.*?)(?=<!-- /lmgt:faq -->)#is' : '#<div class="lmgt-box lmgt-faq"[^>]*>((?:(?!<div).)*?)</div>#is';
		return preg_replace_callback( $pat, function ( $m ) {
			$x = self::faq_parts( $m[1] );
			if ( ! $x ) return $m[0];
			$h = '<div class="lmgt-box lmgt-faq" data-lmgt="faq"><h2>' . esc_html( $x[0] ) . '</h2>';
			foreach ( $x[1] as $e ) $h .= '<h3>' . esc_html( $e['q'] ) . '</h3><p>' . esc_html( $e['a'] ) . '</p>';
			return $h . "</div>\n";
		}, $content );
	}

	// ---- Front: schema and look -------------------------------------------------------------

	public static function schema() {
		if ( ! is_singular() ) return;
		$post = get_queried_object();
		if ( ! $post || empty( $post->post_content ) ) return;
		$c   = $post->post_content;
		$out = array();
		if ( preg_match( '#<!-- lmgt:faq -->(.*?)<!-- /lmgt:faq -->#s', $c, $m ) && ( $px = self::faq_parts( $m[1] ) ) ) {
			$items = array();
			foreach ( $px[1] as $x ) $items[] = array( '@type' => 'Question', 'name' => $x['q'], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $x['a'] ) );
			$out[] = array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $items );
		}
		if ( preg_match( '#<!-- lmgt:who -->(.*?)<!-- /lmgt:who -->#s', $c, $m ) && preg_match_all( '#<a href="([^"]+)"[^>]*>(.*?)</a>#s', $m[1], $ws, PREG_SET_ORDER ) ) {
			$items = array();
			foreach ( $ws as $i => $x ) $items[] = array( '@type' => 'ListItem', 'position' => $i + 1, 'item' => array( '@type' => 'Organization', 'name' => wp_strip_all_tags( html_entity_decode( $x[2], ENT_QUOTES, 'UTF-8' ) ), 'url' => esc_url_raw( $x[1] ) ) );
			$out[] = array( '@context' => 'https://schema.org', '@type' => 'ItemList', 'name' => 'Who takes you there', 'itemListElement' => $items );
		}
		foreach ( $out as $o ) echo '<script type="application/ld+json">' . wp_json_encode( $o, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "</script>\n";
	}

	public static function css() {
		if ( ! is_singular() ) return;
		echo '<style>.lmgt-box{border-left:4px solid #b08d57;background:#f7f4ee;padding:18px 22px;margin:32px 0;border-radius:6px}.lmgt-box h2{margin-top:0}.lmgt-box h3{font-size:1.05em;margin:16px 0 4px}.lmgt-box ul{margin:4px 0 8px 18px}.lmgt-faq h3{font-weight:600}.lmgt-facts dl{display:grid;grid-template-columns:minmax(120px,38%) 1fr;gap:6px 16px;margin:0}.lmgt-facts dt{font-weight:600}.lmgt-facts dd{margin:0}.lmgt-facts-foot{font-size:.85em;opacity:.75;margin:12px 0 0}.lmgt-map-canvas{height:380px;border-radius:4px;margin:8px 0 12px;background:#e8e4da}.lmgt-map-wrap{position:relative;margin:8px 0 12px}.lmgt-map-img{display:block;width:100%;height:auto;border-radius:4px;margin:0}.lmgt-map-hit{position:absolute;width:4.2%;aspect-ratio:1;transform:translate(-50%,-50%);border-radius:50%;display:block}.lmgt-map-hit:hover,.lmgt-map-hit:focus{box-shadow:0 0 0 3px #fff,0 0 0 5px #2f6b4f}.lmgt-box .lmgt-map-list,.lmgt-box .lmgt-map-list li{font-size:1rem;line-height:1.55;font-weight:400;font-family:inherit;letter-spacing:normal}.lmgt-box .lmgt-map-list li strong{font-weight:600}.lmgt-map-list li:target{background:#e6efe9;border-radius:3px}.lmgt-map-list{margin:0 0 0 22px}.lmgt-base{filter:saturate(.18) brightness(1.06)}.lmgt-relief{filter:grayscale(1) contrast(1.1)}.lmgt-pin span{display:block;width:26px;height:26px;border-radius:50%;background:#2f6b4f;color:#fff;font:600 13px/26px sans-serif;text-align:center;border:2px solid #fff;box-shadow:0 1px 3px rgba(0,0,0,.4)}@media(max-width:600px){.lmgt-facts dl{grid-template-columns:1fr}.lmgt-facts dd{margin-bottom:8px}}</style>' . "\n";
	}

	private static function back( $url, $msg ) {
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $msg ), $url ) );
		exit;
	}
}
