<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.2.4: image texts in the right language.
 *
 * Catch-up (brief 4.19, first item), on .dk: Translator → Catch-up translates
 * the featured image's alt text and caption for translations on .travel that
 * lack them (made before 2.2.0). Only those two texts; the article is not
 * touched, so no review. .travel lists the gaps (GET /catchup) and stores each
 * answer only where the text is still missing (POST /thumbtexts).
 *
 * Image texts, on any site: Translator → Image texts asks Claude, 25 images a
 * call, whether each image's alt text, caption, title and description are in
 * the site's own language, and proposes texts where they are not. Nothing is
 * changed until a person ticks and applies; the old texts are kept.
 *
 * Meta on an attachment:
 *   _lmgt_text_check   [at, ok, proposal => [alt, caption, title, description], applied?, dismissed?]
 *   _lmgt_text_before  the four texts as they were before "Apply"
 */
class LMGT_Media {

	const ITEMS  = 'lmgt_catchup_items';
	const FIELDS = array( 'alt', 'caption', 'title', 'description' );

	public static function boot() {
		add_action( 'admin_menu', function () {
			add_submenu_page( 'lmgt', 'Image texts', 'Image texts', 'edit_others_posts', 'lmgt-images', array( __CLASS__, 'page_images' ) );
			if ( LMGT_Bridge::is_source() ) add_submenu_page( 'lmgt', 'Catch-up', 'Catch-up', 'edit_others_posts', 'lmgt-catchup', array( __CLASS__, 'page_catchup' ) );
		}, 26 );
		add_action( 'wp_ajax_lmgt_images', array( __CLASS__, 'ajax_images' ) );
		add_action( 'admin_post_lmgt_images_apply', array( __CLASS__, 'handle_apply' ) );
		if ( ! LMGT_Bridge::on() ) return;
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		if ( LMGT_Bridge::is_source() ) add_action( 'wp_ajax_lmgt_catchup', array( __CLASS__, 'ajax_catchup' ) );
	}

	public static function routes() {
		if ( ! LMGT_Bridge::is_target() ) return;
		$can = function () { return current_user_can( 'edit_others_posts' ); };
		register_rest_route( LMGT_Bridge::NS, '/catchup', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_catchup' ), 'permission_callback' => $can ) );
		register_rest_route( LMGT_Bridge::NS, '/thumbtexts', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_thumbtexts' ), 'permission_callback' => $can ) );
	}

	// ---- Catch-up: featured-image texts (4.19) ----------------------------------

	/** Target: .dk translations whose featured image has no alt text in their language. */
	public static function rest_catchup() {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT p.ID, s.meta_value AS sid, l.meta_value AS lang FROM {$wpdb->posts} p
			JOIN {$wpdb->postmeta} s ON s.post_id = p.ID AND s.meta_key = '_lmgt_remote_source'
			JOIN {$wpdb->postmeta} l ON l.post_id = p.ID AND l.meta_key = '_lmgt_lang'
			WHERE p.post_type = %s AND p.post_status IN ('publish','draft','pending','future','private')", LMGT_CPT ) );
		$out = array();
		foreach ( $rows as $r ) {
			if ( get_post_meta( $r->ID, '_lmgt_adopted', true ) ) continue;
			$att = (int) get_post_thumbnail_id( $r->ID );
			if ( ! $att || get_post_meta( $att, '_lmgt_alt_' . $r->lang, true ) !== '' ) continue;
			$out[] = array( 'sid' => (int) $r->sid, 'lang' => $r->lang, 'id' => (int) $r->ID );
		}
		return $out;
	}

	/** Target: one translation's featured-image texts, stored only where still missing. */
	public static function rest_thumbtexts( WP_REST_Request $req ) {
		$p    = $req->get_json_params();
		$lang = isset( $p['lang'] ) ? (string) $p['lang'] : '';
		$id   = LMGT_Bridge::members( isset( $p['source_id'] ) ? (int) $p['source_id'] : 0 );
		foreach ( $id as $m ) {
			if ( get_post_meta( $m, '_lmgt_lang', true ) !== $lang || get_post_type( $m ) !== LMGT_CPT ) continue;
			LMGT_Sync::store_thumb_texts( get_post_thumbnail_id( $m ), $lang, $p, true );
			return array( 'id' => (int) $m );
		}
		return new WP_Error( 'lmgt_bad', 'No translation in that language for that original.', array( 'status' => 404 ) );
	}

	/** Source: start (fetch the list from .travel) or one step (up to four translations). */
	public static function ajax_catchup() {
		check_ajax_referer( 'lmgt_catchup' );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_send_json_error( 'Not allowed.' );
		if ( isset( $_POST['do'] ) && $_POST['do'] === 'start' ) {
			$list = LMGT_Bridge::call( 'GET', '/catchup', array(), false );
			if ( is_wp_error( $list ) ) wp_send_json_error( $list->get_error_message() );
			update_option( self::ITEMS, array_values( $list ), false );
			wp_send_json_success( array( 'left' => count( $list ), 'lines' => array() ) );
		}
		$items = (array) get_option( self::ITEMS, array() );
		$lines = array();
		foreach ( array_splice( $items, 0, 4 ) as $it ) {
			$thumb = (int) get_post_thumbnail_id( (int) $it['sid'] );
			$t     = $thumb ? LMGT_Sync::thumb_texts( $thumb, $it['lang'] ) : array();
			$where = '#' . (int) $it['sid'] . ' ' . $it['lang'];
			if ( empty( $t['alt'] ) && empty( $t['caption'] ) ) {
				$lines[] = $where . ': skipped – the Danish image has no alt text or caption';
				continue;
			}
			$r       = LMGT_Bridge::call( 'POST', '/thumbtexts', array( 'source_id' => (int) $it['sid'], 'lang' => $it['lang'], 'thumb_alt' => $t['alt'], 'thumb_caption' => $t['caption'] ), false );
			$lines[] = $where . ( is_wp_error( $r ) ? ': failed – ' . $r->get_error_message() : ': done' );
		}
		update_option( self::ITEMS, $items, false );
		if ( ! $items ) LMGT_Bridge::log( 'catch-up: featured-image texts finished' );
		wp_send_json_success( array( 'left' => count( $items ), 'lines' => $lines ) );
	}

	public static function page_catchup() {
		echo '<div class="wrap"><h1>Catch-up</h1><p>Brings older translations up to what newer versions add, without touching the article text. Re-translations stay on the Queue.</p>';
		if ( ! empty( $_GET['lmgt_msg'] ) ) echo '<div class="notice notice-info"><p>' . esc_html( wp_unslash( $_GET['lmgt_msg'] ) ) . '</p></div>';
		// 2.2.16: the overview and the move of translations still on .dk come first.
		do_action( 'lmgt_catchup_top' );
		$list = LMGT_Bridge::call( 'GET', '/catchup', array(), false );
		echo '<h2>Featured-image texts</h2>';
		if ( is_wp_error( $list ) ) {
			echo '<p>traveltalk.travel could not be asked: ' . esc_html( $list->get_error_message() ) . '</p>';
			do_action( 'lmgt_catchup_sections' );
			echo '</div>';
			return;
		}
		echo '<p><strong>' . count( $list ) . '</strong> translation(s) on traveltalk.travel have a featured image without alt text in their language (mostly made before 2.2.0). One short call each translates the Danish alt text and caption; the image and the article stay as they are.</p>';
		if ( $list ) {
			echo '<p><button class="button button-primary" id="lmgt-cu">Translate image texts</button> <span id="lmgt-cu-left"></span></p><pre id="lmgt-cu-log" style="max-height:300px;overflow:auto;background:#fff;padding:8px"></pre>';
			$n = wp_create_nonce( 'lmgt_catchup' );
			echo "<script>(function(){var b=document.getElementById('lmgt-cu'),l=document.getElementById('lmgt-cu-log'),s=document.getElementById('lmgt-cu-left');"
				. "function go(d){var f=new FormData();f.append('action','lmgt_catchup');f.append('do',d);f.append('_ajax_nonce','" . esc_js( $n ) . "');"
				. "fetch(ajaxurl,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){"
				. "if(!r.success){l.textContent+='Stopped: '+r.data+'\\n';b.disabled=false;return}r.data.lines.forEach(function(x){l.textContent+=x+'\\n'});s.textContent=r.data.left+' left';"
				. "if(r.data.left>0)go('step');else{s.textContent='Finished.';}}).catch(function(e){l.textContent+='Stopped: '+e+'\\n';b.disabled=false})}"
				. "b.addEventListener('click',function(){b.disabled=true;go('start')})})();</script>";
		}
		// Later catch-up items (2.2.5: alt texts in articles).
		do_action( 'lmgt_catchup_sections' );
		echo '</div>';
	}

	// ---- Image texts in the site's language --------------------------------------

	private static function texts( $id ) {
		$p = get_post( $id );
		return array(
			'alt'         => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
			'caption'     => $p ? (string) $p->post_excerpt : '',
			'title'       => $p ? (string) $p->post_title : '',
			'description' => $p ? (string) $p->post_content : '',
		);
	}

	private static function schema() {
		$item = array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'integer' ), 'ok' => array( 'type' => 'boolean' ) ), 'required' => array( 'id', 'ok' ), 'additionalProperties' => false );
		foreach ( array_merge( self::FIELDS, array( 'en' ) ) as $f ) {
			$item['properties'][ $f ] = array( 'type' => 'string' );
			$item['required'][]       = $f;
		}
		return array( 'type' => 'object', 'properties' => array( 'items' => array( 'type' => 'array', 'items' => $item ) ), 'required' => array( 'items' ), 'additionalProperties' => false );
	}

	public static function prompt( array $images ) {
		$l = LMGT_Langs::get( LMGT_Langs::source() )['name'];
		return "You check the texts of images on a travel website written in {$l}. For each image, decide whether all its non-empty texts (alt, caption, title, description) are written in natural {$l}.\n"
			. "- Names of places, people, businesses and brands are fine in any language. A title that looks like a file name (IMG_1234, copenhagen-rooftops-2) is fine.\n"
			. "- If any text is in another language or mixes languages: ok = false, and give {$l} versions of every non-empty text, same meaning and about the same length, names kept. Empty texts stay empty.\n"
			. "- If all are fine: ok = true, texts returned unchanged.\n"
			. ( LMGT_Langs::source() === 'en' ? "- en: an empty string.\n" : "- en: when ok is false, your new alt text (or caption, if there is no alt text) in English, word for word, for an editor who may not read {$l}; else an empty string.\n" )
			. "Return JSON {\"items\": [...]}, one item per image, with the same id.\n\nIMAGES:\n" . wp_json_encode( $images, JSON_UNESCAPED_UNICODE );
	}

	/** Images not checked yet, newest first. */
	private static function unchecked( $n ) {
		return get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => 'image', 'posts_per_page' => $n, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'DESC', 'no_found_rows' => true,
			'meta_query' => array( array( 'key' => '_lmgt_text_check', 'compare' => 'NOT EXISTS' ) ) ) );
	}

	private static function count_images( $meta = null ) {
		global $wpdb;
		$sql = "SELECT COUNT(*) FROM {$wpdb->posts} p WHERE p.post_type = 'attachment' AND p.post_mime_type LIKE 'image/%'";
		if ( $meta === 'checked' ) $sql .= " AND EXISTS (SELECT 1 FROM {$wpdb->postmeta} m WHERE m.post_id = p.ID AND m.meta_key = '_lmgt_text_check')";
		return (int) $wpdb->get_var( $sql );
	}

	/** One step: up to 25 unchecked images, one call. Images without any text are noted, not sent. */
	public static function ajax_images() {
		check_ajax_referer( 'lmgt_images' );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_send_json_error( 'Not allowed.' );
		$send = array();
		$now  = current_time( 'mysql', true );
		foreach ( self::unchecked( 25 ) as $id ) {
			$t = self::texts( $id );
			if ( implode( '', $t ) === '' ) {
				update_post_meta( $id, '_lmgt_text_check', array( 'at' => $now, 'ok' => true, 'empty' => true ) );
				continue;
			}
			$send[] = array_merge( array( 'id' => (int) $id ), $t );
		}
		$flagged = 0;
		if ( $send ) {
			if ( ! LMGT_Engines::ai_available() ) wp_send_json_error( 'No AI key saved (Translator → Settings).' );
			$r = LMGT_Engines::ai_json( self::prompt( $send ), self::schema() );
			if ( is_wp_error( $r ) ) wp_send_json_error( $r->get_error_message() );
			$ids = wp_list_pluck( $send, 'id' );
			foreach ( (array) ( isset( $r['items'] ) ? $r['items'] : array() ) as $it ) {
				$id = isset( $it['id'] ) ? (int) $it['id'] : 0;
				if ( ! in_array( $id, $ids, true ) ) continue;
				$ok = ! empty( $it['ok'] );
				$c  = array( 'at' => $now, 'ok' => $ok );
				if ( ! $ok ) {
					foreach ( self::FIELDS as $f ) $c['proposal'][ $f ] = isset( $it[ $f ] ) ? ( $f === 'alt' || $f === 'title' ? sanitize_text_field( $it[ $f ] ) : wp_kses_post( $it[ $f ] ) ) : '';
					$c['en'] = isset( $it['en'] ) ? sanitize_text_field( $it['en'] ) : '';
					$flagged++;
				}
				update_post_meta( $id, '_lmgt_text_check', $c );
			}
		}
		$total = self::count_images();
		wp_send_json_success( array( 'checked' => self::count_images( 'checked' ), 'total' => $total, 'flagged' => $flagged, 'done' => ! self::unchecked( 1 ) ) );
	}

	/** Apply (old texts kept in _lmgt_text_before) or dismiss the ticked proposals. */
	public static function handle_apply() {
		check_admin_referer( 'lmgt_images_apply' );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_die( 'Not allowed.' );
		$dismiss = isset( $_POST['lmgt_do'] ) && $_POST['lmgt_do'] === 'dismiss';
		$n       = 0;
		foreach ( array_map( 'intval', (array) ( isset( $_POST['lmgt_img'] ) ? $_POST['lmgt_img'] : array() ) ) as $id ) {
			$c = get_post_meta( $id, '_lmgt_text_check', true );
			if ( ! is_array( $c ) || ! empty( $c['ok'] ) || empty( $c['proposal'] ) || ! current_user_can( 'edit_post', $id ) ) continue;
			if ( $dismiss ) {
				$c['dismissed'] = current_time( 'mysql', true );
			} else {
				$before = self::texts( $id );
				update_post_meta( $id, '_lmgt_text_before', wp_slash( $before ) );
				$p   = $c['proposal'];
				$upd = array( 'ID' => $id );
				if ( $p['alt'] !== '' && $before['alt'] !== '' ) update_post_meta( $id, '_wp_attachment_image_alt', $p['alt'] );
				if ( $p['caption'] !== '' && $before['caption'] !== '' ) $upd['post_excerpt'] = $p['caption'];
				if ( $p['title'] !== '' && $before['title'] !== '' ) $upd['post_title'] = $p['title'];
				if ( $p['description'] !== '' && $before['description'] !== '' ) $upd['post_content'] = $p['description'];
				if ( count( $upd ) > 1 ) wp_update_post( wp_slash( $upd ) );
				$c['applied'] = current_time( 'mysql', true );
			}
			update_post_meta( $id, '_lmgt_text_check', $c );
			$n++;
		}
		$msg = $n . ' image(s) ' . ( $dismiss ? 'kept as they are.' : 'updated. The old texts are kept with each image.' );
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $msg ), admin_url( 'admin.php?page=lmgt-images' ) ) );
		exit;
	}

	public static function page_images() {
		$lang  = LMGT_Langs::get( LMGT_Langs::source() )['name'];
		$total = self::count_images();
		$done  = self::count_images( 'checked' );
		echo '<div class="wrap"><h1>Image texts</h1><p>Checks that each image\'s alt text, caption, title and description are in ' . esc_html( $lang ) . ', the language of this site, and proposes ' . esc_html( $lang ) . ' texts where they are not. Nothing changes until you tick and apply.</p>';
		echo '<p><strong>' . $done . '</strong> of <strong>' . $total . '</strong> images checked. <button class="button" id="lmgt-im">Check the rest</button> <span id="lmgt-im-st"></span></p>';
		$n = wp_create_nonce( 'lmgt_images' );
		echo "<script>(function(){var b=document.getElementById('lmgt-im'),s=document.getElementById('lmgt-im-st'),f=0;if(!b)return;"
			. "function go(){var d=new FormData();d.append('action','lmgt_images');d.append('_ajax_nonce','" . esc_js( $n ) . "');"
			. "fetch(ajaxurl,{method:'POST',body:d,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){"
			. "if(!r.success){s.textContent='Stopped: '+r.data;b.disabled=false;return}f+=r.data.flagged;s.textContent=r.data.checked+' of '+r.data.total+' checked, '+f+' with texts to fix';"
			. "if(!r.data.done)go();else{s.textContent+=' – finished. Reload to see them.';}}).catch(function(e){s.textContent='Stopped: '+e;b.disabled=false})}"
			. "b.addEventListener('click',function(){b.disabled=true;go()})})();</script>";
		$ids = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => 200, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'DESC', 'no_found_rows' => true, 'meta_key' => '_lmgt_text_check' ) );
		$rows = '';
		foreach ( $ids as $id ) {
			$c = get_post_meta( $id, '_lmgt_text_check', true );
			if ( ! is_array( $c ) || ! empty( $c['ok'] ) || ! empty( $c['applied'] ) || ! empty( $c['dismissed'] ) || empty( $c['proposal'] ) ) continue;
			$t     = self::texts( $id );
			$cells = '';
			foreach ( self::FIELDS as $f ) {
				$cells .= '<td>' . ( $t[ $f ] === '' ? '' : '<div style="color:#8a8a8f">' . esc_html( wp_trim_words( $t[ $f ], 30 ) ) . '</div><div>→ ' . esc_html( wp_trim_words( $c['proposal'][ $f ], 30 ) ) . '</div>' ) . '</td>';
			}
			$rows .= '<tr><td><input type="checkbox" name="lmgt_img[]" value="' . (int) $id . '"></td><td>' . wp_get_attachment_image( $id, array( 60, 60 ) ) . '<br><a href="' . esc_url( get_edit_post_link( $id ) ) . '">#' . (int) $id . '</a></td>' . $cells . '</tr>'
				. ( ! empty( $c['en'] ) ? '<tr><td></td><td colspan="5" class="description">In English: ' . esc_html( $c['en'] ) . '</td></tr>' : '' );
		}
		echo '<h2>Texts to fix</h2>';
		if ( $rows === '' ) {
			echo '<p>None found so far.</p></div>';
			return;
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="lmgt_images_apply">' . wp_nonce_field( 'lmgt_images_apply', '_wpnonce', true, false );
		echo '<table class="widefat striped"><thead><tr><td><input type="checkbox" onclick="document.querySelectorAll(\'[name=&quot;lmgt_img[]&quot;]\').forEach(function(c){c.checked=this.checked}.bind(this))"></td><th>Image</th><th>Alt text</th><th>Caption</th><th>Title</th><th>Description</th></tr></thead><tbody>' . $rows . '</tbody></table>';
		echo '<p><button class="button button-primary" name="lmgt_do" value="apply">Apply the ticked</button> <button class="button" name="lmgt_do" value="dismiss">Keep the ticked as they are</button></p>';
		echo '<p class="description">Grey: the text now. → the proposal. Pages already in the cache show new texts when the cache renews.</p></form></div>';
	}
}
