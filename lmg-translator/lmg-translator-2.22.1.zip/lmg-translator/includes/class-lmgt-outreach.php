<?php
/**
 * 2.8.0 (G, 9 Nov 2026): Translator → Outreach. Every local provider that goes onto the site with
 * a link (ticked by G after checking the website and the fit) lands here: company, website, the
 * article, the site, when. A ready mail text ("a free test ride on traveltalk…") to send from
 * G's or Mio's own mailbox, a status per company, and a CSV for LeisureRelate. Nothing is sent
 * from here: no unattended outreach (house style, automation rule).
 *
 * Option lmgt_outreach: [md5(web) => [name, web, kind, what, post, url, site, lang, at, status, note]].
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class LMGT_Outreach {

	const OPT    = 'lmgt_outreach';
	const STATES = array( 'new' => 'New', 'mailed' => 'Mailed', 'replied' => 'Replied', 'no_reply' => 'No reply', 'partner' => 'Working with us', 'declined' => 'Not interested' );

	public static function boot() {
		add_action( 'admin_menu', function () {
			add_submenu_page( 'lmgt', 'Outreach', 'Outreach', 'edit_others_posts', 'lmgt-outreach', array( __CLASS__, 'page' ) );
		}, 29 );
		add_action( 'admin_post_lmgt_outreach_save', array( __CLASS__, 'handle_save' ) );
		add_action( 'admin_post_lmgt_outreach_csv', array( __CLASS__, 'handle_csv' ) );
	}

	public static function add( array $pv, $post_id ) {
		if ( empty( $pv['web'] ) ) return;
		$all = (array) get_option( self::OPT, array() );
		$k   = md5( untrailingslashit( $pv['web'] ) . '|' . (int) $post_id );
		if ( isset( $all[ $k ] ) ) return;
		$all[ $k ] = array(
			'name'   => sanitize_text_field( $pv['name'] ),
			'web'    => esc_url_raw( $pv['web'] ),
			'kind'   => isset( $pv['kind'] ) && $pv['kind'] === 'abroad' ? 'abroad' : 'local',
			'what'   => isset( $pv['what'] ) ? sanitize_text_field( $pv['what'] ) : '',
			'post'   => (int) $post_id,
			'title'  => html_entity_decode( get_the_title( $post_id ), ENT_QUOTES, 'UTF-8' ),
			'url'    => get_permalink( $post_id ),
			'site'   => wp_parse_url( home_url(), PHP_URL_HOST ),
			'lang'   => get_post_type( $post_id ) === LMGT_CPT ? (string) get_post_meta( $post_id, '_lmgt_lang', true ) : LMGT_Langs::source(),
			'at'     => current_time( 'mysql', true ),
			'status' => 'new',
			'note'   => '',
		);
		update_option( self::OPT, $all, false );
	}

	/** The mail, in the article's language where we have it, else English. Sent by a person. */
	public static function mail( array $r ) {
		if ( $r['lang'] === 'da' ) {
			return "Emne: I er nævnt på traveltalk.dk\n\nHej " . $r['name'] . "\n\nVi har skrevet om " . $r['title'] . " på traveltalk.dk og nævner jer som en af de lokale virksomheder, der er værd at kende – med et link til jeres hjemmeside:\n" . $r['url'] . "\n\nArtiklen er redaktionel og uafhængig. Det koster intet, og I skal ikke gøre noget. Se det som en gratis prøvetur på traveltalk.\n\nVi vil meget gerne høre, hvad I synes, og om der er noget, vi bør tilføje eller rette. Og har I idéer til, hvordan vi kan hjælpe hinanden over for læsere, der vil rejse med jer, så sig endelig til.\n\nVenlig hilsen\nGunnar\ntraveltalk.dk";
		}
		return "Subject: You are featured on " . $r['site'] . "\n\nDear " . $r['name'] . ",\n\nWe have written about " . $r['title'] . " on " . $r['site'] . " and mention you as one of the local companies worth knowing, with a link to your website:\n" . $r['url'] . "\n\nThe article is editorial and independent. There is no cost and nothing you need to do: think of it as a free test ride on Traveltalk.\n\nWe would love to hear what you think, and whether there is anything we should add or correct. And if you have ideas for how we could help each other with readers who want to travel with you, please tell us.\n\nKind regards,\nGunnar\n" . $r['site'];
	}

	public static function handle_save() {
		check_admin_referer( 'lmgt_outreach_save' );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_die( 'Not allowed.' );
		$all = (array) get_option( self::OPT, array() );
		foreach ( (array) ( isset( $_POST['st'] ) ? $_POST['st'] : array() ) as $k => $v ) {
			if ( isset( $all[ $k ] ) && isset( self::STATES[ $v ] ) ) $all[ $k ]['status'] = $v;
		}
		foreach ( (array) ( isset( $_POST['note'] ) ? $_POST['note'] : array() ) as $k => $v ) {
			if ( isset( $all[ $k ] ) ) $all[ $k ]['note'] = sanitize_text_field( wp_unslash( $v ) );
		}
		update_option( self::OPT, $all, false );
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( 'Outreach list saved.' ), admin_url( 'admin.php?page=lmgt-outreach' ) ) );
		exit;
	}

	/** CSV for LeisureRelate: one row per company and article. */
	public static function handle_csv() {
		check_admin_referer( 'lmgt_outreach_csv' );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_die( 'Not allowed.' );
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=traveltalk-outreach-' . gmdate( 'Y-m-d' ) . '.csv' );
		$f = fopen( 'php://output', 'w' );
		fputcsv( $f, array( 'company', 'website', 'kind', 'what', 'article', 'article_url', 'site', 'language', 'added_utc', 'status', 'note' ) );
		foreach ( (array) get_option( self::OPT, array() ) as $r ) {
			fputcsv( $f, array( $r['name'], $r['web'], $r['kind'], $r['what'], $r['title'], $r['url'], $r['site'], $r['lang'], $r['at'], self::STATES[ $r['status'] ], $r['note'] ) );
		}
		fclose( $f );
		exit;
	}

	public static function page() {
		$all = (array) get_option( self::OPT, array() );
		uasort( $all, function ( $a, $b ) { return strcmp( $b['at'], $a['at'] ); } );
		echo '<div class="wrap"><h1>Outreach</h1>';
		if ( ! empty( $_GET['lmgt_msg'] ) ) echo '<div class="notice notice-success"><p>' . esc_html( wp_unslash( $_GET['lmgt_msg'] ) ) . '</p></div>';
		echo '<p>Companies now linked from the site, after you checked their website and the fit. Send each the mail from your own mailbox (copy it below), then set the status. Nothing is sent from here.</p>';
		if ( ! $all ) { echo '<p><em>None yet. They appear when a "Who takes you there" section with linked companies is added to a text.</em></p></div>'; return; }
		$csv = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_outreach_csv' ), 'lmgt_outreach_csv' );
		echo '<p><a class="button" href="' . esc_url( $csv ) . '">Download CSV for LeisureRelate</a></p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="lmgt_outreach_save">' . wp_nonce_field( 'lmgt_outreach_save', '_wpnonce', true, false );
		echo '<table class="widefat striped"><thead><tr><th>Company</th><th>On the page</th><th>Added</th><th>Status</th><th>Note</th><th>Mail</th></tr></thead><tbody>';
		foreach ( $all as $k => $r ) {
			$sel = '<select name="st[' . esc_attr( $k ) . ']">';
			foreach ( self::STATES as $s => $l ) $sel .= '<option value="' . esc_attr( $s ) . '"' . selected( $r['status'], $s, false ) . '>' . esc_html( $l ) . '</option>';
			$sel .= '</select>';
			echo '<tr><td><strong>' . esc_html( $r['name'] ) . '</strong><br><a href="' . esc_url( $r['web'] ) . '" target="_blank">' . esc_html( $r['web'] ) . '</a><br><span class="description">' . esc_html( $r['kind'] . ( $r['what'] ? ' · ' . $r['what'] : '' ) ) . '</span></td>'
				. '<td><a href="' . esc_url( $r['url'] ) . '" target="_blank">' . esc_html( $r['title'] ) . '</a><br><span class="description">' . esc_html( $r['site'] ) . '</span></td>'
				. '<td>' . esc_html( substr( $r['at'], 0, 10 ) ) . '</td><td>' . $sel . '</td>'
				. '<td><input type="text" name="note[' . esc_attr( $k ) . ']" value="' . esc_attr( $r['note'] ) . '" style="width:100%"></td>'
				. '<td><details><summary>Show mail</summary><textarea readonly rows="12" style="width:360px" onclick="this.select()">' . esc_textarea( self::mail( $r ) ) . '</textarea></details></td></tr>';
		}
		echo '</tbody></table><p><button class="button button-primary">Save</button></p></form></div>';
	}
}
