<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.2.7: pictures (G, 27 Oct 2026: longer texts should carry more pictures, not fewer).
 *
 * Related articles on .travel. The grid at the bottom of a .dk article is a
 * Kadence posts block that looks up .dk's own posts when the page is shown
 * (on traveltalk.dk often added by a snippet, not stored in the text), so on
 * .travel it was lost with its pictures. Now .dk shows the article as its page
 * does when it sends a draft, notes which articles it shows (their IDs),
 * their pictures and, where no translation exists yet, their titles translated
 * once; .travel draws the same grid from that (_lmgt_related). Each article
 * links to its published translation in the page's language, found when the
 * page is shown, else to the .dk article (rule 4.10), marked as Danish.
 * Catch-up on .dk sends the grid for translations made earlier, and refreshes
 * it, since .dk's grid changes as articles are published.
 *
 * Pictures per text length, any site: words per picture in the text, and the
 * stretches without one longer than Settings → "A picture at least every"
 * (default 400 words), named by the heading they start under. It says where
 * a picture would help, not which: adding pictures is manual for now (G).
 */
class LMGT_Pictures {

	const EVERY = 400;

	private static $nth = 0;

	public static function boot() {
		add_action( 'add_meta_boxes', function () {
			add_meta_box( 'lmgt_pictures', 'Pictures', array( __CLASS__, 'box' ), LMGT_Store::types( true ), 'side', 'default' );
		} );
		foreach ( array( 'post', 'page' ) as $t ) {
			add_filter( 'manage_' . $t . 's_columns', function ( $c ) { $c['lmgt_pics'] = 'Pictures'; return $c; } );
			add_action( 'manage_' . $t . 's_custom_column', array( __CLASS__, 'column' ), 10, 2 );
		}
		if ( ! LMGT_Bridge::on() ) return;
		add_filter( 'the_content', array( __CLASS__, 'full_src' ), 22 );
		if ( LMGT_Bridge::is_target() ) {
			add_filter( 'the_content', function ( $c ) { self::$nth = 0; return $c; }, 1 );
			add_filter( 'render_block', array( __CLASS__, 'render_grid' ), 10, 2 );
			add_filter( 'the_content', array( __CLASS__, 'append_grids' ), 30 );
			add_action( 'rest_api_init', function () {
				register_rest_route( LMGT_Bridge::NS, '/related', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_related' ), 'permission_callback' => function () { return current_user_can( 'edit_others_posts' ); } ) );
			} );
		} else {
			add_action( 'lmgt_catchup_sections', array( __CLASS__, 'catchup_section' ) );
			add_action( 'wp_ajax_lmgt_related_sync', array( __CLASS__, 'ajax_sync' ) );
		}
	}

	// ---- Pictures per text length ----------------------------------------------

	public static function every() {
		return max( 100, (int) get_option( 'lmgt_picture_every', self::EVERY ) );
	}

	/**
	 * [words, pics, gaps => [[heading, to, words]]]: stretches of text without a
	 * picture, longer than every(), named by the first and last section they
	 * cover; a section the stretch only touches (under 50 words) is not named.
	 */
	public static function analyse( $html ) {
		$parts = preg_split( '/(<img\b[^>]*>|<h[2-4]\b[^>]*>.*?<\/h[2-4]>)/is', (string) $html, -1, PREG_SPLIT_DELIM_CAPTURE );
		$words = 0;
		$pics  = 0;
		$head  = '';
		$run   = array();
		$gaps  = array();
		$close = function () use ( &$run, &$gaps ) {
			$total = array_sum( $run );
			if ( $total > self::every() ) {
				$named = array_keys( array_filter( $run, function ( $n ) { return $n >= 50; } ) );
				if ( ! $named ) $named = array_keys( $run, max( $run ), true );
				$gaps[] = array( 'heading' => (string) reset( $named ), 'to' => (string) end( $named ), 'words' => $total, 'sections' => $run );
			}
			$run = array();
		};
		foreach ( $parts as $p ) {
			if ( preg_match( '/^<img\b/i', $p ) ) {
				$pics++;
				$close();
				continue;
			}
			if ( preg_match( '/^<h[2-4]\b/i', $p ) ) {
				$head = LMGT_Text::plain( $p );
				continue;
			}
			$t = LMGT_Text::plain( $p );
			$n = $t === '' ? 0 : count( preg_split( '/\s+/u', $t ) );
			if ( ! $n ) continue;
			$run[ $head ] = ( isset( $run[ $head ] ) ? $run[ $head ] : 0 ) + $n;
			$words       += $n;
		}
		$close();
		return array( 'words' => $words, 'pics' => $pics, 'gaps' => $gaps );
	}

	public static function box( $post ) {
		$a = self::analyse( $post->post_content );
		echo '<p>' . number_format_i18n( $a['words'] ) . ' words, ' . (int) $a['pics'] . ' picture(s) in the text'
			. ( $a['pics'] ? ': one per ' . number_format_i18n( round( $a['words'] / $a['pics'] ) ) . ' words' : '' ) . '.</p>';
		if ( ! $a['gaps'] ) {
			echo '<p style="color:#008a20">No stretch longer than ' . self::every() . ' words without a picture.</p>';
			return;
		}
		echo '<p><strong>A picture would help</strong> (more than ' . self::every() . ' words without one):</p><ul style="list-style:disc;margin-left:18px">';
		$name = function ( $h ) { return $h === '' ? 'the start' : '"' . $h . '"'; };
		foreach ( $a['gaps'] as $g ) {
			echo '<li>' . esc_html( $g['heading'] === $g['to'] ? 'in ' . $name( $g['heading'] ) : 'from ' . $name( $g['heading'] ) . ' to ' . $name( $g['to'] ) ) . ': ' . number_format_i18n( $g['words'] ) . ' words';
			// The sections inside, with their words, so it is clear where a picture belongs (2.2.11).
			if ( count( $g['sections'] ) > 1 ) {
				$parts = array();
				foreach ( $g['sections'] as $h => $n ) $parts[] = ( $h === '' ? 'start' : $h ) . ' ' . number_format_i18n( $n );
				echo '<br><span class="description">' . esc_html( implode( ' · ', $parts ) ) . '</span>';
			}
			echo '</li>';
		}
		echo '</ul>';
		// 2.17.20 (G, 19 Nov: "not allowed to access this page"): Find pictures is an optional part (Translator → Parts); the button shows only when it is on.
		if ( ! empty( $post->ID ) && LMGT_Parts::on( 'finder' ) ) echo '<p><a class="button" href="' . esc_url( admin_url( 'admin.php?page=lmgt-find&post=' . (int) $post->ID ) ) . '">Find pictures</a></p>';
		elseif ( ! empty( $post->ID ) ) echo '<p class="description">Want an extra picture? Switch on "Find pictures" under ' . ( current_user_can( 'manage_options' ) ? '<a href="' . esc_url( admin_url( 'admin.php?page=lmgt-parts' ) ) . '">Translator → Parts</a>' : 'Translator → Parts (administrator)' ) . '.</p>';
	}

	public static function column( $col, $id ) {
		if ( $col !== 'lmgt_pics' ) return;
		$a = self::analyse( get_post_field( 'post_content', $id ) );
		$t = (int) $a['pics'] . ( $a['pics'] ? ' · 1/' . round( $a['words'] / $a['pics'] ) : '' );
		echo $a['gaps'] ? '<span style="color:#b32d2e" title="' . esc_attr( count( $a['gaps'] ) . ' stretch(es) over ' . self::every() . ' words without a picture' ) . '">' . esc_html( $t ) . ' · ' . count( $a['gaps'] ) . ' gap(s)</span>' : esc_html( $t );
	}

	/**
	 * 2.2.17: a picture stored as src="2022/06/x.png" loads nothing; the browser reads it as
	 * a page under the article (Greece, 30 Oct: 9 of 10 pictures, on .dk and .travel). Shown
	 * with the uploads address of the site that holds the file; the stored text is not changed.
	 */
	public static function full_src( $content ) {
		if ( stripos( $content, '<img' ) === false ) return $content;
		if ( LMGT_Bridge::is_target() ) {
			if ( ! is_singular( LMGT_CPT ) ) return $content;
			$base = LMGT_Bridge::peer() . '/wp-content/uploads/';
		} else {
			$up   = wp_get_upload_dir();
			$base = trailingslashit( $up['baseurl'] );
		}
		return preg_replace( '/(<img\b[^>]*?\s(?:src|data-src)=["\'])(\d{4}\/\d{2}\/[^"\']+)/i', '$1' . $base . '$2', $content );
	}

	// ---- Related articles: .dk side --------------------------------------------

	/**
	 * Source: the article IDs in each related-articles grid of the original, in
	 * order. The original is shown as its own page shows it, the_content filters
	 * included: on traveltalk.dk the grid is not always in the stored text but
	 * added by a snippet when the page is shown (2.2.8).
	 */
	public static function shown( $source_id ) {
		$post = get_post( $source_id );
		if ( ! $post || $post->post_status !== 'publish' ) return array();
		$keep = array( isset( $GLOBALS['wp_query'] ) ? $GLOBALS['wp_query'] : null, isset( $GLOBALS['wp_the_query'] ) ? $GLOBALS['wp_the_query'] : null, isset( $GLOBALS['post'] ) ? $GLOBALS['post'] : null );
		$q    = new WP_Query( array( 'p' => $post->ID, 'post_type' => $post->post_type, 'post_status' => 'publish' ) );
		$GLOBALS['wp_query'] = $GLOBALS['wp_the_query'] = $q;
		$html = '';
		if ( $q->have_posts() ) {
			$q->the_post();
			$html = apply_filters( 'the_content', $post->post_content );
		}
		list( $GLOBALS['wp_query'], $GLOBALS['wp_the_query'], $GLOBALS['post'] ) = $keep;
		if ( $keep[2] ) setup_postdata( $keep[2] );
		$out = array();
		foreach ( array_slice( preg_split( '/<ul\b[^>]*\bwp-block-kadence-posts\b/', $html ), 1 ) as $grid ) {
			$end = strpos( $grid, '</ul>' );
			preg_match_all( '/<article\b[^>]*\bpost-(\d+)\b/', $end === false ? $grid : substr( $grid, 0, $end ), $m );
			$ids = array_values( array_unique( array_map( 'intval', $m[1] ) ) );
			if ( $ids ) $out[] = $ids;
		}
		// The snippet that adds the grid on traveltalk.dk stays quiet in admin and background
		// requests, where this runs. Its rule, read off the Austria page (2.2.10): the 12 newest
		// posts in the category with the page's own slug (page oestrig → category oestrig).
		if ( ! $out && $post->post_type === 'page' ) {
			$cat = get_term_by( 'slug', $post->post_name, 'category' );
			$ids = $cat ? get_posts( array( 'category' => $cat->term_id, 'post_status' => 'publish', 'posts_per_page' => 12, 'fields' => 'ids' ) ) : array();
			if ( $ids ) $out[] = array_map( 'intval', $ids );
		}
		return $out;
	}

	/**
	 * Source: the grids for one language: [[{id, url, title, img, tr}]]. tr is the
	 * title in $lang for articles with no published translation there, made once
	 * and kept on the article (_lmgt_title_tr).
	 */
	public static function related( $source_id, $lang ) {
		$grids = array();
		$need  = array();
		foreach ( self::shown( $source_id ) as $ids ) {
			$items = array();
			foreach ( $ids as $id ) {
				$p = get_post( $id );
				if ( ! $p || $p->post_status !== 'publish' ) continue;
				$thumb = get_post_thumbnail_id( $id );
				$r     = LMGT_Bridge::remote( $id );
				$done  = isset( $r[ $lang ]['status'] ) && in_array( $r[ $lang ]['status'], array( 'publish', 'thin' ), true );
				$tr    = (array) get_post_meta( $id, '_lmgt_title_tr', true );
				$items[] = array( 'id' => $id, 'url' => get_permalink( $id ), 'title' => html_entity_decode( get_the_title( $id ), ENT_QUOTES, 'UTF-8' ), 'img' => $thumb ? (string) wp_get_attachment_image_url( $thumb, 'medium_large' ) : '', 'tr' => isset( $tr[ $lang ] ) ? $tr[ $lang ] : '' );
				if ( ! $done && empty( $tr[ $lang ] ) ) $need[ 't' . $id ] = html_entity_decode( get_the_title( $id ), ENT_QUOTES, 'UTF-8' );
			}
			$grids[] = $items;
		}
		if ( $need && LMGT_Engines::ai_available() ) {
			$r = LMGT_Engines::ai_json( LMGT_Engines::prompt_translate( LMGT_Langs::source(), $lang, $need ), LMGT_Engines::schema_strings( array_keys( $need ) ) );
			if ( ! is_wp_error( $r ) ) {
				foreach ( $grids as $g => $items ) {
					foreach ( $items as $i => $it ) {
						$k = 't' . $it['id'];
						if ( empty( $r[ $k ] ) ) continue;
						$grids[ $g ][ $i ]['tr'] = sanitize_text_field( $r[ $k ] );
						$tr          = (array) get_post_meta( $it['id'], '_lmgt_title_tr', true );
						$tr[ $lang ] = $grids[ $g ][ $i ]['tr'];
						update_post_meta( $it['id'], '_lmgt_title_tr', $tr );
					}
				}
			}
		}
		return $grids;
	}

	/** Source: every (original, language) with a grid and a translation on .travel. */
	public static function todo() {
		global $wpdb;
		$out = array();
		// Every translation: whether its original shows a grid is only known once it is rendered.
		foreach ( $wpdb->get_col( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_lmgt_remote'" ) as $sid ) {
			foreach ( LMGT_Bridge::remote( $sid ) as $lang => $r ) {
				if ( is_array( $r ) && ! empty( $r['id'] ) ) $out[] = array( 'sid' => (int) $sid, 'lang' => $lang );
			}
		}
		return $out;
	}

	public static function catchup_section() {
		$n = count( self::todo() );
		echo '<h2>Related articles</h2><p><strong>' . $n . '</strong> translation(s) on traveltalk.travel. One click looks at each Danish article as its page shows it and sends its related-articles grid as it is now, with its pictures; titles of articles not yet translated are translated once. Articles without a grid are named in the log. Run it again from time to time: the grid here changes as articles are published.</p>';
		if ( ! $n ) return;
		echo '<p><button class="button button-primary" id="lmgt-rel">Send the grids</button> <span id="lmgt-rel-st"></span></p><pre id="lmgt-rel-log" style="max-height:300px;overflow:auto;background:#fff;padding:8px"></pre>';
		$nonce = wp_create_nonce( 'lmgt_related_sync' );
		echo "<script>(function(){var b=document.getElementById('lmgt-rel'),s=document.getElementById('lmgt-rel-st'),l=document.getElementById('lmgt-rel-log');"
			. "function go(i){var d=new FormData();d.append('action','lmgt_related_sync');d.append('i',i);d.append('_ajax_nonce','" . esc_js( $nonce ) . "');"
			. "fetch(ajaxurl,{method:'POST',body:d,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){"
			. "if(!r.success){l.textContent+='Stopped: '+r.data+'\\n';b.disabled=false;return}l.textContent+=r.data.line+'\\n';s.textContent=r.data.left+' left';"
			. "if(r.data.left>0)go(i+1);else s.textContent='Finished.'}).catch(function(e){l.textContent+='Stopped: '+e+'\\n';b.disabled=false})}"
			. "b.addEventListener('click',function(){b.disabled=true;go(0)})})();</script>";
	}

	/** Source: one (original, language) per step, by its place in todo(). */
	public static function ajax_sync() {
		check_ajax_referer( 'lmgt_related_sync' );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_send_json_error( 'Not allowed.' );
		$todo = self::todo();
		$i    = isset( $_POST['i'] ) ? (int) $_POST['i'] : 0;
		if ( ! isset( $todo[ $i ] ) ) wp_send_json_success( array( 'left' => 0, 'line' => 'Nothing left.' ) );
		$it   = $todo[ $i ];
		$rel  = self::related( $it['sid'], $it['lang'] );
		$r    = LMGT_Bridge::call( 'POST', '/related', array( 'source_id' => $it['sid'], 'lang' => $it['lang'], 'related' => $rel ), false );
		$line = '#' . $it['sid'] . ' ' . $it['lang'] . ': ' . ( is_wp_error( $r ) ? 'failed – ' . $r->get_error_message() : ( ! empty( $r['skipped'] ) ? 'skipped – a page of traveltalk.travel\'s own' : ( $rel ? array_sum( array_map( 'count', $rel ) ) . ' article(s)' : 'no grid on the Danish article' ) ) );
		wp_send_json_success( array( 'left' => count( $todo ) - $i - 1, 'line' => $line ) );
	}

	// ---- Related articles: .travel side ----------------------------------------

	/** Target: keep the grids, cleaned. */
	public static function store( $id, $related ) {
		if ( ! is_array( $related ) ) return;
		$clean = array();
		foreach ( $related as $g ) {
			$items = array();
			foreach ( (array) $g as $it ) {
				if ( ! is_array( $it ) || empty( $it['id'] ) || empty( $it['url'] ) ) continue;
				$items[] = array( 'id' => (int) $it['id'], 'url' => esc_url_raw( $it['url'] ), 'title' => sanitize_text_field( isset( $it['title'] ) ? $it['title'] : '' ), 'img' => esc_url_raw( isset( $it['img'] ) ? $it['img'] : '' ), 'tr' => sanitize_text_field( isset( $it['tr'] ) ? $it['tr'] : '' ) );
			}
			$clean[] = $items;
		}
		update_post_meta( $id, '_lmgt_related', wp_slash( $clean ) );
	}

	public static function rest_related( WP_REST_Request $req ) {
		$p    = $req->get_json_params();
		$lang = isset( $p['lang'] ) ? (string) $p['lang'] : '';
		foreach ( LMGT_Bridge::members( isset( $p['source_id'] ) ? (int) $p['source_id'] : 0 ) as $id ) {
			if ( get_post_meta( $id, '_lmgt_lang', true ) !== $lang ) continue;
			// A linked English page of .travel's own keeps its own layout.
			if ( get_post_type( $id ) !== LMGT_CPT ) return array( 'id' => (int) $id, 'skipped' => 'own page' );
			self::store( $id, isset( $p['related'] ) ? $p['related'] : array() );
			do_action( 'litespeed_purge_post', $id );
			return array( 'id' => (int) $id );
		}
		return new WP_Error( 'lmgt_bad', 'No translation in that language for that original.', array( 'status' => 404 ) );
	}

	/**
	 * Target: the nth posts block on a translation, at any depth, is drawn from
	 * the stored grid. Its own query would look for .dk's posts here and print
	 * "No posts", so without a stored grid it prints nothing (2.2.10).
	 */
	public static function render_grid( $content, $block ) {
		if ( empty( $block['blockName'] ) || $block['blockName'] !== 'kadence/posts' || ! is_singular( LMGT_CPT ) ) return $content;
		$id  = get_queried_object_id();
		$rel = get_post_meta( $id, '_lmgt_related', true );
		$i   = self::$nth++;
		return is_array( $rel ) && ! empty( $rel[ $i ] ) ? self::grid( $rel[ $i ], get_post_meta( $id, '_lmgt_lang', true ) ) : '';
	}

	/** Target: grids with no posts block of their own in the translation go at the end, where .dk shows them (2.2.8). */
	public static function append_grids( $content ) {
		if ( ! is_singular( LMGT_CPT ) || ! in_the_loop() || ! is_main_query() ) return $content;
		$id  = get_the_ID();
		$rel = get_post_meta( $id, '_lmgt_related', true );
		if ( ! is_array( $rel ) ) return $content;
		$lang = get_post_meta( $id, '_lmgt_lang', true );
		foreach ( array_slice( $rel, self::$nth ) as $items ) {
			if ( $items ) $content .= self::grid( $items, $lang );
		}
		return $content;
	}

	public static function grid( array $items, $lang ) {
		$more = array( 'en' => 'Read more', 'de' => 'Weiterlesen', 'fr' => 'Lire la suite', 'es' => 'Leer más', 'it' => 'Leggi di più', 'pt' => 'Leia mais', 'sv' => 'Läs mer', 'nb' => 'Les mer', 'fi' => 'Lue lisää' );
		$more = isset( $more[ $lang ] ) ? $more[ $lang ] : $more['en'];
		$li   = '';
		foreach ( $items as $it ) {
			// 2.2.17 (G, 30 Oct): the article in the page's language, else in English; one with neither is left out, not sent to Danish.
			$by  = array();
			foreach ( LMGT_Bridge::members( (int) $it['id'] ) as $m ) {
				if ( get_post_status( $m ) === 'publish' ) $by[ get_post_meta( $m, '_lmgt_lang', true ) ] = (int) $m;
			}
			$tid = isset( $by[ $lang ] ) ? $by[ $lang ] : ( isset( $by['en'] ) ? $by['en'] : 0 );
			if ( ! $tid ) continue;
			$url   = get_permalink( $tid );
			$title = get_the_title( $tid );
			$img   = get_the_post_thumbnail_url( $tid, 'medium_large' ) ?: $it['img'];
			$attr  = isset( $by[ $lang ] ) ? '' : ' hreflang="en"';
			$mark  = '';
			$li .= '<li class="kb-post-list-item"><article class="entry content-bg loop-entry">'
				. ( $img ? '<a aria-hidden="true" tabindex="-1" class="post-thumbnail kadence-thumbnail-ratio-2-3" href="' . esc_url( $url ) . '"' . $attr . '><div class="post-thumbnail-inner"><img src="' . esc_url( $img ) . '" alt="" loading="lazy" decoding="async"></div></a>' : '' )
				. '<div class="entry-content-wrap"><header class="entry-header"><h2 class="entry-title"><a href="' . esc_url( $url ) . '"' . $attr . '>' . $title . '</a>' . $mark . '</h2></header>'
				. '<footer class="entry-footer"><p class="more-link-wrap"><a class="post-more-link" href="' . esc_url( $url ) . '"' . $attr . '>' . esc_html( $more ) . '</a></p></footer></div></article></li>';
		}
		if ( $li === '' ) return '';
		return '<style>.lmgt-related{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:2rem;list-style:none;margin:2em 0;padding:0}.lmgt-related .post-thumbnail-inner{aspect-ratio:3/2;overflow:hidden}.lmgt-related .post-thumbnail-inner img{width:100%;height:100%;object-fit:cover;display:block}.lmgt-related .entry-title{font-size:1.1em;margin:.6em 0 .3em}</style>'
			. '<ul class="wp-block-kadence-posts kb-posts kadence-posts-list content-wrap grid-cols kb-posts-style-boxed grid-sm-col-2 grid-lg-col-3 item-image-style-above lmgt-related">' . $li . '</ul>';
	}
}
