<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.2.26: Translate everything (Translator → Translate everything).
 *
 * Works out every published original on this site that has no version yet in a
 * language, puts them in order and keeps the queue topped up in the background
 * until nothing is missing. Works on any site: with a partner site (.dk → .travel)
 * the versions go there; on a site on its own they stay on that site.
 *
 * Order (G, 3 Nov 2026: English first, pages before posts):
 *   1. languages in the order of LANG_ORDER, English first; the first N
 *      languages that still miss something run side by side ("lanes");
 *   2. within a language: the IDs pasted under "Do these first", then pages
 *      (longest first), then posts (newest first). For English, an original
 *      that already has another language comes first among its kind, so its
 *      hreflang x-default can point to English instead of the original.
 * Not queued: the front page, the blog page, password-protected or noindex
 * originals, hand-tagged translations, IDs under "Leave out", and pairs that
 * once failed or could not be queued (they are listed; Retry in the Queue).
 *
 * Results are drafts for review, unless "Publish what passes the check" is
 * ticked: then they are published like the automatic ones of new articles
 * (flagged ones held back) and listed under Auto-published.
 */
class LMGT_Plan {

	const LANG_ORDER = array( 'en', 'de', 'fr', 'es', 'it', 'pt', 'sv', 'nb', 'fi', 'da' );
	const KEEP_DONE  = 30;

	public static function boot() {
		add_action( 'admin_menu', function () {
			add_submenu_page( 'lmgt', 'Translate everything', 'Translate everything', 'edit_others_posts', 'lmgt-plan', array( __CLASS__, 'page' ) );
		}, 15 );
		add_action( 'admin_post_lmgt_plan', array( __CLASS__, 'handle' ) );
	}

	public static function on() {
		// 2.13.0: with the part switched off (Translator → Parts) nothing is added in the background either.
		return LMGT_Parts::on( 'plan' ) && get_option( 'lmgt_plan_on', '0' ) === '1';
	}

	/** The plan's languages, in working order. */
	public static function langs() {
		$enabled = LMGT_Langs::enabled();
		$picked  = get_option( 'lmgt_plan_langs', null );
		$picked  = is_array( $picked ) ? $picked : $enabled;
		$out     = array();
		foreach ( self::LANG_ORDER as $c ) if ( in_array( $c, $enabled, true ) && in_array( $c, $picked, true ) ) $out[] = $c;
		foreach ( $enabled as $c ) if ( ! in_array( $c, $out, true ) && in_array( $c, $picked, true ) ) $out[] = $c;
		return $out;
	}

	private static function id_list( $opt ) {
		return array_values( array_unique( array_filter( array_map( 'intval', preg_split( '/[^0-9]+/', (string) get_option( $opt, '' ) ) ) ) ) );
	}

	/** Every original that may be translated: [id => ['type','len','date']], in base order (pages longest first, then posts newest first). */
	public static function originals() {
		global $wpdb;
		$types = array();
		if ( get_option( 'lmgt_plan_pages', '1' ) === '1' ) $types[] = 'page';
		if ( get_option( 'lmgt_plan_posts', '1' ) === '1' ) $types[] = 'post';
		if ( ! $types ) return array();
		$in   = "'" . implode( "','", $types ) . "'";
		$rows = $wpdb->get_results( "SELECT ID, post_type, LENGTH(post_content) AS len, post_date_gmt FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_password = '' AND post_type IN ($in) ORDER BY (post_type = 'page') DESC, CASE WHEN post_type = 'page' THEN LENGTH(post_content) ELSE 0 END DESC, post_date_gmt DESC" );
		$skip = array_merge( self::id_list( 'lmgt_plan_skip' ), array( (int) get_option( 'page_on_front' ), (int) get_option( 'page_for_posts' ) ), array_map( 'intval', LMGT_Store::tagged() ) );
		$noix = array_map( 'intval', $wpdb->get_col( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'rank_math_robots' AND meta_value LIKE '%noindex%'" ) );
		$auto = array_map( 'intval', $wpdb->get_col( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_lmgt_source' OR meta_key = '_lmgt_remote_source'" ) );
		$out  = array();
		foreach ( $rows as $r ) {
			$id = (int) $r->ID;
			if ( in_array( $id, $skip, true ) || in_array( $id, $noix, true ) || in_array( $id, $auto, true ) || (int) $r->len < 200 ) continue;
			$out[ $id ] = array( 'type' => $r->post_type, 'len' => (int) $r->len );
		}
		return $out;
	}

	/** [source id => [lang => status]] for every version that exists, here or on the partner site. */
	public static function versions() {
		global $wpdb;
		$out  = array();
		$rows = $wpdb->get_results( "SELECT s.meta_value AS src, l.meta_value AS lang, p.post_status AS st FROM {$wpdb->postmeta} s JOIN {$wpdb->postmeta} l ON l.post_id = s.post_id AND l.meta_key = '_lmgt_lang' JOIN {$wpdb->posts} p ON p.ID = s.post_id WHERE s.meta_key = '_lmgt_source' AND p.post_status NOT IN ('trash','auto-draft','inherit')" );
		foreach ( $rows as $r ) $out[ (int) $r->src ][ $r->lang ] = $r->st;
		foreach ( $wpdb->get_results( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_lmgt_remote'" ) as $r ) {
			$v = maybe_unserialize( $r->meta_value );
			if ( ! is_array( $v ) ) continue;
			foreach ( $v as $lang => $x ) {
				if ( is_array( $x ) ) $out[ (int) $r->post_id ][ $lang ] = isset( $x['status'] ) ? $x['status'] : 'draft';
			}
		}
		return $out;
	}

	/** [pid:lang => true] for pairs in the queue (any status) and pairs that failed or could not be queued. */
	private static function taken() {
		$t = array();
		foreach ( LMGT_Jobs::ids() as $id ) {
			$j = LMGT_Jobs::get( $id );
			if ( $j ) $t[ (int) $j['post'] . ':' . $j['lang'] ] = $j['status'];
		}
		foreach ( (array) get_option( 'lmgt_plan_failed', array() ) as $k => $v ) $t[ $k ] = 'skipped';
		return $t;
	}

	/** What is still missing in one language, in order. */
	public static function missing( $lang, $orig = null, $vers = null, $taken = null ) {
		$orig  = $orig === null ? self::originals() : $orig;
		$vers  = $vers === null ? self::versions() : $vers;
		$taken = $taken === null ? self::taken() : $taken;
		$first = array();
		$sets  = array();
		$rest  = array();
		$pri   = self::id_list( 'lmgt_plan_first' );
		foreach ( $pri as $id ) if ( isset( $orig[ $id ] ) ) $first[] = $id;
		$posts = array();
		foreach ( $orig as $id => $o ) {
			if ( in_array( $id, $first, true ) ) continue;
			if ( $o['type'] === 'page' ) { $lang === 'en' && ! empty( $vers[ $id ] ) ? $sets[] = $id : $rest[] = $id; }
			else $posts[] = $id;
		}
		// Pages before posts; within each, English for an original that already has other languages comes first.
		$pfirst = array();
		$plater = array();
		foreach ( $posts as $id ) ( $lang === 'en' && ! empty( $vers[ $id ] ) ) ? $pfirst[] = $id : $plater[] = $id;
		$out = array();
		foreach ( array_merge( $first, $sets, $rest, $pfirst, $plater ) as $id ) {
			if ( isset( $vers[ $id ][ $lang ] ) || isset( $taken[ $id . ':' . $lang ] ) ) continue;
			$out[] = $id;
		}
		return $out;
	}

	/** Runs every minute while the plan is on: tidies up and tops the queue up. */
	public static function refill() {
		if ( ! self::on() ) return;
		$langs = self::langs();
		$orig  = self::originals();
		$vers  = self::versions();
		$open  = array();
		$done  = array();
		foreach ( LMGT_Jobs::ids() as $id ) {
			$j = LMGT_Jobs::get( $id );
			if ( ! $j || empty( $j['plan'] ) ) continue;
			if ( in_array( $j['status'], array( 'queued', 'running' ), true ) ) $open[ $j['lang'] ] = ( isset( $open[ $j['lang'] ] ) ? $open[ $j['lang'] ] : 0 ) + 1;
			if ( $j['status'] === 'done' ) $done[] = $id;
		}
		// Done plan jobs are counted and cleared, keeping the newest few to look at.
		if ( count( $done ) > self::KEEP_DONE ) {
			$gone = array_slice( $done, 0, count( $done ) - self::KEEP_DONE );
			foreach ( $gone as $id ) LMGT_Jobs::remove( $id );
			update_option( 'lmgt_plan_cleared', (int) get_option( 'lmgt_plan_cleared', 0 ) + count( $gone ), false );
		}
		$taken  = self::taken();
		$lanes  = max( 1, min( 4, (int) get_option( 'lmgt_plan_lanes', 2 ) ) );
		$window = max( 2, min( 40, (int) get_option( 'lmgt_plan_window', 8 ) ) );
		$active = array();
		foreach ( $langs as $l ) {
			if ( count( $active ) >= $lanes ) break;
			$m = self::missing( $l, $orig, $vers, $taken );
			if ( $m || ! empty( $open[ $l ] ) ) $active[ $l ] = $m;
		}
		if ( ! $active ) {
			update_option( 'lmgt_plan_on', '0', true );
			update_option( 'lmgt_plan_finished', time(), false );
			if ( LMGT_Bridge::on() ) LMGT_Bridge::log( 'Translate everything: nothing left to queue, stopped' );
			return;
		}
		$per    = max( 1, (int) floor( $window / count( $active ) ) );
		$failed = (array) get_option( 'lmgt_plan_failed', array() );
		$added  = 0;
		foreach ( $active as $l => $list ) {
			$room = $per - ( isset( $open[ $l ] ) ? $open[ $l ] : 0 );
			foreach ( $list as $pid ) {
				if ( $room <= 0 ) break;
				$r = LMGT_Jobs::add( $pid, $l, false, true );
				if ( is_wp_error( $r ) ) {
					$failed[ $pid . ':' . $l ] = $r->get_error_message();
					continue;
				}
				$room--;
				$added++;
			}
		}
		update_option( 'lmgt_plan_failed', $failed, false );
		update_option( 'lmgt_plan_refilled', time(), false );
	}

	/** A plan job that failed is not queued again by the plan. */
	public static function job_failed( array $job ) {
		if ( empty( $job['plan'] ) ) return;
		$f = (array) get_option( 'lmgt_plan_failed', array() );
		$f[ (int) $job['post'] . ':' . $job['lang'] ] = (string) $job['error'];
		update_option( 'lmgt_plan_failed', $f, false );
	}

	/** Retry in the Queue lets the plan see the pair again. */
	public static function job_retried( array $job ) {
		$f = (array) get_option( 'lmgt_plan_failed', array() );
		unset( $f[ (int) $job['post'] . ':' . $job['lang'] ] );
		update_option( 'lmgt_plan_failed', $f, false );
	}

	/** Originals with versions but no English: their x-default points to the original. [missing => ids, draft => ids] */
	public static function no_english( $orig, $vers ) {
		$out = array( 'missing' => array(), 'draft' => array() );
		if ( LMGT_Langs::source() === 'en' ) return $out;
		foreach ( $vers as $id => $v ) {
			if ( ! isset( $orig[ $id ] ) ) continue;
			$pub = array_filter( $v, function ( $s ) { return $s === 'publish'; } );
			if ( ! $pub || isset( $pub['en'] ) ) continue;
			$out[ isset( $v['en'] ) ? 'draft' : 'missing' ][] = $id;
		}
		return $out;
	}

	// ---- Page ------------------------------------------------------------------

	public static function page() {
		$orig  = self::originals();
		$vers  = self::versions();
		$taken = self::taken();
		$langs = self::langs();
		$on    = self::on();
		$npg   = count( array_filter( $orig, function ( $o ) { return $o['type'] === 'page'; } ) );
		echo '<div class="wrap"><h1>Translate everything</h1>';
		echo '<p>Every published original here (' . (int) $npg . ' pages, ' . (int) ( count( $orig ) - $npg ) . ' posts) that has no version yet in a language is queued, English first, pages before posts, and worked in the background. <strong>You can close this page.</strong> ';
		echo get_option( 'lmgt_plan_publish', '0' ) === '1' ? 'Translations that pass the check are <strong>published</strong> and listed under Auto-published' . ( LMGT_Bridge::is_source() ? ' on ' . esc_html( wp_parse_url( LMGT_Bridge::peer(), PHP_URL_HOST ) ) : '' ) . '; flagged ones wait as drafts.' : 'Translations are saved as <strong>drafts</strong> for review.';
		echo '</p>';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:12px 0">';
		wp_nonce_field( 'lmgt_plan' );
		echo '<input type="hidden" name="action" value="lmgt_plan">';
		if ( $on ) {
			echo '<button class="button" name="do" value="pause">Pause</button> <span style="margin-left:8px;color:#00a32a">● Running in the background';
			$t = (int) get_option( 'lmgt_bg_last', 0 );
			echo $t ? ' · last step ' . esc_html( human_time_diff( $t ) ) . ' ago' : ' · waiting for the first step (within a minute or two)';
			echo '</span>';
		} else {
			echo '<button class="button button-primary" name="do" value="start">Start</button> <span style="margin-left:8px">Paused.';
			$f = (int) get_option( 'lmgt_plan_finished', 0 );
			if ( $f ) echo ' Last run finished ' . esc_html( human_time_diff( $f ) ) . ' ago: nothing was left.';
			echo '</span>';
		}
		echo '</form>';

		echo '<table class="widefat striped" style="max-width:900px"><thead><tr><th>Language</th><th>Have a version</th><th>In the queue</th><th>Could not be done</th><th>Still to queue</th><th>Next up</th></tr></thead><tbody>';
		foreach ( $langs as $l ) {
			$have = 0;
			foreach ( $orig as $id => $o ) if ( isset( $vers[ $id ][ $l ] ) ) $have++;
			$q = $f = 0;
			foreach ( $taken as $k => $st ) {
				list( $pid, $lang ) = explode( ':', $k ) + array( '', '' );
				if ( $lang !== $l || ! isset( $orig[ (int) $pid ] ) || isset( $vers[ (int) $pid ][ $l ] ) ) continue;
				if ( in_array( $st, array( 'queued', 'running' ), true ) ) $q++;
				elseif ( $st === 'failed' || $st === 'skipped' ) $f++;
			}
			$miss = self::missing( $l, $orig, $vers, $taken );
			$next = array_map( function ( $id ) { return esc_html( get_the_title( $id ) ); }, array_slice( $miss, 0, 3 ) );
			printf( '<tr><td><strong>%s</strong></td><td>%d of %d</td><td>%d</td><td>%s</td><td>%d</td><td>%s</td></tr>',
				esc_html( LMGT_Langs::get( $l )['name'] ), $have, count( $orig ), $q, $f ? '<span style="color:#b32d2e">' . $f . '</span>' : '0', count( $miss ), implode( ' · ', $next ) );
		}
		if ( ! $langs ) echo '<tr><td colspan="6">No language ticked. Tick languages under Translator → Settings → Translate into, and below.</td></tr>';
		echo '</tbody></table>';

		$ne = self::no_english( $orig, $vers );
		if ( $ne['missing'] || $ne['draft'] ) {
			echo '<h2>Pages whose world default (x-default) is still the original</h2><p>Google sends readers of a language with no version to x-default. It points to English as soon as an English version is published; until then it points to the original. English for these is queued first.</p><ul style="list-style:disc;margin-left:20px">';
			if ( $ne['missing'] ) echo '<li>' . count( $ne['missing'] ) . ' without an English version: ' . implode( ', ', array_map( function ( $id ) { return esc_html( get_the_title( $id ) ); }, array_slice( $ne['missing'], 0, 25 ) ) ) . ( count( $ne['missing'] ) > 25 ? ' …' : '' ) . '</li>';
			if ( $ne['draft'] ) echo '<li>' . count( $ne['draft'] ) . ' whose English version is a draft, waiting for you: ' . implode( ', ', array_map( function ( $id ) { return esc_html( get_the_title( $id ) ); }, array_slice( $ne['draft'], 0, 25 ) ) ) . ( count( $ne['draft'] ) > 25 ? ' …' : '' ) . '</li>';
			echo '</ul>';
		}

		$failed = (array) get_option( 'lmgt_plan_failed', array() );
		if ( $failed ) {
			echo '<details style="margin-top:12px"><summary>' . count( $failed ) . ' not done, with the reason</summary><table class="widefat striped" style="max-width:900px"><tbody>';
			foreach ( array_slice( $failed, 0, 200, true ) as $k => $why ) {
				list( $pid, $lang ) = explode( ':', $k ) + array( '', '' );
				$l = LMGT_Langs::get( $lang );
				echo '<tr><td>' . esc_html( get_the_title( (int) $pid ) ) . ' (#' . (int) $pid . ')</td><td>' . esc_html( $l ? $l['name'] : $lang ) . '</td><td>' . esc_html( $why ) . '</td></tr>';
			}
			echo '</tbody></table><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'lmgt_plan' );
			echo '<input type="hidden" name="action" value="lmgt_plan"><p><button class="button" name="do" value="forget">Try these again</button></p></form></details>';
		}

		$o = function ( $k, $d ) { return get_option( $k, $d ); };
		$picked = get_option( 'lmgt_plan_langs', null );
		$picked = is_array( $picked ) ? $picked : LMGT_Langs::enabled();
		echo '<h2>How</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'lmgt_plan' );
		echo '<input type="hidden" name="action" value="lmgt_plan"><input type="hidden" name="do" value="save"><table class="form-table">';
		echo '<tr><th>Languages</th><td>';
		$all = LMGT_Langs::enabled();
		usort( $all, function ( $a, $b ) { $o = LMGT_Plan::LANG_ORDER; return ( array_search( $a, $o, true ) === false ? 99 : array_search( $a, $o, true ) ) - ( array_search( $b, $o, true ) === false ? 99 : array_search( $b, $o, true ) ); } );
		foreach ( $all as $c ) echo '<label style="display:inline-block;min-width:130px"><input type="checkbox" name="lmgt_plan_langs[]" value="' . esc_attr( $c ) . '" ' . checked( in_array( $c, $picked, true ), true, false ) . '> ' . esc_html( LMGT_Langs::get( $c )['name'] ) . '</label> ';
		echo '<p class="description">Worked in this order. Only languages switched on under Settings → Translate into.</p></td></tr>';
		echo '<tr><th>Languages side by side</th><td><input type="number" name="lmgt_plan_lanes" min="1" max="4" value="' . esc_attr( (int) $o( 'lmgt_plan_lanes', 2 ) ) . '" class="small-text"> <span class="description">1 = English until done, then the next. 2 = English and the next language at the same time.</span></td></tr>';
		echo '<tr><th>Workers at a time</th><td><input type="number" name="lmgt_workers" min="1" max="4" value="' . esc_attr( LMGT_Jobs::workers() ) . '" class="small-text"> <span class="description">Translations made at the same moment. More is faster but loads the server; lower it if the site gets slow or answers 508.</span></td></tr>';
		echo '<tr><th>In the queue at once</th><td><input type="number" name="lmgt_plan_window" min="2" max="40" value="' . esc_attr( (int) $o( 'lmgt_plan_window', 8 ) ) . '" class="small-text"> <span class="description">Topped up every minute.</span></td></tr>';
		echo '<tr><th>What</th><td><label><input type="checkbox" name="lmgt_plan_pages" value="1" ' . checked( $o( 'lmgt_plan_pages', '1' ), '1', false ) . '> Pages</label> &nbsp; <label><input type="checkbox" name="lmgt_plan_posts" value="1" ' . checked( $o( 'lmgt_plan_posts', '1' ), '1', false ) . '> Posts</label> <span class="description">Pages always come first.</span></td></tr>';
		echo '<tr><th>Publish</th><td><label><input type="checkbox" name="lmgt_plan_publish" value="1" ' . checked( $o( 'lmgt_plan_publish', '0' ), '1', false ) . '> Publish what passes the check, without waiting for review</label><p class="description">Off: drafts for review. On: like the automatic translations of new articles (flagged ones held back, all listed under Auto-published).</p></td></tr>';
		echo '<tr><th>Do these first</th><td><textarea name="lmgt_plan_first" rows="2" class="large-text code" placeholder="IDs in order, e.g. the country list">' . esc_textarea( (string) $o( 'lmgt_plan_first', '' ) ) . '</textarea></td></tr>';
		echo '<tr><th>Leave out</th><td><textarea name="lmgt_plan_skip" rows="2" class="large-text code" placeholder="IDs never to translate">' . esc_textarea( (string) $o( 'lmgt_plan_skip', '' ) ) . '</textarea><p class="description">Left out by themselves: the front page, the blog page, password-protected and noindex pages, and very short ones.</p></td></tr>';
		echo '</table>';
		submit_button( 'Save' );
		echo '</form></div>';
	}

	public static function handle() {
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_die( 'Not allowed.' );
		check_admin_referer( 'lmgt_plan' );
		$do  = isset( $_POST['do'] ) ? sanitize_key( $_POST['do'] ) : '';
		$msg = '';
		if ( $do === 'start' ) {
			update_option( 'lmgt_plan_on', '1', true );
			update_option( 'lmgt_work', '1', true );
			delete_option( 'lmgt_plan_finished' );
			self::refill();
			LMGT_Jobs::ensure_schedule();
			LMGT_Jobs::kick_all();
			$msg = 'Started. It runs in the background; you can close this page.';
		} elseif ( $do === 'pause' ) {
			update_option( 'lmgt_plan_on', '0', true );
			$msg = 'Paused. Steps already running finish; queued translations wait.';
		} elseif ( $do === 'forget' ) {
			delete_option( 'lmgt_plan_failed' );
			$msg = 'They will be tried again.';
		} elseif ( $do === 'save' ) {
			$langs = array_values( array_intersect( array_map( 'sanitize_key', (array) ( isset( $_POST['lmgt_plan_langs'] ) ? $_POST['lmgt_plan_langs'] : array() ) ), LMGT_Langs::enabled() ) );
			update_option( 'lmgt_plan_langs', $langs, false );
			update_option( 'lmgt_plan_lanes', max( 1, min( 4, (int) $_POST['lmgt_plan_lanes'] ) ), false );
			update_option( 'lmgt_workers', max( 1, min( 4, (int) $_POST['lmgt_workers'] ) ), false );
			update_option( 'lmgt_plan_window', max( 2, min( 40, (int) $_POST['lmgt_plan_window'] ) ), false );
			foreach ( array( 'lmgt_plan_pages', 'lmgt_plan_posts', 'lmgt_plan_publish' ) as $k ) update_option( $k, empty( $_POST[ $k ] ) ? '0' : '1', false );
			foreach ( array( 'lmgt_plan_first', 'lmgt_plan_skip' ) as $k ) update_option( $k, implode( ', ', array_filter( array_map( 'intval', preg_split( '/[^0-9]+/', isset( $_POST[ $k ] ) ? (string) wp_unslash( $_POST[ $k ] ) : '' ) ) ) ), false );
			$msg = 'Saved.';
		}
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $msg ), admin_url( 'admin.php?page=lmgt-plan' ) ) );
		exit;
	}
}
