<?php
/**
 * 2.10.0 (G, 9 Nov 2026: "make a clear destination, where to fix what"): Translator → Work list.
 * Every page and post on this site where something waits for a person, oldest first, with what
 * waits, in which step, since when, and one button that opens it. Then the translations that are
 * still drafts. The menu shows the count.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class LMGT_Worklist {

	/** meta key => [what waits, step]. */
	const WAITS = array(
		'_lmgt_pending'       => array( 'A new version to Accept or Reject', 'Check' ),
		'_lmgt_gap_draft'     => array( 'New sections to read and add', 'Deepen' ),
		'_lmgt_structure'     => array( 'A new structure to Accept or Reject', 'Structure' ),
		'_lmgt_links_pending' => array( 'Proposed links to Accept or Reject', 'Links' ),
		'_lmgt_faq_pending'   => array( 'Questions for "Know before you go"', 'Boxes' ),
		'_lmgt_facts_pending' => array( 'Rows for the fact box', 'Boxes' ),
	);

	public static function boot() {
		add_action( 'admin_menu', function () {
			$n = count( LMGT_Worklist::items() );
			add_submenu_page( 'lmgt', 'Work list', 'Work list' . ( $n ? ' <span class="awaiting-mod">' . (int) $n . '</span>' : '' ), 'edit_others_posts', 'lmgt-work', array( __CLASS__, 'page' ), 1 );
		}, 11 );
	}

	/** [post_id => [[label, step, at], ...]] for posts that are not in the trash. */
	public static function items() {
		static $cache = null;
		if ( $cache !== null ) return $cache;
		global $wpdb;
		$keys = array_keys( self::WAITS );
		$in   = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT m.post_id, m.meta_key, m.meta_value FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key IN ($in) AND p.post_status NOT IN ('trash','auto-draft','inherit')", $keys ) );
		$out  = array();
		foreach ( $rows as $r ) {
			$v = maybe_unserialize( $r->meta_value );
			if ( ! is_array( $v ) || ! $v ) continue;
			if ( $r->meta_key === '_lmgt_pending' && empty( $v['translation'] ) ) continue;
			$label = self::WAITS[ $r->meta_key ][0];
			if ( $r->meta_key === '_lmgt_pending' && isset( $v['kind'] ) && $v['kind'] === 'improve' ) $label = 'Improvements from the Danish original to Accept or Reject';
			$out[ (int) $r->post_id ][] = array( $label, self::WAITS[ $r->meta_key ][1], isset( $v['at'] ) ? (string) $v['at'] : '' );
		}
		uasort( $out, function ( $a, $b ) { return strcmp( min( array_column( $a, 2 ) ), min( array_column( $b, 2 ) ) ); } );
		return $cache = $out;
	}

	private static function ago( $at ) {
		if ( $at === '' ) return '';
		$t = strtotime( $at . ' UTC' );
		return '<span title="' . esc_attr( wp_date( 'j M Y, H:i', $t ) ) . '">' . esc_html( human_time_diff( $t ) ) . ' ago</span>';
	}

	public static function page() {
		echo '<div class="wrap"><h1>Work list</h1>';
		echo '<p>Everything on this site that waits for you, oldest first. Open one, do the step named under "Next" at the top of its Translator panel, and it leaves this list.</p>';
		$items = self::items();
		if ( ! $items ) {
			echo '<div class="notice notice-success inline"><p><strong>✓ Nothing waits for you.</strong></p></div>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th>Page or post</th><th>What waits</th><th>Step</th><th>Since</th><th></th></tr></thead><tbody>';
			foreach ( $items as $id => $list ) {
				$first = true;
				foreach ( $list as $w ) {
					echo '<tr>' . ( $first ? '<td rowspan="' . count( $list ) . '"><strong>' . esc_html( html_entity_decode( get_the_title( $id ), ENT_QUOTES, 'UTF-8' ) ?: '(no title)' ) . '</strong><br><span class="description">' . esc_html( self::kind( $id ) ) . '</span></td>' : '' )
						. '<td>' . esc_html( $w[0] ) . '</td><td>' . esc_html( $w[1] ) . '</td><td>' . self::ago( $w[2] ) . '</td>'
						. ( $first ? '<td rowspan="' . count( $list ) . '" style="text-align:right"><a class="button button-primary" href="' . esc_url( get_edit_post_link( $id, 'url' ) ) . '">Open</a></td>' : '' ) . '</tr>';
					$first = false;
				}
			}
			echo '</tbody></table>';
		}
		$drafts = get_posts( array( 'post_type' => LMGT_CPT, 'post_status' => array( 'draft', 'pending' ), 'posts_per_page' => 50, 'orderby' => 'modified', 'order' => 'ASC', 'meta_query' => array( array( 'key' => '_lmgt_moved_to', 'compare' => 'NOT EXISTS' ) ) ) );
		$drafts = array_filter( $drafts, function ( $p ) use ( $items ) { return ! isset( $items[ $p->ID ] ); } );
		if ( $drafts ) {
			echo '<h2 style="margin-top:28px">Translations not published yet (' . count( $drafts ) . ')</h2><p class="description">Nothing is proposed on these; they wait for you to read and publish them.</p>';
			echo '<table class="widefat striped"><thead><tr><th>Translation</th><th>Language</th><th>Last changed</th><th></th></tr></thead><tbody>';
			foreach ( $drafts as $p ) {
				echo '<tr><td>' . esc_html( html_entity_decode( get_the_title( $p ), ENT_QUOTES, 'UTF-8' ) ) . '</td><td>' . esc_html( strtoupper( (string) get_post_meta( $p->ID, '_lmgt_lang', true ) ) ) . '</td><td>' . self::ago( $p->post_modified_gmt ) . '</td><td style="text-align:right"><a class="button" href="' . esc_url( get_edit_post_link( $p->ID, 'url' ) ) . '">Open</a></td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';
	}

	private static function kind( $id ) {
		$t = get_post_type( $id );
		if ( $t === LMGT_CPT ) return 'Translation · ' . strtoupper( (string) get_post_meta( $id, '_lmgt_lang', true ) );
		$o = get_post_type_object( $t );
		return $o ? $o->labels->singular_name : $t;
	}
}
