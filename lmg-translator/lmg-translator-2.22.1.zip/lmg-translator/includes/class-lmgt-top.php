<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.3.0: "Most read about [place]" inside the Read more block.
 *
 * Views are counted by a small script (so cached pages count too): once per
 * visitor per page per browser session, not for logged-in editors, not for
 * browsers that identify as automated. Daily counts are kept for 30 days.
 * The five related texts with the most views over those days are listed in the
 * page's language; related = same category (and its sub-categories), sibling
 * and child pages, the same place on a translation's breadcrumb. Where nothing
 * has been counted yet the newest related texts are listed under "More about".
 * The list is worked out at most twice a day per page and cached.
 */
class LMGT_Top {

	const DAYS = 30;
	const MAX  = 5;

	const HEAD_TOP = array(
		'en' => 'Most read about %s', 'da' => 'Mest læste om %s', 'de' => 'Am meisten gelesen über %s', 'fr' => 'Les plus lus sur %s', 'es' => 'Lo más leído sobre %s',
		'it' => 'I più letti su %s', 'pt' => 'Os mais lidos sobre %s', 'sv' => 'Mest läst om %s', 'nb' => 'Mest lest om %s', 'fi' => 'Luetuimmat: %s',
	);
	const HEAD_MORE = array(
		'en' => 'More about %s', 'da' => 'Mere om %s', 'de' => 'Mehr zu %s', 'fr' => 'Plus sur %s', 'es' => 'Más sobre %s',
		'it' => 'Altro su %s', 'pt' => 'Mais sobre %s', 'sv' => 'Mer om %s', 'nb' => 'Mer om %s', 'fi' => 'Lisää: %s',
	);

	public static function boot() {
		add_action( 'rest_api_init', function () {
			register_rest_route( 'lmgt/v2', '/hit', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_hit' ), 'permission_callback' => '__return_true' ) );
		} );
		add_action( 'wp_footer', array( __CLASS__, 'beacon' ), 99 );
		add_filter( 'manage_posts_columns', function ( $c ) { $c['lmgt_views'] = 'Views 30d'; return $c; } );
		add_filter( 'manage_pages_columns', function ( $c ) { $c['lmgt_views'] = 'Views 30d'; return $c; } );
		add_filter( 'manage_' . LMGT_CPT . '_posts_columns', function ( $c ) { $c['lmgt_views'] = 'Views 30d'; return $c; } );
		foreach ( array( 'posts', 'pages', LMGT_CPT . '_posts' ) as $t ) {
			// 2.19.2 (G, 22 Nov, WST: "00"): WordPress runs the posts hook for translations too, so the number came twice.
			add_action( 'manage_' . $t . '_custom_column', function ( $col, $id ) use ( $t ) {
				if ( $col !== 'lmgt_views' || ( $t === 'posts' && get_post_type( $id ) === LMGT_CPT ) ) return;
				echo (int) self::views( $id );
			}, 10, 2 );
		}
	}

	// ---- Counting --------------------------------------------------------------------

	public static function beacon() {
		if ( ! get_option( 'lmgt_top', 1 ) || ! is_singular( LMGT_Store::types( true ) ) || is_front_page() || current_user_can( 'edit_posts' ) ) return;
		$id = (int) get_queried_object_id();
		if ( ! $id ) return;
		echo "<script>(function(){try{if(navigator.webdriver||!window.fetch)return;var k='lmgt_h" . $id . "';if(sessionStorage.getItem(k))return;sessionStorage.setItem(k,'1');"
			. "fetch(" . wp_json_encode( esc_url_raw( rest_url( 'lmgt/v2/hit' ) ) ) . ",{method:'POST',keepalive:true,headers:{'Content-Type':'application/json'},body:JSON.stringify({id:" . $id . "})});}catch(e){}})();</script>\n";
	}

	public static function rest_hit( WP_REST_Request $req ) {
		$p  = $req->get_json_params();
		$id = isset( $p['id'] ) ? (int) $p['id'] : 0;
		if ( ! $id || get_post_status( $id ) !== 'publish' || ! in_array( get_post_type( $id ), LMGT_Store::types( true ), true ) ) return array( 'ok' => false );
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
		if ( $ua === '' || preg_match( '/bot|crawl|spider|slurp|headless|lighthouse|preview|monitor|curl|wget|python|go-http/i', $ua ) ) return array( 'ok' => false );
		$d   = get_post_meta( $id, '_lmgt_views_d', true );
		$d   = is_array( $d ) ? $d : array();
		$day = gmdate( 'Ymd' );
		$d[ $day ] = ( isset( $d[ $day ] ) ? (int) $d[ $day ] : 0 ) + 1;
		$cut = gmdate( 'Ymd', time() - self::DAYS * DAY_IN_SECONDS );
		foreach ( array_keys( $d ) as $k ) if ( (string) $k < $cut ) unset( $d[ $k ] );
		update_post_meta( $id, '_lmgt_views_d', $d );
		return array( 'ok' => true );
	}

	public static function views( $id ) {
		$d = get_post_meta( $id, '_lmgt_views_d', true );
		return is_array( $d ) ? array_sum( array_map( 'intval', $d ) ) : 0;
	}

	// ---- Related texts ---------------------------------------------------------------

	/** Original ids related to a post or page of the site's own language. */
	private static function related_source( $id ) {
		$post = get_post( $id );
		if ( ! $post ) return array();
		$out  = array();
		$cats = array();
		if ( $post->post_type === 'page' ) {
			$out = get_posts( array( 'post_type' => 'page', 'post_parent' => $post->post_parent ? $post->post_parent : $id, 'post_status' => 'publish', 'posts_per_page' => 100, 'fields' => 'ids', 'post__not_in' => array( $id ) ) );
			$out = array_merge( $out, get_posts( array( 'post_type' => 'page', 'post_parent' => $id, 'post_status' => 'publish', 'posts_per_page' => 100, 'fields' => 'ids' ) ) );
			$t   = get_term_by( 'slug', $post->post_name, 'category' );
			if ( $t ) $cats = array( $t->term_id );
		} else {
			foreach ( (array) get_the_category( $id ) as $c ) if ( (int) $c->term_id !== (int) get_option( 'default_category' ) ) $cats[] = (int) $c->term_id;
		}
		if ( $cats ) {
			$all = $cats;
			foreach ( $cats as $c ) { $kids = get_term_children( $c, 'category' ); if ( is_array( $kids ) ) $all = array_merge( $all, $kids ); }
			$out = array_merge( $out, get_posts( array( 'post_type' => 'post', 'category__in' => array_unique( $all ), 'post_status' => 'publish', 'posts_per_page' => 150, 'fields' => 'ids', 'post__not_in' => array( $id ) ) ) );
		}
		return array_values( array_diff( array_unique( array_map( 'intval', $out ) ), array( (int) $id ) ) );
	}

	private static function related( $id, $lang ) {
		$is_tr = get_post_type( $id ) === LMGT_CPT || LMGT_Store::is_tagged( $id );
		if ( $is_tr && get_post_meta( $id, '_lmgt_remote_source', true ) ) {
			// Made on traveltalk.dk: related = translations in this language under the same place in the breadcrumb.
			$trail = get_post_meta( $id, '_lmgt_trail', true );
			$key   = is_array( $trail ) && $trail ? untrailingslashit( (string) end( $trail )['url'] ) : '';
			if ( $key === '' ) return array();
			$out = array();
			foreach ( get_posts( array( 'post_type' => LMGT_CPT, 'post_status' => 'publish', 'posts_per_page' => 400, 'fields' => 'ids', 'lmgt_all' => true, 'no_found_rows' => true, 'post__not_in' => array( $id ), 'meta_key' => '_lmgt_lang', 'meta_value' => $lang ) ) as $pid ) {
				$t = get_post_meta( $pid, '_lmgt_trail', true );
				if ( is_array( $t ) && $t && untrailingslashit( (string) end( $t )['url'] ) === $key ) $out[] = (int) $pid;
			}
			return $out;
		}
		if ( $is_tr ) {
			$src = (int) get_post_meta( $id, '_lmgt_source', true );
			$out = array();
			foreach ( $src ? self::related_source( $src ) : array() as $pid ) {
				$set = LMGT_Store::of( $pid, array( 'publish' ) );
				if ( isset( $set[ $lang ] ) ) $out[] = (int) $set[ $lang ];
			}
			return $out;
		}
		return self::related_source( $id );
	}

	/** [[title, url]] up to MAX, and whether they are ranked by readers. */
	public static function top( $id, $lang ) {
		$key = 'lmgt_top_' . $id;
		$c   = get_transient( $key );
		if ( is_array( $c ) ) return $c;
		$skip = (array) apply_filters( 'lmgt_top_skip', array() );
		$ids  = array_diff( self::related( $id, $lang ), array( (int) $id ), $skip );
		$rank = array();
		foreach ( $ids as $pid ) {
			if ( get_post_status( $pid ) !== 'publish' || get_post_meta( $pid, '_lmgt_rm_off', true ) === 'top' ) continue;
			$rank[ $pid ] = self::views( $pid );
		}
		$counted = count( array_filter( $rank ) ) >= 3;
		if ( $counted ) {
			arsort( $rank );
			$pick = array_slice( array_keys( array_filter( $rank ) ), 0, self::MAX );
		} else {
			uksort( $rank, function ( $a, $b ) { return strcmp( (string) get_post_field( 'post_date_gmt', $b ), (string) get_post_field( 'post_date_gmt', $a ) ); } );
			$pick = array_slice( array_keys( $rank ), 0, self::MAX );
		}
		$out = array( 'items' => array(), 'counted' => $counted );
		foreach ( $pick as $pid ) $out['items'][] = array( html_entity_decode( get_the_title( $pid ), ENT_QUOTES, 'UTF-8' ), get_permalink( $pid ) );
		set_transient( $key, $out, 12 * HOUR_IN_SECONDS );
		return $out;
	}

	/** The list item for the Read more block, or ''. */
	public static function row( $id, $lang, $subject ) {
		if ( ! get_option( 'lmgt_top', 1 ) || $subject === '' ) return '';
		$t = self::top( $id, $lang );
		if ( empty( $t['items'] ) ) return '';
		$head = isset( ( $t['counted'] ? self::HEAD_TOP : self::HEAD_MORE )[ $lang ] ) ? ( $t['counted'] ? self::HEAD_TOP : self::HEAD_MORE )[ $lang ] : ( $t['counted'] ? self::HEAD_TOP : self::HEAD_MORE )['en'];
		$li = '';
		foreach ( $t['items'] as $i ) $li .= '<li><a href="' . esc_url( $i[1] ) . '">' . esc_html( $i[0] ) . '</a></li>';
		return '<li class="lmgt-top"><span class="lmgt-top-title">' . esc_html( sprintf( $head, $subject ) ) . '</span><ul>' . $li . '</ul></li>';
	}
}
