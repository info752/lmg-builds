<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * LMGT_Focus – 2.17.18, Travel 360 phase 1 (G, 17 Nov 2026).
 *
 * traveltalk.travel runs English only until it is as big as traveltalk.dk and has shown it can be kept up to date.
 *   - English only (Settings, on by default): automatic translations go to English only. On traveltalk.travel no new
 *     translation into another language is started. The language button shows English (and Danish, the original).
 *     The existing pages in other languages stay published, indexed, in the sitemap and with hreflang; nothing is
 *     deleted, unpublished, noindexed or redirected (HARD RULE, 11 Sep). Switch the setting off and everything works
 *     as in 2.17.17: the other languages are kept, not removed.
 *   - On traveltalk.dk every post has "Oversæt til engelsk (traveltalk.travel)?": Ja (default) / Nej / Senere, and
 *     ticks for more languages (kept for a later wave). Ja → queued about 30 minutes after first publication (as
 *     before). Nej → never queued. Senere → on Translator → Afventer oversættelse, with a button to translate now.
 *   - On a translation, G approves headline and intro (Yes/No) instead of reading the whole text; the back-translation
 *     check still marks changed meaning. Publish needs that Yes. Flags do not block: "Publish despite N flags" asks once.
 *
 * Meta on the original: _lmgt_en_choice ja|nej|senere (empty = ja), _lmgt_more_langs array of codes.
 * Meta on the translation: _lmgt_intro_ok array( ok => 1|0, by, at ).
 */
class LMGT_Focus {

	public static function boot() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_box' ) );
		add_action( 'save_post', array( __CLASS__, 'save_choice' ), 20, 2 );
		add_action( 'admin_menu', function () {
			if ( ! LMGT_Bridge::is_target() ) add_submenu_page( 'lmgt', 'Afventer oversættelse', 'Afventer oversættelse', 'edit_others_posts', 'lmgt-later', array( __CLASS__, 'page_later' ) );
		}, 42 );
		add_action( 'admin_post_lmgt_later_now', array( __CLASS__, 'handle_later_now' ) );
		add_action( 'admin_post_lmgt_intro', array( __CLASS__, 'handle_intro' ) );
		// 2.17.19: recompute every stored language set once, so x-default moves to English on existing pages too.
		add_action( 'lmgt_xdef_batch', array( __CLASS__, 'xdef_batch' ) );
		add_action( 'admin_init', function () {
			if ( ! LMGT_Bridge::is_source() || get_option( 'lmgt_xdef_done', '' ) === '2.17.19' || wp_next_scheduled( 'lmgt_xdef_batch' ) ) return;
			$ids = get_posts( array( 'post_type' => 'any', 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids', 'meta_key' => '_lmgt_set', 'no_found_rows' => true ) );
			update_option( 'lmgt_xdef_todo', array_map( 'intval', $ids ), false );
			update_option( 'lmgt_xdef_done', '2.17.19', false );
			wp_schedule_single_event( time() + 60, 'lmgt_xdef_batch' );
		} );
	}

	public static function xdef_batch() {
		$todo = (array) get_option( 'lmgt_xdef_todo', array() );
		foreach ( array_splice( $todo, 0, 15 ) as $id ) LMGT_Bridge::refresh_set( (int) $id );
		update_option( 'lmgt_xdef_todo', $todo, false );
		if ( $todo ) wp_schedule_single_event( time() + 60, 'lmgt_xdef_batch' );
	}

	public static function english_only() {
		return get_option( 'lmgt_english_only', '1' ) === '1';
	}

	/** Languages an automatic translation of $post_id goes to. */
	public static function auto_langs( $post_id ) {
		$on = LMGT_Langs::enabled();
		if ( ! self::english_only() ) return $on;
		if ( LMGT_Bridge::is_target() ) return array(); // .travel makes no new translations of its own articles into other languages.
		$want = array_merge( array( 'en' ), (array) get_post_meta( $post_id, '_lmgt_more_langs', true ) );
		return array_values( array_intersect( $on, $want ) );
	}

	public static function choice( $post_id ) {
		$c = (string) get_post_meta( $post_id, '_lmgt_en_choice', true );
		return in_array( $c, array( 'nej', 'senere' ), true ) ? $c : 'ja';
	}

	/** Language codes the language button may show while English only is on. */
	public static function switcher_langs( array $langs, $cur ) {
		if ( ! self::english_only() ) return $langs;
		$keep = array( 'en', 'da', $cur );
		return array_values( array_filter( $langs, function ( $c ) use ( $keep ) { return in_array( $c, $keep, true ); } ) );
	}

	// ---- 3a: the choice on traveltalk.dk ---------------------------------------------

	public static function add_box() {
		if ( LMGT_Bridge::is_target() ) return;
		add_meta_box( 'lmgt_en_choice', 'Oversæt til engelsk (traveltalk.travel)?', array( __CLASS__, 'box' ), 'post', 'side', 'high' );
	}

	public static function box( $post ) {
		$c    = self::choice( $post->ID );
		$more = (array) get_post_meta( $post->ID, '_lmgt_more_langs', true );
		wp_nonce_field( 'lmgt_en_choice_' . $post->ID, 'lmgt_en_choice_nonce' );
		foreach ( array( 'ja' => 'Ja', 'nej' => 'Nej – aldrig', 'senere' => 'Senere' ) as $k => $label ) {
			echo '<label style="display:block;margin:2px 0"><input type="radio" name="lmgt_en_choice" value="' . esc_attr( $k ) . '" ' . checked( $c, $k, false ) . '> ' . esc_html( $label ) . '</label>';
		}
		echo '<p class="description">Ja: oversættes ca. 30 min. efter første udgivelse og ligger som kladde på traveltalk.travel. Senere: står på Translator → Afventer oversættelse.</p>';
		$others = array_values( array_diff( LMGT_Langs::enabled(), array( 'en' ) ) );
		if ( $others ) {
			echo '<details' . ( $more ? ' open' : '' ) . '><summary>Flere sprog (sjældent)</summary>';
			foreach ( $others as $code ) {
				$l = LMGT_Langs::get( $code );
				echo '<label style="display:block"><input type="checkbox" name="lmgt_more_langs[]" value="' . esc_attr( $code ) . '" ' . checked( in_array( $code, $more, true ), true, false ) . '> ' . esc_html( $l ? $l['native'] : $code ) . '</label>';
			}
			echo '</details>';
		}
	}

	public static function save_choice( $id, $post ) {
		if ( $post->post_type !== 'post' || LMGT_Bridge::is_target() || wp_is_post_revision( $id ) ) return;
		if ( ! isset( $_POST['lmgt_en_choice_nonce'] ) || ! wp_verify_nonce( $_POST['lmgt_en_choice_nonce'], 'lmgt_en_choice_' . $id ) ) return;
		if ( ! current_user_can( 'edit_post', $id ) ) return;
		$was = self::choice( $id );
		$c   = isset( $_POST['lmgt_en_choice'] ) ? sanitize_key( wp_unslash( $_POST['lmgt_en_choice'] ) ) : 'ja';
		$c   = in_array( $c, array( 'ja', 'nej', 'senere' ), true ) ? $c : 'ja';
		if ( $c === 'ja' ) delete_post_meta( $id, '_lmgt_en_choice' ); else update_post_meta( $id, '_lmgt_en_choice', $c );
		$more = array_values( array_intersect( array_map( 'sanitize_key', (array) ( isset( $_POST['lmgt_more_langs'] ) ? wp_unslash( $_POST['lmgt_more_langs'] ) : array() ) ), array_keys( LMGT_Langs::all() ) ) );
		if ( $more ) update_post_meta( $id, '_lmgt_more_langs', $more ); else delete_post_meta( $id, '_lmgt_more_langs' );
		// Changed to Ja on a post that is already out and was held back: queue it now.
		if ( $c === 'ja' && $was !== 'ja' && $post->post_status === 'publish' ) self::queue_now( $id );
	}

	public static function queue_now( $id ) {
		$n = 0;
		foreach ( self::auto_langs( $id ) as $lang ) if ( ! is_wp_error( LMGT_Jobs::add( (int) $id, $lang, true ) ) ) $n++;
		update_post_meta( $id, '_lmgt_auto_queued', time() );
		return $n;
	}

	public static function page_later() {
		$ids = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 300, 'fields' => 'ids', 'meta_key' => '_lmgt_en_choice', 'meta_value' => 'senere', 'no_found_rows' => true ) );
		echo '<div class="wrap"><h1>Afventer oversættelse</h1><p>Indlæg, hvor "Oversæt til engelsk?" står på Senere. "Oversæt nu" sætter det til Ja og lægger det i køen.</p>';
		if ( ! $ids ) { echo '<p>Ingen.</p></div>'; return; }
		echo '<table class="widefat striped"><thead><tr><th>Indlæg</th><th>Udgivet</th><th></th></tr></thead><tbody>';
		foreach ( $ids as $id ) {
			$now = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_later_now&post=' . $id ), 'lmgt_later_now_' . $id );
			printf( '<tr><td><a href="%s">%s</a></td><td>%s</td><td><a class="button" href="%s">Oversæt nu</a></td></tr>', esc_url( get_edit_post_link( $id, 'url' ) ), esc_html( get_the_title( $id ) ), esc_html( get_the_date( 'j M Y', $id ) ), esc_url( $now ) );
		}
		echo '</tbody></table></div>';
	}

	public static function handle_later_now() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_later_now_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		delete_post_meta( $id, '_lmgt_en_choice' );
		$n = self::queue_now( $id );
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $n . ' oversættelse(r) lagt i køen for "' . get_the_title( $id ) . '".' ), admin_url( 'admin.php?page=lmgt-later' ) ) );
		exit;
	}

	// ---- 3c: headline and intro -------------------------------------------------------

	public static function intro_ok( $id ) {
		$v = get_post_meta( $id, '_lmgt_intro_ok', true );
		return is_array( $v ) && ! empty( $v['ok'] );
	}

	public static function intro_said( $id ) {
		$v = get_post_meta( $id, '_lmgt_intro_ok', true );
		return is_array( $v ) ? $v : null;
	}

	/** The first paragraph of the text, plain. */
	public static function intro_text( $post ) {
		$html = (string) $post->post_content;
		if ( preg_match( '#<p[^>]*>(.*?)</p>#is', $html, $m ) && trim( wp_strip_all_tags( $m[1] ) ) !== '' ) return trim( wp_strip_all_tags( $m[1] ) );
		$plain = trim( wp_strip_all_tags( $html ) );
		$cut   = preg_split( "/\n\s*\n/", $plain, 2 );
		return trim( $cut[0] );
	}

	/** The approval block shown in "Translation: what to do now". */
	public static function intro_block( $post ) {
		$said = self::intro_said( $post->ID );
		$yes  = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_intro&ok=1&post=' . $post->ID ), 'lmgt_intro_' . $post->ID );
		$no   = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_intro&ok=0&post=' . $post->ID ), 'lmgt_intro_' . $post->ID );
		$intro = self::intro_text( $post );
		$out  = '<div style="border:1px solid #c3c4c7;border-radius:4px;padding:8px 10px;margin:0 0 10px;background:#fff">';
		$out .= '<p style="margin:0 0 4px"><strong>Headline and intro</strong></p>';
		$out .= '<p style="margin:0 0 4px;font-weight:600">' . esc_html( get_the_title( $post ) ) . '</p>';
		$out .= '<p style="margin:0 0 8px">' . esc_html( mb_strlen( $intro ) > 600 ? mb_substr( $intro, 0, 597 ) . '…' : $intro ) . '</p>';
		if ( $said && ! empty( $said['ok'] ) ) {
			$out .= '<p style="color:#008a20;margin:0"><strong>✓ Approved</strong> ' . esc_html( isset( $said['at'] ) ? $said['at'] : '' ) . ' · <a href="' . esc_url( $no ) . '">undo</a></p>';
		} else {
			if ( $said ) $out .= '<p style="color:#b32d2e;margin:0 0 6px"><strong>Not approved.</strong> Change the headline or the intro, Update, then say Yes.</p>';
			$out .= '<p style="margin:0"><a class="button button-primary" href="' . esc_url( $yes ) . '">Yes, fine</a> <a class="button" href="' . esc_url( $no ) . '">No</a></p>';
		}
		$out .= '<p class="description" style="margin:6px 0 0">Approve these two; spot-check the rest. The check below marks changed meaning.</p></div>';
		return $out;
	}

	public static function handle_intro() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_intro_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$ok = ! empty( $_GET['ok'] );
		update_post_meta( $id, '_lmgt_intro_ok', array( 'ok' => $ok ? 1 : 0, 'by' => get_current_user_id(), 'at' => current_time( 'j M H:i' ) ) );
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $ok ? 'Headline and intro approved.' : 'Headline and intro not approved. Change them, Update, then say Yes.' ), get_edit_post_link( $id, 'url' ) ) );
		exit;
	}
}
