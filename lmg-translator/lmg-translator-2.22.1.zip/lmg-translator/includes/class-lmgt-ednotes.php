<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.22.0 (G, 26 Nov: "the useful comments like where to put which images end up in the middle of the
 * post, and if I delete them they pop up again"): notes to the editor never stay in the text.
 * Every save moves them to the box "Notes for the editor"; readers never see them; translations never
 * get them. Notes you delete in the box are remembered and not put back.
 */
class LMGT_EdNotes {

	const META = '_lmgt_ednotes';
	const GONE = '_lmgt_ednotes_gone';

	private static $pending = array();

	/** Headings that open a section for the editor, in the languages the sites use. */
	const HEAD = '(?:noter\s+)?til\s+redaktionen|for\s+redaktionen|redaktionelle\s+noter|redaktionsnoter|note\s+til\s+redaktionen|billedplan|billedforslag|(?:notes?\s+)?(?:to|for)\s+the\s+editors?|editor\'?s?\'?\s+notes?|editorial\s+notes?|image\s+plan|picture\s+plan|photo\s+plan|(?:noter\s+)?till?\s+redaktionen|för\s+redaktionen|redaktionsanteckningar|bildplan|(?:notater\s+)?til\s+redaksjonen|for\s+redaksjonen|bildeplan|(?:hinweise\s+)?(?:für|an)\s+die\s+redaktion|bildplanung|toimitukselle|kuvasuunnitelma|(?:notes?\s+)?(?:pour|à)\s+la\s+rédaction|plan\s+des\s+images|(?:notas\s+)?para\s+la\s+redacción|plan\s+de\s+imágenes|(?:note\s+)?per\s+la\s+redazione|piano\s+delle\s+immagini|(?:notas\s+)?para\s+a\s+redação|plano\s+de\s+imagens';

	/** A paragraph that is an image suggestion or placement note. */
	const PIC = '(?:billedforslag|billedplacering|billede\s*\d+\s*[:–-]|placer\s+billede|indsæt\s+billede|foto(?:forslag)?\s*\d+\s*[:–-]|image\s+(?:suggestion|idea|placement)|suggested\s+(?:image|picture|photo)|(?:picture|photo)\s+suggestion|(?:image|picture|photo)\s*\d+\s*[:–-]|(?:insert|place|add)\s+(?:an?\s+)?(?:image|picture|photo)|bildförslag|bildeforslag|bild(?:vorschlag)?\s*\d+\s*[:–-]|bildvorschlag|bild\s+einfügen|kuvaehdotus|kuva\s*\d+\s*[:–-]|suggestion\s+d\'image|image\s+suggérée|sugerencia\s+de\s+imagen|imagen\s+sugerida|suggerimento\s+(?:per\s+l\'?)?immagine|immagine\s+suggerita|sugestão\s+de\s+imagem|imagem\s+sugerida)';

	public static function boot() {
		add_filter( 'wp_insert_post_data', array( __CLASS__, 'on_insert' ), 5, 2 );
		add_action( 'wp_insert_post', array( __CLASS__, 'store' ), 1, 2 );
		add_filter( 'the_content', array( __CLASS__, 'front' ), 1 );
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_box' ) );
		add_action( 'save_post', array( __CLASS__, 'save_box' ), 2 );
		add_action( 'admin_footer-post.php', array( __CLASS__, 'save_first_js' ) );
		add_action( 'admin_footer-post-new.php', array( __CLASS__, 'save_first_js' ) );
	}

	private static function types() {
		return array_unique( array_merge( (array) LMGT_Store::types(), array( 'post', 'page', LMGT_CPT ) ) );
	}

	/**
	 * Splits $html into the text without notes and the notes, as plain-text chunks.
	 * @return array [ html, chunks[] ]
	 */
	public static function split( $html ) {
		$html   = (string) $html;
		$chunks = array();
		if ( $html === '' ) return array( $html, $chunks );

		// 1. Sections for the editor: from such a heading to the next heading of the same or higher level.
		$hre = '#(?:<!--\s*wp:heading\b[^>]*-->\s*)?<h([1-6])\b[^>]*>(.*?)</h\1>(?:\s*<!--\s*/wp:heading\s*-->)?#is';
		for ( $guard = 0; $guard < 10; $guard++ ) {
			if ( ! preg_match_all( $hre, $html, $m, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) break;
			$hit = false;
			foreach ( $m as $k => $h ) {
				if ( ! preg_match( '/^\s*(?:' . self::HEAD . ')\b/iu', self::text( $h[2][0] ) ) ) continue;
				$lvl   = (int) $h[1][0];
				$start = $h[0][1];
				$end   = strlen( $html );
				for ( $j = $k + 1; $j < count( $m ); $j++ ) {
					if ( (int) $m[ $j ][1][0] <= $lvl ) { $end = $m[ $j ][0][1]; break; }
				}
				$cut = substr( $html, $start, $end - $start );
				// Closing tags of a block the section sits in stay in the text.
				list( $cut, $keep ) = self::outer_closers( $cut );
				$chunks[] = self::text( $cut );
				$html     = substr( $html, 0, $start ) . $keep . substr( $html, $end );
				$hit      = true;
				break;
			}
			if ( ! $hit ) break;
		}

		// 2. Paragraphs and list items that are image suggestions.
		$html = preg_replace_callback(
			'#(?:<!--\s*wp:paragraph\b[^>]*-->\s*)?<p\b[^>]*>(.*?)</p>(?:\s*<!--\s*/wp:paragraph\s*-->)?#is',
			function ( $p ) use ( &$chunks ) {
				$t = self::text( $p[1] );
				if ( ! preg_match( '/^\s*[\[(*_]*\s*' . self::PIC . '/iu', $t ) ) return $p[0];
				$chunks[] = $t;
				return '';
			},
			$html
		);

		// 3. Bracketed notes inside a sentence: [Billedforslag 3: …], (Image suggestion: …).
		$html = preg_replace_callback(
			'/\s*[\[(]\s*' . self::PIC . '[^\])<]{0,400}[\])]/iu',
			function ( $b ) use ( &$chunks ) {
				$chunks[] = trim( self::text( $b[0] ) );
				return '';
			},
			$html
		);

		$chunks = array_values( array_filter( array_map( 'trim', $chunks ), 'strlen' ) );
		if ( $chunks ) $html = preg_replace( "/\n{3,}/", "\n\n", $html );
		return array( $html, $chunks );
	}

	/** Closing tags at the end of $cut that close a block opened before it: [ cut, closers to keep ]. */
	private static function outer_closers( $cut ) {
		if ( ! preg_match( '#(?:\s*(?:</[a-z0-9]+>|<!--\s*/wp:[a-z0-9/-]+\s*-->))+\s*$#i', $cut, $t ) ) return array( $cut, '' );
		$body = substr( $cut, 0, strlen( $cut ) - strlen( $t[0] ) );
		preg_match_all( '#</([a-z0-9]+)>|<!--\s*/wp:([a-z0-9/-]+)\s*-->#i', $t[0], $tok, PREG_SET_ORDER );
		$open = array();
		$keep = '';
		$mine = '';
		foreach ( $tok as $k ) {
			$html_tag = $k[1] !== '';
			$name     = strtolower( $html_tag ? $k[1] : $k[2] );
			$key      = ( $html_tag ? 'h:' : 'b:' ) . $name;
			if ( ! isset( $open[ $key ] ) ) {
				$q = preg_quote( $name, '#' );
				$open[ $key ] = $html_tag
					? preg_match_all( '#<' . $q . '\b#i', $body ) - preg_match_all( '#</' . $q . '>#i', $body )
					: preg_match_all( '#<!--\s*wp:' . $q . '\b(?![^>]*/-->)#i', $body ) - preg_match_all( '#<!--\s*/wp:' . $q . '\s*-->#i', $body );
			}
			if ( $open[ $key ] > 0 ) { $open[ $key ]--; $mine .= $k[0]; }
			else $keep .= $k[0];
		}
		return array( $body . $mine, $keep );
	}

	/** The text without notes (used before translating). */
	public static function clean( $html ) {
		$r = self::split( $html );
		return $r[0];
	}

	private static function text( $html ) {
		$h = preg_replace( '#<!--.*?-->#s', '', (string) $html );
		$h = preg_replace( '#</t[dh]>\s*#i', ' | ', $h );
		$h = preg_replace( '#<br\s*/?>|</(?:p|li|tr|h[1-6]|div|table|ul|ol)>#i', "\n", $h );
		$h = html_entity_decode( wp_strip_all_tags( $h ), ENT_QUOTES, 'UTF-8' );
		$h = preg_replace( '/[ \t]+/', ' ', $h );
		$h = preg_replace( '/ ?\| ?\n/', "\n", $h );
		return trim( preg_replace( "/\n\s*\n+/", "\n", $h ) );
	}

	private static function hash( $t ) {
		return md5( strtolower( preg_replace( '/\s+/u', ' ', trim( (string) $t ) ) ) );
	}

	public static function on_insert( $data, $postarr ) {
		if ( empty( $data['post_type'] ) || ! in_array( $data['post_type'], self::types(), true ) ) return $data;
		if ( empty( $data['post_content'] ) ) return $data;
		list( $html, $chunks ) = self::split( wp_unslash( $data['post_content'] ) );
		if ( ! $chunks ) return $data;
		$data['post_content'] = wp_slash( $html );
		self::$pending[] = array( 'id' => isset( $postarr['ID'] ) ? (int) $postarr['ID'] : 0, 'chunks' => $chunks );
		return $data;
	}

	public static function store( $id, $post ) {
		if ( ! self::$pending || ! $post || wp_is_post_revision( $id ) || ! in_array( $post->post_type, self::types(), true ) ) return;
		foreach ( self::$pending as $k => $p ) {
			if ( $p['id'] && $p['id'] !== (int) $id ) continue;
			unset( self::$pending[ $k ] );
			self::add( $id, $p['chunks'] );
			break;
		}
	}

	public static function add( $id, array $chunks ) {
		$gone = (array) get_post_meta( $id, self::GONE, true );
		$have = self::get( $id );
		$hs   = wp_list_pluck( $have, 'h' );
		$new  = false;
		foreach ( $chunks as $c ) {
			$h = self::hash( $c );
			if ( in_array( $h, $gone, true ) || in_array( $h, $hs, true ) ) continue;
			$have[] = array( 'h' => $h, 't' => $c, 'at' => current_time( 'mysql', true ) );
			$hs[]   = $h;
			$new    = true;
		}
		if ( $new ) update_post_meta( $id, self::META, wp_slash( $have ) );
	}

	public static function get( $id ) {
		$v = get_post_meta( (int) $id, self::META, true );
		return is_array( $v ) ? array_values( $v ) : array();
	}

	public static function front( $content ) {
		if ( is_admin() || ! is_string( $content ) || $content === '' ) return $content;
		return self::clean( $content );
	}

	// ---- The box ---------------------------------------------------------------

	public static function add_box( $type ) {
		if ( ! in_array( $type, self::types(), true ) ) return;
		global $post;
		if ( ! $post || ! self::get( $post->ID ) ) return;
		add_meta_box( 'lmgt_ednotes', 'Notes for the editor', array( __CLASS__, 'box' ), $type, 'side', 'high' );
	}

	private static function joined( array $notes ) {
		return implode( "\n\n----\n\n", wp_list_pluck( $notes, 't' ) );
	}

	public static function box( $post ) {
		$txt = self::joined( self::get( $post->ID ) );
		wp_nonce_field( 'lmgt_ednotes_' . $post->ID, 'lmgt_ednotes_nonce' );
		echo '<p class="description">Taken out of the text on save (picture plan, links, checks). Readers and translations never see them. Delete what you have done; deleted notes do not come back.</p>';
		echo '<textarea name="lmgt_ednotes" rows="12" style="width:100%;font-size:12px">' . esc_textarea( $txt ) . '</textarea>';
		echo '<input type="hidden" name="lmgt_ednotes_was" value="' . esc_attr( md5( $txt ) ) . '">';
	}

	public static function save_box( $id ) {
		if ( ! isset( $_POST['lmgt_ednotes_was'], $_POST['lmgt_ednotes'] ) || wp_is_post_revision( $id ) ) return;
		if ( empty( $_POST['lmgt_ednotes_nonce'] ) || ! wp_verify_nonce( $_POST['lmgt_ednotes_nonce'], 'lmgt_ednotes_' . $id ) || ! current_user_can( 'edit_post', $id ) ) return;
		$now  = str_replace( "\r\n", "\n", (string) wp_unslash( $_POST['lmgt_ednotes'] ) );
		$have = self::get( $id );
		if ( md5( $now ) === (string) $_POST['lmgt_ednotes_was'] ) return; // untouched: keep what is stored, including notes taken out in this save
		$gone = (array) get_post_meta( $id, self::GONE, true );
		$shown = $have;
		// Only the notes the box showed count as reviewed; any taken out during this same save stay.
		$was = (string) $_POST['lmgt_ednotes_was'];
		$keep = array();
		for ( $n = count( $have ); $n >= 0; $n-- ) {
			if ( md5( self::joined( array_slice( $have, 0, $n ) ) ) === $was ) { $shown = array_slice( $have, 0, $n ); $keep = array_slice( $have, $n ); break; }
		}
		foreach ( $shown as $c ) $gone[] = $c['h'];
		update_post_meta( $id, self::GONE, array_values( array_unique( $gone ) ) );
		$out = array();
		if ( trim( $now ) !== '' ) $out[] = array( 'h' => self::hash( $now ), 't' => trim( $now ), 'at' => current_time( 'mysql', true ) );
		$out = array_merge( $out, $keep );
		if ( $out ) update_post_meta( $id, self::META, wp_slash( $out ) );
		else delete_post_meta( $id, self::META );
	}

	/**
	 * The Translator buttons on the edit screen work on the saved text. With unsaved edits in the block
	 * editor (a deleted note, say), the step used the old text and the deleted lines came back.
	 * Now the editor saves first, then the step runs.
	 */
	public static function save_first_js() {
		?>
<script>
(function(){
	if(!window.wp||!wp.data||!wp.data.select('core/editor'))return;
	var ed=function(){return wp.data.select('core/editor');};
	var busy=function(){var e=ed();var m=wp.data.select('core/edit-post');return e.isSavingPost()||e.isAutosavingPost()||(m&&m.isSavingMetaBoxes&&m.isSavingMetaBoxes());};
	var isStep=function(u){return /admin-post\.php/.test(u||'')&&/[?&]action=lmgt_/.test(u||'');};
	var saveThen=function(go){
		var p=wp.data.dispatch('core/editor').savePost();
		var wait=function(){if(busy()){setTimeout(wait,200);return;}
			if(ed().didPostSaveRequestFail&&ed().didPostSaveRequestFail()){alert('The post could not be saved, so the Translator step was not run. Save the post, then try again.');return;}
			go();};
		Promise.resolve(p).then(function(){setTimeout(wait,300);},function(){setTimeout(wait,300);});
	};
	var pass=false;
	document.addEventListener('click',function(e){
		if(pass)return;
		var a=e.target.closest&&e.target.closest('a[href]');
		if(!a||!isStep(a.href)||!ed().isEditedPostDirty())return;
		e.preventDefault();e.stopImmediatePropagation();
		saveThen(function(){pass=true;a.click();pass=false;});
	},true);
	document.addEventListener('submit',function(e){
		if(pass)return;
		var f=e.target;var act=f.elements&&f.elements.namedItem('action');
		if(!/admin-post\.php/.test(f.getAttribute('action')||'')||!act||!/^lmgt_/.test(act.value)||!ed().isEditedPostDirty())return;
		e.preventDefault();e.stopImmediatePropagation();
		var s=e.submitter||null;
		saveThen(function(){pass=true;if(f.requestSubmit){f.requestSubmit(s);}else{f.submit();}pass=false;});
	},true);
})();
</script>
		<?php
	}
}
