<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Check Google tags, rebuilt for the bridge (2.2.6).
 *
 * Checks from the database what every page will print: language, noindex,
 * canonical, and the hreflang set (its own address in it, x-default by the
 * rule, every member published and not thin, the same set on every member of
 * this site). On .dk it also compares each original's stored set with a fresh
 * computation and, on request, with what .travel stores (one call: GET /sets).
 * Nothing is fetched over the web except "Check live" on ONE page, chosen by a
 * person (no HTTP sweeps of our own sites, brief section 0). Read-only, except
 * "Send the set again" on .dk, which does what saving the original does.
 *
 * Until 2.2.5 this page fetched every translation and its original over HTTP
 * with the one-site (1.x) rules, so on the bridge most of what it reported
 * was not wrong at all.
 */
class LMGT_Checker {

	public static function boot() {
		add_action( 'wp_ajax_lmgt_check_live', array( __CLASS__, 'ajax_live' ) );
		add_action( 'admin_post_lmgt_resend_set', array( __CLASS__, 'handle_resend' ) );
	}

	// ---- What a page should print ----------------------------------------------

	/** The set the page prints, from the database: [members, x], or array() when it prints none. */
	public static function expected( $id ) {
		$post = get_post( $id );
		if ( ! $post || $post->post_status !== 'publish' ) return array();
		$in = function ( $set ) use ( $id ) {
			return is_array( $set ) && ! empty( $set['members'] ) && in_array( get_permalink( $id ), $set['members'], true ) ? $set : array();
		};
		if ( LMGT_Bridge::is_target() ) {
			if ( get_post_meta( $id, '_lmgt_remote_source', true ) ) return $in( get_post_meta( $id, '_lmgt_set', true ) );
			return self::local( $id );
		}
		if ( LMGT_Bridge::is_source() ) {
			if ( get_post_meta( $id, '_lmgt_moved_to', true ) ) return array();
			$src = LMGT_Store::is_translation( $id ) ? (int) get_post_meta( $id, '_lmgt_source', true ) : $id;
			return $in( get_post_meta( $src, '_lmgt_set', true ) );
		}
		return self::local( $id );
	}

	/** One site (and .travel's own pages): the original and its published, non-thin translations; x-default the original. */
	private static function local( $id ) {
		$src = LMGT_Store::is_translation( $id ) ? (int) get_post_meta( $id, '_lmgt_source', true ) : $id;
		$p   = get_post( $src );
		if ( ! $p || $p->post_status !== 'publish' || (int) get_option( 'page_on_front' ) === $src ) return array();
		$m = array( LMGT_Langs::source() => get_permalink( $src ) );
		foreach ( LMGT_Store::of( $src, array( 'publish' ) ) as $lang => $tid ) {
			if ( LMGT_Langs::get( $lang ) && ! LMGT_Store::is_thin( $tid ) ) $m[ $lang ] = get_permalink( $tid );
		}
		return count( $m ) > 1 ? array( 'members' => $m, 'x' => $m[ LMGT_Langs::source() ] ) : array();
	}

	/** The pages to check: published translations, and the originals that have a set. */
	private static function pages() {
		$ids = get_posts( array( 'post_type' => LMGT_CPT, 'post_status' => 'publish', 'posts_per_page' => 2000, 'fields' => 'ids', 'no_found_rows' => true, 'lmgt_all' => true ) );
		foreach ( LMGT_Store::tagged() as $t ) if ( get_post_status( $t ) === 'publish' ) $ids[] = (int) $t;
		global $wpdb;
		$key  = LMGT_Bridge::is_target() ? '_lmgt_remote_source' : ( LMGT_Bridge::is_source() ? '_lmgt_set' : '' );
		if ( $key ) {
			foreach ( $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT m.post_id FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key = %s AND p.post_status = 'publish' AND p.post_type IN ('" . implode( "','", array_map( 'esc_sql', LMGT_Store::types() ) ) . "')", $key ) ) as $id ) $ids[] = (int) $id;
		}
		return array_values( array_unique( array_map( 'intval', $ids ) ) );
	}

	/**
	 * One page, from the database. Problems are what Google would get wrong;
	 * notes are things that look odd but are on purpose.
	 *
	 * @return array{problems:string[],notes:string[],stale?:bool}
	 */
	public static function check( $id ) {
		$p     = array();
		$n     = array();
		$out   = array();
		$url   = get_permalink( $id );
		$cpt   = get_post_type( $id ) === LMGT_CPT;
		$lang  = get_post_meta( $id, '_lmgt_lang', true );
		$thin  = LMGT_Store::is_thin( $id );
		$moved = LMGT_Bridge::is_source() ? get_post_meta( $id, '_lmgt_moved_to', true ) : '';
		if ( ( $cpt || $lang ) && ! LMGT_Langs::get( $lang ) ) $p[] = 'no valid language stored';

		$robots = (array) get_post_meta( $id, 'rank_math_robots', true );
		if ( in_array( 'noindex', $robots, true ) ) $p[] = 'set to noindex in Rank Math (Advanced tab)';
		if ( $thin ) $n[] = 'under ' . (int) get_option( 'lmgt_noindex_under', 800 ) . ' words: hidden from Google and out of the language set until filled out (on purpose)';

		$canon = (string) get_post_meta( $id, 'rank_math_canonical_url', true );
		if ( $moved ) {
			$n[]  = 'copied to traveltalk.travel: canonical there, no language links here (on purpose)';
			$sid  = (int) get_post_meta( $id, '_lmgt_source', true );
			$r    = LMGT_Bridge::remote( $sid );
			$code = get_post_meta( $id, '_lmgt_lang', true );
			if ( isset( $r[ $code ]['url'] ) && $r[ $code ]['url'] !== $moved ) $p[] = 'canonical points to ' . $moved . ', but the copy on traveltalk.travel is now ' . $r[ $code ]['url'];
		} elseif ( $canon !== '' && untrailingslashit( $canon ) !== untrailingslashit( $url ) ) {
			$p[] = 'canonical set by hand to ' . $canon;
		}

		if ( ! $moved && ! $thin ) {
			$set = self::expected( $id );
			if ( LMGT_Bridge::is_target() && get_post_meta( $id, '_lmgt_remote_source', true ) && ! $set ) {
				$p[] = 'not in its language set, so it prints no language links (Translator → Bridge → Reconcile on traveltalk.dk)';
			}
			if ( LMGT_Bridge::is_source() && ! LMGT_Store::is_translation( $id ) ) {
				$fresh = LMGT_Bridge::compute_set( $id );
				$saved = get_post_meta( $id, '_lmgt_set', true );
				if ( $fresh != $saved ) {
					$p[]          = 'stored language set is out of date';
					$out['stale'] = true;
				}
			}
			if ( $set ) {
				$want_x = LMGT_Bridge::on() && ! ( LMGT_Bridge::is_target() && ! get_post_meta( $id, '_lmgt_remote_source', true ) )
					? ( isset( $set['members']['en'] ) ? $set['members']['en'] : ( isset( $set['members']['da'] ) ? $set['members']['da'] : '' ) )
					: $set['members'][ LMGT_Langs::source() ];
				if ( $set['x'] !== $want_x ) $p[] = 'x-default is ' . $set['x'] . ', expected ' . $want_x;
				// 2.2.26: say why a set's world default is still the original.
				if ( LMGT_Bridge::on() && ! isset( $set['members']['en'] ) && LMGT_Langs::source() !== 'en' && $set['x'] === ( isset( $set['members'][ LMGT_Langs::source() ] ) ? $set['members'][ LMGT_Langs::source() ] : '' ) ) $n[] = 'x-default is the original: no English version published yet (Translate everything queues English for these first)';
				$host = wp_parse_url( home_url(), PHP_URL_HOST );
				foreach ( $set['members'] as $code => $m ) {
					if ( ! LMGT_Langs::get( $code ) ) {
						$p[] = 'unknown language "' . $code . '" in the set';
						continue;
					}
					if ( wp_parse_url( $m, PHP_URL_HOST ) !== $host || $m === $url ) continue;
					$mid = url_to_postid( $m );
					if ( ! $mid ) $mid = LMGT_Store::find( $code, basename( untrailingslashit( wp_parse_url( $m, PHP_URL_PATH ) ) ) );
					if ( ! $mid || get_post_status( $mid ) !== 'publish' ) $p[] = 'lists ' . $code . ' ' . $m . ', which is not a published page here';
					elseif ( LMGT_Store::is_thin( $mid ) ) $p[] = 'lists ' . $code . ' ' . $m . ', which is under the word limit';
				}
				if ( LMGT_Bridge::is_target() && get_post_meta( $id, '_lmgt_remote_source', true ) ) {
					foreach ( LMGT_Bridge::members( (int) get_post_meta( $id, '_lmgt_remote_source', true ) ) as $o ) {
						if ( $o !== $id && get_post_status( $o ) === 'publish' && ! LMGT_Store::is_thin( $o ) && get_post_meta( $o, '_lmgt_set', true ) != get_post_meta( $id, '_lmgt_set', true ) ) {
							$p[] = 'its set differs from the one stored on ' . get_permalink( $o );
							break;
						}
					}
				}
			}
		}
		return array_merge( $out, array( 'problems' => $p, 'notes' => $n ) );
	}

	// ---- The page ----------------------------------------------------------------

	public static function page() {
		$ids  = self::pages();
		$bad  = 0;
		$rows = '';
		$all  = ! empty( $_GET['all'] );
		foreach ( $ids as $id ) {
			$r = self::check( $id );
			if ( $r['problems'] ) $bad++;
			if ( ! $all && ! $r['problems'] ) continue;
			$res = $r['problems'] ? '<span style="color:#b32d2e">' . esc_html( implode( ' · ', $r['problems'] ) ) . '</span>' : '<span style="color:#008a20">OK</span>';
			if ( $r['notes'] ) $res .= '<br><span class="description">' . esc_html( implode( ' · ', $r['notes'] ) ) . '</span>';
			if ( ! empty( $r['stale'] ) ) $res .= ' <a class="button button-small" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_resend_set&id=' . $id ), 'lmgt_resend_' . $id ) ) . '">Send the set again</a>';
			$rows .= '<tr><td><a href="' . esc_url( get_permalink( $id ) ) . '" target="_blank">' . esc_html( wp_parse_url( get_permalink( $id ), PHP_URL_PATH ) ) . '</a></td><td>' . $res . '</td><td><button type="button" class="button button-small lmgt-live" data-id="' . (int) $id . '">Check live</button><div class="lmgt-live-out"></div></td></tr>';
		}
		echo '<div class="wrap"><h1>Check Google tags</h1>';
		if ( ! empty( $_GET['lmgt_msg'] ) ) echo '<div class="notice notice-info"><p>' . esc_html( wp_unslash( $_GET['lmgt_msg'] ) ) . '</p></div>';
		echo '<p>Checks from the database what each page tells Google: its language, noindex, canonical, and the language links (its own address in the set, x-default, every listed version published and long enough, the same set on every version). Pages hidden on purpose are named, not counted as problems. Nothing is fetched from the sites; <strong>Check live</strong> fetches that one page as a visitor sees it.</p>';
		echo '<p><strong>' . count( $ids ) . '</strong> page(s) checked, <strong style="color:' . ( $bad ? '#b32d2e' : '#008a20' ) . '">' . $bad . '</strong> with problems. '
			. ( $all ? '<a href="' . esc_url( admin_url( 'admin.php?page=lmgt-check' ) ) . '">Show only problems</a>' : '<a href="' . esc_url( admin_url( 'admin.php?page=lmgt-check&all=1' ) ) . '">Show all pages</a>' ) . '</p>';
		if ( LMGT_Bridge::is_source() ) self::compare_sites();
		echo $rows === '' ? '<p style="color:#008a20">No problems.</p>' : '<table class="widefat striped"><thead><tr><th>Page</th><th>Result</th><th></th></tr></thead><tbody>' . $rows . '</tbody></table>';
		echo '</div>';
		$nonce = wp_create_nonce( 'lmgt_check_live' );
		echo "<script>document.querySelectorAll('.lmgt-live').forEach(function(b){b.addEventListener('click',function(){var o=b.nextElementSibling;b.disabled=true;o.textContent='…';"
			. "var f=new FormData();f.append('action','lmgt_check_live');f.append('id',b.dataset.id);f.append('_ajax_nonce','" . esc_js( $nonce ) . "');"
			. "fetch(ajaxurl,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){var d=r.data||{};o.style.color=r.success&&d.ok?'#008a20':'#b32d2e';o.textContent=r.success?(d.ok?'Live: OK':'Live: '+d.problems.join(' · ')):String(r.data);b.disabled=false})})});</script>";
	}

	/** .dk: one call to .travel; each original's set must be the same on both sites. */
	private static function compare_sites() {
		if ( empty( $_GET['compare'] ) ) {
			echo '<p><a class="button" href="' . esc_url( admin_url( 'admin.php?page=lmgt-check&compare=1' ) ) . '">Compare the sets with traveltalk.travel</a> <span class="description">One call to traveltalk.travel.</span></p>';
			return;
		}
		$theirs = LMGT_Bridge::call( 'GET', '/sets', array(), false );
		if ( is_wp_error( $theirs ) ) {
			echo '<p style="color:#b32d2e">traveltalk.travel could not be asked: ' . esc_html( $theirs->get_error_message() ) . '</p>';
			return;
		}
		$diff = array();
		foreach ( $theirs as $sid => $langs ) {
			$ours = md5( maybe_serialize( get_post_meta( (int) $sid, '_lmgt_set', true ) ) );
			foreach ( (array) $langs as $code => $m ) {
				if ( ! isset( $m['set'] ) || ! in_array( $m['status'], array( 'publish' ), true ) ) continue;
				if ( $m['set'] !== $ours ) $diff[] = '#' . (int) $sid . ' ' . $code . ' (' . $m['url'] . ')';
			}
		}
		echo $diff ? '<p style="color:#b32d2e"><strong>Different set on traveltalk.travel</strong> for: ' . esc_html( implode( ', ', $diff ) ) . '. "Send the set again" on the original, or Translator → Bridge → Reconcile.</p>' : '<p style="color:#008a20">Every published translation on traveltalk.travel stores the same set as its original here.</p>';
	}

	public static function handle_resend() {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		check_admin_referer( 'lmgt_resend_' . $id );
		if ( ! current_user_can( 'edit_others_posts' ) || ! LMGT_Bridge::is_source() ) wp_die( 'Not allowed.' );
		LMGT_Bridge::refresh_set( $id );
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( 'Set recomputed and sent for ' . get_permalink( $id ) . '.' ), admin_url( 'admin.php?page=lmgt-check' ) ) );
		exit;
	}

	// ---- Check live: one page, chosen by a person -----------------------------

	public static function ajax_live() {
		check_ajax_referer( 'lmgt_check_live' );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_send_json_error( 'Not allowed.' );
		wp_send_json_success( self::live( isset( $_POST['id'] ) ? (int) $_POST['id'] : 0 ) );
	}

	/** Fetch the page once and compare it with what the database says it should print. */
	public static function live( $id ) {
		$url  = get_permalink( $id );
		$p    = array();
		$lang = get_post_meta( $id, '_lmgt_lang', true );
		$lang = LMGT_Langs::get( $lang ) ? $lang : LMGT_Langs::source();
		$r    = wp_remote_get( $url, array( 'timeout' => 30, 'redirection' => 0, 'headers' => array( 'User-Agent' => 'LMG-Translator-Check/2.2' ) ) );
		if ( is_wp_error( $r ) ) return array( 'ok' => false, 'problems' => array( 'could not fetch: ' . $r->get_error_message() ) );
		$code = (int) wp_remote_retrieve_response_code( $r );
		if ( $code !== 200 ) return array( 'ok' => false, 'problems' => array( 'HTTP ' . $code ) );
		$h      = wp_remote_retrieve_body( $r );
		$want_l = LMGT_Bridge::hreflang_code( $lang );
		if ( ! preg_match( '/<html[^>]*\slang="([^"]+)"/i', $h, $m ) || strtolower( substr( $m[1], 0, strlen( $want_l ) ) ) !== $want_l ) $p[] = '<html lang> is "' . ( isset( $m[1] ) ? $m[1] : 'missing' ) . '", expected "' . $want_l . '"';
		$moved  = LMGT_Bridge::is_source() ? get_post_meta( $id, '_lmgt_moved_to', true ) : '';
		$want_c = $moved ? $moved : $url;
		if ( ! preg_match( '/<link[^>]+rel=["\']canonical["\'][^>]*href=["\']([^"\']+)/i', $h, $m ) ) $p[] = 'no canonical';
		elseif ( untrailingslashit( html_entity_decode( $m[1] ) ) !== untrailingslashit( $want_c ) ) $p[] = 'canonical is ' . $m[1] . ', expected ' . $want_c;
		$noindex = (bool) preg_match( '/<meta[^>]+name=["\']robots["\'][^>]*content=["\'][^"\']*noindex/i', $h );
		$thin    = LMGT_Store::is_thin( $id );
		if ( $noindex && ! $thin ) $p[] = 'noindex';
		if ( ! $noindex && $thin ) $p[] = 'should be noindex (under the word limit)';
		$loc = LMGT_Langs::get( $lang )['locale'];
		if ( preg_match( '/<meta[^>]+property=["\']og:locale["\'][^>]*content=["\']([^"\']+)/i', $h, $m ) && $m[1] !== $loc ) $p[] = 'og:locale is "' . $m[1] . '", expected "' . $loc . '"';
		$want = array();
		$set  = self::expected( $id );
		if ( $set && ! $thin ) {
			foreach ( $set['members'] as $c => $u ) $want[ LMGT_Bridge::hreflang_code( $c ) ] = $u;
			$want['x-default'] = $set['x'];
		}
		preg_match_all( '/<link[^>]+rel=["\']alternate["\'][^>]*hreflang=["\']([^"\']+)["\'][^>]*href=["\']([^"\']+)/i', $h, $mm, PREG_SET_ORDER );
		$got = array();
		foreach ( $mm as $x ) {
			if ( isset( $got[ $x[1] ] ) ) $p[] = 'hreflang "' . $x[1] . '" printed twice';
			$got[ $x[1] ] = html_entity_decode( $x[2] );
		}
		ksort( $want );
		ksort( $got );
		if ( $got != $want ) {
			$miss  = array_diff_assoc( $want, $got );
			$extra = array_diff_assoc( $got, $want );
			if ( $miss ) $p[] = 'hreflang missing or different: ' . implode( ', ', array_keys( $miss ) );
			if ( $extra ) $p[] = 'unexpected hreflang: ' . implode( ', ', array_keys( $extra ) ) . ( strpos( implode( ' ', $extra ), '?lang=' ) !== false ? ' (?lang= – old plugin still active?)' : '' );
		}
		return array( 'ok' => ! $p, 'problems' => $p );
	}
}
