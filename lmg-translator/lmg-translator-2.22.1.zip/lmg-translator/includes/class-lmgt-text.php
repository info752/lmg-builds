<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Text handling that never calls an engine: protecting what must not be
 * translated, splitting long articles, and the two deterministic checks
 * (language, numbers) that do not trust a model's word for anything.
 */
class LMGT_Text {

	/**
	 * Block-editor comments, shortcodes and RankMath variables are swapped for
	 * empty placeholder tags before any engine sees the text, and put back after.
	 * An engine that drops, duplicates or reorders one has broken the layout, and
	 * restore() refuses the result rather than saving a page with a missing block.
	 */
	public static function protect( $html ) {
		$map = array();
		$out = preg_replace_callback(
			'/<!--.*?-->|\[\/?[a-zA-Z_][^\]\[]*\]|%[a-z_]+%/s',
			function ( $m ) use ( &$map ) {
				$i = count( $map );
				$map[ $i ] = $m[0];
				return '<lmgt-p data-i="' . $i . '"></lmgt-p>';
			},
			(string) $html
		);
		return array( $out, $map );
	}

	/**
	 * Images, video and embeds become placeholders too: an engine that rewrites
	 * HTML can drop a long <img> tag without a trace, and the page loses its
	 * pictures. Alt texts come out as separate fields so they are still translated.
	 *
	 * @return array [ html, map, alts ] with alts as [ 'alt_N' => text ]
	 */
	public static function protect_media( $html, array $map ) {
		$alts = array();
		$out  = preg_replace_callback(
			'#<(?:img|source)\b[^>]*>|<(iframe|video|audio|picture)\b.*?</\1>#is',
			function ( $m ) use ( &$map, &$alts ) {
				$i = count( $map );
				$map[ $i ] = $m[0];
				if ( preg_match( '/\balt="([^"]+)"/i', $m[0], $a ) && trim( $a[1] ) !== '' ) {
					$alts[ 'alt_' . $i ] = html_entity_decode( $a[1], ENT_QUOTES, 'UTF-8' );
				}
				return '<lmgt-p data-i="' . $i . '"></lmgt-p>';
			},
			(string) $html
		);
		return array( $out, $map, $alts );
	}

	/** Put translated alt texts back into the protected tags before restore(). */
	public static function apply_alts( array $map, array $fields ) {
		foreach ( $fields as $k => $v ) {
			if ( strpos( $k, 'alt_' ) !== 0 || ! is_string( $v ) || trim( $v ) === '' ) continue;
			$i = (int) substr( $k, 4 );
			if ( ! isset( $map[ $i ] ) ) continue;
			$map[ $i ] = preg_replace( '/\balt="[^"]*"/i', 'alt="' . esc_attr( $v ) . '"', $map[ $i ], 1 );
		}
		return $map;
	}

	/** @return string|WP_Error */
	public static function restore( $html, $map ) {
		$seen = array();
		$out  = preg_replace_callback(
			'/<lmgt-p\s+data-i="(\d+)"\s*\/?>(?:\s*<\/lmgt-p>)?/i',
			function ( $m ) use ( $map, &$seen ) {
				$i = (int) $m[1];
				$seen[] = $i;
				return isset( $map[ $i ] ) ? $map[ $i ] : '';
			},
			(string) $html
		);
		sort( $seen );
		if ( $seen !== array_keys( $map ) ) {
			return new WP_Error( 'lmgt_layout', sprintf( 'Layout markers changed during translation (%d expected, %d found). Nothing saved.', count( $map ), count( $seen ) ) );
		}
		if ( stripos( $out, 'lmgt-p' ) !== false ) {
			return new WP_Error( 'lmgt_layout', 'A layout marker was mangled during translation. Nothing saved.' );
		}
		return $out;
	}

	/** Split at block boundaries (placeholders) or blank lines, chunks under $max chars. */
	public static function chunks( $html, $max = 9000 ) {
		// Zero-width split points only, so no character is lost between chunks.
		$parts = preg_split( '/(?=<lmgt-p data-i="\d+"><\/lmgt-p>\s*<)|(?<=\n\n)/', (string) $html );
		$out   = array();
		$cur   = '';
		foreach ( $parts as $p ) {
			if ( $cur !== '' && strlen( $cur ) + strlen( $p ) > $max ) {
				$out[] = $cur;
				$cur   = '';
			}
			$cur .= $p;
		}
		if ( $cur !== '' ) $out[] = $cur;
		return $out ? $out : array( '' );
	}

	public static function plain( $html ) {
		$t = preg_replace( '/<lmgt-p[^>]*><\/lmgt-p>/', ' ', (string) $html );
		$t = wp_strip_all_tags( strip_shortcodes( $t ) );
		$t = html_entity_decode( $t, ENT_QUOTES, 'UTF-8' );
		return trim( preg_replace( '/\s+/u', ' ', $t ) );
	}

	/**
	 * Which language a text is written in, by marker words. Returns the best
	 * code and its lead over the runner-up; a short text gives a small lead and
	 * the caller treats that as "cannot tell", not as a pass.
	 */
	public static function detect( $text ) {
		$words = preg_split( '/[^\p{L}]+/u', mb_strtolower( (string) $text ), -1, PREG_SPLIT_NO_EMPTY );
		$total = count( $words );
		if ( $total < 25 ) return array( 'code' => null, 'lead' => 0, 'words' => $total );
		$freq = array_count_values( $words );
		$score = array();
		foreach ( LMGT_Langs::markers() as $code => $list ) {
			$s = 0;
			foreach ( $list as $w ) if ( isset( $freq[ $w ] ) ) $s += $freq[ $w ];
			$score[ $code ] = $s / $total;
		}
		arsort( $score );
		$codes = array_keys( $score );
		$lead  = $score[ $codes[0] ] - $score[ $codes[1] ];
		return array( 'code' => $codes[0], 'lead' => round( $lead, 4 ), 'words' => $total, 'scores' => $score );
	}

	/**
	 * Multi-digit numbers present in one text and not the other. Separators are
	 * dropped first so 1.500 (Danish) and 1,500 (English) compare equal. Single
	 * digits are left out: the house style spells those out in prose, so their
	 * absence in a translation is style, not error.
	 */
	public static function number_diff( $a, $b ) {
		$na = self::numbers( $a );
		$nb = self::numbers( $b );
		return array(
			'missing' => array_values( array_diff_key( $na, $nb ) ),
			'extra'   => array_values( array_diff_key( $nb, $na ) ),
		);
	}

	private static function numbers( $text ) {
		preg_match_all( '/\d[\d.,\x{00A0}]*\d|\d/u', (string) $text, $m );
		$out = array();
		foreach ( $m[0] as $n ) {
			$d = preg_replace( '/\D/', '', $n );
			if ( strlen( $d ) < 2 ) continue;
			$out[ $d ] = trim( $n );
		}
		return $out;
	}
}
