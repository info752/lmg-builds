<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Languages: one table, every code in one place.
 *
 * `code`     our key; also the hreflang / html lang value, except Norwegian.
 * `prefix`   the first URL segment. Norwegian is `no` in the address and in
 *            hreflang and <html lang>: the ISO 639-1 short code, which Google
 *            accepts for Norwegian. `nb` stays the internal key and the DeepL
 *            target, since DeepL has no NO. The router only claims
 *            /no/<slug>/ when a Norwegian translation with that slug exists, so
 *            /no/ itself and its child pages stay exactly as they are.
 * `deepl`    DeepL target code. EN-GB, not EN: the house style is British
 *            spelling on English sites. NB, never NO: DeepL has no NO, and the
 *            old plugin asked for it on every Norwegian run.
 */
class LMGT_Langs {

	public static function all() {
		return array(
			'da' => array( 'name' => 'Danish',    'native' => 'Dansk',    'prefix' => 'da', 'hreflang' => 'da', 'locale' => 'da_DK', 'deepl' => 'DA',    'deepl_src' => 'DA' ),
			'en' => array( 'name' => 'English',   'native' => 'English',  'prefix' => 'en', 'hreflang' => 'en', 'locale' => 'en_GB', 'deepl' => 'EN-GB', 'deepl_src' => 'EN' ),
			'de' => array( 'name' => 'German',    'native' => 'Deutsch',  'prefix' => 'de', 'hreflang' => 'de', 'locale' => 'de_DE', 'deepl' => 'DE',    'deepl_src' => 'DE' ),
			'fr' => array( 'name' => 'French',    'native' => 'Français', 'prefix' => 'fr', 'hreflang' => 'fr', 'locale' => 'fr_FR', 'deepl' => 'FR',    'deepl_src' => 'FR' ),
			'es' => array( 'name' => 'Spanish',   'native' => 'Español',  'prefix' => 'es', 'hreflang' => 'es', 'locale' => 'es_ES', 'deepl' => 'ES',    'deepl_src' => 'ES' ),
			'it' => array( 'name' => 'Italian',   'native' => 'Italiano', 'prefix' => 'it', 'hreflang' => 'it', 'locale' => 'it_IT', 'deepl' => 'IT',    'deepl_src' => 'IT' ),
			'sv' => array( 'name' => 'Swedish',   'native' => 'Svenska',  'prefix' => 'sv', 'hreflang' => 'sv', 'locale' => 'sv_SE', 'deepl' => 'SV',    'deepl_src' => 'SV' ),
			'nb' => array( 'name' => 'Norwegian', 'native' => 'Norsk',    'prefix' => 'no', 'hreflang' => 'no', 'locale' => 'nb_NO', 'deepl' => 'NB',    'deepl_src' => 'NB' ),
			'pt' => array( 'name' => 'Portuguese', 'native' => 'Português', 'prefix' => 'pt', 'hreflang' => 'pt', 'locale' => 'pt_BR', 'deepl' => 'PT-BR', 'deepl_src' => 'PT' ),
			'fi' => array( 'name' => 'Finnish',   'native' => 'Suomi',    'prefix' => 'fi', 'hreflang' => 'fi', 'locale' => 'fi_FI', 'deepl' => 'FI',    'deepl_src' => 'FI' ),
		);
	}

	public static function get( $code ) {
		$all = self::all();
		return isset( $all[ $code ] ) ? $all[ $code ] : null;
	}

	/** The site's own language — the source of every translation. From the WP locale. */
	public static function source() {
		$code = strtolower( substr( get_locale(), 0, 2 ) );
		if ( $code === 'no' || $code === 'nn' ) $code = 'nb';
		$opt = get_option( 'lmgt_source_lang', '' );
		if ( $opt && self::get( $opt ) ) $code = $opt;
		return self::get( $code ) ? $code : 'da';
	}

	/** Targets switched on in settings, never including the source. */
	public static function enabled() {
		// 2.16.0: a site outside the traveltalk pair starts with no languages (boxes and map only, G 13 Nov).
		$on  = (array) get_option( 'lmgt_languages', LMGT_Bridge::on() ? array( 'sv' ) : array() );
		$src = self::source();
		$out = array();
		foreach ( self::all() as $code => $l ) {
			// 2.11.0: Swedish, Norwegian and Finnish are made on traveltalk.dk, never on .travel.
			if ( class_exists( 'LMGT_Bridge' ) && LMGT_Bridge::is_target() && LMGT_Nordic::is( $code ) ) continue;
			if ( $code !== $src && in_array( $code, $on, true ) ) $out[] = $code;
		}
		return $out;
	}

	public static function by_prefix( $prefix ) {
		if ( LMGT_Bridge::is_target() ) {
			if ( $prefix === 'nb' ) return 'nb';
			if ( $prefix === 'no' || $prefix === 'en' ) return null;
		}
		foreach ( self::all() as $code => $l ) {
			if ( $l['prefix'] === $prefix ) return $code;
		}
		return null;
	}

	/**
	 * Words common in one language and rare in its neighbours, for the language
	 * check. Danish, Norwegian and Swedish share most of their vocabulary, so the
	 * lists lean on the spellings that tell them apart (af/av, efter/etter,
	 * meget/mye/mycket, nogle/noen/några, och/og).
	 */
	public static function markers() {
		return array(
			'da' => array( 'og', 'af', 'ikke', 'efter', 'meget', 'nogle', 'mellem', 'gennem', 'blev', 'hvad', 'også', 'være', 'kan', 'der', 'jeg', 'vores', 'selv', 'eller', 'hvor', 'måske', 'stadig', 'altid', 'både', 'nu', 'her' ),
			'nb' => array( 'og', 'av', 'ikke', 'etter', 'mye', 'noen', 'mellom', 'gjennom', 'ble', 'hva', 'også', 'være', 'kan', 'det', 'jeg', 'våre', 'selv', 'eller', 'hvor', 'kanskje', 'fortsatt', 'alltid', 'både', 'nå', 'her' ),
			'sv' => array( 'och', 'av', 'inte', 'efter', 'mycket', 'några', 'mellan', 'genom', 'blev', 'vad', 'också', 'vara', 'kan', 'det', 'jag', 'våra', 'själv', 'eller', 'var', 'kanske', 'fortfarande', 'alltid', 'både', 'nu', 'här', 'är', 'att', 'som', 'för', 'med' ),
			'fi' => array( 'ja', 'on', 'ei', 'että', 'se', 'myös', 'kun', 'tai', 'mutta', 'jos', 'voi', 'ovat', 'oli', 'kuin', 'sekä', 'vain', 'missä', 'hyvin', 'paljon', 'aina' ),
			'de' => array( 'und', 'der', 'die', 'das', 'nicht', 'ist', 'mit', 'auch', 'auf', 'für', 'eine', 'sich', 'dem', 'wird', 'oder', 'nach', 'sehr', 'noch', 'zwischen', 'durch' ),
			'en' => array( 'the', 'and', 'of', 'to', 'is', 'in', 'that', 'with', 'for', 'not', 'are', 'this', 'from', 'you', 'can', 'which', 'also', 'there', 'between', 'through' ),
			'fr' => array( 'le', 'la', 'les', 'et', 'des', 'est', 'une', 'pas', 'pour', 'dans', 'qui', 'avec', 'sur', 'aussi', 'plus', 'vous', 'mais', 'entre', 'très', 'leur' ),
			'es' => array( 'el', 'la', 'los', 'las', 'y', 'es', 'una', 'para', 'con', 'por', 'que', 'del', 'también', 'muy', 'pero', 'entre', 'como', 'más', 'sus', 'donde' ),
			'pt' => array( 'não', 'uma', 'com', 'também', 'muito', 'você', 'são', 'pelo', 'pela', 'dos', 'das', 'ao', 'mas', 'onde', 'isso', 'está', 'seu', 'sua', 'até', 'já' ),
			'it' => array( 'il', 'la', 'gli', 'e', 'di', 'che', 'una', 'per', 'con', 'non', 'anche', 'del', 'della', 'sono', 'molto', 'tra', 'come', 'più', 'dove', 'questo' ),
		);
	}
}
