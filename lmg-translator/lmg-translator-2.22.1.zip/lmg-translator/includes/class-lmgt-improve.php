<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.1.5: improve and keep (brief 4.5).
 *
 * On traveltalk.travel, an English page written for .travel (most by Mio) that
 * is linked as the English version of a .dk original keeps its address and its
 * text. One AI call compares it with the Danish original and returns:
 *   - sections the Danish original has and the English page lacks, each placed
 *     after the English heading it belongs under;
 *   - a few exact replacements, only where the English page speaks to Danish
 *     readers or contradicts the original.
 * The page itself is not touched. The result waits as a version to apply or
 * discard (_lmgt_pending, kind 'improve'); applying keeps the old text under
 * Revisions. Every original paragraph is still there by construction: sections
 * are only inserted, and a replacement may change one sentence at most.
 */
class LMGT_Improve {

	public static function boot() {
		if ( ! LMGT_Bridge::is_target() ) return;
		add_action( 'add_meta_boxes', function () {
			foreach ( LMGT_Store::types( true ) as $t ) add_meta_box( 'lmgt_improve', 'traveltalk.dk original', array( __CLASS__, 'box' ), $t, 'side', 'high' );
		} );
		add_action( 'admin_post_lmgt_improve', array( __CLASS__, 'handle' ) );
	}

	public static function box( $post ) {
		$sid = (int) get_post_meta( $post->ID, '_lmgt_remote_source', true );
		if ( ! empty( $_GET['lmgt_msg'] ) ) echo '<p><strong>' . esc_html( wp_unslash( $_GET['lmgt_msg'] ) ) . '</strong></p>';
		if ( ! $sid ) {
			echo '<p class="description">Not linked to a traveltalk.dk original. Link it from the Danish page on .dk (box "traveltalk.travel" → Link an English page by its address).</p>';
			return;
		}
		$url = get_post_meta( $post->ID, '_lmgt_remote_url', true );
		echo '<p>English version of <a href="' . esc_url( $url ) . '" target="_blank">' . esc_html( $url ) . '</a></p>';
		$p = get_post_meta( $post->ID, '_lmgt_pending', true );
		if ( is_array( $p ) && isset( $p['kind'] ) && $p['kind'] === 'improve' ) {
			$i = $p['improve'];
			echo '<div class="notice notice-info inline"><p><strong>Improved version waiting</strong> (' . esc_html( $p['at'] ) . ' UTC, ' . esc_html( $i['engine'] ) . '): '
				. (int) $i['words_before'] . ' → ' . (int) $i['words_after'] . ' words. Your text stays; this only adds.</p>';
			if ( $i['sections'] ) {
				echo '<p><strong>New sections</strong></p><ul style="list-style:disc;margin-left:16px">';
				foreach ( $i['sections'] as $s ) echo '<li><strong>' . esc_html( $s['heading'] ) . '</strong> <span class="description">(after "' . esc_html( $s['after'] ?: 'end' ) . '")</span><br>' . esc_html( $s['preview'] ) . '…</li>';
				echo '</ul>';
			}
			if ( $i['replaced'] ) {
				echo '<p><strong>Changed sentences</strong></p><ul style="list-style:disc;margin-left:16px">';
				foreach ( $i['replaced'] as $r ) echo '<li><del>' . esc_html( $r['find'] ) . '</del><br>→ ' . esc_html( $r['replace'] ) . ( $r['why'] ? ' <span class="description">(' . esc_html( $r['why'] ) . ')</span>' : '' ) . '</li>';
				echo '</ul>';
			}
			$apply = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_apply&post=' . $post->ID ), 'lmgt_apply_' . $post->ID );
			$drop  = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_discard&post=' . $post->ID ), 'lmgt_discard_' . $post->ID );
			echo '<p><a class="button button-primary" href="' . esc_url( $apply ) . '">Accept: put it in the text</a> <a class="button" href="' . esc_url( $drop ) . '">Reject: keep my text</a></p>';
			echo '<p class="description">Read it first with Preview after applying, or apply and check: the current text stays under Revisions. Save your own edits before applying.</p></div>';
			return;
		}
		// 2.9.3: also on translations Translator made. A full new version from .dk waiting comes first.
		if ( is_array( $p ) && ! empty( $p['translation'] ) ) {
			echo '<p class="description">A new version from traveltalk.dk is waiting (box "Translation"). Accept or reject it first; then you can propose improvements here.</p>';
			return;
		}
		$go = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_improve&post=' . $post->ID ), 'lmgt_improve_' . $post->ID );
		echo '<p><a class="button" href="' . esc_url( $go ) . '">Propose improvements from the Danish original</a></p>';
		echo '<p class="description">Adds what the Danish page has and this one lacks, and rewrites sentences written for Danish readers. Nothing changes until you apply it.</p>';
	}

	public static function handle() {
		$id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
		check_admin_referer( 'lmgt_improve_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		@set_time_limit( 200 );
		$r   = self::propose( $id );
		$msg = is_wp_error( $r ) ? 'No improvement proposed: ' . $r->get_error_message() : $r;
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $msg ), get_edit_post_link( $id, 'url' ) ) );
		exit;
	}

	/** @return string|WP_Error a line for the person */
	public static function propose( $id ) {
		$post = get_post( $id );
		$sid  = (int) get_post_meta( $id, '_lmgt_remote_source', true );
		if ( ! $post || ! $sid ) return new WP_Error( 'lmgt_improve', 'This page is not linked to a traveltalk.dk original.' );
		$wait = get_post_meta( $id, '_lmgt_pending', true );
		if ( is_array( $wait ) && ! empty( $wait['translation'] ) && ( ! isset( $wait['kind'] ) || $wait['kind'] !== 'improve' ) ) return new WP_Error( 'lmgt_improve', 'A new version from traveltalk.dk is waiting. Accept or reject it first.' );
		if ( ! LMGT_Engines::ai_available() ) return new WP_Error( 'lmgt_improve', 'No ' . LMGT_Engines::ai_name() . ' key on this site.' );
		$orig = LMGT_Bridge::call( 'GET', '/original', array( 'id' => $sid ), false );
		if ( is_wp_error( $orig ) ) return $orig;

		$html  = $post->post_content;
		$heads = array();
		if ( preg_match_all( '#<h[1-6][^>]*>(.*?)</h[1-6]>#is', $html, $m ) ) {
			foreach ( $m[1] as $h ) $heads[] = trim( html_entity_decode( wp_strip_all_tags( $h ), ENT_QUOTES, 'UTF-8' ) );
		}
		LMGT_Meter::reset();
		$res = LMGT_Engines::ai_json( LMGT_Engines::prompt_improve(
			$orig['title'], mb_substr( self::outline( $orig['content'] ), 0, 45000 ),
			$post->post_title, mb_substr( self::outline( $html ), 0, 35000 ), $heads
		), LMGT_Engines::schema_improve() );
		$meter = LMGT_Meter::take();
		if ( is_wp_error( $res ) ) return $res;

		// Sentences first, on the page's own text, each only where it occurs exactly once with its tags unchanged.
		$replaced = array();
		foreach ( (array) $res['replace'] as $r ) {
			$find = (string) $r['find'];
			$rep  = (string) $r['replace'];
			if ( mb_strlen( $find ) > 400 || mb_strlen( $rep ) > 500 ) continue;
			$at = LMGT_Admin::locate( $html, $find );
			if ( ! $at ) continue;
			preg_match_all( '/<[^>]+>/', substr( $html, $at[0], $at[1] ), $a );
			preg_match_all( '/<[^>]+>/', $rep, $b );
			if ( $a[0] !== $b[0] ) continue;
			$html       = substr_replace( $html, $rep, $at[0], $at[1] );
			$replaced[] = array( 'find' => wp_strip_all_tags( $find ), 'replace' => wp_strip_all_tags( $rep ), 'why' => sanitize_text_field( $r['why'] ) );
		}
		$blocks   = strpos( $html, '<!-- wp:' ) !== false;
		$sections = array();
		foreach ( (array) $res['sections'] as $s ) {
			if ( empty( $s['heading'] ) || empty( $s['html'] ) ) continue;
			$after = LMGT_Structure::match_heading( (string) $s['after'], $heads );
			$s     = array(
				'heading' => sanitize_text_field( $s['heading'] ),
				'html'    => wp_kses( (string) $s['html'], array( 'p' => array(), 'ul' => array(), 'li' => array(), 'strong' => array(), 'em' => array() ) ),
			);
			$html = LMGT_Admin::place( $html, $after, function ( $level ) use ( $s, $blocks ) { return LMGT_Admin::section_markup( $s, $blocks, $level ); }, $s );
			$sections[] = array( 'heading' => $s['heading'], 'after' => $after, 'preview' => mb_substr( wp_strip_all_tags( $s['html'] ), 0, 160 ) );
		}
		if ( ! $sections && ! $replaced ) return 'Nothing to add: the English page already covers what the Danish original says.';

		$before = LMGT_Store::words( $post );
		$after  = str_word_count( wp_strip_all_tags( $html ) );
		if ( $after < $before ) return new WP_Error( 'lmgt_improve', 'The proposal was shorter than the page. Nothing kept.' );
		update_post_meta( $id, '_lmgt_pending', wp_slash( array(
			'translation'     => array( 'title' => $post->post_title, 'content' => $html, 'excerpt' => $post->post_excerpt, 'seo_title' => '', 'seo_desc' => '' ),
			'report'          => array( 'engine' => LMGT_Engines::ai_label(), 'improved_from' => $orig['url'], 'meter' => $meter ),
			'source_modified' => $orig['modified'],
			'at'              => current_time( 'mysql', true ),
			'kind'            => 'improve',
			'improve'         => array( 'sections' => $sections, 'replaced' => $replaced, 'words_before' => $before, 'words_after' => $after, 'engine' => LMGT_Engines::ai_label(), 'cost' => LMGT_Meter::cost_label( $meter ) ),
		) ) );
		return sprintf( '%d new section(s) and %d changed sentence(s) proposed (%s). Read them in the box "traveltalk.dk original", then apply or discard.', count( $sections ), count( $replaced ), LMGT_Meter::cost_label( $meter ) );
	}

	/** Text with its headings marked, so the engine sees the structure. */
	private static function outline( $html ) {
		$html = preg_replace_callback( '#<h([1-6])[^>]*>(.*?)</h\1>#is', function ( $m ) { return "\n\n" . str_repeat( '#', (int) $m[1] ) . ' ' . wp_strip_all_tags( $m[2] ) . "\n"; }, $html );
		$html = preg_replace( '#</(p|li|ul|ol|div|table|tr)>#i', "$0\n", $html );
		return trim( preg_replace( "/\n{3,}/", "\n\n", html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES, 'UTF-8' ) ) );
	}
}
