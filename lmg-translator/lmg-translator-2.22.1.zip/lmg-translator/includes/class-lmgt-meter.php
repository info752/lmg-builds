<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.1.2: the pilot's two numbers (brief 5.1).
 *
 * Engine cost: every DeepL, Gemini and Claude call adds what it was billed for
 * (DeepL characters, tokens in and out per model) to a counter for the current
 * request. The queue folds each step's counter into the job, and the job's total
 * travels with the draft in its report (report['meter']). Counts are stored, not
 * money: the price table on Translator → Pilot turns them into cost when shown,
 * so a wrong price can be corrected afterwards.
 *
 * Review time: on the edit screen and the preview of an unpublished translation,
 * seconds count while the window has focus and the reviewer has moved, typed or
 * scrolled in the last three minutes. They stop at the first publication.
 *
 * Meta on a translation:
 *   _lmgt_report['meter']  pipeline counts: [deepl => chars, ai => [model => [in, out, calls]]]
 *   _lmgt_meter_extra      calls made from the edit screen (fix, SEO, gap sections), same shape
 *   _lmgt_review_secs      active review seconds before first publication
 *   _lmgt_review_users     logins that reviewed
 *   _lmgt_review_first     first review second (Unix time)
 *   _lmgt_review_done      first publication (Unix time); counting stops
 *   _lmgt_review_flags     open flags at that moment
 */
class LMGT_Meter {

	const IDLE = 180;

	private static $step = array();

	public static function boot() {
		add_action( 'wp_ajax_lmgt_review_time', array( __CLASS__, 'ajax_review_time' ) );
		add_action( 'transition_post_status', array( __CLASS__, 'on_publish' ), 20, 3 );
		add_action( 'admin_footer-post.php', function () { global $post; if ( $post ) self::tracker( $post->ID ); } );
		add_action( 'wp_footer', function () { if ( is_singular( LMGT_CPT ) ) self::tracker( get_queried_object_id() ); } );
		add_action( 'admin_menu', function () {
			add_submenu_page( 'lmgt', 'Pilot', 'Pilot', 'edit_others_posts', 'lmgt-pilot', array( __CLASS__, 'page' ) );
		}, 30 );
		add_action( 'admin_post_lmgt_pilot_csv', array( __CLASS__, 'csv' ) );
		add_action( 'admin_post_lmgt_prices', array( __CLASS__, 'save_prices' ) );
	}

	// ---- Counting ------------------------------------------------------------

	public static function deepl( $chars ) {
		self::$step = self::sum( self::$step, array( 'deepl' => (int) $chars ) );
	}

	public static function ai( $model, $in, $out ) {
		self::$step = self::sum( self::$step, array( 'ai' => array( (string) $model => array( 'in' => (int) $in, 'out' => (int) $out, 'calls' => 1 ) ) ) );
	}

	public static function reset() { self::$step = array(); }

	public static function peek() { return self::$step; }

	public static function take() {
		$m = self::$step;
		self::$step = array();
		return $m;
	}

	public static function sum( $a, $b ) {
		$a = is_array( $a ) ? $a : array();
		$b = is_array( $b ) ? $b : array();
		if ( ! empty( $b['deepl'] ) ) $a['deepl'] = ( isset( $a['deepl'] ) ? (int) $a['deepl'] : 0 ) + (int) $b['deepl'];
		foreach ( isset( $b['ai'] ) ? (array) $b['ai'] : array() as $model => $u ) {
			foreach ( array( 'in', 'out', 'calls' ) as $k ) {
				$a['ai'][ $model ][ $k ] = ( isset( $a['ai'][ $model ][ $k ] ) ? (int) $a['ai'][ $model ][ $k ] : 0 ) + ( isset( $u[ $k ] ) ? (int) $u[ $k ] : 0 );
			}
		}
		return $a;
	}

	/** Spend of this request on a translation's edit screen (fix, SEO, gap sections). */
	public static function charge( $id ) {
		$m = self::take();
		if ( ! $m || get_post_type( $id ) !== LMGT_CPT ) return;
		update_post_meta( $id, '_lmgt_meter_extra', self::sum( get_post_meta( $id, '_lmgt_meter_extra', true ), $m ) );
	}

	/** Everything spent on one translation. */
	public static function of( $id ) {
		$r = get_post_meta( $id, '_lmgt_report', true );
		return self::sum( is_array( $r ) && isset( $r['meter'] ) ? $r['meter'] : array(), get_post_meta( $id, '_lmgt_meter_extra', true ) );
	}

	// ---- Prices --------------------------------------------------------------

	/** USD per million: DeepL characters; model input and output tokens. */
	const PRICES = "deepl 23\nclaude-opus-5-5 4 20\nclaude-opus-5 5 25\nclaude-sonnet-5-5 2 10\nclaude-haiku-5-5 0.10 0.50\nclaude-fable-5-1 10 50\ngemini-2.5-flash 0.30 2.50";

	public static function prices() {
		$out = array();
		foreach ( preg_split( '/\R/', (string) get_option( 'lmgt_prices', self::PRICES ) ) as $line ) {
			$p = preg_split( '/\s+/', trim( $line ) );
			if ( count( $p ) >= 2 && is_numeric( $p[1] ) ) $out[ strtolower( $p[0] ) ] = array( (float) $p[1], isset( $p[2] ) && is_numeric( $p[2] ) ? (float) $p[2] : 0.0 );
		}
		return $out;
	}

	/** Exact model name first, then the longest listed name it starts with. */
	private static function price_of( $model, array $prices ) {
		$model = strtolower( $model );
		if ( isset( $prices[ $model ] ) ) return $prices[ $model ];
		$best = null;
		$len  = 0;
		foreach ( $prices as $k => $v ) {
			if ( $k !== 'deepl' && strpos( $model, $k ) === 0 && strlen( $k ) > $len ) { $best = $v; $len = strlen( $k ); }
		}
		return $best;
	}

	/** @return array{usd:float,unpriced:string[]} */
	public static function cost( $m ) {
		$prices = self::prices();
		$usd    = 0.0;
		$miss   = array();
		if ( ! empty( $m['deepl'] ) ) {
			if ( isset( $prices['deepl'] ) ) $usd += $m['deepl'] / 1e6 * $prices['deepl'][0];
			else $miss[] = 'deepl';
		}
		foreach ( isset( $m['ai'] ) ? (array) $m['ai'] : array() as $model => $u ) {
			$p = self::price_of( $model, $prices );
			if ( ! $p ) { $miss[] = $model; continue; }
			$usd += $u['in'] / 1e6 * $p[0] + $u['out'] / 1e6 * $p[1];
		}
		return array( 'usd' => $usd, 'unpriced' => $miss );
	}

	public static function cost_label( $m ) {
		if ( ! $m ) return '';
		$c = self::cost( $m );
		return '$' . number_format( $c['usd'], 3 ) . ( $c['unpriced'] ? ' + unpriced: ' . implode( ', ', $c['unpriced'] ) : '' );
	}

	public static function tokens( $m, $k ) {
		$n = 0;
		foreach ( isset( $m['ai'] ) ? (array) $m['ai'] : array() as $u ) $n += (int) $u[ $k ];
		return $n;
	}

	public static function save_prices() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Not allowed.' );
		check_admin_referer( 'lmgt_prices' );
		$v = sanitize_textarea_field( wp_unslash( isset( $_POST['lmgt_prices'] ) ? $_POST['lmgt_prices'] : '' ) );
		trim( $v ) === '' ? delete_option( 'lmgt_prices' ) : update_option( 'lmgt_prices', $v, false );
		wp_safe_redirect( admin_url( 'admin.php?page=lmgt-pilot' ) );
		exit;
	}

	// ---- Review time ---------------------------------------------------------

	private static function counting( $id ) {
		$s = get_post_status( $id );
		return get_post_type( $id ) === LMGT_CPT && $s && ! in_array( $s, array( 'publish', 'trash' ), true ) && ! get_post_meta( $id, '_lmgt_review_done', true );
	}

	/** Counts active seconds in 5-second ticks and sends them every 30 seconds and when the page is left. */
	public static function tracker( $id ) {
		$id = (int) $id;
		if ( ! $id || ! self::counting( $id ) || ! current_user_can( 'edit_post', $id ) ) return;
		?>
		<script>
		(function(){
			var id=<?php echo $id; ?>,n='<?php echo esc_js( wp_create_nonce( 'lmgt_rt_' . $id ) ); ?>',u='<?php echo esc_js( admin_url( 'admin-ajax.php' ) ); ?>',idle=<?php echo self::IDLE * 1000; ?>,secs=0,last=Date.now();
			function seen(){last=Date.now();}
			function watch(d){if(!d||d.lmgtWatched)return;d.lmgtWatched=1;['mousemove','mousedown','keydown','wheel','scroll','touchstart','input'].forEach(function(e){d.addEventListener(e,seen,{passive:true,capture:true});});}
			watch(document);
			setInterval(function(){
				// The block editor writes inside an iframe; its events do not reach this page.
				Array.prototype.forEach.call(document.querySelectorAll('iframe'),function(f){try{watch(f.contentDocument);}catch(e){}});
				if(document.visibilityState==='visible'&&document.hasFocus()&&Date.now()-last<idle)secs+=5;
			},5000);
			function send(){
				if(secs<5)return;
				var f=new FormData();f.append('action','lmgt_review_time');f.append('post',id);f.append('secs',secs);f.append('_ajax_nonce',n);secs=0;
				if(!(navigator.sendBeacon&&navigator.sendBeacon(u,f)))fetch(u,{method:'POST',body:f,credentials:'same-origin',keepalive:true});
			}
			setInterval(send,30000);
			document.addEventListener('visibilitychange',function(){if(document.visibilityState==='hidden')send();});
			window.addEventListener('pagehide',send);
		})();
		</script>
		<?php
	}

	public static function ajax_review_time() {
		$id = isset( $_POST['post'] ) ? (int) $_POST['post'] : 0;
		check_ajax_referer( 'lmgt_rt_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_send_json_error();
		if ( ! self::counting( $id ) ) wp_send_json_success( array( 'counted' => 0 ) );
		// One send carries at most 30 s plus what was left when the page closed.
		$secs = max( 0, min( 120, (int) $_POST['secs'] ) );
		update_post_meta( $id, '_lmgt_review_secs', (int) get_post_meta( $id, '_lmgt_review_secs', true ) + $secs );
		if ( ! get_post_meta( $id, '_lmgt_review_first', true ) ) update_post_meta( $id, '_lmgt_review_first', time() );
		$users = (array) get_post_meta( $id, '_lmgt_review_users', true );
		$login = wp_get_current_user()->user_login;
		if ( ! in_array( $login, $users, true ) ) update_post_meta( $id, '_lmgt_review_users', array_values( array_filter( array_merge( $users, array( $login ) ) ) ) );
		wp_send_json_success( array( 'counted' => $secs ) );
	}

	/** The first publication ends the review: the clock stops and the flags at that moment are kept. */
	public static function on_publish( $new, $old, $post ) {
		if ( $new !== 'publish' || $old === 'publish' || $post->post_type !== LMGT_CPT || get_post_meta( $post->ID, '_lmgt_review_done', true ) ) return;
		update_post_meta( $post->ID, '_lmgt_review_done', time() );
		update_post_meta( $post->ID, '_lmgt_review_flags', LMGT_Store::open_issues( $post->ID ) );
	}

	// ---- Pilot page ----------------------------------------------------------

	/** Translations on this site that carry pipeline counts or review time, grouped by original. */
	private static function rows() {
		$ids = get_posts( array(
			'post_type'      => LMGT_CPT,
			'post_status'    => array( 'publish', 'draft', 'pending', 'future', 'private' ),
			'posts_per_page' => 500,
			'fields'         => 'ids',
			'orderby'        => 'date',
			'order'          => 'DESC',
			'lmgt_all'       => true,
			'no_found_rows'  => true,
		) );
		$groups = array();
		foreach ( $ids as $id ) {
			$m    = self::of( $id );
			$secs = (int) get_post_meta( $id, '_lmgt_review_secs', true );
			if ( ! $m && ! $secs ) continue;
			$remote = (int) get_post_meta( $id, '_lmgt_remote_source', true );
			$key    = $remote ? 'r' . $remote : 'l' . (int) get_post_meta( $id, '_lmgt_source', true );
			if ( ! isset( $groups[ $key ] ) ) {
				$url = $remote ? (string) get_post_meta( $id, '_lmgt_remote_url', true ) : get_permalink( (int) get_post_meta( $id, '_lmgt_source', true ) );
				$groups[ $key ] = array( 'original' => $url, 'rows' => array() );
			}
			$r    = get_post_meta( $id, '_lmgt_report', true );
			$done = (int) get_post_meta( $id, '_lmgt_review_done', true );
			$groups[ $key ]['rows'][] = array(
				'id'       => $id,
				'lang'     => get_post_meta( $id, '_lmgt_lang', true ),
				'status'   => get_post_status( $id ),
				'words'    => LMGT_Store::words( get_post( $id ) ),
				'flags'    => $done ? (int) get_post_meta( $id, '_lmgt_review_flags', true ) : LMGT_Store::open_issues( $id ),
				'engine'   => is_array( $r ) && isset( $r['engine'] ) ? $r['engine'] : '',
				'meter'    => $m,
				'secs'     => $secs,
				'done'     => $done,
				'users'    => implode( ', ', (array) get_post_meta( $id, '_lmgt_review_users', true ) ),
			);
		}
		return $groups;
	}

	private static function minutes( $secs ) {
		return number_format( $secs / 60, 1 );
	}

	public static function page() {
		$groups = self::rows();
		echo '<div class="wrap"><h1>Pilot: review time and engine cost</h1>';
		echo '<p>Engine cost is counted for drafts made by 2.1.2 or later. Review time counts on the edit screen and the preview of an unpublished translation while the window has focus and someone moved, typed or scrolled in the last ' . (int) ( self::IDLE / 60 ) . ' minutes. It stops at the first publication.</p>';
		if ( LMGT_Bridge::is_source() ) echo '<p><strong>New translations live on ' . esc_html( LMGT_Bridge::peer() ) . ':</strong> see Translator → Pilot there for the full table. Cost per job is also in the Queue here.</p>';

		$clean = $flagged = $articles = array();
		foreach ( $groups as $g ) {
			$sum = 0.0;
			foreach ( $g['rows'] as $row ) {
				$sum += self::cost( $row['meter'] )['usd'];
				if ( $row['done'] ) {
					if ( $row['flags'] ) $flagged[] = $row['secs'];
					else $clean[] = $row['secs'];
				}
			}
			if ( $sum > 0 ) $articles[] = $sum;
		}
		$avg = function ( $a ) { return $a ? array_sum( $a ) / count( $a ) : 0; };
		echo '<table class="widefat" style="max-width:720px"><tbody>';
		printf( '<tr><th>Review minutes per draft, clean (published)</th><td>%s min · %d draft(s)</td></tr>', esc_html( self::minutes( $avg( $clean ) ) ), count( $clean ) );
		printf( '<tr><th>Review minutes per draft, flagged (published)</th><td>%s min · %d draft(s)</td></tr>', esc_html( self::minutes( $avg( $flagged ) ) ), count( $flagged ) );
		printf( '<tr><th>Engine cost per article (all its languages)</th><td>$%s · %d article(s)</td></tr>', esc_html( number_format( $avg( $articles ), 3 ) ), count( $articles ) );
		echo '</tbody></table>';

		echo '<p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_pilot_csv' ), 'lmgt_pilot_csv' ) ) . '">Download CSV</a></p>';
		echo '<table class="widefat striped"><thead><tr><th>Language</th><th>Status</th><th>Words</th><th>Flags</th><th>Engine</th><th>DeepL chars</th><th>AI tokens in / out</th><th>Cost</th><th>Review min</th><th>Reviewer</th></tr></thead><tbody>';
		if ( ! $groups ) echo '<tr><td colspan="10">Nothing measured yet.</td></tr>';
		foreach ( $groups as $g ) {
			$sum  = array();
			$secs = 0;
			echo '<tr><td colspan="10"><strong><a href="' . esc_url( $g['original'] ) . '" target="_blank">' . esc_html( $g['original'] ) . '</a></strong></td></tr>';
			foreach ( $g['rows'] as $row ) {
				$l    = LMGT_Langs::get( $row['lang'] );
				$sum  = self::sum( $sum, $row['meter'] );
				$secs += $row['secs'];
				printf( '<tr><td><a href="%s">%s</a></td><td>%s</td><td>%d</td><td>%d</td><td>%s</td><td>%s</td><td>%s / %s</td><td>%s</td><td>%s%s</td><td>%s</td></tr>',
					esc_url( get_edit_post_link( $row['id'] ) ), esc_html( $l ? $l['name'] : $row['lang'] ), esc_html( $row['status'] ), (int) $row['words'], (int) $row['flags'],
					esc_html( $row['engine'] ), esc_html( number_format( isset( $row['meter']['deepl'] ) ? $row['meter']['deepl'] : 0 ) ),
					esc_html( number_format( self::tokens( $row['meter'], 'in' ) ) ), esc_html( number_format( self::tokens( $row['meter'], 'out' ) ) ),
					esc_html( self::cost_label( $row['meter'] ) ), esc_html( self::minutes( $row['secs'] ) ), $row['done'] ? '' : ' <span class="description">(open)</span>', esc_html( $row['users'] ) );
			}
			printf( '<tr><td colspan="7" style="text-align:right"><em>Article total</em></td><td><strong>%s</strong></td><td><strong>%s</strong></td><td></td></tr>', esc_html( self::cost_label( $sum ) ), esc_html( self::minutes( $secs ) ) );
		}
		echo '</tbody></table>';

		if ( current_user_can( 'manage_options' ) ) {
			echo '<h2>Prices</h2><p class="description">USD per million. <code>deepl</code>: characters, at the paid API rate (DeepL API Pro is €20 per million, about $23; DeepL Free costs nothing until its 500,000 a month run out). A model line: input, then output tokens. A model is matched by its full name, else by the longest name here it starts with. Cost is worked out when shown, so a change applies to past drafts too. Empty restores the defaults.</p>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'lmgt_prices' );
			echo '<input type="hidden" name="action" value="lmgt_prices"><textarea name="lmgt_prices" rows="8" cols="50" style="font-family:monospace">' . esc_textarea( get_option( 'lmgt_prices', self::PRICES ) ) . '</textarea>';
			submit_button( 'Save prices' );
			echo '</form>';
		}
		echo '</div>';
	}

	public static function csv() {
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_die( 'Not allowed.' );
		check_admin_referer( 'lmgt_pilot_csv' );
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="lmgt-pilot-' . gmdate( 'Y-m-d' ) . '.csv"' );
		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array( 'original', 'translation_id', 'lang', 'status', 'words', 'flags', 'engine', 'deepl_chars', 'ai_tokens_in', 'ai_tokens_out', 'ai_calls', 'cost_usd', 'unpriced', 'review_minutes', 'review_finished_utc', 'reviewers' ) );
		foreach ( self::rows() as $g ) {
			foreach ( $g['rows'] as $row ) {
				$c = self::cost( $row['meter'] );
				fputcsv( $out, array(
					$g['original'], $row['id'], $row['lang'], $row['status'], $row['words'], $row['flags'], $row['engine'],
					isset( $row['meter']['deepl'] ) ? $row['meter']['deepl'] : 0, self::tokens( $row['meter'], 'in' ), self::tokens( $row['meter'], 'out' ), self::tokens( $row['meter'], 'calls' ),
					number_format( $c['usd'], 4, '.', '' ), implode( ' ', $c['unpriced'] ), self::minutes( $row['secs'] ), $row['done'] ? gmdate( 'Y-m-d H:i', $row['done'] ) : '', $row['users'],
				) );
			}
		}
		fclose( $out );
		exit;
	}
}
