<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.11.0: the Traveltalk Nordic model (G, 10 Nov 2026).
 *
 * Swedish, Norwegian and Finnish live on traveltalk.dk; traveltalk.travel is
 * the English site. Replaces the 28 Oct rule that every translation leaves .dk.
 *
 *   .dk (source): Nordic translations are saved here, never sent to .travel;
 *     copies made earlier are taken back once (their 301 to .travel ends and
 *     the .dk page answers again). Its hreflang set lists the .dk address.
 *   .travel (target): a Nordic copy whose set now points to .dk answers 301
 *     there, leaves the sitemap, and its language front page goes to .dk's.
 *     A Nordic page with no .dk copy is left as it is.
 *
 * 2.12.0: Catch-up → "Fetch back" copies a Nordic page that exists only on
 * .travel here, published; .travel then sends its readers here.
 *
 * Meta, .dk: _lmgt_moved_back = the .travel address a translation used to send readers to;
 *            _lmgt_fetched_from = the .travel page a translation was fetched back from.
 */
class LMGT_Nordic {

	const LANGS = array( 'sv', 'nb', 'fi' );

	public static function is( $code ) {
		return in_array( (string) $code, self::LANGS, true );
	}

	public static function boot() {
		if ( LMGT_Bridge::is_source() ) {
			add_action( 'lmgt_catchup_top', array( __CLASS__, 'fetch_section' ), 4 );
			add_action( 'wp_ajax_lmgt_fetch_back', array( __CLASS__, 'ajax_fetch' ) );
			return;
		}
		if ( ! LMGT_Bridge::is_target() ) return;
		add_action( 'rest_api_init', function () {
			register_rest_route( LMGT_Bridge::NS, '/page', array( 'methods' => 'GET', 'callback' => array( 'LMGT_Nordic', 'rest_page' ), 'permission_callback' => function () { return current_user_can( 'edit_others_posts' ); } ) );
		} );
		add_action( 'template_redirect', array( __CLASS__, 'to_dk' ), 0 );
		add_filter( 'rank_math/sitemap/entry', function ( $url, $type, $object ) {
			return $object instanceof WP_Post && LMGT_Nordic::dk_url( $object->ID ) ? false : $url;
		}, 20, 3 );
	}

	/** Target: the .dk address of a Nordic copy, when .dk's set says the page is there; '' otherwise. */
	public static function dk_url( $id ) {
		if ( get_post_type( $id ) !== LMGT_CPT || ! get_post_meta( $id, '_lmgt_remote_source', true ) ) return '';
		$lang = get_post_meta( $id, '_lmgt_lang', true );
		if ( ! self::is( $lang ) ) return '';
		$set = get_post_meta( $id, '_lmgt_set', true );
		$to  = is_array( $set ) && ! empty( $set['members'][ $lang ] ) ? $set['members'][ $lang ] : '';
		$dk  = LMGT_Bridge::peer();
		// The peer may be stored with or without www (2.11.1).
		$host = function ( $u ) { return preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( $u, PHP_URL_HOST ) ) ); };
		return $to && $dk && $host( $to ) === $host( $dk ) ? $to : '';
	}

	public static function to_dk() {
		if ( is_preview() ) return;
		if ( is_singular( LMGT_CPT ) ) {
			$to = self::dk_url( get_queried_object_id() );
			if ( $to ) {
				wp_redirect( $to, 301, 'LMG Translator' );
				exit;
			}
			return;
		}
		$lang = get_query_var( 'lmgt_lang_home' );
		if ( $lang && self::is( $lang ) && LMGT_Bridge::peer() ) {
			$l = LMGT_Langs::get( $lang );
			wp_redirect( trailingslashit( LMGT_Bridge::peer() ) . $l['prefix'] . '/', 301, 'LMG Translator' );
			exit;
		}
	}

	// ---- 2.12.0: fetch back what exists only on .travel ------------------------------

	/** Target: one bridge translation as stored, for .dk to take back. */
	public static function rest_page( WP_REST_Request $req ) {
		$p = get_post( (int) $req->get_param( 'id' ) );
		if ( ! $p || $p->post_type !== LMGT_CPT || ! get_post_meta( $p->ID, '_lmgt_remote_source', true ) ) return new WP_Error( 'lmgt_bad', 'No bridge translation with that ID.', array( 'status' => 404 ) );
		return array(
			'id'        => $p->ID,
			'lang'      => (string) get_post_meta( $p->ID, '_lmgt_lang', true ),
			'source_id' => (int) get_post_meta( $p->ID, '_lmgt_remote_source', true ),
			'status'    => $p->post_status,
			'slug'      => $p->post_name,
			'title'     => $p->post_title,
			'content'   => $p->post_content,
			'excerpt'   => $p->post_excerpt,
			'seo_title' => (string) get_post_meta( $p->ID, 'rank_math_title', true ),
			'seo_desc'  => (string) get_post_meta( $p->ID, 'rank_math_description', true ),
			'keyword'   => (string) get_post_meta( $p->ID, 'rank_math_focus_keyword', true ),
			'url'       => get_permalink( $p ),
		);
	}

	/** Source: Nordic versions published only on .travel: [[sid, lang, remote id, url]]. */
	public static function fetch_todo() {
		global $wpdb;
		$out = array();
		foreach ( $wpdb->get_results( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_lmgt_remote'" ) as $row ) {
			$sid = (int) $row->post_id;
			if ( get_post_status( $sid ) !== 'publish' ) continue;
			$local = LMGT_Store::of( $sid, array( 'publish' ) );
			foreach ( (array) maybe_unserialize( $row->meta_value ) as $lang => $r ) {
				if ( ! self::is( $lang ) || isset( $local[ $lang ] ) || ! is_array( $r ) || empty( $r['id'] ) || empty( $r['url'] ) ) continue;
				if ( ! isset( $r['status'] ) || ! in_array( $r['status'], array( 'publish', 'thin' ), true ) ) continue;
				$out[] = array( 'sid' => $sid, 'lang' => (string) $lang, 'id' => (int) $r['id'], 'url' => (string) $r['url'] );
			}
		}
		return $out;
	}

	public static function fetch_section() {
		$todo = self::fetch_todo();
		echo '<h2>Swedish, Norwegian and Finnish still only on traveltalk.travel</h2>';
		if ( ! $todo ) {
			echo '<p>None. Every Swedish, Norwegian and Finnish translation lives here on traveltalk.dk.</p>';
			return;
		}
		echo '<p>These were made for traveltalk.travel and have no copy here. "Fetch back" copies each one here as it is (text, title, SEO fields), published, at the same address under /sv/, /no/ or /fi/. Then its traveltalk.travel address sends readers and Google here for good (301). Nothing is translated again.</p><ul>';
		foreach ( $todo as $it ) {
			echo '<li>' . esc_html( get_the_title( $it['sid'] ) ) . ' – ' . esc_html( LMGT_Langs::get( $it['lang'] )['name'] ) . ': <a href="' . esc_url( $it['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $it['url'] ) . '</a></li>';
		}
		echo '</ul><p><button class="button button-primary" id="lmgt-fb">Fetch back ' . count( $todo ) . '</button> <span id="lmgt-fb-st"></span></p><pre id="lmgt-fb-log" style="max-height:300px;overflow:auto;background:#fff;padding:8px"></pre>';
		$nonce = wp_create_nonce( 'lmgt_fetch_back' );
		echo "<script>(function(){var b=document.getElementById('lmgt-fb'),s=document.getElementById('lmgt-fb-st'),l=document.getElementById('lmgt-fb-log');"
			. "function go(i){var d=new FormData();d.append('action','lmgt_fetch_back');d.append('i',i);d.append('_ajax_nonce','" . esc_js( $nonce ) . "');"
			. "fetch(ajaxurl,{method:'POST',body:d,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){"
			. "if(!r.success){l.textContent+='Stopped: '+r.data+'\\n';b.disabled=false;return}l.textContent+=r.data.line+'\\n';s.textContent=r.data.left+' left';"
			. "if(r.data.left>0)setTimeout(function(){go(r.data.next)},2000);else s.textContent='Finished. Reload the page.'}).catch(function(e){l.textContent+='Stopped: '+e+'\\n';b.disabled=false})}"
			. "b.addEventListener('click',function(){b.disabled=true;go(0)})})();</script>";
	}

	/** One per step; a fetched item leaves the list, a failed one is stepped over. */
	public static function ajax_fetch() {
		check_ajax_referer( 'lmgt_fetch_back' );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_send_json_error( 'Not allowed.' );
		$todo = self::fetch_todo();
		$i    = isset( $_POST['i'] ) ? (int) $_POST['i'] : 0;
		if ( ! isset( $todo[ $i ] ) ) wp_send_json_success( array( 'left' => 0, 'next' => $i, 'line' => 'Nothing left.' ) );
		$it   = $todo[ $i ];
		$line = self::fetch_one( $it );
		$todo = self::fetch_todo();
		$next = ( isset( $todo[ $i ] ) && $todo[ $i ]['sid'] === $it['sid'] && $todo[ $i ]['lang'] === $it['lang'] ) ? $i + 1 : $i;
		wp_send_json_success( array( 'left' => max( 0, count( $todo ) - $next ), 'next' => $next, 'line' => $line ) );
	}

	/** Copy one .travel page here, publish it, send the new set. Returns a log line. */
	public static function fetch_one( array $it ) {
		$where = get_the_title( $it['sid'] ) . ' (' . $it['lang'] . ')';
		$r     = LMGT_Bridge::call( 'GET', '/page', array( 'id' => $it['id'] ), false );
		if ( is_wp_error( $r ) ) return $where . ': failed – ' . $r->get_error_message() . ( strpos( $r->get_error_message(), '404' ) !== false ? ' (is Translator 2.12.0 installed on traveltalk.travel?)' : '' );
		if ( empty( $r['content'] ) || (int) $r['source_id'] !== $it['sid'] || $r['lang'] !== $it['lang'] ) return $where . ': failed – traveltalk.travel answered with a different or empty page';
		$t = array(
			'title' => (string) $r['title'], 'content' => (string) $r['content'], 'excerpt' => (string) $r['excerpt'],
			'seo_title' => (string) $r['seo_title'], 'seo_desc' => (string) $r['seo_desc'],
		);
		// The page's own keyword and meta come along; no new SEO call.
		$GLOBALS['lmgt_seo_new'] = array( 'keyword' => (string) $r['keyword'], 'meta' => (string) $r['seo_desc'] );
		$id = LMGT_Store::save( $it['sid'], $it['lang'], $t, array( 'fetched_from' => (string) $r['url'], 'issues' => array() ) );
		unset( $GLOBALS['lmgt_seo_new'] );
		if ( is_wp_error( $id ) ) return $where . ': failed – ' . $id->get_error_message();
		update_post_meta( $id, '_lmgt_made_with', 'fetched from traveltalk.travel by ' . LMGT_VERSION );
		update_post_meta( $id, '_lmgt_fetched_from', esc_url_raw( (string) $r['url'] ) );
		$up = array( 'ID' => $id, 'post_status' => 'publish' );
		if ( ! empty( $r['slug'] ) ) $up['post_name'] = sanitize_title( $r['slug'] );
		$ok = wp_update_post( $up, true );
		if ( is_wp_error( $ok ) ) return $where . ': saved as a draft here, not published – ' . $ok->get_error_message();
		// It was published on .travel: it counts as read.
		LMGT_Store::mark_reviewed( $id );
		LMGT_Bridge::refresh_set( $it['sid'] );
		do_action( 'litespeed_purge_post', $id );
		return $where . ': fetched – ' . get_permalink( $id ) . ' (traveltalk.travel now sends its readers here)';
	}

	/** Source, once on upgrade: Nordic translations copied to .travel come back. Returns a log line. */
	public static function take_back() {
		if ( ! LMGT_Bridge::is_source() ) return '';
		$ids = get_posts( array(
			'post_type' => LMGT_CPT, 'post_status' => array( 'publish', 'draft', 'pending', 'future', 'private' ), 'posts_per_page' => -1, 'fields' => 'ids', 'lmgt_all' => true, 'no_found_rows' => true,
			'meta_query' => array( array( 'key' => '_lmgt_lang', 'value' => self::LANGS, 'compare' => 'IN' ) ),
		) );
		$n = 0;
		foreach ( $ids as $id ) {
			$to    = get_post_meta( $id, '_lmgt_moved_to', true );
			$draft = get_post_meta( $id, '_lmgt_moved_draft', true );
			if ( ! $to && ! $draft ) continue;
			if ( $to ) update_post_meta( $id, '_lmgt_moved_back', $to );
			delete_post_meta( $id, '_lmgt_moved_to' );
			delete_post_meta( $id, '_lmgt_moved_draft' );
			delete_post_meta( $id, '_lmgt_moved_id' );
			// 2.0.0 names that the upgrade would otherwise turn back into a move.
			delete_post_meta( $id, '_lmgt_canonical' );
			delete_post_meta( $id, '_lmgt_moved_to_travel' );
			do_action( 'litespeed_purge_post', $id );
			$n++;
		}
		wp_cache_delete( 'lmgt_peer_langs', 'lmgt' );
		// The sets are recomputed and sent to .travel right after, by the upgrade's backfill.
		return $n ? $n . ' Nordic translation(s) back on traveltalk.dk' : '';
	}
}
