<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Translator 2.0: the .dk → .travel bridge.
 *
 * One plugin, two roles, set in wp-config.php (never in the repo):
 *   define( 'LMGT_ROLE', 'source' );                       // traveltalk.dk
 *   define( 'LMGT_ROLE', 'target' );                       // traveltalk.travel
 *   define( 'LMGT_PEER', 'https://traveltalk.travel' );    // the other site
 *   define( 'LMGT_PEER_USER', 'translator' );              // user on the other site
 *   define( 'LMGT_PEER_PASS', 'xxxx xxxx xxxx xxxx xxxx xxxx' ); // its application password
 * Without LMGT_ROLE the plugin behaves exactly as 1.10 (one site, local translations).
 *
 * The source runs the pipeline and sends each result to the target over the
 * REST API, where it is stored as a draft translation (so WordPress fires the
 * target's own hooks: cache purge, sitemap, revisions). The target tells the
 * source when a translation is published, withdrawn or moved.
 *
 * The hreflang set is decided in one place: the .dk original's post meta
 * (_lmgt_set). The source recomputes it on every change and pushes the same
 * array to the target, which stores it on every member. Both domains print it
 * from that array with the same function, so the blocks are byte-identical.
 *
 * Meta, source (.dk):
 *   _lmgt_remote      on the original: [lang => [id, url, status]] on the target
 *   _lmgt_set         on the original: [members => [lang => url], x => url]
 *   _lmgt_moved_to    on a local translation copied to the target: its URL there
 *   _lmgt_moved_draft on a local draft copied to the target: '1'
 * Meta, target (.travel):
 *   _lmgt_remote_source  .dk original ID
 *   _lmgt_remote_url     .dk original URL
 *   _lmgt_set            the set as last pushed by the source
 */
class LMGT_Bridge {

	const NS        = 'lmgt/v2';
	const QUEUE_OPT = 'lmgt_bridge_queue';
	const LOG_OPT   = 'lmgt_bridge_log';
	const RECON_OPT = 'lmgt_bridge_recon';

	/** 2.3.1: the bridge login also travels in its own header, for hosts that strip Authorization. */
	const AUTH_HDR  = 'X-LMGT-Auth';

	/** True while answering a /draft call: the caller updates its own record from the reply (2.2.16). */
	private static $quiet = false;

	/** The two bridge sites. Their role and peer follow from the address, so a wrong setting cannot swap them. */
	const SITES = array(
		'traveltalk.dk'     => array( 'role' => 'source', 'peer' => 'https://traveltalk.travel', 'front' => 'https://traveltalk.travel/' ),
		'traveltalk.travel' => array( 'role' => 'target', 'peer' => 'https://traveltalk.dk', 'front' => 'https://www.traveltalk.dk/' ),
	);

	/** The fragment a link from .dk to .travel carries (2.2.24). */
	const FROM_DK = 'lmg-from-dk';

	private static function site() {
		$host = preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) );
		return isset( self::SITES[ $host ] ) ? self::SITES[ $host ] : null;
	}

	/**
	 * LMGT_ROLE in wp-config.php wins; then the site's own address; then the
	 * role saved by 2.0.0 (Settings → LMG Translator) on any other site.
	 */
	public static function role() {
		$site = self::site();
		$r    = defined( 'LMGT_ROLE' ) ? LMGT_ROLE : ( $site ? $site['role'] : get_option( 'lmgt_role', '' ) );
		return in_array( $r, array( 'source', 'target' ), true ) ? $r : '';
	}

	public static function on() { return self::role() !== ''; }
	public static function is_source() { return self::role() === 'source'; }
	public static function is_target() { return self::role() === 'target'; }

	public static function peer() {
		$site = self::site();
		$p    = defined( 'LMGT_PEER' ) ? LMGT_PEER : ( $site ? $site['peer'] : get_option( 'lmgt_remote_url', '' ) );
		return untrailingslashit( (string) $p );
	}

	/**
	 * The peer's front page as the peer itself prints it, for links readers click.
	 * peer() is the address the bridge calls (traveltalk.dk without www), and
	 * a link to it costs the reader a redirect to www (2.2.24).
	 */
	public static function peer_front() {
		$site = self::site();
		return ! defined( 'LMGT_PEER' ) && $site && ! empty( $site['front'] ) ? $site['front'] : trailingslashit( self::peer() );
	}

	/**
	 * 2.2.24: a link from .dk to .travel carries a fragment, so .travel knows the
	 * reader came from .dk even when the browser withholds the referrer. A
	 * fragment is never sent to a server and Google ignores it; canonicals,
	 * hreflang and redirects never get one.
	 */
	public static function from_dk( $url ) {
		$url = (string) $url;
		if ( ! self::is_source() || $url === '' || strpos( $url, '#' ) !== false || strpos( $url, self::peer() . '/' ) !== 0 ) return $url;
		return $url . '#' . self::FROM_DK;
	}

	/**
	 * User and application password on the peer: wp-config.php first, then
	 * what pairing stored, then the 2.0.0 names.
	 */
	public static function peer_user() {
		if ( defined( 'LMGT_PEER_USER' ) ) return (string) LMGT_PEER_USER;
		$c = self::paired();
		return $c ? $c['user'] : (string) get_option( 'lmgt_remote_user', '' );
	}

	public static function peer_pass() {
		if ( defined( 'LMGT_PEER_PASS' ) ) return (string) LMGT_PEER_PASS;
		$c = self::paired();
		if ( $c ) return $c['pass'];
		return defined( 'LMGT_REMOTE_APP_PASSWORD' ) ? (string) LMGT_REMOTE_APP_PASSWORD : '';
	}

	// ---- Pairing (2.1.1) -------------------------------------------------------
	//
	// One site makes a code: it creates its bridge user and an application
	// password and puts both in the code. The other site takes the code, stores
	// it, makes its own user and password, and sends them back over the new
	// link. Passwords are kept in the database, encrypted with the site's own
	// wp-config keys; never in the repo. Constants in wp-config still win.

	const PAIR_OPT  = 'lmgt_peer_cred';
	const PAIR_USER = 'lmgt-bridge';
	const PAIR_NAME = 'LMG Translator bridge';

	private static function box_key() {
		return sodium_crypto_generichash( wp_salt( 'auth' ) . '|lmgt-bridge', '', SODIUM_CRYPTO_SECRETBOX_KEYBYTES );
	}

	private static function seal( $plain ) {
		$n = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		return base64_encode( $n . sodium_crypto_secretbox( $plain, $n, self::box_key() ) );
	}

	private static function open( $sealed ) {
		$raw = base64_decode( (string) $sealed, true );
		if ( ! $raw || strlen( $raw ) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ) return false;
		try {
			return sodium_crypto_secretbox_open( substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), self::box_key() );
		} catch ( Exception $e ) {
			return false;
		}
	}

	/** [user, pass] stored by pairing, or null. Null too when the wp-config keys changed since: pair again. */
	public static function paired() {
		$c = get_option( self::PAIR_OPT );
		if ( ! is_array( $c ) || empty( $c['user'] ) ) return null;
		$p = self::open( isset( $c['pass'] ) ? $c['pass'] : '' );
		return $p === false ? null : array( 'user' => (string) $c['user'], 'pass' => $p );
	}

	private static function store_peer( $user, $pass ) {
		update_option( self::PAIR_OPT, array( 'user' => sanitize_user( $user ), 'pass' => self::seal( $pass ), 'at' => current_time( 'mysql', true ) ), false );
	}

	/**
	 * This site's bridge user (Editor) and a fresh application password for the
	 * other site. Older bridge passwords are revoked only once the new one is in use.
	 *
	 * @return array|WP_Error [user, pass, uid, uuid]
	 */
	private static function issue_own() {
		if ( ! class_exists( 'WP_Application_Passwords' ) || ! wp_is_application_passwords_available() ) return new WP_Error( 'lmgt_pair', 'Application passwords are switched off on this site (they need HTTPS, and no plugin may disable them).' );
		$u = get_user_by( 'login', self::PAIR_USER );
		if ( ! $u ) {
			$host = wp_parse_url( home_url(), PHP_URL_HOST );
			$id   = wp_insert_user( array( 'user_login' => self::PAIR_USER, 'user_pass' => wp_generate_password( 32, true, true ), 'user_email' => self::PAIR_USER . '@' . preg_replace( '/^www\./', '', $host ), 'display_name' => 'LMG Translator bridge', 'role' => 'editor' ) );
			if ( is_wp_error( $id ) ) return $id;
			$u = get_user_by( 'id', $id );
		}
		$r = WP_Application_Passwords::create_new_application_password( $u->ID, array( 'name' => self::PAIR_NAME . ' (' . self::peer() . ')' ) );
		if ( is_wp_error( $r ) ) return $r;
		return array( 'user' => self::PAIR_USER, 'pass' => $r[0], 'uid' => $u->ID, 'uuid' => $r[1]['uuid'] );
	}

	/** Revoke this site's bridge passwords; $keep spares one (the new one), $only removes just that one. */
	private static function revoke_own( $uid, $keep = '', $only = '' ) {
		foreach ( WP_Application_Passwords::get_user_application_passwords( $uid ) as $item ) {
			if ( strpos( $item['name'], self::PAIR_NAME ) !== 0 || $item['uuid'] === $keep || ( $only && $item['uuid'] !== $only ) ) continue;
			WP_Application_Passwords::delete_application_password( $uid, $item['uuid'] );
		}
	}

	/** Step 1, on either site: a one-time code, valid 15 minutes. */
	public static function make_code() {
		// A code that was never used carries a live password: revoke it before making a new one.
		$pending = get_option( 'lmgt_pair_pending' );
		if ( is_array( $pending ) ) self::revoke_own( $pending['uid'], '', $pending['uuid'] );
		$own = self::issue_own();
		if ( is_wp_error( $own ) ) return $own;
		update_option( 'lmgt_pair_pending', array( 'uid' => $own['uid'], 'uuid' => $own['uuid'] ), false );
		$token = wp_generate_password( 32, false, false );
		set_transient( 'lmgt_pair_token', array( 'hash' => wp_hash_password( $token ), 'uid' => $own['uid'], 'uuid' => $own['uuid'] ), 15 * MINUTE_IN_SECONDS );
		self::log( 'pairing code created' );
		return rtrim( strtr( base64_encode( wp_json_encode( array( 'site' => home_url(), 'user' => $own['user'], 'pass' => $own['pass'], 'token' => $token ) ) ), '+/', '-_' ), '=' );
	}

	/** Step 2, on the other site: store the code, then hand this site's password back over the new link. */
	public static function use_code( $code ) {
		$c = json_decode( (string) base64_decode( strtr( trim( (string) $code ), '-_', '+/' ) ), true );
		if ( ! is_array( $c ) || empty( $c['user'] ) || empty( $c['pass'] ) || empty( $c['token'] ) ) return new WP_Error( 'lmgt_pair', 'That is not a pairing code. Copy the whole code from the other site\'s Bridge page.' );
		$host = function ( $u ) { return preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( $u, PHP_URL_HOST ) ) ); };
		if ( $host( $c['site'] ) !== $host( self::peer() ) ) return new WP_Error( 'lmgt_pair', 'That code was made on ' . $host( $c['site'] ) . ', not on ' . $host( self::peer() ) . '.' );
		$before = get_option( self::PAIR_OPT );
		self::store_peer( $c['user'], $c['pass'] );
		$own = self::issue_own();
		if ( is_wp_error( $own ) ) return $own;
		$r = self::call( 'POST', '/pair', array( 'token' => $c['token'], 'user' => $own['user'], 'pass' => $own['pass'] ), false );
		if ( is_wp_error( $r ) ) {
			// The other site did not accept: undo this attempt only; a working pair stays as it was.
			$before ? update_option( self::PAIR_OPT, $before, false ) : delete_option( self::PAIR_OPT );
			self::revoke_own( $own['uid'], '', $own['uuid'] );
			return $r;
		}
		self::revoke_own( $own['uid'], $own['uuid'] );
		self::log( 'paired with ' . self::peer() );
		return true;
	}

	/** Receives this site's half of the pair. Only with the one-time token from make_code(). */
	public static function rest_pair( WP_REST_Request $req ) {
		$p    = $req->get_json_params();
		$t = get_transient( 'lmgt_pair_token' );
		if ( ! is_array( $t ) || empty( $p['token'] ) || ! wp_check_password( (string) $p['token'], $t['hash'] ) ) return new WP_Error( 'lmgt_pair', 'Pairing code expired or already used. Make a new one.', array( 'status' => 403 ) );
		if ( empty( $p['user'] ) || empty( $p['pass'] ) ) return new WP_Error( 'lmgt_pair', 'user and pass required.', array( 'status' => 400 ) );
		delete_transient( 'lmgt_pair_token' );
		delete_option( 'lmgt_pair_pending' );
		self::revoke_own( $t['uid'], $t['uuid'] );
		self::store_peer( (string) $p['user'], (string) $p['pass'] );
		self::log( 'paired with ' . self::peer() );
		return array( 'ok' => true );
	}

	/** This site only: forget the other site's password and revoke the one issued here. */
	public static function unpair() {
		delete_option( self::PAIR_OPT );
		delete_option( 'lmgt_pair_pending' );
		delete_transient( 'lmgt_pair_token' );
		$u = get_user_by( 'login', self::PAIR_USER );
		if ( $u && class_exists( 'WP_Application_Passwords' ) ) self::revoke_own( $u->ID );
		self::log( 'unpaired' );
	}

	public static function boot() {
		if ( ! self::on() ) return;
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_filter( 'rest_authentication_errors', array( __CLASS__, 'rest_auth' ), 5 );
		add_action( 'admin_menu', function () {
			add_submenu_page( 'lmgt', 'Bridge', 'Bridge', 'edit_others_posts', 'lmgt-bridge', array( __CLASS__, 'page' ) );
		}, 20 );
		add_action( 'lmgt_bridge_retry', array( __CLASS__, 'retry_queue' ) );
		add_action( 'init', function () {
			if ( ! wp_next_scheduled( 'lmgt_bridge_retry' ) ) wp_schedule_event( time() + 300, 'hourly', 'lmgt_bridge_retry' );
			if ( self::is_source() && ! wp_next_scheduled( 'lmgt_bridge_recon' ) ) wp_schedule_event( time() + 900, 'daily', 'lmgt_bridge_recon' );
		} );
		if ( self::is_source() ) {
			add_action( 'lmgt_bridge_recon', array( __CLASS__, 'reconcile' ) );
			add_action( 'transition_post_status', array( __CLASS__, 'source_transition' ), 30, 3 );
			add_filter( 'rank_math/frontend/canonical', array( __CLASS__, 'moved_canonical' ), 20 );
			add_filter( 'get_canonical_url', function ( $c, $post ) { $to = get_post_meta( $post->ID, '_lmgt_moved_to', true ); return $to ? $to : $c; }, 20, 2 );
			add_filter( 'rank_math/sitemap/entry', array( __CLASS__, 'sitemap_skip_moved' ), 10, 3 );
			// 2.2.18: moved translations also leave the sitemap's own count and pages, and a copy clears Rank Math's sitemap cache.
			add_filter( 'rank_math/sitemap/get_posts/where', array( __CLASS__, 'sitemap_where_moved' ), 10, 2 );
			add_filter( 'rank_math/sitemap/post_count/where', array( __CLASS__, 'sitemap_where_moved' ), 10, 2 );
			foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $h ) {
				add_action( $h, function ( $mid, $pid, $key ) { if ( $key === '_lmgt_moved_to' ) LMGT_Bridge::sitemap_stale( $pid ); }, 10, 3 );
			}
			add_filter( 'the_content', array( __CLASS__, 'read_in_row' ), 15 );
			add_action( 'admin_post_lmgt_move', array( __CLASS__, 'handle_move' ) );
			add_action( 'admin_post_lmgt_link_en', array( __CLASS__, 'handle_link_en' ) );
			add_action( 'add_meta_boxes', array( __CLASS__, 'box' ) );
		} else {
			add_action( 'transition_post_status', array( __CLASS__, 'target_transition' ), 30, 3 );
			add_action( 'post_updated', array( __CLASS__, 'target_moved' ), 30, 3 );
			// A translation made here of a linked English page joins the .dk set (2.1.5).
			add_action( 'added_post_meta', function ( $mid, $pid, $key ) { if ( $key === '_lmgt_lang' && self::adopt( $pid ) ) self::notify( $pid ); }, 10, 3 );
			add_filter( 'the_content', array( __CLASS__, 'family_line' ), 5 );
			add_filter( 'the_content', array( __CLASS__, 'read_in_row_target' ), 15 );
			// Thin translations: readable, but noindex and out of the sitemap until filled out (2.1.6).
			add_filter( 'rank_math/frontend/robots', function ( $r ) { if ( is_singular( LMGT_CPT ) && LMGT_Store::is_thin( get_queried_object_id() ) ) $r['index'] = 'noindex'; return $r; } );
			add_filter( 'wp_robots', function ( $r ) { if ( is_singular( LMGT_CPT ) && LMGT_Store::is_thin( get_queried_object_id() ) ) { $r['noindex'] = true; unset( $r['index'] ); } return $r; } );
			add_filter( 'rank_math/sitemap/entry', function ( $url, $type, $object ) { return $object instanceof WP_Post && LMGT_Store::is_thin( $object ) ? false : $url; }, 10, 3 );
			add_action( 'parse_request', array( __CLASS__, 'route_root' ), 2 );
			add_action( 'lmgt_rethin', array( __CLASS__, 'rethin_run' ) );
		}
	}

	// ---- Languages in bridge mode --------------------------------------------

	/** Address prefix on this site. On the target, English lives at root and Norwegian under /nb/. */
	public static function prefix( $code ) {
		$l = LMGT_Langs::get( $code );
		if ( ! $l ) return null;
		if ( self::is_target() ) {
			if ( $code === 'en' ) return '';
			if ( $code === 'nb' ) return 'nb';
		}
		return $l['prefix'];
	}

	public static function hreflang_code( $code ) {
		if ( self::on() && $code === 'nb' ) return 'nb';
		$l = LMGT_Langs::get( $code );
		return $l ? $l['hreflang'] : $code;
	}

	/** Fixed order for printing, so every member prints the same bytes. */
	private static function order( array $members ) {
		$out = array();
		foreach ( array_keys( LMGT_Langs::all() ) as $code ) {
			if ( isset( $members[ $code ] ) ) $out[ $code ] = $members[ $code ];
		}
		return $out;
	}

	// ---- The set -------------------------------------------------------------

	/** Source: [lang => [id, url, status]] for one original; always an array. */
	public static function remote( $source_id ) {
		$r = get_post_meta( $source_id, '_lmgt_remote', true );
		return is_array( $r ) ? $r : array();
	}

	/**
	 * Source only. The original (when published), every published translation on
	 * the target, and local translations not yet moved for languages the target
	 * does not have; Nordic languages from .dk (2.11.0). x-default: the original.
	 */
	public static function compute_set( $source_id ) {
		$src = get_post( $source_id );
		if ( ! $src || $src->post_status !== 'publish' || ! in_array( $src->post_type, LMGT_Store::types(), true ) ) return array();
		if ( (int) get_option( 'page_on_front' ) === (int) $source_id ) return array();
		$members = array( LMGT_Langs::source() => get_permalink( $source_id ) );
		$local = LMGT_Store::of( $source_id, array( 'publish' ) );
		foreach ( self::remote( $source_id ) as $lang => $r ) {
			// 2.11.0: a Nordic language with a published page on .dk is that page, not an older copy on .travel.
			if ( self::is_source() && LMGT_Nordic::is( $lang ) && isset( $local[ $lang ] ) ) continue;
			if ( is_array( $r ) && isset( $r['status'] ) && $r['status'] === 'publish' && ! empty( $r['url'] ) && LMGT_Langs::get( $lang ) ) $members[ $lang ] = $r['url'];
		}
		foreach ( $local as $lang => $tid ) {
			if ( isset( $members[ $lang ] ) || get_post_meta( $tid, '_lmgt_moved_to', true ) ) continue;
			$members[ $lang ] = get_permalink( $tid );
		}
		if ( count( $members ) < 2 ) return array();
		$members = self::order( $members );
		// 2.17.19 (G, 18 Nov): x-default is the English page when one is published, else the original (was: always the original, 10 Nov).
		$x       = isset( $members['en'] ) ? $members['en'] : $members[ LMGT_Langs::source() ];
		return array( 'members' => $members, 'x' => $x );
	}

	/** Recompute, store, push to the target, purge local members. Source only. */
	public static function refresh_set( $source_id ) {
		$source_id = (int) $source_id;
		if ( ! $source_id || ! self::is_source() ) return;
		$set = self::compute_set( $source_id );
		$old = get_post_meta( $source_id, '_lmgt_set', true );
		update_post_meta( $source_id, '_lmgt_set', wp_slash( $set ) );
		if ( $set !== $old || get_post_meta( $source_id, '_lmgt_remote', true ) ) {
			self::call( 'POST', '/set', array( 'source_id' => $source_id, 'set' => $set ) );
		}
		LMGT_Store::purge_cluster( $source_id );
	}

	/** The stored set for the page being viewed, or array() when it prints none. */
	public static function current_set() {
		if ( ! is_singular() ) return array();
		$id = get_queried_object_id();
		if ( get_post_status( $id ) !== 'publish' ) return array();
		if ( self::is_source() ) {
			if ( get_post_meta( $id, '_lmgt_moved_to', true ) ) return array();
			$source = LMGT_Store::is_translation( $id ) ? (int) get_post_meta( $id, '_lmgt_source', true ) : $id;
			$set    = get_post_meta( $source, '_lmgt_set', true );
		} else {
			if ( ! get_post_meta( $id, '_lmgt_remote_source', true ) ) return array();
			$set = get_post_meta( $id, '_lmgt_set', true );
		}
		if ( ! is_array( $set ) || empty( $set['members'] ) ) return array();
		// A page whose address is not in the set (moved, renamed since) prints nothing.
		return in_array( get_permalink( $id ), $set['members'], true ) ? $set : array();
	}

	public static function print_set( array $set ) {
		foreach ( $set['members'] as $code => $url ) {
			echo '<link rel="alternate" hreflang="' . esc_attr( self::hreflang_code( $code ) ) . '" href="' . esc_url( $url ) . '" />' . "\n";
		}
		echo '<link rel="alternate" hreflang="x-default" href="' . esc_url( $set['x'] ) . '" />' . "\n";
	}

	// ---- Transport -----------------------------------------------------------

	/**
	 * One REST call to the peer. Writes that fail are queued and retried hourly;
	 * nothing is dropped silently.
	 *
	 * @return array|WP_Error decoded body
	 */
	public static function call( $method, $path, array $body = array(), $queue = true ) {
		$peer = self::peer();
		if ( ! $peer || self::peer_user() === '' || self::peer_pass() === '' ) return new WP_Error( 'lmgt_peer', 'Not paired with the other site yet: use Pairing below (Translator → Bridge).' );
		$url  = $peer . '/wp-json/' . self::NS . $path;
		$args = array(
			'method'  => $method,
			'timeout' => 30,
			'headers' => array(
				'Authorization' => 'Basic ' . base64_encode( self::peer_user() . ':' . str_replace( ' ', '', self::peer_pass() ) ),
				self::AUTH_HDR  => base64_encode( self::peer_user() . ':' . str_replace( ' ', '', self::peer_pass() ) ),
				'Content-Type'  => 'application/json',
			),
		);
		if ( $method === 'GET' ) {
			if ( $body ) $url = add_query_arg( $body, $url );
		} else {
			$args['body'] = wp_json_encode( $body );
		}
		$r    = wp_remote_request( $url, $args );
		$code = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
		// The host turned the call away before WordPress ran (508: resource limit): try once more after a pause (2.2.16).
		if ( in_array( $code, array( 429, 503, 508 ), true ) ) {
			self::log( $method . ' ' . $path . ' HTTP ' . $code . ', trying again in 5 seconds' );
			sleep( 5 );
			$r    = wp_remote_request( $url, $args );
			$code = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
		}
		$data = is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
		if ( $code >= 200 && $code < 300 ) {
			self::log( $method . ' ' . $path . ' OK' );
			return is_array( $data ) ? $data : array();
		}
		$msg = is_wp_error( $r ) ? $r->get_error_message() : 'HTTP ' . $code . ( is_array( $data ) && isset( $data['message'] ) ? ': ' . $data['message'] : '' );
		if ( $code === 401 ) $msg .= ' (' . self::peer() . ' refused the bridge login. On that site, check that application passwords are switched on (Users → Profile shows an Application Passwords section; a security or speed plugin can switch them off), then Retry. If it persists, pair again under Translator → Bridge)';
		self::log( $method . ' ' . $path . ' FAILED ' . $msg );
		if ( $queue && $method !== 'GET' ) self::enqueue( $method, $path, $body, $msg );
		return new WP_Error( 'lmgt_peer', $msg );
	}

	private static function enqueue( $method, $path, array $body, $err ) {
		$q   = (array) get_option( self::QUEUE_OPT, array() );
		$key = md5( $method . $path . wp_json_encode( $body ) );
		$q[ $key ] = array( 'method' => $method, 'path' => $path, 'body' => $body, 'tries' => isset( $q[ $key ] ) ? $q[ $key ]['tries'] + 1 : 1, 'error' => $err, 'at' => current_time( 'mysql', true ) );
		update_option( self::QUEUE_OPT, $q, false );
	}

	public static function retry_queue() {
		$q = (array) get_option( self::QUEUE_OPT, array() );
		foreach ( $q as $key => $item ) {
			$r = self::call( $item['method'], $item['path'], $item['body'], false );
			if ( is_wp_error( $r ) ) {
				$q[ $key ]['tries']++;
				$q[ $key ]['error'] = $r->get_error_message();
			} else {
				unset( $q[ $key ] );
			}
		}
		update_option( self::QUEUE_OPT, $q, false );
	}

	public static function log( $line ) {
		$log   = (array) get_option( self::LOG_OPT, array() );
		$log[] = gmdate( 'Y-m-d H:i:s' ) . ' ' . $line;
		update_option( self::LOG_OPT, array_slice( $log, -200 ), false );
	}

	// ---- REST routes ---------------------------------------------------------

	/**
	 * 2.3.1: a bridge call that reached WordPress without a logged-in user (the
	 * host stripped Authorization, or a plugin fixed the user before the REST
	 * request began) logs in here with the bridge application password.
	 */
	public static function rest_auth( $result ) {
		if ( ! empty( $result ) || is_user_logged_in() || ! class_exists( 'WP_Application_Passwords' ) ) return $result;
		$route = isset( $GLOBALS['wp']->query_vars['rest_route'] ) ? (string) $GLOBALS['wp']->query_vars['rest_route'] : '';
		if ( $route === '' && isset( $_SERVER['REQUEST_URI'] ) ) $route = (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH );
		if ( strpos( $route, '/' . self::NS . '/' ) === false ) return $result;
		$raw = '';
		foreach ( array( 'HTTP_X_LMGT_AUTH', 'HTTP_AUTHORIZATION', 'REDIRECT_HTTP_AUTHORIZATION' ) as $k ) {
			if ( empty( $_SERVER[ $k ] ) ) continue;
			$raw = preg_replace( '/^Basic\s+/i', '', trim( (string) wp_unslash( $_SERVER[ $k ] ) ) );
			break;
		}
		if ( $raw === '' && isset( $_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW'] ) ) $raw = base64_encode( wp_unslash( $_SERVER['PHP_AUTH_USER'] ) . ':' . wp_unslash( $_SERVER['PHP_AUTH_PW'] ) );
		$pair = explode( ':', (string) base64_decode( $raw, true ), 2 );
		if ( count( $pair ) !== 2 || $pair[0] === '' ) return $result;
		$u = get_user_by( 'login', $pair[0] );
		if ( ! $u ) return $result;
		$pass = preg_replace( '/[^a-z\d]/i', '', $pair[1] );
		foreach ( WP_Application_Passwords::get_user_application_passwords( $u->ID ) as $item ) {
			if ( ! wp_check_password( $pass, $item['password'], $u->ID ) ) continue;
			wp_set_current_user( $u->ID );
			WP_Application_Passwords::record_application_password_usage( $u->ID, $item['uuid'] );
			return true;
		}
		return $result;
	}

	public static function routes() {
		$can = function () { return current_user_can( 'edit_others_posts' ); };
		register_rest_route( self::NS, '/pair', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_pair' ), 'permission_callback' => $can ) );
		register_rest_route( self::NS, '/ping', array( 'methods' => 'GET', 'permission_callback' => $can, 'callback' => function () {
			return array( 'user' => wp_get_current_user()->user_login, 'role' => self::role(), 'langs' => array_merge( array( LMGT_Langs::source() ), LMGT_Langs::enabled() ) );
		} ) );
		if ( self::is_target() ) {
			register_rest_route( self::NS, '/draft', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_draft' ), 'permission_callback' => $can ) );
			register_rest_route( self::NS, '/thumb', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_thumb' ), 'permission_callback' => $can ) );
			register_rest_route( self::NS, '/set', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_set' ), 'permission_callback' => $can ) );
			register_rest_route( self::NS, '/sets', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_sets' ), 'permission_callback' => $can ) );
			register_rest_route( self::NS, '/match', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_match' ), 'permission_callback' => $can ) );
			register_rest_route( self::NS, '/link', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_link' ), 'permission_callback' => $can ) );
			register_rest_route( self::NS, '/english', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_english' ), 'permission_callback' => $can ) );
		} else {
			register_rest_route( self::NS, '/notify', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_notify' ), 'permission_callback' => $can ) );
			register_rest_route( self::NS, '/original', array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'rest_original' ), 'permission_callback' => $can ) );
		}
	}

	/** Target: members of one .dk original on this site, any status but trash. */
	public static function members( $remote_source ) {
		return get_posts( array(
			'post_type'      => LMGT_Store::types( true ),
			'post_status'    => array( 'publish', 'draft', 'pending', 'future', 'private' ),
			'posts_per_page' => 50,
			'fields'         => 'ids',
			'meta_key'       => '_lmgt_remote_source',
			'meta_value'     => (int) $remote_source,
			'lmgt_all'       => true,
			'no_found_rows'  => true,
		) );
	}

	public static function member( $remote_source, $lang ) {
		foreach ( self::members( $remote_source ) as $id ) {
			if ( get_post_meta( $id, '_lmgt_lang', true ) === $lang ) return (int) $id;
		}
		return 0;
	}

	/**
	 * Target: create or refresh the translation. A published one is never
	 * overwritten; the new version waits for "apply" as on one site. status
	 * 'publish' is accepted only for copying an already-reviewed .dk translation.
	 */
	public static function rest_draft( WP_REST_Request $req ) {
		$p    = $req->get_json_params();
		$lang = isset( $p['lang'] ) ? (string) $p['lang'] : '';
		$sid  = isset( $p['source_id'] ) ? (int) $p['source_id'] : 0;
		if ( ! LMGT_Langs::get( $lang ) || ! $sid || empty( $p['title'] ) || empty( $p['content'] ) ) return new WP_Error( 'lmgt_bad', 'lang, source_id, title and content are required.', array( 'status' => 400 ) );
		$t = array(
			'title'     => (string) $p['title'],
			'content'   => (string) $p['content'],
			'excerpt'   => isset( $p['excerpt'] ) ? (string) $p['excerpt'] : '',
			'seo_title' => isset( $p['seo_title'] ) ? (string) $p['seo_title'] : '',
			'seo_desc'  => isset( $p['seo_desc'] ) ? (string) $p['seo_desc'] : '',
		);
		$report = isset( $p['report'] ) && is_array( $p['report'] ) ? $p['report'] : array();
		$id     = self::member( $sid, $lang );

		$hash   = isset( $p['source_hash'] ) ? sanitize_key( $p['source_hash'] ) : '';
		// The version that made the translation: .dk's, sent with it (2.2.2); a 2.2.1 or older .dk sends none.
		$made   = ! empty( $p['made_with'] ) ? sanitize_text_field( $p['made_with'] ) : 'before 2.2.2';
		// 2.2.17: a copy of a .dk translation made before the original last changed arrives flagged.
		$stale  = ! empty( $p['source_stale']['hash'] ) ? array( 'at' => sanitize_text_field( (string) $p['source_stale']['at'] ), 'hash' => sanitize_key( $p['source_stale']['hash'] ) ) : null;

		// 2.7.1 (G, 8 Nov: "the safari companies and the links I added are gone"): a draft someone has
		// edited here since it arrived is not overwritten either. The new copy waits, like on a
		// published translation, and the person chooses.
		$edited = $id && get_post_status( $id ) !== 'publish' && ( ( $w = (string) get_post_meta( $id, '_lmgt_written', true ) ) === '' || $w !== get_post_field( 'post_modified_gmt', $id ) ); // a draft from before 2.7.1 counts as edited: safer
		if ( $id && ( get_post_status( $id ) === 'publish' || $edited ) ) {
			update_post_meta( $id, '_lmgt_pending', wp_slash( array( 'translation' => $t, 'report' => $report, 'source_modified' => isset( $p['source_modified'] ) ? $p['source_modified'] : '', 'source_hash' => $hash, 'source_stale' => $stale, 'made_with' => $made, 'at' => current_time( 'mysql', true ) ) ) );
			LMGT_Sync::store_thumb_texts( get_post_thumbnail_id( $id ), $lang, $p, true );
			// The related-articles grid is navigation, not article text: it takes effect at once.
			if ( isset( $p['related'] ) ) LMGT_Pictures::store( $id, $p['related'] );
			return array( 'id' => $id, 'url' => get_permalink( $id ), 'status' => get_post_status( $id ), 'pending' => true );
		}
		if ( $id && get_post_type( $id ) !== LMGT_CPT ) return new WP_Error( 'lmgt_linked', 'An existing English post is linked for this original. Nothing saved.', array( 'status' => 409 ) );
		if ( $id && get_post_meta( $id, '_lmgt_adopted', true ) ) return new WP_Error( 'lmgt_adopted', 'A ' . LMGT_Langs::get( $lang )['name'] . ' translation made on .travel is waiting there as a draft. Nothing saved; publish or trash it there first.', array( 'status' => 409 ) );

		// .dk is waiting for this reply and records the result itself: no call back to it meanwhile (2.2.16).
		self::$quiet = true;
		$GLOBALS['lmgt_saving_lang'] = $lang;
		$data = array(
			'post_type'      => LMGT_CPT,
			'post_status'    => 'draft',
			'post_title'     => $t['title'],
			'post_content'   => $t['content'],
			'post_excerpt'   => $t['excerpt'],
			'post_name'      => $id ? get_post_field( 'post_name', $id ) : sanitize_title( ! empty( $p['slug'] ) ? $p['slug'] : $t['title'] ),
			'comment_status' => 'closed',
			'ping_status'    => 'closed',
		);
		if ( $id ) $data['ID'] = $id;
		$r = $id ? wp_update_post( wp_slash( $data ), true ) : wp_insert_post( wp_slash( $data ), true );
		unset( $GLOBALS['lmgt_saving_lang'] );
		if ( is_wp_error( $r ) ) {
			self::$quiet = false;
			return $r;
		}
		update_post_meta( (int) $r, '_lmgt_written', get_post_field( 'post_modified_gmt', (int) $r ) ); // 2.7.1: what arrived, to tell later edits apart
		$id = (int) $r;

		update_post_meta( $id, '_lmgt_lang', $lang );
		update_post_meta( $id, '_lmgt_remote_source', $sid );
		update_post_meta( $id, '_lmgt_remote_url', esc_url_raw( (string) $p['source_url'] ) );
		update_post_meta( $id, '_lmgt_source_type', isset( $p['source_type'] ) && $p['source_type'] === 'page' ? 'page' : 'post' );
		update_post_meta( $id, '_lmgt_source_modified', isset( $p['source_modified'] ) ? (string) $p['source_modified'] : '' );
		update_post_meta( $id, '_lmgt_report', wp_slash( $report ) );
		update_post_meta( $id, '_lmgt_made_with', $made );
		if ( ! empty( $p['author_name'] ) ) update_post_meta( $id, '_lmgt_author_name', sanitize_text_field( $p['author_name'] ) ); // 2.20.0
		if ( isset( $p['related'] ) ) LMGT_Pictures::store( $id, $p['related'] );
		if ( ! empty( $p['page_template'] ) ) update_post_meta( $id, '_lmgt_page_template', sanitize_text_field( $p['page_template'] ) );
		if ( $t['seo_title'] !== '' && trim( (string) get_post_meta( $id, 'rank_math_title', true ) ) === '' ) update_post_meta( $id, 'rank_math_title', $t['seo_title'] ); // 2.17.9: a person's SEO title stays
		if ( ! empty( $p['pillar'] ) ) update_post_meta( $id, 'rank_math_pillar_content', 'on' ); // 2.6.3: the original's pillar tick travels with it
		LMGT_Store::apply_seo( $id, array(
			'keyword' => isset( $p['keyword'] ) ? sanitize_text_field( $p['keyword'] ) : '',
			'meta'    => $t['seo_desc'] !== '' ? $t['seo_desc'] : ( isset( $p['meta'] ) ? sanitize_text_field( $p['meta'] ) : '' ),
		) );
		delete_post_meta( $id, '_lmgt_pending' );
		LMGT_Sync::made_from( $id, $hash );
		if ( $stale ) update_post_meta( $id, '_lmgt_mother_changed', $stale );
		if ( isset( $p['trail'] ) ) LMGT_Trail::store( $id, $p['trail'] );
		// The featured image: set at once when already imported; a new file comes in its own call (2.2.16).
		$thumb = 'none';
		if ( ! empty( $p['thumb_url'] ) ) {
			$url   = esc_url_raw( $p['thumb_url'] );
			$have  = self::have_thumb( $url );
			$thumb = $have || empty( $p['thumb_later'] ) ? 'set' : 'later';
			if ( $thumb === 'set' ) LMGT_Sync::store_thumb_texts( $have ? self::use_thumb( $id, $have ) : self::import_thumb( $id, $url ), $lang, $p );
		}

		// 2.6.2: a copy that arrives as a draft is never ticked as read; only one published straight away carries the tick.
		LMGT_Store::mark_reviewed( $id, ! empty( $p['reviewed'] ) && isset( $p['status'] ) && $p['status'] === 'publish' );
		if ( isset( $p['status'] ) && $p['status'] === 'publish' ) {
			wp_update_post( array( 'ID' => $id, 'post_status' => 'publish' ) );
		}
		// 2.2.25: made automatically for a new article; listed for the person to look at, who is told by e-mail.
		if ( ! empty( $p['autopub'] ) ) {
			update_post_meta( $id, '_lmgt_autopub', $p['autopub'] === 'hold' ? 'hold' : 'published' );
			update_post_meta( $id, '_lmgt_autopub_at', time() );
			delete_post_meta( $id, '_lmgt_autopub_seen' );
			delete_post_meta( $id, '_lmgt_autopub_mailed' );
			LMGT_Auto::announce();
		}
		self::$quiet = false;
		return array( 'id' => $id, 'url' => get_permalink( $id ), 'status' => self::member_status( $id ), 'thumb' => $thumb, 'edit' => admin_url( 'post.php?post=' . $id . '&action=edit' ) );
	}

	/** Target: the featured image of a translation just sent, in a call of its own (2.2.16). */
	public static function rest_thumb( WP_REST_Request $req ) {
		$p    = $req->get_json_params();
		$lang = isset( $p['lang'] ) ? (string) $p['lang'] : '';
		$id   = self::member( isset( $p['source_id'] ) ? (int) $p['source_id'] : 0, $lang );
		if ( ! $id || get_post_type( $id ) !== LMGT_CPT || empty( $p['thumb_url'] ) ) return new WP_Error( 'lmgt_bad', 'No translation in that language for that original, or no image.', array( 'status' => 404 ) );
		$url  = esc_url_raw( $p['thumb_url'] );
		$have = self::have_thumb( $url );
		$att  = $have ? self::use_thumb( $id, $have ) : self::import_thumb( $id, $url );
		if ( ! $att ) return new WP_Error( 'lmgt_thumb', 'The image could not be imported.', array( 'status' => 502 ) );
		LMGT_Sync::store_thumb_texts( $att, $lang, $p );
		do_action( 'litespeed_purge_post', $id );
		return array( 'id' => $id, 'attachment' => $att );
	}

	private static function have_thumb( $url ) {
		$have = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_lmgt_src_url', 'meta_value' => $url ) );
		return $have ? (int) $have[0] : 0;
	}

	private static function use_thumb( $id, $att ) {
		set_post_thumbnail( $id, $att );
		return (int) $att;
	}

	/** Featured image: imported once per source file, then reused. Returns the attachment ID, 0 on failure. */
	private static function import_thumb( $id, $url ) {
		$have = self::have_thumb( $url );
		if ( $have ) return self::use_thumb( $id, $have );
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$att = media_sideload_image( $url, $id, null, 'id' );
		if ( is_wp_error( $att ) ) {
			self::log( 'thumb FAILED ' . $url . ' ' . $att->get_error_message() );
			return 0;
		}
		update_post_meta( $att, '_lmgt_src_url', $url );
		set_post_thumbnail( $id, $att );
		return (int) $att;
	}

	/** Target: the set as decided on .dk, stored on every member here. */
	public static function rest_set( WP_REST_Request $req ) {
		$p   = $req->get_json_params();
		$sid = isset( $p['source_id'] ) ? (int) $p['source_id'] : 0;
		$set = isset( $p['set'] ) && is_array( $p['set'] ) ? $p['set'] : array();
		if ( ! $sid ) return new WP_Error( 'lmgt_bad', 'source_id required.', array( 'status' => 400 ) );
		$clean = array();
		if ( ! empty( $set['members'] ) && ! empty( $set['x'] ) ) {
			foreach ( (array) $set['members'] as $code => $url ) {
				if ( LMGT_Langs::get( $code ) ) $clean['members'][ $code ] = esc_url_raw( $url );
			}
			$clean['x'] = esc_url_raw( $set['x'] );
		}
		$ids = self::members( $sid );
		foreach ( $ids as $id ) {
			update_post_meta( $id, '_lmgt_set', wp_slash( $clean ) );
			do_action( 'litespeed_purge_post', $id );
		}
		return array( 'stored_on' => array_map( 'intval', $ids ) );
	}

	/** Target: every member and its state, for the daily reconciliation. */
	public static function rest_sets() {
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT p.ID, p.post_status, m.meta_value AS src FROM {$wpdb->posts} p JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_lmgt_remote_source' WHERE p.post_status <> 'trash'" );
		$out  = array();
		foreach ( $rows as $r ) {
			// 'set': a fingerprint of the stored set, for Check Google tags on .dk (2.2.6).
			$out[ (int) $r->src ][ get_post_meta( $r->ID, '_lmgt_lang', true ) ] = array( 'id' => (int) $r->ID, 'url' => get_permalink( $r->ID ), 'status' => self::member_status( $r->ID ), 'set' => md5( maybe_serialize( get_post_meta( $r->ID, '_lmgt_set', true ) ) ) );
		}
		return $out;
	}

	/** Target: English posts and pages on the same subject, for a person to confirm (brief 4.5). */
	public static function rest_match( WP_REST_Request $req ) {
		$q   = sanitize_text_field( (string) $req->get_param( 'q' ) );
		$ids = $q === '' ? array() : get_posts( array( 'post_type' => LMGT_Store::types(), 'post_status' => 'publish', 's' => $q, 'posts_per_page' => 8, 'fields' => 'ids' ) );
		$out = array();
		foreach ( $ids as $id ) {
			$out[] = array( 'id' => (int) $id, 'title' => get_the_title( $id ), 'url' => get_permalink( $id ), 'linked_to' => (int) get_post_meta( $id, '_lmgt_remote_source', true ) );
		}
		return $out;
	}

	/** Target (2.4.2): the English member of a .dk original, published or not, for "What the English version has". */
	public static function rest_english( WP_REST_Request $req ) {
		foreach ( self::members( (int) $req->get_param( 'source' ) ) as $id ) {
			if ( get_post_meta( $id, '_lmgt_lang', true ) !== 'en' ) continue;
			$p = get_post( $id );
			return array( 'id' => (int) $id, 'title' => $p->post_title, 'content' => $p->post_content, 'url' => get_permalink( $id ), 'status' => $p->post_status );
		}
		return new WP_Error( 'lmgt_none', 'No English version of this article on traveltalk.travel.', array( 'status' => 404 ) );
	}

	/** Target: an existing English post becomes the English member of a .dk original. Confirmed by a person on .dk. */
	public static function rest_link( WP_REST_Request $req ) {
		$p   = $req->get_json_params();
		$id  = isset( $p['post_id'] ) ? (int) $p['post_id'] : 0;
		if ( ! $id && ! empty( $p['url'] ) ) $id = url_to_postid( esc_url_raw( (string) $p['url'] ) );
		$sid = isset( $p['source_id'] ) ? (int) $p['source_id'] : 0;
		$post = get_post( $id );
		if ( ! $post || ! in_array( $post->post_type, LMGT_Store::types(), true ) || ! $sid ) return new WP_Error( 'lmgt_bad', 'post_id must be a post or page here; source_id required.', array( 'status' => 400 ) );
		$other = self::member( $sid, 'en' );
		if ( $other && $other !== $id ) return new WP_Error( 'lmgt_taken', 'That original already has an English member here (#' . $other . ').', array( 'status' => 409 ) );
		update_post_meta( $id, '_lmgt_lang', 'en' );
		update_post_meta( $id, '_lmgt_remote_source', $sid );
		update_post_meta( $id, '_lmgt_remote_url', esc_url_raw( (string) $p['source_url'] ) );
		self::notify( $id );
		// Its own translations made here join the set, so they keep their hreflang (2.1.5).
		foreach ( LMGT_Store::of( $id ) as $tid ) {
			if ( self::adopt( $tid ) ) self::notify( $tid );
		}
		return array( 'id' => $id, 'url' => get_permalink( $id ), 'status' => $post->post_status );
	}

	/** Source: a member on the target was published, withdrawn or moved. */
	public static function rest_notify( WP_REST_Request $req ) {
		$p    = $req->get_json_params();
		$sid  = isset( $p['source_id'] ) ? (int) $p['source_id'] : 0;
		$lang = isset( $p['lang'] ) ? (string) $p['lang'] : '';
		if ( ! $sid || ! get_post( $sid ) || ! LMGT_Langs::get( $lang ) ) return new WP_Error( 'lmgt_bad', 'Unknown original or language.', array( 'status' => 400 ) );
		$remote = self::remote( $sid );
		if ( isset( $p['status'] ) && $p['status'] === 'trash' ) {
			unset( $remote[ $lang ] );
		} else {
			$remote[ $lang ] = array( 'id' => (int) $p['id'], 'url' => esc_url_raw( (string) $p['url'] ), 'status' => sanitize_key( (string) $p['status'] ) );
		}
		update_post_meta( $sid, '_lmgt_remote', wp_slash( $remote ) );
		wp_cache_delete( 'lmgt_peer_langs', 'lmgt' );
		self::refresh_set( $sid );
		return array( 'ok' => true );
	}

	/**
	 * Target: a translation made here of an English page that is linked to a .dk
	 * original becomes a member of that original's set. Its own source stays as
	 * it was; it only gains the .dk original. Marked _lmgt_adopted, so a .dk
	 * translation in the same language never overwrites it.
	 */
	public static function adopt( $tid ) {
		if ( ! self::is_target() || get_post_type( $tid ) !== LMGT_CPT || get_post_meta( $tid, '_lmgt_remote_source', true ) ) return false;
		$page = (int) get_post_meta( $tid, '_lmgt_source', true );
		$sid  = $page ? (int) get_post_meta( $page, '_lmgt_remote_source', true ) : 0;
		if ( ! $sid ) return false;
		update_post_meta( $tid, '_lmgt_remote_source', $sid );
		update_post_meta( $tid, '_lmgt_remote_url', esc_url_raw( (string) get_post_meta( $page, '_lmgt_remote_url', true ) ) );
		update_post_meta( $tid, '_lmgt_adopted', '1' );
		return true;
	}

	/** Source: one original as stored, for the improver on the target. */
	public static function rest_original( WP_REST_Request $req ) {
		$post = get_post( (int) $req->get_param( 'id' ) );
		if ( ! $post || ! in_array( $post->post_type, LMGT_Store::types(), true ) || $post->post_status !== 'publish' ) return new WP_Error( 'lmgt_bad', 'No published original with that ID.', array( 'status' => 404 ) );
		return array( 'id' => $post->ID, 'title' => $post->post_title, 'content' => $post->post_content, 'modified' => $post->post_modified_gmt, 'url' => get_permalink( $post ) );
	}

	// ---- Target: tell the source -----------------------------------------------

	public static function notify( $id ) {
		$sid = (int) get_post_meta( $id, '_lmgt_remote_source', true );
		if ( ! $sid ) return;
		self::call( 'POST', '/notify', array(
			'source_id' => $sid,
			'lang'      => get_post_meta( $id, '_lmgt_lang', true ),
			'id'        => (int) $id,
			'url'       => get_permalink( $id ),
			'status'    => self::member_status( $id ),
		) );
	}

	/**
	 * 2.2.21: the word threshold for noindex changed (Settings). Noindex and the sitemap follow at once,
	 * but .dk keeps the status it was last told ('thin' or 'publish') and builds its hreflang sets from
	 * it. Every published translation whose state flipped is queued and re-reported to .dk a few at a
	 * time (cron, 30 seconds apart), and Rank Math's sitemap cache is cleared now and at the end.
	 * Returns how many were queued.
	 */
	public static function threshold_changed( $old, $new ) {
		if ( ! self::on() || ! self::is_target() || (int) $old === (int) $new ) return 0;
		$queue = (array) get_option( 'lmgt_rethin_queue', array() );
		$first = 0;
		foreach ( get_posts( array( 'post_type' => LMGT_CPT, 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids', 'lmgt_all' => true, 'no_found_rows' => true, 'meta_key' => '_lmgt_remote_source' ) ) as $id ) {
			$first = $first ? $first : (int) $id;
			$w   = LMGT_Store::words( $id );
			$was = (int) $old > 0 && $w < (int) $old;
			$now = (int) $new > 0 && $w < (int) $new;
			if ( $was !== $now && ! in_array( (int) $id, $queue, true ) ) $queue[] = (int) $id;
		}
		update_option( 'lmgt_rethin_queue', array_values( $queue ), false );
		if ( $first ) self::sitemap_stale( $first );
		do_action( 'litespeed_purge_all' );
		if ( $queue && ! wp_next_scheduled( 'lmgt_rethin' ) ) wp_schedule_single_event( time() + 20, 'lmgt_rethin' );
		self::log( 'noindex threshold ' . (int) $old . ' → ' . (int) $new . ': ' . count( $queue ) . ' translation(s) queued to be re-reported to ' . self::peer() );
		return count( $queue );
	}

	public static function rethin_run() {
		$q     = (array) get_option( 'lmgt_rethin_queue', array() );
		$batch = array_splice( $q, 0, 6 );
		foreach ( $batch as $id ) {
			if ( get_post_status( $id ) === 'publish' ) self::notify( (int) $id );
		}
		update_option( 'lmgt_rethin_queue', array_values( $q ), false );
		if ( $q ) {
			wp_schedule_single_event( time() + 30, 'lmgt_rethin' );
		} else {
			if ( $batch ) self::sitemap_stale( (int) $batch[0] );
			do_action( 'litespeed_purge_all' );
			self::log( 'noindex threshold: all queued translations re-reported' );
		}
	}

	/** A published translation under the word threshold counts as 'thin': .dk leaves it out of the set. */
	private static function member_status( $id ) {
		$s = get_post_status( $id );
		return $s === 'publish' && LMGT_Store::is_thin( $id ) ? 'thin' : $s;
	}

	public static function target_transition( $new, $old, $post ) {
		if ( $new === $old || self::$quiet ) return;
		self::adopt( $post->ID );
		if ( ! get_post_meta( $post->ID, '_lmgt_remote_source', true ) ) return;
		if ( $new === 'publish' || $old === 'publish' || $new === 'trash' ) self::notify( $post->ID );
	}

	/** A published member's address changed: the source must print the new one. */
	public static function target_moved( $id, $after, $before ) {
		if ( $after->post_status !== 'publish' || $before->post_status !== 'publish' ) return;
		// A new address, or a thin page filled out (or cut back): the source must print the new state.
		if ( $after->post_name === $before->post_name && LMGT_Store::is_thin( $before ) === LMGT_Store::is_thin( $after ) ) return;
		if ( get_post_meta( $id, '_lmgt_remote_source', true ) ) self::notify( $id );
	}

	/** English translations live at root: /<slug>/, only when no post or page owns that address. */
	public static function route_root( $wp ) {
		if ( is_admin() ) return;
		$path = trim( (string) $wp->request, '/' );
		if ( $path === '' || strpos( $path, '/' ) !== false ) return;
		$slug = sanitize_title( urldecode( $path ) );
		if ( get_page_by_path( $slug, OBJECT, array( 'post', 'page' ) ) ) return;
		$statuses = current_user_can( 'edit_others_posts' ) ? array( 'publish', 'draft', 'pending', 'private', 'future' ) : array( 'publish' );
		$id = LMGT_Store::find( 'en', $slug, $statuses );
		if ( ! $id ) return;
		$wp->query_vars = array( 'post_type' => LMGT_CPT, 'p' => $id );
		if ( get_post_status( $id ) !== 'publish' ) $wp->query_vars['preview'] = 'true';
	}

	/** "From the traveltalk.dk family – started in Denmark in 2018", linking to the Danish original (brief 4.9). */
	public static function family_line( $content ) {
		if ( ! is_singular() || ! in_the_loop() || ! is_main_query() ) return $content;
		$id  = get_the_ID();
		$url = get_post_meta( $id, '_lmgt_remote_url', true );
		if ( ! $url || get_post_type( $id ) !== LMGT_CPT ) return $content;
		$t = array(
			'en' => 'From the %s family – started in Denmark in 2018',
			'de' => 'Aus der %s-Familie – gegründet 2018 in Dänemark',
			'fr' => 'De la famille %s – fondée au Danemark en 2018',
			'es' => 'De la familia %s – fundada en Dinamarca en 2018',
			'it' => 'Dalla famiglia %s – nata in Danimarca nel 2018',
			'sv' => 'Från %s-familjen – startad i Danmark 2018',
			'nb' => 'Fra %s-familien – startet i Danmark i 2018',
			'fi' => '%s-perheestä – perustettu Tanskassa vuonna 2018',
		);
		$lang = get_post_meta( $id, '_lmgt_lang', true );
		$line = sprintf( isset( $t[ $lang ] ) ? $t[ $lang ] : $t['en'], '<a href="' . esc_url( $url ) . '" hreflang="da">traveltalk.dk</a>' );
		return '<p class="lmgt-family" style="font-size:.9em;opacity:.85">' . $line . '</p>' . $content;
	}

	// ---- Source: send, move, link --------------------------------------------

	/**
	 * The pipeline's result goes to the target as a draft. Address, focus
	 * keyword and meta description are chosen here, where the engines are.
	 *
	 * @return int|WP_Error target post ID
	 */
	public static function send( $source_id, $lang, array $t, array $report, $status = 'draft', $reviewed = false, $slug = '', array $extra = array() ) {
		$src = get_post( $source_id );
		if ( ! $src ) return new WP_Error( 'lmgt_source', 'Original no longer exists.' );
		$remote = self::remote( $source_id );
		// A copy brings its own keyword and meta: the address call is only needed when one is missing (2.2.16).
		$own    = array( 'keyword' => isset( $t['keyword'] ) ? (string) $t['keyword'] : '', 'meta' => isset( $t['seo_desc'] ) ? (string) $t['seo_desc'] : '', 'slug' => $slug );
		if ( isset( $remote[ $lang ] ) || ( $own['keyword'] !== '' && $own['meta'] !== '' && $slug !== '' ) ) {
			$seo = isset( $remote[ $lang ] ) ? array( 'keyword' => '', 'meta' => '', 'slug' => '' ) : $own;
		} else {
			$seo = LMGT_Store::seo_basics( $lang, $t['title'], $t['content'], $src->post_type === 'page' );
			if ( $own['keyword'] !== '' ) $seo['keyword'] = $own['keyword'];
		}
		if ( $slug !== '' ) $seo['slug'] = $slug;
		$thumb  = get_post_thumbnail_id( $source_id );
		$thumb_t = $thumb ? LMGT_Sync::thumb_texts( $thumb, $lang ) : array();
		$hash   = LMGT_Sync::text_hash( $src );
		update_post_meta( $source_id, '_lmgt_text_hash', $hash );
		// A copy made from an older text of the original must not pass as made from today's (2.2.17).
		$stale  = ! empty( $t['stale'] );
		$related = LMGT_Pictures::related( $source_id, $lang );
		$trail   = LMGT_Trail::of( $source_id, $lang );
		// The address, image-text and related-title calls above belong to this draft's cost.
		if ( isset( $report['meter'] ) ) $report['meter'] = LMGT_Meter::sum( $report['meter'], LMGT_Meter::peek() );
		$r = self::call( 'POST', '/draft', array(
			'source_id'       => (int) $source_id,
			'source_url'      => get_permalink( $source_id ),
			'pillar'          => get_post_meta( $source_id, 'rank_math_pillar_content', true ) === 'on' ? 1 : 0, // 2.6.3
			'source_type'     => $src->post_type,
			'author_name'     => (string) get_the_author_meta( 'display_name', $src->post_author ), // 2.20.0: the writer, for the copy's schema
			'source_modified' => $src->post_modified_gmt,
			'source_hash'     => $stale ? '' : $hash,
			'source_stale'    => $stale ? array( 'at' => $src->post_modified_gmt, 'hash' => $hash ) : null,
			'made_with'       => ! empty( $t['made_with'] ) ? $t['made_with'] : LMGT_VERSION,
			'page_template'   => $src->post_type === 'page' ? (string) get_page_template_slug( $source_id ) : '',
			'lang'            => $lang,
			'title'           => $t['title'],
			'content'         => LMGT_Sync::absolute_links( $t['content'] ),
			'excerpt'         => isset( $t['excerpt'] ) ? $t['excerpt'] : '',
			'seo_title'       => isset( $t['seo_title'] ) ? $t['seo_title'] : '',
			'seo_desc'        => isset( $t['seo_desc'] ) ? $t['seo_desc'] : '',
			'slug'            => $seo['slug'],
			'keyword'         => $seo['keyword'],
			'meta'            => $seo['meta'],
			'thumb_url'       => $thumb ? wp_get_attachment_url( $thumb ) : '',
			'thumb_alt'       => isset( $thumb_t['alt'] ) ? $thumb_t['alt'] : '',
			'thumb_caption'   => isset( $thumb_t['caption'] ) ? $thumb_t['caption'] : '',
			'related'         => $related,
			'trail'           => $trail,
			'thumb_later'     => true,
			'report'          => $report,
			'status'          => $status,
			'reviewed'        => $reviewed,
		) + $extra, false );
		if ( is_wp_error( $r ) ) return $r;
		$remote[ $lang ] = array( 'id' => (int) $r['id'], 'url' => (string) $r['url'], 'status' => (string) $r['status'] );
		update_post_meta( $source_id, '_lmgt_remote', wp_slash( $remote ) );
		wp_cache_delete( 'lmgt_peer_langs', 'lmgt' );
		self::refresh_set( $source_id );
		// A new image file goes over in its own, later call; a failure there is retried, the draft stands.
		if ( isset( $r['thumb'] ) && $r['thumb'] === 'later' ) {
			self::call( 'POST', '/thumb', array( 'source_id' => (int) $source_id, 'lang' => $lang, 'thumb_url' => wp_get_attachment_url( $thumb ), 'thumb_alt' => isset( $thumb_t['alt'] ) ? $thumb_t['alt'] : '', 'thumb_caption' => isset( $thumb_t['caption'] ) ? $thumb_t['caption'] : '' ) );
		}
		return (int) $r['id'];
	}

	/**
	 * Copy a local translation to the target (brief 4.6, 4.7). A published one
	 * goes over published, keeps its review status, and stays readable here with
	 * canonical → the target. A draft goes over as a draft and is only tagged.
	 * Nothing is deleted, moved or redirected here.
	 */
	public static function move( $tid ) {
		$tr = get_post( $tid );
		if ( ! $tr || $tr->post_type !== LMGT_CPT ) return new WP_Error( 'lmgt_move', 'Only a translation can be copied.' );
		$sid  = (int) get_post_meta( $tid, '_lmgt_source', true );
		$lang = get_post_meta( $tid, '_lmgt_lang', true );
		if ( LMGT_Nordic::is( $lang ) ) return new WP_Error( 'lmgt_move', 'Swedish, Norwegian and Finnish stay on traveltalk.dk.' );
		$pub  = $tr->post_status === 'publish';
		$src  = get_post( $sid );
		$t    = array(
			'stale'     => $src && get_post_meta( $tid, '_lmgt_source_modified', true ) !== $src->post_modified_gmt,
			'title'     => $tr->post_title,
			'content'   => $tr->post_content,
			'excerpt'   => $tr->post_excerpt,
			'seo_title' => (string) get_post_meta( $tid, 'rank_math_title', true ),
			'seo_desc'  => (string) get_post_meta( $tid, 'rank_math_description', true ),
			'keyword'   => (string) get_post_meta( $tid, 'rank_math_focus_keyword', true ),
			// A copy keeps the version that made it, not the one that copies it.
			'made_with' => get_post_meta( $tid, '_lmgt_made_with', true ) ?: 'before 2.2.2',
		);
		$report = get_post_meta( $tid, '_lmgt_report', true );
		$r = self::send( $sid, $lang, $t, is_array( $report ) ? $report : array(), $pub ? 'publish' : 'draft', $pub || LMGT_Store::is_reviewed( $tid ), $tr->post_name );
		if ( is_wp_error( $r ) ) return $r;
		$remote = self::remote( $sid );
		if ( $pub ) {
			update_post_meta( $tid, '_lmgt_moved_to', esc_url_raw( $remote[ $lang ]['url'] ) );
			if ( ! empty( $remote[ $lang ]['id'] ) ) update_post_meta( $tid, '_lmgt_moved_id', (int) $remote[ $lang ]['id'] );
		} else {
			update_post_meta( $tid, '_lmgt_moved_draft', '1' );
		}
		// send() has already pushed the set. Only a thin copy changes it again: this page now leaves it.
		if ( $pub && $remote[ $lang ]['status'] !== 'publish' ) self::refresh_set( $sid );
		do_action( 'litespeed_purge_post', $tid );
		return $r;
	}

	public static function handle_move() {
		$tid = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		if ( ! current_user_can( 'edit_others_posts' ) || ! check_admin_referer( 'lmgt_move_' . $tid ) ) wp_die( 'Not allowed.' );
		$r = self::move( $tid );
		$msg = is_wp_error( $r ) ? 'Not copied: ' . $r->get_error_message() : 'Copied to ' . self::peer() . ' (#' . $r . ').';
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $msg ), get_edit_post_link( $tid, 'url' ) ) );
		exit;
	}

	public static function handle_link_en() {
		$sid = isset( $_REQUEST['id'] ) ? (int) $_REQUEST['id'] : 0;
		$pid = isset( $_REQUEST['target'] ) ? (int) $_REQUEST['target'] : 0;
		$url = isset( $_REQUEST['target_url'] ) ? esc_url_raw( wp_unslash( $_REQUEST['target_url'] ) ) : '';
		if ( ! current_user_can( 'edit_others_posts' ) || ! check_admin_referer( 'lmgt_link_' . $sid ) ) wp_die( 'Not allowed.' );
		if ( ! $pid && ( ! $url || strpos( $url, self::peer() . '/' ) !== 0 ) ) {
			wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( 'Not linked: give the address of a page on ' . self::peer() . '.' ), get_edit_post_link( $sid, 'url' ) ) );
			exit;
		}
		$r = self::call( 'POST', '/link', array( 'post_id' => $pid, 'url' => $url, 'source_id' => $sid, 'source_url' => get_permalink( $sid ) ), false );
		if ( ! is_wp_error( $r ) ) {
			$remote       = self::remote( $sid );
			$remote['en'] = array( 'id' => (int) $r['id'], 'url' => (string) $r['url'], 'status' => (string) $r['status'] );
			update_post_meta( $sid, '_lmgt_remote', wp_slash( $remote ) );
			self::refresh_set( $sid );
		}
		$msg = is_wp_error( $r ) ? 'Not linked: ' . $r->get_error_message() : 'Linked as the English version: ' . $r['url'];
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $msg ), get_edit_post_link( $sid, 'url' ) ) );
		exit;
	}

	/** Source: a local member or the original changed state; the set may have changed. */
	public static function source_transition( $new, $old, $post ) {
		if ( $new === $old || ( $new !== 'publish' && $old !== 'publish' ) ) return;
		if ( $post->post_type === LMGT_CPT ) self::refresh_set( (int) get_post_meta( $post->ID, '_lmgt_source', true ) );
		elseif ( get_post_meta( $post->ID, '_lmgt_remote', true ) ) self::refresh_set( $post->ID );
	}

	/** A copied .dk translation stays readable; Google is told the .travel page is the one (brief 4.6). */
	public static function moved_canonical( $c ) {
		if ( ! is_singular( LMGT_CPT ) ) return $c;
		$to = get_post_meta( get_queried_object_id(), '_lmgt_moved_to', true );
		return $to ? $to : $c;
	}

	public static function sitemap_skip_moved( $url, $type, $object ) {
		if ( $type === 'post' && $object instanceof WP_Post && get_post_meta( $object->ID, '_lmgt_moved_to', true ) ) return false;
		return $url;
	}

	/** Rank Math counts and pages its sitemap in SQL: leave the moved translations out there too, so no page of it runs short. */
	public static function sitemap_where_moved( $where, $types ) {
		if ( ! in_array( LMGT_CPT, (array) $types, true ) ) return $where;
		global $wpdb;
		return $where . " AND p.ID NOT IN ( SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_lmgt_moved_to' AND meta_value <> '' )";
	}

	/**
	 * A translation moved to .travel (or back): Rank Math keeps its sitemap in a
	 * cache that only a save of the post clears, and a copy saves nothing. Its own
	 * hook queues the clearing for the end of the request; without Rank Math's
	 * watcher loaded, its cache is cleared directly (2.2.18).
	 */
	public static function sitemap_stale( $pid ) {
		static $done = array();
		$type = get_post_type( $pid );
		if ( ! $type || isset( $done[ $type ] ) ) return;
		$done[ $type ] = true;
		if ( has_action( 'rank_math/sitemap/invalidate_object_type' ) ) {
			do_action( 'rank_math/sitemap/invalidate_object_type', 'post', (int) $pid );
		} elseif ( is_callable( array( 'RankMath\\Sitemap\\Cache', 'invalidate_storage' ) ) ) {
			\RankMath\Sitemap\Cache::invalidate_storage( $type );
			\RankMath\Sitemap\Cache::invalidate_storage( '1' );
		}
	}

	/** "Læs på: English · Deutsch …" near the top of a .dk original with published versions (brief 4.8). */
	public static function read_in_row( $content ) {
		if ( ! is_singular( LMGT_Store::types() ) || ! in_the_loop() || ! is_main_query() || LMGT_Store::is_translation( get_the_ID() ) ) return $content;
		$set = self::current_set();
		if ( ! $set ) return $content;
		$links  = array();
		$travel = false;
		foreach ( $set['members'] as $code => $url ) {
			if ( $code === LMGT_Langs::source() ) continue;
			// Versions on .travel open in a new window (G, 28 Oct).
			$away    = strpos( $url, self::peer() . '/' ) === 0;
			$links[] = '<a href="' . esc_url( $away ? self::from_dk( $url ) : $url ) . '" hreflang="' . esc_attr( self::hreflang_code( $code ) ) . '" lang="' . esc_attr( self::hreflang_code( $code ) ) . '"' . ( $away ? ' target="_blank" rel="noopener"' : '' ) . '>' . esc_html( LMGT_Langs::get( $code )['native'] ) . '</a>';
			$travel  = $travel || $away;
		}
		if ( ! $links ) return $content;
		// "Read in" for readers who do not read Danish; the site named when the versions are there (2.2.16).
		$row = '<p class="lmgt-read-in" style="font-size:.95em">Læs på · <span lang="en">Read in</span>: ' . implode( ' · ', $links ) . ( $travel ? ' <span lang="en">– traveltalk.travel</span>' : '' ) . '</p>';
		// After the first paragraph: inside the first screen on mobile.
		$pos = strpos( $content, '</p>' );
		return $pos === false ? $row . $content : substr( $content, 0, $pos + 4 ) . $row . substr( $content, $pos + 4 );
	}

	/**
	 * "Leer en: English · Deutsch · Dansk (original)" on a translation on the
	 * target (2.2.3), in the page's language: every other published version, the
	 * original marked. Under the family line, so near the top on mobile. A thin
	 * translation is in no set, so its own row offers at least the original.
	 */
	public static function read_in_row_target( $content ) {
		if ( ! is_singular( LMGT_CPT ) || ! in_the_loop() || ! is_main_query() ) return $content;
		$id   = get_the_ID();
		$cur  = get_post_meta( $id, '_lmgt_lang', true );
		$dk   = get_post_meta( $id, '_lmgt_remote_url', true );
		$set  = LMGT_Front::cluster();
		// The original: the .dk article for a bridge translation, else this site's own (English) page.
		$orig = $dk ? 'da' : LMGT_Langs::source();
		if ( ! $set ) $set = $dk ? array( 'da' => $dk ) : array( $orig => get_permalink( (int) get_post_meta( $id, '_lmgt_source', true ) ) );
		$t = array(
			'en' => array( 'Read in', 'original' ), 'de' => array( 'Lesen auf', 'Original' ), 'fr' => array( 'Lire en', 'original' ),
			'es' => array( 'Leer en', 'original' ), 'it' => array( 'Leggi in', 'originale' ), 'pt' => array( 'Ler em', 'original' ),
			'sv' => array( 'Läs på', 'original' ), 'nb' => array( 'Les på', 'original' ), 'fi' => array( 'Lue kielellä', 'alkuperäinen' ),
		);
		$w     = isset( $t[ $cur ] ) ? $t[ $cur ] : $t['en'];
		$links = array();
		foreach ( $set as $code => $url ) {
			$l = LMGT_Langs::get( $code );
			if ( $code === $cur || ! $l || ! $url ) continue;
			$h       = self::hreflang_code( $code );
			$links[] = '<a href="' . esc_url( $url ) . '" hreflang="' . esc_attr( $h ) . '" lang="' . esc_attr( $h ) . '">' . esc_html( $l['native'] ) . '</a>' . ( $code === $orig ? ' (' . esc_html( $w[1] ) . ')' : '' );
		}
		if ( ! $links ) return $content;
		$row = '<p class="lmgt-read-in" style="font-size:.95em">' . esc_html( $w[0] ) . ': ' . implode( ' · ', $links ) . '</p>';
		$pos = strpos( $content, '</p>' );
		return $pos === false ? $row . $content : substr( $content, 0, $pos + 4 ) . $row . substr( $content, $pos + 4 );
	}

	/** Untranslated article: the switcher sends the reader to the language's front page on the target (brief 4.8). */
	public static function peer_lang_home( $code ) {
		$l = LMGT_Langs::get( $code );
		if ( ! $l || ! self::is_source() || LMGT_Nordic::is( $code ) || ! self::peer_has( $code ) ) return '';
		if ( $code === 'en' ) return trailingslashit( self::peer() );
		return trailingslashit( self::peer() ) . ( $code === 'nb' ? 'nb' : $l['prefix'] ) . '/';
	}

	/**
	 * Source: does the target have at least one published version in $code?
	 * Its language front page answers 404 until then, so nothing links there.
	 * Read from the .dk originals' _lmgt_remote, never from the peer.
	 */
	public static function peer_has( $code ) {
		$langs = wp_cache_get( 'lmgt_peer_langs', 'lmgt' );
		if ( ! is_array( $langs ) ) {
			global $wpdb;
			$langs = array();
			foreach ( $wpdb->get_col( "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_lmgt_remote'" ) as $v ) {
				foreach ( (array) maybe_unserialize( $v ) as $lang => $r ) {
					if ( is_array( $r ) && isset( $r['status'] ) && $r['status'] === 'publish' ) $langs[ $lang ] = true;
				}
			}
			wp_cache_set( 'lmgt_peer_langs', $langs, 'lmgt', 300 );
		}
		return ! empty( $langs[ $code ] );
	}

	// ---- Source: edit screen box ---------------------------------------------

	public static function box() {
		foreach ( LMGT_Store::types( true ) as $t ) {
			add_meta_box( 'lmgt_bridge', 'traveltalk.travel', array( __CLASS__, 'box_html' ), $t, 'side', 'high' );
		}
	}

	public static function box_html( $post ) {
		if ( ! empty( $_GET['lmgt_msg'] ) ) echo '<p><strong>' . esc_html( wp_unslash( $_GET['lmgt_msg'] ) ) . '</strong></p>';
		if ( $post->post_type === LMGT_CPT ) {
			$to = get_post_meta( $post->ID, '_lmgt_moved_to', true );
			if ( $to ) {
				$live = LMGT_Migrate::target_url( $post->ID );
				echo $live ? '<p>Copied. This address now sends readers and Google to <a href="' . esc_url( $live ) . '">' . esc_html( $live ) . '</a> (301).</p>' : '<p>Copied. Canonical → <a href="' . esc_url( $to ) . '">' . esc_html( $to ) . '</a>. Not live on traveltalk.travel, so this copy is still shown here.</p>';
			} elseif ( get_post_meta( $post->ID, '_lmgt_moved_draft', true ) ) {
				echo '<p>Moved to .travel as a draft. Finish it there.</p>';
			} else {
				$url = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_move&id=' . $post->ID ), 'lmgt_move_' . $post->ID );
				echo '<p><a class="button" href="' . esc_url( $url ) . '">Copy to traveltalk.travel</a></p>';
				if ( get_post_meta( $post->ID, '_lmgt_lang', true ) === 'en' ) echo '<p class="description">Check the original\'s box first for an existing English piece on .travel.</p>';
			}
			return;
		}
		$remote = self::remote( $post->ID );
		if ( $remote ) {
			echo '<ul>';
			foreach ( $remote as $lang => $r ) {
				echo '<li>' . esc_html( LMGT_Langs::get( $lang )['native'] ) . ' – ' . esc_html( $r['status'] ) . ': <a href="' . esc_url( $r['url'] ) . '">' . esc_html( wp_parse_url( $r['url'], PHP_URL_PATH ) ) . '</a></li>';
			}
			echo '</ul>';
		}
		if ( isset( $remote['en'] ) || $post->post_status !== 'publish' ) return;
		// English: extend, never duplicate (brief 4.5). A person confirms.
		// By address too: the title search finds nothing when the names differ (Østrig, Austria).
		echo '<p><label>Link an English page on .travel by its address:<br><input type="url" name="target_url" form="lmgt-link-url" style="width:100%" placeholder="' . esc_attr( self::peer() ) . '/destinations/…"></label> <button class="button" form="lmgt-link-url" onclick="return confirm(\'Same subject and same scope?\')">Link as English</button></p>';
		add_action( 'admin_footer', function () use ( $post ) {
			echo '<form id="lmgt-link-url" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="lmgt_link_en"><input type="hidden" name="id" value="' . (int) $post->ID . '">' . wp_nonce_field( 'lmgt_link_' . $post->ID, '_wpnonce', true, false ) . '</form>';
		} );
		$hits = self::call( 'GET', '/match', array( 'q' => self::subject( $post ) ), false );
		if ( is_wp_error( $hits ) ) {
			echo '<p class="description">English check unavailable: ' . esc_html( $hits->get_error_message() ) . '</p>';
			return;
		}
		if ( ! $hits ) {
			echo '<p class="description">No English piece on .travel matches by title. Link one by address above, or translate into English as new.</p>';
			return;
		}
		echo '<p><strong>Same subject and scope on .travel?</strong> Link it instead of translating. Overlapping but different scope: do not link.</p><ul>';
		foreach ( $hits as $h ) {
			if ( $h['linked_to'] ) continue;
			$url = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_link_en&id=' . $post->ID . '&target=' . (int) $h['id'] ), 'lmgt_link_' . $post->ID );
			echo '<li><a href="' . esc_url( $h['url'] ) . '" target="_blank">' . esc_html( $h['title'] ) . '</a> – <a href="' . esc_url( $url ) . '" onclick="return confirm(\'Same subject and same scope?\')">link as English</a></li>';
		}
		echo '</ul>';
	}

	/** Search words for the match: the title without Danish filler and numbers. */
	public static function subject( $post ) {
		$w = preg_split( '/[\s:–—,.!?]+/u', mb_strtolower( wp_strip_all_tags( $post->post_title ) ) );
		$stop = array( 'de', 'den', 'det', 'og', 'i', 'på', 'til', 'med', 'for', 'en', 'et', 'bedste', 'guide', 'af', 'om', 'til', 'hvad', 'du', 'skal', 'se' );
		$w = array_filter( $w, function ( $x ) use ( $stop ) { return $x !== '' && ! is_numeric( $x ) && ! in_array( $x, $stop, true ); } );
		return implode( ' ', array_slice( array_values( $w ), 0, 3 ) );
	}

	// ---- Status page ---------------------------------------------------------

	public static function page() {
		$code = '';
		$note = '';
		if ( isset( $_POST['lmgt_bridge_do'] ) && check_admin_referer( 'lmgt_bridge' ) ) {
			$do = $_POST['lmgt_bridge_do'];
			if ( $do === 'retry' ) self::retry_queue();
			if ( $do === 'recon' && self::is_source() ) self::reconcile();
			if ( in_array( $do, array( 'code', 'pair', 'unpair' ), true ) && current_user_can( 'manage_options' ) ) {
				if ( $do === 'code' ) {
					$r = self::make_code();
					is_wp_error( $r ) ? $note = $r->get_error_message() : $code = $r;
				} elseif ( $do === 'pair' ) {
					$r    = self::use_code( isset( $_POST['lmgt_code'] ) ? wp_unslash( $_POST['lmgt_code'] ) : '' );
					$note = is_wp_error( $r ) ? 'Not paired: ' . $r->get_error_message() : 'Paired.';
				} else {
					self::unpair();
					$note = 'Unpaired on this site. Unpair on ' . self::peer() . ' too.';
				}
			}
		}
		echo '<div class="wrap"><h1>Translator bridge</h1>';
		echo '<p>Role: <strong>' . esc_html( self::role() ) . '</strong> · Peer: <strong>' . esc_html( self::peer() ?: '(not set)' ) . '</strong> · User: <strong>' . esc_html( self::peer_user() ?: '(not set)' ) . '</strong> · Application password: <strong>' . ( self::peer_pass() !== '' ? 'set' : 'missing' ) . '</strong></p>';
		$old = (array) get_option( 'lmgt_queue', array() );
		if ( $old ) echo '<p class="description">' . count( $old ) . ' unsent call(s) left from 2.0.0 (old format, not resent). The pipeline sends them again when the article is re-translated.</p>';
		$test = self::call( 'GET', '/ping', array(), false );
		echo '<p>Connection: ' . ( is_wp_error( $test ) ? '<strong style="color:#b32d2e">' . esc_html( $test->get_error_message() ) . '</strong>' : '<strong style="color:#008a20">OK – logged in on the peer as ' . esc_html( $test['user'] ) . ', role ' . esc_html( $test['role'] ) . '</strong>' ) . '</p>';
		echo '<form method="post">';
		wp_nonce_field( 'lmgt_bridge' );
		echo '<button class="button" name="lmgt_bridge_do" value="retry">Retry queue now</button> ';
		if ( self::is_source() ) echo '<button class="button" name="lmgt_bridge_do" value="recon">Reconcile now</button>';
		echo '</form>';
		if ( current_user_can( 'manage_options' ) ) {
			echo '<h2>Pairing</h2>';
			if ( $note ) echo '<p><strong>' . esc_html( $note ) . '</strong></p>';
			if ( defined( 'LMGT_PEER_PASS' ) ) {
				echo '<p class="description">The password is set in wp-config.php, which wins over pairing.</p>';
			} elseif ( $code ) {
				echo '<p>Copy this code and paste it on <strong>' . esc_html( self::peer() ) . '</strong> → Translator → Bridge → Pair, within 15 minutes. It works once.</p>';
				echo '<textarea readonly rows="4" style="width:100%;font-family:monospace" onclick="this.select()">' . esc_textarea( $code ) . '</textarea>';
			} else {
				echo '<form method="post">';
				wp_nonce_field( 'lmgt_bridge' );
				echo '<p>1. On one site: <button class="button" name="lmgt_bridge_do" value="code">Create pairing code</button></p>';
				echo '<p>2. On the other site, paste it here: <input type="text" name="lmgt_code" class="regular-text" autocomplete="off"> <button class="button button-primary" name="lmgt_bridge_do" value="pair">Pair</button></p>';
				if ( get_option( self::PAIR_OPT ) ) echo '<p><button class="button" name="lmgt_bridge_do" value="unpair" onclick="return confirm(\'Stop the link from this site?\')">Unpair</button> <span class="description">Paired ' . esc_html( get_option( self::PAIR_OPT )['at'] ) . ' UTC.</span></p>';
				echo '</form>';
			}
		}
		$q = (array) get_option( self::QUEUE_OPT, array() );
		echo '<h2>Queue (' . count( $q ) . ')</h2><ul>';
		foreach ( $q as $i ) echo '<li>' . esc_html( $i['method'] . ' ' . $i['path'] . ' – tries ' . $i['tries'] . ' – ' . $i['error'] ) . '</li>';
		echo '</ul>';
		if ( self::is_source() ) {
			$r = get_option( self::RECON_OPT, array() );
			echo '<h2>Reconciliation</h2><p>' . esc_html( isset( $r['at'] ) ? $r['at'] . ' UTC' : 'not run yet' ) . ( isset( $r['error'] ) ? ' – ' . esc_html( $r['error'] ) : '' ) . '</p><ul>';
			foreach ( isset( $r['mismatches'] ) ? $r['mismatches'] : array() as $m ) echo '<li>' . esc_html( $m ) . '</li>';
			echo '</ul>';
		}
		echo '<h2>Log</h2><pre style="max-height:400px;overflow:auto;background:#fff;padding:8px">' . esc_html( implode( "\n", array_reverse( (array) get_option( self::LOG_OPT, array() ) ) ) ) . '</pre></div>';
	}

	// ---- Reconciliation ------------------------------------------------------

	/** Once a day: compare the target's members with what .dk has stored. Mismatches are reported, not fixed. */
	public static function reconcile() {
		$theirs = self::call( 'GET', '/sets', array(), false );
		$out    = array( 'at' => current_time( 'mysql', true ), 'mismatches' => array() );
		if ( is_wp_error( $theirs ) ) {
			$out['error'] = $theirs->get_error_message();
			update_option( self::RECON_OPT, $out, false );
			return;
		}
		global $wpdb;
		$ours = array();
		foreach ( $wpdb->get_col( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_lmgt_remote'" ) as $sid ) {
			$ours[ (int) $sid ] = self::remote( $sid );
		}
		foreach ( array_unique( array_merge( array_keys( $ours ), array_map( 'intval', array_keys( $theirs ) ) ) ) as $sid ) {
			$a = isset( $ours[ $sid ] ) ? $ours[ $sid ] : array();
			$b = isset( $theirs[ $sid ] ) ? $theirs[ $sid ] : array();
			foreach ( array_unique( array_merge( array_keys( $a ), array_keys( $b ) ) ) as $lang ) {
				$x = isset( $a[ $lang ] ) ? $a[ $lang ]['url'] . ' ' . $a[ $lang ]['status'] : '(none)';
				$y = isset( $b[ $lang ] ) ? $b[ $lang ]['url'] . ' ' . $b[ $lang ]['status'] : '(none)';
				if ( $x !== $y ) $out['mismatches'][] = "#$sid $lang: .dk has $x; .travel has $y";
			}
			if ( isset( $ours[ $sid ] ) && $b ) {
				$set = get_post_meta( $sid, '_lmgt_set', true );
				if ( is_array( $set ) && ! empty( $set['members'][ LMGT_Langs::source() ] ) && $set['members'][ LMGT_Langs::source() ] !== get_permalink( $sid ) ) {
					$out['mismatches'][] = "#$sid: original's address changed since the set was pushed";
				}
			}
		}
		self::log( 'reconcile: ' . count( $out['mismatches'] ) . ' mismatches' );
		update_option( self::RECON_OPT, $out, false );
	}
}
