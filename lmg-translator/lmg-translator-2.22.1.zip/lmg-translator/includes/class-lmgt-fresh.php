<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.20.0 (G, 23 Nov 2026): a translation counts as a new piece of content on
 * the site where it goes live.
 *
 *   - Its publish date is the moment it goes live, not the day its draft was
 *     made or saved last. Scheduled translations keep the time they were set for.
 *     Stored once in _lmgt_live_at; a translation that is taken down and put
 *     back keeps its first go-live date.
 *   - Its "last updated" date moves with it, and Rank Math's sitemap cache is
 *     cleared, so the sitemap shows a fresh lastmod at once.
 *   - On traveltalk.travel, translated destination guides (pages) join the
 *     feed and the latest-posts lists too, not only translated articles.
 *   - On the first load after the update, every translation that is already
 *     live gets its current date recorded as its go-live date; nothing is re-dated.
 */
class LMGT_Fresh {

	public static function boot() {
		add_action( 'transition_post_status', array( __CLASS__, 'go_live' ), 1, 3 );
		add_action( 'admin_init', array( __CLASS__, 'mark_existing' ) );
		add_action( 'pre_get_posts', array( __CLASS__, 'hubs_in_lists' ), 21 );
	}

	public static function on() {
		return (bool) get_option( 'lmgt_fresh_dates', 1 );
	}

	public static function go_live( $new, $old, $post ) {
		if ( ! self::on() || $new !== 'publish' || in_array( $old, array( 'publish', 'future' ), true ) ) return;
		if ( ! $post instanceof WP_Post || $post->post_type !== LMGT_CPT ) return;
		if ( get_post_meta( $post->ID, '_lmgt_live_at', true ) ) return;
		global $wpdb;
		$local = current_time( 'mysql' );
		$gmt   = current_time( 'mysql', true );
		$wpdb->update( $wpdb->posts, array( 'post_date' => $local, 'post_date_gmt' => $gmt, 'post_modified' => $local, 'post_modified_gmt' => $gmt ), array( 'ID' => $post->ID ) );
		$post->post_date = $local; $post->post_date_gmt = $gmt; $post->post_modified = $local; $post->post_modified_gmt = $gmt;
		update_post_meta( $post->ID, '_lmgt_live_at', $gmt );
		clean_post_cache( $post->ID );
		if ( method_exists( 'LMGT_Bridge', 'sitemap_stale' ) ) LMGT_Bridge::sitemap_stale( $post->ID );
		do_action( 'litespeed_purge_url', home_url( '/feed/' ) );
		do_action( 'litespeed_purge_url', home_url( '/' ) );
	}

	/** One time: translations live before 2.20.0 keep the date they have, recorded as their go-live date. */
	public static function mark_existing() {
		if ( get_option( 'lmgt_fresh_marked' ) ) return;
		global $wpdb;
		$wpdb->query( $wpdb->prepare(
			"INSERT INTO {$wpdb->postmeta} (post_id, meta_key, meta_value)
			 SELECT p.ID, '_lmgt_live_at', p.post_date_gmt FROM {$wpdb->posts} p
			 LEFT JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_lmgt_live_at'
			 WHERE p.post_type = %s AND p.post_status IN ('publish','private') AND m.meta_id IS NULL",
			LMGT_CPT
		) );
		update_option( 'lmgt_fresh_marked', LMGT_VERSION, false );
	}

	/** .travel: the feed and latest lists take translated guides (pages) as well as translated articles. */
	public static function hubs_in_lists( $q ) {
		if ( ! LMGT_Bridge::is_target() || ! get_option( 'lmgt_front_translations', 1 ) || ! get_option( 'lmgt_feed_hubs', 1 ) ) return;
		$types = (array) $q->get( 'post_type' );
		if ( ! in_array( LMGT_CPT, $types, true ) || ! in_array( 'post', $types, true ) ) return;
		$meta = (array) $q->get( 'meta_query' );
		$hit  = false;
		foreach ( $meta as $i => $m ) {
			if ( ! is_array( $m ) || ! isset( $m[1]['relation'], $m[1][0]['key'] ) || $m[1][0]['key'] !== '_lmgt_lang' ) continue;
			$meta[ $i ] = array(
				'relation' => 'OR',
				array( 'key' => '_lmgt_lang', 'compare' => 'NOT EXISTS' ),
				array( 'key' => '_lmgt_lang', 'value' => 'en' ),
			);
			$hit = true;
		}
		if ( $hit ) $q->set( 'meta_query', $meta );
	}
}
