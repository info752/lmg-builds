<?php
/**
 * 2.19.0 (G, 22 Nov 2026: "set up a few simple goals … be the authority, enter Google top 10, make it a
 * pillar, make it a supportive post to this pillar"). One goal per article, chosen in the first step:
 *
 *   pillar   long and complete, a table of contents, many links in from the posts that support it.
 *   support  belongs to one pillar: links up to it, has its own narrower keyword.
 *   top10    Rank Math green, and a content check against what the pages now in Google's top 10 cover.
 *
 * Being the authority (facts from the text, sources, depth) is built into every step for every article,
 * so it is not a choice here. Nothing in this file writes into the text: the goal and the pillar are
 * stored as post meta (_lmgt_goal, _lmgt_goal_pillar); Rank Math's own "pillar content" switch is set
 * for a pillar.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class LMGT_Goals {

	const LABELS = array(
		''        => 'No goal set',
		'pillar'  => 'Pillar – the main page on the subject',
		'support' => 'Supporting post – belongs to a pillar',
		'top10'   => 'Top 10 on Google',
	);

	public static function boot() {
		add_action( 'admin_post_lmgt_goal', array( __CLASS__, 'handle' ) );
		add_action( 'admin_post_lmgt_toc', array( __CLASS__, 'handle_toc' ) ); // 2.21.0
		add_action( 'admin_post_lmgt_goal_fix', array( __CLASS__, 'handle_fix' ) ); // 2.21.0
	}

	public static function get( $id ) {
		$g = (string) get_post_meta( (int) $id, '_lmgt_goal', true );
		return isset( self::LABELS[ $g ] ) ? $g : '';
	}

	public static function pillar_of( $id ) {
		return (int) get_post_meta( (int) $id, '_lmgt_goal_pillar', true );
	}

	/** Pages and posts that can be a pillar: chosen as pillar here, or marked pillar in Rank Math. */
	public static function pillars( $not = 0 ) {
		$ids = get_posts( array(
			'post_type' => array( 'post', 'page' ), 'post_status' => array( 'publish', 'draft', 'future' ), 'posts_per_page' => 300,
			'fields' => 'ids', 'no_found_rows' => true, 'post__not_in' => array( (int) $not ), 'lmgt_all' => true,
			'meta_query' => array( 'relation' => 'OR',
				array( 'key' => '_lmgt_goal', 'value' => 'pillar' ),
				array( 'key' => 'rank_math_pillar_content', 'value' => 'on' ),
			),
		) );
		$out = array();
		foreach ( $ids as $pid ) $out[ $pid ] = get_the_title( $pid );
		asort( $out );
		return $out;
	}

	/** The posts that have chosen $pillar as their pillar. */
	public static function supporters( $pillar ) {
		return get_posts( array(
			'post_type' => array( 'post', 'page' ), 'post_status' => 'any', 'posts_per_page' => 200, 'fields' => 'ids', 'no_found_rows' => true, 'lmgt_all' => true,
			'meta_query' => array( array( 'key' => '_lmgt_goal', 'value' => 'support' ), array( 'key' => '_lmgt_goal_pillar', 'value' => (int) $pillar ) ),
		) );
	}

	/** Does $html link to post $to? Its address, its short address or its ?p= form. */
	public static function links_to( $html, $to ) {
		$u = untrailingslashit( (string) get_permalink( $to ) );
		if ( $u !== '' && stripos( $html, $u ) !== false ) return true;
		$path = untrailingslashit( (string) wp_parse_url( $u, PHP_URL_PATH ) );
		if ( $path !== '' && $path !== '/' && preg_match( '~href=["\']' . preg_quote( $path, '~' ) . '/?["\'#?]~i', $html ) ) return true;
		return (bool) preg_match( '#[?&]p=' . (int) $to . '\b#', $html );
	}

	private static function toc( $html ) {
		if ( preg_match( '#wp:rank-math/toc-block|ez-toc|lwptoc|wp:yoast-seo/table-of-contents|class="[^"]*\btoc\b#i', $html ) ) return true;
		return preg_match_all( '#<a\s[^>]*href=["\']\#[^"\']+["\']#i', $html ) >= 3; // a list of jumps to its own sections
	}

	/** 2.21.0: the action for a check, as a small button (admin-post action on this post). */
	private static function act( $id, $action, $label, $extra = '', $primary = false ) {
		$u = wp_nonce_url( admin_url( 'admin-post.php?action=' . $action . '&post=' . (int) $id . $extra ), $action . '_' . (int) $id );
		return '<a class="button' . ( $primary ? ' button-primary' : ' button-small' ) . '" href="' . esc_url( $u ) . '">' . esc_html( $label ) . '</a>';
	}

	private static function edit_link( $pid, $label = '' ) {
		return '<a href="' . esc_url( get_edit_post_link( $pid, 'url' ) ) . '" target="_blank">' . esc_html( $label !== '' ? $label : html_entity_decode( get_the_title( $pid ), ENT_QUOTES, 'UTF-8' ) ) . '</a>';
	}

	/**
	 * 2.21.0 (G, 23 Nov: "think the user is new … where, and is it already taken care of?"; "you can not do anything in 1"):
	 * each check is [state, what, how, button]. state: true ✓, false ✗ (to do), 'hint' ○ (advice, not counted),
	 * 'later' ○ (counted later). how says what to do, where, and whether another step does it. The first ✗ with a
	 * button becomes the step's main button.
	 */
	public static function row( $n, $post, array $links ) {
		$id    = $post->ID;
		$goal  = self::get( $id );
		$check = array();
		$html  = $post->post_content;
		$ai    = LMGT_Engines::ai_available();
		$pub   = $post->post_status === 'publish';
		if ( $goal === 'pillar' ) {
			$w   = LMGT_Store::words( $post );
			$min = max( 100, (int) get_option( 'lmgt_min_words_pillar', 1500 ) );
			$sup = self::supporters( $id );
			$up  = array_filter( $sup, function ( $s ) use ( $id ) { return self::links_to( (string) get_post_field( 'post_content', $s ), $id ); } );
			$check[] = array( $w >= $min, $w . ' words (a pillar needs ' . $min . ' or more)',
				'Too short for the main page on the subject. Click Find content gaps: Claude suggests the missing sections, you tick the ones to write and read them before they go in. Step 2 Deepen shows the same button.',
				$ai ? self::act( $id, 'lmgt_gaps', 'Find content gaps' ) : '' );
			$own = strpos( $html, '<!-- lmgt:toc -->' ) !== false;
			$check[] = array( self::toc( $html ), 'A table of contents',
				'Not added by any other step, and marking the page as pillar does not add one. Click Insert the table of contents: it goes in after the intro, before the first section, and lists the section headings with jump links. The previous version stays under Revisions.',
				self::toc( $html ) ? ( $own ? self::act( $id, 'lmgt_toc', 'Update the table of contents' ) : '' ) : self::act( $id, 'lmgt_toc', 'Insert the table of contents' ) );
			if ( ! $pub ) {
				$check[] = array( 'later', 'Pages linking here: counted once the page is published', 'A pillar needs 5 or more. After publishing, click Propose links to this page here.', '' );
			} else {
				$check[] = array( (int) $links['in'] >= 5, (int) $links['in'] . ' other page(s) link here (a pillar needs 5 or more)',
					'Click Propose links to this page: Claude finds sentences in related articles that can link here, and you tick which go in (the list appears in the Links step). Run it again until 5 or more pages link here.',
					$ai ? self::act( $id, 'lmgt_links_in', 'Propose links to this page' ) : '' );
			}
			$check[] = array( get_post_meta( $id, 'rank_math_pillar_content', true ) === 'on', 'Marked as pillar in Rank Math',
				'Rank Math\'s "pillar content" switch is off. Click Mark as pillar; it changes nothing in the text.',
				self::act( $id, 'lmgt_goal_fix', 'Mark as pillar', '&do=flag' ) );
			if ( ! $sup ) {
				$cand = self::support_candidates( $id );
				$how  = 'Advice, not required. A pillar gets stronger when 3 to 10 narrower posts belong to it and link up to it. Open a related post, choose "Supporting post" in its step 1 and pick this pillar.';
				$btn  = '';
				if ( $cand ) {
					$how .= ' Or tick related posts here and make them supporting posts in one click (their text does not change):<ul style="margin:4px 0 0 0;list-style:none">';
					foreach ( $cand as $c ) $how .= '<li><label><input type="checkbox" class="lmgt-suppick" value="' . (int) $c . '" checked> </label>' . self::edit_link( $c ) . '</li>';
					$how .= '</ul>';
					$base = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_goal_fix&do=support&post=' . $id ), 'lmgt_goal_fix_' . $id );
					$btn  = '<a class="button button-small lmgt-supacc" data-base="' . esc_url( $base ) . '" href="' . esc_url( $base . '&ids=' . implode( '-', $cand ) ) . '">Make the ticked supporting posts</a>'
						. '<script>(function(){document.addEventListener("change",function(e){if(!e.target.classList||!e.target.classList.contains("lmgt-suppick"))return;var on=[].slice.call(document.querySelectorAll(".lmgt-suppick")).filter(function(x){return x.checked}).map(function(x){return x.value});[].forEach.call(document.querySelectorAll(".lmgt-supacc"),function(b){b.href=b.getAttribute("data-base")+"&ids="+(on.length?on.join("-"):"none");b.textContent=on.length?"Make the "+on.length+" ticked supporting posts":"Tick at least one post";});});})();</script>';
				}
				$check[] = array( 'hint', 'No supporting posts have chosen this pillar yet', $how, $btn );
			} else {
				$miss = array_diff( $sup, $up );
				$how  = 'Each supporting post should link up to this pillar. Open these and click Propose links in their Links step (the pillar is always proposed first): ';
				$how .= implode( ', ', array_map( function ( $s ) { return self::edit_link( $s ); }, array_slice( $miss, 0, 8 ) ) ) . '.';
				$check[] = array( ! $miss, count( $sup ) . ' supporting post(s) belong to this pillar, ' . count( $up ) . ' link up to it', $how, '' );
			}
		} elseif ( $goal === 'support' ) {
			$p = self::pillar_of( $id );
			if ( ! $p || ! get_post( $p ) ) {
				$check[] = array( false, 'No pillar chosen', 'Open "Change the goal" just below, pick the pillar in the second list and click Save the goal.', '' );
			} else {
				$kw  = mb_strtolower( trim( (string) strtok( (string) get_post_meta( $id, 'rank_math_focus_keyword', true ), ',' ) ) );
				$pkw = mb_strtolower( trim( (string) strtok( (string) get_post_meta( $p, 'rank_math_focus_keyword', true ), ',' ) ) );
				$check[] = array( true, 'Pillar: ' . html_entity_decode( get_the_title( $p ), ENT_QUOTES, 'UTF-8' ), '', '' );
				$check[] = array( self::links_to( $html, $p ), 'Links up to the pillar',
					'Click Propose links: the pillar is always the first link proposed, and you tick which go in. The Links step shows the same button.',
					$ai ? self::act( $id, 'lmgt_links_add', 'Propose links' ) : '' );
				$check[] = array( $kw !== '' && $kw !== $pkw, 'Its own keyword' . ( $kw !== '' ? ' ("' . $kw . '")' : '' ) . ', narrower than the pillar\'s' . ( $pkw !== '' ? ' ("' . $pkw . '")' : '' ),
					$kw === '' ? 'No focus keyword yet. Click the Rank Math icon at the top right of the editor and type it under Focus Keyword, then Update.' : 'Same keyword as the pillar, so the two compete in Google. In Rank Math (icon at the top right of the editor) change the focus keyword to something narrower, for example "' . $pkw . ' + the angle of this post", then Update.', '' );
				$check[] = array( self::links_to( (string) get_post_field( 'post_content', $p ), $id ), 'The pillar links down to this post',
					'Click Propose links from the pillar: Claude looks for a sentence in the pillar (and in related posts) that can link here; you tick which go in.',
					$ai && $pub ? self::act( $id, 'lmgt_links_in', 'Propose links from the pillar' ) : self::edit_link( $p, 'Open the pillar' ) );
			}
		} elseif ( $goal === 'top10' ) {
			$score = (int) get_post_meta( $id, 'rank_math_seo_score', true );
			$g     = get_post_meta( $id, '_lmgt_gaps', true );
			$check[] = array( $score >= 81, 'Rank Math score ' . ( $score ? $score : '–' ) . '/100 (green: 81 or more)', $score ? 'Work through the red ✗ in the SEO step below; each says where to fix it. Press Update afterwards: Rank Math works the score out then.' : 'Not worked out yet: press Update once.', '' );
			$check[] = array( is_array( $g ) && ! empty( $g['top10'] ), 'Compared with what the top 10 cover',
				'Click Compare with the top 10: Claude lists what the pages now in Google\'s top 10 cover that this text does not; you tick what to write.',
				$ai ? self::act( $id, 'lmgt_gaps', 'Compare with the top 10', '&top10=1' ) : '' );
			if ( $pub ) $check[] = array( (int) $links['in'] >= 2, (int) $links['in'] . ' other page(s) link here (2 or more)',
				'Click Propose links to this page: Claude finds sentences in related articles that can link here; you tick which go in.',
				$ai ? self::act( $id, 'lmgt_links_in', 'Propose links to this page' ) : '' );
		}
		$txt  = '<strong>' . esc_html( self::LABELS[ $goal ] ) . '</strong>';
		$bad  = 0;
		$main = '';
		if ( $goal === '' ) $txt .= '<p class="description" style="margin:4px 0 0">Optional. A goal adds the checks for that kind of page here (pillar, supporting post, Google top 10). Open "Choose a goal" below.</p>';
		if ( $check ) {
			$txt .= '<ul style="margin:4px 0 0;list-style:none">';
			foreach ( $check as $c ) {
				if ( $c[0] === true ) { $txt .= '<li><span style="color:#008a20">✓</span> ' . esc_html( $c[1] ) . ( isset( $c[3] ) && $c[3] !== '' && strpos( $c[3], 'lmgt_toc' ) !== false ? ' ' . $c[3] : '' ) . '</li>'; continue; }
				$soft = $c[0] === 'hint' || $c[0] === 'later';
				if ( ! $soft ) { $bad++; if ( $main === '' && $c[3] !== '' && strpos( $c[3], 'class="button' ) !== false && strpos( $c[3], 'lmgt-supacc' ) === false ) $main = $c[3]; }
				$txt .= '<li style="margin:0 0 8px">' . ( $soft ? '<span style="color:#996800">○</span> ' : '<span style="color:#b32d2e">✗</span> ' ) . '<strong>' . esc_html( $c[1] ) . '</strong>'
					. ( $c[2] !== '' ? '<br><span class="description">' . ( strpos( $c[2], '<' ) !== false ? $c[2] : esc_html( $c[2] ) ) . '</span>' : '' )
					. ( $c[3] !== '' ? '<br>' . $c[3] : '' ) . '</li>';
			}
			$txt .= '</ul>';
		}
		$txt .= self::form( $post, $goal );
		// The step's main button: the first open check's own action, as the big button on the right.
		$main = $main !== '' ? str_replace( 'button-small', 'button-primary', $main ) : '';
		LMGT_Steps::row( $n, 'Goal', $goal === '' ? 'none' : ( $bad ? 'todo' : 'done' ), $txt, $main );
	}

	/** 2.21.0: posts that could support $pillar – no goal yet, same category or naming its keyword. At most 6. */
	public static function support_candidates( $pillar ) {
		$kw   = trim( (string) strtok( (string) get_post_meta( $pillar, 'rank_math_focus_keyword', true ), ',' ) );
		$cats = wp_get_post_categories( $pillar );
		$base = array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 12, 'fields' => 'ids', 'no_found_rows' => true, 'post__not_in' => array( (int) $pillar ),
			'meta_query' => array( array( 'key' => '_lmgt_goal', 'compare' => 'NOT EXISTS' ) ) );
		$ids  = array();
		if ( $kw !== '' ) $ids = get_posts( $base + array( 's' => $kw, 'orderby' => 'relevance' ) );
		if ( count( $ids ) < 6 && $cats ) $ids = array_merge( $ids, get_posts( $base + array( 'category__in' => $cats, 'orderby' => 'modified' ) ) );
		return array_slice( array_values( array_unique( array_map( 'intval', $ids ) ) ), 0, 6 );
	}

	/** 2.21.0: the language words for the table of contents title. */
	const TOC_TITLE = array( 'da' => 'Indhold', 'en' => 'Contents', 'de' => 'Inhalt', 'sv' => 'Innehåll', 'nb' => 'Innhold', 'fi' => 'Sisältö', 'fr' => 'Sommaire', 'es' => 'Contenido', 'it' => 'Indice', 'nl' => 'Inhoud', 'pt' => 'Índice', 'pl' => 'Spis treści', 'ja' => '目次', 'zh' => '目录', 'ko' => '목차' );

	/**
	 * 2.21.0: a table of contents built from the text's own H2 headings (and H3 under them when there are fewer
	 * than 4 H2), put in after the intro as Translator's own box, so it is valid in any editor and travels into
	 * translations with its links working. Headings without an anchor get one. Our boxes are left out.
	 */
	public static function insert_toc( $html, $lang ) {
		$skip = array();
		if ( preg_match_all( '#<!-- lmgt:(\w+) -->.*?<!-- /lmgt:\1 -->#s', $html, $bm, PREG_OFFSET_CAPTURE ) ) foreach ( $bm[0] as $b ) $skip[] = array( $b[1], $b[1] + strlen( $b[0] ) );
		$in_box = function ( $at ) use ( $skip ) { foreach ( $skip as $s ) if ( $at >= $s[0] && $at < $s[1] ) return true; return false; };
		if ( ! preg_match_all( '#<h([23])(\s[^>]*)?>(.*?)</h\1>#is', $html, $m, PREG_OFFSET_CAPTURE | PREG_SET_ORDER ) ) return false;
		$h2 = 0;
		foreach ( $m as $x ) if ( $x[1][0] === '2' && ! $in_box( $x[0][1] ) ) $h2++;
		$levels = $h2 >= 4 ? array( '2' ) : array( '2', '3' );
		$used = array(); $items = array(); $out = $html; $shift = 0;
		if ( preg_match_all( '#\sid=["\']([^"\']+)["\']#i', $html, $ids ) ) foreach ( $ids[1] as $i ) $used[ $i ] = true;
		foreach ( $m as $x ) {
			if ( ! in_array( $x[1][0], $levels, true ) || $in_box( $x[0][1] ) ) continue;
			$text = trim( html_entity_decode( wp_strip_all_tags( $x[3][0] ), ENT_QUOTES, 'UTF-8' ) );
			if ( $text === '' ) continue;
			$attrs = isset( $x[2][0] ) ? (string) $x[2][0] : '';
			if ( preg_match( '#\sid=["\']([^"\']+)["\']#i', $attrs, $im ) ) {
				$anchor = $im[1];
			} else {
				$base = sanitize_title( $text ); if ( $base === '' ) $base = 'section';
				$anchor = $base; $k = 2;
				while ( isset( $used[ $anchor ] ) ) $anchor = $base . '-' . $k++;
				$used[ $anchor ] = true;
				$tag  = '<h' . $x[1][0] . $attrs . ' id="' . esc_attr( $anchor ) . '">';
				$old  = '<h' . $x[1][0] . $attrs . '>';
				$at   = $x[0][1] + $shift;
				$out  = substr( $out, 0, $at ) . $tag . substr( $out, $at + strlen( $old ) );
				$shift += strlen( $tag ) - strlen( $old );
			}
			$items[] = array( 'key' => substr( md5( $anchor ), 0, 8 ), 'content' => $text, 'level' => (int) $x[1][0], 'link' => '#' . $anchor, 'disable' => false );
		}
		if ( count( $items ) < 3 ) return false;
		$title = isset( self::TOC_TITLE[ $lang ] ) ? self::TOC_TITLE[ $lang ] : 'Contents';
		$list  = '<ul style="margin:6px 0 0 18px">'; $open = false;
		foreach ( $items as $i => $it ) {
			$li = '<a href="' . esc_attr( $it['link'] ) . '">' . esc_html( $it['content'] ) . '</a>';
			if ( $it['level'] === 3 && $i > 0 ) { $list .= ( $open ? '' : '<ul style="margin:2px 0 2px 18px">' ) . '<li>' . $li . '</li>'; $open = true; continue; }
			if ( $open ) { $list .= '</ul>'; $open = false; }
			$list .= ( $i > 0 ? '</li>' : '' ) . '<li>' . $li;
		}
		$list .= ( $open ? '</ul>' : '' ) . '</li></ul>';
		$box  = '<nav class="lmgt-toc toc" aria-label="' . esc_attr( $title ) . '" style="background:#f6f7f7;border-left:3px solid #2271b1;padding:12px 16px;margin:16px 0"><p style="margin:0"><strong>' . esc_html( $title ) . '</strong></p>' . $list . '</nav>';
		$blocks = strpos( $out, '<!-- wp:' ) !== false;
		$full   = "<!-- lmgt:toc -->\n" . ( $blocks ? "<!-- wp:html -->\n" . $box . "\n<!-- /wp:html -->" : $box ) . "\n<!-- /lmgt:toc -->";
		// Our own earlier table of contents is replaced where it stands.
		$pat = '#<!-- lmgt:toc -->.*?<!-- /lmgt:toc -->#s';
		if ( preg_match( $pat, $out ) ) return preg_replace( $pat, str_replace( '$', '\\$', $full ), $out, 1 );
		$at = class_exists( 'LMGT_Boxes' ) ? LMGT_Boxes::intro_end( $out ) : false;
		if ( $at === false ) { $first = strpos( $out, '<h' . $items[0]['level'] ); $at = $first === false ? 0 : $first; }
		// Before a heading block's opening comment, not inside it.
		if ( preg_match( '#<!-- wp:heading[^>]*-->\s*$#', substr( $out, 0, $at ), $hc ) ) $at -= strlen( $hc[0] );
		return rtrim( substr( $out, 0, $at ) ) . "\n\n" . $full . "\n\n" . ltrim( substr( $out, $at ) );
	}

	public static function handle_toc() {
		$id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
		check_admin_referer( 'lmgt_toc_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$post = get_post( $id );
		$back = get_edit_post_link( $id, 'url' );
		$own = strpos( $post->post_content, '<!-- lmgt:toc -->' ) !== false;
		if ( ! $own && self::toc( $post->post_content ) ) self::back( $back, 'This text already has a table of contents. Nothing changed.' );
		$lang = $post->post_type === LMGT_CPT ? (string) get_post_meta( $id, '_lmgt_lang', true ) : LMGT_Langs::source();
		$new  = self::insert_toc( $post->post_content, $lang );
		if ( $new === false ) self::back( $back, 'Not enough section headings for a table of contents (3 or more needed). Run Structure first, or add headings.' );
		LMGT_Store::update_content( $id, array( 'post_content' => $new ) );
		delete_transient( 'lmgt_links_' . $id );
		self::back( $back, ( $own ? 'Table of contents updated with the current headings.' : 'Table of contents put in after the intro, before the first section.' ) . ' It is a block of its own in the editor; after changing headings, click Update the table of contents in step 1. The previous version is under Revisions.' );
	}

	/** 2.21.0: one-click fixes in step 1 that change no text: Rank Math's pillar switch, supporting posts. */
	public static function handle_fix() {
		$id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
		check_admin_referer( 'lmgt_goal_fix_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$back = get_edit_post_link( $id, 'url' );
		$do   = isset( $_GET['do'] ) ? sanitize_key( $_GET['do'] ) : '';
		if ( $do === 'flag' ) {
			update_post_meta( $id, 'rank_math_pillar_content', 'on' );
			update_post_meta( $id, '_lmgt_goal_set_pillar', 1 );
			self::back( $back, 'Marked as pillar in Rank Math.' );
		}
		if ( $do === 'support' ) {
			$n = 0;
			foreach ( array_filter( array_map( 'intval', explode( '-', isset( $_GET['ids'] ) ? (string) $_GET['ids'] : '' ) ) ) as $s ) {
				if ( $s === $id || ! current_user_can( 'edit_post', $s ) || self::get( $s ) !== '' ) continue;
				update_post_meta( $s, '_lmgt_goal', 'support' );
				update_post_meta( $s, '_lmgt_goal_pillar', $id );
				$n++;
			}
			self::back( $back, $n ? $n . ' post(s) now belong to this pillar as supporting posts. Their text did not change; their step 1 now shows what each still needs (a link up to this pillar, its own keyword).' : 'Nothing ticked. Nothing changed.' );
		}
		self::back( $back, 'Nothing to do.' );
	}

	private static function back( $url, $msg ) {
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $msg ), $url ) );
		exit;
	}

	private static function form( $post, $goal ) {
		$id  = $post->ID;
		$opt = '';
		foreach ( self::LABELS as $k => $l ) $opt .= '<option value="' . esc_attr( $k ) . '"' . selected( $goal, $k, false ) . '>' . esc_html( $k === '' ? 'No goal' : $l ) . '</option>';
		$pl  = '<option value="0">– choose the pillar –</option>';
		foreach ( self::pillars( $id ) as $pid => $t ) $pl .= '<option value="' . (int) $pid . '"' . selected( self::pillar_of( $id ), $pid, false ) . '>' . esc_html( $t ) . '</option>';
		add_action( 'admin_footer', function () use ( $id ) {
			echo '<form id="lmgt-goal" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="lmgt_goal"><input type="hidden" name="post_id" value="' . (int) $id . '">'
				. wp_nonce_field( 'lmgt_goal_' . $id, '_wpnonce', true, false ) . '</form>';
		} );
		return '<details style="margin-top:6px"' . ( $goal === '' || ( $goal === 'support' && ! self::pillar_of( $id ) ) ? ' open' : '' ) . '><summary>' . ( $goal === '' ? 'Choose a goal' : 'Change the goal' ) . '</summary>'
			. '<p style="margin:6px 0"><select form="lmgt-goal" name="lmgt_goal" onchange="var p=document.getElementById(\'lmgt-goal-p\');if(p)p.style.display=this.value===\'support\'?\'\':\'none\'">' . $opt . '</select></p>'
			. '<p id="lmgt-goal-p" style="margin:6px 0;' . ( $goal === 'support' ? '' : 'display:none' ) . '"><select form="lmgt-goal" name="lmgt_goal_pillar" style="max-width:100%">' . $pl . '</select><br><span class="description">Pillars are pages and posts with the goal Pillar, or marked as pillar in Rank Math.</span></p>'
			. '<p style="margin:6px 0"><button class="button button-primary" form="lmgt-goal">Save the goal</button></p>'
			. '<p class="description" style="margin:0">Every goal also gets what makes an article an authority: facts from the text, sources, depth. Nothing is written into the text when you save.</p></details>';
	}

	public static function handle() {
		$id = isset( $_POST['post_id'] ) ? (int) $_POST['post_id'] : 0;
		check_admin_referer( 'lmgt_goal_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$g = isset( $_POST['lmgt_goal'] ) ? sanitize_key( $_POST['lmgt_goal'] ) : '';
		if ( ! isset( self::LABELS[ $g ] ) ) $g = '';
		$was = self::get( $id );
		if ( $g === '' ) delete_post_meta( $id, '_lmgt_goal' ); else update_post_meta( $id, '_lmgt_goal', $g );
		$p = isset( $_POST['lmgt_goal_pillar'] ) ? (int) $_POST['lmgt_goal_pillar'] : 0;
		if ( $g === 'support' && $p && $p !== $id ) update_post_meta( $id, '_lmgt_goal_pillar', $p ); elseif ( $g !== 'support' ) delete_post_meta( $id, '_lmgt_goal_pillar' );
		// Rank Math's own pillar switch follows the goal, only where Translator set it.
		if ( $g === 'pillar' && get_post_meta( $id, 'rank_math_pillar_content', true ) !== 'on' ) { update_post_meta( $id, 'rank_math_pillar_content', 'on' ); update_post_meta( $id, '_lmgt_goal_set_pillar', 1 ); }
		if ( $was === 'pillar' && $g !== 'pillar' && get_post_meta( $id, '_lmgt_goal_set_pillar', true ) ) { delete_post_meta( $id, 'rank_math_pillar_content' ); delete_post_meta( $id, '_lmgt_goal_set_pillar' ); }
		// 2.19.4 (G, 22 Nov: blank screen after saving a goal): the goal does not change the text, so the link count
		// stays cached; clearing it made the reload count every link again, with up to six slow look-ups.
		$msg = 'Goal saved: ' . self::LABELS[ $g ] . ( $g === 'support' && $p ? ' (pillar: ' . get_the_title( $p ) . ')' : '' ) . '. The checks are in step 1.';
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $msg ), get_edit_post_link( $id, 'url' ) ) );
		exit;
	}
}
