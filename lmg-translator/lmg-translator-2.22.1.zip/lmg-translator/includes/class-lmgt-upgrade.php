<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Runs once per new version, on the first page load after the zip is uploaded
 * (an upload over the old plugin does not fire the activation hook).
 *
 * From the 2.0.0 fresh build (live 25–26 Oct 2026), which kept its data in
 * other places, it carries over:
 *   options  lmgt_active_langs → lmgt_languages (only when 1.10 never saved one)
 *   cron     lmgt_retry_queue, lmgt_reconcile → removed (2.1 runs lmgt_bridge_*)
 *   .dk      _lmgt_set [lang => id, url, status] → _lmgt_remote
 *            _lmgt_canonical       → _lmgt_moved_to
 *            _lmgt_moved_to_travel → _lmgt_moved_draft
 *   .travel  _lmgt_source_id / _lmgt_source_url → _lmgt_remote_source / _lmgt_remote_url,
 *            and a pipeline post becomes a translation (lmgt_translation)
 *            _lmgt_flags → _lmgt_report issues
 * Old meta and options are left in place. Nothing is deleted or unpublished.
 *
 * Then, on .dk, every original with translations gets its hreflang set
 * computed, so the existing translations print hreflang again at once.
 */
class LMGT_Upgrade {

	const OPT   = 'lmgt_version';
	const WAVE1 = array( 'en', 'de', 'fr', 'it', 'es' );

	public static function boot() {
		add_action( 'init', array( __CLASS__, 'maybe_run' ), 99 );
	}

	/**
	 * Once per version. With a persistent object cache (LiteSpeed on .travel)
	 * get_option() and transients could still show the old state to other
	 * requests, and 2.2.7 ran six times there. So the lock is a row in the
	 * options table, taken with one atomic insert, and the version is read again
	 * from the database once the lock is held (2.2.8).
	 */
	public static function maybe_run() {
		if ( get_option( self::OPT ) === LMGT_VERSION ) return;
		global $wpdb;
		$lock = 'lmgt_upgrade_lock';
		if ( ! $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')", $lock, time() ) ) ) {
			// Held by another request; a lock older than five minutes was left by one that died, and is taken over.
			$t = (int) $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $lock ) );
			if ( time() - $t < 300 || ! $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s", time(), $lock, $t ) ) ) return;
		}
		$now = maybe_unserialize( $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", self::OPT ) ) );
		if ( $now === LMGT_VERSION ) {
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s", $lock ) );
			wp_cache_delete( 'alloptions', 'options' );
			wp_cache_delete( self::OPT, 'options' );
			return;
		}
		$done = array();
		$done[] = self::options();
		$done[] = self::agreement();
		$done[] = self::scope_20261110();
		if ( LMGT_Bridge::is_source() ) {
			$done[] = self::source_meta();
			$done[] = LMGT_Nordic::take_back();
			$done[] = self::backfill_sets();
			$done[] = self::text_hashes();
			$done[] = self::sitemap();
		}
		if ( LMGT_Bridge::is_target() ) $done[] = self::target_meta();
		if ( LMGT_Bridge::is_target() ) $done[] = self::thin_members();
		$done[] = self::made_with();
		$done[] = self::words_meta();
		// 2.2.19: keyword proposals made from the Danish text are dropped; "Propose keywords" asks again.
		if ( delete_option( 'lmgt_kw_proposals' ) ) $done[] = 'old keyword proposals cleared';
		$done[] = self::purge();
		flush_rewrite_rules( false );
		update_option( self::OPT, LMGT_VERSION );
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s", $lock ) );
		if ( LMGT_Bridge::on() ) LMGT_Bridge::log( 'upgrade to ' . LMGT_VERSION . ': ' . implode( '; ', array_filter( $done ) ) );
	}

	/**
	 * 2.2.16: the .dk addresses of copied translations now redirect, every .dk page
	 * gains the line to .travel, and .travel's breadcrumbs change. Cached copies
	 * would hide all of it: clear the LiteSpeed cache once.
	 */
	private static function purge() {
		do_action( 'litespeed_purge_all' );
		return 'page cache cleared';
	}

	/** 2.2.21: the Translations list sorts by length; give every translation its word count once. */
	private static function words_meta() {
		global $wpdb;
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT p.ID FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_lmgt_words'
			WHERE p.post_type = %s AND p.post_status <> 'trash' AND m.meta_id IS NULL", LMGT_CPT ) );
		foreach ( $ids as $id ) update_post_meta( (int) $id, '_lmgt_words', LMGT_Store::words( (int) $id ) );
		return $ids ? count( $ids ) . ' translation word counts stored' : '';
	}

	/** 2.2.18: translations copied before this version are still in Rank Math's cached sitemap; clear it once. */
	private static function sitemap() {
		$ids = self::ids_with( '_lmgt_moved_to' );
		if ( ! $ids ) return '';
		LMGT_Bridge::sitemap_stale( $ids[0] );
		return 'sitemap cache cleared (' . count( $ids ) . ' moved translations)';
	}

	private static function options() {
		wp_clear_scheduled_hook( 'lmgt_retry_queue' );
		wp_clear_scheduled_hook( 'lmgt_reconcile' );
		if ( get_option( 'lmgt_languages', null ) !== null ) return '';
		$langs = get_option( 'lmgt_active_langs', null );
		$langs = is_array( $langs ) && $langs ? $langs : self::WAVE1;
		update_option( 'lmgt_languages', array_values( array_intersect( array_keys( LMGT_Langs::all() ), $langs ) ), false );
		return 'languages ' . implode( ',', $langs );
	}

	/**
	 * G's agreement of 26 Oct 2026: Claude translates, no DeepL, model Claude
	 * Haiku 5.5. Applied once (2.1.3), so a later deliberate change in Settings
	 * is not undone by the next upgrade. Keys are not touched.
	 */
	/**
	 * 2.13.0, once (G, 10 Nov 2026, briefs/translator-scope-2026-11-10.md): nothing publishes by itself,
	 * and the small corner notes (Read in English, Back to traveltalk.dk, welcome) are off. All three
	 * stay in Settings for a later deliberate change.
	 */
	private static function scope_20261110() {
		if ( get_option( 'lmgt_scope_20261110' ) ) return '';
		foreach ( array( 'lmgt_auto_publish', 'lmgt_plan_publish', 'lmgt_english_offer', 'lmgt_back_chip', 'lmgt_welcome' ) as $k ) update_option( $k, '0', false );
		update_option( 'lmgt_scope_20261110', LMGT_VERSION, false );
		return 'scope 10 Nov: auto-publish and corner notes off';
	}

	private static function agreement() {
		if ( get_option( 'lmgt_agreement_20261026' ) ) return '';
		$before = 'engine ' . get_option( 'lmgt_engine', '-' ) . ', AI ' . get_option( 'lmgt_ai', '-' ) . ', back ' . get_option( 'lmgt_back_engine', '-' ) . ', model ' . ( get_option( 'lmgt_claude_model', '' ) ?: '-' );
		update_option( 'lmgt_ai', 'claude', false );
		update_option( 'lmgt_engine', 'gemini', false );
		update_option( 'lmgt_back_engine', 'gemini', false );
		update_option( 'lmgt_claude_model', 'claude-haiku-5-5', false );
		update_option( 'lmgt_agreement_20261026', LMGT_VERSION, false );
		return 'agreed engine set: Claude only, claude-haiku-5-5 (was ' . $before . ')';
	}

	private static function ids_with( $key ) {
		global $wpdb;
		return array_map( 'intval', $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s", $key ) ) );
	}

	private static function source_meta() {
		$n = 0;
		foreach ( self::ids_with( '_lmgt_set' ) as $id ) {
			$old = get_post_meta( $id, '_lmgt_set', true );
			if ( ! is_array( $old ) || isset( $old['members'] ) || ! $old ) continue;
			$remote = LMGT_Bridge::remote( $id );
			foreach ( $old as $lang => $m ) {
				if ( $lang === LMGT_Langs::source() || isset( $remote[ $lang ] ) || ! is_array( $m ) || empty( $m['url'] ) || ! LMGT_Langs::get( $lang ) ) continue;
				$remote[ $lang ] = array( 'id' => (int) ( isset( $m['id'] ) ? $m['id'] : 0 ), 'url' => esc_url_raw( $m['url'] ), 'status' => sanitize_key( isset( $m['status'] ) ? $m['status'] : 'draft' ) );
			}
			if ( $remote ) update_post_meta( $id, '_lmgt_remote', wp_slash( $remote ) );
			$n++;
		}
		foreach ( self::ids_with( '_lmgt_canonical' ) as $id ) {
			if ( ! get_post_meta( $id, '_lmgt_moved_to', true ) ) update_post_meta( $id, '_lmgt_moved_to', esc_url_raw( get_post_meta( $id, '_lmgt_canonical', true ) ) );
			$n++;
		}
		foreach ( self::ids_with( '_lmgt_moved_to_travel' ) as $id ) {
			update_post_meta( $id, '_lmgt_moved_draft', '1' );
			$n++;
		}
		return $n ? "2.0.0 meta carried over on $n post(s)" : '';
	}

	/** Every original with a translation here or on .travel. Stored locally; pushed to .travel only where it has members. */
	private static function backfill_sets() {
		global $wpdb;
		$sources = $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT m.meta_value FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key = '_lmgt_source' AND p.post_status = 'publish' AND p.post_type = %s",
			LMGT_CPT
		) );
		foreach ( (array) get_option( 'lmgt_tagged', array() ) as $tid ) {
			$s = (int) get_post_meta( $tid, '_lmgt_source', true );
			if ( $s && get_post_status( $tid ) === 'publish' ) $sources[] = $s;
		}
		$sources = array_unique( array_map( 'intval', $sources ) );
		$pushed  = 0;
		foreach ( $sources as $sid ) {
			if ( ! $sid ) continue;
			if ( get_post_meta( $sid, '_lmgt_remote', true ) ) {
				LMGT_Bridge::refresh_set( $sid );
				$pushed++;
			} else {
				update_post_meta( $sid, '_lmgt_set', wp_slash( LMGT_Bridge::compute_set( $sid ) ) );
			}
		}
		foreach ( self::ids_with( '_lmgt_remote' ) as $sid ) {
			if ( ! in_array( $sid, $sources, true ) ) {
				LMGT_Bridge::refresh_set( $sid );
				$pushed++;
			}
		}
		return count( $sources ) . " set(s) computed, $pushed sent to .travel";
	}

	/**
	 * 2.2.0: every original with members on .travel gets its text fingerprint.
	 * .travel takes it as the text each translation was made from, where it has
	 * none yet, so changes from now on are flagged; earlier ones are not known.
	 */
	private static function text_hashes() {
		$all = array();
		foreach ( self::ids_with( '_lmgt_remote' ) as $sid ) {
			$p = get_post( $sid );
			if ( ! $p ) continue;
			$h = LMGT_Sync::text_hash( $p );
			update_post_meta( $sid, '_lmgt_text_hash', $h );
			$all[ $sid ] = array( 'hash' => $h, 'at' => $p->post_modified_gmt );
		}
		foreach ( array_chunk( $all, 100, true ) as $part ) LMGT_Bridge::call( 'POST', '/changed', array( 'hashes' => $part, 'baseline' => true ) );
		return $all ? count( $all ) . ' original(s) fingerprinted for "Mother text changed"' : '';
	}

	/** 2.2.2: translations made before versions were recorded say so, for the catch-up (brief 4.19). */
	private static function made_with() {
		global $wpdb;
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT p.ID FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_lmgt_made_with' WHERE p.post_type = %s AND p.post_status <> 'trash' AND m.meta_id IS NULL", LMGT_CPT ) );
		foreach ( $ids as $id ) update_post_meta( (int) $id, '_lmgt_made_with', 'before 2.2.2' );
		return $ids ? count( $ids ) . ' translation(s) marked "made before 2.2.2"' : '';
	}

	/** 2.1.6: published members under the word threshold are reported to .dk as 'thin', so it drops them from hreflang. */
	private static function thin_members() {
		$n = 0;
		foreach ( self::ids_with( '_lmgt_remote_source' ) as $id ) {
			if ( get_post_status( $id ) !== 'publish' || ! LMGT_Store::is_thin( $id ) ) continue;
			LMGT_Bridge::notify( $id );
			$n++;
		}
		return $n ? "$n thin translation(s) set to noindex and reported to .dk" : '';
	}

	private static function target_meta() {
		$n = 0;
		foreach ( self::ids_with( '_lmgt_source_id' ) as $id ) {
			if ( get_post_meta( $id, '_lmgt_remote_source', true ) ) continue;
			update_post_meta( $id, '_lmgt_remote_source', (int) get_post_meta( $id, '_lmgt_source_id', true ) );
			update_post_meta( $id, '_lmgt_remote_url', esc_url_raw( (string) get_post_meta( $id, '_lmgt_source_url', true ) ) );
			$flags = array_filter( (array) get_post_meta( $id, '_lmgt_flags', true ) );
			if ( $flags && ! get_post_meta( $id, '_lmgt_report', true ) ) {
				$issues = array();
				foreach ( $flags as $f ) $issues[] = array( 'type' => 'meaning', 'original' => '', 'back' => '', 'note' => (string) $f );
				update_post_meta( $id, '_lmgt_report', wp_slash( array( 'issues' => $issues ) ) );
			}
			// A post the 2.0.0 pipeline wrote becomes a translation; an English post linked by a person stays as it is.
			if ( ! get_post_meta( $id, '_lmgt_linked_existing', true ) && get_post_type( $id ) === 'post' ) set_post_type( $id, LMGT_CPT );
			$n++;
		}
		return $n ? "2.0.0 translations carried over: $n" : '';
	}
}
