<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.2.12: Find pictures (G, 27 Oct 2026: look in our own media first, then
 * the media banks, e.g. the Austrian tourist board's, which is second to none).
 *
 * Translator → Find pictures, opened from the Pictures box: for every section
 * inside a stretch without a picture, the Media Library is searched for the
 * section heading's words (image title, caption, alt text and file name;
 * æ/ø/å also as ae/oe/aa), pictures already in the article left out, best
 * matches first. "Put it here" inserts the picture as an image block after the
 * section's first paragraph; only on a click, and the earlier text stays in
 * Revisions. Below, the media banks from Media → Image Banks with the search
 * words to copy: downloading there is done by a person, under that bank's
 * terms, and the next search here finds the upload.
 */
class LMGT_Finder {

	const STOP = array( 'og', 'i', 'på', 'til', 'med', 'for', 'en', 'et', 'den', 'det', 'de', 'af', 'om', 'er', 'som', 'så', 'du', 'kan', 'der', 'har', 'mere', 'end', 'bare', 'også', 'hvad', 'hvor', 'the', 'and', 'of', 'in', 'to', 'a', 'an', 'for', 'with', 'on', 'at', 'is', 'und', 'der', 'die', 'das', 'mit', 'von', 'le', 'la', 'les', 'et', 'des', 'el', 'los', 'y', 'tip', 'traveltalk', 'guide', 'bedste', 'best' );

	public static function boot() {
		add_action( 'admin_menu', function () {
			add_submenu_page( 'lmgt', 'Find pictures', 'Find pictures', 'edit_others_posts', 'lmgt-find', array( __CLASS__, 'page' ) );
		}, 28 );
		add_action( 'admin_post_lmgt_put_picture', array( __CLASS__, 'handle_put' ) );
	}

	/** Search words of a heading: letters only, no short or filler words, at most five. */
	public static function words( $heading ) {
		$w = preg_split( '/[^\p{L}\p{N}]+/u', mb_strtolower( wp_strip_all_tags( (string) $heading ) ), -1, PREG_SPLIT_NO_EMPTY );
		$w = array_filter( $w, function ( $x ) { return mb_strlen( $x ) > 2 && ! in_array( $x, self::STOP, true ) && ! is_numeric( $x ); } );
		return array_slice( array_values( array_unique( $w ) ), 0, 5 );
	}

	/** A word and how Danish letters are often written in file names. */
	private static function variants( $w ) {
		$v = array( $w, strtr( $w, array( 'æ' => 'ae', 'ø' => 'oe', 'å' => 'aa' ) ), strtr( $w, array( 'æ' => 'a', 'ø' => 'o', 'å' => 'a' ) ) );
		return array_values( array_unique( $v ) );
	}

	/** Pictures already in the article (in the text and the featured one). */
	public static function used( $post ) {
		preg_match_all( '/\bwp-image-(\d+)\b/', $post->post_content, $m );
		$ids = array_map( 'intval', $m[1] );
		$t   = (int) get_post_thumbnail_id( $post->ID );
		if ( $t ) $ids[] = $t;
		return array_unique( $ids );
	}

	/**
	 * Media Library images matching the words, best first: one point per word
	 * found in title, caption, alt text or file name.
	 *
	 * @return int[] attachment IDs
	 */
	/**
	 * 2.2.27 (G, 2 Nov 2026: "rather wide scope, mostly non-relevant images"): the
	 * database is asked broadly (any word as part of a field, as before), then each
	 * candidate is judged here: whole words only ("sea" no longer finds "season"),
	 * alt text and title count most, the caption next, the file name least; and when
	 * the heading has three or more search words, at least two must match (Settings →
	 * Find pictures). Returns [ID => why] in order, best first.
	 */
	public static function search( array $words, array $exclude = array(), $limit = 6 ) {
		global $wpdb;
		if ( ! $words ) return array();
		$alts = array();
		$args = array();
		foreach ( $words as $w ) {
			foreach ( self::variants( $w ) as $v ) {
				$like   = '%' . $wpdb->esc_like( $v ) . '%';
				$alts[] = '(p.post_title LIKE %s OR p.post_excerpt LIKE %s OR a.meta_value LIKE %s OR f.meta_value LIKE %s)';
				array_push( $args, $like, $like, $like, $like );
			}
		}
		$sql = "SELECT p.ID, p.post_title, p.post_excerpt, a.meta_value AS alt, f.meta_value AS file FROM {$wpdb->posts} p
			LEFT JOIN {$wpdb->postmeta} a ON a.post_id = p.ID AND a.meta_key = '_wp_attachment_image_alt'
			LEFT JOIN {$wpdb->postmeta} f ON f.post_id = p.ID AND f.meta_key = '_wp_attached_file'
			WHERE p.post_type = 'attachment' AND p.post_mime_type LIKE 'image/%%' AND (" . implode( ' OR ', $alts ) . ')';
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ) );
		$need = self::need( count( $words ) );
		$out  = array();
		foreach ( (array) $rows as $r ) {
			if ( in_array( (int) $r->ID, $exclude, true ) ) continue;
			$fields = array(
				'alt text' => array( 3, (string) $r->alt ),
				'title'    => array( 3, (string) $r->post_title ),
				'caption'  => array( 2, (string) $r->post_excerpt ),
				'file name'=> array( 1, preg_replace( '/[-_.\/]+/', ' ', (string) $r->file ) ),
			);
			$score = 0;
			$hit   = array();
			foreach ( $words as $w ) {
				foreach ( $fields as $name => $f ) {
					if ( self::has_word( $f[1], $w ) ) {
						$score += $f[0];
						$hit[]  = $w . ' (' . $name . ')';
						break;
					}
				}
			}
			if ( count( $hit ) < $need ) continue;
			$out[] = array( (int) $r->ID, $score, count( $hit ), implode( ', ', $hit ) );
		}
		usort( $out, function ( $a, $b ) { return $b[2] - $a[2] ?: ( $b[1] - $a[1] ?: $b[0] - $a[0] ); } );
		$res = array();
		foreach ( array_slice( $out, 0, $limit ) as $o ) $res[ $o[0] ] = $o[3];
		return $res;
	}

	/** How many of the search words must match: 1, or 2 when there are three or more (Settings). */
	public static function need( $count ) {
		return get_option( 'lmgt_find_strict', '1' ) === '1' && $count >= 3 ? 2 : 1;
	}

	/** A whole word, in any of its spellings (ø as oe or o), case-insensitive. */
	public static function has_word( $text, $w ) {
		$text = mb_strtolower( (string) $text );
		if ( $text === '' ) return false;
		foreach ( self::variants( $w ) as $v ) {
			if ( preg_match( '/(?<![\p{L}\p{N}])' . preg_quote( $v, '/' ) . '(?![\p{L}\p{N}])/u', $text ) ) return true;
		}
		return false;
	}

	public static function headings( $html ) {
		preg_match_all( '/<h[2-4]\b[^>]*>.*?<\/h[2-4]>/is', (string) $html, $m );
		return array_map( array( 'LMGT_Text', 'plain' ), $m[0] );
	}

	/** Insert an image block after the first paragraph of the nth section (or right after its heading). */
	public static function insert( $html, $nth, $att ) {
		if ( ! preg_match_all( '/<h[2-4]\b[^>]*>.*?<\/h[2-4]>/is', $html, $m, PREG_OFFSET_CAPTURE ) || ! isset( $m[0][ $nth ] ) ) return false;
		$after = $m[0][ $nth ][1] + strlen( $m[0][ $nth ][0] );
		$next  = isset( $m[0][ $nth + 1 ] ) ? $m[0][ $nth + 1 ][1] : strlen( $html );
		$p     = stripos( $html, '</p>', $after );
		$at    = ( $p !== false && $p < $next ) ? $p + 4 : $after;
		// Stay outside the block the insertion point closes.
		if ( preg_match( '/\G\s*<!-- \/wp:(?:paragraph|heading) -->/', $html, $c, 0, $at ) ) $at += strlen( $c[0] );
		$src = wp_get_attachment_image_url( $att, 'large' );
		if ( ! $src ) return false;
		$alt   = (string) get_post_meta( $att, '_wp_attachment_image_alt', true );
		$block = "\n\n<!-- wp:image {\"id\":" . (int) $att . ",\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->\n"
			. '<figure class="wp-block-image size-large"><img src="' . esc_url( $src ) . '" alt="' . esc_attr( $alt ) . '" class="wp-image-' . (int) $att . '"/></figure>'
			. "\n<!-- /wp:image -->\n\n";
		return substr( $html, 0, $at ) . $block . substr( $html, $at );
	}

	public static function handle_put() {
		$pid = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
		$nth = isset( $_GET['nth'] ) ? (int) $_GET['nth'] : -1;
		$att = isset( $_GET['att'] ) ? (int) $_GET['att'] : 0;
		check_admin_referer( 'lmgt_put_' . $pid );
		if ( ! current_user_can( 'edit_post', $pid ) ) wp_die( 'Not allowed.' );
		$h   = self::headings( get_post_field( 'post_content', $pid, 'raw' ) );
		$new = isset( $h[ $nth ] ) && isset( $_GET['h'] ) && md5( $h[ $nth ] ) === $_GET['h'] ? self::insert( get_post_field( 'post_content', $pid, 'raw' ), $nth, $att ) : false;
		if ( $new === false ) {
			$msg = 'Not inserted: the article has changed since this page was opened. Look again.';
		} else {
			LMGT_Store::update_content( $pid, array( 'post_content' => $new ) );
			$msg = 'Picture put under "' . $h[ $nth ] . '". The earlier text is in Revisions.';
			// An alt text for it in this article's language, from the picture and its section (2.2.14).
			$r    = LMGT_Alts::check( $pid, 'id:' . $att );
			$msg .= is_wp_error( $r ) ? ' No alt text proposed: ' . $r->get_error_message() : ( $r ? ' An alt text is proposed below.' : ' Its alt text already fits.' );
		}
		wp_safe_redirect( add_query_arg( array( 'page' => 'lmgt-find', 'post' => $pid, 'placed' => $new === false ? 0 : $att, 'lmgt_msg' => rawurlencode( $msg ) ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/** The alt text proposed for the picture just placed, to edit and apply here. */
	private static function placed_box( $post, $att ) {
		$c = $att ? get_post_meta( $post->ID, '_lmgt_alt_check', true ) : null;
		if ( ! is_array( $c ) || empty( $c['items'] ) ) return;
		foreach ( $c['items'] as $i => $it ) {
			if ( $it['key'] !== 'id:' . $att || $it['ok'] ) continue;
			$l = LMGT_Langs::get( LMGT_Alts::lang_of( $post ) );
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="background:#fff;border:1px solid #c3c4c7;padding:12px 16px;margin:12px 0;display:flex;gap:16px;align-items:flex-start">'
				. '<input type="hidden" name="action" value="lmgt_alts_apply">' . wp_nonce_field( 'lmgt_alts_apply', '_wpnonce', true, false )
				. '<input type="hidden" name="lmgt_pick[' . (int) $post->ID . '][]" value="' . (int) $i . '"><input type="hidden" name="lmgt_back" value="' . esc_url( admin_url( 'admin.php?page=lmgt-find&post=' . (int) $post->ID ) ) . '">'
				. wp_get_attachment_image( $att, array( 120, 90 ), false, array( 'style' => 'width:120px;height:90px;object-fit:cover' ) )
				. '<div style="flex:1"><p style="margin-top:0"><strong>Alt text for the picture you placed</strong> (' . esc_html( $l['name'] ) . ', from the picture and its section). Edit if needed:</p>'
				. '<textarea name="lmgt_alt[' . (int) $post->ID . '][' . (int) $i . ']" rows="2" maxlength="160" style="width:100%">' . esc_textarea( $it['new'] ) . '</textarea>'
				. LMGT_Alts::hint( $it )
				. '<p><button class="button button-primary" name="lmgt_do" value="apply">Apply</button> <button class="button" name="lmgt_do" value="dismiss">Keep the one it has</button></p></div></form>';
		}
	}

	/** Media → Image Banks (LMG Image Banks), the Media Library line left out. */
	private static function banks() {
		$raw = (string) get_option( 'lmg_image_banks', function_exists( 'lmg_image_banks_default' ) ? lmg_image_banks_default() : '' );
		$out = array();
		foreach ( preg_split( '/\R/', $raw ) as $line ) {
			$p = array_map( 'trim', explode( '|', $line ) );
			if ( count( $p ) < 2 || $p[1] === '' || strpos( $p[1], 'upload.php' ) !== false ) continue;
			$out[] = array( 'name' => $p[0], 'url' => $p[1], 'notes' => isset( $p[2] ) ? $p[2] : '' );
		}
		return $out;
	}

	public static function page() {
		$pid  = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
		$post = $pid ? get_post( $pid ) : null;
		echo '<div class="wrap"><h1>Find pictures</h1>';
		if ( ! empty( $_GET['lmgt_msg'] ) ) echo '<div class="notice notice-info"><p>' . esc_html( wp_unslash( $_GET['lmgt_msg'] ) ) . '</p></div>';
		if ( ! $post ) {
			echo '<form><input type="hidden" name="page" value="lmgt-find"><p><label>Post or page ID <input type="number" name="post" class="small-text"></label> <button class="button">Look</button></p><p class="description">Or use "Find pictures" in the Pictures box on the edit screen.</p></form></div>';
			return;
		}
		self::placed_box( $post, isset( $_GET['placed'] ) ? (int) $_GET['placed'] : 0 );
		$a = LMGT_Pictures::analyse( $post->post_content );
		echo '<p><a href="' . esc_url( get_edit_post_link( $pid ) ) . '"><strong>' . esc_html( get_the_title( $pid ) ) . '</strong></a> · ' . number_format_i18n( $a['words'] ) . ' words, ' . (int) $a['pics'] . ' picture(s).</p>';
		if ( ! $a['gaps'] ) {
			echo '<p style="color:#008a20">No stretch longer than ' . LMGT_Pictures::every() . ' words without a picture.</p></div>';
			return;
		}
		$heads = self::headings( $post->post_content );
		$used  = self::used( $post );
		$title = self::words( $post->post_title );
		foreach ( $a['gaps'] as $g ) {
			echo '<h2>' . number_format_i18n( $g['words'] ) . ' words without a picture</h2>';
			foreach ( $g['sections'] as $h => $n ) {
				if ( $n < 150 ) continue;
				$nth = array_search( $h, $heads, true );
				if ( $nth === false ) continue;
				$words = self::words( $h );
				if ( ! $words ) $words = $title;
				$found = self::search( $words, $used );
				$by_title = false;
				// 2.2.27: no longer the heading and title words together (that widened the search); the title alone, said so.
				if ( ! $found && $title && $title !== $words ) { $found = self::search( $title, $used ); $by_title = (bool) $found; }
				echo '<h3>' . esc_html( $h ) . ' <span class="description">(' . number_format_i18n( $n ) . ' words)</span></h3>';
				echo '<p class="description">Searched for: <code>' . esc_html( implode( ' ', $words ) ) . '</code>' . ( self::need( count( $words ) ) > 1 ? ' – at least 2 of these words must match' : '' ) . ( $by_title ? '. Nothing for these; shown by the article title\'s words: <code>' . esc_html( implode( ' ', $title ) ) . '</code>' : '' ) . '</p>';
				if ( $found ) {
					echo '<div style="display:flex;flex-wrap:wrap;gap:14px">';
					foreach ( $found as $att => $why ) {
						$put = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_put_picture&post=' . $pid . '&nth=' . (int) $nth . '&h=' . md5( $h ) . '&att=' . $att ), 'lmgt_put_' . $pid );
						$alt = (string) get_post_meta( $att, '_wp_attachment_image_alt', true );
						echo '<div style="width:170px">' . wp_get_attachment_image( $att, array( 170, 120 ), false, array( 'style' => 'width:170px;height:120px;object-fit:cover' ) )
							. '<div style="font-size:12px;margin:4px 0">' . esc_html( wp_trim_words( $alt !== '' ? $alt : get_the_title( $att ), 10 ) ) . '</div>'
							. '<div style="font-size:11px;color:#646970;margin:0 0 4px">Matched: ' . esc_html( $why ) . '</div>'
							. '<a class="button button-small" href="' . esc_url( $put ) . '" onclick="return confirm(\'Put this picture under &quot;' . esc_attr( $h ) . '&quot;?\')">Put it here</a> <a class="button-link" href="' . esc_url( get_edit_post_link( $att ) ) . '" target="_blank">#' . (int) $att . '</a></div>';
					}
					echo '</div>';
				} else {
					echo '<p>Nothing in the Media Library for these words.</p>';
				}
			}
		}
		$banks = self::banks();
		if ( $banks ) {
			echo '<h2>Not there? The media banks</h2><p>Search there with the words above, download, upload to the Media Library; the next look here finds it. Each bank\'s own terms apply.</p><ul style="list-style:disc;margin-left:18px">';
			foreach ( $banks as $b ) echo '<li><a href="' . esc_url( $b['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $b['name'] ) . '</a>' . ( $b['notes'] !== '' ? ' – <span class="description">' . esc_html( $b['notes'] ) . '</span>' : '' ) . '</li>';
			echo '</ul><p class="description">The list is edited under Media → Image Banks.</p>';
		}
		echo '</div>';
	}
}
