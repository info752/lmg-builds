<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.22.0 (G, 26 Nov: "travel creeps in on think-smarter. Follow the content"): what the site writes
 * about, and the words every prompt uses for it. Option lmgt_subject overrides the guess from the address.
 */
class LMGT_Subject {

	const ALL = array( 'travel', 'wine', 'sport', 'think' );

	public static function get() {
		$o = (string) get_option( 'lmgt_subject', '' );
		if ( in_array( $o, self::ALL, true ) ) return $o;
		$h = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		if ( strpos( $h, 'winetalk' ) !== false ) return 'wine';
		if ( strpos( $h, 'sporttalk' ) !== false ) return 'sport';
		if ( strpos( $h, 'think-smarter' ) !== false || strpos( $h, 'thinksmarter' ) !== false ) return 'think';
		return 'travel';
	}

	public static function is_travel() {
		return self::get() === 'travel';
	}

	public static function w( $key ) {
		$w = array(
			'travel' => array(
				'kind'   => 'travel',
				'writer' => 'travel journalist',
				'house'  => 'Traveltalk, a travel media house',
				'reader' => 'a traveller',
				'gaps'   => 'best time to go, getting there, getting around, where to stay, food, costs, practical facts, safety',
				'lead'   => 'Describe the place, not a trip. Concrete and specific.',
				'never'  => 'top-10 lists, grading travel agents, operators or airlines, selling trips, knocking other destinations',
				'order'  => 'Every Traveltalk text runs: inviting intro, the middle, the practical part last (when to go, getting there, getting around, where to stay). A practical section goes after the last practical heading or, when there is none, after the last heading; any other section goes in the middle, never after a practical heading.',
				'worth'  => 'what makes the place worth it or what the reader would not expect',
				'friend' => 'a well-travelled friend',
			),
			'wine' => array(
				'kind'   => 'wine',
				'writer' => 'wine writer',
				'house'  => 'Winetalk, a wine and food media house',
				'reader' => 'a wine lover',
				'gaps'   => 'grapes, style and taste, the region and its soils, vintages, how to serve it, food to go with it, price level, where to buy it, how long it keeps',
				'lead'   => 'Describe the wine, the grape, the region or the producer. Concrete and specific: taste, place, people.',
				'never'  => 'top-10 lists, scores out of 100, grading producers or wine shops, selling bottles, knocking other wines or regions',
				'order'  => 'Every Winetalk text runs: inviting intro, the middle (the wine, the place, the people), the practical part last (serving, food, price, where to buy). A practical section goes after the last heading; any other section goes in the middle.',
				'worth'  => 'what makes the wine or region worth knowing or what the reader would not expect',
				'friend' => 'a friend who knows wine',
			),
			'sport' => array(
				'kind'   => 'sport',
				'writer' => 'sports journalist',
				'house'  => 'WorldSportTalk, an international sport media house',
				'reader' => 'a fan',
				'gaps'   => 'the background, the key people, the numbers and records, the history, what is at stake, what comes next, how to follow or watch it',
				'lead'   => 'Describe the athlete, team, event or game. Concrete and specific: results, moments, people.',
				'never'  => 'top-10 lists, betting tips or odds, ranking or grading people beyond the record, rumours stated as facts',
				'order'  => 'Every WorldSportTalk text runs: inviting intro, the middle (the story, the record, the context), the facts and what comes next last. A section on facts or what comes next goes after the last heading; any other section goes in the middle.',
				'worth'  => 'what makes the story matter or what the reader would not expect',
				'friend' => 'a friend who follows the sport',
			),
			'think' => array(
				'kind'   => 'non-fiction',
				'writer' => 'non-fiction writer on clear thinking and decisions',
				'house'  => 'Think Smarter, a media house on clear thinking, learning and better decisions',
				'reader' => 'a curious reader',
				'gaps'   => 'a clear definition, where the idea comes from, the evidence for and against, a worked example, common mistakes, how to use it in daily life',
				'lead'   => 'Explain the idea, the method or the finding. Concrete and specific: one example before any general claim.',
				'never'  => 'top-10 lists, self-help promises, selling courses or products, medical or financial advice for the individual reader',
				'order'  => 'Every Think Smarter text runs: inviting intro, the middle (the idea, the evidence, the examples), how to use it last. A section on using it goes after the last heading; any other section goes in the middle.',
				'worth'  => 'what makes the idea useful or what the reader would not expect',
				'friend' => 'a well-read friend',
			),
		);
		$s = self::get();
		return isset( $w[ $s ][ $key ] ) ? $w[ $s ][ $key ] : $w['travel'][ $key ];
	}
}
