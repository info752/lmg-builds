<?php
/**
 * 2.9.4 (G, 9 Nov 2026): "More about X" on traveltalk.travel, at the end of every country page and
 * every article: help the reader on to the right next page for where they are in their search.
 *
 *   Get inspired    articles about the same country that are not planning articles
 *   Plan your trip  when to go, budget, routes, where to stay, visas …
 *   Nearby          the country pages of the other countries in the same region
 *
 * Built from what the bridge stores on .travel: _lmgt_remote_url (the traveltalk.dk original) and
 * _lmgt_trail (its place in .dk's structure). English pages only, links only to this site. Up to
 * 3 cards a row; an empty row is not shown; an article already linked from the text is left out.
 * Meta _lmgt_row on an article (inspire|plan|none) moves it by hand. Index cached 6 hours.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class LMGT_More {

	const IDX  = 'lmgt_more_idx';
	const PLAN = '/\b(when to|best time|weather|climate|season|budget|cost|price|prices|money|visa|itinerar|route|getting (there|around)|how to|practical|where to stay|accommodation|hotel|tips|guide|plan|planning|transport|flights?|safety|vaccin)/i';

	public static function boot() {
		if ( ! LMGT_Bridge::is_target() ) return;
		add_filter( 'the_content', array( __CLASS__, 'render' ), 34 );
		add_action( 'save_post', function () { delete_transient( LMGT_More::IDX ); } );
		add_action( 'add_meta_boxes', function () {
			add_meta_box( 'lmgt_more', 'More about – row', array( __CLASS__, 'box' ), LMGT_Store::types( true ), 'side', 'low' );
		} );
		add_action( 'save_post', array( __CLASS__, 'save_box' ), 20 );
	}

	private static function path( $url ) {
		return untrailingslashit( strtolower( (string) wp_parse_url( (string) $url, PHP_URL_PATH ) ) );
	}

	/** [id => [dk, trail[], page, lang, title, row]] for every published English item that has a traveltalk.dk original. */
	private static function index() {
		$idx = get_transient( self::IDX );
		if ( is_array( $idx ) ) return $idx;
		$idx = array();
		$q   = get_posts( array( 'post_type' => LMGT_Store::types( true ), 'post_status' => 'publish', 'posts_per_page' => -1, 'meta_key' => '_lmgt_remote_url', 'no_found_rows' => true ) );
		foreach ( $q as $p ) {
			$lang = $p->post_type === LMGT_CPT ? (string) get_post_meta( $p->ID, '_lmgt_lang', true ) : 'en';
			if ( $lang !== 'en' ) continue;
			$trail = array();
			foreach ( (array) get_post_meta( $p->ID, '_lmgt_trail', true ) as $l ) if ( ! empty( $l['url'] ) ) $trail[] = self::path( $l['url'] );
			$page = $p->post_type === 'page' || ( $p->post_type === LMGT_CPT && get_post_meta( $p->ID, '_lmgt_source_type', true ) === 'page' );
			$idx[ $p->ID ] = array(
				'dk'    => self::path( get_post_meta( $p->ID, '_lmgt_remote_url', true ) ),
				'trail' => $trail,
				'page'  => $page,
				'title' => html_entity_decode( get_the_title( $p ), ENT_QUOTES, 'UTF-8' ),
				'row'   => (string) get_post_meta( $p->ID, '_lmgt_row', true ),
				'date'  => $p->post_date_gmt,
			);
		}
		set_transient( self::IDX, $idx, 6 * HOUR_IN_SECONDS );
		return $idx;
	}

	/** A page's region: the last level of its trail, else the parent of its traveltalk.dk address. */
	private static function region_of( array $it ) {
		if ( $it['trail'] ) return end( $it['trail'] );
		$d = dirname( $it['dk'] );
		return $d === '/' || $d === '.' ? '' : $d;
	}

	/** The country (and its region) a page or article is about, as traveltalk.dk paths. */
	private static function where( $id, array $idx ) {
		if ( ! isset( $idx[ $id ] ) ) return null;
		$me = $idx[ $id ];
		if ( $me['page'] ) {
			// A country page has articles under it; a region page (Asia) does not get this.
			return array( 'country' => $me['dk'], 'region' => self::region_of( $me ) );
		}
		$n = count( $me['trail'] );
		if ( ! $n ) return null;
		return array( 'country' => $me['trail'][ $n - 1 ], 'region' => $n > 1 ? $me['trail'][ $n - 2 ] : '' );
	}

	public static function render( $content ) {
		if ( is_admin() || ! is_singular() || ! in_the_loop() || ! is_main_query() || get_option( 'lmgt_more_on', '1' ) !== '1' ) return $content;
		$id  = get_the_ID();
		$idx = self::index();
		$w   = self::where( $id, $idx );
		if ( ! $w || $w['country'] === '' ) return $content;

		$hub = 0;
		foreach ( $idx as $pid => $it ) if ( $it['page'] && $it['dk'] === $w['country'] ) { $hub = $pid; break; }
		$arts = array();
		foreach ( $idx as $pid => $it ) {
			if ( $pid === $id || $it['page'] || $it['row'] === 'none' || ! in_array( $w['country'], $it['trail'], true ) ) continue;
			if ( strpos( $content, self::path( get_permalink( $pid ) ) . '/' ) !== false ) continue;
			$arts[ $pid ] = $it;
		}
		if ( ! $hub && ! $arts ) return $content;
		uasort( $arts, function ( $a, $b ) { return strcmp( $b['date'], $a['date'] ); } );
		$inspire = $plan = array();
		foreach ( $arts as $pid => $it ) {
			$is_plan = $it['row'] === 'plan' || ( $it['row'] !== 'inspire' && preg_match( self::PLAN, $it['title'] ) );
			if ( $is_plan ) $plan[] = $pid; else $inspire[] = $pid;
		}
		$near = array();
		if ( $w['region'] !== '' ) {
			foreach ( $idx as $pid => $it ) {
				if ( ! $it['page'] || $pid === $id || $it['dk'] === $w['country'] || $it['dk'] === $w['region'] ) continue;
				if ( self::region_of( $it ) === $w['region'] ) $near[] = $pid;
			}
			shuffle( $near ); // a different neighbour now and then; the page cache keeps it steady for a while
		}

		$name = $hub ? LMGT_Trail::short( $idx[ $hub ]['title'] ) : '';
		if ( $name !== '' ) $name = preg_replace( '/^(travel(ling)? to|visit|discover|explore)\s+/i', '', $name );
		$out  = '';
		$rows = array(
			array( 'Get inspired', array_slice( $inspire, 0, 3 ) ),
			array( 'Plan your trip', array_slice( $plan, 0, 3 ) ),
			array( 'Nearby', array_slice( $near, 0, 3 ) ),
		);
		// On an article, the country page itself comes first under Plan your trip, unless the text links it.
		if ( $hub && $hub !== $id && strpos( $content, self::path( get_permalink( $hub ) ) . '/' ) === false ) {
			array_unshift( $rows[1][1], $hub );
			$rows[1][1] = array_slice( $rows[1][1], 0, 3 );
		}
		foreach ( $rows as $r ) {
			if ( ! $r[1] ) continue;
			$out .= '<h3 class="lmgt-more-row">' . esc_html( $r[0] ) . '</h3>' . self::cards( $r[1] );
		}
		if ( $out === '' ) return $content;
		$title = $name !== '' ? 'More about ' . $name : 'More to read';
		return $content . '<section class="lmgt-more"><h2>' . esc_html( $title ) . '</h2>' . $out . '</section>';
	}

	private static function cards( array $ids ) {
		$li = '';
		foreach ( $ids as $tid ) {
			$url = get_permalink( $tid );
			$img = get_the_post_thumbnail_url( $tid, 'medium_large' );
			$ex  = wp_trim_words( wp_strip_all_tags( get_the_excerpt( $tid ) ), 16, '…' );
			$li .= '<li class="kb-post-list-item"><article class="entry content-bg loop-entry">'
				. ( $img ? '<a aria-hidden="true" tabindex="-1" class="post-thumbnail" href="' . esc_url( $url ) . '"><div class="post-thumbnail-inner"><img src="' . esc_url( $img ) . '" alt="" loading="lazy" decoding="async"></div></a>' : '' )
				. '<div class="entry-content-wrap"><header class="entry-header"><h3 class="entry-title"><a href="' . esc_url( $url ) . '">' . esc_html( html_entity_decode( get_the_title( $tid ), ENT_QUOTES, 'UTF-8' ) ) . '</a></h3></header>'
				. ( $ex !== '' ? '<div class="entry-summary"><p>' . esc_html( $ex ) . '</p></div>' : '' )
				. '<footer class="entry-footer"><p class="more-link-wrap"><a class="post-more-link" href="' . esc_url( $url ) . '">Read more</a></p></footer></div></article></li>';
		}
		return '<ul class="kb-posts kadence-posts-list content-wrap grid-cols kb-posts-style-boxed item-image-style-above lmgt-related lmgt-more-grid">' . $li . '</ul>'
			. '<style>.lmgt-more{margin-top:3em}.lmgt-more-row{margin:1.6em 0 .2em;font-size:1.05em;text-transform:uppercase;letter-spacing:.06em;color:#b08d57}.lmgt-more-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:2rem;list-style:none;margin:1em 0 2em;padding:0}.lmgt-more-grid .post-thumbnail-inner{aspect-ratio:3/2;overflow:hidden}.lmgt-more-grid img{width:100%;height:100%;object-fit:cover;display:block}.lmgt-more-grid .entry-title{font-size:1.1em;margin:.6em 0 .3em}</style>';
	}

	public static function box( $post ) {
		$v = (string) get_post_meta( $post->ID, '_lmgt_row', true );
		echo '<input type="hidden" name="lmgt_row_box" value="1">' . wp_nonce_field( 'lmgt_row_' . $post->ID, 'lmgt_row_nonce', true, false ) . '<select name="lmgt_row" style="width:100%">';
		foreach ( array( '' => 'Decide by itself', 'inspire' => 'Get inspired', 'plan' => 'Plan your trip', 'none' => 'Leave it out' ) as $k => $l ) echo '<option value="' . esc_attr( $k ) . '"' . selected( $v, $k, false ) . '>' . esc_html( $l ) . '</option>';
		echo '</select><p class="description">Where this article shows in "More about …" on the other pages of its country.</p>';
	}

	public static function save_box( $id ) {
		if ( empty( $_POST['lmgt_row_box'] ) || ! isset( $_POST['lmgt_row_nonce'] ) || ! wp_verify_nonce( $_POST['lmgt_row_nonce'], 'lmgt_row_' . $id ) || ! current_user_can( 'edit_post', $id ) ) return;
		$v = isset( $_POST['lmgt_row'] ) && in_array( $_POST['lmgt_row'], array( 'inspire', 'plan', 'none' ), true ) ? $_POST['lmgt_row'] : '';
		if ( $v === '' ) delete_post_meta( $id, '_lmgt_row' ); else update_post_meta( $id, '_lmgt_row', $v );
		delete_transient( self::IDX );
	}
}
