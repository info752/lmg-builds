<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.20.0 (G, 23 Nov 2026): structured data that says what each page is.
 *
 *   - headline: the article's own title, without " - traveltalk.travel".
 *   - author: the original's writer. On traveltalk.travel the copies are
 *     saved by the bridge user, whose name ("LMG Translator bridge") Google
 *     showed as the author; it is replaced by the writer sent from .dk, else
 *     the publisher (Organization).
 *   - inLanguage: one value per page, the page's own language (hreflang code).
 *   - translationOfWork on a translation (pointing at the original), and
 *     workTranslation on the original (its translations): the hreflang set,
 *     said in schema.org as well.
 *   - translator: the publisher, on translations.
 *   - the main image's caption in the page's language, or none rather than
 *     a Danish caption on an English page.
 *   - destination guides: about → TouristDestination (with the region it lies
 *     in as containedInPlace), so the page is tied to the place, not only to words.
 */
class LMGT_Schema {

	const INTEREST = '/interest|rejseinteresse|reseintresse|reiseinteresse|matkateema|reisethem|th[eè]mes? de voyage|temas? de viaj|temi di viaggio|temas de viagem/i';

	public static function boot() {
		add_filter( 'rank_math/json_ld', array( __CLASS__, 'graph' ), PHP_INT_MAX - 5, 2 );
	}

	public static function on() {
		return (bool) get_option( 'lmgt_schema_plus', 1 );
	}

	public static function graph( $data, $jsonld = null ) {
		if ( ! self::on() || ! is_array( $data ) ) return $data;
		$lang = LMGT_Front::current_lang();
		$code = $lang ? LMGT_Bridge::hreflang_code( $lang ) : self::site_code();
		array_walk_recursive( $data, function ( &$v, $k ) use ( $code ) {
			if ( $k === 'inLanguage' ) $v = $code;
		} );
		if ( ! is_singular() || is_front_page() ) return $data;
		$post = get_queried_object();
		if ( ! $post instanceof WP_Post ) return $data;
		$is_tr = $post->post_type === LMGT_CPT;
		$title = trim( html_entity_decode( wp_strip_all_tags( get_the_title( $post ) ), ENT_QUOTES, 'UTF-8' ) );
		$org   = array( '@id' => home_url( '/#organization' ) );

		$set  = self::versions( $post );
		$self = get_permalink( $post );
		$orig = $is_tr ? self::original_url( $post ) : '';
		$bot  = self::bridge_user( $post );
		$who  = $is_tr ? trim( (string) get_post_meta( $post->ID, '_lmgt_author_name', true ) ) : '';
		$dest = self::destination( $post, $data );

		$drop = array();
		foreach ( $data as $key => &$node ) {
			if ( ! is_array( $node ) || empty( $node['@type'] ) ) continue;
			$types = (array) $node['@type'];

			if ( array_intersect( $types, array( 'Article', 'BlogPosting', 'NewsArticle' ) ) ) {
				if ( $title !== '' ) $node['headline'] = mb_substr( $title, 0, 110 );
				if ( isset( $node['name'] ) && $title !== '' ) $node['name'] = $title;
				if ( $bot ) $node['author'] = $who !== '' ? array( '@type' => 'Person', 'name' => $who ) : $org;
				if ( $is_tr ) {
					$node['translator'] = $org;
					if ( $orig !== '' ) $node['translationOfWork'] = array( '@type' => 'CreativeWork', '@id' => $orig, 'url' => $orig );
				}
				$others = $is_tr ? array() : array_values( array_filter( $set, function ( $u ) use ( $self, $orig ) { return $u !== $self && $u !== $orig; } ) );
				if ( $others ) $node['workTranslation'] = array_map( function ( $u ) { return array( '@type' => 'CreativeWork', '@id' => $u, 'url' => $u ); }, $others );
				if ( $dest ) $node['about'] = $dest;
			}

			if ( in_array( 'WebPage', $types, true ) && $dest && empty( $node['about'] ) ) $node['about'] = $dest;

			if ( in_array( 'Person', $types, true ) && $bot && isset( $node['@id'] ) && strpos( (string) $node['@id'], '/author/' ) !== false && self::is_bot_node( $node ) ) {
				$drop[] = $key;
				continue;
			}

			if ( $is_tr && in_array( 'ImageObject', $types, true ) && isset( $node['caption'] ) ) {
				$cap = self::caption( $post, $lang );
				if ( $cap !== '' ) $node['caption'] = $cap; else unset( $node['caption'] );
			}
		}
		unset( $node );
		foreach ( $drop as $k ) unset( $data[ $k ] );
		return $data;
	}

	private static function site_code() {
		$c = LMGT_Langs::source();
		return $c ? LMGT_Bridge::hreflang_code( $c ) : substr( get_locale(), 0, 2 );
	}

	/** Every published version's address, source first (as the hreflang set). */
	private static function versions( $post ) {
		$set = array();
		if ( LMGT_Bridge::on() ) {
			$s = LMGT_Bridge::current_set();
			if ( ! empty( $s['members'] ) ) $set = $s['members'];
		}
		if ( ! $set ) $set = LMGT_Front::cluster();
		return array_values( array_unique( array_filter( array_map( 'strval', (array) $set ) ) ) );
	}

	private static function original_url( $post ) {
		$u = (string) get_post_meta( $post->ID, '_lmgt_remote_url', true );
		if ( $u !== '' ) return $u;
		$src = (int) get_post_meta( $post->ID, '_lmgt_source', true );
		return $src && get_post_status( $src ) === 'publish' ? (string) get_permalink( $src ) : '';
	}

	/** The page is saved by the bridge's own user, not by a writer. */
	private static function bridge_user( $post ) {
		$u = get_userdata( (int) $post->post_author );
		if ( ! $u ) return true;
		return $u->user_login === 'lmgt-bridge' || $u->user_nicename === 'lmgt-bridge' || stripos( (string) $u->display_name, 'translator bridge' ) !== false;
	}

	private static function is_bot_node( $node ) {
		return strpos( (string) $node['@id'], '/author/lmgt-bridge' ) !== false || ( isset( $node['name'] ) && stripos( (string) $node['name'], 'translator bridge' ) !== false );
	}

	private static function caption( $post, $lang ) {
		$att = get_post_thumbnail_id( $post );
		if ( ! $att || ! $lang ) return '';
		$c = trim( wp_strip_all_tags( (string) get_post_meta( $att, '_lmgt_caption_' . $lang, true ) ) );
		if ( $c === '' ) $c = trim( (string) get_post_meta( $att, '_lmgt_alt_' . $lang, true ) );
		return $c;
	}

	/**
	 * A destination guide: a page (or a translation of one) placed under a region
	 * in its breadcrumb, not under travel interests. [TouristDestination] or null.
	 */
	private static function destination( $post, array $data ) {
		$page = $post->post_type === 'page' || ( $post->post_type === LMGT_CPT && get_post_meta( $post->ID, '_lmgt_source_type', true ) === 'page' );
		if ( ! $page ) return null;
		$crumbs = array();
		foreach ( $data as $n ) {
			if ( is_array( $n ) && isset( $n['@type'] ) && $n['@type'] === 'BreadcrumbList' && ! empty( $n['itemListElement'] ) ) {
				foreach ( $n['itemListElement'] as $li ) {
					$crumbs[] = array(
						'name' => isset( $li['item']['name'] ) ? html_entity_decode( (string) $li['item']['name'], ENT_QUOTES, 'UTF-8' ) : '',
						'url'  => isset( $li['item']['@id'] ) ? (string) $li['item']['@id'] : '',
					);
				}
			}
		}
		if ( count( $crumbs ) < 3 ) return null;
		foreach ( $crumbs as $c ) {
			if ( preg_match( self::INTEREST, $c['name'] . ' ' . $c['url'] ) ) return null;
		}
		$skip = array_filter( array_map( 'intval', explode( ',', (string) get_option( 'lmgt_rm_skip', '' ) ) ) );
		if ( in_array( (int) $post->ID, $skip, true ) ) return null;
		$here   = end( $crumbs );
		$parent = $crumbs[ count( $crumbs ) - 2 ];
		$name   = trim( strtok( (string) get_post_meta( $post->ID, 'rank_math_focus_keyword', true ), ',' ) );
		if ( $name === '' || mb_stripos( $here['name'], $name ) === false ) $name = $here['name'];
		if ( $name === '' ) return null;
		$out = array( '@type' => 'TouristDestination', 'name' => $name, 'url' => get_permalink( $post ) );
		if ( $parent['name'] !== '' && untrailingslashit( $parent['url'] ) !== untrailingslashit( home_url( '/' ) ) ) {
			$out['containedInPlace'] = array_filter( array( '@type' => 'Place', 'name' => $parent['name'], 'url' => $parent['url'] ) );
		}
		$img = get_the_post_thumbnail_url( $post, 'full' );
		if ( $img ) $out['image'] = $img;
		return $out;
	}
}
