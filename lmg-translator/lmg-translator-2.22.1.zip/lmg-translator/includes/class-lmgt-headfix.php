<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Headings that swallowed the text after them (2.3.2, rewritten in 2.21.1).
 *
 * 2.3.2 only knew <hN>Head\n\nText</hN>. On 23 Nov 2026 the "Know before you go" box on
 * traveltalk.travel came back as <h2>Title\n\nQ? A\n\n<h3>Q2?\n\nA2…: closing tags gone,
 * so the browser showed the questions in H2 letters. The editor then folded it into
 * <h2>Title Q? A</h2>. 2.3.2's lazy <h2>(.*?)</h2> also ran across sections and could strip
 * their <p> tags. Now each heading, every level, ends where a heading can no longer go on:
 * its own close, a blank line, a paragraph, another heading, any block tag or block comment.
 * Text cut off is put back as paragraphs, stray closing heading tags are dropped, and the
 * questions box is rebuilt from what is left. Runs on save, before translating, on display,
 * in the bulk check under Translator → Heading check, and in a daily check.
 */
class LMGT_Headfix {

	const SCAN_HOOK = 'lmgt_headfix_scan';
	const STOP      = '#\R[ \t]*\R|</?(?:p|div|ul|ol|li|dl|dt|dd|table|thead|tbody|tr|td|th|figure|figcaption|blockquote|section|article|aside|header|footer|nav|pre|hr|form|details|summary|iframe|h[1-6])(?=[\s>/])[^>]*>|<!--|<lmgt-p\b#iu';
	const Q_WORDS   = 'Do|Does|Did|Is|Are|Was|Can|Could|Should|Shall|Will|Would|What|Which|When|Where|Why|How|Who|Whom|Whose|Must|May|Have|Has|Hvad|Hvor|Hvordan|Hvornår|Hvilke|Hvilken|Hvilket|Hvem|Hvorfor|Kan|Skal|Er|Må|Har|Bør|Behøver|Findes|Gibt|Wie|Was|Wann|Wo|Warum|Welche|Welcher|Kann|Muss|Brauche|Ist|Sind|Hur|När|Vad|Vilken|Vilka|Finns|Behöver|Måste|Hva|Når|Hvilke|Trenger';

	public static function boot() {
		add_filter( 'wp_insert_post_data', array( __CLASS__, 'on_save' ), 9, 2 );
		add_filter( 'the_content', array( __CLASS__, 'on_display' ), 4 );
		add_action( 'admin_menu', function () {
			add_submenu_page( 'lmgt', 'Heading check', 'Heading check', 'edit_others_posts', 'lmgt-headings', array( __CLASS__, 'page' ) );
		}, 60 );
		add_action( 'admin_post_lmgt_headings_fix', array( __CLASS__, 'handle_fix' ) );
		add_action( self::SCAN_HOOK, array( __CLASS__, 'scan_daily' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
		add_action( 'init', function () {
			if ( ! wp_next_scheduled( self::SCAN_HOOK ) ) wp_schedule_event( time() + 300, 'daily', self::SCAN_HOOK );
		} );
	}

	public static function on_save( $data, $raw ) {
		if ( empty( $data['post_content'] ) || ( isset( $data['post_type'] ) && $data['post_type'] === 'revision' ) ) return $data;
		$html  = wp_unslash( $data['post_content'] );
		$place = strpos( $html, 'lmgt-faq' ) === false ? '' : self::place_for( isset( $raw['ID'] ) ? (int) $raw['ID'] : 0, isset( $data['post_title'] ) ? wp_unslash( $data['post_title'] ) : '' );
		$fixed = self::fix_all( $html, $place );
		if ( $fixed !== $html ) $data['post_content'] = wp_slash( $fixed );
		return $data;
	}

	/** Display: the visitor never sees a swallowed heading, even before the page is saved again. */
	public static function on_display( $content ) {
		if ( stripos( $content, '<h' ) === false ) return $content;
		$p = get_post();
		return self::fix_all( $content, $p && strpos( $content, 'lmgt-faq' ) !== false ? self::place_for( $p->ID, $p->post_title ) : '' );
	}

	private static function place_for( $id, $title ) {
		if ( $id && class_exists( 'LMGT_Boxes' ) && ( $p = get_post( $id ) ) ) return LMGT_Boxes::place_name( $p );
		return html_entity_decode( (string) $title, ENT_QUOTES, 'UTF-8' );
	}

	/** Every repair in order: headings, then the questions box. */
	public static function fix_all( $html, $place = '' ) {
		$html = (string) $html;
		if ( stripos( $html, '<h' ) === false || ! mb_check_encoding( $html, 'UTF-8' ) ) return $html;
		$out = self::repair( $html );
		if ( is_string( $out ) && strpos( $out, 'lmgt-faq' ) !== false ) $out = self::fix_faq( $out, $place );
		// Never hand back less than came in: a failed pattern returns null, and the text stays as it was.
		if ( ! is_string( $out ) || preg_last_error() !== PREG_NO_ERROR || mb_strlen( self::txt( $out ) ) < mb_strlen( self::txt( $html ) ) * 0.98 ) return $html;
		return $out;
	}

	/** True when a text still has a heading that holds body text. */
	public static function broken( $html, $place = '' ) {
		return self::fix_all( $html, $place ) !== $html;
	}

	public static function repair( $html ) {
		$html = (string) $html;
		if ( stripos( $html, '<h' ) === false || ! mb_check_encoding( $html, 'UTF-8' ) ) return $html;
		$orig = $html;
		// Block editor: a heading block keeps its own comments; the cut-off text becomes paragraph blocks after it.
		$html = preg_replace_callback( '#(<!-- wp:heading(?: \{[^\n]*?\})? -->\s*)<h([1-6])(?=[\s>])([^>]*)>((?:(?!<!-- /?wp:).)*?)</h\2>(\s*<!-- /wp:heading -->)#is', function ( $m ) {
			$s = self::split_inner( $m[4] );
			if ( ! $s ) return $m[0];
			$out = $m[1] . '<h' . $m[2] . $m[3] . '>' . $s[0] . '</h' . $m[2] . '>' . $m[5];
			foreach ( $s[1] as $p ) $out .= "\n\n<!-- wp:paragraph -->\n<p>" . $p . "</p>\n<!-- /wp:paragraph -->";
			return $out;
		}, $html );
		$html = self::balance( $html );
		$html = self::split_long( $html );
		$html = self::drop_strays( $html );
		return $html === $orig ? $orig : $html;
	}

	/** [head, paragraphs] when a heading's inner HTML holds a paragraph break, else null. */
	private static function split_inner( $inner ) {
		if ( ! preg_match( '#\R[ \t]*\R|(?:<br\s*/?>\s*)+|</?p(?:\s[^>]*)?>#iu', $inner, $b, PREG_OFFSET_CAPTURE ) ) return null;
		$head = trim( substr( $inner, 0, $b[0][1] ) );
		$rest = trim( preg_replace( '#</?p(?:\s[^>]*)?>#i', "\n\n", substr( $inner, $b[0][1] + strlen( $b[0][0] ) ) ) );
		if ( $head === '' || $rest === '' ) return null;
		if ( stripos( $b[0][0], '<br' ) === 0 && mb_strlen( wp_strip_all_tags( $rest ) ) < 120 ) return null;
		return array( $head, self::paras( $rest ) );
	}

	private static function paras( $text ) {
		return array_values( array_filter( array_map( 'trim', preg_split( '#\R[ \t]*\R#u', $text ) ), 'strlen' ) );
	}

	/** Walk the headings: close each where it must end, keep cut-off text as paragraphs, drop closing tags left alone. */
	private static function balance( $html ) {
		$out = '';
		$pos = 0;
		$len = strlen( $html );
		$orphans = array(); // level => count of closes to drop
		while ( preg_match( '#<h([1-6])(?=[\s>])[^>]*>#i', $html, $m, PREG_OFFSET_CAPTURE, $pos ) ) {
			$at    = $m[0][1];
			$lvl   = $m[1][0];
			$start = $at + strlen( $m[0][0] );
			$out  .= self::drop_orphans( substr( $html, $pos, $at - $pos ), $orphans ) . $m[0][0];
			$close = stripos( $html, '</h' . $lvl . '>', $start );
			$stop  = preg_match( self::STOP, $html, $s, PREG_OFFSET_CAPTURE, $start ) ? $s[0][1] : $len;
			// A <br> inside a heading is a wanted two-line headline unless real body text follows it.
			if ( preg_match( '#(?:<br\s*/?>\s*)+#i', $html, $br, PREG_OFFSET_CAPTURE, $start ) && $br[0][1] < min( $stop, $close === false ? $len : $close ) ) {
				$after = substr( $html, $br[0][1], min( $stop, $close === false ? $len : $close ) - $br[0][1] );
				if ( mb_strlen( trim( wp_strip_all_tags( $after ) ) ) >= 120 ) $stop = $br[0][1];
			}
			if ( $close !== false && ( $close <= $stop || trim( substr( $html, $stop, $close - $stop ) ) === '' ) ) {
				$out .= substr( $html, $start, $close + 5 - $start );
				$pos  = $close + 5;
				continue;
			}
			$head = rtrim( substr( $html, $start, $stop - $start ) );
			// Nothing before the cut: no empty heading, the opening tag goes.
			if ( trim( wp_strip_all_tags( $head ) ) === '' ) $out = substr( $out, 0, -strlen( $m[0][0] ) ) . $head;
			else $out .= $head . '</h' . $lvl . '>';
			$pos  = $stop;
			// Skip the break itself, then collect loose text until the next tag that starts a block.
			if ( preg_match( '#\G(?:\R[ \t]*\R|(?:<br\s*/?>\s*)+)#iu', $html, $bb, 0, $pos ) ) $pos += strlen( $bb[0] );
			$loose_end = preg_match( '#</?(?:p|div|ul|ol|li|dl|table|figure|blockquote|section|article|aside|pre|hr|form|details|iframe|h[1-6])(?=[\s>/])[^>]*>|<!--|<lmgt-p\b#i', $html, $le, PREG_OFFSET_CAPTURE, $pos ) ? $le[0][1] : $len;
			$loose = substr( $html, $pos, $loose_end - $pos );
			if ( trim( wp_strip_all_tags( $loose ) ) !== '' ) {
				foreach ( self::paras( $loose ) as $p ) $out .= "\n<p>" . $p . '</p>';
				$out .= "\n";
				$pos  = $loose_end;
			}
			// The heading's own late close now has no opening: drop it, unless another heading of that level claims it first.
			$next_open = preg_match( '#<h' . $lvl . '(?=[\s>])#i', $html, $no, PREG_OFFSET_CAPTURE, $pos ) ? $no[0][1] : $len;
			$late      = stripos( $html, '</h' . $lvl . '>', $pos );
			if ( $late !== false && $late < $next_open ) $orphans[ $lvl ] = ( isset( $orphans[ $lvl ] ) ? $orphans[ $lvl ] : 0 ) + 1;
		}
		$out .= self::drop_orphans( substr( $html, $pos ), $orphans );
		return $out;
	}

	private static function drop_orphans( $chunk, array &$orphans ) {
		foreach ( $orphans as $lvl => $n ) {
			if ( $n < 1 ) continue;
			$chunk = preg_replace_callback( '#\s*</h' . $lvl . '>#i', function () use ( &$orphans, $lvl ) {
				if ( $orphans[ $lvl ] < 1 ) return func_get_arg( 0 )[0];
				$orphans[ $lvl ]--;
				return '';
			}, $chunk );
		}
		return $chunk;
	}

	/**
	 * Already folded by the editor, so no tag is missing: <h3>Question? Long answer…</h3>, or
	 * lines of body text inside one heading. A heading over 120 characters is cut at its first
	 * line break, else after a question mark followed by 40+ characters.
	 */
	private static function split_long( $html ) {
		return preg_replace_callback( '#<h([2-6])(?=[\s>])([^>]*)>((?:(?!</?h[1-6][\s>]).)*?)</h\1>#is', function ( $m ) {
			$t = trim( $m[3] );
			if ( preg_match( '#</?(?:p|div|ul|ol|li|table|figure|blockquote)[\s>]|<!--#i', $t ) ) return $m[0];
			$plain = self::txt( $t );
			if ( mb_strlen( $plain ) <= 120 ) return $m[0];
			$open = '<h' . $m[1] . $m[2] . '>';
			$cls  = '</h' . $m[1] . '>';
			if ( preg_match( '#^(.+?)\R\s*(\S.*)$#su', $t, $x ) ) return $open . trim( $x[1] ) . $cls . "\n<p>" . implode( "</p>\n<p>", self::paras( preg_replace( '#\R#u', "\n\n", $x[2] ) ) ) . '</p>';
			if ( preg_match( '#^([^<]+?\?)\s+(\S[^<]{39,})$#su', $t, $x ) ) return $open . $x[1] . $cls . "\n<p>" . $x[2] . '</p>';
			return $m[0];
		}, $html );
	}

	/** Last pass: a closing heading tag with no heading open goes. */
	private static function drop_strays( $html ) {
		$open = 0;
		return preg_replace_callback( '#<h([1-6])(?=[\s>])[^>]*>|\s*</h([1-6])>#i', function ( $m ) use ( &$open ) {
			if ( isset( $m[2] ) && $m[2] !== '' ) {
				if ( (int) $m[2] === $open ) { $open = 0; return $m[0]; }
				return '';
			}
			$open = (int) $m[1];
			return $m[0];
		}, $html );
	}

	/** The questions box: title in the H2, every question an H3, every answer a paragraph. */
	public static function fix_faq( $html, $place = '' ) {
		return preg_replace_callback( '#(<div class="lmgt-box lmgt-faq"[^>]*>)(.*?)(</div>)#is', function ( $m ) use ( $place ) {
			$x = self::faq_read( $m[2], $place );
			if ( ! $x ) return $m[0];
			$nl = strpos( $m[2], "\n" ) !== false ? "\n" : '';
			$h  = $m[1] . $nl . '<h2>' . esc_html( $x[0] ) . '</h2>' . $nl;
			foreach ( $x[1] as $e ) $h .= '<h3>' . esc_html( $e['q'] ) . '</h3>' . $nl . '<p>' . esc_html( $e['a'] ) . '</p>' . $nl;
			$new = $h . $m[3];
			return self::norm( $new ) === self::norm( $m[0] ) ? $m[0] : $new;
		}, $html );
	}

	private static function norm( $h ) {
		return preg_replace( '/\s+/', ' ', html_entity_decode( preg_replace( '/>\s+</', '><', $h ), ENT_QUOTES, 'UTF-8' ) );
	}

	private static function txt( $h ) {
		return trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( html_entity_decode( $h, ENT_QUOTES, 'UTF-8' ) ) ) );
	}

	/** [title, [[q, a], …]] read loosely from a box, line by line, or null when nothing can be read. */
	public static function faq_read( $inner, $place = '' ) {
		$t = preg_replace( '#<h2(?=[\s>])[^>]*>#i', "\n@@T ", (string) $inner );
		$t = preg_replace( '#<h[3-6](?=[\s>])[^>]*>#i', "\n@@Q ", $t );
		$t = preg_replace( '#</h[1-6]>|</?p(?=[\s>/])[^>]*>|<br\s*/?>|</?div[^>]*>#i', "\n", $t );
		$lines = array();
		foreach ( preg_split( '#\R#u', $t ) as $l ) {
			$k = 'L';
			if ( strpos( ltrim( $l ), '@@T ' ) === 0 ) { $k = 'T'; $l = substr( ltrim( $l ), 4 ); }
			elseif ( strpos( ltrim( $l ), '@@Q ' ) === 0 ) { $k = 'Q'; $l = substr( ltrim( $l ), 4 ); }
			$l = self::txt( $l );
			if ( $l !== '' ) $lines[] = array( $k, $l );
		}
		if ( ! $lines || $lines[0][0] !== 'T' ) return null;
		$title = $lines[0][1];
		array_shift( $lines );
		// Title holding the first question: "Know before you go: Place Do I need …? No. …"
		if ( strpos( $title, '?' ) !== false && ( $cut = self::title_end( $title, $place ) ) ) {
			array_unshift( $lines, array( 'L', trim( substr( $title, $cut ) ) ) );
			$title = trim( substr( $title, 0, $cut ) );
		}
		$qa = array();
		$q  = null;
		foreach ( $lines as $ln ) {
			list( $k, $l ) = $ln;
			$folded = preg_match( '#^(.{8,200}?\?)\s+(\S.{19,})$#su', $l, $x );
			if ( $k === 'Q' ) {
				if ( $q !== null ) $qa[] = array( 'q' => $q, 'a' => '' );
				if ( $folded ) { $qa[] = array( 'q' => $x[1], 'a' => $x[2] ); $q = null; } else $q = $l;
				continue;
			}
			if ( $q !== null ) { $qa[] = array( 'q' => $q, 'a' => $l ); $q = null; continue; }
			if ( $folded ) { $qa[] = array( 'q' => $x[1], 'a' => $x[2] ); continue; }
			if ( mb_strlen( $l ) <= 200 && substr( $l, -1 ) === '?' ) { $q = $l; continue; }
			if ( $qa ) { $qa[ count( $qa ) - 1 ]['a'] = trim( $qa[ count( $qa ) - 1 ]['a'] . ' ' . $l ); continue; }
		}
		$qa = array_values( array_filter( $qa, function ( $e ) { return $e['q'] !== '' && $e['a'] !== ''; } ) );
		return $qa && $title !== '' ? array( $title, $qa ) : null;
	}

	/** Where the box title ends when the first question was folded into it. */
	private static function title_end( $title, $place ) {
		foreach ( array_filter( array( $place ) ) as $pl ) {
			$i = mb_stripos( $title, $pl );
			if ( $i !== false ) {
				$end = strlen( mb_substr( $title, 0, $i + mb_strlen( $pl ) ) );
				$tail = substr( $title, $end );
				if ( preg_match( '#^(?:\s+før du rejser)?#u', $tail, $fr ) ) $end += strlen( $fr[0] );
				if ( strpos( substr( $title, $end ), '?' ) !== false ) return $end;
			}
		}
		$colon = strpos( $title, ':' );
		$from  = $colon === false ? 0 : $colon + 1;
		if ( preg_match( '#\s(?=(?:' . self::Q_WORDS . ')\b[^?]*\?)#u', $title, $w, PREG_OFFSET_CAPTURE, $from ) ) return $w[0][1];
		return 0;
	}

	// ---- Bulk check: Translator → Heading check --------------------------------------------

	private static function scan( $limit = 0 ) {
		global $wpdb;
		$types = array_values( array_diff( get_post_types( array( 'show_ui' => true ) ), array( 'attachment', 'wp_block', 'wp_template', 'wp_template_part', 'wp_navigation' ) ) );
		if ( ! $types ) return array();
		$in   = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_title, post_type, post_status, post_content FROM {$wpdb->posts} WHERE post_type IN ($in) AND post_status NOT IN ('trash','auto-draft','inherit') AND post_content LIKE %s ORDER BY ID", array_merge( $types, array( '%<h%' ) ) ) );
		$bad  = array();
		foreach ( $rows as $r ) {
			$place = strpos( $r->post_content, 'lmgt-faq' ) === false ? '' : self::place_for( (int) $r->ID, $r->post_title );
			if ( self::fix_all( $r->post_content, $place ) !== $r->post_content ) {
				$bad[] = array( 'id' => (int) $r->ID, 'title' => $r->post_title, 'type' => $r->post_type, 'status' => $r->post_status );
				if ( $limit && count( $bad ) >= $limit ) break;
			}
		}
		return $bad;
	}

	public static function scan_daily() {
		$bad = self::scan();
		update_option( 'lmgt_headfix_found', array( 'n' => count( $bad ), 'at' => time() ), false );
	}

	public static function notice() {
		if ( ! current_user_can( 'edit_others_posts' ) ) return;
		$s = get_current_screen();
		if ( $s && strpos( (string) $s->id, 'lmgt-headings' ) !== false ) return;
		$f = get_option( 'lmgt_headfix_found' );
		if ( ! is_array( $f ) || empty( $f['n'] ) ) return;
		echo '<div class="notice notice-warning"><p><strong>LMG Translator:</strong> ' . (int) $f['n'] . ' page(s) have a heading that swallowed the text under it (text shown in heading letters). Visitors already see them repaired. <a href="' . esc_url( admin_url( 'admin.php?page=lmgt-headings' ) ) . '">Repair them in the text</a>.</p></div>';
	}

	public static function page() {
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_die( 'Not allowed.' );
		$bad = self::scan();
		update_option( 'lmgt_headfix_found', array( 'n' => count( $bad ), 'at' => time() ), false );
		echo '<div class="wrap"><h1>Heading check</h1>';
		if ( isset( $_GET['fixed'] ) ) echo '<div class="notice notice-success"><p>' . (int) $_GET['fixed'] . ' page(s) repaired. The previous version of each is under Revisions.</p></div>';
		echo '<p>Finds pages where a heading swallowed the text after it, so questions, answers or paragraphs show in heading letters. Every heading level and the "Know before you go" box are checked, on originals and translations, published or not.</p>';
		if ( ! $bad ) { echo '<p><strong>✓ No page has a swallowed heading.</strong></p></div>'; return; }
		echo '<p><strong>' . count( $bad ) . ' page(s) to repair.</strong> Only the headings and the questions box change; every word stays.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="lmgt_headings_fix">';
		wp_nonce_field( 'lmgt_headings_fix' );
		echo '<p><button class="button button-primary">Repair all ' . count( $bad ) . '</button></p>';
		echo '<table class="widefat striped"><thead><tr><th>Page</th><th>Type</th><th>Status</th></tr></thead><tbody>';
		foreach ( $bad as $b ) echo '<tr><td><a href="' . esc_url( get_edit_post_link( $b['id'] ) ) . '">' . esc_html( $b['title'] !== '' ? $b['title'] : '#' . $b['id'] ) . '</a></td><td>' . esc_html( $b['type'] ) . '</td><td>' . esc_html( $b['status'] ) . '</td></tr>';
		echo '</tbody></table></form></div>';
	}

	public static function handle_fix() {
		check_admin_referer( 'lmgt_headings_fix' );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_die( 'Not allowed.' );
		@set_time_limit( 300 );
		$n = 0;
		foreach ( self::scan( 200 ) as $b ) {
			$p = get_post( $b['id'] );
			if ( ! $p || ! current_user_can( 'edit_post', $p->ID ) ) continue;
			$new = self::fix_all( $p->post_content, self::place_for( $p->ID, $p->post_title ) );
			if ( $new === $p->post_content ) continue;
			LMGT_Store::update_content( $p->ID, array( 'post_content' => $new ) );
			$n++;
		}
		self::scan_daily();
		wp_safe_redirect( admin_url( 'admin.php?page=lmgt-headings&fixed=' . $n ) );
		exit;
	}
}
