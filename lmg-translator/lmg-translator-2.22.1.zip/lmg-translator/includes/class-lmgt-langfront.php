<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Each language's front page: /en/, /sv/ … on page 1.
 *
 * Built, not translated. The source front page is made of moving parts (newest
 * posts, hero, category blocks), so a translated copy would be stale by the
 * next post and would link to source-language articles. Instead the page is
 * assembled from what exists in that language:
 *   - hero: the source front page's image, a fixed line in the language
 *   - guides: translated pages (country and pillar guides), A–Z
 *   - latest: the newest translated articles
 * It grows by itself as translations are published. /en/page/2/ onward stays
 * the plain listing.
 *
 * The source front page and each language front page point at each other with
 * hreflang once a language has enough to stand on (lmgt_front_min, default 3).
 */
class LMGT_LangFront {

	const LATEST = 24;

	public static function boot() {
		add_filter( 'template_include', array( __CLASS__, 'template' ), 100 );
		add_action( 'pre_get_posts', array( __CLASS__, 'per_page' ) );
		add_action( 'wp_head', array( __CLASS__, 'hreflang' ), 2 );
		add_action( 'transition_post_status', array( __CLASS__, 'purge' ), 20, 3 );
	}

	public static function enabled() {
		return get_option( 'lmgt_lang_front', '1' ) === '1';
	}

	/** Page 1 of a language listing. */
	public static function is_front() {
		return self::enabled() && get_query_var( 'lmgt_lang_home' ) && max( 1, (int) get_query_var( 'paged' ) ) === 1;
	}

	/** Listing pages after the front hold as many as the front shows, so page 2 continues where it stops. */
	public static function per_page( $q ) {
		if ( self::enabled() && $q->is_main_query() && $q->get( 'lmgt_lang_home' ) ) $q->set( 'posts_per_page', self::LATEST );
	}

	public static function template( $template ) {
		if ( ! self::is_front() || is_404() ) return $template;
		return LMGT_DIR . 'templates/lang-front.php';
	}

	/** Published translations in $lang: guides (translated pages) or articles (everything else). */
	public static function items( $lang, $guides, $limit ) {
		$type = array( 'key' => '_lmgt_source_type', 'value' => 'page' );
		if ( ! $guides ) {
			$type = array( 'relation' => 'OR', array( 'key' => '_lmgt_source_type', 'value' => 'page', 'compare' => '!=' ), array( 'key' => '_lmgt_source_type', 'compare' => 'NOT EXISTS' ) );
		}
		return get_posts( array(
			'post_type'        => LMGT_Store::types( true ),
			'post_status'      => 'publish',
			'posts_per_page'   => $limit,
			'orderby'          => $guides ? 'title' : 'date',
			'order'            => $guides ? 'ASC' : 'DESC',
			'lmgt_all'         => true,
			'suppress_filters' => false,
			// On .dk, copies that now live on .travel are no longer listed (2.2.16).
			'meta_query'       => LMGT_Bridge::is_source() ? array( array( 'key' => '_lmgt_lang', 'value' => $lang ), $type, array( 'key' => '_lmgt_moved_to', 'compare' => 'NOT EXISTS' ) ) : array( array( 'key' => '_lmgt_lang', 'value' => $lang ), $type ),
		) );
	}

	/** Card text: the meta description, which is written to be read alone; the opening words only as a fallback. */
	public static function blurb( $post ) {
		$d = trim( (string) get_post_meta( $post->ID, 'rank_math_description', true ) );
		if ( $d !== '' && strpos( $d, '%' ) === false && strpos( $d, '{' ) === false ) return $d;
		if ( has_excerpt( $post ) ) return get_the_excerpt( $post );
		// Paragraphs only: the opening heading would otherwise run into the first sentence.
		$html = preg_replace( '#<h[1-6][^>]*>.*?</h[1-6]>#is', ' ', $post->post_content );
		$text = preg_match_all( '#<p[^>]*>(.*?)</p>#is', $html, $m ) ? implode( ' ', $m[1] ) : $html;
		return wp_trim_words( LMGT_Text::plain( $text ), 26, '…' );
	}

	/** The source front page's image, or the first guide's. */
	public static function hero_image( $guides ) {
		$front = (int) get_option( 'page_on_front' );
		$img   = $front ? get_post_thumbnail_id( $front ) : 0;
		if ( ! $img && $guides ) $img = get_post_thumbnail_id( $guides[0] );
		return $img;
	}

	/**
	 * Which kind of site this is, so the fixed words fit it (2.21.2).
	 * travel (traveltalk, vacation-talk), wine (winetalk), sport (worldsporttalk), think (think-smarter).
	 * Option lmgt_front_profile or the filter of the same name overrides the guess from the domain.
	 */
	public static function profile() {
		$p = (string) get_option( 'lmgt_front_profile', '' );
		if ( $p === '' ) {
			$host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
			$p    = 'travel';
			if ( strpos( $host, 'winetalk' ) !== false ) $p = 'wine';
			elseif ( strpos( $host, 'worldsporttalk' ) !== false ) $p = 'sport';
			elseif ( strpos( $host, 'think-smarter' ) !== false ) $p = 'think';
		}
		return apply_filters( 'lmgt_front_profile', $p );
	}

	/** Fixed words on the language front page, in that language and for this kind of site. */
	public static function t( $lang, $key ) {
		$more = array( 'en' => 'All articles in English', 'de' => 'Alle Artikel auf Deutsch', 'sv' => 'Alla artiklar på svenska', 'nb' => 'Alle artikler på norsk', 'fi' => 'Kaikki artikkelit suomeksi', 'fr' => 'Tous les articles en français', 'es' => 'Todos los artículos en español', 'pt' => 'Todos os artigos em português', 'it' => 'Tutti gli articoli in italiano', 'da' => 'Alle artikler på dansk' );
		$latest = array( 'en' => 'Latest articles', 'de' => 'Neueste Artikel', 'sv' => 'Senaste artiklarna', 'nb' => 'Nyeste artikler', 'fi' => 'Uusimmat artikkelit', 'fr' => 'Derniers articles', 'es' => 'Últimos artículos', 'pt' => 'Artigos mais recentes', 'it' => 'Ultimi articoli', 'da' => 'Nyeste artikler' );
		$profiles = array(
			'travel' => array(
				'en' => array( 'Travel with soul', 'Destination guides and travel stories, written by people who have been there.', 'Destination guides' ),
				'de' => array( 'Reisen mit Seele', 'Reiseführer und Reisegeschichten, geschrieben von Menschen, die dort waren.', 'Reiseführer' ),
				'sv' => array( 'Resor med själ', 'Reseguider och reseberättelser, skrivna av människor som har varit där.', 'Reseguider' ),
				'nb' => array( 'Reiser med sjel', 'Reiseguider og reisefortellinger, skrevet av folk som har vært der.', 'Reiseguider' ),
				'fi' => array( 'Matkoja sielulla', 'Matkaoppaita ja matkakertomuksia ihmisiltä, jotka ovat käyneet paikan päällä.', 'Matkaoppaat' ),
				'fr' => array( 'Voyager avec âme', 'Guides de destination et récits de voyage, écrits par des gens qui y sont allés.', 'Guides de destination' ),
				'es' => array( 'Viajar con alma', 'Guías de destino e historias de viaje, escritas por gente que ha estado allí.', 'Guías de destino' ),
				'pt' => array( 'Viajar com alma', 'Guias de destino e histórias de viagem, escritos por quem já esteve lá.', 'Guias de destino' ),
				'it' => array( 'Viaggiare con anima', 'Guide di viaggio e racconti, scritti da chi ci è stato.', 'Guide di viaggio' ),
				'da' => array( 'Rejser med sjæl', 'Rejseguider og rejsehistorier, skrevet af folk, der har været der.', 'Rejseguider' ),
			),
			'wine' => array(
				'en' => array( 'Wine first, then food', 'Regions, grapes and bottles worth knowing, and the food that goes with them.', 'Wine guides' ),
				'de' => array( 'Erst der Wein, dann das Essen', 'Weinregionen, Rebsorten und Flaschen, die man kennen sollte, und das Essen, das dazu passt.', 'Weinführer' ),
				'sv' => array( 'Vinet först, sedan maten', 'Vinregioner, druvor och flaskor värda att känna till, och maten som passar till dem.', 'Vinguider' ),
				'nb' => array( 'Vinen først, så maten', 'Vinområder, druer og flasker som er verdt å kjenne, og maten som passer til dem.', 'Vinguider' ),
				'fi' => array( 'Ensin viini, sitten ruoka', 'Viinialueita, rypäleitä ja pulloja, jotka kannattaa tuntea, sekä niihin sopivaa ruokaa.', 'Viinioppaat' ),
				'fr' => array( 'Le vin d’abord, puis la table', 'Régions, cépages et bouteilles à connaître, et les plats qui leur vont.', 'Guides du vin' ),
				'es' => array( 'Primero el vino, luego la comida', 'Regiones, uvas y botellas que vale la pena conocer, y la comida que les va bien.', 'Guías de vino' ),
				'pt' => array( 'Primeiro o vinho, depois a comida', 'Regiões, castas e garrafas que vale a pena conhecer, e a comida que combina com elas.', 'Guias de vinho' ),
				'it' => array( 'Prima il vino, poi il cibo', 'Regioni, vitigni e bottiglie da conoscere, e i piatti che li accompagnano.', 'Guide al vino' ),
				'da' => array( 'Vin først, så maden', 'Vinområder, druer og flasker, der er værd at kende, og maden, der passer til dem.', 'Vinguider' ),
			),
			'sport' => array(
				'en' => array( 'World sport, in depth', 'Insight beyond the results: the stories, the stakes and the people behind them.', 'Sport guides' ),
				'de' => array( 'Weltsport mit Tiefgang', 'Hintergründe statt nur Ergebnisse: die Geschichten, worum es geht und die Menschen dahinter.', 'Sport-Guides' ),
				'sv' => array( 'Världssport på djupet', 'Insikt bortom resultaten: berättelserna, vad som står på spel och människorna bakom.', 'Sportguider' ),
				'nb' => array( 'Verdenssport i dybden', 'Innsikt utover resultatene: historiene, hva som står på spill, og menneskene bak.', 'Sportsguider' ),
				'fi' => array( 'Maailman urheilu syvemmin', 'Taustaa tulosten takaa: tarinat, panokset ja ihmiset niiden takana.', 'Urheiluoppaat' ),
				'fr' => array( 'Le sport mondial en profondeur', 'Au-delà des résultats : les histoires, les enjeux et les personnes qui les portent.', 'Guides du sport' ),
				'es' => array( 'El deporte mundial a fondo', 'Más allá de los resultados: las historias, lo que está en juego y las personas detrás.', 'Guías de deporte' ),
				'pt' => array( 'O desporto mundial em profundidade', 'Para além dos resultados: as histórias, o que está em jogo e as pessoas por trás.', 'Guias de desporto' ),
				'it' => array( 'Lo sport mondiale in profondità', 'Oltre i risultati: le storie, la posta in gioco e le persone che ci stanno dietro.', 'Guide allo sport' ),
				'da' => array( 'Verdenssport i dybden', 'Indsigt ud over resultaterne: historierne, hvad der står på spil, og menneskene bag.', 'Sportsguider' ),
			),
			'think' => array(
				'en' => array( 'Tools for clearer thinking', 'Is this really true? Are you being taken for a ride? Practical tools to think, check and decide better.', 'Guides' ),
				'de' => array( 'Werkzeuge für klareres Denken', 'Stimmt das wirklich? Werden Sie hinters Licht geführt? Praktische Werkzeuge, um besser zu denken, zu prüfen und zu entscheiden.', 'Leitfäden' ),
				'sv' => array( 'Verktyg för klarare tänkande', 'Stämmer det verkligen? Blir du lurad? Praktiska verktyg för att tänka, kontrollera och besluta bättre.', 'Guider' ),
				'nb' => array( 'Verktøy for klarere tenkning', 'Stemmer det egentlig? Blir du lurt? Praktiske verktøy for å tenke, sjekke og bestemme bedre.', 'Guider' ),
				'fi' => array( 'Työkaluja selkeämpään ajatteluun', 'Onko tämä todella totta? Huijataanko sinua? Käytännön työkaluja parempaan ajatteluun, tarkistamiseen ja päätöksiin.', 'Oppaat' ),
				'fr' => array( 'Des outils pour penser plus clair', 'Est-ce vraiment vrai ? Vous mène-t-on en bateau ? Des outils pratiques pour mieux penser, vérifier et décider.', 'Guides' ),
				'es' => array( 'Herramientas para pensar con claridad', '¿Es realmente cierto? ¿Le están engañando? Herramientas prácticas para pensar, comprobar y decidir mejor.', 'Guías' ),
				'pt' => array( 'Ferramentas para pensar com clareza', 'Isto é mesmo verdade? Estão a enganá-lo? Ferramentas práticas para pensar, verificar e decidir melhor.', 'Guias' ),
				'it' => array( 'Strumenti per pensare con chiarezza', 'È davvero così? Ti stanno prendendo in giro? Strumenti pratici per pensare, verificare e decidere meglio.', 'Guide' ),
				'da' => array( 'Redskaber til klarere tænkning', 'Er det nu rigtigt? Bliver du taget ved næsen? Praktiske redskaber til at tænke, tjekke og beslutte bedre.', 'Guider' ),
			),
		);
		$prof = self::profile();
		$set  = isset( $profiles[ $prof ] ) ? $profiles[ $prof ] : $profiles['travel'];
		$l    = isset( $set[ $lang ] ) ? $lang : 'en';
		$row  = array( 'kicker' => $set[ $l ][0], 'lead' => $set[ $l ][1], 'guides' => $set[ $l ][2], 'latest' => $latest[ $l ], 'more' => $more[ $l ] );
		return isset( $row[ $key ] ) ? $row[ $key ] : '';
	}

	/** [code => url] for the source front page and every language front page with enough content. */
	public static function set() {
		$min = max( 1, (int) get_option( 'lmgt_front_min', 3 ) );
		$out = array( LMGT_Langs::source() => home_url( '/' ) );
		foreach ( LMGT_Front::published_counts() as $code => $n ) {
			if ( $n < $min || ! LMGT_Langs::get( $code ) || $code === LMGT_Langs::source() ) continue;
			$url = LMGT_Front::lang_home_url( $code );
			if ( $url ) $out[ $code ] = $url;
		}
		return count( $out ) > 1 ? $out : array();
	}

	public static function hreflang() {
		if ( ! self::enabled() || lmgt_legacy_active() || LMGT_Bridge::on() ) return;
		$lang = get_query_var( 'lmgt_lang_home' );
		if ( $lang ? ! self::is_front() : ! is_front_page() ) return;
		$set = self::set();
		if ( ! $set || ( $lang && ! isset( $set[ $lang ] ) ) ) return;
		foreach ( $set as $code => $url ) {
			echo '<link rel="alternate" hreflang="' . esc_attr( LMGT_Langs::get( $code )['hreflang'] ) . '" href="' . esc_url( $url ) . '" />' . "\n";
		}
		echo '<link rel="alternate" hreflang="x-default" href="' . esc_url( $set[ LMGT_Langs::source() ] ) . '" />' . "\n";
	}

	/** A version published or withdrawn changes its language front page and the source front page's hreflang. */
	public static function purge( $new, $old, $post ) {
		if ( ( $old !== 'publish' && $new !== 'publish' ) || ! get_post_meta( $post->ID, '_lmgt_lang', true ) ) return;
		wp_cache_delete( 'lmgt_counts', 'lmgt' );
		$url = LMGT_Front::lang_home_url( get_post_meta( $post->ID, '_lmgt_lang', true ) );
		if ( $url ) do_action( 'litespeed_purge_url', $url );
		do_action( 'litespeed_purge_url', home_url( '/' ) );
	}
}
