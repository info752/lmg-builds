<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.2.16: translations leave traveltalk.dk (G, 28 Oct 2026).
 *
 * Google does not accept language versions on a country domain, and the .dk
 * translations may pull .dk's own traffic down. All of them go to .travel;
 * .dk keeps Danish only and points to .travel.
 *
 *   - Copied: once its .travel version is published, a .dk translation's
 *     address answers 301 → that page. The .dk post stays in the database
 *     (out of sight), so nothing is lost; if the .travel page is taken
 *     offline, the .dk address shows its own copy again.
 *   - Language front pages on .dk (/en/, /de/ …) answer 301 → the same
 *     language's front page on .travel once no translation in that language
 *     is left here and .travel has one published.
 *   - Translator → Catch-up → "Translations still on traveltalk.dk": copies
 *     them, one per step. Only languages switched on at .travel
 *     (Translator → Settings there); Swedish, Norwegian and Finnish go too
 *     once ticked there (G, 28 Oct). The Nordic departure pages (/se/,
 *     /no/, /fi/) are pages, not translations: they stay on .dk for the
 *     Nordic sites and are never touched here. Where
 *     .travel already has a page for the same original and language, the .dk
 *     copy is pointed at it instead of copied. English that may already
 *     exist on .travel under another name (match check, brief 4.5) is listed
 *     for a person, never copied blind.
 *   - On every .dk page: one line in the footer naming .travel's languages,
 *     each linking to its front page there, in a new window (G). The
 *     article row ("Read in") names traveltalk.travel when it links there.
 *
 * Meta, .dk: _lmgt_moved_to (existing), _lmgt_copy_check: English item held for a person.
 */
class LMGT_Migrate {

	public static function boot() {
		if ( ! LMGT_Bridge::is_source() ) return;
		add_action( 'template_redirect', array( __CLASS__, 'redirect' ), 1 );
		add_action( 'wp_footer', array( __CLASS__, 'footer_line' ), 50 );
		// 2.13.0: the copy to .travel is a part (Translator → Parts), off by default; the redirects of what moved stay.
		if ( LMGT_Parts::on( 'copy' ) ) {
			add_action( 'lmgt_catchup_top', array( __CLASS__, 'catchup_section' ), 5 );
			add_action( 'wp_ajax_lmgt_migrate', array( __CLASS__, 'ajax_step' ) );
		}
	}

	// ---- Redirects ---------------------------------------------------------------

	/** The .travel address of a copied translation, while it is published there; '' otherwise. */
	public static function target_url( $tid ) {
		if ( ! get_post_meta( $tid, '_lmgt_moved_to', true ) ) return '';
		$sid    = (int) get_post_meta( $tid, '_lmgt_source', true );
		$lang   = get_post_meta( $tid, '_lmgt_lang', true );
		$remote = LMGT_Bridge::remote( $sid );
		if ( empty( $remote[ $lang ]['url'] ) || ! in_array( $remote[ $lang ]['status'], array( 'publish', 'thin' ), true ) ) return '';
		return $remote[ $lang ]['url'];
	}

	public static function redirect() {
		if ( is_preview() ) return;
		if ( is_singular( LMGT_CPT ) ) {
			$to = self::target_url( get_queried_object_id() );
			if ( $to ) {
				wp_redirect( $to, 301, 'LMG Translator' );
				exit;
			}
			return;
		}
		$lang = get_query_var( 'lmgt_lang_home' );
		if ( $lang && ! self::left( $lang ) ) {
			$to = LMGT_Bridge::peer_lang_home( $lang );
			if ( $to ) {
				wp_redirect( $to, 301, 'LMG Translator' );
				exit;
			}
		}
	}

	/** Published translations in $lang still shown on .dk (not copied, or copied but not live on .travel). */
	public static function left( $lang ) {
		$n = 0;
		foreach ( get_posts( array( 'post_type' => LMGT_CPT, 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids', 'lmgt_all' => true, 'no_found_rows' => true, 'meta_key' => '_lmgt_lang', 'meta_value' => $lang ) ) as $id ) {
			if ( ! self::target_url( $id ) ) $n++;
		}
		return $n;
	}

	// ---- Pointers to .travel -------------------------------------------------------

	/** "traveltalk.travel – our international site: English · Deutsch · …" in the footer of every .dk page. */
	public static function footer_line() {
		if ( is_admin() || ! apply_filters( 'lmgt_intl_line', true ) ) return;
		$links = array();
		foreach ( array_keys( LMGT_Langs::all() ) as $code ) {
			$url = LMGT_Bridge::peer_lang_home( $code );
			if ( ! $url ) continue;
			$h       = LMGT_Bridge::hreflang_code( $code );
			$links[] = '<a href="' . esc_url( LMGT_Bridge::from_dk( $url ) ) . '" hreflang="' . esc_attr( $h ) . '" lang="' . esc_attr( $h ) . '" target="_blank" rel="noopener">' . esc_html( LMGT_Langs::get( $code )['native'] ) . '</a>';
		}
		if ( ! $links ) return;
		echo '<div class="lmgt-intl" lang="en" style="text-align:center;font-size:.9em;padding:14px 16px">traveltalk.travel – our international site: ' . implode( ' · ', $links ) . '</div>';
	}

	// ---- Catch-up: copy what is still here -------------------------------------------

	/** .travel's languages, from its own settings (asked once per page view). */
	private static function travel_langs() {
		static $langs = null;
		if ( $langs !== null ) return $langs;
		$r     = LMGT_Bridge::call( 'GET', '/ping', array(), false );
		$langs = ! is_wp_error( $r ) && isset( $r['langs'] ) ? (array) $r['langs'] : null;
		return $langs;
	}

	/** Translations on .dk not yet on .travel: [[id, lang, status]], oldest original first. */
	public static function todo() {
		$out = array();
		foreach ( get_posts( array( 'post_type' => LMGT_CPT, 'post_status' => array( 'publish', 'draft', 'pending' ), 'posts_per_page' => -1, 'fields' => 'ids', 'lmgt_all' => true, 'no_found_rows' => true, 'orderby' => 'ID', 'order' => 'ASC' ) ) as $id ) {
			if ( get_post_meta( $id, '_lmgt_moved_draft', true ) ) continue;
			if ( LMGT_Nordic::is( get_post_meta( $id, '_lmgt_lang', true ) ) ) continue; // 2.11.0: they stay on .dk
			if ( get_post_meta( $id, '_lmgt_moved_to', true ) && self::target_url( $id ) ) continue;
			if ( ! (int) get_post_meta( $id, '_lmgt_source', true ) ) continue;
			$out[] = array( 'id' => (int) $id, 'lang' => (string) get_post_meta( $id, '_lmgt_lang', true ), 'status' => get_post_status( $id ) );
		}
		return $out;
	}

	public static function catchup_section() {
		$todo  = self::todo();
		$langs = self::travel_langs();
		echo '<h2>Translations still on traveltalk.dk</h2>';
		if ( ! $todo ) {
			echo '<p>None. Every translation lives on traveltalk.travel; the old .dk addresses send readers there.</p>';
			return;
		}
		if ( $langs === null ) {
			echo '<p>traveltalk.travel could not be asked which languages it has. Try again in a minute.</p>';
			return;
		}
		$count = array();
		foreach ( $todo as $it ) {
			$k = $it['lang'];
			if ( ! isset( $count[ $k ] ) ) $count[ $k ] = array( 'publish' => 0, 'other' => 0 );
			$count[ $k ][ $it['status'] === 'publish' ? 'publish' : 'other' ]++;
		}
		echo '<p>These go to traveltalk.travel, one at a time: published ones stay published there, drafts arrive as drafts. Once a copy is live on traveltalk.travel, its .dk address sends readers and Google there for good (301); the .dk copy stays in the database, out of sight.</p><ul>';
		$go = 0;
		foreach ( $count as $code => $n ) {
			$l  = LMGT_Langs::get( $code );
			$on = in_array( $code, $langs, true );
			if ( $on ) $go += $n['publish'] + $n['other'];
			echo '<li><strong>' . esc_html( $l ? $l['name'] : $code ) . '</strong>: ' . (int) $n['publish'] . ' published, ' . (int) $n['other'] . ' draft(s)' . ( $on ? '' : ' – <em>not switched on at traveltalk.travel (Translator → Settings there): stays here. traveltalk.travel answered: ' . esc_html( implode( ', ', $langs ) ) . '</em>' ) . '</li>';
		}
		echo '</ul><p class="description">English is checked first: where traveltalk.travel may already have its own English page on the same subject, the item is listed below for you and not copied. A language not switched on at traveltalk.travel waits here until it is.</p>';
		$held = array_filter( $todo, function ( $it ) { return get_post_meta( $it['id'], '_lmgt_copy_check', true ); } );
		$go  -= count( $held );
		if ( $go > 0 ) {
				echo '<p><button class="button button-primary" id="lmgt-mig">Copy ' . (int) $go . ' to traveltalk.travel</button> <span id="lmgt-mig-st"></span></p><pre id="lmgt-mig-log" style="max-height:300px;overflow:auto;background:#fff;padding:8px"></pre>';
			$nonce = wp_create_nonce( 'lmgt_migrate' );
			echo "<script>(function(){var b=document.getElementById('lmgt-mig'),s=document.getElementById('lmgt-mig-st'),l=document.getElementById('lmgt-mig-log');"
				. "function go(i){var d=new FormData();d.append('action','lmgt_migrate');d.append('i',i);d.append('_ajax_nonce','" . esc_js( $nonce ) . "');"
				. "fetch(ajaxurl,{method:'POST',body:d,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){"
				. "if(!r.success){l.textContent+='Stopped: '+r.data+'\\n';b.disabled=false;return}l.textContent+=r.data.line+'\\n';s.textContent=r.data.left+' left';"
				. "if(r.data.left>0)setTimeout(function(){go(r.data.next)},1500);else s.textContent='Finished. Reload the page for what is left.'}).catch(function(e){l.textContent+='Stopped: '+e+'\\n';b.disabled=false})}"
				. "b.addEventListener('click',function(){b.disabled=true;go(0)})})();</script>";
		}
		if ( $held ) {
			echo '<h3>English: check these first</h3><p>traveltalk.travel has English pages that may cover the same subject. Open the Danish original: in its traveltalk.travel box, link the English page that matches, or, if none does, open the English translation and use "Copy to traveltalk.travel".</p><ul>';
			foreach ( $held as $it ) {
				$sid = (int) get_post_meta( $it['id'], '_lmgt_source', true );
				echo '<li><a href="' . esc_url( get_edit_post_link( $sid ) ) . '">' . esc_html( get_the_title( $sid ) ) . '</a> – candidates: ' . esc_html( get_post_meta( $it['id'], '_lmgt_copy_check', true ) ) . '</li>';
			}
			echo '</ul>';
		}
	}

	/** One translation per step. $i walks the list; items held or kept here are stepped over. */
	public static function ajax_step() {
		check_ajax_referer( 'lmgt_migrate' );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_send_json_error( 'Not allowed.' );
		$langs = self::travel_langs();
		if ( $langs === null ) wp_send_json_error( 'traveltalk.travel could not be asked which languages it has.' );
		$todo = array_values( array_filter( self::todo(), function ( $it ) use ( $langs ) { return in_array( $it['lang'], $langs, true ); } ) );
		$i    = isset( $_POST['i'] ) ? (int) $_POST['i'] : 0;
		if ( ! isset( $todo[ $i ] ) ) wp_send_json_success( array( 'left' => 0, 'next' => $i, 'line' => 'Nothing left.' ) );
		$it   = $todo[ $i ];
		$line = self::one( $it['id'] );
		// A copied item leaves the list, so the next one moves up to $i; a held one stays, so step past it.
		$todo = array_values( array_filter( self::todo(), function ( $x ) use ( $langs ) { return in_array( $x['lang'], $langs, true ); } ) );
		$next = ( isset( $todo[ $i ] ) && $todo[ $i ]['id'] === $it['id'] ) ? $i + 1 : $i;
		wp_send_json_success( array( 'left' => max( 0, count( $todo ) - $next ), 'next' => $next, 'line' => $line ) );
	}

	/** Copy one translation, or point it at the page .travel already has. Returns a log line. */
	public static function one( $tid ) {
		$sid    = (int) get_post_meta( $tid, '_lmgt_source', true );
		$lang   = get_post_meta( $tid, '_lmgt_lang', true );
		$where  = get_the_title( $sid ) . ' (' . $lang . ')';
		$remote = LMGT_Bridge::remote( $sid );
		// .travel already has this original in this language (linked English page, or translated there).
		if ( ! empty( $remote[ $lang ]['url'] ) ) {
			if ( ! in_array( $remote[ $lang ]['status'], array( 'publish', 'thin' ), true ) ) return $where . ': kept – traveltalk.travel has a ' . $remote[ $lang ]['status'] . ' version; publish it there first';
			if ( get_post_status( $tid ) !== 'publish' ) {
				update_post_meta( $tid, '_lmgt_moved_draft', '1' );
				return $where . ': draft set aside – traveltalk.travel already has it';
			}
			update_post_meta( $tid, '_lmgt_moved_to', esc_url_raw( $remote[ $lang ]['url'] ) );
			LMGT_Bridge::refresh_set( $sid );
			do_action( 'litespeed_purge_post', $tid );
			return $where . ': not copied – now sends readers to the version already there, ' . $remote[ $lang ]['url'];
		}
		// English: extend, never duplicate (brief 4.5). A possible match is left to a person.
		if ( $lang === 'en' && ! get_post_meta( $tid, '_lmgt_copy_checked', true ) ) {
			$hits = LMGT_Bridge::call( 'GET', '/match', array( 'q' => LMGT_Bridge::subject( get_post( $sid ) ) ), false );
			if ( is_wp_error( $hits ) ) return $where . ': failed – English check unavailable: ' . $hits->get_error_message();
			$free = array_filter( (array) $hits, function ( $h ) { return empty( $h['linked_to'] ); } );
			if ( $free ) {
				update_post_meta( $tid, '_lmgt_copy_check', implode( '; ', wp_list_pluck( $free, 'title' ) ) );
				return $where . ': held for you – possible English page on traveltalk.travel: ' . implode( '; ', wp_list_pluck( $free, 'title' ) );
			}
		}
		$r = LMGT_Bridge::move( $tid );
		if ( is_wp_error( $r ) ) return $where . ': failed – ' . $r->get_error_message();
		delete_post_meta( $tid, '_lmgt_copy_check' );
		$remote = LMGT_Bridge::remote( $sid );
		return $where . ': copied, ' . $remote[ $lang ]['status'] . ' – ' . $remote[ $lang ]['url'];
	}
}
