<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.13.0 (G, 10 Nov 2026): Translator → Parts. Fewer moving parts.
 *
 * Each optional part of the plugin can be switched on or off here, in plain words.
 * A part that is off is not started at all (its menu page, buttons and background
 * work are gone); nothing is deleted, and switching it on again brings it back.
 *
 * Defaults (briefs/translator-scope-2026-11-10.md): tools readers never see are off;
 * parts readers see stay on until G switches them off one at a time.
 *
 * Option: lmgt_parts = [key => '1'|'0']; a key not stored takes its default.
 */
class LMGT_Parts {

	const OPT = 'lmgt_parts';

	/** key => [label, what switching it off does, default, seen by readers] */
	public static function all() {
		return array(
			// Seen by readers: on until G decides.
			'trail'     => array( 'Breadcrumbs in the page\'s language', 'Off: translations on traveltalk.travel show a plain breadcrumb ("Home / title") instead of "Startseite / Europa / Österreich".', '1', true ),
			'readmore'  => array( '"Read more" box and article structure', 'Off: the "Read more" box disappears from the end of every article, and the structure check leaves the edit screen.', '1', true ),
			'top'       => array( '"Most read about …"', 'Off: the "Most read" list inside "Read more" disappears, and page views are no longer counted.', '1', true ),
			'boxes'     => array( 'Boxes: facts, map, "Know before you go" and "Who takes you there"', 'Off: the boxes, the map and their FAQ and list schema disappear from every page that has them.', '1', true ),
			'more'      => array( '"More about …" rows (traveltalk.travel)', 'Off: the rows of next pages at the end of traveltalk.travel pages disappear.', '1', true ),
			'clusters'  => array( 'Country pages and their articles (traveltalk.dk)', 'Off: the article lists on country pages disappear, and some addresses where a page and a category share a name may show the category instead. Switch off only together with Claude.', '1', true ),
			'pictures'  => array( 'Related-articles grid and picture addresses', 'Off: the grid at the bottom of translations disappears, and short picture addresses in translations may stop loading.', '1', true ),
			'media'     => array( 'Image texts (featured image and alt texts)', 'Off: the catch-up buttons for image texts and the Alt texts page leave the menu. Texts already saved stay.', '1', false ),
			'steps'     => array( 'Steps panel and "Next" on the edit screen', 'Off: the panel at the top of every edit screen and its "last run" stamps disappear. The boxes below stay.', '1', false ),
			'worklist'  => array( 'Work list', 'Off: Translator → Work list leaves the menu.', '1', false ),
			'outreach'  => array( 'Outreach list (providers to contact)', 'Off: Translator → Outreach leaves the menu. The list itself is kept.', '1', false ),
			'oneplace'  => array( 'Work on a translation in one place (traveltalk.travel)', 'Off: copies of translations sent to traveltalk.travel show again in traveltalk.dk\'s Translations list and can be edited there.', '1', false ),
			// Never seen by readers: off.
			'finder'    => array( 'Find pictures', 'Off: Translator → Find pictures leaves the menu.', '0', false ),
			'localpics' => array( 'Save pictures on traveltalk.travel', 'Off: Translator → Save pictures leaves the menu. Pictures load from traveltalk.dk as now.', '0', false ),
			'improve'   => array( 'Improve and keep (Mio\'s own English pages)', 'Off: the "traveltalk.dk original" box leaves edit screens on traveltalk.travel.', '0', false ),
			'meter'     => array( 'Cost meter (Pilot)', 'Off: Translator → Pilot leaves the menu, and review minutes are no longer timed.', '0', false ),
			'plan'      => array( 'Translate everything', 'Off: Translator → Translate everything leaves the menu. Translate article by article from its edit screen.', '0', false ),
			'legacy'    => array( 'Old language setup finder', 'Off: Translator → Old language setup leaves the menu.', '0', false ),
			'copy'      => array( 'Copy translations from traveltalk.dk to traveltalk.travel', 'Off: the copy button leaves Catch-up. Addresses already moved keep sending readers on.', '0', false ),
		);
	}

	public static function on( $key ) {
		$all = self::all();
		if ( ! isset( $all[ $key ] ) ) return true;
		$o = get_option( self::OPT, array() );
		return ( is_array( $o ) && isset( $o[ $key ] ) ? (string) $o[ $key ] : $all[ $key ][2] ) === '1';
	}

	public static function boot() {
		add_action( 'admin_menu', function () {
			add_submenu_page( 'lmgt', 'Parts', 'Parts', 'manage_options', 'lmgt-parts', array( __CLASS__, 'page' ) );
		}, 105 );
		add_action( 'admin_post_lmgt_parts', array( __CLASS__, 'save' ) );
	}

	public static function page() {
		$all = self::all();
		echo '<div class="wrap"><h1>Parts</h1>';
		if ( isset( $_GET['saved'] ) ) echo '<div class="notice notice-success"><p>Saved. Purge LiteSpeed so readers see the change.</p></div>';
		echo '<p>Switch a part off to see whether the site is better without it; switch it on again at any time. Nothing is deleted. Change one at a time, then look at a page.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'lmgt_parts' );
		echo '<input type="hidden" name="action" value="lmgt_parts">';
		foreach ( array( true => 'Seen by readers', false => 'Only in wp-admin' ) as $seen => $head ) {
			echo '<h2>' . esc_html( $head ) . '</h2><table class="form-table" role="presentation">';
			foreach ( $all as $k => $p ) {
				if ( (bool) $p[3] !== (bool) $seen ) continue;
				echo '<tr><th scope="row">' . esc_html( $p[0] ) . '</th><td><label><input type="checkbox" name="parts[' . esc_attr( $k ) . ']" value="1" ' . checked( self::on( $k ), true, false ) . '> On</label><p class="description">' . esc_html( $p[1] ) . '</p></td></tr>';
			}
			echo '</table>';
		}
		submit_button( 'Save' );
		echo '</form></div>';
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Not allowed.' );
		check_admin_referer( 'lmgt_parts' );
		$in  = isset( $_POST['parts'] ) ? (array) $_POST['parts'] : array();
		$out = array();
		foreach ( array_keys( self::all() ) as $k ) $out[ $k ] = empty( $in[ $k ] ) ? '0' : '1';
		update_option( self::OPT, $out, true );
		do_action( 'litespeed_purge_all' );
		wp_safe_redirect( admin_url( 'admin.php?page=lmgt-parts&saved=1' ) );
		exit;
	}
}
