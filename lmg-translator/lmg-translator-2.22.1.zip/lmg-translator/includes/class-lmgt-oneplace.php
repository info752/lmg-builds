<?php
/**
 * 2.9.2 (G, 9 Nov 2026): one place to work on a translation – traveltalk.travel, where readers
 * see it. On traveltalk.dk a translation that has been sent there is a workshop copy: it leaves
 * the Translations list (a "Sent to traveltalk.travel" view keeps them findable), and its edit
 * screen points to the translation on traveltalk.travel instead of opening. "Open the workshop
 * copy anyway" is still there. Nothing is deleted; Translator keeps sending new versions from
 * the Danish original as before, and they wait on traveltalk.travel for Accept.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class LMGT_OnePlace {

	public static function boot() {
		if ( ! LMGT_Bridge::is_source() ) return;
		add_action( 'pre_get_posts', array( __CLASS__, 'hide_sent' ) );
		add_filter( 'views_edit-' . LMGT_CPT, array( __CLASS__, 'views' ) );
		add_action( 'load-post.php', array( __CLASS__, 'gate' ) );
	}

	private static function sent( $id ) {
		return get_post_meta( $id, '_lmgt_moved_to', true ) || get_post_meta( $id, '_lmgt_moved_draft', true );
	}

	public static function hide_sent( $q ) {
		if ( ! is_admin() || ! $q->is_main_query() || $q->get( 'post_type' ) !== LMGT_CPT ) return;
		global $pagenow;
		if ( $pagenow !== 'edit.php' ) return;
		$mq   = (array) $q->get( 'meta_query' );
		$mq[] = ! empty( $_GET['lmgt_sent'] )
			? array( 'relation' => 'OR', array( 'key' => '_lmgt_moved_to', 'compare' => 'EXISTS' ), array( 'key' => '_lmgt_moved_draft', 'compare' => 'EXISTS' ) )
			: array( 'relation' => 'AND', array( 'key' => '_lmgt_moved_to', 'compare' => 'NOT EXISTS' ), array( 'key' => '_lmgt_moved_draft', 'compare' => 'NOT EXISTS' ) );
		$q->set( 'meta_query', $mq );
	}

	public static function views( $views ) {
		global $wpdb;
		$n = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key IN ('_lmgt_moved_to','_lmgt_moved_draft')" );
		$views['lmgt_sent'] = '<a href="' . esc_url( admin_url( 'edit.php?post_type=' . LMGT_CPT . '&lmgt_sent=1' ) ) . '"' . ( ! empty( $_GET['lmgt_sent'] ) ? ' class="current"' : '' ) . '>Sent to traveltalk.travel (' . $n . ')</a>';
		return $views;
	}

	/** The edit link on traveltalk.travel for a sent translation, or its public address when the id is not known. */
	private static function there( $id ) {
		$peer = untrailingslashit( (string) LMGT_Bridge::peer() );
		$rid  = (int) get_post_meta( $id, '_lmgt_moved_id', true );
		if ( ! $rid ) {
			$sid  = (int) get_post_meta( $id, '_lmgt_source', true );
			$lang = (string) get_post_meta( $id, '_lmgt_lang', true );
			$r    = $sid ? LMGT_Bridge::remote( $sid ) : array();
			if ( ! empty( $r[ $lang ]['id'] ) ) {
				$rid = (int) $r[ $lang ]['id'];
				update_post_meta( $id, '_lmgt_moved_id', $rid );
			}
		}
		if ( $rid && $peer ) return $peer . '/wp-admin/post.php?post=' . $rid . '&action=edit';
		$to = get_post_meta( $id, '_lmgt_moved_to', true );
		return $to ? $to : $peer . '/wp-admin/';
	}

	public static function gate() {
		$id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
		if ( ! $id || get_post_type( $id ) !== LMGT_CPT || ! self::sent( $id ) || ! empty( $_GET['lmgt_here'] ) ) return;
		$there = self::there( $id );
		$here  = add_query_arg( 'lmgt_here', 1 );
		wp_die(
			'<h2>Edit this translation on traveltalk.travel</h2>'
			. '<p>"' . esc_html( get_the_title( $id ) ) . '" has been sent to traveltalk.travel, where readers see it. Work on it there, so there is one place for every change.</p>'
			. '<p><a class="button button-primary button-large" href="' . esc_url( $there ) . '">Open it on traveltalk.travel</a></p>'
			. '<p style="margin-top:24px"><a href="' . esc_url( $here ) . '">Open the workshop copy here anyway</a> <span class="description">(changes made here are not sent on by themselves)</span></p>',
			'Edit on traveltalk.travel',
			array( 'response' => 200 )
		);
	}
}
