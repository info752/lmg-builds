<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.2.16: breadcrumbs in the page's language on .travel (brief 4.17).
 *
 * Translations carry no categories, so their breadcrumb was "Home / <title>",
 * in English, on every language. .dk now sends the original's trail with each
 * draft: the parent pages of a page (Europa → Østrig), or for a post the
 * country page of its category (category oestrig → page oestrig, the 2.2.10
 * rule) with that page's parents, else the category itself. Names are
 * translated once and kept on .dk: pages in _lmgt_title_tr (shared with the
 * related grid), categories as term meta _lmgt_name_tr. One category tree,
 * never one per language.
 *
 * On .travel the trail is stored on the translation (_lmgt_trail). When the
 * page is shown, Home is the language's front page and each level links to
 * its translation in that language where one is published, else it shows
 * as plain text (no link back into Danish). Kadence's breadcrumb and Rank
 * Math's breadcrumb schema both show it; levels without a link stay out of
 * the schema. Translations made on .travel itself take their levels from the
 * parent pages of their English page that are translated into their language.
 *
 * 2.2.18: a level takes the page's short name, not its full title ("Amerika",
 * not "Amerika — to kontinenter, en hel verden"): Rank Math's Breadcrumb Title
 * where one is set, else the title up to the first dash, colon or bar. Short
 * names are translated once and kept in _lmgt_crumb_tr (the related grid keeps
 * the full titles in _lmgt_title_tr). Trails sent before 2.2.18 are shortened
 * the same way when shown.
 */
class LMGT_Trail {

	const HOME = array(
		'en' => 'Home', 'de' => 'Startseite', 'fr' => 'Accueil', 'es' => 'Inicio', 'it' => 'Home',
		'pt' => 'Início', 'sv' => 'Hem', 'nb' => 'Hjem', 'fi' => 'Etusivu', 'da' => 'Hjem',
	);

	public static function boot() {
		if ( ! LMGT_Bridge::on() ) return;
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		if ( LMGT_Bridge::is_source() ) {
			add_action( 'lmgt_catchup_sections', array( __CLASS__, 'catchup_section' ), 30 );
			add_action( 'wp_ajax_lmgt_trail_sync', array( __CLASS__, 'ajax_sync' ) );
			return;
		}
		add_action( 'template_redirect', array( __CLASS__, 'buffer' ), 99 );
		add_filter( 'rank_math/frontend/breadcrumb/items', array( __CLASS__, 'rank_math' ), 20 );
	}

	public static function routes() {
		if ( ! LMGT_Bridge::is_target() ) return;
		register_rest_route( LMGT_Bridge::NS, '/trail', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_trail' ), 'permission_callback' => function () { return current_user_can( 'edit_others_posts' ); } ) );
	}

	// ---- .dk: the original's trail ---------------------------------------------

	/** Source: [[url, name in $lang]] from the top level down, without Home and without the original itself. */
	public static function of( $source_id, $lang ) {
		$post = get_post( $source_id );
		if ( ! $post ) return array();
		$levels = array();
		$pages  = array();
		if ( $post->post_type === 'page' ) {
			$pages = array_reverse( get_post_ancestors( $post ) );
		} else {
			$cat = self::category( $post->ID );
			$hub = $cat ? get_posts( array( 'post_type' => 'page', 'name' => $cat->slug, 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids' ) ) : array();
			if ( $hub ) {
				$pages = array_merge( array_reverse( get_post_ancestors( $hub[0] ) ), array( (int) $hub[0] ) );
			} elseif ( $cat ) {
				foreach ( array_merge( array_reverse( get_ancestors( $cat->term_id, 'category', 'taxonomy' ) ), array( $cat->term_id ) ) as $tid ) {
					$levels[] = array( 'term' => (int) $tid );
				}
			}
		}
		foreach ( $pages as $pid ) {
			if ( get_post_status( $pid ) === 'publish' ) $levels[] = array( 'page' => (int) $pid );
		}
		if ( ! $levels ) return array();

		// Names in $lang: kept from earlier sends, the rest in one call.
		$need = array();
		foreach ( $levels as $i => $l ) {
			if ( isset( $l['page'] ) ) {
				$tr   = (array) get_post_meta( $l['page'], '_lmgt_crumb_tr', true );
				$set  = trim( (string) get_post_meta( $l['page'], 'rank_math_breadcrumb_title', true ) );
				$name = $set !== '' ? $set : self::short( html_entity_decode( get_the_title( $l['page'] ), ENT_QUOTES, 'UTF-8' ) );
				$levels[ $i ] += array( 'url' => get_permalink( $l['page'] ), 'da' => $name, 'name' => isset( $tr[ $lang ] ) ? $tr[ $lang ] : '' );
				if ( $levels[ $i ]['name'] === '' ) $need[ 'p' . $l['page'] ] = $name;
			} else {
				$term = get_term( $l['term'], 'category' );
				$tr   = (array) get_term_meta( $l['term'], '_lmgt_name_tr', true );
				$levels[ $i ] += array( 'url' => (string) get_term_link( $term ), 'da' => $term->name, 'name' => isset( $tr[ $lang ] ) ? $tr[ $lang ] : '' );
				if ( $levels[ $i ]['name'] === '' ) $need[ 'c' . $l['term'] ] = $term->name;
			}
		}
		if ( $need && $lang !== LMGT_Langs::source() && LMGT_Engines::ai_available() ) {
			$r = LMGT_Engines::ai_json( LMGT_Engines::prompt_translate( LMGT_Langs::source(), $lang, $need ), LMGT_Engines::schema_strings( array_keys( $need ) ) );
			if ( is_wp_error( $r ) ) LMGT_Bridge::log( 'breadcrumb names FAILED ' . $lang . ' ' . $r->get_error_message() );
			foreach ( $levels as $i => $l ) {
				$k = isset( $l['page'] ) ? 'p' . $l['page'] : 'c' . $l['term'];
				if ( is_wp_error( $r ) || empty( $r[ $k ] ) ) continue;
				$levels[ $i ]['name'] = sanitize_text_field( $r[ $k ] );
				if ( isset( $l['page'] ) ) {
					$tr          = (array) get_post_meta( $l['page'], '_lmgt_crumb_tr', true );
					$tr[ $lang ] = $levels[ $i ]['name'];
					update_post_meta( $l['page'], '_lmgt_crumb_tr', $tr );
				} else {
					$tr          = (array) get_term_meta( $l['term'], '_lmgt_name_tr', true );
					$tr[ $lang ] = $levels[ $i ]['name'];
					update_term_meta( $l['term'], '_lmgt_name_tr', $tr );
				}
			}
		}
		$out = array();
		foreach ( $levels as $l ) {
			// A level whose name could not be translated is left out rather than shown in Danish.
			if ( $l['name'] !== '' ) $out[] = array( 'url' => $l['url'], 'name' => $l['name'] );
		}
		return $out;
	}

	/** A title cut at its first spaced dash, colon or bar: "Amerika — zwei Kontinente, eine ganze Welt" → "Amerika". Unchanged when nothing is left. */
	public static function short( $name ) {
		$name  = trim( (string) $name );
		$parts = preg_split( '/\s+[\x{2014}\x{2013}|-]\s+|:\s+/u', $name, 2 );
		$first = is_array( $parts ) ? trim( $parts[0] ) : '';
		return mb_strlen( $first ) >= 2 ? $first : $name;
	}

	/** Rank Math's primary category, else the post's first category. */
	private static function category( $post_id ) {
		$primary = (int) get_post_meta( $post_id, 'rank_math_primary_category', true );
		$term    = $primary ? get_term( $primary, 'category' ) : null;
		if ( $term && ! is_wp_error( $term ) ) return $term;
		// "Uncategorized" (the default category) says nothing to a reader.
		$cats = array_values( array_filter( get_the_category( $post_id ), function ( $c ) { return (int) $c->term_id !== (int) get_option( 'default_category' ); } ) );
		return $cats ? $cats[0] : null;
	}

	// ---- .travel: store and show ---------------------------------------------------

	public static function store( $id, $trail ) {
		$clean = array();
		foreach ( array_slice( (array) $trail, 0, 6 ) as $l ) {
			if ( ! is_array( $l ) || empty( $l['url'] ) || ! isset( $l['name'] ) || trim( $l['name'] ) === '' ) continue;
			$clean[] = array( 'url' => esc_url_raw( $l['url'] ), 'name' => sanitize_text_field( $l['name'] ) );
		}
		update_post_meta( $id, '_lmgt_trail', wp_slash( $clean ) );
		do_action( 'litespeed_purge_post', $id );
	}

	/** Target: one translation's trail (catch-up). */
	public static function rest_trail( WP_REST_Request $req ) {
		$p  = $req->get_json_params();
		$id = LMGT_Bridge::member( isset( $p['source_id'] ) ? (int) $p['source_id'] : 0, isset( $p['lang'] ) ? (string) $p['lang'] : '' );
		if ( ! $id || get_post_type( $id ) !== LMGT_CPT ) return array( 'skipped' => true );
		self::store( $id, isset( $p['trail'] ) ? $p['trail'] : array() );
		return array( 'id' => $id, 'levels' => count( (array) get_post_meta( $id, '_lmgt_trail', true ) ) );
	}

	/**
	 * The breadcrumb for a translation on this site: [home => [name, url], levels => [[name, url]]].
	 * url '' is a level shown as text. null for any other page.
	 */
	public static function crumbs( $id ) {
		if ( get_post_type( $id ) !== LMGT_CPT ) return null;
		$lang = get_post_meta( $id, '_lmgt_lang', true );
		if ( ! LMGT_Langs::get( $lang ) ) return null;
		$home   = LMGT_Front::lang_home_url( $lang );
		$out    = array( 'home' => array( isset( self::HOME[ $lang ] ) ? self::HOME[ $lang ] : self::HOME['en'], $home ? $home : home_url( '/' ) ), 'levels' => array() );
		$trail  = get_post_meta( $id, '_lmgt_trail', true );
		if ( get_post_meta( $id, '_lmgt_remote_source', true ) && ! get_post_meta( $id, '_lmgt_adopted', true ) ) {
			foreach ( is_array( $trail ) ? $trail : array() as $l ) {
				$m = LMGT_Sync::member_of( $l['url'], $lang );
				$out['levels'][] = array( self::short( $l['name'] ), $m ? get_permalink( $m ) : '' );
			}
			return $out;
		}
		// Made on this site: the English page's parents that are translated into this language.
		$src = (int) get_post_meta( $id, '_lmgt_source', true );
		foreach ( $src ? array_reverse( get_post_ancestors( $src ) ) : array() as $pid ) {
			$tr = LMGT_Store::of( $pid, array( 'publish' ) );
			if ( isset( $tr[ $lang ] ) ) $out['levels'][] = array( self::short( html_entity_decode( get_the_title( $tr[ $lang ] ), ENT_QUOTES, 'UTF-8' ) ), get_permalink( $tr[ $lang ] ) );
		}
		return $out;
	}

	/** Kadence prints its breadcrumb in the header, before the content: rewrite it in the finished page. */
	public static function buffer() {
		if ( is_admin() || ! is_singular( LMGT_CPT ) || is_feed() ) return;
		$c = self::crumbs( get_queried_object_id() );
		if ( ! $c ) return;
		ob_start( function ( $html ) use ( $c ) {
			return self::kadence( $html, $c );
		} );
	}

	/** Replaces the first Kadence breadcrumb's links before the current item; the current item stays as Kadence printed it. */
	public static function kadence( $html, array $c ) {
		if ( ! is_string( $html ) || ! preg_match( '/<div class="kadence-breadcrumb-container">(.*?)(<span class="kadence-bread-current">.*?<\/span>)<\/div>/s', $html, $m, PREG_OFFSET_CAPTURE ) ) return $html;
		$sep  = preg_match( '/<span class="bc-delimiter">.*?<\/span>/s', $m[1][0], $d ) ? $d[0] : '<span class="bc-delimiter">/</span>';
		$out  = '<span><a href="' . esc_url( $c['home'][1] ) . '" itemprop="url" class="kadence-bc-home" ><span>' . esc_html( $c['home'][0] ) . '</span></a></span> ' . $sep . ' ';
		foreach ( $c['levels'] as $l ) {
			$out .= ( $l[1] ? '<span><a href="' . esc_url( $l[1] ) . '" itemprop="url" ><span>' . esc_html( $l[0] ) . '</span></a></span>' : '<span>' . esc_html( $l[0] ) . '</span>' ) . ' ' . $sep . ' ';
		}
		$new = '<div class="kadence-breadcrumb-container">' . $out . $m[2][0] . '</div>';
		return substr_replace( $html, $new, $m[0][1], strlen( $m[0][0] ) );
	}

	/** Rank Math's breadcrumb (and its schema): Home in the language, the levels, the current page as Rank Math made it. */
	public static function rank_math( $crumbs ) {
		if ( ! is_singular( LMGT_CPT ) || ! is_array( $crumbs ) || ! $crumbs ) return $crumbs;
		$c = self::crumbs( get_queried_object_id() );
		if ( ! $c ) return $crumbs;
		$out = array( array( $c['home'][0], $c['home'][1] ) );
		foreach ( $c['levels'] as $l ) {
			$out[] = $l[1] ? array( $l[0], $l[1] ) : array( $l[0], '', 'hide_in_schema' => true );
		}
		$out[] = end( $crumbs );
		return $out;
	}

	// ---- Catch-up on .dk -------------------------------------------------------------

	public static function catchup_section() {
		$n = count( LMGT_Pictures::todo() );
		echo '<h2>Breadcrumbs</h2><p><strong>' . $n . '</strong> translation(s) on traveltalk.travel. One click sends each one the path above it on traveltalk.dk (for example Europa → Østrig), with the names in its language, so its breadcrumb reads in that language. Names are translated once and kept. Nothing in the article changes.</p>';
		if ( ! $n ) return;
		echo '<p><button class="button button-primary" id="lmgt-trail">Send the breadcrumbs</button> <span id="lmgt-trail-st"></span></p><pre id="lmgt-trail-log" style="max-height:300px;overflow:auto;background:#fff;padding:8px"></pre>';
		$nonce = wp_create_nonce( 'lmgt_trail_sync' );
		echo "<script>(function(){var b=document.getElementById('lmgt-trail'),s=document.getElementById('lmgt-trail-st'),l=document.getElementById('lmgt-trail-log');"
			. "function go(i){var d=new FormData();d.append('action','lmgt_trail_sync');d.append('i',i);d.append('_ajax_nonce','" . esc_js( $nonce ) . "');"
			. "fetch(ajaxurl,{method:'POST',body:d,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){"
			. "if(!r.success){l.textContent+='Stopped: '+r.data+'\\n';b.disabled=false;return}l.textContent+=r.data.line+'\\n';s.textContent=r.data.left+' left';"
			. "if(r.data.left>0)go(i+1);else s.textContent='Finished.'}).catch(function(e){l.textContent+='Stopped: '+e+'\\n';b.disabled=false})}"
			. "b.addEventListener('click',function(){b.disabled=true;go(0)})})();</script>";
	}

	public static function ajax_sync() {
		check_ajax_referer( 'lmgt_trail_sync' );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_send_json_error( 'Not allowed.' );
		$todo = LMGT_Pictures::todo();
		$i    = isset( $_POST['i'] ) ? (int) $_POST['i'] : 0;
		if ( ! isset( $todo[ $i ] ) ) wp_send_json_success( array( 'left' => 0, 'line' => 'Nothing left.' ) );
		$it    = $todo[ $i ];
		$trail = self::of( $it['sid'], $it['lang'] );
		$r     = LMGT_Bridge::call( 'POST', '/trail', array( 'source_id' => $it['sid'], 'lang' => $it['lang'], 'trail' => $trail ), false );
		$line  = '#' . $it['sid'] . ' ' . $it['lang'] . ': ' . ( is_wp_error( $r ) ? 'failed – ' . $r->get_error_message() : ( ! empty( $r['skipped'] ) ? 'skipped – a page of traveltalk.travel\'s own' : ( $trail ? implode( ' → ', wp_list_pluck( $trail, 'name' ) ) : 'top level, Home only' ) ) );
		wp_send_json_success( array( 'left' => count( $todo ) - $i - 1, 'line' => $line ) );
	}
}
