<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Translator → Old language setup.
 *
 * Finds what is left of the former GTranslate / LeisureNordic setup and the
 * rules behind the 410 on /sv/ and the redirect from /en/. Reading is the
 * default; every switch-off is reversible and logged with an Undo:
 *   - a mu-plugin is renamed to .php.off (WordPress only loads *.php)
 *   - a plugin is deactivated
 *   - a Rank Math redirection is set to inactive
 *   - 410-list entries are removed, and kept in the log to put back
 * .htaccess and theme files are only shown, never edited. Nothing is deleted.
 */
class LMGT_Legacy {

	const LOG = 'lmgt_legacy_log';

	/** Functions only the old setup defines: proof that a file is loaded right now. */
	const FUNCS = array(
		'tt_current_lang'                => 'tt_gtranslate_fix',
		'tt_hreflang_tags'               => 'tt_gtranslate_fix (prints its own hreflang)',
		'tt_gtranslate_cookie_fix'       => 'tt_gtranslate_fix',
		'tt_lang_switcher_render'        => 'tt_lang_switcher / tt_gtranslate_fix (header switcher)',
		'tt_register_lang_content_block' => 'tt_lang_block',
		'ln_detect_script'               => 'leisurenordic',
		'ln_header_switcher'             => 'leisurenordic (header switcher)',
		'lnl_current_lang'               => 'leisurenordic-lite',
		'tt_translate_text'              => 'Traveltalk AI Translator (old plugin)',
	);

	const MARKERS = '/googtrans|gtranslate|doGTranslate|tt_current_lang|leisurenordic|ln_detect_script|lnl_current_lang|tt_lang_switcher|tt\/lang-content/i';

	/** Shortcodes and blocks of the old setup. Content using them changes when the file is switched off. */
	const CONTENT = array( '<!-- wp:tt/lang-content', '[lang_content', '[nordic', '[tt_lang_switcher', '[nordic_switcher', '[nordic_partner', '[nordic_cta', '[nordic_nav' );

	const PREFIX = '#^/?(da|en|sv|no|nb|fi|de|fr|es|it)(/|$)#';
	const BARE   = '#^/?(da|en|sv|no|nb|fi|de|fr|es|it)/?$#';

	public static function boot() {
		add_action( 'admin_menu', function () {
			add_submenu_page( 'lmgt', 'Old language setup', 'Old language setup', 'manage_options', 'lmgt-legacy', array( __CLASS__, 'page' ) );
		}, 20 );
		add_action( 'admin_post_lmgt_legacy', array( __CLASS__, 'handle' ) );
	}

	// ---- Findings ------------------------------------------------------------

	/**
	 * Every file WordPress loads that could hold the old setup: all mu-plugins,
	 * the main file of each active plugin, the theme's functions.php.
	 *
	 * @return array[] path, kind (mu|plugin|theme), lines
	 */
	private static function files() {
		$out = array();
		foreach ( (array) glob( WPMU_PLUGIN_DIR . '/*.php' ) as $f ) {
			$out[] = array( 'path' => $f, 'kind' => 'mu' );
		}
		foreach ( (array) get_option( 'active_plugins', array() ) as $rel ) {
			$out[] = array( 'path' => WP_PLUGIN_DIR . '/' . $rel, 'kind' => 'plugin', 'plugin' => $rel );
		}
		foreach ( array_unique( array( get_stylesheet_directory(), get_template_directory() ) ) as $d ) {
			if ( is_file( $d . '/functions.php' ) ) $out[] = array( 'path' => $d . '/functions.php', 'kind' => 'theme' );
		}
		$hits = array();
		foreach ( $out as $f ) {
			if ( strpos( $f['path'], LMGT_DIR ) === 0 ) continue;
			$lines = self::matching_lines( $f['path'], self::MARKERS );
			if ( $lines ) $hits[] = $f + array( 'lines' => $lines );
		}
		return $hits;
	}

	/** @return string[] "line: text" for each line matching $re (first 8). */
	private static function matching_lines( $path, $re ) {
		$rows = @file( $path, FILE_IGNORE_NEW_LINES );
		$out  = array();
		foreach ( (array) $rows as $n => $line ) {
			if ( preg_match( $re, $line ) ) $out[] = ( $n + 1 ) . ': ' . trim( mb_substr( $line, 0, 160 ) );
			if ( count( $out ) >= 8 ) break;
		}
		return $out;
	}

	private static function rank_math_rules() {
		global $wpdb;
		$t = $wpdb->prefix . 'rank_math_redirections';
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $t ) ) !== $t ) return array();
		$out = array();
		foreach ( $wpdb->get_results( "SELECT id, sources, url_to, header_code, status FROM $t" ) as $r ) {
			foreach ( (array) maybe_unserialize( $r->sources ) as $src ) {
				$pat = isset( $src['pattern'] ) ? (string) $src['pattern'] : '';
				if ( preg_match( self::PREFIX, $pat ) || ( isset( $src['comparison'] ) && $src['comparison'] === 'regex' && preg_match( '#\\b(en|sv|no|fi)\\b#', $pat ) ) ) {
					$out[] = array( 'id' => (int) $r->id, 'pattern' => $pat, 'comparison' => isset( $src['comparison'] ) ? $src['comparison'] : '', 'to' => $r->url_to, 'code' => $r->header_code, 'status' => $r->status );
				}
			}
		}
		return $out;
	}

	/** Entries in the 410 list for a bare language folder (/sv/), not for old article paths under it. */
	private static function gone_paths() {
		return array_values( array_filter( (array) get_option( 'tt_410_paths', array() ), function ( $p ) {
			return (bool) preg_match( self::BARE, (string) $p );
		} ) );
	}

	/** What the site answers on the bare language folders, and who sent the redirect. */
	private static function probes() {
		$out = array();
		foreach ( array( '/sv/', '/en/', '/no/', '/fi/', '/de/' ) as $p ) {
			$r = wp_remote_get( home_url( $p ), array( 'timeout' => 15, 'redirection' => 0, 'headers' => array( 'User-Agent' => 'LMG-Translator-Check/1.0' ) ) );
			$out[ $p ] = is_wp_error( $r ) ? array( 'code' => $r->get_error_message() ) : array(
				'code' => wp_remote_retrieve_response_code( $r ),
				'to'   => wp_remote_retrieve_header( $r, 'location' ),
				'by'   => wp_remote_retrieve_header( $r, 'x-redirect-by' ),
			);
		}
		return $out;
	}

	/** @return array marker => post IDs, published items only, in their text or their Elementor data. */
	private static function content_uses() {
		global $wpdb;
		$out = array();
		foreach ( self::CONTENT as $m ) {
			$like = '%' . $wpdb->esc_like( $m ) . '%';
			$ids  = $wpdb->get_col( $wpdb->prepare(
				"SELECT DISTINCT p.ID FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} e ON e.post_id = p.ID AND e.meta_key = '_elementor_data'
				 WHERE p.post_status = 'publish' AND p.post_type <> 'revision' AND ( p.post_content LIKE %s OR e.meta_value LIKE %s )
				 ORDER BY p.ID",
				$like, $like
			) );
			if ( $ids ) $out[ $m ] = array_map( 'intval', $ids );
		}
		return $out;
	}

	// ---- Page ----------------------------------------------------------------

	public static function page() {
		echo '<div class="wrap"><h1>Old language setup</h1><p>Read-only unless you press a button. Every button can be undone below. Nothing is deleted.</p>';

		echo '<h2>1. Old code loaded right now</h2>';
		$loaded = array_filter( self::FUNCS, 'function_exists', ARRAY_FILTER_USE_KEY );
		echo $loaded ? '<ul style="list-style:disc;margin-left:18px"><li>' . implode( '</li><li>', array_map( function ( $f, $w ) { return '<code>' . esc_html( $f ) . '()</code> — ' . esc_html( $w ); }, array_keys( $loaded ), $loaded ) ) . '</li></ul>' : '<p style="color:#008a20">None of the old functions is defined. Nothing of the old setup is running.</p>';

		echo '<h2>2. Files that mention the old setup</h2>';
		$files = self::files();
		if ( ! $files ) echo '<p style="color:#008a20">No mu-plugin, active plugin or theme functions.php mentions it.</p>';
		foreach ( $files as $f ) {
			echo '<p><code>' . esc_html( str_replace( ABSPATH, '', $f['path'] ) ) . '</code> (' . esc_html( $f['kind'] ) . ', loaded by WordPress) ';
			if ( $f['kind'] === 'mu' ) echo self::button( 'mu_off', $f['path'], 'Switch off (rename to .off)' );
			if ( $f['kind'] === 'plugin' ) echo self::button( 'plugin_off', $f['plugin'], 'Deactivate plugin' );
			if ( $f['kind'] === 'theme' ) echo '<em>theme file: shown only, edit by hand</em>';
			echo '</p><pre style="background:#f6f7f7;padding:6px 10px;white-space:pre-wrap">' . esc_html( implode( "\n", $f['lines'] ) ) . '</pre>';
		}
		$uses = self::content_uses();
		if ( $uses ) {
			echo '<div class="notice notice-warning inline"><p><strong>Published content still uses the old shortcodes/blocks.</strong> With their code no longer loaded, visitors may see the raw tag. Remove the tags by hand: keep text meant for everyone, delete text meant only for one country.</p>';
			foreach ( $uses as $m => $ids ) {
				echo '<p><code>' . esc_html( $m ) . '</code> in ' . count( $ids ) . ' item(s):</p><ul style="list-style:disc;margin-left:18px">';
				foreach ( $ids as $id ) {
					printf( '<li><a href="%s">%s</a> (%s) · <a href="%s" target="_blank">view</a></li>', esc_url( get_edit_post_link( $id ) ), esc_html( get_the_title( $id ) ?: '#' . $id ), esc_html( get_post_type( $id ) ), esc_url( get_permalink( $id ) ) );
				}
				echo '</ul>';
			}
			echo '</div>';
		}

		echo '<h2>3. The bare language folders as served</h2><table class="widefat striped"><thead><tr><th>Address</th><th>Answer</th><th>Redirects to</th><th>Sent by</th></tr></thead><tbody>';
		foreach ( self::probes() as $p => $r ) {
			printf( '<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>', esc_html( $p ), esc_html( $r['code'] ), esc_html( isset( $r['to'] ) ? $r['to'] : '' ), esc_html( isset( $r['by'] ) && $r['by'] ? $r['by'] : ( isset( $r['to'] ) && $r['to'] ? 'no X-Redirect-By: server rule (.htaccess / LiteSpeed)' : '' ) ) );
		}
		echo '</tbody></table>';

		echo '<h3>410 list (tt_410_handler): bare language folders</h3>';
		$gone = self::gone_paths();
		echo $gone ? '<pre>' . esc_html( implode( "\n", $gone ) ) . '</pre>' . self::button( 'gone_off', '', 'Remove these ' . count( $gone ) . ' entries' ) : '<p>None.</p>';

		echo '<h3>Rank Math redirections on a language folder</h3>';
		$rules = self::rank_math_rules();
		if ( ! $rules ) echo '<p>None.</p>';
		foreach ( $rules as $r ) {
			echo '<p>#' . (int) $r['id'] . ' <code>' . esc_html( $r['pattern'] ) . '</code> (' . esc_html( $r['comparison'] ) . ') → ' . esc_html( $r['to'] ? $r['to'] : '—' ) . ' · ' . esc_html( $r['code'] ) . ' · ' . esc_html( $r['status'] ) . ' ';
			if ( $r['status'] === 'active' ) echo self::button( 'rm_off', (string) $r['id'], 'Set inactive' );
			echo '</p>';
		}

		echo '<h3>.htaccess lines on a language folder</h3>';
		$ht = is_file( ABSPATH . '.htaccess' ) ? self::matching_lines( ABSPATH . '.htaccess', '#^\s*(RewriteRule|RewriteCond|Redirect\w*)\b.*[\^/ ](en|sv|no|fi)(/|\$|\s|$)#i' ) : array();
		echo $ht ? '<pre>' . esc_html( implode( "\n", $ht ) ) . '</pre><p class="description">Shown only. A wrong .htaccess edit takes the site down, so this is done by hand with a backup.</p>' : '<p>None.</p>';

		echo '<h2>Log</h2>';
		$log = array_reverse( (array) get_option( self::LOG, array() ), true );
		if ( ! $log ) echo '<p>Nothing switched off yet.</p>';
		foreach ( $log as $i => $e ) {
			echo '<p>' . esc_html( $e['at'] . ' — ' . $e['what'] ) . ' ' . ( empty( $e['undone'] ) ? self::button( 'undo', (string) $i, 'Undo' ) : '<em>undone</em>' ) . '</p>';
		}
		echo '</div>';
	}

	private static function button( $do, $arg, $label ) {
		return '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline">'
			. wp_nonce_field( 'lmgt_legacy', '_wpnonce', true, false )
			. '<input type="hidden" name="action" value="lmgt_legacy"><input type="hidden" name="do" value="' . esc_attr( $do ) . '"><input type="hidden" name="arg" value="' . esc_attr( $arg ) . '">'
			. '<button class="button">' . esc_html( $label ) . '</button></form>';
	}

	// ---- Actions -------------------------------------------------------------

	public static function handle() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Not allowed.' );
		check_admin_referer( 'lmgt_legacy' );
		$arg = wp_unslash( isset( $_POST['arg'] ) ? $_POST['arg'] : '' );
		$msg = self::act( sanitize_key( $_POST['do'] ), $arg );
		do_action( 'litespeed_purge_all' );
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $msg ), admin_url( 'admin.php?page=lmgt-legacy' ) ) );
		exit;
	}

	private static function act( $do, $arg ) {
		global $wpdb;
		switch ( $do ) {
			case 'mu_off':
				$f = realpath( $arg );
				if ( ! $f || dirname( $f ) !== realpath( WPMU_PLUGIN_DIR ) || substr( $f, -4 ) !== '.php' ) return 'Not a mu-plugin.';
				if ( ! @rename( $f, $f . '.off' ) ) return 'Could not rename (file permissions). Nothing changed.';
				self::log( 'Renamed ' . basename( $f ) . ' to ' . basename( $f ) . '.off', array( 'type' => 'mu', 'path' => $f ) );
				return basename( $f ) . ' switched off.';

			case 'plugin_off':
				if ( ! in_array( $arg, (array) get_option( 'active_plugins', array() ), true ) ) return 'Plugin not active.';
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
				deactivate_plugins( $arg );
				self::log( 'Deactivated ' . $arg, array( 'type' => 'plugin', 'plugin' => $arg ) );
				return $arg . ' deactivated.';

			case 'gone_off':
				$gone = self::gone_paths();
				if ( ! $gone ) return 'Nothing to remove.';
				update_option( 'tt_410_paths', array_values( array_diff( (array) get_option( 'tt_410_paths', array() ), $gone ) ), false );
				self::log( 'Removed from the 410 list: ' . implode( ', ', $gone ), array( 'type' => 'gone', 'paths' => $gone ) );
				return count( $gone ) . ' entries removed from the 410 list.';

			case 'rm_off':
				$id = (int) $arg;
				$t  = $wpdb->prefix . 'rank_math_redirections';
				$was = $wpdb->get_var( $wpdb->prepare( "SELECT status FROM $t WHERE id = %d", $id ) );
				if ( $was !== 'active' ) return 'Redirection not active.';
				$wpdb->update( $t, array( 'status' => 'inactive' ), array( 'id' => $id ) );
				$wpdb->delete( $wpdb->prefix . 'rank_math_redirections_cache', array( 'redirection_id' => $id ) );
				self::log( 'Rank Math redirection #' . $id . ' set inactive', array( 'type' => 'rm', 'id' => $id ) );
				return 'Redirection #' . $id . ' set inactive.';

			case 'undo':
				return self::undo( (int) $arg );
		}
		return 'Unknown action.';
	}

	private static function log( $what, array $undo ) {
		$log   = (array) get_option( self::LOG, array() );
		$log[] = array( 'at' => current_time( 'mysql' ), 'what' => $what, 'undo' => $undo );
		update_option( self::LOG, $log, false );
	}

	private static function undo( $i ) {
		global $wpdb;
		$log = (array) get_option( self::LOG, array() );
		if ( ! isset( $log[ $i ] ) || ! empty( $log[ $i ]['undone'] ) ) return 'Nothing to undo.';
		$u = $log[ $i ]['undo'];
		switch ( $u['type'] ) {
			case 'mu':
				if ( ! @rename( $u['path'] . '.off', $u['path'] ) ) return 'Could not rename back. Nothing changed.';
				break;
			case 'plugin':
				require_once ABSPATH . 'wp-admin/includes/plugin.php';
				$r = activate_plugin( $u['plugin'] );
				if ( is_wp_error( $r ) ) return 'Could not reactivate: ' . $r->get_error_message();
				break;
			case 'gone':
				update_option( 'tt_410_paths', array_values( array_unique( array_merge( (array) get_option( 'tt_410_paths', array() ), $u['paths'] ) ) ), false );
				break;
			case 'rm':
				$wpdb->update( $wpdb->prefix . 'rank_math_redirections', array( 'status' => 'active' ), array( 'id' => (int) $u['id'] ) );
				break;
		}
		$log[ $i ]['undone'] = current_time( 'mysql' );
		update_option( self::LOG, $log, false );
		return 'Undone: ' . $log[ $i ]['what'];
	}
}
