<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.2.18: pictures saved on traveltalk.travel (brief item 3).
 *
 * Every picture inside a translation that came from traveltalk.dk loaded from
 * traveltalk.dk's host. This step, on .travel (Translator → Save pictures),
 * imports each such picture once into .travel's own media library and points
 * the translation at it. The same picture used in several languages is
 * imported once (meta _lmgt_imported_from on the attachment = the full-size
 * address on .dk). A few pictures per click-free step, a pause between steps,
 * one retry on a host-limit answer (508). English translations go first, so
 * the file name comes from an English picture text where there is one.
 *
 * The text is written straight to the database: no revision, no "Mother text
 * changed", no notice to .dk, and the modified date stays. A picture that
 * cannot be fetched is left as it was and listed. Translations that arrive
 * or are applied later bring .dk's addresses again: run the step again.
 */
class LMGT_LocalPics {

	const PER_STEP = 2;

	public static function boot() {
		if ( ! LMGT_Bridge::on() || ! LMGT_Bridge::is_target() ) return;
		add_action( 'admin_menu', function () {
			add_submenu_page( 'lmgt', 'Save pictures', 'Save pictures', 'edit_others_posts', 'lmgt-localpics', array( __CLASS__, 'page' ) );
		}, 36 );
		add_action( 'wp_ajax_lmgt_localpics_step', array( __CLASS__, 'ajax_step' ) );
	}

	// ---- Pure text work (no WordPress calls) -----------------------------------

	/** The host of the peer without "www.", lower case. */
	public static function host_of( $url ) {
		$h = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		return preg_replace( '/^www\./', '', $h );
	}

	/**
	 * An address inside a translation, as an absolute address on the peer's uploads
	 * folder, or '' when it is not one. Short addresses ("2022/06/x.png") count.
	 */
	public static function peer_url( $src, $peer ) {
		$src = html_entity_decode( trim( (string) $src ), ENT_QUOTES, 'UTF-8' );
		if ( $src === '' ) return '';
		$base = untrailingslashit( $peer ) . '/wp-content/uploads/';
		if ( preg_match( '#^\d{4}/\d{2}/[^/].*$#', $src ) ) return $base . $src;
		if ( strpos( $src, '//' ) === 0 ) $src = 'https:' . $src;
		if ( ! preg_match( '#^https?://#i', $src ) ) return '';
		if ( self::host_of( $src ) !== self::host_of( $peer ) ) return '';
		if ( strpos( wp_parse_url( $src, PHP_URL_PATH ), '/wp-content/uploads/' ) !== 0 ) return '';
		return $src;
	}

	/** [full-size address without query, width asked for or 0]: ".../x-1024x683.jpg" → [".../x.jpg", 1024]. */
	public static function canon( $url ) {
		$url = preg_replace( '/[?#].*$/', '', (string) $url );
		$url = preg_replace( '#^http://#i', 'https://', $url );
		$url = preg_replace( '#^(https://)www\.#i', '$1', $url );
		$w   = 0;
		if ( preg_match( '/^(.*)-(\d{2,5})x(\d{2,5})(\.[A-Za-z0-9]{2,5})$/', $url, $m ) ) {
			$w   = (int) $m[2];
			$url = $m[1] . $m[4];
		}
		return array( $url, $w );
	}

	/** Every .dk picture address in $html: [[exact src, absolute address]], in order. */
	public static function found( $html, $peer ) {
		$out = array();
		if ( ! preg_match_all( '/<img\b[^>]*>/i', (string) $html, $tags ) ) return $out;
		foreach ( $tags[0] as $tag ) {
			foreach ( array( 'src', 'data-src' ) as $a ) {
				if ( ! preg_match( '/\s' . $a . '=(["\'])(.*?)\1/is', $tag, $m ) ) continue;
				$abs = self::peer_url( $m[2], $peer );
				if ( $abs !== '' ) $out[] = array( $m[2], $abs );
			}
		}
		return $out;
	}

	public static function attr( $tag, $name ) {
		return preg_match( '/\s' . preg_quote( $name, '/' ) . '=(["\'])(.*?)\1/is', $tag, $m ) ? html_entity_decode( $m[2], ENT_QUOTES, 'UTF-8' ) : '';
	}

	/**
	 * Rewrites the pictures of $html. $resolve( $absolute_address, $alt ) returns
	 * [attachment id, new address] to switch it, null to leave it for a later step,
	 * false when it cannot be fetched (left as it is). $report gets the outcome per address.
	 */
	public static function rewrite( $html, $peer, callable $resolve, &$report ) {
		$report = array( 'switched' => 0, 'left' => 0, 'failed' => array() );
		$hrefs  = array();
		$tagfn  = function ( $m ) use ( $peer, $resolve, &$report, &$hrefs ) {
			$tag = $m[0];
			$src = self::attr( $tag, 'src' );
			$ds  = self::attr( $tag, 'data-src' );
			$abs = self::peer_url( $src, $peer );
			if ( $abs === '' ) $abs = self::peer_url( $ds, $peer );
			if ( $abs === '' ) return $tag;
			$r = $resolve( $abs, self::attr( $tag, 'alt' ) );
			if ( $r === false ) { $report['failed'][] = $abs; return $tag; }
			if ( ! $r ) { $report['left']++; return $tag; }
			list( $id, $new ) = $r;
			foreach ( array( 'src', 'data-src' ) as $a ) {
				if ( self::attr( $tag, $a ) !== '' && self::peer_url( self::attr( $tag, $a ), $peer ) !== '' ) {
					$tag = preg_replace( '/(\s' . $a . '=)(["\'])(.*?)\2/is', '$1"' . esc_url( $new ) . '"', $tag, 1 );
				}
			}
			// WordPress builds srcset itself from the attachment; the .dk one would point back there.
			$tag = preg_replace( '/\s(?:srcset|data-srcset|sizes|data-sizes)=(["\']).*?\1/is', '', $tag );
			if ( preg_match( '/\sclass=(["\'])(.*?)\1/is', $tag, $c ) ) {
				$cls = preg_replace( '/\bwp-image-\d+\b/', '', $c[2] );
				$tag = preg_replace( '/(\sclass=)(["\'])(.*?)\2/is', '$1"' . trim( $cls . ' wp-image-' . (int) $id ) . '"', $tag, 1 );
			} else {
				$tag = preg_replace( '/<img\b/i', '<img class="wp-image-' . (int) $id . '"', $tag, 1 );
			}
			$hrefs[ $abs ] = array( $new, (int) $id );
			$report['switched']++;
			return $tag;
		};
		// Image blocks first: their stored id must follow the new picture, or the editor calls the block broken.
		$html = preg_replace_callback( '/(<!-- wp:image\s+)(\{.*?\})(\s*-->)(.*?)(<!-- \/wp:image -->)/s', function ( $b ) use ( $tagfn, &$hrefs ) {
			$before = count( $hrefs );
			$inner  = preg_replace_callback( '/<img\b[^>]*>/i', $tagfn, $b[4] );
			$json   = $b[2];
			if ( count( $hrefs ) > $before ) {
				$last = end( $hrefs );
				$json = preg_replace( '/"id"\s*:\s*\d+/', '"id":' . (int) $last[1], $json, 1 );
			}
			return $b[1] . $json . $b[3] . $inner . $b[5];
		}, (string) $html );
		$html = preg_replace_callback( '/<img\b[^>]*>/i', $tagfn, $html );
		// A picture that links to its own large file.
		$html = preg_replace_callback( '/(<a\b[^>]*\shref=)(["\'])(.*?)\2/is', function ( $m ) use ( $peer, &$hrefs ) {
			$abs = self::peer_url( $m[3], $peer );
			if ( $abs === '' ) return $m[0];
			list( $full ) = self::canon( $abs );
			foreach ( $hrefs as $from => $to ) {
				list( $f ) = self::canon( $from );
				if ( $f === $full ) return $m[1] . '"' . esc_url( $to[0] ) . '"';
			}
			return $m[0];
		}, $html );
		return $html;
	}

	// ---- Work -------------------------------------------------------------------

	/** Translation IDs with a .dk picture in their text, English first, minus the ones whose pictures failed. */
	public static function todo() {
		global $wpdb;
		$peer = LMGT_Bridge::peer();
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT p.ID, p.post_content, l.meta_value AS lang FROM {$wpdb->posts} p
			LEFT JOIN {$wpdb->postmeta} l ON l.post_id = p.ID AND l.meta_key = '_lmgt_lang'
			WHERE p.post_type = %s AND p.post_status IN ('publish','draft','pending','future','private') AND p.post_content LIKE %s ORDER BY p.ID ASC", LMGT_CPT, '%<img%' ) );
		$out = array();
		foreach ( $rows as $r ) {
			$failed = (array) get_post_meta( $r->ID, '_lmgt_pics_failed', true );
			$n      = 0;
			foreach ( self::found( $r->post_content, $peer ) as $f ) {
				if ( ! in_array( self::canon( $f[1] )[0], $failed, true ) ) $n++;
			}
			if ( $n ) $out[] = array( 'id' => (int) $r->ID, 'lang' => (string) $r->lang, 'pics' => $n );
		}
		usort( $out, function ( $a, $b ) {
			$ea = $a['lang'] === 'en' ? 0 : 1;
			$eb = $b['lang'] === 'en' ? 0 : 1;
			return $ea === $eb ? $a['id'] - $b['id'] : $ea - $eb;
		} );
		return $out;
	}

	private static function existing( $key ) {
		$ids = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_lmgt_imported_from', 'meta_value' => $key, 'no_found_rows' => true ) );
		return $ids ? (int) $ids[0] : 0;
	}

	/** A file name from a picture text: lower case words, 60 characters at most, with the original extension. */
	public static function file_name( $alt, $original ) {
		$ext  = strtolower( pathinfo( wp_parse_url( $original, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
		$base = sanitize_title( wp_strip_all_tags( $alt ) );
		if ( $base === '' ) $base = sanitize_title( pathinfo( wp_parse_url( $original, PHP_URL_PATH ), PATHINFO_FILENAME ) );
		return trim( substr( $base, 0, 60 ), '-' ) . '.' . ( $ext ? $ext : 'jpg' );
	}

	/** Fetch and import one picture. Returns the attachment ID or a WP_Error. */
	private static function import( $key, $first_given, $alt, $english ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$tmp = null;
		$base = untrailingslashit( LMGT_Bridge::peer() );
		$path = (string) wp_parse_url( $key, PHP_URL_PATH );
		foreach ( array( $base . $path, $first_given ) as $try ) {
			if ( ! $try ) continue;
			for ( $i = 0; $i < 2; $i++ ) {
				$tmp = download_url( $try, 60 );
				if ( ! is_wp_error( $tmp ) ) break 2;
				// Host limit (508) or a passing 5xx: wait and ask once more.
				if ( $i === 0 && preg_match( '/\b(5\d\d)\b/', $tmp->get_error_message() ) ) sleep( 4 ); else break;
			}
		}
		if ( is_wp_error( $tmp ) ) return $tmp;
		$name = self::file_name( $english ? $alt : '', $key );
		$id   = media_handle_sideload( array( 'name' => $name, 'tmp_name' => $tmp ), 0, null, array( 'post_title' => $alt !== '' ? wp_strip_all_tags( $alt ) : pathinfo( $name, PATHINFO_FILENAME ) ) );
		if ( is_wp_error( $id ) ) { if ( file_exists( $tmp ) ) @unlink( $tmp ); return $id; }
		update_post_meta( $id, '_lmgt_imported_from', $key );
		if ( $alt !== '' ) update_post_meta( $id, '_wp_attachment_image_alt', wp_strip_all_tags( $alt ) );
		return (int) $id;
	}

	/** The address of attachment $id at the width the text asked for, else the full size. */
	private static function url_for( $id, $width ) {
		if ( $width ) {
			$meta = wp_get_attachment_metadata( $id );
			$dir  = dirname( (string) wp_get_attachment_url( $id ) );
			foreach ( isset( $meta['sizes'] ) ? (array) $meta['sizes'] : array() as $s ) {
				if ( (int) $s['width'] === (int) $width ) return $dir . '/' . $s['file'];
			}
		}
		return (string) wp_get_attachment_url( $id );
	}

	/** One translation, up to PER_STEP new imports. Returns [line, failed addresses, done]. */
	public static function step( $post_id ) {
		global $wpdb;
		$post   = get_post( $post_id );
		$peer   = LMGT_Bridge::peer();
		$lang   = (string) get_post_meta( $post_id, '_lmgt_lang', true );
		$budget = self::PER_STEP;
		$failed = (array) get_post_meta( $post_id, '_lmgt_pics_failed', true );
		$errs   = array();
		$resolve = function ( $abs, $alt ) use ( &$budget, $failed, &$errs, $lang ) {
			list( $key, $w ) = self::canon( $abs );
			if ( in_array( $key, $failed, true ) ) return null;
			$id = self::existing( $key );
			if ( ! $id ) {
				if ( $budget < 1 ) return null;
				$budget--;
				$id = self::import( $key, $abs !== $key ? $abs : '', $alt, $lang === 'en' );
				if ( is_wp_error( $id ) ) { $errs[ $key ] = $id->get_error_message(); return false; }
			}
			return array( $id, self::url_for( $id, $w ) );
		};
		$new = self::rewrite( $post->post_content, $peer, $resolve, $report );
		if ( $new !== $post->post_content ) {
			$wpdb->update( $wpdb->posts, array( 'post_content' => $new ), array( 'ID' => $post_id ) );
			clean_post_cache( $post_id );
			do_action( 'litespeed_purge_post', $post_id );
		}
		// Nothing switched and nothing failed: leave it alone rather than run for ever.
		if ( ! $report['switched'] && ! $report['failed'] ) {
			foreach ( self::found( $post->post_content, $peer ) as $f ) $report['failed'][] = $f[1];
			$errs[ $peer ] = 'not recognised, left as it is';
		}
		if ( $report['failed'] ) {
			$keys = array();
			foreach ( $report['failed'] as $f ) $keys[] = self::canon( $f )[0];
			update_post_meta( $post_id, '_lmgt_pics_failed', array_values( array_unique( array_merge( $failed, $keys ) ) ) );
		}
		$line = '#' . $post_id . ' ' . $lang . ' ' . get_the_title( $post_id ) . ': ' . $report['switched'] . ' saved here'
			. ( $report['left'] ? ', ' . $report['left'] . ' still to do' : '' )
			. ( $report['failed'] ? ', ' . count( $report['failed'] ) . ' could not be fetched (' . implode( '; ', array_map( function ( $k, $v ) { return basename( $k ) . ': ' . $v; }, array_keys( $errs ), $errs ) ) . ')' : '' );
		return array( $line, $report['failed'] );
	}

	// ---- Screen -----------------------------------------------------------------

	public static function page() {
		$todo = self::todo();
		$pics = array_sum( wp_list_pluck( $todo, 'pics' ) );
		echo '<div class="wrap"><h1>Save pictures on this site</h1>';
		echo '<p>Pictures inside translations came from traveltalk.dk and still load from there. This step copies each one once into this site\'s media library and points the translation at it. The same picture used in several languages is copied once. Two pictures at a time, with a pause, because the hosts answer 508 under load. The text is not otherwise changed: no new revision, no "Mother text changed".</p>';
		if ( ! $todo ) {
			echo '<p style="color:#008a20"><strong>Every translation here uses its own pictures.</strong> (Translations that arrive or are applied later bring traveltalk.dk\'s addresses again: run this step again then.)</p></div>';
			return;
		}
		echo '<p><strong>' . count( $todo ) . '</strong> translation(s) with <strong>' . $pics . '</strong> picture(s) still on traveltalk.dk. English first.</p>';
		echo '<p><button class="button button-primary" id="lmgt-lp">Save the pictures</button> <label><input type="checkbox" id="lmgt-lp-retry"> also try again the pictures that failed before</label> <span id="lmgt-lp-st"></span></p><pre id="lmgt-lp-log" style="max-height:340px;overflow:auto;background:#fff;padding:8px"></pre>';
		$nonce = wp_create_nonce( 'lmgt_localpics_step' );
		echo "<script>(function(){var b=document.getElementById('lmgt-lp'),s=document.getElementById('lmgt-lp-st'),l=document.getElementById('lmgt-lp-log'),r=document.getElementById('lmgt-lp-retry'),stop=0;"
			. "function go(first){var d=new FormData();d.append('action','lmgt_localpics_step');d.append('first',first?'1':'0');d.append('retry',r.checked?'1':'0');d.append('_ajax_nonce','" . esc_js( $nonce ) . "');"
			. "fetch(ajaxurl,{method:'POST',body:d,credentials:'same-origin'}).then(function(x){return x.json()}).then(function(x){"
			. "if(!x.success){l.textContent+='Stopped: '+x.data+'\\n';b.disabled=false;return}l.textContent+=x.data.line+'\\n';l.scrollTop=l.scrollHeight;s.textContent=x.data.left+' translation(s) left';"
			. "if(x.data.left>0)setTimeout(function(){go(false)},2500);else{s.textContent='Finished.';b.disabled=false}}).catch(function(e){l.textContent+='Stopped: '+e+'\\n';b.disabled=false})}"
			. "b.addEventListener('click',function(){b.disabled=true;go(true)})})();</script></div>";
	}

	public static function ajax_step() {
		check_ajax_referer( 'lmgt_localpics_step' );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_send_json_error( 'Not allowed.' );
		@set_time_limit( 120 );
		if ( ! empty( $_POST['retry'] ) && ! empty( $_POST['first'] ) && $_POST['first'] === '1' ) delete_post_meta_by_key( '_lmgt_pics_failed' );
		$todo = self::todo();
		if ( ! $todo ) wp_send_json_success( array( 'left' => 0, 'line' => 'Nothing left.' ) );
		list( $line ) = self::step( $todo[0]['id'] );
		wp_send_json_success( array( 'left' => count( self::todo() ), 'line' => $line ) );
	}
}
