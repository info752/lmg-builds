<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.2.0: right from the first translation (brief 4.10–4.18, G 27 Oct 2026).
 *
 * Links (4.10), on .travel: a link to a .dk article points at its published
 * version in the page's language when there is one (thin ones included), and
 * stays on the .dk original until then. Decided when the page is shown, from
 * the members' own meta, so links switch by themselves as translations are
 * published. Relative links are made absolute (.dk) when a draft is sent.
 *
 * Mother text (4.11): .dk keeps a fingerprint of each original's plain text
 * (tags and shortcodes stripped, so a link-only edit does not count). A changed
 * fingerprint goes to .travel, which flags every translation made from an
 * older text. Nothing re-translates without a person. One way only, .dk →
 * .travel: a translation is never back-translated (4.12).
 *
 * Danish-only blocks (4.13), on .travel translations: shortcodes and link
 * domains listed in Settings print nothing (links keep their text). Shortcodes
 * this site does not have print nothing either, so no raw [tag] reaches a reader.
 *
 * Featured image (4.15): alt text and caption are translated when the draft is
 * sent and kept per language on the attachment on .travel. The attachment's
 * own fields stay as they are.
 *
 * Review list (4.18): Translator → Review.
 *
 * Meta, source (.dk):    _lmgt_text_hash        on the original
 * Meta, target (.travel): _lmgt_source_hash      fingerprint of the text the translation was made from
 *                        _lmgt_mother_changed   [at, hash] once the Danish text has changed since
 *                        _lmgt_alt_{lang}, _lmgt_caption_{lang}  on an attachment
 */
class LMGT_Sync {

	const MAP          = 'lmgt_dk_links';
	const DANISH_ONLY  = "tt_gyg\ntt_airalo\nnordic_partner\nnordic_cta\ngetyourguide.com\ngetyourguide.dk\nairalo.com";

	public static function boot() {
		add_action( 'admin_menu', function () {
			add_submenu_page( 'lmgt', 'Review', 'Review', 'edit_others_posts', 'lmgt-review', array( __CLASS__, 'page' ) );
		}, 25 );
		if ( ! LMGT_Bridge::on() ) return;
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		if ( LMGT_Bridge::is_source() ) {
			add_action( 'post_updated', array( __CLASS__, 'source_saved' ), 40, 3 );
			return;
		}
		add_filter( 'the_content', array( __CLASS__, 'danish_only' ), 10 );
		add_filter( 'the_content', array( __CLASS__, 'local_links' ), 21 );
		add_filter( 'wp_get_attachment_image_attributes', array( __CLASS__, 'image_alt' ), 20, 2 );
		add_filter( 'attachment_fields_to_edit', array( __CLASS__, 'media_fields' ), 20, 2 );
		add_filter( 'attachment_fields_to_save', array( __CLASS__, 'media_fields_save' ), 20, 2 );
		add_filter( 'wp_get_attachment_caption', array( __CLASS__, 'image_caption' ), 20, 2 );
		// The link map is rebuilt after any change to a member's address, language or status.
		$forget = function () { delete_transient( self::MAP ); };
		foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $h ) {
			add_action( $h, function ( $mid, $pid, $key ) use ( $forget ) { if ( in_array( $key, array( '_lmgt_remote_url', '_lmgt_remote_source', '_lmgt_lang', '_lmgt_set' ), true ) ) $forget(); }, 10, 3 );
		}
		add_action( 'transition_post_status', function ( $new, $old, $post ) use ( $forget ) { if ( $new !== $old && get_post_meta( $post->ID, '_lmgt_remote_source', true ) ) $forget(); }, 10, 3 );
		add_action( 'post_updated', function ( $id, $after, $before ) use ( $forget ) { if ( $after->post_name !== $before->post_name && get_post_meta( $id, '_lmgt_remote_source', true ) ) $forget(); }, 10, 3 );
		add_action( 'add_meta_boxes', function () {
			add_meta_box( 'lmgt_mother', 'Danish original', array( __CLASS__, 'box' ), LMGT_CPT, 'side', 'high' );
		} );
		add_action( 'admin_post_lmgt_retranslate', array( __CLASS__, 'handle_retranslate' ) );
		add_action( 'admin_post_lmgt_mother_ok', array( __CLASS__, 'handle_mother_ok' ) );
		add_filter( 'views_edit-' . LMGT_CPT, array( __CLASS__, 'view_changed' ) );
		add_action( 'pre_get_posts', function ( $q ) {
			if ( is_admin() && $q->is_main_query() && ! empty( $_GET['lmgt_changed'] ) ) $q->set( 'meta_key', '_lmgt_mother_changed' );
		} );
	}

	public static function routes() {
		$can = function () { return current_user_can( 'edit_others_posts' ); };
		if ( LMGT_Bridge::is_target() ) {
			register_rest_route( LMGT_Bridge::NS, '/changed', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_changed' ), 'permission_callback' => $can ) );
		} else {
			register_rest_route( LMGT_Bridge::NS, '/requeue', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_requeue' ), 'permission_callback' => $can ) );
		}
	}

	// ---- Mother text (4.11) ----------------------------------------------------

	/** What a reader reads: title and text, no tags, links or shortcodes. */
	public static function text_hash( $post ) {
		return md5( LMGT_Text::plain( $post->post_title ) . '|' . LMGT_Text::plain( $post->post_content ) );
	}

	/** Source: an original with members on .travel was saved with a different text. */
	public static function source_saved( $id, $after, $before ) {
		if ( ! in_array( $after->post_type, LMGT_Store::types(), true ) || $after->post_status !== 'publish' || ! LMGT_Bridge::remote( $id ) ) return;
		$hash = self::text_hash( $after );
		if ( $hash === get_post_meta( $id, '_lmgt_text_hash', true ) ) return;
		update_post_meta( $id, '_lmgt_text_hash', $hash );
		LMGT_Bridge::call( 'POST', '/changed', array( 'hashes' => array( $id => array( 'hash' => $hash, 'at' => $after->post_modified_gmt ) ) ) );
	}

	/**
	 * Target: [source_id => [hash, at]]. A translation made from another text is
	 * flagged; one back on the same text is cleared. baseline only fills in a
	 * missing fingerprint (the 2.2.0 upgrade), never flags.
	 */
	public static function rest_changed( WP_REST_Request $req ) {
		$p        = $req->get_json_params();
		$baseline = ! empty( $p['baseline'] );
		$flagged  = 0;
		foreach ( (array) ( isset( $p['hashes'] ) ? $p['hashes'] : array() ) as $sid => $h ) {
			if ( ! is_array( $h ) || empty( $h['hash'] ) ) continue;
			$hash = sanitize_key( $h['hash'] );
			foreach ( LMGT_Bridge::members( (int) $sid ) as $id ) {
				// Linked English pages and translations made here have their own text; improve-and-keep covers them.
				if ( get_post_type( $id ) !== LMGT_CPT || get_post_meta( $id, '_lmgt_adopted', true ) ) continue;
				$had = get_post_meta( $id, '_lmgt_source_hash', true );
				if ( $baseline ) {
					if ( $had === '' ) update_post_meta( $id, '_lmgt_source_hash', $hash );
					continue;
				}
				if ( $had === $hash ) {
					delete_post_meta( $id, '_lmgt_mother_changed' );
					continue;
				}
				update_post_meta( $id, '_lmgt_mother_changed', array( 'at' => sanitize_text_field( isset( $h['at'] ) ? (string) $h['at'] : '' ), 'hash' => $hash ) );
				$flagged++;
			}
		}
		return array( 'flagged' => $flagged );
	}

	/** Source: "Re-translate" on .travel queues the job here, as the Queue page would. */
	public static function rest_requeue( WP_REST_Request $req ) {
		$p = $req->get_json_params();
		$r = LMGT_Jobs::add( isset( $p['source_id'] ) ? (int) $p['source_id'] : 0, isset( $p['lang'] ) ? (string) $p['lang'] : '' );
		return is_wp_error( $r ) ? new WP_Error( 'lmgt_queue', $r->get_error_message(), array( 'status' => 409 ) ) : array( 'job' => $r );
	}

	/** The translation now carries the text it was made from: store it, and clear the flag when it is the current one. */
	public static function made_from( $id, $hash ) {
		if ( $hash === '' ) return;
		update_post_meta( $id, '_lmgt_source_hash', $hash );
		$c = get_post_meta( $id, '_lmgt_mother_changed', true );
		if ( ! is_array( $c ) || $c['hash'] === $hash ) delete_post_meta( $id, '_lmgt_mother_changed' );
	}

	public static function box( $post ) {
		$c   = get_post_meta( $post->ID, '_lmgt_mother_changed', true );
		$sid = (int) get_post_meta( $post->ID, '_lmgt_remote_source', true );
		if ( ! $sid ) {
			echo '<p class="description">Made on this site, not from traveltalk.dk.</p>';
		} elseif ( is_array( $c ) ) {
			$edit = LMGT_Bridge::peer() . '/wp-admin/post.php?post=' . $sid . '&action=edit';
			$re   = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_retranslate&post=' . $post->ID ), 'lmgt_retranslate_' . $post->ID );
			$ok   = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_mother_ok&post=' . $post->ID ), 'lmgt_mother_ok_' . $post->ID );
			echo '<div class="notice notice-warning inline"><p><strong>Mother text changed</strong> ' . esc_html( $c['at'] ) . ' UTC. '
				. '<a href="' . esc_url( $edit ) . '" target="_blank">See its Revisions on traveltalk.dk</a>.</p></div>';
			echo '<p><a class="button" href="' . esc_url( $re ) . '">Re-translate</a> <a class="button-link" href="' . esc_url( $ok ) . '" onclick="return confirm(\'The change does not matter for this translation?\')">Dismiss – change not relevant</a></p>';
			echo '<p class="description">Re-translate queues it on traveltalk.dk. ' . ( $post->post_status === 'publish' ? 'The new version waits here; this page stays as it is until you apply it.' : 'The new text replaces this draft.' ) . '</p>';
		} else {
			echo '<p>The Danish text is unchanged since this was translated.</p>';
		}
		$found = array();
		self::strip( $post->post_content, $found );
		if ( $found ) echo '<p class="description"><strong>Hidden on this page</strong> (Danish-only, Settings): ' . esc_html( implode( ', ', array_map( function ( $k, $n ) { return $k . ' ×' . $n; }, array_keys( $found ), $found ) ) ) . '.</p>';
	}

	public static function handle_retranslate() {
		$id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
		check_admin_referer( 'lmgt_retranslate_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$r   = LMGT_Bridge::call( 'POST', '/requeue', array( 'source_id' => (int) get_post_meta( $id, '_lmgt_remote_source', true ), 'lang' => get_post_meta( $id, '_lmgt_lang', true ) ), false );
		$msg = is_wp_error( $r ) ? 'Not queued: ' . $r->get_error_message() : 'Queued on traveltalk.dk. It runs while Translator → Queue is open there; the new version then arrives here.';
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $msg ), get_edit_post_link( $id, 'url' ) ) );
		exit;
	}

	/** The change does not matter here: take the new text as the one this translation follows. */
	public static function handle_mother_ok() {
		$id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
		check_admin_referer( 'lmgt_mother_ok_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$c = get_post_meta( $id, '_lmgt_mother_changed', true );
		if ( is_array( $c ) ) self::made_from( $id, $c['hash'] );
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( 'Dismissed. The flag returns if the Danish text changes again.' ), get_edit_post_link( $id, 'url' ) ) );
		exit;
	}

	public static function changed_count() {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key = '_lmgt_mother_changed' AND p.post_type = %s AND p.post_status <> 'trash'", LMGT_CPT ) );
	}

	public static function view_changed( $views ) {
		$n = self::changed_count();
		if ( $n ) $views['lmgt_changed'] = '<a href="' . esc_url( admin_url( 'edit.php?post_type=' . LMGT_CPT . '&lmgt_changed=1' ) ) . '"' . ( empty( $_GET['lmgt_changed'] ) ? '' : ' class="current"' ) . '>Mother text changed <span class="count">(' . $n . ')</span></a>';
		return $views;
	}

	// ---- Links (4.10) ----------------------------------------------------------

	private static function host( $url ) {
		return preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) ) );
	}

	private static function path( $url ) {
		return trim( strtolower( rawurldecode( (string) wp_parse_url( $url, PHP_URL_PATH ) ) ), '/' );
	}

	/** Source, when sending: href="/…" means this site, so it must not point into .travel. */
	public static function absolute_links( $html ) {
		$home = untrailingslashit( home_url() );
		return preg_replace( '/(href=["\'])\/(?!\/)/i', '$1' . $home . '/', (string) $html );
	}

	/** Target: [.dk path => [lang => published member ID]], from each member's .dk address (stored, and the set's current one). */
	private static function map() {
		$map = get_transient( self::MAP );
		if ( is_array( $map ) ) return $map;
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT p.ID, u.meta_value AS url, l.meta_value AS lang FROM {$wpdb->posts} p
			JOIN {$wpdb->postmeta} u ON u.post_id = p.ID AND u.meta_key = '_lmgt_remote_url'
			JOIN {$wpdb->postmeta} l ON l.post_id = p.ID AND l.meta_key = '_lmgt_lang'
			WHERE p.post_status = 'publish'" );
		update_meta_cache( 'post', wp_list_pluck( $rows, 'ID' ) );
		$map = array();
		foreach ( $rows as $r ) {
			$map[ self::path( $r->url ) ][ $r->lang ] = (int) $r->ID;
			// The original may have moved since the draft was sent; the set carries its address now.
			// The set is keyed by language; the original is its Danish member.
			$set = get_post_meta( $r->ID, '_lmgt_set', true );
			if ( ! empty( $set['members']['da'] ) ) $map[ self::path( $set['members']['da'] ) ][ $r->lang ] = (int) $r->ID;
		}
		set_transient( self::MAP, $map, DAY_IN_SECONDS );
		return $map;
	}

	/** Target: the published member in $lang of the .dk page at $url, 0 when there is none (2.2.16). */
	/**
	 * 2.5.1 (G, 7 Nov, Africa list on Botswana): older .dk texts link to the page tree's old
	 * address, /rejsemal-i-hele-verden/afrika/kenya/, which .dk sends on to /afrika/kenya/.
	 * The map knows only the new one, so such links lost their target. Try the address the
	 * old one is forwarded to.
	 */
	const OLD_BASES = array( 'rejsemal-i-hele-verden/' );

	private static function alias( $key, array $map ) {
		if ( isset( $map[ $key ] ) ) return $key;
		foreach ( self::OLD_BASES as $b ) {
			if ( strpos( $key, $b ) === 0 && isset( $map[ substr( $key, strlen( $b ) ) ] ) ) return substr( $key, strlen( $b ) );
		}
		return $key;
	}

	public static function member_of( $url, $lang ) {
		$map = self::map();
		$key = self::alias( self::path( $url ), $map );
		return isset( $map[ $key ][ $lang ] ) ? (int) $map[ $key ][ $lang ] : 0;
	}

	public static function local_links( $content ) {
		if ( ! is_singular() || ! in_the_loop() || ! is_main_query() || strpos( $content, 'href=' ) === false ) return $content;
		// .travel's own pages are in its own language (English).
		$lang = LMGT_Front::current_lang();
		$lang = $lang ? $lang : LMGT_Langs::source();
		$peer = self::host( LMGT_Bridge::peer() );
		$own  = self::host( home_url() );
		$map  = null;
		// 2.2.17 (G, 30 Oct): in a translation, a .dk link goes to the page here in its language, else
		// to the English one, else the link goes and its words stay. Readers were sent into Danish.
		// 2.14.0 (G, 13 Nov): the same on .travel's own pages, which were never covered.
		$unlink = true;
		return preg_replace_callback( '/(<a\s[^>]*>)(.*?)(<\/a>)/is', function ( $a ) use ( $lang, $peer, $own, $unlink, &$map ) {
			// A link that names its language (the family line, "Leer en …") points where it means to.
			if ( stripos( $a[1], 'hreflang=' ) !== false ) return $a[0];
			if ( ! preg_match( '/href="((?:https?:\/\/[^"#?\/]+)?\/[^"#?]*)([^"]*)"/i', $a[1], $m ) ) return $a[0];
			$host = strpos( $m[1], '/' ) === 0 ? $own : self::host( $m[1] );
			// 2.14.0: a .dk address written as if it were on this site (/rejsemal/…, copied before links were
			// made absolute) lands on the homepage here. Only Danish paths that are not a page here count.
			if ( $host === $own && ! self::danish_path( self::path( $m[1] ) ) ) return $a[0];
			if ( $host !== $own && $host !== $peer ) return $a[0];
			$key = self::path( $m[1] );
			// A picture or a file on .dk is not a page in Danish.
			if ( strpos( $key, 'wp-content/' ) === 0 ) return $a[0];
			// 2.14.0: a link to .dk's front page names the sister site on purpose.
			if ( $key === '' ) return $a[0];
			if ( $map === null ) $map = self::map();
			$key = self::alias( $key, $map );
			foreach ( array_unique( array( $lang, 'en' ) ) as $l ) {
				if ( ! empty( $map[ $key ][ $l ] ) ) return str_replace( $m[0], 'href="' . esc_url( get_permalink( $map[ $key ][ $l ] ) ) . $m[2] . '"', $a[1] ) . $a[2] . $a[3];
			}
			return $unlink ? $a[2] : $a[0];
		}, $content );
	}

	/** 2.14.0: the first segments of traveltalk.dk's Danish trees. */
	const DANISH_BASES = array( 'rejsemal', 'rejsemal-i-hele-verden', 'rejsetyper', 'rejseinteresser', 'uncategorized-da', 'europa', 'asien', 'afrika', 'amerika', 'mellemosten', 'oceanien' );

	/** 2.14.0: a path on this site that is really a .dk address – Danish base, and no page here answers to it. */
	private static function danish_path( $path ) {
		$first = strtok( $path, '/' );
		if ( ! $first || ! in_array( $first, self::DANISH_BASES, true ) ) return false;
		// 2.14.1: url_to_postid() falls back to the last part of a path, so /rejsemal/europa/frankrig/paris/
		// "found" any post called paris and the link was left alone. A page counts only if it lives at this very address.
		$id = url_to_postid( home_url( '/' . $path . '/' ) );
		return ! $id || self::path( get_permalink( $id ) ) !== $path;
	}

	// ---- Danish-only blocks (4.13) --------------------------------------------

	/** [shortcode names, link domains] from Settings. A line with a dot is a domain. */
	private static function listed() {
		$codes = array();
		$hosts = array();
		foreach ( preg_split( '/[\s,]+/', strtolower( (string) get_option( 'lmgt_danish_only', self::DANISH_ONLY ) ) ) as $l ) {
			$l = trim( $l, "[]/ \t" );
			if ( $l === '' ) continue;
			if ( strpos( $l, '.' ) !== false ) $hosts[] = preg_replace( '/^(https?:\/\/)?(www\.)?/', '', $l );
			else $codes[] = $l;
		}
		return array( $codes, $hosts );
	}

	/**
	 * Listed shortcodes go whole (enclosed text too); shortcodes this site does
	 * not have lose their tags; links to listed domains keep only their text.
	 * $found counts what went, for the edit screen.
	 */
	public static function strip( $html, &$found = array() ) {
		$found = array();
		list( $codes, $hosts ) = self::listed();
		$count = function ( $k ) use ( &$found ) { $found[ $k ] = isset( $found[ $k ] ) ? $found[ $k ] + 1 : 1; };
		if ( $codes && strpos( $html, '[' ) !== false ) {
			$html = preg_replace_callback( '/' . get_shortcode_regex( $codes ) . '/', function ( $m ) use ( $count ) {
				if ( $m[1] === '[' && $m[6] === ']' ) return $m[0];
				$count( '[' . $m[2] . ']' );
				return '';
			}, $html );
		}
		if ( strpos( $html, '[' ) !== false ) {
			$html = preg_replace_callback( '/\[\/?([a-z][a-z0-9]*_[a-z0-9_-]*)(?:\s[^\]]*)?\]/i', function ( $m ) use ( $count ) {
				if ( shortcode_exists( $m[1] ) ) return $m[0];
				if ( $m[0][1] !== '/' ) $count( '[' . $m[1] . '] (not on this site)' );
				return '';
			}, $html );
		}
		if ( $hosts && stripos( $html, '<a' ) !== false ) {
			$html = preg_replace_callback( '/<a\s[^>]*href=["\']https?:\/\/([^\/"\'?#:]+)[^>]*>(.*?)<\/a>/is', function ( $m ) use ( $hosts, $count ) {
				$h = preg_replace( '/^www\./', '', strtolower( $m[1] ) );
				foreach ( $hosts as $d ) {
					if ( $h === $d || substr( $h, -strlen( $d ) - 1 ) === '.' . $d ) {
						$count( $d . ' link' );
						return $m[2];
					}
				}
				return $m[0];
			}, $html );
		}
		return $html;
	}

	public static function danish_only( $content ) {
		if ( ! LMGT_Front::current_lang() || get_query_var( 'lmgt_lang_home' ) ) return $content;
		return self::strip( $content );
	}

	// ---- Featured image (4.15) -------------------------------------------------

	/** Source, when sending: the featured image's alt text and caption in $lang. Empty when there is none or the call fails. */
	public static function thumb_texts( $att, $lang ) {
		$in = array_filter( array(
			'alt'     => trim( (string) get_post_meta( $att, '_wp_attachment_image_alt', true ) ),
			'caption' => trim( (string) get_post_field( 'post_excerpt', $att ) ),
		), 'strlen' );
		if ( ! $in || ! LMGT_Engines::ai_available() ) return array();
		$r = LMGT_Engines::ai_json( LMGT_Engines::prompt_translate( LMGT_Langs::source(), $lang, $in ), LMGT_Engines::schema_strings( array_keys( $in ) ) );
		if ( is_wp_error( $r ) ) {
			LMGT_Bridge::log( 'image texts FAILED #' . $att . ' ' . $lang . ' ' . $r->get_error_message() );
			return array();
		}
		return array(
			'alt'     => isset( $r['alt'], $in['alt'] ) ? sanitize_text_field( $r['alt'] ) : '',
			'caption' => isset( $r['caption'], $in['caption'] ) ? wp_kses_post( $r['caption'] ) : '',
		);
	}

	/** Target: keep them per language on the attachment. $only_missing for a published page, whose reviewed texts stay. */
	public static function store_thumb_texts( $att, $lang, array $p, $only_missing = false ) {
		if ( ! $att ) return;
		foreach ( array( 'alt' => 'thumb_alt', 'caption' => 'thumb_caption' ) as $k => $in ) {
			if ( empty( $p[ $in ] ) ) continue;
			$key = '_lmgt_' . $k . '_' . $lang;
			if ( $only_missing && get_post_meta( $att, $key, true ) !== '' ) continue;
			update_post_meta( $att, $key, $k === 'alt' ? sanitize_text_field( $p[ $in ] ) : wp_kses_post( $p[ $in ] ) );
		}
	}

	/**
	 * Media Library (2.2.13): the image's alt text and caption in each language,
	 * as pages in that language show them. The image's own fields above serve
	 * the site's language; one image serves every language, so its title and
	 * file name stay as they are.
	 */
	public static function media_fields( $fields, $post ) {
		if ( strpos( (string) $post->post_mime_type, 'image/' ) !== 0 ) return $fields;
		foreach ( LMGT_Langs::all() as $code => $l ) {
			if ( $code === LMGT_Langs::source() ) continue;
			$alt = (string) get_post_meta( $post->ID, '_lmgt_alt_' . $code, true );
			$cap = (string) get_post_meta( $post->ID, '_lmgt_caption_' . $code, true );
			if ( $alt === '' && $cap === '' && ! in_array( $code, LMGT_Langs::enabled(), true ) ) continue;
			$fields[ 'lmgt_alt_' . $code ] = array( 'label' => 'Alt text (' . $l['native'] . ')', 'input' => 'text', 'value' => $alt, 'helps' => 'Shown on ' . $l['name'] . ' pages; empty = the alt text above.' );
			$fields[ 'lmgt_caption_' . $code ] = array( 'label' => 'Caption (' . $l['native'] . ')', 'input' => 'textarea', 'value' => $cap );
		}
		return $fields;
	}

	public static function media_fields_save( $post, $att ) {
		foreach ( LMGT_Langs::all() as $code => $l ) {
			foreach ( array( 'alt', 'caption' ) as $k ) {
				if ( ! isset( $att[ 'lmgt_' . $k . '_' . $code ] ) ) continue;
				$v = $k === 'alt' ? sanitize_text_field( $att[ 'lmgt_' . $k . '_' . $code ] ) : wp_kses_post( $att[ 'lmgt_' . $k . '_' . $code ] );
				$v === '' ? delete_post_meta( $post['ID'], '_lmgt_' . $k . '_' . $code ) : update_post_meta( $post['ID'], '_lmgt_' . $k . '_' . $code, $v );
			}
		}
		return $post;
	}

	public static function image_alt( $attr, $att ) {
		$lang = LMGT_Front::current_lang();
		$alt  = $lang && $att ? get_post_meta( $att->ID, '_lmgt_alt_' . $lang, true ) : '';
		if ( $alt !== '' ) $attr['alt'] = $alt;
		return $attr;
	}

	public static function image_caption( $caption, $id ) {
		$lang = LMGT_Front::current_lang();
		$c    = $lang ? get_post_meta( $id, '_lmgt_caption_' . $lang, true ) : '';
		return $c !== '' ? $c : $caption;
	}

	// ---- Glossary (4.14) -------------------------------------------------------

	/** Settings → Glossary for $to: "source term = target term" lines, as written. */
	public static function glossary( $to ) {
		$g = (array) get_option( 'lmgt_glossary', array() );
		return isset( $g[ $to ] ) ? trim( (string) $g[ $to ] ) : '';
	}

	// ---- Review list (4.18) ----------------------------------------------------

	public static function page() {
		$base = array( 'post_type' => LMGT_CPT, 'posts_per_page' => 300, 'fields' => 'ids', 'orderby' => 'modified', 'order' => 'DESC', 'lmgt_all' => true, 'no_found_rows' => true );
		$drafts = get_posts( array_merge( $base, array( 'post_status' => array( 'draft', 'pending' ) ) ) );
		$live   = get_posts( array_merge( $base, array( 'post_status' => 'publish', 'meta_query' => array( 'relation' => 'OR', array( 'key' => '_lmgt_mother_changed', 'compare' => 'EXISTS' ), array( 'key' => '_lmgt_pending', 'compare' => 'EXISTS' ) ) ) ) );
		echo '<div class="wrap"><h1>Review</h1><p>' . count( $drafts ) . ' draft(s) waiting · ' . count( $live ) . ' published translation(s) with a changed Danish text or a waiting version.</p>';
		foreach ( array( 'Drafts' => $drafts, 'Published, needs a look' => $live ) as $h => $ids ) {
			echo '<h2>' . esc_html( $h ) . '</h2>';
			if ( ! $ids ) { echo '<p>None.</p>'; continue; }
			echo '<table class="widefat striped"><thead><tr><th>Translation</th><th>Language</th><th>Flags</th><th>Words</th><th>Made with</th><th>Mother text changed</th><th>Waiting version</th><th>Original</th></tr></thead><tbody>';
			foreach ( $ids as $id ) {
				$l    = LMGT_Langs::get( get_post_meta( $id, '_lmgt_lang', true ) );
				$open = LMGT_Store::open_issues( $id );
				$c    = get_post_meta( $id, '_lmgt_mother_changed', true );
				$p    = get_post_meta( $id, '_lmgt_pending', true );
				$src  = get_post_meta( $id, '_lmgt_remote_url', true );
				if ( ! $src ) $src = get_permalink( (int) get_post_meta( $id, '_lmgt_source', true ) );
				printf( '<tr><td><a href="%s">%s</a></td><td>%s</td><td>%s</td><td>%d</td><td>%s</td><td>%s</td><td>%s</td><td><a href="%s" target="_blank">%s</a></td></tr>',
					esc_url( get_edit_post_link( $id, 'url' ) ), esc_html( get_the_title( $id ) ), esc_html( $l ? $l['name'] : '?' ),
					$open ? '<span style="color:#b32d2e">' . (int) $open . '</span>' . ( LMGT_Store::is_reviewed( $id ) ? ' (read)' : '' ) : '0',
					(int) LMGT_Store::words( $id ), esc_html( get_post_meta( $id, '_lmgt_made_with', true ) ), is_array( $c ) ? esc_html( $c['at'] ) : '', is_array( $p ) && ! empty( $p['at'] ) ? esc_html( $p['at'] ) : '',
					esc_url( $src ), esc_html( (string) wp_parse_url( $src, PHP_URL_PATH ) ) );
			}
			echo '</tbody></table>';
		}
		echo '<p class="description">Review minutes and engine cost per draft: Translator → Pilot.</p></div>';
	}
}
