<?php
/**
 * 2.7.0 (G, 8 Nov 2026): one panel at the top of the edit screen with the work in the order it is
 * done, each step with its state (✓ done, ● waiting for you, – not needed) and one clear verb.
 * The detailed boxes stay where they are; the panel says where to look and does the common step.
 *
 *   1 Check      flags from the translation check (translations only)
 *   2 Deepen     length and content gaps, sections waiting to be read
 *   3 Structure  intro and practical part, a proposed structure waiting
 *   4 Tone       passages against the house-style tone rules, rewrites waiting (2.19.5)
 *   5 SEO        focus keyword and meta description
 *   6 Links      internal links out of the text and into it, counted and listed
 *   7 Publish    "I have read the check" and the status (translations only)
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class LMGT_Steps {

	private static $pid = 0;
	private static $seen = array();

	public static function boot() {
		add_action( 'add_meta_boxes', function () {
			add_meta_box( 'lmgt_steps', 'Translator – steps', array( __CLASS__, 'panel' ), LMGT_Store::types( true ), 'normal', 'high' );
		} );
		add_action( 'admin_post_lmgt_links_refresh', array( __CLASS__, 'handle_refresh' ) );
		add_action( 'admin_post_lmgt_links_add', array( __CLASS__, 'handle_add' ) );
		add_action( 'admin_post_lmgt_links_apply', array( __CLASS__, 'handle_apply' ) );
		add_action( 'admin_post_lmgt_links_in', array( __CLASS__, 'handle_in' ) );
		add_action( 'admin_post_lmgt_links_moved', array( __CLASS__, 'handle_fix_moved' ) );
		add_action( 'admin_post_lmgt_links_in_apply', array( __CLASS__, 'handle_in_apply' ) );
		add_action( 'admin_post_lmgt_kw_suggest', array( __CLASS__, 'handle_kw_suggest' ) );
		add_action( 'admin_post_lmgt_struct_repeat', array( __CLASS__, 'handle_struct_repeat' ) ); // 2.21.0
	}

	/**
	 * 2.17.13 (G, 14 Nov: "add approved links also externally"): the sites the editor has approved for
	 * links out, one per line in Translator → Settings. Empty = the starter list for the site's subject.
	 */
	public static function ext_defaults() {
		$s = class_exists( 'LMGT_Boxes' ) ? LMGT_Boxes::subject() : 'travel';
		if ( $s === 'sport' ) return "formula1.com\nfia.com\natptour.com\nwtatennis.com\nausopen.com\nwimbledon.com\nrolandgarros.com\nusopen.org\nuefa.com\nfifa.com\nolympics.com\nnfl.com\nnba.com\nicc-cricket.com\npgatour.com";
		if ( $s === 'wine' ) return "champagne.fr\nbordeaux.com\nriojawine.com\nchianticlassico.com\nivdp.pt\nwinesofsa.co.za";
		return "visitdenmark.com\nvisitnorway.com\nvisitsweden.com\nvisitfinland.com\nitalia.it\nspain.info\nfrance.fr\nvisitportugal.com\nvisitbritain.com\nnps.gov\nparks.canada.ca\nunesco.org";
	}

	public static function ext_sites() {
		$t = (string) get_option( 'lmgt_ext_sites', '' );
		if ( trim( $t ) === '' ) $t = self::ext_defaults();
		$out = array();
		foreach ( preg_split( '/[\s,]+/', strtolower( $t ) ) as $d ) {
			$d = preg_replace( '#^https?://#', '', trim( $d ) );
			$d = preg_replace( '#^www\.|/.*$#', '', $d );
			if ( $d !== '' ) $out[] = $d;
		}
		return array_values( array_unique( $out ) );
	}

	public static function ext_max() {
		return max( 0, min( 6, (int) get_option( 'lmgt_ext_max', 3 ) ) );
	}

	/** Is the address on the approved list (the domain itself or a subdomain of it)? */
	public static function ext_listed( $url ) {
		$h = preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) ) );
		foreach ( self::ext_sites() as $d ) if ( $h === $d || substr( $h, -strlen( '.' . $d ) ) === '.' . $d ) return true;
		return false;
	}

	private static function nonce_url( $action, $id, $extra = '', $nonce = '' ) {
		return wp_nonce_url( admin_url( 'admin-post.php?action=' . $action . '&post=' . (int) $id . $extra ), $nonce !== '' ? $nonce : $action . '_' . (int) $id );
	}

	public static function row( $n, $title, $state, $text, $buttons = '' ) {
		$badge = array(
			'done' => '<span style="color:#008a20;font-weight:600">✓ done</span>',
			'wait' => '<span style="color:#b26200;font-weight:600">● waiting for you</span>',
			'todo' => '<span style="color:#b32d2e;font-weight:600">● to do</span>',
			'none' => '<span style="color:#8c8f94">– not needed</span>',
			'hand' => '<span style="color:#b26200;font-weight:600">● to do by hand</span>',
		);
		// 2.21.0 (G, 23 Nov: "you can not do anything in 1 so it adds to the confusion"): "to do" always comes with a
		// button. Where what is left can only be done in the editor, the step says "to do by hand" and the text says where.
		if ( $state === 'todo' && trim( wp_strip_all_tags( (string) $buttons ) ) === '' ) $state = 'hand';
		self::$seen[] = array( $n, $title, $state, $text, $buttons );
		$buttons = self::tidy_buttons( $state, $buttons ); // 2.18.0
		echo '<tr><td style="width:24px;font-weight:600">' . (int) $n . '</td><td style="width:110px"><strong>' . esc_html( $title ) . '</strong></td><td style="width:150px">' . $badge[ $state ] . '</td><td>' . $text . ( self::$pid ? LMGT_Stamps::line( self::$pid, $title, $state === 'wait' ) : '' ) . '</td><td class="lmgt-btns">' . $buttons . '</td></tr>';
	}

	/** 2.18.0: the Rank Math score and the keyword checks Translator can make from the saved post. */
	private static function seo_checks( $post, $kw, $md ) {
		$score = get_post_meta( $post->ID, 'rank_math_seo_score', true );
		$k     = mb_strtolower( trim( (string) strtok( $kw, ',' ) ) );
		$out   = array();
		if ( $k !== '' ) {
			$plain = mb_strtolower( LMGT_Text::plain( LMGT_Structure::without_boxes( $post->post_content ) ) );
			$first = mb_substr( $plain, 0, max( 300, (int) ( mb_strlen( $plain ) * 0.1 ) ) );
			$heads = preg_match_all( '#<h[2-4][^>]*>(.*?)</h[2-4]>#is', $post->post_content, $hm ) ? mb_strtolower( wp_strip_all_tags( implode( ' ', $hm[1] ) ) ) : '';
			$slugk = sanitize_title( $k );
			$out[] = array( mb_strpos( mb_strtolower( $post->post_title ), $k ) !== false, 'Keyword in the title', 'Change the title at the top of the editor so "' . $k . '" is in it, near the start. Then Update.' );
			$out[] = array( $md !== '' && mb_strpos( mb_strtolower( $md ), $k ) !== false, 'Keyword in the meta description', $md === '' ? 'Click Write the meta description on the right.' : 'Click the Rank Math button (its score) at the top right of the editor → Edit Snippet → Description, and use "' . $k . '" in it. Translator never changes a description you have written.' );
			$out[] = array( mb_strpos( $first, $k ) !== false, 'Keyword in the first 10% of the text', 'Use "' . $k . '" in the first paragraph, in the editor. Then Update.' );
			$out[] = array( $heads !== '' && mb_strpos( $heads, $k ) !== false, 'Keyword in a subheading', 'Use "' . $k . '" in one section heading (H2 or H3), in the editor. Then Update.' );
			$out[] = array( $slugk !== '' && strpos( (string) $post->post_name, $slugk ) !== false, 'Keyword in the address', $post->post_status === 'publish' ? 'Leave it: the page is published and Google knows its address. Not worth a changed address.' : 'Click the Rank Math button (its score) at the top right of the editor → Edit Snippet → Permalink, and put "' . $slugk . '" in it.' );
		}
		$ml = mb_strlen( $md );
		if ( $md !== '' ) $out[] = array( $ml >= 120 && $ml <= 160, 'Meta description 120–160 characters', 'It has ' . $ml . '. Click the Rank Math button (its score) at the top right of the editor → Edit Snippet → Description, and ' . ( $ml < 120 ? 'add a few words' : 'shorten it' ) . '.' );
		$bad = array_filter( $out, function ( $c ) { return ! $c[0]; } );
		$h   = '';
		if ( $score !== '' && $score !== false ) {
			$s   = (int) $score;
			$col = $s >= 81 ? '#008a20' : ( $s >= 51 ? '#b26200' : '#b32d2e' );
			$h  .= '<div style="margin-top:6px">Rank Math score: <strong style="color:' . $col . '">' . $s . '/100</strong>' . ( $s >= 81 ? ' (green)' : ' – aim for 81 or more (green)' ) . '.</div>';
		} else {
			$h .= '<div style="margin-top:6px" class="description">Rank Math score: not yet worked out. Press Update once.</div>';
		}
		if ( $out ) {
			$h .= '<ul style="margin:4px 0 0 0;list-style:none">';
			foreach ( $out as $c ) $h .= '<li>' . ( $c[0] ? '<span style="color:#008a20">✓</span> ' . esc_html( $c[1] ) : '<span style="color:#b32d2e">✗</span> ' . esc_html( $c[1] ) . ' <span class="description">– ' . esc_html( $c[2] ) . '</span>' ) . '</li>';
			$h .= '</ul>';
			if ( $bad ) $h .= '<p class="description" style="margin:4px 0 0">These are changed by hand: each ✗ says where. Press Update afterwards; the score here then follows Rank Math\'s.</p>';
		}
		return array( 'html' => $h, 'ok' => ! $bad );
	}

	/**
	 * 2.18.0 (G, 22 Nov: "the interaction is messy … good design leads to better using"): one main button per
	 * step. A waiting step keeps Accept and Reject side by side; otherwise the main button stays and the rest
	 * go under "More".
	 */
	private static function tidy_buttons( $state, $buttons ) {
		if ( $state === 'wait' || ! preg_match_all( '#<a\b[^>]*>.*?</a>#s', (string) $buttons, $m ) || count( $m[0] ) < 2 ) return $buttons;
		$all  = $m[0];
		$main = 0;
		foreach ( $all as $i => $a ) if ( preg_match( '#class="[^"]*button-primary#', $a ) ) { $main = $i; break; }
		$first = $all[ $main ];
		unset( $all[ $main ] );
		return $first . '<details class="lmgt-more"><summary>More</summary><div>' . implode( ' ', $all ) . '</div></details>';
	}

	private static function btn( $url, $label, $primary = false ) {
		return '<a class="button' . ( $primary ? ' button-primary' : '' ) . '" href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a> ';
	}

	/** 2.21.0: the steps, then every other Translator box as a section of the same panel. */
	public static function panel( $post ) {
		self::box( $post );
		if ( current_user_can( 'edit_post', $post->ID ) ) LMGT_Admin::sections_html( $post );
	}

	public static function box( $post ) {
		if ( ! current_user_can( 'edit_post', $post->ID ) ) return;
		$id   = $post->ID;
		$tr   = $post->post_type === LMGT_CPT;
		self::$pid = $id;
		$ai   = LMGT_Engines::ai_available();
		self::$seen = array();
		ob_start();
		echo '<p class="description" style="margin-top:12px">All steps, in order. <strong>● to do</strong> has a button on the right: click it once and wait for the green "Done" bar. <strong>● waiting for you</strong>: read the proposal, then Accept or Reject. <strong>● to do by hand</strong>: the text says what to change in the editor. <strong>–</strong> not needed: nothing to do.</p>';
		echo '<style>#lmgt-steps-table{table-layout:auto;width:100%;max-width:100%}#lmgt-steps-table>tbody>tr>td{overflow-wrap:break-word;word-break:normal;vertical-align:top}#lmgt-steps-table>tbody>tr>td:nth-child(1){width:24px}#lmgt-steps-table>tbody>tr>td:nth-child(2){width:90px}#lmgt-steps-table>tbody>tr>td:nth-child(3){width:130px}#lmgt-steps-table>tbody>tr>td:nth-child(4){min-width:260px}#lmgt-steps-table td.lmgt-btns{width:auto;min-width:150px;max-width:260px;text-align:right;white-space:normal}#lmgt-steps-table td.lmgt-btns .button{white-space:normal;height:auto;min-height:30px;line-height:1.4;padding-top:4px;padding-bottom:4px;margin:0 0 6px 6px;max-width:100%;text-align:center}#lmgt-steps-table td table{width:100%;max-width:100%;table-layout:auto}#lmgt-steps-table td table td,#lmgt-steps-table td table th{overflow-wrap:break-word;word-break:normal;white-space:normal}@media(max-width:1100px){#lmgt-steps-table>tbody>tr>td:nth-child(4){min-width:200px}}#lmgt_steps .inside{container-type:inline-size;overflow-x:hidden}#lmgt-steps-table .lmgt-more{margin-top:6px}#lmgt-steps-table .lmgt-more summary{cursor:pointer;color:#2271b1;list-style:none;font-size:13px;text-align:right}#lmgt-steps-table .lmgt-more summary::-webkit-details-marker{display:none}#lmgt-steps-table .lmgt-more summary:after{content:" ▾"}#lmgt-steps-table .lmgt-more[open] summary:after{content:" ▴"}#lmgt-steps-table .lmgt-more>div{margin-top:6px}@container (max-width:700px){#lmgt-steps-table,#lmgt-steps-table>tbody,#lmgt-steps-table>tbody>tr{display:block;width:100%}#lmgt-steps-table>tbody>tr>td{display:block;width:auto!important;min-width:0!important;max-width:none!important;padding:2px 10px}#lmgt-steps-table>tbody>tr>td:nth-child(1),#lmgt-steps-table>tbody>tr>td:nth-child(2),#lmgt-steps-table>tbody>tr>td:nth-child(3){display:inline-block}#lmgt-steps-table>tbody>tr{padding:8px 0;border-bottom:1px solid #dcdcde}#lmgt-steps-table td.lmgt-btns{text-align:left}#lmgt-steps-table td.lmgt-btns .button{margin:0 6px 6px 0}#lmgt-steps-table .lmgt-more summary{text-align:left}}</style>';
		echo '<table id="lmgt-steps-table" class="widefat striped" style="border:0"><tbody>';
		$n = 0;

		// 0 Goal (2.19.0): originals and a site's own posts, not translations.
		if ( ! $tr && class_exists( 'LMGT_Goals' ) ) {
			$n++;
			LMGT_Goals::row( $n, $post, self::links( $post ) );
		}

		// 1 Check
		if ( $tr ) {
			$n++;
			$p     = get_post_meta( $id, '_lmgt_pending', true );
			$flags = LMGT_Store::open_issues( $id );
			if ( is_array( $p ) && ! empty( $p['translation'] ) ) {
				self::row( $n, 'Check', 'wait', 'A ' . ( isset( $p['kind'] ) && $p['kind'] === 'fix' ? 'corrected' : 'new' ) . ' version is waiting.',
					self::btn( self::nonce_url( 'lmgt_apply', $id ), 'Accept: put it in the text', true ) . self::btn( self::nonce_url( 'lmgt_discard', $id ), 'Reject: keep my text' ) );
			} elseif ( $flags ) {
				// 2.17.4: number flags have their own button; Fix only handles meaning.
				$nums = LMGT_Store::open_numbers( $id );
				$txt  = (int) $flags . ' flag(s) – listed under "Translation check"' . ( $nums ? ' (' . (int) $nums . ' of them number(s) that differ from the original: check them in the text)' : '' ) . '.';
				$b    = ( $ai && $flags > $nums ? self::btn( self::nonce_url( 'lmgt_fix', $id ), 'Fix the flags', true ) : '' ) . ( $nums ? self::btn( self::nonce_url( 'lmgt_numbers_ok', $id ), 'Numbers are right – clear', $flags === $nums ) : '' );
				self::row( $n, 'Check', 'todo', $txt, $b );
			} else {
				self::row( $n, 'Check', 'done', 'No flags.' );
			}
		}

		// 2 Deepen
		$n++;
		$words = LMGT_Store::words( $post );
		$min   = LMGT_Store::min_words( $id );
		$draft = get_post_meta( $id, '_lmgt_gap_draft', true );
		$g     = get_post_meta( $id, '_lmgt_gaps', true );
		$len   = (int) $words . ' words (minimum ' . (int) $min . ').';
		$why   = $words < $min ? ' <strong>Too short.</strong> Click <em>Find content gaps</em>: Claude suggests sections the subject should have; you tick the ones to write, read them, and add the ones you want. About a minute.' : ' Long enough. <span class="description">Optional: <em>Find content gaps</em> (under More) suggests sections that would make it more complete.</span>';
		if ( LMGT_Store::as_written( $id ) ) {
			self::row( $n, 'Deepen', 'none', 'News: kept as written.' );
		} elseif ( is_array( $draft ) && ! empty( $draft['sections'] ) ) {
			self::row( $n, 'Deepen', 'wait', count( $draft['sections'] ) . ' new section(s) written. Click <em>Go to the sections</em>, read each one, tick the ones you want and add them. Nothing is in the text until you do.', '<a class="button button-primary" href="#lmgt-gd-anchor" onclick="var e=document.querySelector(\'[form=lmgt-gd]\');if(e){e.scrollIntoView({behavior:\'smooth\',block:\'center\'});return false}">Go to the sections</a>' );
		} elseif ( is_array( $g ) && ! empty( $g['gaps'] ) ) {
			self::row( $n, 'Deepen', 'wait', $len . ' ' . count( $g['gaps'] ) . ' suggestion(s) for missing sections. Click <em>Go to the suggestions</em>, tick the ones worth writing, and let Claude write them; you read them before they go in.', '<a class="button button-primary" href="#" onclick="var e=document.querySelector(\'[form=lmgt-gp]\');if(e){e.scrollIntoView({behavior:\'smooth\',block:\'center\'})}return false">Go to the suggestions</a>' );
		} else {
			$t10 = class_exists( 'LMGT_Goals' ) && LMGT_Goals::get( $id ) === 'top10';
			self::row( $n, 'Deepen', $words < $min || ( $t10 && empty( $g['top10'] ) ) ? 'todo' : 'none', $len . $why . ( $t10 ? ( empty( $g['top10'] ) ? ' <strong>Goal Top 10:</strong> click <em>Compare with the top 10</em> to see what the pages now in Google\'s top 10 cover that this text does not.' : ' Compared with the top 10: nothing missing.' ) : '' ),
				$ai ? ( $t10 ? self::btn( self::nonce_url( 'lmgt_gaps', $id, '&top10=1' ), 'Compare with the top 10', empty( $g['top10'] ) ) : '' ) . self::btn( self::nonce_url( 'lmgt_gaps', $id ), 'Find content gaps', $words < $min && ! $t10 ) : '' );
		}

		// 3 Structure
		$n++;
		if ( LMGT_Store::as_written( $id ) ) {
			self::row( $n, 'Structure', 'none', 'News: kept as written.' );
		} else {
			$pend = get_post_meta( $id, '_lmgt_structure', true );
			$c    = LMGT_Structure::check( $post );
			$base = admin_url( 'admin-post.php?action=lmgt_structure_apply&post=' . $id );
			if ( is_array( $pend ) && ! empty( $pend['content'] ) ) {
				self::row( $n, 'Structure', 'wait', 'A new structure is waiting.', self::btn( wp_nonce_url( $base . '&do=apply', 'lmgt_structure_' . $id ), 'Accept: put it in the text', true ) . self::btn( wp_nonce_url( $base . '&do=drop', 'lmgt_structure_' . $id ), 'Reject: keep my text' ) );
			} else {
				// 2.21.0 (G, 23 Nov): each problem in words a newcomer can act on, with where it is fixed.
				$bad = array();
				$iw  = isset( $c['intro_words'] ) ? (int) $c['intro_words'] : 0;
				$fix = $ai ? ' <em>Propose the structure</em> fixes this.' : ' Fix it in the editor.';
				if ( $c['intro'] === 'missing' ) $bad[] = '<strong>No intro.</strong> The text starts straight with a section heading; readers and Google need 2 to 4 sentences first that say what the page is about.' . $fix;
				elseif ( $c['intro'] === 'short' ) $bad[] = '<strong>Intro too short</strong> (' . $iw . ' words before the first section heading; 25 to 250 is right).' . $fix;
				elseif ( $c['intro'] === 'long' ) $bad[] = '<strong>Intro too long</strong> (' . $iw . ' words before the first section heading; 25 to 250 is right). The first section heading should come sooner.' . $fix;
				if ( $c['practical'] === 'missing' ) $bad[] = '<strong>No practical part.</strong> A travel text needs a section near the end on getting there, when to go, where to stay or prices.' . ( $ai ? ' <em>Propose the structure</em> writes one from facts already in the text.' : '' );
				elseif ( $c['practical'] === 'middle' ) $bad[] = '<strong>The practical part is in the middle</strong>' . ( ! empty( $c['practical_at'] ) ? ' (the section "' . esc_html( $c['practical_at'] ) . '")' : '' ) . '. Readers look for it near the end.' . ( $ai ? ' <em>Propose the structure</em> moves it there; the wording stays the same.' : ' Move that section to the end in the editor.' );
				if ( ! empty( $c['repeat'] ) ) $bad[] = '<strong>A section heading repeats the title</strong> ("' . esc_html( $c['repeat'][0] ) . '"). Click <em>Remove the repeated heading</em>; the text under it stays.';
				if ( ! empty( $c['shortcodes'] ) ) { $sc = $c['shortcodes'][0]; $bad[] = '<strong>A shortcode is broken:</strong> [' . esc_html( $sc[0] ) . '] opens ' . (int) $sc[1] . ' time(s) and closes ' . (int) $sc[2] . ' time(s), so part of the page may show as raw text. In the editor, open the ⋮ menu at the top right → Code editor, search for [' . esc_html( $sc[0] ) . ' and add or remove the missing [/' . esc_html( $sc[0] ) . '].'; }
				$can = ( $c['intro'] !== 'ok' || $c['practical'] !== 'ok' ) && $ai;
				$rb  = ! empty( $c['repeat'] ) ? self::btn( self::nonce_url( 'lmgt_struct_repeat', $id ), 'Remove the repeated heading', ! $can ) : '';
				$ok  = ! empty( $c['kept'] ) ? 'Checked by Claude: nothing to move, kept as it is.' : 'Intro and practical part in place.';
				if ( strpos( $post->post_content, '<!-- lmgt:toc -->' ) !== false ) $ok .= ' <span class="description">After moving sections, update the table of contents in step 1.</span>';
				self::row( $n, 'Structure', $bad ? 'todo' : 'done', $bad ? implode( '<br>', $bad ) . ( $can ? '<br><span class="description">Claude proposes; nothing changes until you click Accept. About a minute.</span>' : '' ) : $ok, ( $can ? self::btn( wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_structure&post=' . $id ), 'lmgt_structure_' . $id ), 'Propose the structure', true ) : '' ) . $rb );
			}
		}

		// Tone (2.19.5): after Structure. Advice only, never in blocking().
		if ( class_exists( 'LMGT_Tone' ) ) {
			$n++;
			LMGT_Tone::step_row( $n, $post );
		}

		// 4 SEO
		$n++;
		$kw = trim( (string) get_post_meta( $id, 'rank_math_focus_keyword', true ) );
		$md = trim( (string) get_post_meta( $id, 'rank_math_description', true ) );
		$seo_txt = 'Keyword: ' . ( $kw !== '' ? '<strong>' . esc_html( $kw ) . '</strong>' : '<em>none</em>' ) . ' · Meta: ' . ( $md !== '' ? (int) mb_strlen( $md ) . ' characters' : '<em>none</em>' ) . '.';
		// 2.17.13 (G, 14 Nov): extra keywords help when the text mentions them. Advice only – never written to Rank Math.
		$ks = get_post_meta( $id, '_lmgt_kw_suggest', true );
		if ( is_array( $ks ) && ! empty( $ks['list'] ) ) {
			$have = array_map( function ( $k ) { return mb_strtolower( trim( $k ) ); }, explode( ',', $kw ) );
			$left = array_values( array_filter( $ks['list'], function ( $k ) use ( $have ) { return ! in_array( mb_strtolower( $k ), $have, true ); } ) );
			if ( $left ) $seo_txt .= '<div style="margin-top:6px">Extra keywords you could add (all in the text): <strong>' . implode( '</strong> · <strong>', array_map( 'esc_html', $left ) ) . '</strong><br><span class="description">Add the ones you want after your main keyword in Rank Math → Focus Keyword. Translator never adds them.</span></div>';
		}
		$kbtn = $ai && $kw !== '' ? self::btn( self::nonce_url( 'lmgt_kw_suggest', $id ), 'Suggest extra keywords' ) : '';
		// 2.18.0 (G, 22 Nov: "one addition would be optimizing the SEO score"): Rank Math's score and the checks
		// behind it that Translator can read, each with what to do. Rank Math works the score out when you press Update.
		$sc = self::seo_checks( $post, $kw, $md );
		$seo_txt .= $sc['html'];
		$mbtn = ! $tr && $ai && $kw !== '' && $md === '' ? self::btn( self::nonce_url( 'lmgt_seo', $id, '&only=meta' ), 'Write the meta description', true ) : '';
		// 2.21.0: an original with no focus keyword gets one proposed (with a meta description when it has none); what is set is never changed.
		if ( ! $tr && $ai && $kw === '' ) { $mbtn = self::btn( self::nonce_url( 'lmgt_seo', $id ), 'Set the focus keyword', true ); $seo_txt .= '<div style="margin-top:6px"><span style="color:#b32d2e">✗</span> <strong>No focus keyword.</strong> <span class="description">Click Set the focus keyword: Claude picks the main search word (for a country page, the country\'s name) and puts it in Rank Math' . ( $md === '' ? ', with a meta description' : '' ) . '. Change it in Rank Math afterwards if you want another.</span></div>'; }
		self::row( $n, 'SEO', $kw !== '' && $md !== '' && $sc['ok'] ? 'done' : 'todo', $seo_txt, $mbtn . ( $tr && $ai ? self::btn( self::nonce_url( 'lmgt_seo', $id ), $kw !== '' || $md !== '' ? 'Set SEO again' : 'Set SEO', $kw === '' || $md === '' ) : '' ) . $kbtn );

		// 5 Links
		$n++;
		$l = self::links( $post );
		$need_in = $l['in'] < 2;
		$txt = '<strong>' . count( $l['out'] ) . '</strong> link(s) out to this site' . self::fam_text( $l ) . ' · <strong>' . (int) $l['in'] . '</strong> page(s) link here' . ( ! empty( $l['ext'] ) ? ' · <strong>' . (int) $l['ext'] . '</strong> external' : '' ) . ( $l['at'] ? ' <span class="description">(counted ' . esc_html( $l['at'] ) . ' UTC)</span>' : '' ) . '.';
		// 2.17.21 (G, 19 Nov, Rome: "three dot links, but the Links step tells another story"): map links are added when the page is shown, so they are named apart.
		$ml = get_post_meta( $id, '_lmgt_map_links', true );
		if ( is_array( $ml ) && ! empty( $ml['links'] ) ) { $nm = count( array_filter( $ml['links'], function ( $x ) { return ! empty( $x[0] ); } ) ); if ( $nm ) $txt .= ' Plus <strong>' . $nm . '</strong> from the map dots (shown to readers, not counted here).'; }
		$txt .= self::link_lists( $l );
		$unc = count( array_filter( (array) $l['out'], function ( $o ) { return ! empty( $o['unchecked'] ); } ) );
		if ( $unc ) $txt .= ' <span class="description">' . (int) $unc . ' new link(s) not checked yet: click <em>Count again</em> to check that they work.</span>';
		$lp = get_post_meta( $id, '_lmgt_links_pending', true );
		if ( is_array( $lp ) && ! empty( $lp['list'] ) ) {
			// 2.17.13: tick the links you want; only those go in.
			$li = '<ul style="list-style:none;margin-left:0">';
			foreach ( $lp['list'] as $i => $x ) {
				$note = '';
				if ( $x['kind'] === 'external' ) $note = ! empty( $x['listed'] ) ? ' <span class="description">(external · on your list · the page answers)</span>' : ' <span class="description" style="color:#996800">(external · not on your list – your call · the page answers)</span>';
				$li .= '<li><label><input type="checkbox" class="lmgt-linkpick" value="' . (int) $i . '" checked> "' . esc_html( $x['phrase'] ) . '"</label> → <a href="' . esc_url( $x['url'] ) . '" target="_blank">' . esc_html( $x['url'] ) . '</a>' . $note . '</li>';
			}
			$li .= '</ul>';
			$acc  = self::nonce_url( 'lmgt_links_apply', $id, '&do=apply' );
			$js   = '<script>(function(){document.addEventListener("change",function(e){if(!e.target.classList||!e.target.classList.contains("lmgt-linkpick"))return;var p=[].slice.call(document.querySelectorAll(".lmgt-linkpick"));var on=p.filter(function(x){return x.checked}).map(function(x){return x.value});[].forEach.call(document.querySelectorAll(".lmgt-linkacc"),function(b){var base=b.getAttribute("data-base");b.href=on.length<p.length?base+"&only="+(on.length?on.join("-"):"none"):base;b.textContent=on.length?"Accept: put the "+on.length+" ticked in the text":"Tick at least one link";});});})();</script>';
			self::row( $n, 'Links', 'wait', count( $lp['list'] ) . ' link(s) proposed in your existing sentences. Untick the ones you do not want:' . $li . $js, '<a class="button button-primary lmgt-linkacc" data-base="' . esc_url( $acc ) . '" href="' . esc_url( $acc ) . '">Accept: put the ticked in the text</a> ' . self::btn( self::nonce_url( 'lmgt_links_apply', $id, '&do=drop' ), 'Reject' ) );
		} elseif ( is_array( $lip = get_post_meta( $id, '_lmgt_links_in_pending', true ) ) && ! empty( $lip['list'] ) ) {
			// 2.17.21: links from other pages to this one, waiting.
			$li = '<ul style="list-style:none;margin-left:0">';
			foreach ( $lip['list'] as $i => $x ) $li .= '<li><label><input type="checkbox" class="lmgt-inpick" value="' . (int) $i . '" checked> In <a href="' . esc_url( get_edit_post_link( $x['src'] ) ) . '" target="_blank">' . esc_html( $x['title'] ) . '</a>: "' . esc_html( $x['phrase'] ) . '" → this page</label></li>';
			$li .= '</ul>';
			$acc = self::nonce_url( 'lmgt_links_in_apply', $id, '&do=apply' );
			$js  = '<script>(function(){document.addEventListener("change",function(e){if(!e.target.classList||!e.target.classList.contains("lmgt-inpick"))return;var p=[].slice.call(document.querySelectorAll(".lmgt-inpick"));var on=p.filter(function(x){return x.checked}).map(function(x){return x.value});[].forEach.call(document.querySelectorAll(".lmgt-inacc"),function(b){var base=b.getAttribute("data-base");b.href=on.length<p.length?base+"&only="+(on.length?on.join("-"):"none"):base;b.textContent=on.length?"Accept: put the "+on.length+" ticked in those pages":"Tick at least one link";});});})();</script>';
			self::row( $n, 'Links', 'wait', count( $lip['list'] ) . ' other page(s) can link to this one, in sentences they already have. Untick the ones you do not want:' . $li . $js, '<a class="button button-primary lmgt-inacc" data-base="' . esc_url( $acc ) . '" href="' . esc_url( $acc ) . '">Accept: put the ticked in those pages</a> ' . self::btn( self::nonce_url( 'lmgt_links_in_apply', $id, '&do=drop' ), 'Reject' ) );
		} else {
			// 2.17.21 (G, 19 Nov: "links accepted, still to do – make the communication very easy and clear"): say which half is missing.
			$out_ok = count( $l['out'] ) + (int) $l['peer'] >= 2;
			$pub    = $post->post_status === 'publish';
			$what   = $out_ok && ! $need_in ? '<strong>Done:</strong> links out and links in are in place.<br>'
				: ( ! $out_ok ? '<strong>To do: links out.</strong> This text links to fewer than 2 of our pages. Click <em>Propose links</em>.<br>' : '' )
				. ( $need_in ? ( $pub ? '<strong>To do: links in.</strong> Only ' . (int) $l['in'] . ' other page(s) on this site link to this one; 2 or more help readers and Google find it. Click <em>Propose links to this page</em>.<br>' : '<strong>Links in:</strong> counted once the page is published.<br>' ) : '' );
			$state  = $out_ok && ( ! $need_in || ! $pub ) ? 'done' : 'todo';
			self::row( $n, 'Links', $state, $what . $txt, ( $ai ? self::btn( self::nonce_url( 'lmgt_links_add', $id ), 'Propose links', ! $out_ok ) : '' ) . ( $ai && $need_in && $pub ? self::btn( self::nonce_url( 'lmgt_links_in', $id ), 'Propose links to this page', $out_ok ) : '' ) . self::btn( self::nonce_url( 'lmgt_links_refresh', $id ), 'Count again' ) );
		}

		// 6 Boxes (2.9.0)
		$n++;
		LMGT_Boxes::step_row( $n, $post );

		// 7 Publish
		if ( $tr ) {
			$n++;
			$flags = LMGT_Store::open_issues( $id );
			$pub   = $post->post_status === 'publish';
			// 2.17.18 (Travel 360 3c): headline and intro approved = ready; flags and open steps are advice.
			if ( $pub ) self::row( $n, 'Publish', 'done', 'Published.' );
			elseif ( ! LMGT_Focus::intro_ok( $id ) ) self::row( $n, 'Publish', 'wait', 'Approve the headline and intro in "Translation: what to do now" (Yes/No), spot-check the rest.' );
			else self::row( $n, 'Publish', 'wait', 'Ready: press Publish in "Translation: what to do now"' . ( $flags ? ' (' . (int) $flags . ' flag(s) open – you may publish despite them)' : '' ) . '.' );
		}
		echo '</tbody></table>';
		$table = ob_get_clean();
		echo self::next_line(); // 2.10.0
		echo self::all_bar( $id );
		echo $table;
		echo LMGT_Stamps::history_html( $id ); // 2.17.2
	}

	/**
	 * 2.17.23 (G, 20 Nov: "+500 texts to translate … efficient process, with the admin able to change, overrule, go back"):
	 * "Prepare all" runs every open step's proposal in order (Structure, Links, links to this page, Know before you go,
	 * facts, map), each as its own request, so no single click runs into the host's time limit. Nothing changes in the
	 * text. "Accept all" then puts every waiting proposal in, in the same order, with the ticks as they stand; anything
	 * can still be rejected or changed one by one first, and every step keeps the old text under Revisions.
	 */
	private static function all_bar( $id ) {
		$edit = get_edit_post_link( $id, 'url' );
		return '<div id="lmgt-all" style="margin:10px 0;padding:10px 12px;background:#f0f6fc;border:1px solid #c5d9ed;border-radius:4px">'
			. '<button type="button" class="button button-primary" id="lmgt-prep-all">Prepare all</button> '
			. '<button type="button" class="button" id="lmgt-acc-all">Accept all waiting</button> '
			. '<span class="description" style="margin-left:6px">Prepare all: Claude proposes every open step in turn (a few minutes on a long text; the text does not change). Read the proposals below, untick or reject what you do not want, then Accept all waiting.</span></div>'
			. "<script>(function(){function init(){var T=document.getElementById('lmgt-steps-table');if(!T)return;"
			. "var PROP=['lmgt_gaps','lmgt_structure','lmgt_tone','lmgt_links_add','lmgt_links_in','lmgt_faq_propose','lmgt_facts_propose','lmgt_map_propose'];"
			. "var ACC=['lmgt_structure_apply','lmgt_tone_apply','lmgt_links_apply','lmgt_links_in_apply','lmgt_faq_apply','lmgt_facts_apply','lmgt_map_apply'];"
			. "function act(h){var m=h.match(/[?&]action=([a-z_]+)/);return m?m[1]:''}"
			. "function rows(st){return [].slice.call(T.querySelectorAll('tr')).filter(function(r){var c=r.children[2];return c&&c.textContent.indexOf(st)>-1})}var NM={lmgt_gaps:'Content gaps',lmgt_structure:'Structure',lmgt_structure_apply:'Structure',lmgt_tone:'Tone',lmgt_tone_apply:'Tone',lmgt_links_add:'Links',lmgt_links_apply:'Links',lmgt_links_in:'Links to this page',lmgt_links_in_apply:'Links to this page',lmgt_faq_propose:'Know before you go',lmgt_faq_apply:'Know before you go',lmgt_facts_propose:'Fact box',lmgt_facts_apply:'Fact box',lmgt_map_propose:'Map',lmgt_map_apply:'Map'};function nm(r,a){var x=act(a.href);return NM[x]||x}"
			. "function prep(){var L=[];rows('to do').forEach(function(r){[].forEach.call(r.querySelectorAll('a.button'),function(a){var x=act(a.href);if(PROP.indexOf(x)>-1&&!/again/i.test(a.textContent)&&!L.some(function(y){return act(y[1])===x}))L.push([nm(r,a),a.href,PROP.indexOf(x)])})});L.sort(function(a,b){return a[2]-b[2]});return L}"
			. "function acc(){var L=[];rows('waiting for you').forEach(function(r){[].forEach.call(r.querySelectorAll('a.button-primary'),function(a){var x=act(a.href);if(ACC.indexOf(x)>-1&&/do=apply/.test(a.href)&&!/only=none/.test(a.href))L.push([nm(r,a),a.href+(x==='lmgt_links_apply'?'&chain=1':''),ACC.indexOf(x)])})});L.sort(function(a,b){return a[2]-b[2]});return L}"
			. "function dirty(){try{if(window.wp&&wp.data&&wp.data.select('core/editor'))return wp.data.select('core/editor').isEditedPostDirty()}catch(x){}try{var as=window.wp&&wp.autosave&&wp.autosave.server;if(as&&as.postChanged){if(as.postChanged())return true}else if(window.tinymce&&tinymce.activeEditor&&tinymce.activeEditor.isDirty())return true}catch(x){}return !!window.lmgtDirty}"
			. "function bar(t){var d=document.getElementById('lmgt-busy');if(!d){d=document.createElement('div');d.id='lmgt-busy';document.body.appendChild(d)}d.innerHTML='<span class=\"spinner is-active\" style=\"float:none;margin:0 8px 0 0;vertical-align:middle\"></span>'+t;var P=document.getElementById('lmgt-prog');if(!P){P=document.createElement('div');P.id='lmgt-prog';P.style.cssText='margin-top:10px;padding:10px 12px;background:#1d2327;color:#fff;border-radius:4px;font-size:14px';document.getElementById('lmgt-all').appendChild(P)}P.innerHTML=d.innerHTML}var EST={'Content gaps':40,Structure:60,Tone:50,Links:45,'Links to this page':40,'Know before you go':50,'Fact box':45,Map:55};function est(n){return EST[n]||45}function fmt(s){s=Math.max(0,Math.round(s));return s>=60?Math.floor(s/60)+' min '+(s%60<10?'0':'')+(s%60)+' s':s+' s'}function lock(on){[].forEach.call(document.querySelectorAll('#lmgt-all button,#lmgt-steps-table a.button,a[href*=\"action=lmgt_\"]'),function(b){b.classList[on?'add':'remove']('lmgt-locked')});var pb=document.getElementById('lmgt-prep-all'),ab=document.getElementById('lmgt-acc-all');if(on){if(pb)pb.textContent='Working…';if(ab)ab.disabled=true;if(pb)pb.disabled=true}}"
			. "function msg(u){try{var q=new URL(u).searchParams;return q.get('lmgt_msg')||q.get('lmgt_smsg')||''}catch(x){return ''}}"
			. "function run(L,verb){if(!L.length){alert(verb==='prep'?'Nothing to prepare: no step is \"to do\" with a proposal button.':'Nothing waiting to accept.');return}"
			. "if(dirty()&&!confirm('You have unsaved changes in the editor. Cancel, press Update, then try again. OK: go on; unsaved changes are lost.'))return;"
			. "lock(true);window.onbeforeunload=function(){return 'Translator is still working.'};var out=[],i=0,t0=Date.now(),ts=0,tick=null;function show(){var it=L[i];if(!it)return;var el=(Date.now()-ts)/1000,left=est(it[0])-el;for(var k=i+1;k<L.length;k++)left+=est(L[k][0]);var all=0;for(k=0;k<L.length;k++)all+=est(L[k][0]);var pct=Math.min(98,Math.round(100*((Date.now()-t0)/1000)/Math.max(1,all)));var over=el>est(it[0]);bar('<strong>Step '+(i+1)+' of '+L.length+': '+it[0].replace(/[<>&]/g,'')+'</strong> · '+(verb==='prep'?'Claude is writing the proposal':'putting it in')+'<br>'+(over?'Taking longer than usual ('+fmt(el)+' on this step). Still working – do not close or reload.':'About '+fmt(left<5?5:left)+' left · '+fmt((Date.now()-t0)/1000)+' so far. Do not close or reload this page.')+'<div style=\"margin-top:8px;height:6px;background:#3c434a;border-radius:3px\"><div style=\"height:6px;width:'+pct+'%;background:#72aee6;border-radius:3px;transition:width 1s\"></div></div>')}function next(){if(i>=L.length){clearInterval(tick);window.onbeforeunload=null;bar('<strong>✓ Done: '+L.length+' step(s) in '+fmt((Date.now()-t0)/1000)+'.</strong> Reloading to show the proposals…');var u=new URL(" . wp_json_encode( $edit ) . ");u.searchParams.set('lmgt_msg',(verb==='prep'?'Prepared: ':'Accepted: ')+out.join(' · '));location.href=u.toString();return}"
			. "var it=L[i];ts=Date.now();clearInterval(tick);show();tick=setInterval(show,1000);fetch(it[1],{credentials:'same-origin',redirect:'follow'}).then(function(r){var m=msg(r.url);if(!m)m=verb==='acc'&&/admin-post\\.php/.test(r.url)?'not done (the text was edited since: open this step on its own)':'no result shown: open this step on its own';out.push(it[0]+': '+m);i++;next()}).catch(function(){out.push(it[0]+': no answer – try this step on its own');i++;next()})}next()}"
			. "document.getElementById('lmgt-prep-all').addEventListener('click',function(){run(prep(),'prep')});"
			. "document.getElementById('lmgt-acc-all').addEventListener('click',function(){var L=acc();if(L.length&&!confirm('Put '+L.length+' waiting proposal(s) in the text, in this order: '+L.map(function(x){return x[0]}).join(', ')+'? The previous version stays under Revisions.'))return;run(L,'acc')});"
			. "}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init()})();</script>";
	}

	/**
	 * 2.17.16 (G, 16 Nov: "we need a stricter procedure"): the steps that must be settled before a
	 * translation is published. Check, Structure, SEO and Links may not be "to do"; nothing may be
	 * "waiting for you". Deepen is advice only (better done on the Danish original).
	 */
	public static function blocking( array $rows ) {
		$out = array();
		foreach ( $rows as $r ) {
			if ( $r[1] === 'Publish' || $r[1] === 'Deepen' ) continue; // 2.17.17: Deepen is advice, also when its suggestions wait
			if ( $r[1] === 'Tone' ) continue; // 2.19.5: Tone is advice, never holds up publishing
			if ( $r[2] === 'wait' || ( ( $r[2] === 'todo' || $r[2] === 'hand' ) && in_array( $r[1], array( 'Check', 'Structure', 'SEO', 'Links' ), true ) ) ) $out[] = $r;
		}
		return $out;
	}

	public static function names( array $rows ) {
		return implode( ', ', array_map( function ( $r ) { return 'step ' . (int) $r[0] . ' ' . $r[1]; }, $rows ) );
	}

	/** The open steps of a translation, worked out the same way as the steps panel. */
	public static function open_steps( $post ) {
		ob_start();
		self::box( $post );
		ob_end_clean();
		return self::blocking( (array) self::$seen );
	}

	/** 2.10.0 (G, 9 Nov: "can do it easily"): the one thing to do now, with its button. Waiting for you beats to do; the order is the order of the steps. */
	private static function next_line() {
		$pick = null;
		foreach ( array( 'wait', 'todo', 'hand' ) as $want ) {
			foreach ( self::$seen as $r ) if ( $r[2] === $want ) { $pick = $r; break 2; }
		}
		if ( ! $pick ) {
			return '<div style="background:#edfaef;border:2px solid #00a32a;border-radius:6px;padding:12px 16px;margin:4px 0 0"><strong style="font-size:15px">✓ All steps done.</strong> Nothing is waiting for you on this one.</div>';
		}
		$txt = preg_replace( '#<(ol|ul|table|details)\b.*$#is', '', $pick[3] );
		$txt = trim( wp_strip_all_tags( $txt ) );
		// 2.21.0: name the first open check (✗) of the step, so the line says what the button is for.
		if ( preg_match( '#✗</span>\s*(?:<strong>)?(.*?)(?:</strong>|<br>|</li>| <span)#s', $pick[3], $xm ) ) $txt .= ( $txt !== '' ? ' · first: ' : '' ) . trim( wp_strip_all_tags( $xm[1] ) );
		if ( mb_strlen( $txt ) > 220 ) $txt = mb_substr( $txt, 0, 217 ) . '…';
		$what = $pick[2] === 'wait' ? 'Waiting for you' : ( $pick[2] === 'hand' ? 'To do by hand, in the editor' : 'To do' );
		$btn  = trim( $pick[4] ) !== '' ? '<div style="margin-top:10px">' . $pick[4] . '</div>' : '';
		$more = $pick[2] === 'wait' ? '<p class="description" style="margin:8px 0 0">Read what is proposed in step ' . (int) $pick[0] . ' below, then Accept or Reject.</p>'
			: ( $pick[2] === 'hand' ? '<p class="description" style="margin:8px 0 0">No button can do this one: step ' . (int) $pick[0] . ' below says what to change and where. Press Update afterwards.</p>' : '<p class="description" style="margin:8px 0 0">Click the button, wait for the green "Done" bar, and the next step shows here. Step ' . (int) $pick[0] . ' below says more.</p>' );
		return '<div style="background:#fff8e5;border:2px solid #dba617;border-radius:6px;padding:12px 16px;margin:4px 0 0"><div style="font-size:12px;text-transform:uppercase;letter-spacing:.05em;color:#8a6d00">Next · ' . esc_html( $what ) . '</div>'
			. '<div style="font-size:16px;margin-top:2px"><strong>' . (int) $pick[0] . ' ' . esc_html( $pick[1] ) . ':</strong> ' . esc_html( $txt ) . '</div>' . $btn . $more . '</div>';
	}

	// ---- Links ----------------------------------------------------------------------

	/** Internal links out of the text (this site and the sister site) and pages on this site linking in. Cached 6 hours. */
	public static function links( $post, $fresh = false ) {
		$key = 'lmgt_links_' . $post->ID;
		$c   = $fresh ? false : get_transient( $key );
		if ( is_array( $c ) && isset( $c['v'], $c['fam'], $c['ext'], $c['r'] ) && $c['v'] === md5( $post->post_content ) ) return $c;
		// 2.19.4 (G, 22 Nov: blank screen after Update): when the article page is shown, links are never looked up over the
		// network; earlier answers are reused, and links not yet checked are checked by "Count again" (or in the background).
		$prev = array();
		$old  = get_transient( $key );
		if ( is_array( $old ) && ! empty( $old['out'] ) ) foreach ( (array) $old['out'] as $o ) if ( empty( $o['unchecked'] ) ) $prev[ $o['url'] ] = $o;
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		$peer = class_exists( 'LMGT_Bridge' ) && LMGT_Bridge::peer() ? wp_parse_url( LMGT_Bridge::peer(), PHP_URL_HOST ) : '';
		$strip = function ( $h ) { return preg_replace( '/^www\./', '', (string) $h ); };
		$out = array();
		$np  = 0;
		$ext = 0;
		// 2.17.3 (G, 14 Nov): links to all four sites count – traveltalk.dk, traveltalk.travel, winetalk.dk, worldsporttalk.com.
		$fam = array( 'traveltalk.dk' => 0, 'traveltalk.travel' => 0, 'winetalk.dk' => 0, 'worldsporttalk.com' => 0 );
		$moves_left = $fresh ? 6 : 0;
		preg_match_all( '/<a\s[^>]*href=["\']([^"\'#]+)["\']/i', $post->post_content, $m );
		foreach ( array_unique( $m[1] ) as $u ) {
			$h = wp_parse_url( $u, PHP_URL_HOST );
			if ( strpos( $u, '/wp-content/' ) !== false ) continue;
			if ( ! $h || $strip( $h ) === $strip( $host ) ) {
				if ( isset( $prev[ $u ] ) ) { $out[] = $prev[ $u ]; continue; }
				$k = $moves_left;
				$o = self::resolve( $u, $moves_left );
				if ( empty( $o['ok'] ) && ! $fresh && $k === 0 ) $o['unchecked'] = true;
				$out[] = $o;
			} elseif ( isset( $fam[ $strip( $h ) ] ) ) {
				$fam[ $strip( $h ) ]++;
				$np++;
			} elseif ( $peer && $strip( $h ) === $strip( $peer ) ) {
				$np++;
			} elseif ( preg_match( '#^https?://#i', $u ) ) {
				$ext++; // 2.17.13: links out to other sites
			}
		}
		$in   = array();
		$path = untrailingslashit( (string) wp_parse_url( get_permalink( $post ), PHP_URL_PATH ) );
		if ( $path !== '' && $post->post_status === 'publish' ) {
			global $wpdb;
			$like = '%' . $wpdb->esc_like( $path . '/' ) . '%';
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_title FROM {$wpdb->posts} WHERE post_status = 'publish' AND ID <> %d AND post_type IN ('post','page','" . esc_sql( LMGT_CPT ) . "') AND post_content LIKE %s LIMIT 60", $post->ID, $like ) );
			foreach ( $rows as $r ) $in[] = array( 'id' => (int) $r->ID, 'title' => html_entity_decode( $r->post_title, ENT_QUOTES, 'UTF-8' ) );
		}
		unset( $fam[ $strip( $host ) ] );
		$c = array( 'r' => 2, 'v' => md5( $post->post_content ), 'out' => $out, 'peer' => $np, 'fam' => array_filter( $fam ), 'ext' => $ext, 'in' => count( $in ), 'in_list' => $in, 'at' => current_time( 'mysql', true ) );
		set_transient( $key, $c, 6 * HOUR_IN_SECONDS );
		return $c;
	}

	/**
	 * 2.17.24 (G, 20 Nov: "links that are active are rejected"): an internal link is fine when it reaches a page, a post,
	 * a translation or a category/tag page – also where a page and a category share an address (/rejseinteresser/vinrejser/),
	 * which WordPress's own lookup misses. A link that answers through a redirect is "moved", with its new address.
	 * Only "not found" is a real dead link. At most $left addresses are asked over the network per count.
	 */
	private static function resolve( $u, &$left ) {
		$pid = url_to_postid( $u );
		if ( $pid ) return array( 'url' => $u, 'title' => html_entity_decode( get_the_title( $pid ), ENT_QUOTES, 'UTF-8' ), 'ok' => true );
		$path = trim( (string) wp_parse_url( $u, PHP_URL_PATH ), '/' );
		if ( $path === '' ) return array( 'url' => $u, 'title' => 'Front page', 'ok' => true );
		$p = get_page_by_path( $path, OBJECT, array( 'page', 'post', LMGT_CPT ) );
		if ( $p && $p->post_status === 'publish' ) return array( 'url' => $u, 'title' => html_entity_decode( get_the_title( $p ), ENT_QUOTES, 'UTF-8' ), 'ok' => true );
		$slug = basename( $path );
		foreach ( array( 'category', 'post_tag' ) as $tax ) {
			$t = get_term_by( 'slug', $slug, $tax );
			if ( $t && untrailingslashit( (string) get_term_link( $t ) ) === untrailingslashit( home_url( '/' . $path ) ) ) return array( 'url' => $u, 'title' => $t->name . ' (category page)', 'ok' => true );
		}
		if ( $left > 0 ) {
			$left--;
			$abs = preg_match( '#^https?://#i', $u ) ? $u : home_url( '/' . $path . '/' );
			$r   = wp_remote_head( $abs, array( 'timeout' => 6, 'redirection' => 0 ) );
			$c   = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
			if ( $c >= 200 && $c < 300 ) return array( 'url' => $u, 'title' => $u, 'ok' => true );
			if ( $c >= 300 && $c < 400 ) {
				$to = (string) wp_remote_retrieve_header( $r, 'location' );
				if ( $to !== '' ) {
					if ( $to[0] === '/' ) $to = home_url( $to );
					$n = $left; $t = self::resolve( $to, $n ); $left = $n;
					if ( ! empty( $t['ok'] ) ) return array( 'url' => $u, 'title' => $t['title'], 'ok' => true, 'moved' => $to );
				}
			}
		}
		return array( 'url' => $u, 'title' => $u, 'ok' => false );
	}

	/** 2.17.24: links that go through a redirect are pointed straight at their new address. Nothing else changes. */
	public static function handle_fix_moved() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_links_moved_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$back = get_edit_post_link( $id, 'url' );
		$post = get_post( $id );
		$l    = self::links( $post, true );
		$html = $post->post_content;
		$n    = 0;
		foreach ( $l['out'] as $o ) {
			if ( empty( $o['moved'] ) ) continue;
			$q    = preg_quote( $o['url'], '#' );
			$html = preg_replace( '#(<a\s[^>]*href=["\'])' . $q . '(["\'])#i', '${1}' . esc_url( $o['moved'] ) . '${2}', $html, -1, $k );
			$n   += $k;
		}
		if ( ! $n ) self::back( $back, 'No moved links to point at their new address.' );
		LMGT_Store::update_content( $id, array( 'post_content' => $html ) );
		delete_transient( 'lmgt_links_' . $id );
		self::back( $back, $n . ' link(s) now go straight to their new address. The previous version is under Revisions.' );
	}

	/** 2.17.3: ", 9 to traveltalk.dk, 2 to winetalk.dk" – each of the four sites by name. */
	private static function fam_text( array $l ) {
		if ( ! empty( $l['fam'] ) ) {
			$p = array();
			foreach ( $l['fam'] as $site => $k ) $p[] = (int) $k . ' to ' . $site;
			return ', ' . implode( ', ', $p );
		}
		return ! empty( $l['peer'] ) ? ', ' . (int) $l['peer'] . ' to the sister site' : '';
	}

	private static function link_lists( array $l ) {
		$h = '<details style="margin-top:4px"><summary>Show the links</summary><div style="display:flex;gap:24px;flex-wrap:wrap"><div><strong>Out</strong><ul style="list-style:disc;margin-left:18px">';
		foreach ( $l['out'] as $o ) $h .= '<li>' . ( $o['ok'] ? '' : ( ! empty( $o['unchecked'] ) ? '<span style="color:#996800">not checked yet: </span>' : '<span style="color:#b32d2e">not found: </span>' ) ) . '<a href="' . esc_url( $o['url'] ) . '" target="_blank">' . esc_html( $o['title'] ) . '</a>' . ( ! empty( $o['moved'] ) ? ' <span style="color:#996800">(moved: works through a redirect to ' . esc_html( $o['moved'] ) . ')</span>' : '' ) . '</li>';
		$mv = count( array_filter( $l['out'], function ( $o ) { return ! empty( $o['moved'] ); } ) );
		if ( $mv && self::$pid ) $h .= '<li style="list-style:none"><a class="button" href="' . esc_url( self::nonce_url( 'lmgt_links_moved', self::$pid ) ) . '">Point ' . (int) $mv . ' moved link(s) at the new address</a></li>';
		if ( ! $l['out'] ) $h .= '<li><em>none</em></li>';
		$h .= '</ul></div><div><strong>In</strong><ul style="list-style:disc;margin-left:18px">';
		foreach ( $l['in_list'] as $i ) $h .= '<li><a href="' . esc_url( get_edit_post_link( $i['id'] ) ) . '">' . esc_html( $i['title'] ) . '</a></li>';
		if ( ! $l['in_list'] ) $h .= '<li><em>none' . '</em></li>';
		$h .= '</ul><p class="description">Links written in the text only. Menus, grids, map dots and the Read more block are not counted.</p></div></div></details>';
		return $h;
	}

	/**
	 * 2.7.3 (G, 9 Nov: "Add internal links", "Link out to external resources"): links put into
	 * sentences the text already has. Internal links only to the site's own articles in the same
	 * language; external ones only to official or primary sources, and only if the page answers.
	 * Nothing changes until Accept.
	 */
	public static function handle_add() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_links_add_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$post = get_post( $id );
		$back = get_edit_post_link( $id, 'url' );
		$lang = $post->post_type === LMGT_CPT ? (string) get_post_meta( $id, '_lmgt_lang', true ) : LMGT_Langs::source();
		$cand = LMGT_Admin::link_candidates( $post, $lang );
		$a    = LMGT_Langs::get( $lang );
		$subj = class_exists( 'LMGT_Boxes' ) ? LMGT_Boxes::subject() : 'travel';
		$off  = array(
			'travel' => 'a national park authority, a tourist board, a government page',
			'wine'   => 'a wine region\'s official body, an appellation or consortium, the producer\'s own site',
			'sport'  => 'the governing body, the official event or league site, official results and standings',
		);
		$max  = self::ext_max();
		// 2.19.0: a supporting post always gets a link up to its pillar proposed.
		$pil  = class_exists( 'LMGT_Goals' ) && LMGT_Goals::get( $id ) === 'support' ? LMGT_Goals::pillar_of( $id ) : 0;
		$must = '';
		if ( $pil && get_post( $pil ) && ! LMGT_Goals::links_to( $post->post_content, $pil ) ) {
			$cand = array( get_the_title( $pil ) => get_permalink( $pil ) ) + $cand;
			$must = '0. First and required: one internal link to PILLAR ' . get_permalink( $pil ) . ' (' . get_the_title( $pil ) . '), the main page on this subject, from a phrase that names its subject.\n';
		}
		$prompt = "ARTICLE is a {$a['name']} {$subj} article. Propose links to put into sentences it already has.\n" . $must
			. "1. internal: 3 to 6 links, only to addresses in LINKS, where a reader would want to read on. phrase: 2 to 6 words copied exactly from ARTICLE (same letters and case), in running text, not in a heading, never in the first two sentences of ARTICLE, and only where the linked page is about what that sentence is about.\n"
			. "2. external: at most {$max} links to official or primary sources that back a fact in ARTICLE ({$off[ $subj ]}). Prefer pages on the APPROVED sites; another site only if it is the official or primary source. Only addresses you are certain exist, as specific as you are sure of; none is better than a guess. Never a booking site, a betting site, a shop or a blog. phrase as above.\n"
			. "APPROVED: " . implode( ', ', self::ext_sites() ) . "\n"
			. "Each phrase used once. Return JSON: {\"links\":[{\"phrase\":\"…\",\"url\":\"…\",\"kind\":\"internal|external\"}]}.\n\n"
			. "LINKS:\n" . implode( "\n", array_map( function ( $t, $u ) { return $t . ' | ' . $u; }, array_keys( $cand ), $cand ) ) . "\n\nARTICLE:\n" . mb_substr( LMGT_Text::plain( $post->post_content ), 0, 30000 );
		@set_time_limit( 200 );
		$r = LMGT_Engines::ai_json( $prompt );
		if ( is_wp_error( $r ) ) self::back( $back, $r->get_error_message() );
		$ok   = array_map( 'untrailingslashit', array_values( $cand ) );
		$html = $post->post_content;
		$plain0 = LMGT_Text::plain( $html );
		$list = array();
		$next = 0;
		foreach ( (array) ( isset( $r['links'] ) ? $r['links'] : array() ) as $x ) {
			if ( empty( $x['phrase'] ) || empty( $x['url'] ) ) continue;
			$url  = esc_url_raw( (string) $x['url'] );
			$kind = isset( $x['kind'] ) && $x['kind'] === 'external' ? 'external' : 'internal';
			if ( $kind === 'internal' && ! in_array( untrailingslashit( $url ), $ok, true ) ) continue;
			if ( $kind === 'external' ) {
				if ( $next >= $max ) continue;
				$h = wp_remote_head( $url, array( 'timeout' => 8, 'redirection' => 3 ) );
				$c = is_wp_error( $h ) ? 0 : (int) wp_remote_retrieve_response_code( $h );
				if ( $c < 200 || $c >= 400 ) continue;
			}
			// 2.17.25 (G, 20 Nov): no link in the opening words of a text.
			$at0 = mb_strpos( $plain0, (string) $x['phrase'] );
			if ( $at0 !== false && $at0 < 200 ) continue;
			$new = self::wrap_once( $html, (string) $x['phrase'], $url, $kind );
			if ( $new === null ) continue;
			$html   = $new;
			if ( $kind === 'external' ) $next++;
			$list[] = array( 'phrase' => (string) $x['phrase'], 'url' => $url, 'kind' => $kind, 'listed' => $kind === 'external' && self::ext_listed( $url ) );
		}
		if ( ! $list ) self::back( $back, 'No links could be placed: the suggestions did not match the text or the pages did not answer. Nothing changed.' );
		update_post_meta( $id, '_lmgt_links_pending', wp_slash( array( 'content' => $html, 'list' => $list, 'at' => current_time( 'mysql', true ) ) ) );
		self::back( $back, count( $list ) . ' link(s) proposed. Read them in step 5 and press Accept to put them in.' );
	}

	/** The first occurrence of $phrase in running text (not in a tag, a heading or an existing link) becomes a link. */
	private static function wrap_once( $html, $phrase, $url, $kind ) {
		$parts = preg_split( '/(<[^>]+>)/', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
		$in_a  = 0;
		$in_h  = 0;
		foreach ( $parts as $i => $p ) {
			if ( $p !== '' && $p[0] === '<' ) {
				if ( preg_match( '#^<a[\s>]#i', $p ) ) $in_a++;
				elseif ( preg_match( '#^</a>#i', $p ) ) $in_a = max( 0, $in_a - 1 );
				elseif ( preg_match( '#^<h[1-6][\s>]#i', $p ) ) $in_h++;
				elseif ( preg_match( '#^</h[1-6]>#i', $p ) ) $in_h = max( 0, $in_h - 1 );
				continue;
			}
			if ( $in_a || $in_h ) continue;
			$at = strpos( $p, $phrase );
			if ( $at === false ) continue;
			$attr = $kind === 'external' ? ' target="_blank" rel="noopener"' : '';
			$parts[ $i ] = substr( $p, 0, $at ) . '<a href="' . esc_url( $url ) . '"' . $attr . '>' . $phrase . '</a>' . substr( $p, $at + strlen( $phrase ) );
			return implode( '', $parts );
		}
		return null;
	}

	public static function handle_apply() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_links_apply_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$back = get_edit_post_link( $id, 'url' );
		$p    = get_post_meta( $id, '_lmgt_links_pending', true );
		if ( ! isset( $_GET['do'] ) || $_GET['do'] !== 'apply' || ! is_array( $p ) ) { delete_post_meta( $id, '_lmgt_links_pending' ); self::back( $back, 'Proposed links rejected. The text is unchanged.' ); }
		// 2.17.23: in "Accept all" the structure goes in first; the links are then found again in the new text, so the guard is not needed.
		if ( empty( $_GET['chain'] ) && LMGT_Stamps::edited_since( $id, '_lmgt_links_pending', $p['at'] ) ) { delete_post_meta( $id, '_lmgt_links_pending' ); self::back( $back, 'Not put in: the text was edited after the links were proposed. Press Propose links again.' ); }
		// 2.17.13: only the ticked links, built again on the text as it is – the text they were proposed on.
		$pick = array_keys( $p['list'] );
		if ( isset( $_GET['only'] ) ) $pick = array_map( 'intval', array_filter( explode( '-', (string) $_GET['only'] ), 'is_numeric' ) );
		$html = get_post( $id )->post_content;
		$done = 0;
		foreach ( $pick as $i ) {
			if ( ! isset( $p['list'][ $i ] ) ) continue;
			$x   = $p['list'][ $i ];
			$new = self::wrap_once( $html, $x['phrase'], $x['url'], $x['kind'] );
			if ( $new === null ) continue;
			$html = $new;
			$done++;
		}
		delete_post_meta( $id, '_lmgt_links_pending' );
		if ( ! $done ) self::back( $back, 'No links put in: none was ticked. The text is unchanged.' );
		LMGT_Store::update_content( $id, array( 'post_content' => $html ) );
		delete_transient( 'lmgt_links_' . $id );
		self::back( $back, $done . ' link(s) put in the text. The previous version is under Revisions.' );
	}

	/**
	 * 2.17.21 (G, 19 Nov, Road trip gennem det centrale Europa: "0 pages link here"): links TO this page from
	 * other published pages in the same language – the ones sharing a category with it, and its country or
	 * region page – each in a sentence that page already has. Nothing changes until Accept; each page keeps
	 * its old version under Revisions.
	 */
	private static function in_candidates( $post, $lang ) {
		$have = wp_list_pluck( (array) self::links( $post )['in_list'], 'id' );
		$ids  = array();
		$cats = wp_get_post_categories( $post->ID );
		$src  = $post->post_type === LMGT_CPT ? (int) get_post_meta( $post->ID, '_lmgt_source', true ) : 0;
		if ( ! $cats && $src ) $cats = wp_get_post_categories( $src );
		if ( $cats ) {
			$args = array( 'post_status' => 'publish', 'posts_per_page' => 20, 'fields' => 'ids', 'post__not_in' => array_merge( array( $post->ID ), $have ), 'no_found_rows' => true, 'orderby' => 'modified' );
			$ids  = $post->post_type === LMGT_CPT ? array() : get_posts( $args + array( 'post_type' => 'post', 'category__in' => $cats ) );
			if ( $post->post_type === LMGT_CPT && $src ) {
				// A translation: the translations of the original's category neighbours, in the same language.
				foreach ( get_posts( $args + array( 'post_type' => 'post', 'category__in' => $cats, 'post__not_in' => array( $src ) ) ) as $sid ) {
					$t = LMGT_Store::of( $sid, array( 'publish' ) );
					if ( ! empty( $t[ $lang ] ) && ! in_array( (int) $t[ $lang ], $have, true ) ) $ids[] = (int) $t[ $lang ];
				}
			}
		}
		if ( class_exists( 'LMGT_Structure' ) ) {
			$c = LMGT_Structure::cluster( $post->ID );
			foreach ( array( 'place', 'region' ) as $k ) if ( ! empty( $c[ $k ][1] ) ) { $pid = url_to_postid( $c[ $k ][1] ); if ( $pid && ! in_array( $pid, $have, true ) ) array_unshift( $ids, $pid ); }
		}
		// 2.21.0: a page with no category (a pillar is often a page) – the posts that name its focus keyword.
		if ( count( $ids ) < 4 && $post->post_type !== LMGT_CPT ) {
			$kw = trim( (string) strtok( (string) get_post_meta( $post->ID, 'rank_math_focus_keyword', true ), ',' ) );
			if ( $kw === '' ) $kw = html_entity_decode( $post->post_title, ENT_QUOTES, 'UTF-8' );
			$ids = array_merge( $ids, get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 12, 'fields' => 'ids', 'no_found_rows' => true, 's' => $kw, 'orderby' => 'relevance', 'post__not_in' => array_merge( array( $post->ID ), $have ) ) ) );
		}
		// 2.21.0: a pillar's own supporting posts come first; a supporting post's pillar comes first.
		if ( class_exists( 'LMGT_Goals' ) && $post->post_type !== LMGT_CPT ) {
			$g = LMGT_Goals::get( $post->ID );
			$first = $g === 'pillar' ? LMGT_Goals::supporters( $post->ID ) : ( $g === 'support' && LMGT_Goals::pillar_of( $post->ID ) ? array( LMGT_Goals::pillar_of( $post->ID ) ) : array() );
			$first = array_filter( array_map( 'intval', $first ), function ( $f ) use ( $have ) { return get_post_status( $f ) === 'publish' && ! in_array( $f, $have, true ); } );
			$ids = array_merge( $first, $ids );
		}
		return array_slice( array_values( array_unique( array_map( 'intval', $ids ) ) ), 0, 8 );
	}

	public static function handle_in() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_links_in_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$post = get_post( $id );
		$back = get_edit_post_link( $id, 'url' );
		$lang = $post->post_type === LMGT_CPT ? (string) get_post_meta( $id, '_lmgt_lang', true ) : LMGT_Langs::source();
		$a    = LMGT_Langs::get( $lang );
		$ids  = array_filter( self::in_candidates( $post, $lang ), function ( $c ) { return current_user_can( 'edit_post', $c ); } );
		if ( ! $ids ) self::back( $back, 'No page found that could link here: none shares a category with this one, or they all link here already. Add a category, or link to it by hand from a related page.' );
		$pages = '';
		foreach ( $ids as $c ) $pages .= "\n\n=== PAGE {$c}: " . html_entity_decode( get_the_title( $c ), ENT_QUOTES, 'UTF-8' ) . " ===\n" . mb_substr( LMGT_Text::plain( get_post_field( 'post_content', $c ) ), 0, 5000 );
		$prompt = "TARGET is a {$a['name']} article titled \"" . html_entity_decode( $post->post_title, ENT_QUOTES, 'UTF-8' ) . "\". Its start:\n" . mb_substr( LMGT_Text::plain( $post->post_content ), 0, 1200 ) . "\n\n"
			. "Below are other PAGES of the same site. For each PAGE where a reader would naturally want to read TARGET next, pick one phrase of 2 to 6 words, copied exactly from that PAGE (same letters and case), in running text, not a heading, that fits as a link to TARGET. Skip a PAGE where nothing fits; a forced link is worse than none. At most one phrase per PAGE.\n"
			. "Return JSON: {\"links\":[{\"page\":123,\"phrase\":\"…\"}]}." . $pages;
		@set_time_limit( 200 );
		$r = LMGT_Engines::ai_json( $prompt );
		if ( is_wp_error( $r ) ) self::back( $back, $r->get_error_message() );
		$url  = get_permalink( $id );
		$list = array();
		foreach ( (array) ( isset( $r['links'] ) ? $r['links'] : array() ) as $x ) {
			$src = isset( $x['page'] ) ? (int) $x['page'] : 0;
			if ( ! in_array( $src, $ids, true ) || empty( $x['phrase'] ) ) continue;
			$html = (string) get_post_field( 'post_content', $src );
			if ( self::wrap_once( $html, (string) $x['phrase'], $url, 'internal' ) === null ) continue;
			$list[] = array( 'src' => $src, 'title' => html_entity_decode( get_the_title( $src ), ENT_QUOTES, 'UTF-8' ), 'phrase' => (string) $x['phrase'], 'v' => md5( $html ) );
		}
		if ( ! $list ) self::back( $back, 'Looked at ' . count( $ids ) . ' related page(s); none had a sentence where a link to this page fits. Nothing changed.' );
		update_post_meta( $id, '_lmgt_links_in_pending', wp_slash( array( 'list' => $list, 'at' => current_time( 'mysql', true ) ) ) );
		self::back( $back, count( $list ) . ' page(s) can link here. Read them in the Links step and press Accept.' );
	}

	public static function handle_in_apply() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_links_in_apply_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$back = get_edit_post_link( $id, 'url' );
		$p    = get_post_meta( $id, '_lmgt_links_in_pending', true );
		delete_post_meta( $id, '_lmgt_links_in_pending' );
		if ( ! isset( $_GET['do'] ) || $_GET['do'] !== 'apply' || ! is_array( $p ) ) self::back( $back, 'Rejected. No page was changed.' );
		$pick = array_keys( $p['list'] );
		if ( isset( $_GET['only'] ) ) $pick = array_map( 'intval', array_filter( explode( '-', (string) $_GET['only'] ), 'is_numeric' ) );
		$url  = get_permalink( $id );
		$done = array(); $skip = array();
		foreach ( $pick as $i ) {
			if ( ! isset( $p['list'][ $i ] ) ) continue;
			$x = $p['list'][ $i ];
			if ( ! current_user_can( 'edit_post', $x['src'] ) ) continue;
			$html = (string) get_post_field( 'post_content', $x['src'] );
			// A page edited since the proposal is left alone.
			if ( md5( $html ) !== $x['v'] ) { $skip[] = $x['title']; continue; }
			$new = self::wrap_once( $html, $x['phrase'], $url, 'internal' );
			if ( $new === null ) { $skip[] = $x['title']; continue; }
			LMGT_Store::update_content( $x['src'], array( 'post_content' => $new ) );
			delete_transient( 'lmgt_links_' . $x['src'] );
			$done[] = $x['title'];
		}
		delete_transient( 'lmgt_links_' . $id );
		$msg = $done ? count( $done ) . ' page(s) now link here: ' . implode( '; ', $done ) . '. Their previous versions are under Revisions.' : 'No page was changed.';
		if ( $skip ) $msg .= ' Left alone (edited since, or the sentence changed): ' . implode( '; ', $skip ) . '.';
		self::back( $back, $msg );
	}

	/** 2.17.13: up to five extra keywords that the text already mentions. Stored as advice; Rank Math is not touched. */
	public static function handle_kw_suggest() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_kw_suggest_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$post  = get_post( $id );
		$back  = get_edit_post_link( $id, 'url' );
		$kw    = trim( (string) get_post_meta( $id, 'rank_math_focus_keyword', true ) );
		$main  = trim( explode( ',', $kw )[0] );
		$plain = LMGT_Text::plain( $post->post_title . "\n" . $post->post_content );
		$prompt = "MAIN is the focus keyword of ARTICLE. Suggest up to 5 extra keywords: things people search for that ARTICLE is genuinely about (places, people, events, teams, wines) and that support MAIN. "
			. "Each must appear word for word in ARTICLE, 1 to 4 words, no sentence. Not MAIN itself. Return JSON: {\"keywords\":[\"…\"]}.\n\nMAIN: " . $main . "\n\nARTICLE:\n" . mb_substr( $plain, 0, 30000 );
		@set_time_limit( 120 );
		$r = LMGT_Engines::ai_json( $prompt );
		if ( is_wp_error( $r ) ) self::back( $back, $r->get_error_message() );
		$low  = mb_strtolower( $plain );
		$list = array();
		foreach ( (array) ( isset( $r['keywords'] ) ? $r['keywords'] : array() ) as $k ) {
			$k = trim( sanitize_text_field( (string) $k ) );
			if ( $k === '' || mb_strlen( $k ) > 60 || mb_strtolower( $k ) === mb_strtolower( $main ) || mb_strpos( $low, mb_strtolower( $k ) ) === false ) continue;
			$list[] = $k;
		}
		$list = array_slice( array_values( array_unique( $list ) ), 0, 5 );
		if ( ! $list ) self::back( $back, 'No extra keywords found that the text mentions. Nothing changed.' );
		update_post_meta( $id, '_lmgt_kw_suggest', array( 'list' => $list, 'at' => current_time( 'mysql', true ) ) );
		self::back( $back, count( $list ) . ' extra keyword(s) suggested under SEO. Add the ones you want in Rank Math; Translator does not.' );
	}

	private static function back( $url, $msg ) {
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $msg ), $url ) );
		exit;
	}

	/** 2.21.0: a section heading that only repeats the title is taken out; the text under it stays. */
	public static function handle_struct_repeat() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_struct_repeat_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$back = get_edit_post_link( $id, 'url' );
		$post = get_post( $id );
		$c    = LMGT_Structure::check( $post );
		if ( empty( $c['repeat'] ) ) self::back( $back, 'No heading repeats the title. Nothing changed.' );
		$html = $post->post_content;
		$n    = 0;
		foreach ( array_unique( $c['repeat'] ) as $t ) {
			if ( ! preg_match_all( '#(?:<!-- wp:heading[^>]*-->\s*)?<h([1-6])[^>]*>(.*?)</h\1>(?:\s*<!-- /wp:heading -->)?\s*#is', $html, $m, PREG_OFFSET_CAPTURE | PREG_SET_ORDER ) ) continue;
			foreach ( array_reverse( $m ) as $x ) {
				if ( trim( html_entity_decode( wp_strip_all_tags( $x[2][0] ), ENT_QUOTES, 'UTF-8' ) ) !== $t ) continue;
				$html = substr( $html, 0, $x[0][1] ) . substr( $html, $x[0][1] + strlen( $x[0][0] ) );
				$n++;
			}
		}
		if ( ! $n ) self::back( $back, 'The repeated heading could not be found exactly. Delete it by hand in the editor.' );
		LMGT_Store::update_content( $id, array( 'post_content' => $html ) );
		self::back( $back, $n . ' heading(s) that repeated the title taken out; the text under them is kept. The previous version is under Revisions.' );
	}

	public static function handle_refresh() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_links_refresh_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$l = self::links( get_post( $id ), true );
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( count( $l['out'] ) . ' link(s) out, ' . $l['in'] . ' page(s) linking in.' ), get_edit_post_link( $id, 'url' ) ) );
		exit;
	}
}
