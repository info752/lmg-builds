# LMG Translator

Proprietary — © Leisure Media Group Ltd. Replaces "Traveltalk AI Translator" 6.1.0.

Translates a site's own articles into other languages as separate pages with
their own addresses (`/sv/<slug>/`, `/no/<slug>/` …), each with correct
hreflang, canonical and page language. Runs on any site in the group; the
source language is the site's own (Danish on traveltalk.dk).

## Why the old plugin mixed languages

1. When DeepL and Gemini both failed, it saved the Danish original as the translation.
2. It asked DeepL for `NO`, which does not exist (Norwegian is `NB`), so every Norwegian run fell through to the fallback.
3. The fallback model, `gemini-1.5-flash`, has been retired by Google, so the fallback failed too and fault 1 took over.
4. It checked the headline for errors but not the body, so a run could save a new headline over an old or broken body.
5. Bulk ran 50 articles × 8 languages × 2 calls in one page load. That outran both PHP's time limit and DeepL Free's 500,000 characters a month.

Google also got no value from it. Translations lived at `?lang=` addresses whose canonical pointed at the Danish page. All nine hreflang tags were printed on every page, translated or not, and the page still said `lang="da-DK"`.

## How this one works

- **Translations are their own post type** (`lmgt_translation`), so they never appear in Danish archives, feeds, search or Aianna's sources. Trashing a translation cannot touch an original.
- **Hand-written translations that already exist as ordinary posts** are tagged, not moved. On the post: Translations box → "Is this post a translation?" → language + original. The post keeps its status, address and content. It leaves the source-language listings (front page, archives, categories, feeds, search, post grids) but stays in the Rank Math sitemap, and it joins the original's hreflang set. The language is checked against the text before tagging. "Remove language tag" undoes it.
- **Pipeline per article and language, one engine call per step:** prepare → translate (DeepL; Gemini once DeepL's allowance is used up) → polish (Gemini) → check → back-translate into the source language → compare → save as **draft**.
- **AI engine: Gemini or Claude** (Settings → AI engine). The chosen one does every step marked Gemini above. Claude uses its own key or, if empty, the LeisureIntel key on the site; default model `claude-haiku-5-5` (2.1.3; 2.1.0–2.1.2 defaulted to `claude-opus-5-5`). The review box names the engine and model that wrote each draft.
- **Nothing is saved on failure.** Each failure gives its reason in the queue:
  - the body is in the wrong language (word-marker check)
  - the title or body is in the wrong language (Gemini's verdict)
  - a block or shortcode marker was lost
  - an engine error
  - the original was edited while the job ran
- **The check report sits on each draft:**
  - numbers that changed
  - meaning that drifted, found by comparing the back-translation with the original
  - likely errors in the original itself, also shown as suggestions on the original. They are never applied automatically.
- **Publishing is blocked** while a draft has open flags, until "I have read the check" is ticked.
- **Published translations are never overwritten.** A re-translation waits until someone clicks "apply the new version".
- **Addresses:**
  - The router only claims `/<prefix>/<slug>/` when that translation exists. `/fi/` (Matkusta Suomesta), `/no/` (Reise fra Norge) and their child pages are untouched.
  - New slugs avoid existing child pages.
  - `?lmgt_translation=` and `?p=` 301 to the real address.
- **hreflang:** `<link>` tags in `<head>` only, never in the sitemap.
  - Only published versions are listed, and each lists every version including itself, plus `x-default` pointing at the original. URLs are `get_permalink()`, the same string Rank Math prints as canonical.
  - Publishing, unpublishing or moving any version clears the LiteSpeed cache of every page in its set, so all of them print the new set at once.
  - If an original is unpublished, its translations stay published (nothing is unpublished without a person) and carry no hreflang; the original's edit screen says so.
  - Nothing is printed on a page without a published translation.
  - Each translation also sets its own `<html lang>`, og:locale and JSON-LD `inLanguage`.
- **Language front pages:** `/en/`, `/sv/` … open with a front page built from what exists in that language: the source front page's image with a fixed line in the language, the translated guides (pages) A–Z, then the newest 24 articles with cards that show the meta description. It is built, not translated, so it grows by itself as translations are published. `/en/page/2/` onward is the plain listing. Only when no real page owns that address (`/no/` and `/fi/` on traveltalk.dk stay departure pages) and only once something is published; otherwise 404. Own `<html lang>` and canonical. Once a language has 3 published versions (Settings), the source front page and that language's front page list each other in hreflang, with `x-default` on the source front page. Publishing or withdrawing a version clears both from the LiteSpeed cache. Settings → Language front pages switches it off, back to the plain listing.
- **Language switcher**, lower left, on every page. On the front page and other listings it links to each language listing that has content.
- On every article. Existing versions link to their own address. A language without a translation links to the original with `#lmgt-nt-<code>`, which shows a one-line "not yet translated" notice: the same URL to Google, so no duplicate page exists.
- **Translator → Check Google tags** (rebuilt in 2.2.6, see below) checks from the database what every page prints; **Check live** fetches one page as served, og:locale included. It only reads.
- **Translator → Old language setup** lists what is left of the GTranslate / LeisureNordic setup: old functions still defined, mu-plugins, active plugins and theme functions.php that mention it, content still using its shortcodes, what `/sv/`, `/en/`, `/no/`, `/fi/`, `/de/` answer and who sent the redirect, the 410-list entries, Rank Math redirections and .htaccess lines on a language folder. Switching off renames a mu-plugin to `.php.off`, deactivates a plugin, sets a Rank Math redirection inactive or removes bare-folder 410 entries. Each step is logged with Undo. Nothing is deleted; .htaccess and theme files are shown only.
- **`tools/lmgt_hreflang_check.py`** (repo root) crawls sets from outside, as Google does: 200 with no redirect, not noindex, self-canonical, `<html lang>`, identical hreflang block on every member, x-default; `--none` URLs must have no hreflang.

## 2.0: the .dk → .travel bridge

Brief: `briefs/translator-2-bridge-brief.md` in the Leisuretalk repo. The same plugin runs on both sites. traveltalk.dk is always the source and traveltalk.travel always the target, taken from the site's own address; `LMGT_ROLE` in `wp-config.php` overrides that (local tests). On any other site without `LMGT_ROLE`, the plugin works exactly as in 1.10.

- **traveltalk.dk (source)** runs the pipeline and sends each result to .travel as a draft over the REST API. It keeps the hreflang set in the original's post meta, recalculates it on every change, and pushes the same set to .travel.
- **traveltalk.travel (target)** stores the translations:
  - English lives at root, without a prefix. Other languages are under `/de/`, `/sv/`, `/nb/`, `/fi/` …
  - It tells .dk when a translation is published, withdrawn or renamed.
  - Each translation shows the line "From the traveltalk.dk family – started in Denmark in 2018".
- **hreflang:** both domains print the set from the same array, so every member's block is byte-identical. `x-default` points to the English version when it exists, otherwise to the .dk original. Norwegian uses `nb` in hreflang and `<html lang>`.
- **Copying an old .dk translation:** use the "traveltalk.travel" box on the translation's edit screen.
  - A published translation is copied over published. The .dk copy stays readable, gets a canonical to .travel, prints no hreflang and leaves the Rank Math sitemap.
  - A draft is copied over as a draft and tagged on .dk.
- **English:** the original's box searches .travel for an English piece on the same subject. A person confirms "link as English". Nothing is linked automatically.
- **"Læs på: English · Deutsch …"** appears after the first paragraph of a .dk original once versions are published. On an untranslated .dk article, the switcher links to the language's front page on .travel.
- **Translator → Bridge** shows:
  - the connection test
  - the retry queue (failed writes are retried hourly and never dropped)
  - the daily reconciliation, which reports mismatches but does not fix them
  - the log
- **`tools/lmgt_hreflang_check.py --moved DK_URL=TRAVEL_URL`** checks a copied .dk translation.

### Setup (once)

1. Install or update the plugin on both sites, the same version on both (2.0.0 talks `lmgt/v1`, 2.1 `lmgt/v2`). Permalinks are flushed by the upgrade.
2. Pair the sites (2.1.1), as an administrator:
   - On one site: Translator → Bridge → **Create pairing code**. The site creates its user `lmgt-bridge` (Editor) and an application password, and shows a code. It is valid for 15 minutes and works once.
   - On the other site: Translator → Bridge → paste the code → **Pair**. That site creates its own `lmgt-bridge` user and password and hands them back over the new link.
   - Passwords are stored in the database (option `lmgt_peer_cred`), encrypted with the site's wp-config keys, never in the repo. If those keys change, pair again.
   - A code that is never used is revoked when the next code is made. A failed pairing leaves a working pair as it was. **Unpair** forgets the other site's password and revokes this site's; do it on both sites.
   - `LMGT_PEER_USER` / `LMGT_PEER_PASS` in wp-config.php still work and win over pairing.
3. Go to Translator → Bridge on both sites. The connection line must be green.
4. On .travel: RankMath → Sitemap settings → switch on **Translations**.

### 2.1: upgrade from the 2.0.0 fresh build

2.0.0 (Leisuretalk repo, live 25–26 Oct 2026) was built without the 1.10 code, so the .dk translations and language front pages answered 404, and .travel had no language menu. 2.1.0 is this plugin (1.10.1 + bridge) and reads what 2.0.0 left:

- Peer user: `LMGT_PEER_USER`, else the 2.0.0 setting "Remote REST user". Password: `LMGT_PEER_PASS`, else `LMGT_REMOTE_APP_PASSWORD`. Peer address: `LMGT_PEER`, else the other bridge site.
- Keys: saved in Translator → Settings, else `LMGT_DEEPL_KEY` / `LMGT_ANTHROPIC_KEY` from `wp-config.php`.
- On the first page load after the upload (`includes/class-lmgt-upgrade.php`), once per version: 2.0.0's sets, canonicals and draft tags on .dk become 2.1 meta; its posts on .travel become translations; its languages setting is copied when 1.10 never saved one (otherwise wave 1: en, de, fr, it, es); every .dk original with translations gets its hreflang set; permalinks are flushed. Old meta stays; nothing is deleted. The result is the first line of Translator → Bridge → Log.
- .dk never links or canonicalises to a .travel language front page before .travel has a published version in that language.
- On .travel the language menu (lower left) lists English, each language with published versions, the others with a "not yet translated" line, and Dansk → traveltalk.dk.

### 2.1.2: the pilot meter (brief 5.1)

- **Engine cost.** Every DeepL call adds its billed characters (`show_billed_characters`). Every Claude or Gemini call adds its input and output tokens per model. Failed steps and retries count too. The job's total travels with the draft (`_lmgt_report['meter']`). The address/SEO call made while sending is included. Fix, SEO and gap-section calls made from a translation's edit screen go to `_lmgt_meter_extra`. Counts are stored, not money.
- **Review time.** On the edit screen and the preview of an unpublished translation, time counts in 5-second ticks while the window has focus and the reviewer moved, typed or scrolled in the last 3 minutes (the block editor's iframe included). The first publication stops the clock and keeps the number of open flags (`_lmgt_review_*` meta).
- **Translator → Pilot** (on .travel) shows minutes per draft (clean and flagged, published only), cost per article, one row per translation with an article total, and a CSV download. The price table (USD per million) is on the same page. Cost is worked out when the page is shown, so a corrected price also applies to past drafts. On .dk the Queue shows each job's cost.
- Queue → "Review draft" on .dk now opens the draft on .travel (2.1.1 used the .travel ID as a .dk post).

### 2.1.3: the agreed engine (G, 26 Oct 2026)

Claude translates; no DeepL. Model Claude Haiku 5.5. On the first load after the upload, once per site, the upgrade sets Translator → Settings to AI engine Claude, Translation engine "Claude only", back-translate with Claude, Claude model `claude-haiku-5-5`. The previous values are written to Translator → Bridge → Log. Keys are not touched. It is not applied again on later upgrades, so a deliberate change in Settings stays. The built-in defaults match, for a fresh install.

### 2.1.4: .travel's own pages and their translations

On .travel, a page outside the bridge (one of its own English pages, or a translation of it made on .travel) now gets its own hreflang set and language selector, as on one site: English as source and x-default, plus every published translation. 2.1.0–2.1.3 looked only at the bridge set, so these pages printed no hreflang and the selector called a published translation "not yet translated" (reported by Mio on the Indonesia page, 26 Oct). Pages in a .dk set are unchanged. Limit: an English .travel page linked as the English member of a .dk original prints the .dk set only; translations made on .travel of that same page are not added to it.

### 2.1.5: improve and keep, link by address, queue by ID

- **Link by address.** On a .dk original, the "traveltalk.travel" box takes the address of an English page on .travel ("Link as English"). The title search only works where the names match (Japan, but not Østrig/Austria).
- **Translations made on .travel join the set.** When an English page is linked, its own translations made on .travel (e.g. Mio's Spanish) become members of the .dk set and keep their hreflang. They are marked `_lmgt_adopted`. A later .dk translation in the same language never overwrites one: a published one gets the usual waiting version, and a draft refuses it.
- **Improve and keep (brief 4.5).** On a linked English page on .travel, the box "traveltalk.dk original" has "Propose improvements from the Danish original". One AI call returns the sections the Danish page has and the English lacks, placed under the right heading, plus single-sentence replacements where the English speaks to Danish readers. The page is not touched: the result waits with "Apply it / Discard it", and applying keeps the old text under Revisions. Sections are only inserted, a replacement changes one sentence at most, and the result must not be shorter.
- **Queue by ID.** Translator → Queue → paste post or page IDs and pick a language. Articles that already have that language are skipped.

### 2.1.5 (parallel build, brought over in 2.2.13): country name as focus keyword on destination guides (G, 26 Oct 2026)

When the original is a page (the destination guides), the focus keyword asked for is the destination's name alone in the target language: Österreich, Autriche, Austria. Meta description and address are built around it as before. Posts are unchanged. Reason: the English Austria page on .travel reached Rank Math 92 once G changed its keyword to "Austria". Applies to new drafts and to the "Set SEO: keyword, meta, address" button on a translation, which overwrites the keyword and meta of a draft already there.

### 2.1.6: thin translations carry noindex until filled out (G, 26 Oct 2026)

On .travel, a published translation under 800 words (Settings → Noindex thin translations; 0 switches it off) stays readable but carries noindex. It is also left out of Rank Math's sitemap and out of hreflang: it is reported to .dk as 'thin', and .dk leaves it out of the set. Once it is filled out past the threshold, it is indexed again and rejoins the set on both sites. The upgrade reports existing thin translations to .dk once, and the result is written to Translator → Bridge → Log.

### 2.2.0: right from the first translation (brief 4.10–4.18, G 27 Oct 2026)

Code: `includes/class-lmgt-sync.php`.

- **Links (4.10).** On .travel, a link in a page to a .dk article points to that article's published version in the page's language (thin ones included), and stays on the .dk original until one exists. It is decided when the page is shown, so links switch by themselves as translations are published; nothing stored is edited. .travel's own pages count as English. Links of the form `/path/` in a .dk original are made absolute (.dk) when the draft is sent. Pages already in the LiteSpeed cache pick up a new link when their cache renews.
- **Mother text changed (4.11).** .dk keeps a fingerprint of each original's title and text, without tags, links or shortcodes (`_lmgt_text_hash`), so a link-only edit does not count. When it changes, .travel flags every translation made from an older text (`_lmgt_mother_changed`):
  - box "Danish original" on the translation's edit screen: **Re-translate** (queues the job on .dk; it runs while Translator → Queue is open there; a published page gets a waiting version, a draft is replaced) or **Dismiss – change not relevant**
  - "Mother text changed (N)" above the Translations list, and in its Original column
  - Translator → Review
  - The flag clears when the new version is applied, on Dismiss, or when the Danish text goes back to the old one. Linked English pages and translations made on .travel are not flagged (improve-and-keep covers them).
  - The upgrade fingerprints every original with members and sends it as the starting point. Changes made to the Danish text before 2.2.0 are not known.
- **One way only (4.12).** .dk → .travel. Nothing is back-translated into .dk.
- **Danish-only blocks (4.13).** On .travel translations, Settings → Danish-only blocks (default: `tt_gyg`, `tt_airalo`, `nordic_partner`, `nordic_cta`, getyourguide.com, getyourguide.dk, airalo.com; G 27 Oct: no GetYourGuide on translations, main clients first): a listed shortcode prints nothing, enclosed text included; a link to a listed domain keeps only its text. A shortcode .travel does not have (any `[name_with_underscore …]`) prints nothing, so no raw code reaches a reader. The edit screen lists what is hidden. The stored text is not changed. A partner per market is not built (no partners named yet).
- **Glossary (4.14).** Settings → Glossary, one box per language switched on: `source term = term in that language`. Added to Claude's rules for translation and polish, with a fixed line keeping traveltalk, traveltalk.dk and traveltalk.travel as they are.
- **Featured image (4.15).** Alt text and caption are translated on .dk when the draft is sent (one small call, counted in the draft's cost) and stored on .travel per language on the attachment (`_lmgt_alt_{lang}`, `_lmgt_caption_{lang}`). Pages in that language show them; the attachment's own fields stay. A waiting version only fills in texts that are missing. Alt texts inside the article were already translated (1.x).
- **4.16** (og:locale, inLanguage) was already in place. **4.17** (categories): translations carry none; breadcrumbs wait for the hub step.
- **Review (4.18).** Translator → Review: drafts, and published translations with a changed Danish text or a waiting version, with language, open flags, words and the original. Review minutes stay on Translator → Pilot.
- New routes: `/changed` on .travel, `/requeue` on .dk. Install on .travel first, then .dk (see STATUS.md). If .dk is first, its upgrade call is queued and retried hourly.

### 2.2.1: release notes built in

`RELEASE-NOTES.md` in this folder is the plain-language record of every version, for editors and reviewers (shared with Mio). Translator → Release notes shows it (`includes/class-lmgt-notes.php`); after an update each editor sees one notice linking to it. 2.2.1 is 2.2.0 plus this.

### 2.2.2: each translation records the version that made it

`_lmgt_made_with` on every translation: the version of the site whose pipeline made it (sent by .dk with the draft; a copied .dk translation keeps its own; a waiting version carries its own and takes over when applied). The upgrade marks every translation without one "before 2.2.2". Translator → Review shows it. This is the key for the catch-up screen (brief 4.19): each release note's "Older translations" heading says what a version means for translations made before it.

### 2.2.3: "Leer en" on translations on .travel

On a translation on .travel, a row in the page's language after the first paragraph (under the family line): every other published version of the set, the original marked ("Leer en: English · Deutsch · Dansk (original)"). The original is the .dk article for a bridge translation, else .travel's own English page. A thin translation (in no set) shows at least the original. Same idea as "Læs på" on .dk originals (brief 4.8).

Fix: the 2.2.0 link localising skipped no link, so it turned the family line's link to the .dk original into a link to the translation itself. Links with an `hreflang` attribute (family line, read-in rows) are now left as they are.

### 2.2.4: image texts in the right language (`includes/class-lmgt-media.php`)

- **Catch-up, featured-image texts (brief 4.19, first item).** .dk: Translator → Catch-up. .travel lists its .dk translations (not adopted ones) whose featured image has no `_lmgt_alt_{lang}` (GET `/catchup`); .dk translates the Danish alt text and caption of the original's featured image, four translations per step, and sends them (POST `/thumbtexts`), stored only where still missing. A Danish image without texts is skipped and logged.
- **Image texts, any site.** Translator → Image texts. 25 unchecked images per Claude call (structured output): are alt, caption, title and description in the site's language (`LMGT_Langs::source()`)? Proposals are stored in `_lmgt_text_check`; images with no text at all are marked without a call. "Apply the ticked" keeps the old texts in `_lmgt_text_before` and changes only fields that were not empty; "Keep the ticked as they are" dismisses. Nothing is changed by the check itself.

### 2.2.5: alt texts with context (`includes/class-lmgt-alts.php`)

- **Translator → Alt texts, any site.** One Claude call per post (Claude only: it looks at the pictures, sent as image blocks by URL, mid-size): for the featured image and up to 20 images in the text, the alt text now, 500 characters before and 300 after, and the post title. Structured output: `{items: [{n, ok, alt}]}`. Proposals in `_lmgt_alt_check`; a person edits, ticks and applies. Images in the text are matched by `wp-image-N` (else `src`) and get the alt attribute in the post's HTML; the featured image gets `_wp_attachment_image_alt`. `_lmgt_alt_applied` records when. Alt changes leave the text fingerprint as it is (tags are stripped), so no "Mother text changed".
- **Catch-up, alt texts in articles (.dk).** Originals with `_lmgt_alt_applied` newer than `_lmgt_alt_synced[lang]`: one call translates the post's alt texts, .dk sends them by image key (POST `/alts`), .travel sets the alt attributes in the translation and in a waiting version, and the featured image's text for that language.

### 2.2.6: Check Google tags for the bridge (`includes/class-lmgt-checker.php`)

The 1.x checker fetched every translation and its original over HTTP and expected one-site sets, so on the bridge it reported .dk translations on .travel as having no original, thin pages and copied .dk translations as errors, and it swept our own sites (brief section 0). Now: `LMGT_Checker::expected()` gives the set a page prints, from the same meta the front end prints from; `check()` reports problems (language, hand-set noindex or canonical, own address missing from the set, x-default rule, members not published or thin, the set differing between members on .travel, a stale `_lmgt_set` on .dk with "Send the set again" = `refresh_set()`, a copied translation's canonical not matching its .travel address) and notes (thin, copied). On .dk, "Compare the sets with traveltalk.travel" makes one GET `/sets`, which now carries an md5 of each member's stored set. "Check live" fetches one page, chosen by a person.

### 2.2.7: related-articles grid and pictures per text length (`includes/class-lmgt-pictures.php`)

- **Related articles.** The grid on .dk articles is a `kadence/posts` block, rendered from .dk's own posts when the page is shown, so it was empty on .travel. On send (and from Translator → Catch-up → "Send the grids"), .dk renders each such block with the original as the global post, reads the article IDs from `post-N` classes, and sends per block `{id, url, title, img, tr}` (`related` in POST `/draft`, or POST `/related`). `tr` is the title in the target language for articles without a published translation there, translated once and kept in `_lmgt_title_tr`. .travel stores `_lmgt_related` (published translations too: it is navigation, not article text) and draws the nth posts block of a translation from it via `pre_render_block`, in Kadence's markup with a small grid style of its own; each item links to the published translation in that language when there is one (looked up when shown), else to the .dk article with `hreflang="da"` and a "Dansk" mark.
- **2.2.8:** on traveltalk.dk the grid is often added by a snippet when the page is shown (class `kb-posts-id-<ID>_relfix`), not stored in the text. `LMGT_Pictures::shown()` now renders the original's `the_content` in its own singular query and reads every `wp-block-kadence-posts` list from the output; the catch-up covers every translation. On .travel, grids beyond the posts blocks in the translation's text are appended at the end (`the_content`, priority 30). The upgrade lock is an options row taken with one atomic insert and the version is re-read from the database (`LMGT_Upgrade::maybe_run()`), so a persistent object cache can no longer make it run more than once.
- **2.2.15:** the reviewer hint is English (`en` in the answer) for every language but English, on Alt texts, Find pictures (`LMGT_Alts::hint()`) and Image texts (`_lmgt_text_check['en']`); 2.2.14's stored `da` lines still show.
- **2.2.14:** "Put it here" runs `LMGT_Alts::check( $post, 'id:N' )` for the placed picture only (the post's other proposals are kept) and shows the proposal on Find pictures, applied through the same handler (`lmgt_back` returns there). Alt texts are written in the article's language (`lang_of()`: a translation's `_lmgt_lang`, else the site's); translations are checked and listed too, and a translation's featured image gets `_lmgt_alt_{lang}`, not the image's own alt. For languages other than Danish and English the answer carries `da`, a word-for-word Danish rendering shown under the proposal.
- **2.2.13:** the country-name keyword rule (`8f4ee77`, 26 Oct, built in a parallel session as "2.1.5" and never merged into the 2.1.5/2.1.6 that went live) is brought over: `seo_basics()`/`prompt_seo()` take `$guide` (the original is a page). "Set SEO" keeps an existing focus keyword first and appends a different suggestion. On .travel the Media Library edit screen shows and saves `_lmgt_alt_{lang}` / `_lmgt_caption_{lang}` (`attachment_fields_to_edit` / `_save`).
- **2.2.12: Find pictures** (`includes/class-lmgt-finder.php`, Translator → Find pictures, opened from the Pictures box). Per section (150+ words) inside a stretch without a picture: the heading's words (filler words out, at most five) are searched in the Media Library (title, caption, `_wp_attachment_image_alt`, `_wp_attached_file`; æ/ø/å also as ae/oe/aa and a/o/a), one point per word, pictures already in the article excluded, best six shown. "Put it here" inserts a `core/image` block after the section's first paragraph, guarded by the heading's md5 so a changed article is not edited. The banks come from the LMG Image Banks option (`lmg_image_banks`).
- **2.2.11:** each stretch in the Pictures box also lists the sections it runs through with their words (`analyse()` returns `sections` per gap).
- **2.2.10:** the relfix snippet on .dk does not add its grid in admin/AJAX requests, so `shown()` found nothing for country pages. Fallback, verified against the Austria page (12 of 12, same order): for a page, the 12 newest published posts in the category whose slug is the page's slug. On .travel the grid now replaces `kadence/posts` blocks at any depth (`render_block`, not `pre_render_block`, which only fires for top-level blocks), and a block without a stored grid prints nothing instead of Kadence's "No posts".
- **2.2.9:** a spinner beside every run button on the Translator pages (`LMGT_Admin::run_indicator()`, admin footer): on while running, off when the status reads Finished/Stopped or the button is enabled again; Alt texts and Image texts reload when finished. Titles in the Alt texts log are entity-decoded.
- **Pictures per text length.** Pictures box (posts, pages, translations) and Pictures column: pictures in the text, words per picture, and stretches over `lmgt_picture_every` words (Settings, default 400) without one, named by the first and last section they cover with at least 50 words.


### 2.2.26: Translate everything; several at once in the background (G, 3 Nov 2026)

- `includes/class-lmgt-plan.php` (`LMGT_Plan`, Translator → Translate everything): `originals()` = published posts/pages (`lmgt_plan_pages`/`_posts`), not front/blog page, password, Rank Math noindex, translations, `lmgt_plan_skip`, content under 200 bytes. `versions()` = local `_lmgt_source`/`_lmgt_lang` plus `_lmgt_remote`, any status. `missing( $lang )`: `lmgt_plan_first`, pages longest first, posts newest first; for `en` an original with any version comes first among its kind (x-default). Languages: `LANG_ORDER` (en, de, fr, es, it, pt, sv, nb, fi), `lmgt_plan_langs`. `refill()` (each minute while `lmgt_plan_on`): the first `lmgt_plan_lanes` languages with work share `lmgt_plan_window` queue places; jobs carry `plan`; failed or refused pairs go to `lmgt_plan_failed` and are not re-queued (Retry clears); done plan jobs beyond 30 are removed (`lmgt_plan_cleared`); stops by itself when nothing is left. Page shows "x-default still the original" (published versions, no published English).
- `LMGT_Jobs`: per-job lock rows `lmgt_jl_{id}` (atomic `INSERT IGNORE`, stale after 300 s) replace the single `lmgt_lock` transient; `step( 'all'|'bg'|true )`. Workers `lmgt_slot_{n}`, n ≤ `lmgt_workers` (default 2): `cron()` refills, kicks 2…n with non-blocking `admin-ajax.php?action=lmgt_bg` (key `lmgt_bg_key`), works as 1 for 50 s; `ajax_bg()` works 45 s and kicks itself again while work waits. Background takes auto jobs, plan jobs while the plan is on, all jobs with `lmgt_cron`. `save`: `plan` + `lmgt_plan_publish` publishes like auto (hold-back, `autopub` listing).
- Checker: a set without English notes "x-default is the original". `LMGT_Bridge::compute_set()` was already x-default = English when published; unchanged.
- Works on a site without a partner (no `LMGT_ROLE`/known host): versions are stored locally.

### 2.2.27: News as written, sharper Find pictures, AI names (G, 2 Nov 2026)

- `LMGT_Store::as_written()` (`NEWS_SLUGS`: news, nyheder, rejsenyt, travel-news; meta `_lmgt_as_written`; a translation follows its local `_lmgt_source`): `min_words()` returns 0, `is_thin()` false, the translation's gap notice and the original's Length/gap box are replaced by one line. Tick box in the Translations box (`save_as_written`, hidden `lmgt_as_written_box`).
- `LMGT_Finder::search()` returns `[ID => why]`: broad LIKE in SQL, then whole-word matching in PHP (`has_word`), weights alt/title 3, caption 2, file name 1; `need()` = 2 when 3+ words and `lmgt_find_strict` (default on, Settings). Title words are tried alone, not merged.
- `LMGT_Engines::gemini_available/gemini_json` → `ai_available/ai_json`, `LMGT_Jobs::gemini_part` → `ai_part`. Options `lmgt_gemini_key`, `lmgt_gemini_model` and `gemini_model()` keep their names (they are Gemini's).

### 2.2.26: Alt texts leave out pictures Claude cannot fetch (G, 2 Nov 2026)

- `LMGT_Alts::own_host()`: only addresses on traveltalk.dk, traveltalk.travel or this site's home host are sent as `url` image sources (Claude's fetcher obeys the other host's robots.txt; seen with a `maps.googleapis.com` static map in post 1727). Others are counted in `_lmgt_alt_check['skipped']` and named in the step's line.
- `LMGT_Alts::check()`: if the one call fails and the post has two or more items, each is asked alone; failures are set aside.
- `ajax_check()`: a non-empty ID box with no numbers stops with a message instead of falling back to the next unchecked post.

### 2.2.25: new articles translated automatically; welcome note (G, 1 Nov 2026)

- `includes/class-lmgt-auto.php` (`LMGT_Auto`): `transition_post_status` → first publication of a `post` (once, `_lmgt_auto_queued`) schedules `lmgt_auto_queue` 30 minutes ahead; `queue()` calls `LMGT_Jobs::add( $id, $lang, true )` for every `LMGT_Langs::enabled()` language.
- `LMGT_Jobs`: jobs carry `auto`; `cron()` runs `step( true )` (auto jobs only) unless `lmgt_cron` is on; `lmgt_auto_work` keeps the minute schedule alive while auto jobs wait. `save` stage: auto + `lmgt_auto_publish` + not `LMGT_Auto::should_hold()` → `send( …, 'publish', false, '', array( 'autopub' => 'published' ) )`, else a draft with `autopub = hold`; on a site without a peer `LMGT_Auto::local()` publishes after `LMGT_Store::save()`. Manual jobs: unchanged.
- `should_hold()`: report issues, gaps or changed numbers (`lmgt_auto_hold`).
- `LMGT_Bridge::send()` takes `$extra`; `rest_draft()` stores `_lmgt_autopub` (`published`|`hold`), `_lmgt_autopub_at`, clears `_seen`/`_mailed`, and `LMGT_Auto::announce()` schedules `lmgt_auto_mail` an hour ahead (one e-mail listing what is not yet mailed). Translator → Auto-published lists `pending()` (no `_lmgt_autopub_seen`, no `_lmgt_reviewed`); "Mark all as looked at" sets `_seen`.
- Welcome note: `#lmgt-welcome` on .travel translated pages and language front pages (`lmgt_welcome`), shown by `CHIP_JS` after 2 s (waits for `.cmplz-cookiebanner`, up to 15 s), 7 s, paused on hover/touch, `localStorage lmgt_welcome` 60 days, not while the back note is shown; `#lmg-welcome` forces it.

### 2.2.24: the way back no longer depends on the referrer (G, 1 Nov 2026)

- `LMGT_Bridge::from_dk()` appends `#lmg-from-dk` to a .dk → .travel link a reader clicks: the language button (`LMGT_Front::switcher()`, so also the English offer, which copies the menu's address), the "Read in" row (`read_in_row()`) and the footer line (`LMGT_Migrate::footer_line()`). Never in hreflang, canonicals, redirects (`peer_lang_home()` is unchanged) or the sitemap.
- `CHIP_JS` on .travel: the fragment sets `sessionStorage lmgt_from`, clears `lmgt_back_off` and is removed with `history.replaceState`; the script is now printed on .travel also when `lmgt_back_chip` is off, so the fragment is tidied either way. The referrer test stays as a second signal.
- `LMGT_Bridge::peer_front()` (`SITES[...]['front']`): readers' links to the peer's front page use www.traveltalk.dk. `peer()` is unchanged: it is the address the bridge calls.

### 2.2.23: language button between the two sites (G, 1 Nov 2026)

- `LMGT_Front::switcher()`: on .dk (source) every language .travel has goes to `peer_lang_home()` also on the front page and listings (before, only on articles); a .dk language page is used only for a language .travel lacks. An article's own set (`cluster()`) is unchanged, so a .dk translation not yet moved stays linked from its article until it has moved.
- Links to the other host carry `data-x="1"`, `↗`, and `target=_blank rel=noopener` (`lmgt_switcher_newwin`, default on). On .travel the `da` entry reads "Dansk · traveltalk.dk"; on .dk the list ends with "↗ traveltalk.travel".
- The remembered language (`localStorage lmgt_lang`) is neither stored from nor followed to a `data-x` link: no automatic move between the sites.
- `#lmgt-offer` (.dk, `lmgt_english_offer`): `CHIP_JS` picks the first `navigator.languages` entry that has an `a[data-x][hreflang]` item (that exact page on .travel), else English; none when the browser lists `da`; closed or used = `localStorage lmgt_offer_off` for 60 days. `#lmgt-back` (.travel, `lmgt_back_chip`): shown when `document.referrer` is the peer host, remembered in `sessionStorage lmgt_from`, closed with `lmgt_back_off`. Both hidden in markup and shown by script (page-cache safe); `#lmg-offer` / `#lmg-back` in the address force them. No hreflang, canonical or sitemap change.

### 2.2.22: one sortable Words column (G, 31 Oct 2026)

- 2.2.21 registered a second Words column; WordPress already adds the posts columns (`manage_posts_columns`) to the translation list. Removed; the existing `lmgt_words` column is now sortable via `_lmgt_words`.

### 2.2.21: threshold change carried through, Words column (G, 31 Oct 2026)

- `LMGT_Bridge::threshold_changed()` (.travel): on a change of `lmgt_noindex_under`, queues published translations whose thin state flipped (`lmgt_rethin_queue`), clears Rank Math's sitemap cache and LiteSpeed, and `rethin_run()` (single cron event, 6 per run, 30 s apart) calls `notify()` so .dk's stored status and hreflang sets follow.
- `_lmgt_words` meta on every translation (save_post hook, upgrade backfill); Words column, sortable, in the Translations list.

### 2.2.20: pictures saved on .travel, Catch-up names what .travel answered (G, 31 Oct 2026)

- `class-lmgt-localpics.php` (.travel, Translator → Save pictures): imports each .dk picture of a translation once (`_lmgt_imported_from` on the attachment = full-size address), rewrites `src`/`data-src`, drops `srcset`, sets `wp-image-ID` and the image block's id, writes `post_content` directly (no revision, no hash change). Two imports a step, 2.5 s pause, one retry on 5xx. Failed addresses in `_lmgt_pics_failed`. English translations first. Built 31 Oct on branch claude/translator-pictures-wip, here brought onto 2.2.19.
- `LMGT_Migrate::catchup_section()`: the "not switched on at traveltalk.travel" line lists the languages .travel answered.

### 2.2.19: keyword proposals from the page's own title (G, 31 Oct 2026)

- `LMGT_Catchup::destination_name()` asks Claude from the translation's own title (Danish title as context only); a page about no single destination gets an empty keyword; `in_title()` leaves a proposal unticked, with a note, when the title does not contain it. The upgrade deletes `lmgt_kw_proposals`. Carried over from branch `claude/awesome-cray-jrpsqi` (cab3a6a); its breadcrumb change is superseded by 2.2.18's.

### 2.2.18: short breadcrumb names, sitemap cleared on copy (G, 31 Oct 2026)

- `LMGT_Trail::short()`: breadcrumb level = Rank Math breadcrumb title, else the title up to the first spaced dash / colon / bar. Names kept in `_lmgt_crumb_tr`; stored trails are shortened when shown.
- `.dk`: `rank_math/sitemap/get_posts/where` and `post_count/where` leave moved translations out; setting or removing `_lmgt_moved_to` invalidates Rank Math's sitemap cache; the upgrade clears it once.

### 2.2.17: no Danish links in translations, short picture addresses, stale copies marked (G, 30 Oct 2026)

- **Links** (`LMGT_Sync::local_links()`, .travel, `the_content` 21). Whole anchors now: a .dk link maps to the member in the page's language, else `en`, from `map()`; in a translation (`is_singular( LMGT_CPT )`) an unmapped one is unwrapped (inner HTML kept). Kept as they are: anchors with `hreflang` (family line, "Read in"), `wp-content/` paths, other hosts. Other pages keep the 2.2.16 rule (unmapped links stay).
- **Related grid** (`LMGT_Pictures::grid()`): member in `$lang`, else `en` (marked `hreflang="en"`), else the item is skipped. No more `hreflang="da"` cards.
- **Short picture addresses** (`LMGT_Pictures::full_src()`, both roles, `the_content` 22): `src`/`data-src` of the form `YYYY/MM/…` gets the uploads base: .dk's own `baseurl`; on .travel, translations only, `peer()/wp-content/uploads/`. Stored text unchanged.
- **Stale copies** (`LMGT_Bridge::move()` → `send()`): a .dk translation whose `_lmgt_source_modified` differs from the original's `post_modified_gmt` is sent with `source_hash` '' and `source_stale` [at, hash]; `rest_draft()` stores it as `_lmgt_mother_changed` (also kept in `_lmgt_pending` and set on `apply_pending()`). Before, a copy took today's hash and passed as current.
- **List on .travel**: "Newer version waiting" when `_lmgt_pending` holds a translation. The CPT's own `lmgt_id` echo is gone: `manage_posts_custom_column` already runs `words_column()` for translations.

### 2.2.16: lighter copy, translations leave .dk, breadcrumbs per language, catch-up (G, 28 Oct 2026)

- **Lighter copy.** While .travel answers POST `/draft` it no longer calls .dk back (`LMGT_Bridge::$quiet` mutes `target_transition`); .dk records the result from the reply, whose `status` is now `member_status()` (`thin` included). A featured image not yet on .travel comes in its own call, POST `/thumb`, after the draft (`thumb_later` in the payload; queued for retry on failure); one already imported is set inside `/draft`. A copy (`move()`) sends the .dk translation's own focus keyword and meta, so `seo_basics()` runs only when one is missing; `move()` no longer pushes the set a second time (only for a thin copy, which leaves the set). `call()` tries once more after 5 s on HTTP 429/503/508 (508 = the host's resource limit, seen on .travel 27 Oct). One copy is now `/draft` + `/set` (+ `/thumb` for a new image), was `/draft` → `/notify` → `/set` nested, plus two more `/set`.
- **Translations leave .dk** (`includes/class-lmgt-migrate.php`). A .dk translation with `_lmgt_moved_to` whose member is `publish`/`thin` in `_lmgt_remote` answers 301 → that address (`template_redirect`, not in previews); otherwise it shows as before. A .dk language front (`lmgt_lang_home`) answers 301 → `peer_lang_home()` once `left( $lang )` is 0. The language front lists no moved copies. Translator → Catch-up → "Translations still on traveltalk.dk" copies the rest one per AJAX step (`one()`): languages from .travel's `/ping` (`langs`: its source plus Settings → Translate into); where `_lmgt_remote` already has the language, the copy is pointed at it (`_lmgt_moved_to`) instead; English goes through `/match` first and a hit is held (`_lmgt_copy_check`) for a person. The Nordic departure pages (/se/, /no/, /fi/) are ordinary pages, not translations, and are never touched. Footer line on every .dk page (`wp_footer`, filter `lmgt_intl_line`) and the "Læs på · Read in" row link to .travel in a new window.
- **Breadcrumbs per language** (`includes/class-lmgt-trail.php`, brief 4.17). .dk sends `trail` with each draft (POST `/trail` in the catch-up): for a page its ancestors, for a post the page whose slug is its category's (Rank Math primary, else the first; not Uncategorized) with that page's ancestors, else the category with its ancestors. Names are translated once: pages in `_lmgt_title_tr`, categories in term meta `_lmgt_name_tr`. .travel stores `_lmgt_trail` and shows Home (in the language, → `lang_home_url()`), each level linked to its published member in that language (`LMGT_Sync::member_of()`) or as text, then the current item: in Kadence's breadcrumb (output buffer from `template_redirect`, replacing the first `kadence-breadcrumb-container`) and in Rank Math's items (`rank_math/frontend/breadcrumb/items`; text-only levels `hide_in_schema`). Translations made on .travel use their English page's ancestors that have a published translation in their language.
- **Catch-up** (`includes/class-lmgt-catchup.php`, brief 4.19): Overview (GET `/made`: every .dk translation on .travel with its `_lmgt_made_with`, against `LMGT_Catchup::NEEDS`); focus keyword on destination guides (proposals from `seo_basics( …, true )` on the Danish original, applied with POST `/keyword`, which puts the keyword first and keeps the others; meta and address untouched, pages whose meta lacks the keyword are named). Not built: ordering by Search Console impressions.
- The upgrade clears the LiteSpeed cache once (`litespeed_purge_all`) on both sites.


## Languages

| Code | Address | hreflang | DeepL |
|---|---|---|---|
| en | /en/ | en | EN-GB |
| de | /de/ | de | DE |
| fr | /fr/ | fr | FR |
| es | /es/ | es | ES |
| it | /it/ | it | IT |
| sv | /sv/ | sv | SV |
| nb | /no/ | no | NB |
| fi | /fi/ | fi | FI |

To add a language, such as Portuguese for traveltalk.travel, add one row in `includes/class-lmgt-langs.php` and its marker words. Japanese needs a different language check, because Japanese does not separate words with spaces.

Norwegian is `nb` inside the plugin and for DeepL (DeepL has no `NO`), and `no` in the address, hreflang and `<html lang>`.

## Launch checklist (per site)

1. Deactivate **Traveltalk AI Translator**, then LiteSpeed Cache → Purge All. The new plugin refuses to run while the old one is active.
2. Upload `lmg-translator/` to `wp-content/plugins/` and activate it.
3. Translator → Settings: keys, languages, engine. Keys are stored in WordPress options and never printed.
4. Translator → Clean up old plugin: shows the count of the old `_tt_translated_*` fields, then deletes only those fields. No article is changed.
5. RankMath → Sitemap settings: switch on **Translations** so published translations enter the sitemap. RankMath → Titles & Meta → Translations: Robots **Index**.
6. Translator → Old language setup: read it; switch off what is still loaded; remove the rule behind `/sv/` and `/en/`.
7. Tag the existing hand-written translations (Menorca EN and SV).
8. Translate a few articles into one language, review, publish, then run **Check Google tags** and `tools/lmgt_hreflang_check.py` on each set plus one untranslated post. Both must show all OK before any batch.

## Known limits (v1)

- Theme text around the article (menu, footer, "related posts") stays in the site language.
- Translations carry no categories or tags. Their URLs are flat (`/sv/<slug>/`), so nothing breaks.
- Unattended running via WP-Cron is off by default. By house rule the queue runs while the Translator page is open.

### 2.19.5: Tone step (G, 22 Nov 2026, briefs/translator-tone-check-brief.md)
- `class-lmgt-tone.php`, booted with the `steps` part. Step row after Structure; excluded from `LMGT_Steps::blocking()` (advice only). In Prepare all (`lmgt_tone`) and Accept all (`lmgt_tone_apply`), after Structure; `lmgt_tone` runs in the background like the other proposal steps.
- Options: `lmgt_tone_rules` (empty = `LMGT_Tone::RULES`, the 11 rules of house style §9A5), `lmgt_tone_auto` (default on), `lmgt_tone_skip` (page IDs or address words; default `travel-services`; ancestors count), `lmgt_tone_since` (set at first boot).
- One `ai_json` call with a schema `{passages:[{passage, rules[], why, rewrite, needs_detail}]}`, at most 12. A passage must stand in the text's plain text or it is dropped; a rewrite with a number or a capitalised word (not at a sentence start) that the text lacks is turned into "needs a concrete detail". Passages not in one text node (across inline tags) are marked `hand`.
- Meta: `_lmgt_tone` (waiting list), `_lmgt_tone_done` (hash of the text when settled; "Tone: OK" while unchanged), `_lmgt_tone_auto`, `_lmgt_tone_err`. Accept replaces each ticked passage once, on the text as it is now, via `LMGT_Store::update_content`.
- Automatic: `transition_post_status` → first publish of a `post` dated after `lmgt_tone_since`; `added_post_meta` `_lmgt_autopub` (automatic translations). WP-Cron single event `lmgt_tone_auto` two minutes later, once per post.
