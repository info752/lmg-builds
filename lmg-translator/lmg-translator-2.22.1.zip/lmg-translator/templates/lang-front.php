<?php
/**
 * A language's front page (/en/, /sv/ … page 1). See LMGT_LangFront.
 * Kadence's own wrappers, so header, footer and widths match the rest of the site.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$lang     = get_query_var( 'lmgt_lang_home' );
$l        = LMGT_Langs::get( $lang );
$src      = LMGT_Langs::get( LMGT_Langs::source() );
$guides   = LMGT_LangFront::items( $lang, true, 48 );
$latest   = LMGT_LangFront::items( $lang, false, LMGT_LangFront::LATEST );
$counts   = LMGT_Front::published_counts();
$total    = isset( $counts[ $lang ] ) ? $counts[ $lang ] : 0;
$hero_img = LMGT_LangFront::hero_image( $guides );

$card = function ( $p, $eager ) {
	$url = get_permalink( $p );
	echo '<article class="lmgt-lf-card">';
	echo '<a class="lmgt-lf-img" href="' . esc_url( $url ) . '" tabindex="-1" aria-hidden="true">';
	if ( has_post_thumbnail( $p ) ) {
		echo get_the_post_thumbnail( $p, 'medium_large', array( 'loading' => $eager ? 'eager' : 'lazy', 'alt' => '', 'sizes' => '(max-width: 600px) 100vw, (max-width: 1100px) 50vw, 380px' ) );
	}
	echo '</a><div class="lmgt-lf-body"><h3><a href="' . esc_url( $url ) . '">' . esc_html( get_the_title( $p ) ) . '</a></h3>';
	echo '<p>' . esc_html( LMGT_LangFront::blurb( $p ) ) . '</p></div></article>';
};

get_header();
?>
<style>
.lmgt-lf-hero{position:relative;display:flex;align-items:flex-end;min-height:clamp(320px,52vh,560px);padding:clamp(28px,6vw,72px) 16px;color:#fff;background:#252528 center/cover no-repeat;overflow:hidden}
.lmgt-lf-hero img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.lmgt-lf-hero::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.05) 30%,rgba(0,0,0,.62))}
.lmgt-lf-hero .in{position:relative;z-index:1;width:100%;max-width:var(--global-content-width,1200px);margin:0 auto}
.lmgt-lf-hero p.k{margin:0 0 .4em;font-size:.85rem;letter-spacing:.14em;text-transform:uppercase;opacity:.9}
.lmgt-lf-hero h1{margin:0 0 .35em;color:#fff;font-size:clamp(2rem,5.4vw,3.6rem);line-height:1.08}
.lmgt-lf-hero p.l{margin:0;max-width:38em;font-size:clamp(1rem,2.2vw,1.2rem);line-height:1.5}
.lmgt-lf section{margin:clamp(32px,5vw,56px) 0}
/* Themes without Kadence's padded container (Hello Elementor on winetalk, think-smarter) put the text flush against the edge. */
body:not(.wp-theme-kadence) .lmgt-lf{box-sizing:border-box;width:100%;max-width:1200px;margin:0 auto;padding-left:16px;padding-right:16px}
.lmgt-lf h2{margin:0 0 18px;font-size:clamp(1.4rem,3vw,1.9rem)}
.lmgt-lf-grid{display:grid;gap:22px;grid-template-columns:repeat(auto-fill,minmax(250px,1fr))}
.lmgt-lf-card{display:flex;flex-direction:column;background:#fff;border-radius:10px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.08)}
.lmgt-lf-img{display:block;aspect-ratio:3/2;background:#eee;overflow:hidden}
.lmgt-lf-img img{display:block;width:100%;height:100%;object-fit:cover}
.lmgt-lf-body{padding:14px 16px 18px}
.lmgt-lf-body h3{margin:0 0 8px;font-size:1.12rem;line-height:1.3}
.lmgt-lf-body h3 a{color:inherit;text-decoration:none}
.lmgt-lf-body h3 a:hover{text-decoration:underline}
.lmgt-lf-body p{margin:0;font-size:.95rem;line-height:1.5;color:#55555a}
.lmgt-lf-more{margin:22px 0 0}
@media (max-width:600px){.lmgt-lf-grid{gap:16px;grid-template-columns:1fr}.lmgt-lf-hero{min-height:300px}}
</style>
<div class="lmgt-lf-hero">
	<?php if ( $hero_img ) echo wp_get_attachment_image( $hero_img, 'full', false, array( 'loading' => 'eager', 'fetchpriority' => 'high', 'alt' => '', 'sizes' => '100vw', 'data-no-lazy' => '1' ) ); ?>
	<div class="in">
		<p class="k"><?php echo esc_html( LMGT_LangFront::t( $lang, 'kicker' ) ); ?></p>
		<h1><?php echo esc_html( get_bloginfo( 'name' ) ); ?></h1>
		<p class="l"><?php echo esc_html( LMGT_LangFront::t( $lang, 'lead' ) ); ?></p>
	</div>
</div>
<div id="primary" class="content-area">
	<div class="content-container site-container">
		<main id="main" class="site-main lmgt-lf" role="main">
			<?php if ( $guides ) : ?>
			<section aria-labelledby="lmgt-lf-g">
				<h2 id="lmgt-lf-g"><?php echo esc_html( LMGT_LangFront::t( $lang, 'guides' ) ); ?></h2>
				<div class="lmgt-lf-grid"><?php foreach ( $guides as $i => $p ) $card( $p, $i < 3 ); ?></div>
			</section>
			<?php endif; ?>
			<?php if ( $latest ) : ?>
			<section aria-labelledby="lmgt-lf-a">
				<h2 id="lmgt-lf-a"><?php echo esc_html( LMGT_LangFront::t( $lang, 'latest' ) ); ?></h2>
				<div class="lmgt-lf-grid"><?php foreach ( $latest as $i => $p ) $card( $p, ! $guides && $i < 3 ); ?></div>
				<?php if ( $total > LMGT_LangFront::LATEST ) : ?>
				<p class="lmgt-lf-more"><a class="button" href="<?php echo esc_url( home_url( user_trailingslashit( $l['prefix'] . '/page/2' ) ) ); ?>"><?php echo esc_html( LMGT_LangFront::t( $lang, 'more' ) ); ?> →</a></p>
				<?php endif; ?>
			</section>
			<?php endif; ?>
			<p class="lmgt-lf-more"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" hreflang="<?php echo esc_attr( $src['hreflang'] ); ?>" lang="<?php echo esc_attr( $src['hreflang'] ); ?>">🌐 <?php echo esc_html( $src['native'] ); ?> →</a></p>
		</main>
	</div>
</div>
<?php
get_footer();
