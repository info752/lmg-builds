<?php
/**
 * Regression guard for swallowed headings. Run: php tests/test-headfix.php
 * Every case that ever reached a live page is kept here. The build refuses a zip when one fails.
 */
define( 'ABSPATH', __DIR__ );
function wp_strip_all_tags( $s ) { return trim( strip_tags( preg_replace( '@<(script|style)[^>]*?>.*?</\\1>@si', '', $s ) ) ); }
function esc_html( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES, 'UTF-8', false ); }
require __DIR__ . '/../includes/class-lmgt-headfix.php';

$fail = 0;
function check( $name, $ok, $got = '' ) {
	global $fail;
	echo ( $ok ? "ok   " : "FAIL " ) . $name . "\n";
	if ( ! $ok ) { $fail++; echo "     got: " . str_replace( "\n", '\n', $got ) . "\n"; }
}
function heading_texts( $html ) {
	preg_match_all( '#<h[1-6][^>]*>(.*?)</h[1-6]>#is', $html, $m );
	return array_map( 'trim', array_map( 'strip_tags', $m[1] ) );
}
function headings_short( $html, $max = 120 ) {
	foreach ( heading_texts( $html ) as $t ) if ( mb_strlen( $t ) > $max ) return false;
	return true;
}
function balanced( $html ) {
	for ( $l = 1; $l <= 6; $l++ ) if ( preg_match_all( "#<h$l(?=[\\s>])#i", $html ) !== preg_match_all( "#</h$l>#i", $html ) ) return false;
	return true;
}
$words = function ( $h ) { return preg_replace( '/\s+/', ' ', trim( html_entity_decode( strip_tags( $h ), ENT_QUOTES ) ) ); };

// 1. 23 Nov 2026, Everything About Camping Holidays (.travel): closing tags lost in the questions box.
$place = 'Everything About Camping Holidays';
$c1 = "<p>Packing lists: PackPoint</p>\n\n<!-- lmgt:faq -->\n\n<!-- wp:html -->\r\n<div class=\"lmgt-box lmgt-faq\" data-lmgt=\"faq\">\r\n<h2>Know before you go: Everything About Camping Holidays\n\nDo I need expensive camping gear for a first camping holiday? No. You don't need to buy expensive expedition gear to sleep one night in a tent. Start simple and upgrade once you know you love camping.\n\n<h3>What type of camping suits a beginner?\n\nCampsites are the safe start, offering facilities such as toilets, showers and a kitchen. Glamping is another easy introduction for people who are sceptical about camping.\n\n<h3>How much could a camping holiday save compared with a hotel?\n\r\n<p>A campsite in Tuscany costs €20-40 per night for a family, while a hotel in the same location costs €150-300.</p>\r\n<h3>What should I check on a tent before I leave?</h3>\r\n<p>Choose a tent with a water column of at least 3000mm.</p>\r\n</div>\r\n<!-- /wp:html -->\n\n<!-- /lmgt:faq -->\n\n<h2>Next section</h2>\n<p>Body.</p>";
$r1 = LMGT_Headfix::fix_all( $c1, $place );
check( 'camping: box title is only the title', in_array( 'Know before you go: Everything About Camping Holidays', heading_texts( $r1 ), true ), $r1 );
check( 'camping: first question is an H3', strpos( $r1, '<h3>Do I need expensive camping gear for a first camping holiday?</h3>' ) !== false, $r1 );
check( 'camping: every question is an H3', count( preg_grep( '/\?$/', heading_texts( $r1 ) ) ) === 4, $r1 );
check( 'camping: no long heading', headings_short( $r1 ), $r1 );
check( 'camping: tags balanced', balanced( $r1 ), $r1 );
check( 'camping: no word lost', strpos( $words( $r1 ), "No. You don't need to buy expensive expedition gear" ) !== false && strpos( $words( $r1 ), 'Body.' ) !== false, $r1 );
check( 'camping: next section untouched', strpos( $r1, "<h2>Next section</h2>\n<p>Body.</p>" ) !== false, $r1 );
check( 'camping: second run changes nothing', LMGT_Headfix::fix_all( $r1, $place ) === $r1 );

// 2. Same box after the editor folded it: <h2>Title Q? A</h2><h3>Q? A</h3>.
$c2 = '<div class="lmgt-box lmgt-faq" data-lmgt="faq"><h2>Know before you go: Everything About Camping Holidays Do I need expensive camping gear for a first camping holiday? No. You don\'t need to buy expensive expedition gear to sleep one night in a tent.</h2><h3>What type of camping suits a beginner? Campsites are the safe start, offering facilities such as toilets, showers and a kitchen.</h3><h3>Is wild camping allowed?</h3><p>No.</p></div>';
foreach ( array( $place, '' ) as $pl ) {
	$r2 = LMGT_Headfix::fix_all( $c2, $pl );
	$tag = $pl === '' ? ' (place unknown)' : '';
	check( 'folded: title split' . $tag, in_array( 'Know before you go: Everything About Camping Holidays', heading_texts( $r2 ), true ), $r2 );
	check( 'folded: questions split' . $tag, in_array( 'What type of camping suits a beginner?', heading_texts( $r2 ), true ) && in_array( 'Do I need expensive camping gear for a first camping holiday?', heading_texts( $r2 ), true ), $r2 );
	check( 'folded: no long heading' . $tag, headings_short( $r2 ), $r2 );
}

// 3. 5 Nov 2026, Vinrejse til Italien: H3 + paragraph in one classic block (2.3.2 case).
$c3 = "<h3>Fire vinegioner på cirka ti dage\n\nRuten starter i Piemonte og slutter i Toscana, med tid til at smage.</h3>\n\n<p>Mere tekst.</p>";
$r3 = LMGT_Headfix::repair( $c3 );
check( '2.3.2 case: heading closed', strpos( $r3, '<h3>Fire vinegioner på cirka ti dage</h3>' ) !== false, $r3 );
check( '2.3.2 case: paragraph kept', strpos( $r3, 'Ruten starter i Piemonte' ) !== false && balanced( $r3 ), $r3 );

// 4. Block editor heading that swallowed a paragraph.
$c4 = "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Hvornår skal man rejse\n\nForår og efterår er bedst, fordi der er færre turister og lavere priser.</h2>\n<!-- /wp:heading -->";
$r4 = LMGT_Headfix::repair( $c4 );
check( 'block heading: split into heading + paragraph block', strpos( $r4, '<h2 class="wp-block-heading">Hvornår skal man rejse</h2>' ) !== false && strpos( $r4, '<!-- wp:paragraph -->' ) !== false, $r4 );

// 5. H2 never closed, runs into the next section (2.3.2 used to strip every <p> on its way).
$c5 = "<h2>Practical information\n\nBring cash.\n\n<h2>Getting there</h2>\n<p>Fly to Rome.</p>\n<p>Then take the train.</p>";
$r5 = LMGT_Headfix::repair( $c5 );
check( 'unclosed H2: closed at blank line', strpos( $r5, '<h2>Practical information</h2>' ) !== false && balanced( $r5 ), $r5 );
check( 'unclosed H2: later paragraphs keep their tags', substr_count( $r5, '<p>' ) === 3, $r5 );

// 6. Every heading level.
for ( $l = 1; $l <= 6; $l++ ) {
	$r = LMGT_Headfix::repair( "<h$l>Title\n\nThis paragraph was swallowed by the heading and must come out.</h$l>" );
	check( "H$l closed", strpos( $r, "<h$l>Title</h$l>" ) !== false, $r );
}

// 7. Orphan close: <h3>Q\n\nA</p></h3> style leftovers do not leave a stray </h3>.
$r7 = LMGT_Headfix::repair( "<h3>Question\n\nAnswer here.</h3><p>Next.</p>" );
check( 'stray close removed', balanced( $r7 ) && substr_count( $r7, '</h3>' ) === 1, $r7 );

// 8. Clean pages never change.
$clean = array(
	"<h2>Clean heading</h2>\n<p>Text.</p>\n<h3>Sub <em>head</em></h3><p>More.</p>",
	"<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Block heading</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p>Text.</p>\n<!-- /wp:paragraph -->",
	'<h2>Two-line<br>headline</h2><p>Body</p>',
	'<div class="lmgt-box lmgt-faq" data-lmgt="faq"><h2>Know before you go: Rome</h2><h3>Is Rome safe?</h3><p>Yes, mostly.</p><h3>Do I need a visa?</h3><p>Not from the EU.</p></div>',
	"<div class=\"lmgt-box lmgt-faq\" data-lmgt=\"faq\">\n<h2>Værd at vide om Italien før du rejser</h2>\n<h3>Hvornår er det bedst at rejse?</h3>\n<p>Forår og efterår.</p>\n</div>",
	'<header><h1 class="t">Site</h1></header><hr><h4>Short?</h4><p>Yes.</p>',
);
foreach ( $clean as $i => $h ) check( 'clean page ' . ( $i + 1 ) . ' unchanged', LMGT_Headfix::fix_all( $h, 'Rome' ) === $h, LMGT_Headfix::fix_all( $h, 'Rome' ) );

// 9. Live 23 Nov 10:18: the editor folded three questions into the title H2, one per line.
$c9 = "<div class=\"lmgt-box lmgt-faq\" data-lmgt=\"faq\"><h2>Know before you go: Everything About Camping Holidays Do I need expensive camping gear for a first camping holiday? No. You don&#039;t need to buy expensive expedition gear to sleep one night in a tent.\nWhat type of camping suits a beginner? Campsites are the safe start, offering facilities such as toilets, showers and a kitchen.\nHow much could a camping holiday save compared with a hotel?\nA campsite in Tuscany costs €20-40 per night for a family, while a hotel costs €150-300.</h2><h3>Is wild camping allowed everywhere?</h3><p>No. In Norway you must keep 150m from the nearest house.</p></div>";
$r9 = LMGT_Headfix::fix_all( $c9, $place );
check( 'folded lines: 4 questions', count( preg_grep( '/\?$/', heading_texts( $r9 ) ) ) === 4, $r9 );
check( 'folded lines: answer of Q3 kept', strpos( $r9, '<p>A campsite in Tuscany costs €20-40' ) !== false, $r9 );

// 10. Å is bytes C3 85; \x85 must never count as a line break (Sweden box lost "Summer suits … Å").
$c10 = "<div class=\"lmgt-box lmgt-faq\" data-lmgt=\"faq\"><h2>Know before you go: Sweden</h2><h3>When is the best time to visit Sweden?</h3><p>Summer suits the archipelago. Winter suits the ski resorts of Åre and Sälen.</p></div>";
check( 'Å safe', LMGT_Headfix::fix_all( $c10, 'Sweden' ) === $c10, LMGT_Headfix::fix_all( $c10, 'Sweden' ) );
$c10b = "<h2>Åre\n\nÅre is a ski resort in Jämtland with many long runs for every level.</h2>";
check( 'Å safe in repair', strpos( LMGT_Headfix::repair( $c10b ), '<h2>Åre</h2>' ) !== false, LMGT_Headfix::repair( $c10b ) );

// 11. Broken encoding: never touched.
$c11 = "<h2>Bad \xC3 bytes\n\nText that would otherwise be split out of the heading.</h2>";
check( 'invalid UTF-8 unchanged', LMGT_Headfix::fix_all( $c11 ) === $c11 );

// 12. Double close left by an editor: <h2>X</h2>\n</h2>.
$c12 = "<h2 class=\"wp-block-heading\">Guide to Travel in Nigeria</h2>\n</h2>\n\nOne of Africa's largest countries.";
check( 'double close removed', substr_count( LMGT_Headfix::fix_all( $c12 ), '</h2>' ) === 1 );

echo $fail ? "\n$fail FAILED\n" : "\nAll passed\n";
exit( $fail ? 1 : 0 );
