<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Each language's front page: /en/, /sv/ … on page 1.
 *
 * Built, not translated. The source front page is made of moving parts (newest
 * posts, hero, category blocks), so a translated copy would be stale by the
 * next post and would link to source-language articles. Instead the page is
 * assembled from what exists in that language:
 *   - hero: the source front page's image, a fixed line in the language
 *   - guides: translated pages (country and pillar guides), A–Z
 *   - latest: the newest translated articles
 * It grows by itself as translations are published. /en/page/2/ onward stays
 * the plain listing.
 *
 * The source front page and each language front page point at each other with
 * hreflang once a language has enough to stand on (lmgt_front_min, default 3).
 */
class LMGT_LangFront {

	const LATEST = 24;

	public static function boot() {
		add_filter( 'template_include', array( __CLASS__, 'template' ), 100 );
		add_action( 'pre_get_posts', array( __CLASS__, 'per_page' ) );
		add_action( 'wp_head', array( __CLASS__, 'hreflang' ), 2 );
		add_action( 'transition_post_status', array( __CLASS__, 'purge' ), 20, 3 );
	}

	public static function enabled() {
		return get_option( 'lmgt_lang_front', '1' ) === '1';
	}

	/** Page 1 of a language listing. */
	public static function is_front() {
		return self::enabled() && get_query_var( 'lmgt_lang_home' ) && max( 1, (int) get_query_var( 'paged' ) ) === 1;
	}

	/** Listing pages after the front hold as many as the front shows, so page 2 continues where it stops. */
	public static function per_page( $q ) {
		if ( self::enabled() && $q->is_main_query() && $q->get( 'lmgt_lang_home' ) ) $q->set( 'posts_per_page', self::LATEST );
	}

	public static function template( $template ) {
		if ( ! self::is_front() || is_404() ) return $template;
		return LMGT_DIR . 'templates/lang-front.php';
	}

	/** Published translations in $lang: guides (translated pages) or articles (everything else). */
	public static function items( $lang, $guides, $limit ) {
		$type = array( 'key' => '_lmgt_source_type', 'value' => 'page' );
		if ( ! $guides ) {
			$type = array( 'relation' => 'OR', array( 'key' => '_lmgt_source_type', 'value' => 'page', 'compare' => '!=' ), array( 'key' => '_lmgt_source_type', 'compare' => 'NOT EXISTS' ) );
		}
		return get_posts( array(
			'post_type'        => LMGT_Store::types( true ),
			'post_status'      => 'publish',
			'posts_per_page'   => $limit,
			'orderby'          => $guides ? 'title' : 'date',
			'order'            => $guides ? 'ASC' : 'DESC',
			'lmgt_all'         => true,
			'suppress_filters' => false,
			// On .dk, copies that now live on .travel are no longer listed (2.2.16).
			'meta_query'       => LMGT_Bridge::is_source() ? array( array( 'key' => '_lmgt_lang', 'value' => $lang ), $type, array( 'key' => '_lmgt_moved_to', 'compare' => 'NOT EXISTS' ) ) : array( array( 'key' => '_lmgt_lang', 'value' => $lang ), $type ),
		) );
	}

	/** Card text: the meta description, which is written to be read alone; the opening words only as a fallback. */
	public static function blurb( $post ) {
		$d = trim( (string) get_post_meta( $post->ID, 'rank_math_description', true ) );
		if ( $d !== '' && strpos( $d, '%' ) === false && strpos( $d, '{' ) === false ) return $d;
		if ( has_excerpt( $post ) ) return get_the_excerpt( $post );
		// Paragraphs only: the opening heading would otherwise run into the first sentence.
		$html = preg_replace( '#<h[1-6][^>]*>.*?</h[1-6]>#is', ' ', $post->post_content );
		$text = preg_match_all( '#<p[^>]*>(.*?)</p>#is', $html, $m ) ? implode( ' ', $m[1] ) : $html;
		return wp_trim_words( LMGT_Text::plain( $text ), 26, '…' );
	}

	/** The source front page's image, or the first guide's. */
	public static function hero_image( $guides ) {
		$front = (int) get_option( 'page_on_front' );
		$img   = $front ? get_post_thumbnail_id( $front ) : 0;
		if ( ! $img && $guides ) $img = get_post_thumbnail_id( $guides[0] );
		return $img;
	}

	/** Fixed words on the language front page, in that language. */
	public static function t( $lang, $key ) {
		$t = array(
			'en' => array( 'kicker' => 'Travel with soul', 'lead' => 'Destination guides and travel stories, written by people who have been there.', 'guides' => 'Destination guides', 'latest' => 'Latest articles', 'more' => 'All articles in English' ),
			'de' => array( 'kicker' => 'Reisen mit Seele', 'lead' => 'Reiseführer und Reisegeschichten, geschrieben von Menschen, die dort waren.', 'guides' => 'Reiseführer', 'latest' => 'Neueste Artikel', 'more' => 'Alle Artikel auf Deutsch' ),
			'sv' => array( 'kicker' => 'Resor med själ', 'lead' => 'Reseguider och reseberättelser, skrivna av människor som har varit där.', 'guides' => 'Reseguider', 'latest' => 'Senaste artiklarna', 'more' => 'Alla artiklar på svenska' ),
			'nb' => array( 'kicker' => 'Reiser med sjel', 'lead' => 'Reiseguider og reisefortellinger, skrevet av folk som har vært der.', 'guides' => 'Reiseguider', 'latest' => 'Nyeste artikler', 'more' => 'Alle artikler på norsk' ),
			'fi' => array( 'kicker' => 'Matkoja sielulla', 'lead' => 'Matkaoppaita ja matkakertomuksia ihmisiltä, jotka ovat käyneet paikan päällä.', 'guides' => 'Matkaoppaat', 'latest' => 'Uusimmat artikkelit', 'more' => 'Kaikki artikkelit suomeksi' ),
			'fr' => array( 'kicker' => 'Voyager avec âme', 'lead' => 'Guides de destination et récits de voyage, écrits par des gens qui y sont allés.', 'guides' => 'Guides de destination', 'latest' => 'Derniers articles', 'more' => 'Tous les articles en français' ),
			'es' => array( 'kicker' => 'Viajar con alma', 'lead' => 'Guías de destino e historias de viaje, escritas por gente que ha estado allí.', 'guides' => 'Guías de destino', 'latest' => 'Últimos artículos', 'more' => 'Todos los artículos en español' ),
			'pt' => array( 'kicker' => 'Viajar com alma', 'lead' => 'Guias de destino e histórias de viagem, escritos por quem já esteve lá.', 'guides' => 'Guias de destino', 'latest' => 'Artigos mais recentes', 'more' => 'Todos os artigos em português' ),
			'it' => array( 'kicker' => 'Viaggiare con anima', 'lead' => 'Guide di viaggio e racconti, scritti da chi ci è stato.', 'guides' => 'Guide di viaggio', 'latest' => 'Ultimi articoli', 'more' => 'Tutti gli articoli in italiano' ),
			'da' => array( 'kicker' => 'Rejser med sjæl', 'lead' => 'Rejseguider og rejsehistorier, skrevet af folk, der har været der.', 'guides' => 'Rejseguider', 'latest' => 'Nyeste artikler', 'more' => 'Alle artikler på dansk' ),
		);
		$set = isset( $t[ $lang ] ) ? $t[ $lang ] : $t['en'];
		return isset( $set[ $key ] ) ? $set[ $key ] : '';
	}

	/** [code => url] for the source front page and every language front page with enough content. */
	public static function set() {
		$min = max( 1, (int) get_option( 'lmgt_front_min', 3 ) );
		$out = array( LMGT_Langs::source() => home_url( '/' ) );
		foreach ( LMGT_Front::published_counts() as $code => $n ) {
			if ( $n < $min || ! LMGT_Langs::get( $code ) || $code === LMGT_Langs::source() ) continue;
			$url = LMGT_Front::lang_home_url( $code );
			if ( $url ) $out[ $code ] = $url;
		}
		return count( $out ) > 1 ? $out : array();
	}

	public static function hreflang() {
		if ( ! self::enabled() || lmgt_legacy_active() || LMGT_Bridge::on() ) return;
		$lang = get_query_var( 'lmgt_lang_home' );
		if ( $lang ? ! self::is_front() : ! is_front_page() ) return;
		$set = self::set();
		if ( ! $set || ( $lang && ! isset( $set[ $lang ] ) ) ) return;
		foreach ( $set as $code => $url ) {
			echo '<link rel="alternate" hreflang="' . esc_attr( LMGT_Langs::get( $code )['hreflang'] ) . '" href="' . esc_url( $url ) . '" />' . "\n";
		}
		echo '<link rel="alternate" hreflang="x-default" href="' . esc_url( $set[ LMGT_Langs::source() ] ) . '" />' . "\n";
	}

	/** A version published or withdrawn changes its language front page and the source front page's hreflang. */
	public static function purge( $new, $old, $post ) {
		if ( ( $old !== 'publish' && $new !== 'publish' ) || ! get_post_meta( $post->ID, '_lmgt_lang', true ) ) return;
		wp_cache_delete( 'lmgt_counts', 'lmgt' );
		$url = LMGT_Front::lang_home_url( get_post_meta( $post->ID, '_lmgt_lang', true ) );
		if ( $url ) do_action( 'litespeed_purge_url', $url );
		do_action( 'litespeed_purge_url', home_url( '/' ) );
	}
}
