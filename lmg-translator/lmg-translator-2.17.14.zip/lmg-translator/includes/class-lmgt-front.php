<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * What readers and Google see.
 *
 * The hreflang contract, as Google documents it, is enforced in one function
 * (cluster()) that both the original and every translation call, so the two
 * sides can never disagree:
 *   - only PUBLISHED versions are listed — never drafts, never ?lang= addresses
 *   - every version lists every other version AND itself
 *   - x-default points at the original
 *   - nothing at all is printed on a page that has no published translation
 * Each translation is its own canonical, and declares its own language in
 * <html lang>, og:locale and the JSON-LD inLanguage.
 */
class LMGT_Front {

	public static function boot() {
		add_action( 'parse_request', array( __CLASS__, 'route' ), 1 );
		add_filter( 'template_include', array( __CLASS__, 'template' ), 99 );
		add_filter( 'option_theme_mods_' . get_option( 'stylesheet' ), array( __CLASS__, 'theme_mods_as_source' ) );
		add_filter( 'get_post_metadata', array( __CLASS__, 'theme_meta_from_source' ), 10, 4 );
		add_filter( 'kadence_theme_options_defaults', array( __CLASS__, 'theme_defaults' ) );
		add_filter( 'kadence_dynamic_css', array( __CLASS__, 'css_as_source' ), 1 );
		add_filter( 'kadence_dynamic_css', array( __CLASS__, 'css_restore' ), 9999 );
		add_action( 'template_redirect', array( __CLASS__, 'hero_class' ), 99 );
		add_filter( 'pre_do_shortcode_tag', array( __CLASS__, 'source_only_shortcodes' ), 10, 2 );
		add_filter( 'language_attributes', array( __CLASS__, 'html_lang' ), 20 );
		add_action( 'wp_head', array( __CLASS__, 'hreflang' ), 2 );
		add_action( 'wp_footer', array( __CLASS__, 'switcher' ), 60 );
		add_filter( 'the_content', array( __CLASS__, 'localise_links' ), 20 );
		add_filter( 'rank_math/opengraph/facebook/og_locale', array( __CLASS__, 'og_locale' ) );
		add_filter( 'rank_math/json_ld', array( __CLASS__, 'json_ld' ), 99, 2 );
		add_action( 'template_redirect', array( __CLASS__, 'one_address' ), 1 );
		add_action( 'pre_get_posts', array( __CLASS__, 'hide_tagged' ) );
		add_action( 'parse_query', array( __CLASS__, 'lang_home_flags' ) );
		add_filter( 'redirect_canonical', function ( $url ) { return get_query_var( 'lmgt_lang_home' ) ? false : $url; } );
		add_filter( 'get_the_archive_title', array( __CLASS__, 'lang_home_title' ) );
		add_filter( 'document_title_parts', function ( $parts ) {
			if ( get_query_var( 'lmgt_lang_home' ) ) $parts['title'] = self::lang_home_title( '' );
			return $parts;
		} );
		add_filter( 'rank_math/frontend/title', function ( $t ) { return get_query_var( 'lmgt_lang_home' ) ? self::lang_home_title( '' ) . ' - ' . get_bloginfo( 'name' ) : $t; } );
		// One canonical on language listings, printed here so it exists with or without Rank Math.
		add_filter( 'rank_math/frontend/canonical', function ( $c ) { return get_query_var( 'lmgt_lang_home' ) ? '' : $c; } );
		add_action( 'wp_head', function () {
			$l = get_query_var( 'lmgt_lang_home' );
			if ( ! $l ) return;
			$paged = max( 1, (int) get_query_var( 'paged' ) );
			$url   = $paged > 1 ? home_url( user_trailingslashit( LMGT_Langs::get( $l )['prefix'] . '/page/' . $paged ) ) : self::lang_home_url( $l );
			if ( LMGT_Bridge::is_source() && LMGT_Bridge::peer_lang_home( $l ) ) $url = LMGT_Bridge::peer_lang_home( $l ); // brief 4.6: .dk language front pages point to .travel's, once it has one
			echo '<link rel="canonical" href="' . esc_url( $url ) . '" />' . "\n";
		}, 3 );
		add_filter( 'body_class', function ( $c ) {
			$l = self::current_lang();
			if ( $l ) $c[] = 'lmgt-lang-' . $l;
			return $c;
		} );
	}

	/**
	 * /sv/<slug>/ → that Swedish translation, if one is published (or the viewer
	 * may preview it). Anything else under the prefix — /fi/ itself, the Finnish
	 * departure page's children, old 410 paths — is left to WordPress untouched.
	 */
	public static function route( $wp ) {
		if ( is_admin() ) return;
		$path = trim( (string) $wp->request, '/' );
		if ( preg_match( '#^([a-z]{2})(?:/page/(\d+))?$#', $path, $m ) ) {
			self::route_lang_home( $wp, $m );
			return;
		}
		if ( ! preg_match( '#^([a-z]{2})/([^/]+)$#', $path, $m ) ) return;
		$lang = LMGT_Langs::by_prefix( $m[1] );
		if ( ! $lang || $lang === LMGT_Langs::source() ) return;
		$statuses = current_user_can( 'edit_others_posts' ) ? array( 'publish', 'draft', 'pending', 'private', 'future' ) : array( 'publish' );
		$id = LMGT_Store::find( $lang, sanitize_title( urldecode( $m[2] ) ), $statuses );
		if ( ! $id ) return;
		$wp->query_vars = array( 'post_type' => LMGT_CPT, 'p' => $id );
		if ( get_post_status( $id ) !== 'publish' ) $wp->query_vars['preview'] = 'true';
	}

	/**
	 * /sv/ → every published Swedish version on this site, newest first: the
	 * page the switcher opens from the front page and other listings. Only when
	 * no real page lives at /sv/ (on traveltalk.dk /no/ and /fi/ are departure
	 * pages, and stay so). A language with nothing published answers 404.
	 */
	private static function route_lang_home( $wp, $m ) {
		$lang = LMGT_Langs::by_prefix( $m[1] );
		if ( ! $lang || $lang === LMGT_Langs::source() || ! self::lang_home_url( $lang ) ) return;
		$counts = self::published_counts();
		if ( empty( $counts[ $lang ] ) ) return;
		$wp->query_vars = array(
			'post_type'       => LMGT_Store::types( true ),
			'meta_key'        => '_lmgt_lang',
			'meta_value'      => $lang,
			'lmgt_all'        => true,
			'lmgt_lang_home'  => $lang,
			'paged'           => isset( $m[2] ) ? (int) $m[2] : 0,
		);
	}

	/** A listing, not the blog home: keeps themes from drawing the front-page layout. */
	public static function lang_home_flags( $q ) {
		if ( ! $q->is_main_query() || ! $q->get( 'lmgt_lang_home' ) ) return;
		$q->is_home       = false;
		$q->is_front_page = false;
		$q->is_archive    = true;
	}

	public static function lang_home_title( $title ) {
		$code = get_query_var( 'lmgt_lang_home' );
		$t = array( 'da' => 'Artikler på dansk', 'en' => 'Articles in English', 'de' => 'Artikel auf Deutsch', 'fr' => 'Articles en français', 'es' => 'Artículos en español', 'pt' => 'Artigos em português', 'it' => 'Articoli in italiano', 'sv' => 'Artiklar på svenska', 'nb' => 'Artikler på norsk', 'fi' => 'Artikkelit suomeksi' );
		if ( isset( $t[ $code ] ) ) return $t[ $code ];
		$l = LMGT_Langs::get( $code );
		return $l ? $l['native'] : $title;
	}

	/** /sv/ for a language, or '' when a real page already owns that address. */
	public static function lang_home_url( $lang ) {
		$l = LMGT_Langs::get( $lang );
		$prefix = LMGT_Bridge::on() ? LMGT_Bridge::prefix( $lang ) : ( $l ? $l['prefix'] : '' );
		if ( ! $l || $prefix === '' || get_page_by_path( $prefix ) ) return '';
		return home_url( user_trailingslashit( $prefix ) );
	}

	/** Published versions per language on this site, translations and tagged posts. */
	public static function published_counts() {
		global $wpdb;
		$c = wp_cache_get( 'lmgt_counts', 'lmgt' );
		if ( is_array( $c ) ) return $c;
		$rows = $wpdb->get_results( "SELECT m.meta_value AS lang, COUNT(*) AS n FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id
			WHERE m.meta_key = '_lmgt_lang' AND p.post_status = 'publish' GROUP BY m.meta_value" );
		$c = array();
		foreach ( $rows as $r ) $c[ $r->lang ] = (int) $r->n;
		wp_cache_set( 'lmgt_counts', $c, 'lmgt', 300 );
		return $c;
	}

	/**
	 * One address per translation. ?lmgt_translation=… and ?p=… reach the same
	 * post; they 301 to /sv/<slug>/ so Google never sees a second copy.
	 */
	public static function one_address() {
		if ( ! is_singular( LMGT_CPT ) || is_preview() ) return;
		$id = get_queried_object_id();
		if ( get_post_status( $id ) !== 'publish' ) return;
		$want = get_permalink( $id );
		$path = wp_parse_url( $want, PHP_URL_PATH );
		$req  = wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '', PHP_URL_PATH );
		$q    = wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '', PHP_URL_QUERY );
		if ( $req !== $path || ( $q && preg_match( '/(^|&)(lmgt_translation|p|post_type)=/', $q ) ) ) {
			wp_safe_redirect( $want, 301 );
			exit;
		}
	}

	/** The template the original would have used: page.php for pages, single.php for posts. */
	public static function template( $template ) {
		if ( ! is_singular( LMGT_CPT ) ) return $template;
		$id   = get_queried_object_id();
		$type = get_post_meta( $id, '_lmgt_source_type', true );
		if ( $type === 'page' ) {
			$slug = get_post_meta( $id, '_lmgt_page_template', true );
			$cand = array();
			if ( $slug && $slug !== 'default' ) $cand[] = $slug;
			$cand = array_merge( $cand, array( 'page.php', 'singular.php', 'index.php' ) );
		} else {
			$cand = array( 'single-post.php', 'single.php', 'singular.php', 'index.php' );
		}
		$found = locate_template( $cand );
		return $found ? $found : $template;
	}

	/** 'page' or 'post' when a translation is being viewed, else ''. */
	private static function viewed_source_type() {
		if ( is_admin() || ! did_action( 'wp' ) || ! is_singular( LMGT_CPT ) ) return '';
		$type = get_post_meta( get_queried_object_id(), '_lmgt_source_type', true );
		return in_array( $type, array( 'page', 'post' ), true ) ? $type : '';
	}

	/**
	 * Theme settings kept per post type (Kadence: page_title_layout, page_title_height
	 * ...) are read as the original's type, so a translated page gets the same hero.
	 */
	public static function theme_mods_as_source( $mods ) {
		$type = is_array( $mods ) ? self::viewed_source_type() : '';
		if ( ! $type ) return $mods;
		$from = $type . '_';
		$to   = LMGT_CPT . '_';
		foreach ( $mods as $k => $v ) {
			if ( strpos( $k, $from ) === 0 ) $mods[ $to . substr( $k, strlen( $from ) ) ] = $v;
		}
		return $mods;
	}

	/**
	 * Kadence's per-page layout fields (_kad_*): what is set on the translation
	 * itself wins; anything left at default comes from the original. Where the
	 * original uses the theme default too, the default for its type is used.
	 */
	public static function theme_meta_from_source( $value, $id, $key, $single ) {
		static $busy = false;
		if ( $busy || strpos( (string) $key, '_kad_' ) !== 0 || get_post_type( $id ) !== LMGT_CPT || is_admin() ) return $value;
		$busy = true;
		$own  = get_post_meta( $id, $key, true );
		$busy = false;
		if ( $own !== '' && $own !== 'default' && $own !== array() ) return $value;
		$src = (int) get_post_meta( $id, '_lmgt_source', true );
		if ( ! $src ) return $value;
		$v = get_post_meta( $src, $key, true );
		if ( $key === '_kad_post_title' && ( $v === '' || $v === 'default' ) && function_exists( '\Kadence\kadence' ) ) {
			$type = get_post_type( $src );
			$v    = \Kadence\kadence()->option( $type . '_title' ) === false ? 'hide' : \Kadence\kadence()->option( $type . '_title_layout' );
		}
		return array( $v );
	}

	/**
	 * Kadence keeps its defaults per post type and only knows page_* and post_*.
	 * Translations take the page defaults (the hero of a pillar page); saved
	 * settings follow the original's type through theme_mods_as_source.
	 */
	public static function theme_defaults( $d ) {
		if ( ! is_array( $d ) ) return $d;
		foreach ( $d as $k => $v ) {
			if ( strpos( $k, 'page_' ) === 0 ) $d[ LMGT_CPT . '_' . substr( $k, 5 ) ] = $v;
		}
		return $d;
	}

	/**
	 * Kadence writes the hero styles (height, overlay, featured image as
	 * background) only for real pages and posts. While it builds them, the
	 * translation is shown to it as its original's type; restored right after.
	 */
	private static $swap = null;

	public static function css_as_source( $css ) {
		$type = self::viewed_source_type();
		if ( ! $type || self::$swap ) return $css;
		global $wp_query, $post;
		$obj        = $wp_query->get_queried_object();
		self::$swap = array( $wp_query->is_page, $wp_query->is_single, $obj, $obj ? $obj->post_type : '', $post, $post ? $post->post_type : '' );
		$wp_query->is_page   = $type === 'page';
		$wp_query->is_single = $type !== 'page';
		if ( $obj instanceof WP_Post ) $obj->post_type = $type;
		if ( $post instanceof WP_Post ) $post->post_type = $type;
		return $css;
	}

	public static function css_restore( $css ) {
		if ( ! self::$swap ) return $css;
		global $wp_query;
		list( $wp_query->is_page, $wp_query->is_single, $obj, $obj_type, $p, $p_type ) = self::$swap;
		if ( $obj instanceof WP_Post ) $obj->post_type = $obj_type;
		if ( $p instanceof WP_Post ) $p->post_type = $p_type;
		self::$swap = null;
		return $css;
	}

	/** The hero carries the original type's class too, so the theme's page/post hero styles apply. */
	public static function hero_class() {
		$type = self::viewed_source_type();
		if ( ! $type ) return;
		ob_start( function ( $html ) use ( $type ) {
			// The hero and its title box carry the original type's classes too, so the
			// theme's hero styles and title colours (white on the photo) apply.
			return str_replace(
				array( LMGT_CPT . '-hero-section', 'entry-header ' . LMGT_CPT . '-title' ),
				array( $type . '-hero-section ' . LMGT_CPT . '-hero-section', 'entry-header ' . $type . '-title ' . LMGT_CPT . '-title' ),
				$html
			);
		} );
	}

	/** Shortcodes that only exist in the source language print nothing on a translation. */
	public static function source_only_shortcodes( $out, $tag ) {
		return in_array( $tag, array( 'lmg_match' ), true ) && self::viewed_source_type() ? '' : $out;
	}

	/**
	 * Hand-written translations tagged on ordinary posts stay published at their
	 * own address but leave every listing: front page, archives, categories,
	 * feeds, search and post grids. Single views, the editor, REST, explicit
	 * post__in lists and the plugin's own lookups (lmgt_all) are left alone.
	 * Rank Math builds its sitemap with its own SQL, so the posts stay in it.
	 */
	public static function hide_tagged( $q ) {
		if ( $q->is_singular() || $q->get( 'lmgt_all' ) || $q->get( 'post__in' ) ) return;
		if ( ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( is_admin() && ! wp_doing_ajax() ) ) return;
		if ( wp_doing_ajax() && strpos( (string) wp_get_referer(), admin_url() ) === 0 ) return;
		$ids = LMGT_Store::tagged();
		if ( ! $ids ) return;
		$q->set( 'post__not_in', array_merge( (array) $q->get( 'post__not_in' ), $ids ) );
	}

	/**
	 * On a translation, a link to one of our own articles points at that
	 * article's version in the same language once it is published, and at the
	 * original until then. Done when the page is shown, so links switch by
	 * themselves as more articles are translated; nothing is stored.
	 */
	public static function localise_links( $content ) {
		$lang = self::current_lang();
		if ( ! $lang || get_query_var( 'lmgt_lang_home' ) || strpos( $content, 'href=' ) === false ) return $content;
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		$map  = array();
		return preg_replace_callback( '/href="([^"#?]+)([^"]*)"/', function ( $m ) use ( $lang, $host, &$map ) {
			$url = $m[1];
			if ( wp_parse_url( $url, PHP_URL_HOST ) !== $host || count( $map ) > 80 ) return $m[0];
			if ( ! isset( $map[ $url ] ) ) {
				$map[ $url ] = '';
				$pid = url_to_postid( $url );
				if ( $pid && ! LMGT_Store::is_translation( $pid ) ) {
					$set = LMGT_Store::of( $pid, array( 'publish' ) );
					if ( isset( $set[ $lang ] ) ) $map[ $url ] = get_permalink( $set[ $lang ] );
				}
			}
			return $map[ $url ] ? 'href="' . esc_url( $map[ $url ] ) . $m[2] . '"' : $m[0];
		}, $content );
	}

	/** Language of the page being viewed, or null on originals. */
	public static function current_lang() {
		$home = get_query_var( 'lmgt_lang_home' );
		if ( $home ) return $home;
		if ( ! is_singular() ) return null;
		$id = get_queried_object_id();
		if ( ! LMGT_Store::is_translation( $id ) ) return null;
		$l = get_post_meta( $id, '_lmgt_lang', true );
		return LMGT_Langs::get( $l ) ? $l : null;
	}

	public static function html_lang( $out ) {
		$l = self::current_lang();
		if ( ! $l ) return $out;
		$h = LMGT_Bridge::hreflang_code( $l );
		return preg_match( '/lang="[^"]*"/', $out ) ? preg_replace( '/lang="[^"]*"/', 'lang="' . $h . '"', $out ) : trim( $out . ' lang="' . $h . '"' );
	}

	public static function og_locale( $locale ) {
		$l = self::current_lang();
		return $l ? LMGT_Langs::get( $l )['locale'] : $locale;
	}

	public static function json_ld( $data, $jsonld = null ) {
		$l = self::current_lang();
		if ( ! $l || ! is_array( $data ) ) return $data;
		$h = LMGT_Bridge::hreflang_code( $l );
		array_walk_recursive( $data, function ( &$v, $k ) use ( $h ) {
			if ( $k === 'inLanguage' ) $v = $h;
		} );
		return $data;
	}

	/**
	 * The published versions of the page being viewed: [code => url], source
	 * first. Empty when the page has no published translation.
	 */
	public static function cluster() {
		if ( LMGT_Bridge::on() && ! self::target_local() ) {
			$set = LMGT_Bridge::current_set();
			return $set ? $set['members'] : array();
		}
		if ( ! is_singular() ) return array();
		$id = get_queried_object_id();
		if ( LMGT_Store::is_translation( $id ) ) {
			if ( get_post_status( $id ) !== 'publish' ) return array();
			$source = (int) get_post_meta( $id, '_lmgt_source', true );
		} else {
			$source = $id;
		}
		$src = get_post( $source );
		if ( ! $src || $src->post_status !== 'publish' || ! in_array( $src->post_type, LMGT_Store::types(), true ) ) return array();
		if ( (int) get_option( 'page_on_front' ) === $source ) return array();

		$out = array( LMGT_Langs::source() => get_permalink( $source ) );
		foreach ( LMGT_Store::of( $source, array( 'publish' ) ) as $lang => $tid ) {
			if ( LMGT_Langs::get( $lang ) && ! LMGT_Store::is_thin( $tid ) ) $out[ $lang ] = get_permalink( $tid );
		}
		return count( $out ) > 1 ? $out : array();
	}

	/**
	 * On .travel, a page outside the bridge: one of its own English pages, or a
	 * translation of one made here. Its set is built here, as on one site; the
	 * bridge set covers only .dk originals and their members (2.1.4).
	 */
	private static function target_local() {
		if ( ! LMGT_Bridge::is_target() || ! is_singular() ) return false;
		$id = get_queried_object_id();
		if ( get_post_meta( $id, '_lmgt_remote_source', true ) ) return false;
		$src = LMGT_Store::is_translation( $id ) ? (int) get_post_meta( $id, '_lmgt_source', true ) : $id;
		return ! get_post_meta( $src, '_lmgt_remote_source', true );
	}

	public static function hreflang() {
		if ( lmgt_legacy_active() ) return;
		if ( LMGT_Bridge::on() && ! self::target_local() ) {
			$set = LMGT_Bridge::current_set();
			if ( $set ) LMGT_Bridge::print_set( $set );
			return;
		}
		$set = self::cluster();
		if ( ! $set ) return;
		$src = LMGT_Langs::source();
		foreach ( $set as $lang => $url ) {
			echo '<link rel="alternate" hreflang="' . esc_attr( LMGT_Bridge::hreflang_code( $lang ) ) . '" href="' . esc_url( $url ) . '" />' . "\n";
		}
		echo '<link rel="alternate" hreflang="x-default" href="' . esc_url( $set[ $src ] ) . '" />' . "\n";
	}

	/**
	 * "Sprogvalg" in the lower-left corner on every article. Versions that exist
	 * link to their own address. A language without a translation links to the
	 * original with a #fragment, which opens a one-line "not yet translated"
	 * notice: the same URL to Google, so no duplicate page ever exists. No script.
	 */
	public static function switcher() {
		if ( get_option( 'lmgt_switcher', '1' ) !== '1' || is_404() ) return;
		$src_lang = LMGT_Langs::source();
		$cur      = self::current_lang() ?: $src_lang;
		$id       = is_singular() && ! is_front_page() ? get_queried_object_id() : 0;

		if ( $id ) {
			// An article: each version, or the original with the notice.
			if ( ! in_array( get_post_type( $id ), LMGT_Store::types( true ), true ) ) return;
			if ( LMGT_Bridge::is_target() && get_post_meta( $id, '_lmgt_remote_source', true ) ) {
				// A .dk translation on .travel: its set (the Danish original included), then language front pages.
				$set  = self::cluster();
				if ( ! $set ) $set = array( $cur => get_permalink( $id ) );
				$base = '';
			} else {
				$source = LMGT_Store::is_translation( $id ) ? (int) get_post_meta( $id, '_lmgt_source', true ) : $id;
				if ( get_post_status( $source ) !== 'publish' ) return;
				$set  = self::cluster();
				$base = get_permalink( $source );
			}
		} else {
			// Front page and other listings: each language's own listing, if it has anything.
			$set = array( $src_lang => home_url( '/' ) );
			foreach ( self::published_counts() as $code => $n ) {
				$url = $n ? self::lang_home_url( $code ) : '';
				if ( $url && LMGT_Langs::get( $code ) ) $set[ $code ] = $url;
			}
			if ( LMGT_Bridge::is_target() && LMGT_Bridge::peer() ) $set['da'] = LMGT_Bridge::peer_front();
			// 2.2.23: on traveltalk.dk a language that traveltalk.travel has goes to .travel's language front page; the language pages left on .dk serve only a language .travel does not have.
			if ( LMGT_Bridge::is_source() ) {
				foreach ( array_keys( LMGT_Langs::all() ) as $code ) {
					$to = $code === $src_lang ? '' : LMGT_Bridge::peer_lang_home( $code );
					if ( $to ) $set[ $code ] = $to;
				}
			}
			$base = home_url( '/' );
		}
		$langs = array_unique( array_merge( array( $src_lang ), LMGT_Langs::enabled(), array_keys( $set ) ) );

		$items     = '';
		$notes     = '';
		$counts    = self::published_counts();
		$newwin    = get_option( 'lmgt_switcher_newwin', '1' ) === '1';
		$is_target = LMGT_Bridge::is_target();
		$site      = '';
		foreach ( $langs as $code ) {
			$l = LMGT_Langs::get( $code );
			if ( ! $l ) continue;
			$is = $code === $cur;
			if ( $base === '' && ! isset( $set[ $code ] ) ) {
				// .travel translation: English opens the English front page; other languages their own, once they have one.
				$url = $code === $src_lang ? home_url( '/' ) : ( ! empty( $counts[ $code ] ) ? self::lang_home_url( $code ) : '' );
				if ( ! $url ) continue;
				$attr = ' lang="' . esc_attr( LMGT_Bridge::hreflang_code( $code ) ) . '"';
			} elseif ( $code === $src_lang || isset( $set[ $code ] ) ) {
				$url  = isset( $set[ $code ] ) ? $set[ $code ] : $base;
				$attr = ' hreflang="' . esc_attr( LMGT_Bridge::hreflang_code( $code ) ) . '" lang="' . esc_attr( LMGT_Bridge::hreflang_code( $code ) ) . '"' . ( $is ? ' aria-current="page"' : '' );
			} elseif ( $id && LMGT_Bridge::is_source() && LMGT_Bridge::peer_lang_home( $code ) ) {
				$url  = LMGT_Bridge::peer_lang_home( $code );
				$attr = ' lang="' . esc_attr( $l['hreflang'] ) . '"';
			} else {
				$url    = $base . '#lmgt-nt-' . $code;
				$attr   = ' lang="' . esc_attr( $l['hreflang'] ) . '"';
				$orig   = LMGT_Langs::get( $src_lang )['native'];
				$line   = isset( $counts[ $code ] ) && $counts[ $code ] >= 3
					? sprintf( self::growing( $code ), get_bloginfo( 'name' ), $orig )
					: sprintf( self::not_translated( $code ), $orig );
				$notes .= '<p id="lmgt-nt-' . esc_attr( $code ) . '" class="lmgt-nt" lang="' . esc_attr( $l['hreflang'] ) . '">' . esc_html( $line ) . '</p>';
			}
			// 2.2.23: a link to the other site is marked, and opens in a new window (Settings) so this tab stays where it is.
			$away = self::is_away( $url );
			if ( $away ) {
				$url   = LMGT_Bridge::from_dk( $url );
				$attr .= ' data-x="1"' . ( $newwin ? ' target="_blank" rel="noopener"' : '' );
				if ( $site === '' ) $site = self::bare_host( $url );
			}
			$text   = esc_html( $l['native'] ) . ( $away && $is_target ? ' · ' . esc_html( self::bare_host( $url ) ) : '' ) . ( $away ? ' <span class="x" aria-hidden="true">↗</span>' : '' );
			$items .= '<li><a href="' . esc_url( $url ) . '"' . $attr . ' data-l="' . esc_attr( $code ) . '"' . ( $is ? ' class="is-cur"' : '' ) . '>' . $text . '</a></li>';
		}
		if ( $site !== '' && ! $is_target ) $items .= '<li class="s" lang="en">↗ ' . esc_html( $site ) . '</li>';
		$l_cur = LMGT_Langs::get( $cur );

		// 2.2.23: a small note in the corner, closed by the reader. Shown by script, so cached pages are the same for everyone.
		$chip = '';
		$cfg  = array( 'role' => $is_target ? 'target' : ( LMGT_Bridge::is_source() ? 'source' : '' ) );
		if ( $cfg['role'] === 'source' && get_option( 'lmgt_english_offer', '1' ) === '1' ) {
			$cfg['t'] = array();
			$cfg['x'] = array();
			foreach ( array_keys( LMGT_Langs::all() ) as $code ) {
				$cfg['t'][ $code ] = self::offer_text( $code );
				$cfg['x'][ $code ] = self::close_text( $code );
			}
			$chip = '<div class="lmgt-chip" id="lmgt-offer" hidden role="note"><a href="' . esc_url( home_url( '/' ) ) . '"' . ( $newwin ? ' target="_blank" rel="noopener"' : '' ) . '></a><button type="button">×</button></div>';
		} elseif ( $cfg['role'] === 'target' && LMGT_Bridge::peer() && get_option( 'lmgt_back_chip', '1' ) === '1' ) {
			$dk = isset( $set['da'] ) ? (string) $set['da'] : '';
			if ( $dk === '' && $id ) $dk = (string) get_post_meta( $id, '_lmgt_remote_url', true );
			if ( $dk === '' ) $dk = LMGT_Bridge::peer_front();
			$cfg['peer'] = self::bare_host( LMGT_Bridge::peer() );
			$chip = '<div class="lmgt-chip" id="lmgt-back" hidden role="note" lang="' . esc_attr( LMGT_Bridge::hreflang_code( $cur ) ) . '"><a href="' . esc_url( $dk ) . '">← ' . esc_html( self::back_text( $cur, self::bare_host( $dk ) ) ) . '</a><button type="button" aria-label="' . esc_attr( self::close_text( $cur ) ) . '">×</button></div>';
		}
		echo '<style>.lmgt-sw{position:fixed;left:14px;bottom:14px;z-index:99970;font:13px/1.3 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;transition:transform .25s,opacity .25s}'
			. '.lmgt-sw.is-away{transform:translateY(80px);opacity:0}.lmgt-sw[open]{transform:none;opacity:1}'
			. '.lmgt-sw summary{list-style:none;cursor:pointer;display:flex;align-items:center;gap:6px;background:rgba(255,255,255,.96);border:1px solid #B8956A;border-radius:20px;padding:6px 12px;color:#252528;box-shadow:0 2px 8px rgba(0,0,0,.10)}'
			. '.lmgt-sw summary::-webkit-details-marker{display:none}.lmgt-sw summary:hover,.lmgt-sw summary:focus-visible{background:#B8956A;color:#fff;outline:none}'
			. '.lmgt-sw .c{font-weight:600;letter-spacing:.04em}.lmgt-sw .n{opacity:.8}.lmgt-sw .a{font-size:10px;opacity:.7}'
			. '.lmgt-sw ul{position:absolute;left:0;bottom:calc(100% + 6px);min-width:170px;list-style:none;margin:0;padding:6px 0;background:#fff;border:1px solid #dcdcdc;border-radius:12px;box-shadow:0 6px 18px rgba(0,0,0,.14)}'
			. '.lmgt-sw li{margin:0}.lmgt-sw a{display:block;padding:7px 16px;color:#252528;text-decoration:none}.lmgt-sw a:hover{background:#f5efe7}.lmgt-sw a.is-cur{font-weight:600}.lmgt-sw a.is-cur::after{content:" ✓";color:#B8956A}'
			. '.lmgt-sw a.is-off{color:#8a8a8f}'
			. '@media (max-width:600px){.lmgt-sw .n{display:none}}'
			. '.lmgt-nt{display:none;position:fixed;left:14px;bottom:58px;z-index:99971;max-width:min(360px,calc(100vw - 28px));margin:0;padding:10px 14px;background:#252528;color:#fff;border-radius:10px;font:13px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}'
			. '.lmgt-nt:target,.lmgt-nt.is-on{display:block}'
			. '.lmgt-sw .x{font-size:11px;opacity:.7}.lmgt-sw li.s{margin:4px 0 0;padding:6px 16px 2px;border-top:1px solid #eee;color:#8a8a8f;font-size:11px}'
			. '.lmgt-chip{position:fixed;left:14px;bottom:58px;z-index:99960;display:flex;align-items:center;max-width:min(360px,calc(100vw - 28px));background:rgba(255,255,255,.97);border:1px solid #B8956A;border-radius:20px;box-shadow:0 2px 8px rgba(0,0,0,.10);font:13px/1.3 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;transition:bottom .25s}'
			. '.lmgt-chip[hidden]{display:none}.lmgt-chip a{padding:6px 4px 6px 12px;color:#252528;text-decoration:none}.lmgt-chip a:hover{text-decoration:underline}'
			. '.lmgt-welcome{max-width:min(420px,calc(100vw - 28px))}.lmgt-welcome span{padding:8px 4px 8px 14px;color:#252528}.lmgt-chip button{appearance:none;border:0;box-shadow:none;background:none;min-height:0;cursor:pointer;color:#8a8a8f;font-size:16px;line-height:1;padding:6px 10px 6px 4px}.lmgt-chip button:hover{color:#252528}'
			. '.lmgt-sw[open]~.lmgt-chip{display:none}.lmgt-sw.is-away~.lmgt-chip{bottom:14px}</style>' . "\n";
		echo $notes;
		// 2.2.25: a short welcome on translated pages of traveltalk.travel, once per visitor.
		$welcome = '';
		if ( $cfg['role'] === 'target' && self::current_lang() && get_option( 'lmgt_welcome', '1' ) === '1' ) {
			$welcome = '<div class="lmgt-chip lmgt-welcome" id="lmgt-welcome" hidden role="note" lang="' . esc_attr( LMGT_Bridge::hreflang_code( $cur ) ) . '"><span>' . esc_html( self::welcome_text( $cur ) ) . '</span><button type="button" aria-label="' . esc_attr( self::close_text( $cur ) ) . '">×</button></div>';
		}
		echo '<details class="lmgt-sw"><summary aria-label="' . esc_attr( self::label( $cur ) ) . '">🌐 <span class="c">' . esc_html( strtoupper( $l_cur['hreflang'] ) ) . '</span><span class="n">' . esc_html( $l_cur['native'] ) . '</span><span class="a">▲</span></summary><ul>' . $items . '</ul></details>' . "\n";
		echo $chip . $welcome;
		// The reader's choice is remembered in this browser only. 2.17.14: nobody is moved any more
		// (Google advises against automatic language redirects). On a later page that exists in that
		// language, a closable note offers it ("Read this page in English"); where it does not, the
		// "not yet translated" line shows once. Every address answers with its own content.
		$also = array();
		foreach ( $langs as $code ) $also[ $code ] = self::offer_text( $code );
		echo "<script>(function(){var d=document.querySelector('.lmgt-sw');if(!d)return;var K='lmgt_lang',cur=" . wp_json_encode( $cur ) . ",T=" . wp_json_encode( $also ) . ",X=" . wp_json_encode( self::close_text( $cur ) ) . ",s=null;"
			. "try{s=localStorage.getItem(K)}catch(e){}"
			. "d.querySelectorAll('a').forEach(function(a){if(!a.hasAttribute('hreflang'))a.classList.add('is-off');a.addEventListener('click',function(){if(a.hasAttribute('data-x'))return;try{localStorage.setItem(K,a.dataset.l)}catch(e){}})});"
			. "if(s&&s!==cur&&!location.hash){var t=d.querySelector('a[hreflang][data-l=\"'+s+'\"]'),g='lmgt_also_'+location.pathname,shut=false;try{shut=!!sessionStorage.getItem(g)}catch(e){}"
			// 2.17.14: a note instead of a move. Same site only (the other site has its own notes), closed once = gone for this visit,
			// and never on top of another corner note (they are decided by the script after this one, hence the timeout).
			. "if(t&&!t.hasAttribute('data-x')&&t.href.split('#')[0]!==location.href.split('#')[0]){if(!shut)setTimeout(function(){if(document.querySelector('.lmgt-chip:not([hidden])'))return;var c=document.createElement('div'),a=document.createElement('a'),b=document.createElement('button');c.className='lmgt-chip';c.id='lmgt-also';c.setAttribute('role','note');c.lang=t.getAttribute('hreflang');a.href=t.href;a.textContent=(T[s]||T.en)+' →';b.type='button';b.textContent='×';b.setAttribute('aria-label',X);b.addEventListener('click',function(){c.remove();try{sessionStorage.setItem(g,'1')}catch(e){}});a.addEventListener('click',function(){try{localStorage.setItem(K,s)}catch(e){}});c.appendChild(a);c.appendChild(b);d.after(c)},0);return}"
			. "var n=document.getElementById('lmgt-nt-'+s);try{if(n&&!sessionStorage.getItem('lmgt_nt_'+location.pathname)){n.classList.add('is-on');sessionStorage.setItem('lmgt_nt_'+location.pathname,'1');setTimeout(function(){n.classList.remove('is-on')},6000)}}catch(e){}}"
			. "var y=scrollY;addEventListener('scroll',function(){var v=scrollY;d.classList.toggle('is-away',v>y&&v>300);y=v},{passive:true})})();</script>\n";
		if ( $chip !== '' || $welcome !== '' || $cfg['role'] === 'target' ) echo '<script>' . str_replace( '__C__', wp_json_encode( $cfg ), self::CHIP_JS ) . "</script>\n";
	}

	/**
	 * 2.2.23: the two corner notes, both closed by the reader and neither a redirect.
	 *   traveltalk.dk: "Read this page in English ↗" — only for a browser that lists no Danish, only when this page
	 *   exists on .travel in the browser's language (else English). Hidden again for 60 days once closed or used.
	 *   traveltalk.travel: "← Back to traveltalk.dk" — only for a visitor who came from .dk (the referrer, or the #lmg-from-dk
	 *   fragment that .dk's links carry, 2.2.24), kept for the visit.
	 * Address hash #lmg-offer / #lmg-back shows the note regardless, for looking at it.
	 */
	const CHIP_JS = <<<'JS'
(function(){var C=__C__,d=document,L=location,H=L.hash;
function g(s,k){try{return s.getItem(k)}catch(e){return null}}
function p(s,k,v){try{s.setItem(k,v)}catch(e){}}
if(C.role==='source'){
var o=d.getElementById('lmgt-offer'),sw=d.querySelector('.lmgt-sw');if(!o||!sw)return;
var force=H==='#lmg-offer',seen=+g(localStorage,'lmgt_offer_off')||0;
if(!force&&seen&&Date.now()-seen<5184000000)return;
var bl=(navigator.languages&&navigator.languages.length)?navigator.languages:[navigator.language||''],cs=[],da=false,i;
for(i=0;i<bl.length;i++){var c=String(bl[i]).toLowerCase().split('-')[0];if(c==='da')da=true;if(c==='no'||c==='nn')c='nb';cs.push(c)}
if(da&&!force)return;
var it={};sw.querySelectorAll('a[data-x][hreflang]').forEach(function(a){it[a.dataset.l]=a});
var k=null;for(i=0;i<cs.length;i++){if(it[cs[i]]){k=cs[i];break}}
if(!k&&it.en)k='en';
if(!k&&force){it.en=sw.querySelector('a[data-x][data-l="en"]');if(it.en)k='en'}
if(!k)return;
var a=o.querySelector('a'),b=o.querySelector('button');
a.href=it[k].href;a.textContent=C.t[k]+' ↗';a.lang=k;o.lang=k;b.setAttribute('aria-label',C.x[k]);
function stop(){p(localStorage,'lmgt_offer_off',String(Date.now()))}
a.addEventListener('click',stop);
b.addEventListener('click',function(){stop();o.hidden=true});
setTimeout(function(){o.hidden=false},force?0:1500);
}else if(C.role==='target'){
var mk=H==='#lmg-from-dk';
if(mk){p(sessionStorage,'lmgt_from','1');try{sessionStorage.removeItem('lmgt_back_off')}catch(e){}try{history.replaceState(history.state,'',L.pathname+L.search)}catch(e){}}
var m=d.getElementById('lmgt-back'),shownBack=false;
if(m){
var fr=mk||g(sessionStorage,'lmgt_from')==='1',off=!mk&&g(sessionStorage,'lmgt_back_off')==='1';
if(!fr){try{fr=!!d.referrer&&new URL(d.referrer).hostname.replace(/^www\./,'')===C.peer}catch(e){}if(fr)p(sessionStorage,'lmgt_from','1')}
if(H==='#lmg-back'||(fr&&!off)){
m.querySelector('button').addEventListener('click',function(){p(sessionStorage,'lmgt_back_off','1');m.hidden=true});
m.hidden=false;shownBack=true}
}
var w=d.getElementById('lmgt-welcome');
if(w&&!shownBack){
var wf=H==='#lmg-welcome',ws=+g(localStorage,'lmgt_welcome')||0;
if(wf||!ws||Date.now()-ws>5184000000){
var t=null,tries=0;
var banner=function(){var e=d.querySelector('.cmplz-cookiebanner');if(!e)return false;var cs=getComputedStyle(e);return e.offsetHeight>0&&cs.display!=='none'&&cs.visibility!=='hidden'};
var hide=function(){w.hidden=true;clearTimeout(t)};
var arm=function(ms){clearTimeout(t);t=setTimeout(hide,ms)};
var open=function(){if(m&&!m.hidden)return;p(localStorage,'lmgt_welcome',String(Date.now()));w.hidden=false;arm(7000)};
w.querySelector('button').addEventListener('click',hide);
w.addEventListener('mouseenter',function(){clearTimeout(t)});
w.addEventListener('mouseleave',function(){arm(3000)});
w.addEventListener('touchstart',function(){clearTimeout(t)},{passive:true});
w.addEventListener('touchend',function(){arm(4000)});
var wait=function(){if(banner()&&tries++<15){setTimeout(wait,1000)}else{open()}};
setTimeout(wait,wf?0:2000);
}}
}
})();
JS;

	/** Host without www: "traveltalk.travel". */
	private static function bare_host( $url ) {
		$h = wp_parse_url( (string) $url, PHP_URL_HOST );
		return $h ? preg_replace( '/^www\./', '', strtolower( $h ) ) : '';
	}

	/** True when the address is on the other site (a different host, www ignored). */
	private static function is_away( $url ) {
		$h = self::bare_host( $url );
		return $h !== '' && $h !== self::bare_host( home_url() );
	}

	/** "Read this page in English", in the language it offers. */
	private static function offer_text( $code ) {
		$t = array(
			'en' => 'Read this page in English', 'de' => 'Diese Seite auf Deutsch lesen', 'fr' => 'Lire cette page en français',
			'es' => 'Leer esta página en español', 'pt' => 'Ler esta página em português', 'it' => 'Leggi questa pagina in italiano',
			'sv' => 'Läs den här sidan på svenska', 'nb' => 'Les denne siden på norsk', 'fi' => 'Lue tämä sivu suomeksi',
		);
		return isset( $t[ $code ] ) ? $t[ $code ] : $t['en'];
	}

	/** "Back to traveltalk.dk", in the page's language. */
	private static function back_text( $code, $host ) {
		$t = array(
			'da' => 'Tilbage til %s', 'en' => 'Back to %s', 'de' => 'Zurück zu %s', 'fr' => 'Retour à %s', 'es' => 'Volver a %s',
			'pt' => 'Voltar para %s', 'it' => 'Torna a %s', 'sv' => 'Tillbaka till %s', 'nb' => 'Tilbake til %s', 'fi' => 'Takaisin sivustolle %s',
		);
		return sprintf( isset( $t[ $code ] ) ? $t[ $code ] : $t['en'], $host );
	}

	/** The welcome note, in the page's language. */
	private static function welcome_text( $code ) {
		$t = array(
			'en' => 'New in your language every few days: guides from traveltalk.dk, checked by our editors. Come back soon ✈',
			'de' => 'Alle paar Tage neu in Ihrer Sprache: Reiseführer von traveltalk.dk, von unserer Redaktion geprüft. Kommen Sie bald wieder ✈',
			'fr' => 'Du nouveau dans votre langue tous les quelques jours : des guides de traveltalk.dk, relus par notre rédaction. À bientôt ✈',
			'es' => 'Novedades en tu idioma cada pocos días: guías de traveltalk.dk, revisadas por nuestra redacción. ¡Vuelve pronto! ✈',
			'it' => 'Novità nella tua lingua ogni pochi giorni: guide di traveltalk.dk, riviste dalla nostra redazione. A presto ✈',
			'pt' => 'Novidades no seu idioma a cada poucos dias: guias do traveltalk.dk, revisados pela nossa redação. Volte em breve ✈',
			'sv' => 'Nytt på ditt språk med några dagars mellanrum: guider från traveltalk.dk, granskade av vår redaktion. Välkommen tillbaka ✈',
			'nb' => 'Nytt på ditt språk med noen dagers mellomrom: guider fra traveltalk.dk, gjennomgått av redaksjonen vår. Kom snart tilbake ✈',
			'fi' => 'Uutta omalla kielelläsi muutaman päivän välein: traveltalk.dk:n oppaita, toimituksemme tarkistamia. Tervetuloa takaisin ✈',
		);
		return isset( $t[ $code ] ) ? $t[ $code ] : $t['en'];
	}

	private static function close_text( $code ) {
		$t = array( 'da' => 'Luk', 'en' => 'Close', 'de' => 'Schließen', 'fr' => 'Fermer', 'es' => 'Cerrar', 'pt' => 'Fechar', 'it' => 'Chiudi', 'sv' => 'Stäng', 'nb' => 'Lukk', 'fi' => 'Sulje' );
		return isset( $t[ $code ] ) ? $t[ $code ] : $t['en'];
	}

	private static function label( $code ) {
		$t = array( 'da' => 'Sprogvalg', 'sv' => 'Språk', 'nb' => 'Språk', 'fi' => 'Kieli', 'de' => 'Sprache', 'fr' => 'Langue', 'es' => 'Idioma', 'pt' => 'Idioma', 'it' => 'Lingua' );
		return isset( $t[ $code ] ) ? $t[ $code ] : 'Language';
	}

	/**
	 * Once a language has three published articles, the notice says the
	 * collection grows instead. %1$s is the site name, %2$s the original's language.
	 */
	private static function growing( $code ) {
		$t = array(
			'da' => '%1$s på dansk vokser og forbedres hver uge. Denne artikel er endnu kun på originalsproget (%2$s).',
			'en' => '%1$s in English is growing and improving every week. This article is still in its original language (%2$s).',
			'sv' => '%1$s på svenska växer och förbättras varje vecka. Den här artikeln finns ännu bara på originalspråket (%2$s).',
			'nb' => '%1$s på norsk vokser og forbedres hver uke. Denne artikkelen finnes foreløpig bare på originalspråket (%2$s).',
			'fi' => '%1$s suomeksi kasvaa ja paranee joka viikko. Tämä artikkeli on vielä vain alkuperäiskielellä (%2$s).',
			'de' => '%1$s auf Deutsch wächst und wird jede Woche besser. Dieser Artikel ist noch in der Originalsprache (%2$s).',
			'fr' => '%1$s en français s’enrichit et s’améliore chaque semaine. Cet article est encore dans sa langue d’origine (%2$s).',
			'es' => '%1$s en español crece y mejora cada semana. Este artículo aún está en su idioma original (%2$s).',
			'pt' => '%1$s em português cresce e melhora toda semana. Este artigo ainda está no idioma original (%2$s).',
			'it' => '%1$s in italiano cresce e migliora ogni settimana. Questo articolo è ancora nella lingua originale (%2$s).',
		);
		return isset( $t[ $code ] ) ? $t[ $code ] : $t['en'];
	}

	/** One line in the language the reader asked for; %s is the original's language. */
	private static function not_translated( $code ) {
		$t = array(
			'da' => 'Endnu ikke oversat til dansk. Du læser originalen (%s).',
			'en' => 'Not yet translated into English. You are reading the original (%s).',
			'sv' => 'Ännu inte översatt till svenska. Du läser originalet (%s).',
			'nb' => 'Ikke oversatt til norsk ennå. Du leser originalen (%s).',
			'fi' => 'Ei vielä käännetty suomeksi. Luet alkuperäistä tekstiä (%s).',
			'de' => 'Noch nicht ins Deutsche übersetzt. Sie lesen das Original (%s).',
			'fr' => 'Pas encore traduit en français. Vous lisez l’original (%s).',
			'es' => 'Aún no traducido al español. Está leyendo el original (%s).',
			'pt' => 'Ainda não traduzido para o português. Você está lendo o original (%s).',
			'it' => 'Non ancora tradotto in italiano. State leggendo l’originale (%s).',
		);
		return isset( $t[ $code ] ) ? $t[ $code ] : $t['en'];
	}
}
