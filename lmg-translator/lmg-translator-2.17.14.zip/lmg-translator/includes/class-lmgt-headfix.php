<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.3.2: a heading that swallowed the text after it.
 *
 * The classic editor turns a whole block into a heading when the heading line
 * and the next paragraph are separated only by a line break, so the closing
 * </hN> lands after the paragraph: <h3>Heading\n\nParagraph…</h3>. The page then
 * shows the paragraph as a heading, and every translation copies the fault.
 * On every save (originals and translations) and before a text is translated,
 * the heading is closed after its first line and the rest becomes normal text.
 */
class LMGT_Headfix {

	public static function boot() {
		add_filter( 'wp_insert_post_data', array( __CLASS__, 'on_save' ), 9, 2 );
	}

	public static function on_save( $data, $raw ) {
		if ( empty( $data['post_content'] ) || ( isset( $data['post_type'] ) && $data['post_type'] === 'revision' ) ) return $data;
		$html  = wp_unslash( $data['post_content'] );
		$fixed = self::repair( $html );
		if ( $fixed !== $html ) $data['post_content'] = wp_slash( $fixed );
		return $data;
	}

	/** Close each heading after its first line when it holds a paragraph break. */
	public static function repair( $html ) {
		if ( stripos( $html, '<h' ) === false ) return $html;
		$break = '#\R[ \t]*\R|(?:<br\s*/?>\s*)+|</?p(?:\s[^>]*)?>#i';
		$split = function ( $inner ) use ( $break ) {
			if ( ! preg_match( $break, $inner, $b, PREG_OFFSET_CAPTURE ) ) return null;
			$head = trim( substr( $inner, 0, $b[0][1] ) );
			$rest = trim( preg_replace( '#</?p(?:\s[^>]*)?>#i', "\n\n", substr( $inner, $b[0][1] + strlen( $b[0][0] ) ) ) );
			if ( $head === '' || $rest === '' ) return null;
			// A <br> may be a wanted two-line headline; split only when real body text follows.
			if ( stripos( $b[0][0], '<br' ) === 0 && mb_strlen( wp_strip_all_tags( $rest ) ) < 120 ) return null;
			return array( $head, preg_split( '#\R[ \t]*\R#', $rest, -1, PREG_SPLIT_NO_EMPTY ) );
		};
		// Block editor: rebuild the heading block and add paragraph blocks after it.
		$html = preg_replace_callback( '#(<!-- wp:heading(?: \{[^\n]*?\})? -->\s*)<h([1-6])([^>]*)>(.*?)</h\2>(\s*<!-- /wp:heading -->)#is', function ( $m ) use ( $split ) {
			$s = $split( $m[4] );
			if ( ! $s ) return $m[0];
			$out = $m[1] . '<h' . $m[2] . $m[3] . '>' . $s[0] . '</h' . $m[2] . '>' . $m[5];
			foreach ( $s[1] as $p ) $out .= "\n\n<!-- wp:paragraph -->\n<p>" . trim( $p ) . "</p>\n<!-- /wp:paragraph -->";
			return $out;
		}, $html );
		// Classic text: blank lines are paragraphs.
		return preg_replace_callback( '#<h([1-6])([^>]*)>(.*?)</h\1>(?!\s*<!-- /wp:heading)#is', function ( $m ) use ( $split ) {
			$s = $split( $m[3] );
			if ( ! $s ) return $m[0];
			return '<h' . $m[1] . $m[2] . '>' . $s[0] . '</h' . $m[1] . ">\n\n" . implode( "\n\n", array_map( 'trim', $s[1] ) ) . "\n";
		}, $html );
	}
}
