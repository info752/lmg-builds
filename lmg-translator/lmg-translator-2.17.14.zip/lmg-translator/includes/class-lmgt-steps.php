<?php
/**
 * 2.7.0 (G, 8 Nov 2026): one panel at the top of the edit screen with the work in the order it is
 * done, each step with its state (✓ done, ● waiting for you, – not needed) and one clear verb.
 * The detailed boxes stay where they are; the panel says where to look and does the common step.
 *
 *   1 Check      flags from the translation check (translations only)
 *   2 Deepen     length and content gaps, sections waiting to be read
 *   3 Structure  intro and practical part, a proposed structure waiting
 *   4 SEO        focus keyword and meta description
 *   5 Links      internal links out of the text and into it, counted and listed
 *   6 Publish    "I have read the check" and the status (translations only)
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class LMGT_Steps {

	private static $pid = 0;
	private static $seen = array();

	public static function boot() {
		add_action( 'add_meta_boxes', function () {
			add_meta_box( 'lmgt_steps', 'Translator – steps', array( __CLASS__, 'box' ), LMGT_Store::types( true ), 'normal', 'high' );
		} );
		add_action( 'admin_post_lmgt_links_refresh', array( __CLASS__, 'handle_refresh' ) );
		add_action( 'admin_post_lmgt_links_add', array( __CLASS__, 'handle_add' ) );
		add_action( 'admin_post_lmgt_links_apply', array( __CLASS__, 'handle_apply' ) );
		add_action( 'admin_post_lmgt_kw_suggest', array( __CLASS__, 'handle_kw_suggest' ) );
	}

	/**
	 * 2.17.13 (G, 14 Nov: "add approved links also externally"): the sites the editor has approved for
	 * links out, one per line in Translator → Settings. Empty = the starter list for the site's subject.
	 */
	public static function ext_defaults() {
		$s = class_exists( 'LMGT_Boxes' ) ? LMGT_Boxes::subject() : 'travel';
		if ( $s === 'sport' ) return "formula1.com\nfia.com\natptour.com\nwtatennis.com\nausopen.com\nwimbledon.com\nrolandgarros.com\nusopen.org\nuefa.com\nfifa.com\nolympics.com\nnfl.com\nnba.com\nicc-cricket.com\npgatour.com";
		if ( $s === 'wine' ) return "champagne.fr\nbordeaux.com\nriojawine.com\nchianticlassico.com\nivdp.pt\nwinesofsa.co.za";
		return "visitdenmark.com\nvisitnorway.com\nvisitsweden.com\nvisitfinland.com\nitalia.it\nspain.info\nfrance.fr\nvisitportugal.com\nvisitbritain.com\nnps.gov\nparks.canada.ca\nunesco.org";
	}

	public static function ext_sites() {
		$t = (string) get_option( 'lmgt_ext_sites', '' );
		if ( trim( $t ) === '' ) $t = self::ext_defaults();
		$out = array();
		foreach ( preg_split( '/[\s,]+/', strtolower( $t ) ) as $d ) {
			$d = preg_replace( '#^https?://#', '', trim( $d ) );
			$d = preg_replace( '#^www\.|/.*$#', '', $d );
			if ( $d !== '' ) $out[] = $d;
		}
		return array_values( array_unique( $out ) );
	}

	public static function ext_max() {
		return max( 0, min( 6, (int) get_option( 'lmgt_ext_max', 3 ) ) );
	}

	/** Is the address on the approved list (the domain itself or a subdomain of it)? */
	public static function ext_listed( $url ) {
		$h = preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) ) );
		foreach ( self::ext_sites() as $d ) if ( $h === $d || substr( $h, -strlen( '.' . $d ) ) === '.' . $d ) return true;
		return false;
	}

	private static function nonce_url( $action, $id, $extra = '', $nonce = '' ) {
		return wp_nonce_url( admin_url( 'admin-post.php?action=' . $action . '&post=' . (int) $id . $extra ), $nonce !== '' ? $nonce : $action . '_' . (int) $id );
	}

	public static function row( $n, $title, $state, $text, $buttons = '' ) {
		$badge = array(
			'done' => '<span style="color:#008a20;font-weight:600">✓ done</span>',
			'wait' => '<span style="color:#b26200;font-weight:600">● waiting for you</span>',
			'todo' => '<span style="color:#b32d2e;font-weight:600">● to do</span>',
			'none' => '<span style="color:#8c8f94">– not needed</span>',
		);
		self::$seen[] = array( $n, $title, $state, $text, $buttons );
		echo '<tr><td style="width:24px;font-weight:600">' . (int) $n . '</td><td style="width:110px"><strong>' . esc_html( $title ) . '</strong></td><td style="width:150px">' . $badge[ $state ] . '</td><td>' . $text . ( self::$pid ? LMGT_Stamps::line( self::$pid, $title ) : '' ) . '</td><td style="text-align:right;white-space:nowrap">' . $buttons . '</td></tr>';
	}

	private static function btn( $url, $label, $primary = false ) {
		return '<a class="button' . ( $primary ? ' button-primary' : '' ) . '" href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a> ';
	}

	public static function box( $post ) {
		if ( ! current_user_can( 'edit_post', $post->ID ) ) return;
		$id   = $post->ID;
		$tr   = $post->post_type === LMGT_CPT;
		self::$pid = $id;
		$ai   = LMGT_Engines::ai_available();
		self::$seen = array();
		ob_start();
		echo '<p class="description" style="margin-top:12px">All steps, in order. Click once and wait for the green "Done" bar; details are in the boxes below and on the right.</p>';
		echo '<table class="widefat striped" style="border:0"><tbody>';
		$n = 0;

		// 1 Check
		if ( $tr ) {
			$n++;
			$p     = get_post_meta( $id, '_lmgt_pending', true );
			$flags = LMGT_Store::open_issues( $id );
			if ( is_array( $p ) && ! empty( $p['translation'] ) ) {
				self::row( $n, 'Check', 'wait', 'A ' . ( isset( $p['kind'] ) && $p['kind'] === 'fix' ? 'corrected' : 'new' ) . ' version is waiting.',
					self::btn( self::nonce_url( 'lmgt_apply', $id ), 'Accept: put it in the text', true ) . self::btn( self::nonce_url( 'lmgt_discard', $id ), 'Reject: keep my text' ) );
			} elseif ( $flags ) {
				// 2.17.4: number flags have their own button; Fix only handles meaning.
				$nums = LMGT_Store::open_numbers( $id );
				$txt  = (int) $flags . ' flag(s) – listed under "Translation check"' . ( $nums ? ' (' . (int) $nums . ' of them number(s) that differ from the original: check them in the text)' : '' ) . '.';
				$b    = ( $ai && $flags > $nums ? self::btn( self::nonce_url( 'lmgt_fix', $id ), 'Fix the flags', true ) : '' ) . ( $nums ? self::btn( self::nonce_url( 'lmgt_numbers_ok', $id ), 'Numbers are right – clear', $flags === $nums ) : '' );
				self::row( $n, 'Check', 'todo', $txt, $b );
			} else {
				self::row( $n, 'Check', 'done', 'No flags.' );
			}
		}

		// 2 Deepen
		$n++;
		$words = LMGT_Store::words( $post );
		$min   = LMGT_Store::min_words( $id );
		$draft = get_post_meta( $id, '_lmgt_gap_draft', true );
		$g     = get_post_meta( $id, '_lmgt_gaps', true );
		$len   = (int) $words . ' words (minimum ' . (int) $min . ').';
		if ( LMGT_Store::as_written( $id ) ) {
			self::row( $n, 'Deepen', 'none', 'News: kept as written.' );
		} elseif ( is_array( $draft ) && ! empty( $draft['sections'] ) ) {
			self::row( $n, 'Deepen', 'wait', count( $draft['sections'] ) . ' new section(s) written – read them under "New sections to read", then add the ones you want.', '<a class="button button-primary" href="#lmgt-gd-anchor" onclick="var e=document.querySelector(\'[form=lmgt-gd]\');if(e){e.scrollIntoView({behavior:\'smooth\',block:\'center\'});return false}">Go to the sections</a>' );
		} elseif ( is_array( $g ) && ! empty( $g['gaps'] ) ) {
			self::row( $n, 'Deepen', 'wait', $len . ' ' . count( $g['gaps'] ) . ' suggestion(s) found – tick the ones to write.', '<a class="button button-primary" href="#" onclick="var e=document.querySelector(\'[form=lmgt-gp]\');if(e){e.scrollIntoView({behavior:\'smooth\',block:\'center\'})}return false">Go to the suggestions</a>' );
		} else {
			self::row( $n, 'Deepen', $words < $min ? 'todo' : 'none', $len . ( $words < $min ? ' Thin.' : '' ), $ai ? self::btn( self::nonce_url( 'lmgt_gaps', $id ), 'Find content gaps', $words < $min ) : '' );
		}

		// 3 Structure
		$n++;
		if ( LMGT_Store::as_written( $id ) ) {
			self::row( $n, 'Structure', 'none', 'News: kept as written.' );
		} else {
			$pend = get_post_meta( $id, '_lmgt_structure', true );
			$c    = LMGT_Structure::check( $post );
			$base = admin_url( 'admin-post.php?action=lmgt_structure_apply&post=' . $id );
			if ( is_array( $pend ) && ! empty( $pend['content'] ) ) {
				self::row( $n, 'Structure', 'wait', 'A new structure is waiting.', self::btn( wp_nonce_url( $base . '&do=apply', 'lmgt_structure_' . $id ), 'Accept: put it in the text', true ) . self::btn( wp_nonce_url( $base . '&do=drop', 'lmgt_structure_' . $id ), 'Reject: keep my text' ) );
			} else {
				$bad = array();
				if ( $c['intro'] !== 'ok' ) $bad[] = 'intro ' . $c['intro'];
				if ( $c['practical'] !== 'ok' ) $bad[] = 'practical part ' . $c['practical'];
				if ( ! empty( $c['repeat'] ) ) $bad[] = 'a heading repeats the title';
				if ( ! empty( $c['shortcodes'] ) ) $bad[] = 'broken shortcode';
				$can = ( $c['intro'] !== 'ok' || $c['practical'] !== 'ok' ) && $ai;
				self::row( $n, 'Structure', $bad ? 'todo' : 'done', $bad ? ucfirst( implode( ', ', $bad ) ) . '.' : 'Intro and practical part in place.', $can ? self::btn( wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_structure&post=' . $id ), 'lmgt_structure_' . $id ), 'Propose the structure', true ) : '' );
			}
		}

		// 4 SEO
		$n++;
		$kw = trim( (string) get_post_meta( $id, 'rank_math_focus_keyword', true ) );
		$md = trim( (string) get_post_meta( $id, 'rank_math_description', true ) );
		$seo_txt = 'Keyword: ' . ( $kw !== '' ? '<strong>' . esc_html( $kw ) . '</strong>' : '<em>none</em>' ) . ' · Meta: ' . ( $md !== '' ? (int) mb_strlen( $md ) . ' characters' : '<em>none</em>' ) . '.';
		// 2.17.13 (G, 14 Nov): extra keywords help when the text mentions them. Advice only – never written to Rank Math.
		$ks = get_post_meta( $id, '_lmgt_kw_suggest', true );
		if ( is_array( $ks ) && ! empty( $ks['list'] ) ) {
			$have = array_map( function ( $k ) { return mb_strtolower( trim( $k ) ); }, explode( ',', $kw ) );
			$left = array_values( array_filter( $ks['list'], function ( $k ) use ( $have ) { return ! in_array( mb_strtolower( $k ), $have, true ); } ) );
			if ( $left ) $seo_txt .= '<div style="margin-top:6px">Extra keywords you could add (all in the text): <strong>' . implode( '</strong> · <strong>', array_map( 'esc_html', $left ) ) . '</strong><br><span class="description">Add the ones you want after your main keyword in Rank Math → Focus Keyword. Translator never adds them.</span></div>';
		}
		$kbtn = $ai && $kw !== '' ? self::btn( self::nonce_url( 'lmgt_kw_suggest', $id ), 'Suggest extra keywords' ) : '';
		self::row( $n, 'SEO', $kw !== '' && $md !== '' ? 'done' : 'todo', $seo_txt, ( $tr && $ai ? self::btn( self::nonce_url( 'lmgt_seo', $id ), $kw !== '' || $md !== '' ? 'Set SEO again' : 'Set SEO', $kw === '' || $md === '' ) : '' ) . $kbtn );

		// 5 Links
		$n++;
		$l = self::links( $post );
		$need_in = $l['in'] < 2;
		$txt = '<strong>' . count( $l['out'] ) . '</strong> link(s) out to this site' . self::fam_text( $l ) . ' · <strong>' . (int) $l['in'] . '</strong> page(s) link here' . ( ! empty( $l['ext'] ) ? ' · <strong>' . (int) $l['ext'] . '</strong> external' : '' ) . ( $l['at'] ? ' <span class="description">(counted ' . esc_html( $l['at'] ) . ' UTC)</span>' : '' ) . '.';
		$txt .= self::link_lists( $l );
		$lp = get_post_meta( $id, '_lmgt_links_pending', true );
		if ( is_array( $lp ) && ! empty( $lp['list'] ) ) {
			// 2.17.13: tick the links you want; only those go in.
			$li = '<ul style="list-style:none;margin-left:0">';
			foreach ( $lp['list'] as $i => $x ) {
				$note = '';
				if ( $x['kind'] === 'external' ) $note = ! empty( $x['listed'] ) ? ' <span class="description">(external · on your list · the page answers)</span>' : ' <span class="description" style="color:#996800">(external · not on your list – your call · the page answers)</span>';
				$li .= '<li><label><input type="checkbox" class="lmgt-linkpick" value="' . (int) $i . '" checked> "' . esc_html( $x['phrase'] ) . '"</label> → <a href="' . esc_url( $x['url'] ) . '" target="_blank">' . esc_html( $x['url'] ) . '</a>' . $note . '</li>';
			}
			$li .= '</ul>';
			$acc  = self::nonce_url( 'lmgt_links_apply', $id, '&do=apply' );
			$js   = '<script>(function(){document.addEventListener("change",function(e){if(!e.target.classList||!e.target.classList.contains("lmgt-linkpick"))return;var p=[].slice.call(document.querySelectorAll(".lmgt-linkpick"));var on=p.filter(function(x){return x.checked}).map(function(x){return x.value});[].forEach.call(document.querySelectorAll(".lmgt-linkacc"),function(b){var base=b.getAttribute("data-base");b.href=on.length<p.length?base+"&only="+(on.length?on.join("-"):"none"):base;b.textContent=on.length?"Accept: put the "+on.length+" ticked in the text":"Tick at least one link";});});})();</script>';
			self::row( $n, 'Links', 'wait', count( $lp['list'] ) . ' link(s) proposed in your existing sentences. Untick the ones you do not want:' . $li . $js, '<a class="button button-primary lmgt-linkacc" data-base="' . esc_url( $acc ) . '" href="' . esc_url( $acc ) . '">Accept: put the ticked in the text</a> ' . self::btn( self::nonce_url( 'lmgt_links_apply', $id, '&do=drop' ), 'Reject' ) );
		} else {
			self::row( $n, 'Links', count( $l['out'] ) + (int) $l['peer'] >= 2 && ! $need_in ? 'done' : 'todo', $txt, ( $ai ? self::btn( self::nonce_url( 'lmgt_links_add', $id ), 'Propose links', count( $l['out'] ) < 2 ) : '' ) . self::btn( self::nonce_url( 'lmgt_links_refresh', $id ), 'Count again' ) );
		}

		// 6 Boxes (2.9.0)
		$n++;
		LMGT_Boxes::step_row( $n, $post );

		// 7 Publish
		if ( $tr ) {
			$n++;
			$flags = LMGT_Store::open_issues( $id );
			$pub   = $post->post_status === 'publish';
			if ( $pub ) self::row( $n, 'Publish', 'done', 'Published.' );
			elseif ( $flags && ! LMGT_Store::is_reviewed( $id ) ) self::row( $n, 'Publish', 'todo', 'Read the check, tick "I have read the check" (under Translation check), then Publish.' );
			else self::row( $n, 'Publish', 'wait', 'Ready: press Publish at the top right.' );
		}
		echo '</tbody></table>';
		$table = ob_get_clean();
		echo self::next_line(); // 2.10.0
		echo $table;
		echo LMGT_Stamps::history_html( $id ); // 2.17.2
	}

	/** 2.10.0 (G, 9 Nov: "can do it easily"): the one thing to do now, with its button. Waiting for you beats to do; the order is the order of the steps. */
	private static function next_line() {
		$pick = null;
		foreach ( array( 'wait', 'todo' ) as $want ) {
			foreach ( self::$seen as $r ) if ( $r[2] === $want ) { $pick = $r; break 2; }
		}
		if ( ! $pick ) {
			return '<div style="background:#edfaef;border:2px solid #00a32a;border-radius:6px;padding:12px 16px;margin:4px 0 0"><strong style="font-size:15px">✓ All steps done.</strong> Nothing is waiting for you on this one.</div>';
		}
		$txt = preg_replace( '#<(ol|ul|table|details)\b.*$#is', '', $pick[3] );
		$txt = trim( wp_strip_all_tags( $txt ) );
		if ( mb_strlen( $txt ) > 220 ) $txt = mb_substr( $txt, 0, 217 ) . '…';
		$what = $pick[2] === 'wait' ? 'Waiting for you' : 'To do';
		$btn  = trim( $pick[4] ) !== '' ? '<div style="margin-top:10px">' . $pick[4] . '</div>' : '';
		$more = $pick[2] === 'wait' ? '<p class="description" style="margin:8px 0 0">Read what is proposed in step ' . (int) $pick[0] . ' below, then Accept or Reject.</p>' : '';
		return '<div style="background:#fff8e5;border:2px solid #dba617;border-radius:6px;padding:12px 16px;margin:4px 0 0"><div style="font-size:12px;text-transform:uppercase;letter-spacing:.05em;color:#8a6d00">Next · ' . esc_html( $what ) . '</div>'
			. '<div style="font-size:16px;margin-top:2px"><strong>' . (int) $pick[0] . ' ' . esc_html( $pick[1] ) . ':</strong> ' . esc_html( $txt ) . '</div>' . $btn . $more . '</div>';
	}

	// ---- Links ----------------------------------------------------------------------

	/** Internal links out of the text (this site and the sister site) and pages on this site linking in. Cached 6 hours. */
	public static function links( $post, $fresh = false ) {
		$key = 'lmgt_links_' . $post->ID;
		$c   = $fresh ? false : get_transient( $key );
		if ( is_array( $c ) && isset( $c['v'], $c['fam'], $c['ext'] ) && $c['v'] === md5( $post->post_content ) ) return $c;
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		$peer = class_exists( 'LMGT_Bridge' ) && LMGT_Bridge::peer() ? wp_parse_url( LMGT_Bridge::peer(), PHP_URL_HOST ) : '';
		$strip = function ( $h ) { return preg_replace( '/^www\./', '', (string) $h ); };
		$out = array();
		$np  = 0;
		$ext = 0;
		// 2.17.3 (G, 14 Nov): links to all four sites count – traveltalk.dk, traveltalk.travel, winetalk.dk, worldsporttalk.com.
		$fam = array( 'traveltalk.dk' => 0, 'traveltalk.travel' => 0, 'winetalk.dk' => 0, 'worldsporttalk.com' => 0 );
		preg_match_all( '/<a\s[^>]*href=["\']([^"\'#]+)["\']/i', $post->post_content, $m );
		foreach ( array_unique( $m[1] ) as $u ) {
			$h = wp_parse_url( $u, PHP_URL_HOST );
			if ( strpos( $u, '/wp-content/' ) !== false ) continue;
			if ( ! $h || $strip( $h ) === $strip( $host ) ) {
				$pid = url_to_postid( $u );
				$out[] = array( 'url' => $u, 'title' => $pid ? html_entity_decode( get_the_title( $pid ), ENT_QUOTES, 'UTF-8' ) : $u, 'ok' => (bool) $pid );
			} elseif ( isset( $fam[ $strip( $h ) ] ) ) {
				$fam[ $strip( $h ) ]++;
				$np++;
			} elseif ( $peer && $strip( $h ) === $strip( $peer ) ) {
				$np++;
			} elseif ( preg_match( '#^https?://#i', $u ) ) {
				$ext++; // 2.17.13: links out to other sites
			}
		}
		$in   = array();
		$path = untrailingslashit( (string) wp_parse_url( get_permalink( $post ), PHP_URL_PATH ) );
		if ( $path !== '' && $post->post_status === 'publish' ) {
			global $wpdb;
			$like = '%' . $wpdb->esc_like( $path . '/' ) . '%';
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_title FROM {$wpdb->posts} WHERE post_status = 'publish' AND ID <> %d AND post_type IN ('post','page','" . esc_sql( LMGT_CPT ) . "') AND post_content LIKE %s LIMIT 60", $post->ID, $like ) );
			foreach ( $rows as $r ) $in[] = array( 'id' => (int) $r->ID, 'title' => html_entity_decode( $r->post_title, ENT_QUOTES, 'UTF-8' ) );
		}
		unset( $fam[ $strip( $host ) ] );
		$c = array( 'v' => md5( $post->post_content ), 'out' => $out, 'peer' => $np, 'fam' => array_filter( $fam ), 'ext' => $ext, 'in' => count( $in ), 'in_list' => $in, 'at' => current_time( 'mysql', true ) );
		set_transient( $key, $c, 6 * HOUR_IN_SECONDS );
		return $c;
	}

	/** 2.17.3: ", 9 to traveltalk.dk, 2 to winetalk.dk" – each of the four sites by name. */
	private static function fam_text( array $l ) {
		if ( ! empty( $l['fam'] ) ) {
			$p = array();
			foreach ( $l['fam'] as $site => $k ) $p[] = (int) $k . ' to ' . $site;
			return ', ' . implode( ', ', $p );
		}
		return ! empty( $l['peer'] ) ? ', ' . (int) $l['peer'] . ' to the sister site' : '';
	}

	private static function link_lists( array $l ) {
		$h = '<details style="margin-top:4px"><summary>Show the links</summary><div style="display:flex;gap:24px;flex-wrap:wrap"><div><strong>Out</strong><ul style="list-style:disc;margin-left:18px">';
		foreach ( $l['out'] as $o ) $h .= '<li>' . ( $o['ok'] ? '' : '<span style="color:#b32d2e">not found: </span>' ) . '<a href="' . esc_url( $o['url'] ) . '" target="_blank">' . esc_html( $o['title'] ) . '</a></li>';
		if ( ! $l['out'] ) $h .= '<li><em>none</em></li>';
		$h .= '</ul></div><div><strong>In</strong><ul style="list-style:disc;margin-left:18px">';
		foreach ( $l['in_list'] as $i ) $h .= '<li><a href="' . esc_url( get_edit_post_link( $i['id'] ) ) . '">' . esc_html( $i['title'] ) . '</a></li>';
		if ( ! $l['in_list'] ) $h .= '<li><em>none' . '</em></li>';
		$h .= '</ul><p class="description">Links written in the text only. Menus, grids and the Read more block are not counted.</p></div></div></details>';
		return $h;
	}

	/**
	 * 2.7.3 (G, 9 Nov: "Add internal links", "Link out to external resources"): links put into
	 * sentences the text already has. Internal links only to the site's own articles in the same
	 * language; external ones only to official or primary sources, and only if the page answers.
	 * Nothing changes until Accept.
	 */
	public static function handle_add() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_links_add_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$post = get_post( $id );
		$back = get_edit_post_link( $id, 'url' );
		$lang = $post->post_type === LMGT_CPT ? (string) get_post_meta( $id, '_lmgt_lang', true ) : LMGT_Langs::source();
		$cand = LMGT_Admin::link_candidates( $post, $lang );
		$a    = LMGT_Langs::get( $lang );
		$subj = class_exists( 'LMGT_Boxes' ) ? LMGT_Boxes::subject() : 'travel';
		$off  = array(
			'travel' => 'a national park authority, a tourist board, a government page',
			'wine'   => 'a wine region\'s official body, an appellation or consortium, the producer\'s own site',
			'sport'  => 'the governing body, the official event or league site, official results and standings',
		);
		$max  = self::ext_max();
		$prompt = "ARTICLE is a {$a['name']} {$subj} article. Propose links to put into sentences it already has.\n"
			. "1. internal: 3 to 6 links, only to addresses in LINKS, where a reader would want to read on. phrase: 2 to 6 words copied exactly from ARTICLE (same letters and case), in running text, not in a heading.\n"
			. "2. external: at most {$max} links to official or primary sources that back a fact in ARTICLE ({$off[ $subj ]}). Prefer pages on the APPROVED sites; another site only if it is the official or primary source. Only addresses you are certain exist, as specific as you are sure of; none is better than a guess. Never a booking site, a betting site, a shop or a blog. phrase as above.\n"
			. "APPROVED: " . implode( ', ', self::ext_sites() ) . "\n"
			. "Each phrase used once. Return JSON: {\"links\":[{\"phrase\":\"…\",\"url\":\"…\",\"kind\":\"internal|external\"}]}.\n\n"
			. "LINKS:\n" . implode( "\n", array_map( function ( $t, $u ) { return $t . ' | ' . $u; }, array_keys( $cand ), $cand ) ) . "\n\nARTICLE:\n" . mb_substr( LMGT_Text::plain( $post->post_content ), 0, 30000 );
		@set_time_limit( 200 );
		$r = LMGT_Engines::ai_json( $prompt );
		if ( is_wp_error( $r ) ) self::back( $back, $r->get_error_message() );
		$ok   = array_map( 'untrailingslashit', array_values( $cand ) );
		$html = $post->post_content;
		$list = array();
		$next = 0;
		foreach ( (array) ( isset( $r['links'] ) ? $r['links'] : array() ) as $x ) {
			if ( empty( $x['phrase'] ) || empty( $x['url'] ) ) continue;
			$url  = esc_url_raw( (string) $x['url'] );
			$kind = isset( $x['kind'] ) && $x['kind'] === 'external' ? 'external' : 'internal';
			if ( $kind === 'internal' && ! in_array( untrailingslashit( $url ), $ok, true ) ) continue;
			if ( $kind === 'external' ) {
				if ( $next >= $max ) continue;
				$h = wp_remote_head( $url, array( 'timeout' => 8, 'redirection' => 3 ) );
				$c = is_wp_error( $h ) ? 0 : (int) wp_remote_retrieve_response_code( $h );
				if ( $c < 200 || $c >= 400 ) continue;
			}
			$new = self::wrap_once( $html, (string) $x['phrase'], $url, $kind );
			if ( $new === null ) continue;
			$html   = $new;
			if ( $kind === 'external' ) $next++;
			$list[] = array( 'phrase' => (string) $x['phrase'], 'url' => $url, 'kind' => $kind, 'listed' => $kind === 'external' && self::ext_listed( $url ) );
		}
		if ( ! $list ) self::back( $back, 'No links could be placed: the suggestions did not match the text or the pages did not answer. Nothing changed.' );
		update_post_meta( $id, '_lmgt_links_pending', wp_slash( array( 'content' => $html, 'list' => $list, 'at' => current_time( 'mysql', true ) ) ) );
		self::back( $back, count( $list ) . ' link(s) proposed. Read them in step 5 and press Accept to put them in.' );
	}

	/** The first occurrence of $phrase in running text (not in a tag, a heading or an existing link) becomes a link. */
	private static function wrap_once( $html, $phrase, $url, $kind ) {
		$parts = preg_split( '/(<[^>]+>)/', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
		$in_a  = 0;
		$in_h  = 0;
		foreach ( $parts as $i => $p ) {
			if ( $p !== '' && $p[0] === '<' ) {
				if ( preg_match( '#^<a[\s>]#i', $p ) ) $in_a++;
				elseif ( preg_match( '#^</a>#i', $p ) ) $in_a = max( 0, $in_a - 1 );
				elseif ( preg_match( '#^<h[1-6][\s>]#i', $p ) ) $in_h++;
				elseif ( preg_match( '#^</h[1-6]>#i', $p ) ) $in_h = max( 0, $in_h - 1 );
				continue;
			}
			if ( $in_a || $in_h ) continue;
			$at = strpos( $p, $phrase );
			if ( $at === false ) continue;
			$attr = $kind === 'external' ? ' target="_blank" rel="noopener"' : '';
			$parts[ $i ] = substr( $p, 0, $at ) . '<a href="' . esc_url( $url ) . '"' . $attr . '>' . $phrase . '</a>' . substr( $p, $at + strlen( $phrase ) );
			return implode( '', $parts );
		}
		return null;
	}

	public static function handle_apply() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_links_apply_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$back = get_edit_post_link( $id, 'url' );
		$p    = get_post_meta( $id, '_lmgt_links_pending', true );
		if ( ! isset( $_GET['do'] ) || $_GET['do'] !== 'apply' || ! is_array( $p ) ) { delete_post_meta( $id, '_lmgt_links_pending' ); self::back( $back, 'Proposed links rejected. The text is unchanged.' ); }
		if ( LMGT_Stamps::edited_since( $id, '_lmgt_links_pending', $p['at'] ) ) { delete_post_meta( $id, '_lmgt_links_pending' ); self::back( $back, 'Not put in: the text was edited after the links were proposed. Press Propose links again.' ); }
		// 2.17.13: only the ticked links, built again on the text as it is – the text they were proposed on.
		$pick = array_keys( $p['list'] );
		if ( isset( $_GET['only'] ) ) $pick = array_map( 'intval', array_filter( explode( '-', (string) $_GET['only'] ), 'is_numeric' ) );
		$html = get_post( $id )->post_content;
		$done = 0;
		foreach ( $pick as $i ) {
			if ( ! isset( $p['list'][ $i ] ) ) continue;
			$x   = $p['list'][ $i ];
			$new = self::wrap_once( $html, $x['phrase'], $x['url'], $x['kind'] );
			if ( $new === null ) continue;
			$html = $new;
			$done++;
		}
		delete_post_meta( $id, '_lmgt_links_pending' );
		if ( ! $done ) self::back( $back, 'No links put in: none was ticked. The text is unchanged.' );
		LMGT_Store::update_content( $id, array( 'post_content' => $html ) );
		delete_transient( 'lmgt_links_' . $id );
		self::back( $back, $done . ' link(s) put in the text. The previous version is under Revisions.' );
	}

	/** 2.17.13: up to five extra keywords that the text already mentions. Stored as advice; Rank Math is not touched. */
	public static function handle_kw_suggest() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_kw_suggest_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$post  = get_post( $id );
		$back  = get_edit_post_link( $id, 'url' );
		$kw    = trim( (string) get_post_meta( $id, 'rank_math_focus_keyword', true ) );
		$main  = trim( explode( ',', $kw )[0] );
		$plain = LMGT_Text::plain( $post->post_title . "\n" . $post->post_content );
		$prompt = "MAIN is the focus keyword of ARTICLE. Suggest up to 5 extra keywords: things people search for that ARTICLE is genuinely about (places, people, events, teams, wines) and that support MAIN. "
			. "Each must appear word for word in ARTICLE, 1 to 4 words, no sentence. Not MAIN itself. Return JSON: {\"keywords\":[\"…\"]}.\n\nMAIN: " . $main . "\n\nARTICLE:\n" . mb_substr( $plain, 0, 30000 );
		@set_time_limit( 120 );
		$r = LMGT_Engines::ai_json( $prompt );
		if ( is_wp_error( $r ) ) self::back( $back, $r->get_error_message() );
		$low  = mb_strtolower( $plain );
		$list = array();
		foreach ( (array) ( isset( $r['keywords'] ) ? $r['keywords'] : array() ) as $k ) {
			$k = trim( sanitize_text_field( (string) $k ) );
			if ( $k === '' || mb_strlen( $k ) > 60 || mb_strtolower( $k ) === mb_strtolower( $main ) || mb_strpos( $low, mb_strtolower( $k ) ) === false ) continue;
			$list[] = $k;
		}
		$list = array_slice( array_values( array_unique( $list ) ), 0, 5 );
		if ( ! $list ) self::back( $back, 'No extra keywords found that the text mentions. Nothing changed.' );
		update_post_meta( $id, '_lmgt_kw_suggest', array( 'list' => $list, 'at' => current_time( 'mysql', true ) ) );
		self::back( $back, count( $list ) . ' extra keyword(s) suggested under SEO. Add the ones you want in Rank Math; Translator does not.' );
	}

	private static function back( $url, $msg ) {
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $msg ), $url ) );
		exit;
	}

	public static function handle_refresh() {
		$id = (int) $_GET['post'];
		check_admin_referer( 'lmgt_links_refresh_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$l = self::links( get_post( $id ), true );
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( count( $l['out'] ) . ' link(s) out, ' . $l['in'] . ' page(s) linking in.' ), get_edit_post_link( $id, 'url' ) ) );
		exit;
	}
}
