<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.2.25: a new article is translated into every ticked language by itself.
 *
 * About 30 minutes after a new post is first published (time for the editor's
 * last touches; the save step refuses an original edited meanwhile) every
 * language ticked in Settings is queued, flagged "auto". Those jobs run in the
 * background, one step a minute, and nothing else in the queue is touched.
 * G's decision of 1 Nov 2026: such translations are published without waiting
 * for review; G reads them all afterwards. So that nothing slips by:
 *   - a translation the checks flagged (language doubt, changed numbers, gaps)
 *     stays a draft and is listed as waiting (Settings → "Hold back flagged");
 *   - every automatic translation is listed under Translator → Auto-published
 *     until it is marked as looked at (or ticked as read on its edit screen);
 *   - one e-mail about an hour after the first one lands, listing what was
 *     published and what is waiting.
 * Meta (on the translation, i.e. on traveltalk.travel for .dk originals):
 *   _lmgt_autopub        'published' | 'hold'
 *   _lmgt_autopub_at     time
 *   _lmgt_autopub_seen   '1' once marked as looked at
 *   _lmgt_autopub_mailed '1' once named in an e-mail
 * Meta on the original: _lmgt_auto_queued (time), so a post is queued once.
 */
class LMGT_Auto {

	const QUEUE_HOOK = 'lmgt_auto_queue';
	const MAIL_HOOK  = 'lmgt_auto_mail';
	const DELAY      = 1800;

	public static function boot() {
		add_action( 'transition_post_status', array( __CLASS__, 'on_transition' ), 20, 3 );
		add_action( self::QUEUE_HOOK, array( __CLASS__, 'queue' ) );
		add_action( self::MAIL_HOOK, array( __CLASS__, 'mail' ) );
		add_action( 'admin_menu', function () {
			if ( LMGT_Bridge::is_source() ) return;
			add_submenu_page( 'lmgt', 'Auto-published', 'Auto-published', 'edit_others_posts', 'lmgt-auto', array( __CLASS__, 'page' ) );
		}, 41 );
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
		add_action( 'admin_post_lmgt_auto_seen', array( __CLASS__, 'handle_seen' ) );
	}

	public static function on() {
		return get_option( 'lmgt_auto_new', '1' ) === '1';
	}

	/** First publication of an ordinary post, once per post. */
	public static function on_transition( $new, $old, $post ) {
		if ( $new !== 'publish' || $old === 'publish' || ! $post || $post->post_type !== 'post' || ! self::on() || lmgt_legacy_active() ) return;
		if ( get_post_meta( $post->ID, '_lmgt_auto_queued', true ) || LMGT_Store::is_tagged( $post->ID ) ) return;
		update_post_meta( $post->ID, '_lmgt_auto_queued', time() );
		if ( ! wp_next_scheduled( self::QUEUE_HOOK, array( (int) $post->ID ) ) ) wp_schedule_single_event( time() + self::DELAY, self::QUEUE_HOOK, array( (int) $post->ID ) );
	}

	/** One job per ticked language, flagged auto. Whatever cannot be queued (language not switched on, post reads as another language) is skipped. */
	public static function queue( $post_id ) {
		if ( ! self::on() ) return;
		$n = 0;
		foreach ( LMGT_Langs::enabled() as $lang ) {
			if ( ! is_wp_error( LMGT_Jobs::add( (int) $post_id, $lang, true ) ) ) $n++;
		}
		if ( LMGT_Bridge::on() ) LMGT_Bridge::log( 'auto: ' . $n . ' translation(s) queued for #' . (int) $post_id );
	}

	/** True when the checks flagged this translation: it then waits as a draft. */
	public static function should_hold( array $report ) {
		if ( get_option( 'lmgt_auto_hold', '1' ) !== '1' ) return false;
		if ( ! empty( $report['issues'] ) || ! empty( $report['gaps'] ) ) return true;
		$n = isset( $report['numbers'] ) ? (array) $report['numbers'] : array();
		return ! empty( $n['missing'] ) || ! empty( $n['extra'] );
	}

	/** A translation made on this site (traveltalk.travel's own articles): publish it, or leave it waiting, and note which. */
	public static function local( $id, $publish ) {
		if ( ! $id || is_wp_error( $id ) ) return;
		if ( $publish && get_post_status( $id ) !== 'publish' ) wp_update_post( array( 'ID' => (int) $id, 'post_status' => 'publish' ) );
		update_post_meta( $id, '_lmgt_autopub', $publish ? 'published' : 'hold' );
		update_post_meta( $id, '_lmgt_autopub_at', time() );
		self::announce();
	}

	/** The e-mail goes about an hour after the first translation of a batch lands. */
	public static function announce() {
		if ( ! wp_next_scheduled( self::MAIL_HOOK ) ) wp_schedule_single_event( time() + HOUR_IN_SECONDS, self::MAIL_HOOK );
	}

	/** Translations made automatically and not yet looked at: [id => 'published'|'hold']. */
	public static function pending() {
		$ids = get_posts( array(
			'post_type' => LMGT_CPT, 'post_status' => array( 'publish', 'draft', 'pending' ), 'posts_per_page' => 300, 'fields' => 'ids',
			'lmgt_all' => true, 'no_found_rows' => true, 'orderby' => 'ID', 'order' => 'DESC',
			'meta_query' => array(
				'relation' => 'AND',
				array( 'key' => '_lmgt_autopub', 'compare' => 'EXISTS' ),
				array( 'key' => '_lmgt_autopub_seen', 'compare' => 'NOT EXISTS' ),
				array( 'key' => '_lmgt_reviewed', 'compare' => 'NOT EXISTS' ),
			),
		) );
		$out = array();
		foreach ( $ids as $id ) {
			$st = get_post_meta( $id, '_lmgt_autopub', true );
			// A held-back draft that has since been published is just a published one to look at.
			$out[ (int) $id ] = $st === 'hold' && get_post_status( $id ) === 'publish' ? 'published' : $st;
		}
		return $out;
	}

	private static function line( $id ) {
		$l = LMGT_Langs::get( get_post_meta( $id, '_lmgt_lang', true ) );
		return ( $l ? $l['name'] : '?' ) . ': ' . get_the_title( $id );
	}

	public static function mail() {
		$todo = array();
		foreach ( self::pending() as $id => $state ) {
			if ( get_post_meta( $id, '_lmgt_autopub_mailed', true ) !== '1' ) $todo[ $id ] = $state;
		}
		if ( ! $todo ) return;
		$pub  = array();
		$hold = array();
		foreach ( $todo as $id => $state ) {
			$row = self::line( $id ) . "\n  " . ( $state === 'published' ? get_permalink( $id ) : 'waiting as a draft: ' . admin_url( 'post.php?post=' . $id . '&action=edit' ) );
			if ( $state === 'published' ) $pub[] = $row; else $hold[] = $row;
			update_post_meta( $id, '_lmgt_autopub_mailed', '1' );
		}
		$body = '';
		if ( $pub ) $body .= count( $pub ) . " translation(s) were published automatically. Please read them:\n\n" . implode( "\n\n", $pub ) . "\n\n";
		if ( $hold ) $body .= count( $hold ) . " translation(s) were held back as drafts because the check flagged something, and wait for you:\n\n" . implode( "\n\n", $hold ) . "\n\n";
		$body .= 'The whole list, with "Mark all as looked at": ' . admin_url( 'admin.php?page=lmgt-auto' ) . "\n";
		$to = sanitize_email( (string) get_option( 'lmgt_notify_email', '' ) );
		wp_mail( $to !== '' ? $to : get_option( 'admin_email' ), 'LMG Translator: ' . count( $pub ) . ' published automatically, ' . count( $hold ) . ' waiting', $body );
	}

	public static function notice() {
		if ( ! current_user_can( 'edit_others_posts' ) || LMGT_Bridge::is_source() ) return;
		if ( empty( $_GET['page'] ) || strpos( (string) $_GET['page'], 'lmgt' ) !== 0 || $_GET['page'] === 'lmgt-auto' ) return;
		$n = count( self::pending() );
		if ( $n ) echo '<div class="notice notice-warning"><p><strong>' . (int) $n . ' automatic translation(s)</strong> not looked at yet. <a href="' . esc_url( admin_url( 'admin.php?page=lmgt-auto' ) ) . '">See them</a></p></div>';
	}

	public static function page() {
		$rows = self::pending();
		echo '<div class="wrap"><h1>Auto-published translations</h1>';
		echo '<p>Made and published by themselves after a new article went live (Settings → New articles). Read them, then mark them as looked at. A draft here was held back because the check flagged something.</p>';
		if ( ! $rows ) {
			echo '<p>Nothing waiting: every automatic translation is looked at.</p></div>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr><th>Language</th><th>Title</th><th>State</th><th></th></tr></thead><tbody>';
		foreach ( $rows as $id => $state ) {
			$l = LMGT_Langs::get( get_post_meta( $id, '_lmgt_lang', true ) );
			echo '<tr><td>' . esc_html( $l ? $l['name'] : '?' ) . '</td><td>' . esc_html( get_the_title( $id ) ) . '</td><td>' . ( $state === 'published' ? 'published' : '<strong>held back, a draft</strong>' ) . '</td><td><a href="' . esc_url( get_edit_post_link( $id ) ) . '">Open</a>' . ( $state === 'published' ? ' · <a href="' . esc_url( get_permalink( $id ) ) . '" target="_blank" rel="noopener">View</a>' : '' ) . '</td></tr>';
		}
		echo '</tbody></table>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin-top:14px"><input type="hidden" name="action" value="lmgt_auto_seen">';
		wp_nonce_field( 'lmgt_auto_seen' );
		echo '<button class="button button-primary">Mark all as looked at</button> <span class="description">Held-back drafts come back to this list only if you do nothing with them; publish or tick them as read on their own screen.</span></form></div>';
	}

	public static function handle_seen() {
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_die( 'Not allowed.' );
		check_admin_referer( 'lmgt_auto_seen' );
		foreach ( self::pending() as $id => $state ) {
			if ( $state === 'published' ) update_post_meta( $id, '_lmgt_autopub_seen', '1' );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=lmgt-auto' ) );
		exit;
	}
}
