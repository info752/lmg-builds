<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.2.5: alt texts with context (G, 27 Oct 2026: "the context is numero 1").
 *
 * Translator → Alt texts, on any site, for its own posts: Claude gets each
 * image in a post (the picture itself), its alt text now and the text around
 * it, and proposes an alt text in the site's language that says what the
 * picture shows in the article's context ("Sejlbåd for anker ved
 * Amalfikysten", not "Italien"). One call per post. A person reads, edits if
 * needed, ticks and applies; nothing changes before that. Images in the text
 * keep their alt in the post's own HTML (WordPress stores it there); the
 * featured image's alt is the image's own.
 *
 * Catch-up, on .dk (Translator → Catch-up): once Danish alt texts are applied,
 * the translations on .travel still carry the old ones. One call per
 * translation translates the post's current alt texts and .travel puts them
 * into the translation (alt attributes only, POST /alts). The article text is
 * not touched.
 *
 * Meta on a post:
 *   _lmgt_alt_check    [at, items => [[n, key, src, featured, now, new, ok]]]
 *   _lmgt_alt_applied  when a person last applied alt texts (UTC)
 *   _lmgt_alt_synced   source only: [lang => UTC] when each translation got them
 */
class LMGT_Alts {

	const MAX = 20;

	public static function boot() {
		add_action( 'admin_menu', function () {
			add_submenu_page( 'lmgt', 'Alt texts', 'Alt texts', 'edit_others_posts', 'lmgt-alts', array( __CLASS__, 'page' ) );
		}, 27 );
		add_action( 'wp_ajax_lmgt_alts', array( __CLASS__, 'ajax_check' ) );
		add_action( 'admin_post_lmgt_alts_apply', array( __CLASS__, 'handle_apply' ) );
		if ( ! LMGT_Bridge::on() ) return;
		if ( LMGT_Bridge::is_target() ) {
			add_action( 'rest_api_init', function () {
				register_rest_route( LMGT_Bridge::NS, '/alts', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_alts' ), 'permission_callback' => function () { return current_user_can( 'edit_others_posts' ); } ) );
			} );
		} else {
			add_action( 'lmgt_catchup_sections', array( __CLASS__, 'catchup_section' ) );
			add_action( 'wp_ajax_lmgt_alts_sync', array( __CLASS__, 'ajax_sync' ) );
		}
	}

	// ---- Images in a post ------------------------------------------------------

	/** An image's key: its attachment (wp-image-N) or else its address. */
	private static function key( $tag ) {
		if ( preg_match( '/\bwp-image-(\d+)\b/', $tag, $m ) ) return 'id:' . $m[1];
		return preg_match( '/\ssrc=["\']([^"\'?]+)/i', $tag, $m ) ? 'src:' . $m[1] : '';
	}

	/** Every <img> in the HTML, in order: [n, key, src, alt, before, after]. */
	public static function images( $html ) {
		$out = array();
		if ( ! preg_match_all( '/<img\b[^>]*>/i', (string) $html, $mm, PREG_OFFSET_CAPTURE ) ) return $out;
		foreach ( $mm[0] as $n => $m ) {
			$tag = $m[0];
			$src = preg_match( '/\ssrc=["\']([^"\']+)/i', $tag, $s ) ? $s[1] : '';
			$alt = preg_match( '/\salt=["\']([^"\']*)/i', $tag, $a ) ? html_entity_decode( $a[1], ENT_QUOTES, 'UTF-8' ) : '';
			$out[] = array(
				'n'      => $n,
				'key'    => self::key( $tag ),
				'src'    => $src,
				'alt'    => $alt,
				'before' => mb_substr( LMGT_Text::plain( substr( $html, 0, $m[1] ) ), -500 ),
				'after'  => mb_substr( LMGT_Text::plain( substr( $html, $m[1] + strlen( $tag ) ) ), 0, 300 ),
			);
		}
		return $out;
	}

	/** Set alt texts by key ([key => alt]); an image without an alt attribute gets one. */
	public static function set_alts( $html, array $alts ) {
		return preg_replace_callback( '/<img\b[^>]*>/i', function ( $m ) use ( $alts ) {
			$k = self::key( $m[0] );
			if ( $k === '' || ! isset( $alts[ $k ] ) ) return $m[0];
			$v = 'alt="' . esc_attr( $alts[ $k ] ) . '"';
			return preg_match( '/\salt=["\'][^"\']*["\']/i', $m[0] ) ? preg_replace( '/\salt=["\'][^"\']*["\']/i', ' ' . $v, $m[0], 1 ) : preg_replace( '/^<img\b/i', '<img ' . $v, $m[0] );
		}, (string) $html );
	}

	/** A picture Claude can fetch: a mid-size copy of the attachment, else the address in the post. */
	/** 2.2.26: Claude fetches each picture itself and obeys the other site's robots.txt, so only pictures from our own two sites are sent (not maps or hotlinked pictures). */
	private static function own_host( $url ) {
		$h = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		$h = preg_replace( '/^www\./', '', $h );
		$own = array( 'traveltalk.dk', 'traveltalk.travel', preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) ) );
		return $h !== '' && in_array( $h, $own, true );
	}

	private static function picture( $key, $src ) {
		if ( strpos( $key, 'id:' ) === 0 ) {
			$i = wp_get_attachment_image_src( (int) substr( $key, 3 ), 'medium_large' );
			if ( $i ) return $i[0];
		}
		return $src;
	}

	// ---- Check: one post per call ----------------------------------------------

	private static function schema() {
		return array( 'type' => 'object', 'properties' => array( 'items' => array( 'type' => 'array', 'items' => array(
			'type' => 'object', 'properties' => array( 'n' => array( 'type' => 'integer' ), 'ok' => array( 'type' => 'boolean' ), 'alt' => array( 'type' => 'string' ), 'en' => array( 'type' => 'string' ) ),
			'required' => array( 'n', 'ok', 'alt', 'en' ), 'additionalProperties' => false,
		) ) ), 'required' => array( 'items' ), 'additionalProperties' => false );
	}

	/**
	 * The proposal's meaning in English, under it, for reviewers who do not read
	 * the language (G, 27 Oct: there are other users). 2.2.14 gave it in Danish;
	 * those proposals still show theirs.
	 */
	public static function hint( array $it ) {
		if ( ! empty( $it['en'] ) ) return '<div class="description">In English: ' . esc_html( $it['en'] ) . '</div>';
		return ! empty( $it['da'] ) ? '<div class="description">På dansk: ' . esc_html( $it['da'] ) . '</div>' : '';
	}

	/** The article's language: a translation's own (2.2.14), else the site's. */
	public static function lang_of( $post ) {
		$l = get_post_type( $post ) === LMGT_CPT ? get_post_meta( $post->ID, '_lmgt_lang', true ) : '';
		return LMGT_Langs::get( $l ) ? $l : LMGT_Langs::source();
	}

	/** The message: instructions, then each image as its context and its picture. */
	public static function message( WP_Post $post, array $items ) {
		$l      = LMGT_Langs::get( self::lang_of( $post ) )['name'];
		$blocks = array( array( 'type' => 'text', 'text' =>
			"You write alt texts for the images in a {$l} travel article titled \"" . wp_strip_all_tags( $post->post_title ) . "\". For each image you get the picture, its alt text now and the article text around it.\n"
			. "Write an alt text in {$l} that says what the picture shows, in the context of the article. In an article about sailing in Italy: a sailing boat at anchor in a bay on the Amalfi coast, not just \"Italy\".\n"
			. "- At most 125 characters. One plain sentence or phrase, no full stop needed.\n"
			. "- Name a place, building or person only when the article text or the alt text now names it; never guess a name from the picture.\n"
			. "- Do not begin with words like \"image of\" or \"photo of\" in any language. No keyword lists.\n"
			. "- If the alt text now already does this well, ok = true and return it unchanged.\n"
			. ( self::lang_of( $post ) === 'en' ? "- en: an empty string.\n" : "- en: the same alt text in English, word for word, for an editor who checks it and may not read {$l}.\n" )
			. "Return JSON {\"items\": [{\"n\", \"ok\", \"alt\", \"en\"}]}, one item per image, with its number n." ) );
		foreach ( $items as $it ) {
			$blocks[] = array( 'type' => 'text', 'text' => 'Image n=' . $it['n'] . ( $it['featured'] ? ' (the featured image at the top of the article)' : '' ) . "\nAlt text now: " . ( $it['now'] !== '' ? $it['now'] : '(none)' ) . "\nText before: " . $it['before'] . "\nText after: " . $it['after'] );
			$blocks[] = array( 'type' => 'image', 'source' => array( 'type' => 'url', 'url' => $it['picture'] ) );
		}
		return $blocks;
	}

	/**
	 * Ask for one post, or with $only for one image in it (its key, e.g. id:123:
	 * a picture just placed with Find pictures, 2.2.14). Stores the proposals;
	 * changes nothing else.
	 */
	public static function check( $post_id, $only = '' ) {
		$post = get_post( $post_id );
		if ( ! $post || ! in_array( $post->post_type, LMGT_Store::types( true ), true ) ) return new WP_Error( 'lmgt_alts', 'Not a post, page or translation.' );
		$items = array();
		$skipped = 0;
		$thumb = (int) get_post_thumbnail_id( $post_id );
		if ( $thumb && wp_get_attachment_image_src( $thumb, 'medium_large' ) && ( $only === '' || $only === 'featured' ) ) {
			$now = get_post_type( $post ) === LMGT_CPT ? (string) get_post_meta( $thumb, '_lmgt_alt_' . self::lang_of( $post ), true ) : '';
			$items[] = array( 'n' => 0, 'key' => 'featured', 'featured' => true, 'now' => $now !== '' ? $now : (string) get_post_meta( $thumb, '_wp_attachment_image_alt', true ), 'before' => '', 'after' => mb_substr( LMGT_Text::plain( $post->post_content ), 0, 400 ), 'picture' => wp_get_attachment_image_src( $thumb, 'medium_large' )[0] );
		}
		foreach ( self::images( $post->post_content ) as $im ) {
			if ( count( $items ) >= self::MAX || $im['key'] === '' || ( $only !== '' && $im['key'] !== $only ) ) continue;
			$pic = self::picture( $im['key'], $im['src'] );
			if ( ! preg_match( '#^https?://#', $pic ) ) continue;
			if ( ! self::own_host( $pic ) ) { $skipped++; continue; }
			$items[] = array( 'n' => $im['n'] + 1, 'key' => $im['key'], 'featured' => false, 'now' => $im['alt'], 'before' => $im['before'], 'after' => $im['after'], 'picture' => $pic );
		}
		if ( ! $items ) {
			update_post_meta( $post_id, '_lmgt_alt_check', array( 'at' => current_time( 'mysql', true ), 'items' => array(), 'skipped' => $skipped ) );
			return 0;
		}
		if ( ! LMGT_Engines::ai_is_claude() || LMGT_Engines::claude_key() === '' ) return new WP_Error( 'lmgt_alts', 'Alt texts need Claude (Translator → Settings → AI engine), because Claude looks at each picture.' );
		$r = LMGT_Engines::claude_json( self::message( $post, $items ), self::schema() );
		$got = array();
		if ( is_wp_error( $r ) ) {
			// 2.2.26: one picture Claude cannot fetch must not stop the post; ask for each alone and set aside the ones that fail.
			if ( count( $items ) < 2 ) return $r;
			$ok = array();
			foreach ( $items as $it ) {
				$one = LMGT_Engines::claude_json( self::message( $post, array( $it ) ), self::schema() );
				if ( is_wp_error( $one ) ) { $skipped++; continue; }
				$ok[] = $it;
				foreach ( (array) ( isset( $one['items'] ) ? $one['items'] : array() ) as $x ) {
					if ( isset( $x['n'] ) ) $got[ (int) $x['n'] ] = $x;
				}
			}
			$items = $ok;
			if ( ! $items ) return $r;
		} else {
			foreach ( (array) ( isset( $r['items'] ) ? $r['items'] : array() ) as $x ) {
				if ( isset( $x['n'] ) ) $got[ (int) $x['n'] ] = $x;
			}
		}
		$store = array();
		foreach ( $items as $it ) {
			$x  = isset( $got[ $it['n'] ] ) ? $got[ $it['n'] ] : null;
			$new = $x ? mb_substr( sanitize_text_field( $x['alt'] ), 0, 160 ) : '';
			$store[] = array( 'n' => $it['n'], 'key' => $it['key'], 'featured' => $it['featured'], 'picture' => $it['picture'], 'now' => $it['now'], 'new' => $new, 'en' => $x && ! empty( $x['en'] ) ? sanitize_text_field( $x['en'] ) : '', 'ok' => ! $x || ! empty( $x['ok'] ) || $new === '' || $new === $it['now'] );
		}
		$this_skipped = $skipped;
		$fresh = count( array_filter( $store, function ( $s ) { return ! $s['ok']; } ) );
		// One image: the post's other proposals stay as they were.
		if ( $only !== '' ) {
			$had   = get_post_meta( $post_id, '_lmgt_alt_check', true );
			$keep  = is_array( $had ) && ! empty( $had['items'] ) ? array_values( array_filter( $had['items'], function ( $i ) use ( $only ) { return $i['key'] !== $only; } ) ) : array();
			$store = array_merge( $keep, $store );
		}
		update_post_meta( $post_id, '_lmgt_alt_check', wp_slash( array( 'at' => current_time( 'mysql', true ), 'items' => $store, 'skipped' => $this_skipped ) ) );
		return $fresh;
	}

	private static function skipped_note( $id ) {
		$c = get_post_meta( $id, '_lmgt_alt_check', true );
		$n = is_array( $c ) && ! empty( $c['skipped'] ) ? (int) $c['skipped'] : 0;
		return $n ? ' (' . $n . ' picture(s) left out: not on traveltalk.dk/.travel, or Claude could not fetch them)' : '';
	}

	/** Step: the next post from the list the person gave, or the next unchecked post, newest first. */
	public static function ajax_check() {
		check_ajax_referer( 'lmgt_alts' );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_send_json_error( 'Not allowed.' );
		$list = get_option( 'lmgt_alts_list', array() );
		if ( isset( $_POST['ids'] ) && trim( wp_unslash( $_POST['ids'] ) ) !== '' ) {
			$list = array_values( array_filter( array_map( 'intval', preg_split( '/[\s,]+/', wp_unslash( $_POST['ids'] ) ) ) ) );
			if ( ! $list ) wp_send_json_error( 'No post IDs found in the box. Type numbers only (e.g. 1727 1802 1950), or leave it empty.' );
		}
		$id = $list ? array_shift( $list ) : 0;
		update_option( 'lmgt_alts_list', $list, false );
		if ( ! $id ) {
			$next = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids', 'orderby' => 'date', 'order' => 'DESC', 'no_found_rows' => true, 'meta_query' => array( array( 'key' => '_lmgt_alt_check', 'compare' => 'NOT EXISTS' ) ) ) );
			$id   = $next ? (int) $next[0] : 0;
		}
		if ( ! $id ) wp_send_json_success( array( 'done' => true, 'line' => 'No posts left to check.' ) );
		$r = self::check( $id );
		if ( is_wp_error( $r ) ) wp_send_json_error( '#' . $id . ': ' . $r->get_error_message() );
		wp_send_json_success( array( 'done' => false, 'left' => count( $list ), 'line' => '#' . $id . ' ' . html_entity_decode( get_the_title( $id ), ENT_QUOTES, 'UTF-8' ) . ': ' . ( $r ? $r . ' alt text(s) to improve' : 'fine' ) . self::skipped_note( $id ) ) );
	}

	// ---- Apply ----------------------------------------------------------------

	public static function handle_apply() {
		check_admin_referer( 'lmgt_alts_apply' );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_die( 'Not allowed.' );
		$posts = 0;
		$dismiss = isset( $_POST['lmgt_do'] ) && $_POST['lmgt_do'] === 'dismiss';
		$texts   = isset( $_POST['lmgt_alt'] ) ? (array) wp_unslash( $_POST['lmgt_alt'] ) : array();
		foreach ( (array) ( isset( $_POST['lmgt_pick'] ) ? $_POST['lmgt_pick'] : array() ) as $pid => $picked ) {
			$pid = (int) $pid;
			$c   = get_post_meta( $pid, '_lmgt_alt_check', true );
			if ( ! is_array( $c ) || empty( $c['items'] ) || ! current_user_can( 'edit_post', $pid ) ) continue;
			$alts = array();
			foreach ( $c['items'] as $i => $it ) {
				if ( ! in_array( (string) $i, array_map( 'strval', (array) $picked ), true ) || $it['ok'] ) continue;
				$c['items'][ $i ]['ok'] = true;
				if ( $dismiss ) continue;
				$v = isset( $texts[ $pid ][ $i ] ) ? sanitize_text_field( $texts[ $pid ][ $i ] ) : $it['new'];
				if ( $v === '' ) continue;
				$c['items'][ $i ]['applied'] = $v;
				if ( $it['featured'] && get_post_type( $pid ) === LMGT_CPT ) {
					// A translation's featured image is shared: its text goes to that language only (2.2.14).
					update_post_meta( (int) get_post_thumbnail_id( $pid ), '_lmgt_alt_' . self::lang_of( get_post( $pid ) ), $v );
				} elseif ( $it['featured'] ) {
					update_post_meta( (int) get_post_thumbnail_id( $pid ), '_wp_attachment_image_alt', $v );
				} else {
					$alts[ $it['key'] ] = $v;
				}
			}
			if ( $alts ) LMGT_Store::update_content( $pid, array( 'post_content' => self::set_alts( get_post_field( 'post_content', $pid, 'raw' ), $alts ) ) );
			if ( ! $dismiss ) update_post_meta( $pid, '_lmgt_alt_applied', current_time( 'mysql', true ) );
			update_post_meta( $pid, '_lmgt_alt_check', wp_slash( $c ) );
			$posts++;
		}
		$msg = $dismiss ? "Kept as they are in $posts post(s)." : "Alt texts applied in $posts post(s). Earlier text is in each post's Revisions.";
		$back = isset( $_POST['lmgt_back'] ) ? wp_validate_redirect( wp_unslash( $_POST['lmgt_back'] ), '' ) : '';
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $msg ), $back ? $back : admin_url( 'admin.php?page=lmgt-alts' ) ) );
		exit;
	}

	public static function page() {
		$lang = LMGT_Langs::get( LMGT_Langs::source() )['name'];
		echo '<div class="wrap"><h1>Alt texts</h1><p>For each image in a post, Claude looks at the picture and the text around it and proposes an alt text in the article\'s language (' . esc_html( $lang ) . ' here; a translation\'s own) that says what it shows in the article\'s context. You read, edit if needed, tick and apply. Nothing changes before that.</p>';
		echo '<p><label>Post IDs to check, in this order (e.g. the strongest in Search Console); empty = the next unchecked posts, newest first:<br><textarea id="lmgt-al-ids" rows="2" class="large-text code"></textarea></label></p>';
		echo '<p>Check <input type="number" id="lmgt-al-n" value="10" min="1" max="200" class="small-text"> post(s) <button class="button button-primary" id="lmgt-al">Check</button> <span id="lmgt-al-st"></span></p><pre id="lmgt-al-log" style="max-height:200px;overflow:auto;background:#fff;padding:8px"></pre>';
		$n = wp_create_nonce( 'lmgt_alts' );
		echo "<script>(function(){var b=document.getElementById('lmgt-al'),s=document.getElementById('lmgt-al-st'),l=document.getElementById('lmgt-al-log');"
			. "function go(k,ids){var d=new FormData();d.append('action','lmgt_alts');d.append('_ajax_nonce','" . esc_js( $n ) . "');if(ids)d.append('ids',ids);"
			. "fetch(ajaxurl,{method:'POST',body:d,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){"
			. "if(!r.success){l.textContent+='Stopped: '+r.data+'\\n';b.disabled=false;return}l.textContent+=r.data.line+'\\n';"
			. "if(!r.data.done&&k>1){s.textContent='Working: '+(k-1)+' to go';go(k-1)}else{s.textContent='Finished. Reload to see the proposals.';b.disabled=false}}).catch(function(e){l.textContent+='Stopped: '+e+'\\n';b.disabled=false})}"
			. "b.addEventListener('click',function(){b.disabled=true;var ids=document.getElementById('lmgt-al-ids').value.trim(),k=parseInt(document.getElementById('lmgt-al-n').value,10)||1;if(ids)k=Math.max(k,ids.split(/[\\s,]+/).length);go(k,ids)})})();</script>";

		$posts = get_posts( array( 'post_type' => LMGT_Store::types( true ), 'post_status' => 'any', 'posts_per_page' => 100, 'fields' => 'ids', 'meta_key' => '_lmgt_alt_check', 'orderby' => 'modified', 'order' => 'DESC', 'no_found_rows' => true ) );
		$html  = '';
		foreach ( $posts as $pid ) {
			$c = get_post_meta( $pid, '_lmgt_alt_check', true );
			if ( ! is_array( $c ) || empty( $c['items'] ) ) continue;
			$rows = '';
			foreach ( $c['items'] as $i => $it ) {
				if ( $it['ok'] ) continue;
				$rows .= '<tr><td><input type="checkbox" name="lmgt_pick[' . (int) $pid . '][]" value="' . (int) $i . '" checked></td>'
					. '<td><img src="' . esc_url( $it['picture'] ) . '" style="max-width:110px;height:auto" alt="">' . ( $it['featured'] ? '<br><em>featured</em>' : '' ) . '</td>'
					. '<td style="color:#8a8a8f">' . esc_html( $it['now'] !== '' ? $it['now'] : '(none)' ) . '</td>'
					. '<td><textarea name="lmgt_alt[' . (int) $pid . '][' . (int) $i . ']" rows="2" maxlength="160" style="width:100%">' . esc_textarea( $it['new'] ) . '</textarea>'
					. self::hint( $it ) . '</td></tr>';
			}
			if ( $rows === '' ) continue;
			$html .= '<h3><a href="' . esc_url( get_edit_post_link( $pid ) ) . '">' . esc_html( get_the_title( $pid ) ) . '</a> <span class="description">checked ' . esc_html( $c['at'] ) . ' UTC</span></h3>'
				. '<table class="widefat striped" style="table-layout:fixed"><thead><tr><td style="width:2.2em"></td><th style="width:130px">Image</th><th style="width:38%">Alt text now</th><th>Proposal (edit freely)</th></tr></thead><tbody>' . $rows . '</tbody></table>';
		}
		echo '<h2>Proposals</h2>';
		if ( $html === '' ) {
			echo '<p>None waiting.</p></div>';
			return;
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="lmgt_alts_apply">' . wp_nonce_field( 'lmgt_alts_apply', '_wpnonce', true, false ) . $html;
		echo '<p><button class="button button-primary" name="lmgt_do" value="apply">Apply the ticked</button> <button class="button" name="lmgt_do" value="dismiss">Keep the ticked as they are</button></p>';
		echo '<p class="description">Images in the text get the alt text in that post only; a featured image\'s alt text is the image\'s own, wherever it is used. Earlier text stays in the post\'s Revisions.</p></form></div>';
	}

	// ---- Catch-up: translations get the new alt texts ---------------------------

	/** Source: [sid, lang] for every translation on .travel made before the post's alt texts were last applied. */
	public static function pending_sync() {
		global $wpdb;
		$out = array();
		foreach ( $wpdb->get_col( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_lmgt_alt_applied'" ) as $sid ) {
			$applied = get_post_meta( $sid, '_lmgt_alt_applied', true );
			$synced  = (array) get_post_meta( $sid, '_lmgt_alt_synced', true );
			foreach ( LMGT_Bridge::remote( $sid ) as $lang => $r ) {
				if ( ! is_array( $r ) || empty( $r['id'] ) ) continue;
				if ( empty( $synced[ $lang ] ) || $synced[ $lang ] < $applied ) $out[] = array( 'sid' => (int) $sid, 'lang' => $lang );
			}
		}
		return $out;
	}

	public static function catchup_section() {
		$n = count( self::pending_sync() );
		echo '<h2>Alt texts in articles</h2><p><strong>' . $n . '</strong> translation(s) on traveltalk.travel still have the alt texts their Danish post had before you applied new ones under Translator → Alt texts. One short call each translates the post\'s alt texts into the translation; the article text stays as it is.</p>';
		if ( ! $n ) return;
		echo '<p><button class="button button-primary" id="lmgt-as">Bring alt texts over</button> <span id="lmgt-as-st"></span></p><pre id="lmgt-as-log" style="max-height:300px;overflow:auto;background:#fff;padding:8px"></pre>';
		$nonce = wp_create_nonce( 'lmgt_alts_sync' );
		echo "<script>(function(){var b=document.getElementById('lmgt-as'),s=document.getElementById('lmgt-as-st'),l=document.getElementById('lmgt-as-log');"
			. "function go(){var d=new FormData();d.append('action','lmgt_alts_sync');d.append('_ajax_nonce','" . esc_js( $nonce ) . "');"
			. "fetch(ajaxurl,{method:'POST',body:d,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){"
			. "if(!r.success){l.textContent+='Stopped: '+r.data+'\\n';b.disabled=false;return}l.textContent+=r.data.line+'\\n';s.textContent=r.data.left+' left';"
			. "if(r.data.left>0)go();else s.textContent='Finished.'}).catch(function(e){l.textContent+='Stopped: '+e+'\\n';b.disabled=false})}"
			. "b.addEventListener('click',function(){b.disabled=true;go()})})();</script>";
	}

	/** Source: one translation per step. */
	public static function ajax_sync() {
		check_ajax_referer( 'lmgt_alts_sync' );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_send_json_error( 'Not allowed.' );
		$todo = self::pending_sync();
		if ( ! $todo ) wp_send_json_success( array( 'left' => 0, 'line' => 'Nothing left.' ) );
		$it   = $todo[0];
		$post = get_post( $it['sid'] );
		$in   = array();
		foreach ( self::images( $post ? $post->post_content : '' ) as $im ) {
			if ( $im['key'] !== '' && $im['alt'] !== '' ) $in[ 'a' . count( $in ) ] = array( $im['key'], $im['alt'] );
		}
		$thumb = (int) get_post_thumbnail_id( $it['sid'] );
		$talt  = $thumb ? (string) get_post_meta( $thumb, '_wp_attachment_image_alt', true ) : '';
		if ( $talt !== '' ) $in['featured'] = array( 'featured', $talt );
		$where = '#' . $it['sid'] . ' ' . $it['lang'];
		$body  = array( 'source_id' => $it['sid'], 'lang' => $it['lang'], 'alts' => array() );
		if ( $in ) {
			$texts = array();
			foreach ( $in as $k => $v ) $texts[ $k ] = $v[1];
			$r = LMGT_Engines::ai_json( LMGT_Engines::prompt_translate( LMGT_Langs::source(), $it['lang'], $texts ), LMGT_Engines::schema_strings( array_keys( $texts ) ) );
			if ( is_wp_error( $r ) ) wp_send_json_error( $where . ': ' . $r->get_error_message() );
			foreach ( $in as $k => $v ) {
				if ( empty( $r[ $k ] ) ) continue;
				if ( $k === 'featured' ) $body['thumb_alt'] = sanitize_text_field( $r[ $k ] );
				else $body['alts'][ $v[0] ] = sanitize_text_field( $r[ $k ] );
			}
		}
		$res = LMGT_Bridge::call( 'POST', '/alts', $body, false );
		if ( is_wp_error( $res ) ) wp_send_json_error( $where . ': ' . $res->get_error_message() );
		$synced = (array) get_post_meta( $it['sid'], '_lmgt_alt_synced', true );
		$synced[ $it['lang'] ] = current_time( 'mysql', true );
		update_post_meta( $it['sid'], '_lmgt_alt_synced', $synced );
		wp_send_json_success( array( 'left' => count( $todo ) - 1, 'line' => $where . ': ' . ( isset( $res['changed'] ) ? (int) $res['changed'] . ' image(s)' : 'done' ) ) );
	}

	/** Target: alt attributes only, in the translation and in a waiting version; the featured image's text for that language. */
	public static function rest_alts( WP_REST_Request $req ) {
		$p    = $req->get_json_params();
		$lang = isset( $p['lang'] ) ? (string) $p['lang'] : '';
		$alts = isset( $p['alts'] ) && is_array( $p['alts'] ) ? array_map( 'sanitize_text_field', $p['alts'] ) : array();
		foreach ( LMGT_Bridge::members( isset( $p['source_id'] ) ? (int) $p['source_id'] : 0 ) as $id ) {
			if ( get_post_meta( $id, '_lmgt_lang', true ) !== $lang || get_post_type( $id ) !== LMGT_CPT || get_post_meta( $id, '_lmgt_adopted', true ) ) continue;
			$changed = 0;
			if ( $alts ) {
				$old = get_post_field( 'post_content', $id, 'raw' );
				$new = self::set_alts( $old, $alts );
				if ( $new !== $old ) {
					LMGT_Store::update_content( $id, array( 'post_content' => $new ) );
					$changed = count( array_intersect_key( $alts, array_flip( wp_list_pluck( self::images( $old ), 'key' ) ) ) );
				}
				$pend = get_post_meta( $id, '_lmgt_pending', true );
				if ( is_array( $pend ) && ! empty( $pend['translation']['content'] ) ) {
					$pend['translation']['content'] = self::set_alts( $pend['translation']['content'], $alts );
					update_post_meta( $id, '_lmgt_pending', wp_slash( $pend ) );
				}
			}
			if ( ! empty( $p['thumb_alt'] ) ) LMGT_Sync::store_thumb_texts( get_post_thumbnail_id( $id ), $lang, array( 'thumb_alt' => $p['thumb_alt'] ) );
			return array( 'id' => (int) $id, 'changed' => $changed );
		}
		return new WP_Error( 'lmgt_bad', 'No translation in that language for that original.', array( 'status' => 404 ) );
	}
}
