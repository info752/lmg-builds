<?php
/**
 * 2.9.3 (G, 9 Nov 2026): when each step last ran, in small grey type under the step ("30 min ago",
 * full date on hover). Orange "text changed since" when the text is no longer what it was then.
 * No button that reruns everything (G: the granular view is worth more).
 *
 * Meta _lmgt_stamps: [step => [at (UTC mysql), hash (md5 of the text after the step)]].
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class LMGT_Stamps {

	const MAP = array(
		'Check'     => array( 'lmgt_numbers_ok', 'lmgt_fix', 'lmgt_apply', 'lmgt_discard', 'lmgt_retranslate' ),
		'Deepen'    => array( 'lmgt_gaps', 'lmgt_gap_draft', 'lmgt_gap_insert', 'lmgt_improve' ),
		'Structure' => array( 'lmgt_structure', 'lmgt_structure_apply' ),
		'SEO'       => array( 'lmgt_seo', 'lmgt_kw_apply', 'lmgt_kw_suggest' ),
		'Links'     => array( 'lmgt_links_add', 'lmgt_links_apply', 'lmgt_links_refresh' ),
		'Boxes'     => array( 'lmgt_who_box', 'lmgt_faq_propose', 'lmgt_faq_apply', 'lmgt_box_remove', 'lmgt_facts_propose', 'lmgt_facts_apply', 'lmgt_map_propose', 'lmgt_map_apply' ),
	);

	const WAITING = array( '_lmgt_pending', '_lmgt_structure', '_lmgt_links_pending' );

	private static $hit  = array();
	private static $what = array();

	public static function text_hash( $id ) {
		$p = get_post( $id );
		return $p ? md5( preg_replace( '/\s+/', ' ', trim( $p->post_content ) ) ) : '';
	}

	/** Was the text itself changed after the waiting version under $key was made? Saving without a change does not count. */
	public static function edited_since( $id, $key, $at ) {
		$base = (string) get_post_meta( $id, '_lmgt_base' . $key, true );
		if ( $base !== '' ) return self::text_hash( $id ) !== $base;
		return $at && strtotime( get_post_field( 'post_modified_gmt', $id ) . ' UTC' ) > strtotime( $at . ' UTC' );
	}

	public static function boot() {
		foreach ( self::MAP as $step => $actions ) {
			foreach ( $actions as $a ) {
				add_action( 'admin_post_' . $a, function () use ( $step, $a ) { LMGT_Stamps::note( $step, $a ); }, 0 );
			}
		}
		add_action( 'shutdown', array( __CLASS__, 'save' ) );
		// 2.9.6: remember the text as it was when a version was proposed, so "edited since" means the text changed, not just a save.
		foreach ( array( 'added_post_meta', 'updated_post_meta' ) as $h ) {
			add_action( $h, function ( $mid, $pid, $key ) {
				if ( in_array( $key, LMGT_Stamps::WAITING, true ) ) update_post_meta( $pid, '_lmgt_base' . $key, LMGT_Stamps::text_hash( $pid ) );
			}, 10, 3 );
		}
	}

	public static function note( $step, $action = '' ) {
		foreach ( array( 'post', 'post_id', 'id' ) as $k ) {
			if ( ! empty( $_REQUEST[ $k ] ) && is_numeric( $_REQUEST[ $k ] ) ) {
				$id = (int) $_REQUEST[ $k ];
				if ( current_user_can( 'edit_post', $id ) ) {
					self::$hit[ $id ][ $step ] = true;
					// 2.17.2: what was done, for the history under the Steps panel.
					self::$what[ $id ][] = array( $step, $action, isset( $_REQUEST['do'] ) ? sanitize_key( $_REQUEST['do'] ) : '', isset( $_REQUEST['key'] ) ? sanitize_key( $_REQUEST['key'] ) : '', self::hash( $id ) );
				}
				return;
			}
		}
	}

	private static function hash( $id ) {
		clean_post_cache( $id );
		$p = get_post( $id );
		return $p ? md5( $p->post_content ) : '';
	}

	public static function save() {
		foreach ( self::$hit as $id => $steps ) {
			$all = (array) get_post_meta( $id, '_lmgt_stamps', true );
			$h   = self::hash( $id );
			foreach ( array_keys( $steps ) as $s ) $all[ $s ] = array( 'at' => current_time( 'mysql', true ), 'hash' => $h );
			update_post_meta( $id, '_lmgt_stamps', $all );
			$log = (array) get_post_meta( $id, '_lmgt_history', true );
			foreach ( isset( self::$what[ $id ] ) ? self::$what[ $id ] : array() as $w ) {
				$log[] = array( 'at' => current_time( 'mysql', true ), 'step' => $w[0], 'what' => self::label( $w[1], $w[2], $w[3] ), 'changed' => $w[4] !== $h, 'user' => (int) get_current_user_id() );
			}
			update_post_meta( $id, '_lmgt_history', array_slice( array_values( array_filter( $log, 'is_array' ) ), -20 ) );
		}
		self::$hit  = array();
		self::$what = array();
	}

	/** Stamp a step now (for choices saved with the post, such as Read more). */
	public static function set( $id, $step ) {
		$all = (array) get_post_meta( $id, '_lmgt_stamps', true );
		$all[ $step ] = array( 'at' => current_time( 'mysql', true ), 'hash' => self::hash( $id ) );
		update_post_meta( $id, '_lmgt_stamps', $all );
	}

	/** The small line for a step, or '' when it never ran. */
	public static function line( $id, $step ) {
		$all = get_post_meta( $id, '_lmgt_stamps', true );
		if ( ! is_array( $all ) || empty( $all[ $step ]['at'] ) ) return '';
		$t    = strtotime( $all[ $step ]['at'] . ' UTC' );
		$full = wp_date( 'j M Y, H:i', $t );
		$out  = '<br><span class="description" style="font-size:11px" title="' . esc_attr( $full ) . '">Last run ' . esc_html( human_time_diff( $t ) ) . ' ago</span>';
		$p    = get_post( $id );
		if ( $p && $all[ $step ]['hash'] !== '' && md5( $p->post_content ) !== $all[ $step ]['hash'] ) {
			$out .= ' <span style="font-size:11px;color:#b26200;font-weight:600">· text changed since</span>';
		}
		return $out;
	}

	/** 2.17.2: plain words for an action. */
	private static function label( $a, $do, $key ) {
		$no = $do === 'drop' ? 'rejected' : 'accepted';
		$L  = array(
			'lmgt_numbers_ok' => 'numbers marked as checked', 'lmgt_fix' => 'flags fixed (proposal)', 'lmgt_apply' => 'translation put in', 'lmgt_discard' => 'waiting version discarded', 'lmgt_retranslate' => 'sent for new translation',
			'lmgt_gaps' => 'content gaps found', 'lmgt_gap_draft' => 'new sections written', 'lmgt_gap_insert' => 'new sections put in', 'lmgt_improve' => 'improved',
			'lmgt_structure' => 'structure proposed', 'lmgt_structure_apply' => 'structure ' . $no,
			'lmgt_seo' => 'keyword and meta proposed', 'lmgt_kw_apply' => 'keyword and meta set', 'lmgt_kw_suggest' => 'extra keywords suggested',
			'lmgt_links_add' => 'links proposed', 'lmgt_links_apply' => 'links ' . $no, 'lmgt_links_refresh' => 'links counted',
			'lmgt_who_box' => '"Who takes you there" put in', 'lmgt_faq_propose' => 'questions proposed', 'lmgt_faq_apply' => 'questions ' . $no,
			'lmgt_facts_propose' => 'fact box proposed', 'lmgt_facts_apply' => 'fact box ' . $no, 'lmgt_map_propose' => 'map proposed', 'lmgt_map_apply' => 'map ' . $no,
			'lmgt_box_remove' => ( $key ? $key . ' box' : 'box' ) . ' removed',
		);
		return isset( $L[ $a ] ) ? $L[ $a ] : $a;
	}

	/** 2.17.2 (G, 14 Nov): "when are what corrections done" – the last 20 actions under the Steps panel, newest first. */
	public static function history_html( $id ) {
		$log = get_post_meta( $id, '_lmgt_history', true );
		if ( ! is_array( $log ) || ! $log ) return '<p class="description" style="margin-top:10px">History: nothing done with Translator on this text yet (recorded from 2.17.2 on).</p>';
		$h = '<details style="margin-top:10px" open><summary style="cursor:pointer;font-weight:600">History – what was done, when (' . count( $log ) . ')</summary><table class="widefat striped" style="margin-top:6px;max-width:760px"><tbody>';
		foreach ( array_reverse( $log ) as $e ) {
			$t = strtotime( $e['at'] . ' UTC' );
			$u = ! empty( $e['user'] ) ? get_userdata( $e['user'] ) : null;
			$h .= '<tr><td style="white-space:nowrap;width:150px">' . esc_html( wp_date( 'j M Y, H:i', $t ) ) . '</td><td style="width:90px"><strong>' . esc_html( $e['step'] ) . '</strong></td><td>' . esc_html( $e['what'] ) . ( ! empty( $e['changed'] ) ? ' <span style="color:#008a20">· text changed</span>' : '' ) . '</td><td class="description" style="width:120px">' . esc_html( $u ? $u->display_name : '' ) . '</td></tr>';
		}
		return $h . '</tbody></table></details>';
	}
}
