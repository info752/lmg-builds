<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Where translations live: their own post type, `lmgt_translation`.
 *
 * Not ordinary posts, on purpose. A translation that is a normal post shows up
 * in Danish archives, the front page, feeds, search, category pages and the
 * concierge's corpus. As its own type it appears nowhere it is not asked for,
 * and — the property that matters most — removing translations can never touch
 * an original: Trash on this type is Trash on translations only.
 *
 * Meta on each translation:
 *   _lmgt_source           original post ID
 *   _lmgt_lang             target code (sv, nb, …)
 *   _lmgt_source_type      post or page, for choosing the template
 *   _lmgt_source_modified  original's post_modified_gmt when translated (stale check)
 *   _lmgt_report           the checks: issues, numbers, languages, suggestions
 *   _lmgt_reviewed         '1' once a person has read the report
 *   _lmgt_pending          a newer version waiting while the live one stays up
 *
 * A hand-written translation that already exists as an ordinary post keeps its
 * post type and its address; it is "tagged" with _lmgt_source and _lmgt_lang
 * instead, joins the original's hreflang set, and leaves the source-language
 * listings through LMGT_Front::hide_tagged(). Tagged IDs are kept in the
 * lmgt_tagged option so that filter needs no meta join.
 */
class LMGT_Store {

	/** 2.4.0: post, page and the post types ticked under Settings → Post types (airline pages by default). */
	public static function types( $with_translations = false ) {
		$t = array_merge( array( 'post', 'page' ), self::extra() );
		$t = array_values( array_unique( (array) apply_filters( 'lmgt_post_types', $t ) ) );
		if ( $with_translations ) $t[] = LMGT_CPT;
		return $t;
	}

	public static function extra() {
		$saved = get_option( 'lmgt_extra_types', '__auto' );
		if ( $saved === '__auto' ) $saved = did_action( 'init' ) ? self::airline_types() : array();
		$out = array();
		foreach ( (array) $saved as $x ) {
			$x = sanitize_key( $x );
			if ( $x && ! in_array( $x, array( 'post', 'page', LMGT_CPT, 'attachment' ), true ) && ( ! did_action( 'init' ) || post_type_exists( $x ) ) ) $out[] = $x;
		}
		return $out;
	}

	/** Public custom post types that can be ticked. */
	public static function candidates() {
		$out = array();
		foreach ( get_post_types( array( 'public' => true, '_builtin' => false ), 'objects' ) as $name => $o ) {
			if ( $name !== LMGT_CPT ) $out[ $name ] = $o;
		}
		return $out;
	}

	/** Types whose name, address or label says airline/airport (flyselskaber, airlines, lufthavne, airports). */
	public static function airline_types() {
		$out = array();
		foreach ( self::candidates() as $name => $o ) {
			$hay = $name . ' ' . ( is_array( $o->rewrite ) && ! empty( $o->rewrite['slug'] ) ? $o->rewrite['slug'] : '' ) . ' ' . $o->label;
			if ( preg_match( '/airline|flyselskab|airport|lufthavn|flygbolag|flyselskap/i', $hay ) ) $out[] = $name;
		}
		return $out;
	}

	public static function boot() {
		add_action( 'init', array( __CLASS__, 'register_type' ) );
		// 2.6.3 (G, 8 Nov): the plugin's own buttons (structure, gaps, fix, improve, apply) save the
		// text from a request that carries no Rank Math form, and Rank Math then cleared the pillar
		// tick. During those requests the tick cannot be taken away.
		add_filter( 'delete_post_metadata', array( __CLASS__, 'keep_pillar' ), 10, 3 );
		add_filter( 'update_post_metadata', array( __CLASS__, 'keep_pillar_update' ), 10, 4 );
		add_filter( 'post_type_link', array( __CLASS__, 'permalink' ), 10, 2 );
		add_filter( 'wp_unique_post_slug', array( __CLASS__, 'unique_slug' ), 10, 6 );
		add_filter( 'wp_insert_post_data', array( __CLASS__, 'publish_gate' ), 10, 2 );
		add_action( 'load-post.php', array( __CLASS__, 'guard_on_load' ) );
		// A person's own save in the editor is the truth: the snapshot no longer applies.
		add_action( 'save_post', function ( $id ) { if ( isset( $_POST['action'] ) && $_POST['action'] === 'editpost' ) delete_post_meta( $id, '_lmgt_guard' ); }, 1 );
		// 2.17.17 (G, 16 Nov: "can't set the featured image on a translation"): the Featured image box saves at once, outside
		// the edit-screen save, so the guard put the old picture back the next time the screen opened. A picture you choose is yours.
		add_action( 'wp_ajax_set-post-thumbnail', function () { if ( ! empty( $_POST['post_id'] ) ) delete_post_meta( (int) $_POST['post_id'], '_lmgt_guard' ); }, 1 );
		add_action( 'wp_ajax_get-post-thumbnail-html', function () { if ( ! empty( $_POST['post_id'] ) ) delete_post_meta( (int) $_POST['post_id'], '_lmgt_guard' ); }, 1 );
		add_action( 'transition_post_status', array( __CLASS__, 'on_transition' ), 10, 3 );
		add_action( 'pre_get_posts', array( __CLASS__, 'target_search' ) );
	}

	/** On the target site translations are the content: site search finds them, in the listing's language. */
	public static function target_search( $q ) {
		if ( is_admin() || ! $q->is_main_query() || ! $q->is_search() || ! LMGT_Bridge::is_target() ) return;
		$types = $q->get( 'post_type' );
		if ( ! $types || 'any' === $types ) $types = LMGT_Store::types();
		$types   = array_unique( array_merge( (array) $types, array( LMGT_CPT ) ) );
		$lang    = get_query_var( 'lmgt_lang_home' ) ? get_query_var( 'lmgt_lang_home' ) : 'en';
		$meta    = (array) $q->get( 'meta_query' );
		$meta[]  = array(
			'relation' => 'OR',
			array( 'key' => '_lmgt_lang', 'compare' => 'NOT EXISTS' ),
			array( 'key' => '_lmgt_lang', 'value' => $lang ),
		);
		$q->set( 'post_type', $types );
		$q->set( 'meta_query', $meta );
	}

	public static function register_type() {
		register_post_type( LMGT_CPT, array(
			'labels'              => array(
				'name'          => 'Translations',
				'singular_name' => 'Translation',
				'edit_item'     => 'Edit translation',
				'all_items'     => 'All translations',
				'search_items'  => 'Search translations',
				'not_found'     => 'No translations yet',
			),
			// Public so SEO plugins index it and list it in their sitemaps; kept
			// out of site search and menus on the source, and with no archive of its own.
			'public'              => true,
			'publicly_queryable'  => true,
			'exclude_from_search' => true,
			'show_in_nav_menus'   => LMGT_Bridge::is_target(),
			'has_archive'         => false,
			'rewrite'             => false,
			'query_var'           => LMGT_CPT,
			'show_ui'             => true,
			'show_in_menu'        => 'lmgt',
			'show_in_rest'        => true,
			'hierarchical'        => false,
			'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'custom-fields' ),
			'capability_type'     => 'post',
			'map_meta_cap'        => true,
		) );
	}

	// ---- Length and content gaps ---------------------------------------------

	/** Pages (the destination guides) and anything with Rank Math's pillar tick carry the higher minimum. */
	public static function is_pillar( $id ) {
		return $id && ( get_post_type( (int) $id ) === 'page' || in_array( get_post_type( (int) $id ), LMGT_Store::extra(), true ) || get_post_meta( (int) $id, 'rank_math_pillar_content', true ) === 'on' );
	}

	/** Category and page addresses that mark news (2.2.27). */
	const NEWS_SLUGS = array( 'news', 'nyheder', 'rejsenyt', 'travel-news' );

	/**
	 * 2.2.27 (G, 2 Nov 2026): news is translated exactly as written, in every language:
	 * no "thin" mark, no content-gap or expansion suggestions, never held back from
	 * Google for its length. True for a post in a News category (or the Travel News /
	 * Rejsenyt page), for anything with "Translate as written" ticked, and for the
	 * translations of those.
	 */
	public static function as_written( $id ) {
		$id = (int) $id;
		if ( ! $id || ! get_post( $id ) ) return false;
		if ( get_post_meta( $id, '_lmgt_as_written', true ) === '1' ) return true;
		if ( get_post_type( $id ) === LMGT_CPT ) {
			$src = (int) get_post_meta( $id, '_lmgt_source', true );
			return $src && $src !== $id && get_post_type( $src ) !== LMGT_CPT ? self::as_written( $src ) : false;
		}
		if ( get_post_type( $id ) === 'page' ) return in_array( get_post_field( 'post_name', $id ), self::NEWS_SLUGS, true );
		foreach ( (array) get_the_category( $id ) as $c ) {
			if ( in_array( $c->slug, self::NEWS_SLUGS, true ) ) return true;
		}
		return false;
	}

	public static function min_words( $id = 0 ) {
		if ( $id && self::as_written( $id ) ) return 0;
		return self::is_pillar( $id )
			? max( 100, (int) get_option( 'lmgt_min_words_pillar', 1500 ) )
			: max( 100, (int) get_option( 'lmgt_min_words', 800 ) );
	}

	public static function words( $post ) {
		$post = get_post( $post );
		$t    = $post ? LMGT_Text::plain( $post->post_content ) : '';
		return $t === '' ? 0 : count( preg_split( '/\s+/u', $t ) );
	}

	/**
	 * On .travel, a translation under the threshold (Settings, default 800 words)
	 * is published with noindex and kept out of the sitemap and hreflang until it
	 * is filled out (G, 26 Oct 2026). 0 switches it off.
	 */
	public static function is_thin( $post ) {
		$post = get_post( $post );
		$min  = (int) get_option( 'lmgt_noindex_under', 800 );
		return $min > 0 && $post && LMGT_Bridge::is_target() && $post->post_type === LMGT_CPT && self::words( $post ) < $min && ! self::as_written( $post->ID );
	}

	/** Gaps found for an original, stored with the date, shown in its Translations box. */

	/**
	 * 2.5.3 (G, 7 Nov): "I have read the check" belongs to one version of the text and its
	 * check. When the text changes (sections added, a waiting version applied, a new copy
	 * from .dk) or the check is run again, the tick no longer counts and the box is unticked.
	 */
	public static function review_sig( $id ) {
		$p = get_post( (int) $id );
		return $p ? md5( $p->post_content . '|' . maybe_serialize( get_post_meta( $p->ID, '_lmgt_report', true ) ) ) : '';
	}

	public static function is_reviewed( $id ) {
		$v = (string) get_post_meta( (int) $id, '_lmgt_reviewed', true );
		if ( $v === '' ) return false;
		if ( $v === '1' ) return get_post_status( (int) $id ) === 'publish'; // ticked before 2.5.3: counts only for what is already live
		return hash_equals( self::review_sig( $id ), $v );
	}

	public static function mark_reviewed( $id, $on = true ) {
		if ( $on ) update_post_meta( (int) $id, '_lmgt_reviewed', self::review_sig( $id ) );
		else delete_post_meta( (int) $id, '_lmgt_reviewed' );
	}

	/**
	 * Next version (G, 11 Nov 2026): changing the text from a Translator step (structure, boxes, links,
	 * alt texts, pictures ...) set an article's categories back to "Uncategorized" on traveltalk.dk.
	 * The step saves only the text, but another plugin listening to the save resets the terms when the
	 * save does not come from the edit screen. So every Translator text save goes through here: the
	 * post's terms in every taxonomy are remembered first and put back if anything changed them.
	 *
	 * @return int|WP_Error as wp_update_post
	 */
	/**
	 * 2.17.6 (G, 14 Nov, "Antica Enoteca": adding a map wiped the focus keyword and the SEO work). Like the
	 * categories, another plugin listening to the save clears SEO fields when the save does not come from the
	 * edit screen. Every Translator text save keeps them: Rank Math's fields, the featured image, the page
	 * template and the theme's per-post settings are remembered first and put back if the save changed them.
	 */
	private static $guarded = array();

	/** Put terms and SEO fields back to the snapshot; $why for the log. Returns what was restored. */
	public static function guard_check( $id, $why ) {
		$g = get_post_meta( $id, '_lmgt_guard', true );
		if ( ! is_array( $g ) || empty( $g['at'] ) || time() - (int) $g['at'] > 30 * MINUTE_IN_SECONDS ) return array();
		$put = array();
		foreach ( (array) $g['terms'] as $tax => $ids ) {
			$now = wp_get_object_terms( $id, $tax, array( 'fields' => 'ids' ) );
			$now = is_wp_error( $now ) ? array() : array_map( 'intval', $now );
			sort( $now ); $was = array_map( 'intval', (array) $ids ); sort( $was );
			if ( $now !== $was && $was ) { wp_set_object_terms( $id, $was, $tax, false ); $put[] = $tax; }
		}
		$put = array_merge( $put, self::meta_restore( $id, (array) $g['meta'] ) );
		if ( $put && class_exists( 'LMGT_Bridge' ) && LMGT_Bridge::on() ) LMGT_Bridge::log( 'put back on post ' . $id . ' (' . $why . '): ' . implode( ', ', $put ) );
		return $put;
	}

	public static function guard_late() {
		foreach ( array_unique( self::$guarded ) as $id ) self::guard_check( $id, 'end of the Translator save' );
	}

	/** When the post is opened in the editor within 30 minutes of a Translator save: check once more and say so. */
	public static function guard_on_load() {
		$id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
		if ( ! $id || ! current_user_can( 'edit_post', $id ) ) return;
		$put = self::guard_check( $id, 'edit screen opened' );
		if ( $put ) add_action( 'admin_notices', function () use ( $put ) {
			echo '<div class="notice notice-warning"><p><strong>Translator put back what another plugin changed after the last Translator step:</strong> ' . esc_html( implode( ', ', $put ) ) . '. Check the categories and the SEO box, then press Update.</p></div>';
		} );
	}

	const KEEP_META = array( 'rank_math_', '_thumbnail_id', '_wp_page_template', '_kad_', '_kadence', '_yoast_wpseo_', 'cmplz_' );

	public static function meta_snapshot( $id ) {
		$out = array();
		foreach ( (array) get_post_meta( (int) $id ) as $k => $vals ) {
			foreach ( self::KEEP_META as $pre ) if ( strpos( $k, $pre ) === 0 ) { $out[ $k ] = $vals; break; }
		}
		return $out;
	}

	public static function meta_restore( $id, array $snap ) {
		$id  = (int) $id;
		wp_cache_delete( $id, 'post_meta' );
		$now = (array) get_post_meta( $id );
		$put = array();
		foreach ( $snap as $k => $vals ) {
			if ( isset( $now[ $k ] ) && $now[ $k ] === $vals ) continue;
			delete_post_meta( $id, $k );
			foreach ( $vals as $v ) add_post_meta( $id, $k, wp_slash( maybe_unserialize( $v ) ) );
			$put[] = $k;
		}
		if ( $put && class_exists( 'LMGT_Bridge' ) && LMGT_Bridge::on() ) LMGT_Bridge::log( 'SEO fields put back on post ' . $id . ' (' . implode( ', ', $put ) . '): another plugin changed them during a Translator save' );
		return $put;
	}

	public static function update_content( $id, array $fields, $wp_error = false ) {
		$id    = (int) $id;
		$taxes = get_object_taxonomies( get_post_type( $id ) );
		$before = array();
		foreach ( $taxes as $tax ) {
			$t = wp_get_object_terms( $id, $tax, array( 'fields' => 'ids' ) );
			if ( ! is_wp_error( $t ) ) $before[ $tax ] = array_map( 'intval', $t );
		}
		$meta = self::meta_snapshot( $id );
		// 2.17.8 (G, 14 Nov, Roman wine bar: "categories dropped out too"): keep the snapshot, so a plugin that
		// changes terms or SEO fields later in the request, or on the next load, is undone as well.
		update_post_meta( $id, '_lmgt_guard', array( 'at' => time(), 'terms' => $before, 'meta' => $meta ) );
		if ( ! has_action( 'shutdown', array( __CLASS__, 'guard_late' ) ) ) add_action( 'shutdown', array( __CLASS__, 'guard_late' ), 999 );
		self::$guarded[] = $id;
		$r = wp_update_post( wp_slash( array( 'ID' => $id ) + $fields ), $wp_error );
		self::meta_restore( $id, $meta );
		foreach ( $before as $tax => $ids ) {
			$now = wp_get_object_terms( $id, $tax, array( 'fields' => 'ids' ) );
			$now = is_wp_error( $now ) ? array() : array_map( 'intval', $now );
			sort( $now );
			$was = $ids;
			sort( $was );
			if ( $now !== $was ) {
				wp_set_object_terms( $id, $ids, $tax, false );
				if ( class_exists( 'LMGT_Bridge' ) && LMGT_Bridge::on() ) LMGT_Bridge::log( 'terms put back on post ' . $id . ' (' . $tax . '): another plugin changed them during a Translator save' );
			}
		}
		return $r;
	}

	public static function set_gaps( $id, array $gaps, $providers = null ) {
		if ( $providers === null ) { // keep the names a person's own check found (2.4.2)
			$old = get_post_meta( (int) $id, '_lmgt_gaps', true );
			$providers = is_array( $old ) && ! empty( $old['providers'] ) ? $old['providers'] : array();
		}
		$gaps = array_values( array_filter( $gaps, function ( $g ) { return is_array( $g ) && ! empty( $g['topic'] ); } ) );
		$providers = array_values( array_filter( array_map( function ( $p ) {
			if ( ! is_array( $p ) || empty( $p['name'] ) ) return null;
			$web  = isset( $p['web'] ) ? esc_url_raw( (string) $p['web'] ) : '';
			$live = 0;
			// 2.8.0 (G, 9 Nov): check that the company's website answers before it is offered.
			if ( $web !== '' ) {
				$h = wp_remote_get( $web, array( 'timeout' => 8, 'redirection' => 3, 'limit_response_size' => 20000 ) );
				$c = is_wp_error( $h ) ? 0 : (int) wp_remote_retrieve_response_code( $h );
				$live = ( $c >= 200 && $c < 400 ) ? 1 : 0;
			}
			return array( 'name' => sanitize_text_field( $p['name'] ), 'kind' => ( isset( $p['kind'] ) && in_array( $p['kind'], array( 'airline', 'agency', 'transport' ), true ) ) ? $p['kind'] : ( isset( $p['kind'] ) && $p['kind'] === 'abroad' ? 'agency' : 'local' ), 'what' => isset( $p['what'] ) ? sanitize_text_field( $p['what'] ) : '', 'web' => $web, 'live' => $live );
		}, (array) $providers ) ) );
		update_post_meta( (int) $id, '_lmgt_gaps', wp_slash( array( 'gaps' => $gaps, 'providers' => $providers, 'at' => current_time( 'mysql', true ) ) ) );
	}

	/**
	 * Only suggestions that change the text. An engine sometimes returns a note
	 * ("no change needed") as the suggestion; written in, it would become text.
	 */
	public static function real_suggestions( $list ) {
		$out = array();
		foreach ( (array) $list as $s ) {
			$a = isset( $s['text'] ) ? trim( (string) $s['text'] ) : '';
			$b = isset( $s['suggestion'] ) ? trim( (string) $s['suggestion'] ) : '';
			if ( $a === '' || $b === '' || $a === $b ) continue;
			if ( preg_match( '/no change|unchanged|keep as is|ingen ændring|uændret|behold|correct as|\(.*(note|ok|fine).*\)/iu', $b ) ) continue;
			$out[] = $s;
		}
		return $out;
	}

	// ---- Lookups -------------------------------------------------------------

	/** All translations of one original, tagged posts included, keyed by language. Any status but trash. */
	public static function of( $source_id, $statuses = array( 'publish', 'draft', 'pending', 'future', 'private' ) ) {
		$ids = get_posts( array(
			'post_type'      => LMGT_Store::types( true ),
			'lmgt_all'       => true,
			'post_status'    => $statuses,
			'posts_per_page' => 50,
			'fields'         => 'ids',
			'meta_key'       => '_lmgt_source',
			'meta_value'     => (int) $source_id,
			'no_found_rows'  => true,
		) );
		$out = array();
		foreach ( $ids as $id ) {
			$l = get_post_meta( $id, '_lmgt_lang', true );
			if ( $l ) $out[ $l ] = (int) $id;
		}
		return $out;
	}

	public static function find( $lang, $slug, $statuses = array( 'publish' ) ) {
		$ids = get_posts( array(
			'post_type'      => LMGT_CPT,
			'post_status'    => $statuses,
			'name'           => $slug,
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'meta_key'       => '_lmgt_lang',
			'meta_value'     => $lang,
			'no_found_rows'  => true,
		) );
		return $ids ? (int) $ids[0] : 0;
	}

	public static function is_translation( $post ) {
		$post = get_post( $post );
		return $post && ( $post->post_type === LMGT_CPT || self::is_tagged( $post->ID ) );
	}

	/** An ordinary post or page tagged as a hand-written translation. */
	public static function is_tagged( $id ) {
		return in_array( (int) $id, self::tagged(), true );
	}

	/** Language a post's text reads as, or null when it is too short to tell. */
	public static function reads_as( $post ) {
		$post = get_post( $post );
		if ( ! $post ) return null;
		$d = LMGT_Text::detect( LMGT_Text::plain( $post->post_title . ' ' . $post->post_content ) );
		return $d['code'];
	}

	/** @return int[] */
	public static function tagged() {
		return array_map( 'intval', (array) get_option( 'lmgt_tagged', array() ) );
	}

	// ---- Addresses -----------------------------------------------------------

	/** /sv/<slug>/ — flat and short, per the house rule on URL depth. */
	public static function permalink( $link, $post ) {
		if ( $post->post_type !== LMGT_CPT || $post->post_name === '' ) return $link;
		if ( ! in_array( $post->post_status, array( 'publish', 'private', 'future' ), true ) ) return $link;
		$l = LMGT_Langs::get( get_post_meta( $post->ID, '_lmgt_lang', true ) );
		if ( ! $l ) return $link;
		$prefix = LMGT_Bridge::prefix( get_post_meta( $post->ID, '_lmgt_lang', true ) );
		return home_url( user_trailingslashit( ( $prefix === '' ? '' : $prefix . '/' ) . $post->post_name ) );
	}

	/**
	 * Unique within a language, not across the whole type, so the Swedish and
	 * Norwegian "bulgarien" can both be "bulgarien". Also steers clear of real
	 * pages already living under the prefix (/fi/… is the Finnish departure page
	 * and has children), so a translation can never shadow one.
	 */
	public static function unique_slug( $slug, $post_id, $status, $type, $parent, $original ) {
		if ( $type !== LMGT_CPT ) return $slug;
		$lang = get_post_meta( $post_id, '_lmgt_lang', true );
		if ( ! $lang ) $lang = isset( $GLOBALS['lmgt_saving_lang'] ) ? $GLOBALS['lmgt_saving_lang'] : '';
		$l = LMGT_Langs::get( $lang );
		if ( ! $l ) return $slug;
		$base = sanitize_title( $original !== '' ? $original : $slug );
		$try  = $base;
		for ( $n = 2; $n < 50; $n++ ) {
			$other = self::find( $lang, $try, array( 'publish', 'draft', 'pending', 'future', 'private' ) );
			$prefix = LMGT_Bridge::prefix( $lang );
			$page  = $prefix === '' ? get_page_by_path( $try, OBJECT, array( 'post', 'page' ) ) : get_page_by_path( $prefix . '/' . $try );
			if ( ( ! $other || $other === (int) $post_id ) && ! $page ) return $try;
			$try = $base . '-' . $n;
		}
		return $try;
	}

	// ---- Saving --------------------------------------------------------------

	/**
	 * Create the translation as a draft, or refresh an existing draft. A
	 * published translation is never overwritten by a machine: the new version
	 * waits in _lmgt_pending until a person applies it on the edit screen.
	 *
	 * @return int|WP_Error translation ID
	 */
	public static function save( $source_id, $lang, array $t, array $report ) {
		$src = get_post( $source_id );
		if ( ! $src ) return new WP_Error( 'lmgt_source', 'Original no longer exists.' );
		$existing = self::of( $source_id );
		$id       = isset( $existing[ $lang ] ) ? $existing[ $lang ] : 0;
		if ( $id && self::is_tagged( $id ) ) return new WP_Error( 'lmgt_tagged', 'A hand-written ' . LMGT_Langs::get( $lang )['name'] . ' translation exists. Nothing saved.' );

		if ( $id && get_post_status( $id ) === 'publish' ) {
			update_post_meta( $id, '_lmgt_pending', wp_slash( array( 'translation' => $t, 'report' => $report, 'source_modified' => $src->post_modified_gmt, 'made_with' => LMGT_VERSION, 'at' => current_time( 'mysql', true ) ) ) );
			return $id;
		}

		$GLOBALS['lmgt_saving_lang'] = $lang;
		$data = array(
			'post_type'    => LMGT_CPT,
			'post_status'  => 'draft',
			'post_title'   => $t['title'],
			'post_content' => $t['content'],
			'post_excerpt' => $t['excerpt'],
			'post_author'  => $src->post_author,
			'post_name'    => $id ? get_post_field( 'post_name', $id ) : self::short_slug( $lang, $t, $src->post_type === 'page' ),
			'comment_status' => 'closed',
			'ping_status'  => 'closed',
		);
		if ( $id ) {
			$data['ID'] = $id;
			$r = wp_update_post( wp_slash( $data ), true );
		} else {
			$r = wp_insert_post( wp_slash( $data ), true );
		}
		unset( $GLOBALS['lmgt_saving_lang'] );
		if ( is_wp_error( $r ) ) return $r;
		$id = (int) $r;

		update_post_meta( $id, '_lmgt_source', (int) $source_id );
		update_post_meta( $id, '_lmgt_lang', $lang );
		update_post_meta( $id, '_lmgt_source_type', $src->post_type );
		update_post_meta( $id, '_lmgt_source_modified', $src->post_modified_gmt );
		update_post_meta( $id, '_lmgt_report', wp_slash( $report ) );
		update_post_meta( $id, '_lmgt_made_with', LMGT_VERSION );
		delete_post_meta( $id, '_lmgt_reviewed' );
		delete_post_meta( $id, '_lmgt_pending' );

		$thumb = get_post_thumbnail_id( $source_id );
		if ( $thumb ) set_post_thumbnail( $id, $thumb );
		if ( $src->post_type === 'page' ) {
			$tpl = get_page_template_slug( $source_id );
			if ( $tpl ) update_post_meta( $id, '_lmgt_page_template', $tpl );
		}
		// 2.17.9 (G, 14 Nov): an SEO title or description a person has set is kept; only an empty field is filled.
		if ( $t['seo_title'] !== '' && trim( (string) get_post_meta( $id, 'rank_math_title', true ) ) === '' ) update_post_meta( $id, 'rank_math_title', $t['seo_title'] );
		if ( $t['seo_desc'] !== '' && trim( (string) get_post_meta( $id, 'rank_math_description', true ) ) === '' ) update_post_meta( $id, 'rank_math_description', $t['seo_desc'] );
		// Every saved translation gets a focus keyword and a meta description where
		// those are still empty: new ones from the call that chose their address,
		// re-translated drafts from a call of their own. Filled fields are left alone.
		$need = get_post_meta( $id, 'rank_math_focus_keyword', true ) === '' || get_post_meta( $id, 'rank_math_description', true ) === '';
		if ( $need ) {
			$seo = ! empty( $GLOBALS['lmgt_seo_new'] ) ? $GLOBALS['lmgt_seo_new'] : self::seo_basics( $lang, $t['title'], $t['content'], $src->post_type === 'page' );
			if ( get_post_meta( $id, 'rank_math_focus_keyword', true ) !== '' ) $seo['keyword'] = '';
			if ( get_post_meta( $id, 'rank_math_description', true ) !== '' ) $seo['meta'] = '';
			self::apply_seo( $id, $seo );
		}
		unset( $GLOBALS['lmgt_seo_new'] );
		// The address and SEO calls above belong to this draft's cost.
		if ( isset( $report['meter'] ) ) {
			$report['meter'] = LMGT_Meter::sum( $report['meter'], LMGT_Meter::peek() );
			update_post_meta( $id, '_lmgt_report', wp_slash( $report ) );
		}
		return $id;
	}

	/**
	 * Address for a new translation: short, around the search term (house rule
	 * on URLs). Falls back to the title when the engine is unavailable or odd.
	 */
	private static function short_slug( $lang, array $t, $guide = false ) {
		$seo  = self::seo_basics( $lang, $t['title'], $t['content'], $guide );
		$GLOBALS['lmgt_seo_new'] = $seo;
		return $seo['slug'] !== '' ? $seo['slug'] : sanitize_title( $t['title'] );
	}

	/** @return array keyword, meta, slug — each '' when the engine gave nothing usable. */
	public static function seo_basics( $lang, $title, $content, $guide = false, $fixed = '' ) {
		$out = array( 'keyword' => '', 'meta' => '', 'slug' => '' );
		if ( ! LMGT_Engines::ai_available() ) return $out;
		$r = LMGT_Engines::ai_json( LMGT_Engines::prompt_seo( $lang, $title, mb_substr( LMGT_Text::plain( $content ), 0, 800 ), $guide, $fixed ) );
		if ( ! is_array( $r ) ) return $out;
		$slug = ! empty( $r['slug'] ) ? sanitize_title( $r['slug'] ) : '';
		$n    = $slug === '' ? 0 : count( explode( '-', $slug ) );
		$meta = ! empty( $r['meta'] ) ? trim( sanitize_text_field( $r['meta'] ) ) : '';
		$kw   = ! empty( $r['keyword'] ) ? trim( sanitize_text_field( $r['keyword'] ) ) : '';
		$out['slug']    = ( $n >= 2 && $n <= 8 ) ? $slug : '';
		$out['keyword'] = mb_strlen( $kw ) <= 60 ? $kw : '';
		$out['meta']    = ( mb_strlen( $meta ) >= 80 && mb_strlen( $meta ) <= 200 ) ? $meta : '';
		return $out;
	}

	/** Rank Math fields for a translation. Only what came back is written. */
	/** 2.17.9 (G, 14 Nov: "human set the keywords, AI does not delete, but may advise"): fills only empty fields. */
	public static function apply_seo( $id, array $seo ) {
		if ( $seo['keyword'] !== '' && trim( (string) get_post_meta( $id, 'rank_math_focus_keyword', true ) ) === '' ) update_post_meta( $id, 'rank_math_focus_keyword', $seo['keyword'] );
		if ( $seo['meta'] !== '' && trim( (string) get_post_meta( $id, 'rank_math_description', true ) ) === '' ) update_post_meta( $id, 'rank_math_description', $seo['meta'] );
	}

	/** Apply a waiting machine version to a published translation — a person's click. */
	public static function apply_pending( $id ) {
		$p = get_post_meta( $id, '_lmgt_pending', true );
		if ( ! is_array( $p ) || empty( $p['translation'] ) ) return false;
		$t = $p['translation'];
		$meta = self::meta_snapshot( $id );
		wp_update_post( wp_slash( array( 'ID' => $id, 'post_title' => $t['title'], 'post_content' => $t['content'], 'post_excerpt' => $t['excerpt'] ) ) );
		self::meta_restore( $id, $meta );
		// 2.17.9 (G, 14 Nov): an SEO title or description a person has set is kept; only an empty field is filled.
		if ( $t['seo_title'] !== '' && trim( (string) get_post_meta( $id, 'rank_math_title', true ) ) === '' ) update_post_meta( $id, 'rank_math_title', $t['seo_title'] );
		if ( $t['seo_desc'] !== '' && trim( (string) get_post_meta( $id, 'rank_math_description', true ) ) === '' ) update_post_meta( $id, 'rank_math_description', $t['seo_desc'] );
		update_post_meta( $id, '_lmgt_report', wp_slash( $p['report'] ) );
		update_post_meta( $id, '_lmgt_source_modified', $p['source_modified'] );
		if ( ! empty( $p['source_hash'] ) ) LMGT_Sync::made_from( $id, $p['source_hash'] );
		if ( ! empty( $p['source_stale'] ) ) update_post_meta( $id, '_lmgt_mother_changed', $p['source_stale'] );
		if ( ! empty( $p['made_with'] ) ) update_post_meta( $id, '_lmgt_made_with', sanitize_text_field( $p['made_with'] ) );
		delete_post_meta( $id, '_lmgt_pending' );
		return true;
	}

	// ---- Rules on status changes ---------------------------------------------

	/**
	 * 2.6.3 (G, 8 Nov: "the errors don't disappear"): the check sometimes lists a passage and
	 * then says in its own note that nothing changed ("Equivalent; no omission"). Those are not
	 * flags. They are left out of the list, the count and the publish gate.
	 */
	private static function own_request() {
		$a = isset( $_REQUEST['action'] ) ? (string) $_REQUEST['action'] : '';
		return strpos( $a, 'lmgt_' ) === 0 && ( did_action( 'admin_post_' . $a ) || doing_action( 'admin_post_' . $a ) || wp_doing_ajax() || doing_action( 'admin_init' ) || is_admin() );
	}

	public static function keep_pillar( $skip, $id, $key ) {
		return $key === 'rank_math_pillar_content' && self::own_request() ? true : $skip;
	}

	public static function keep_pillar_update( $skip, $id, $key, $value ) {
		return $key === 'rank_math_pillar_content' && $value !== 'on' && self::own_request() && get_post_meta( $id, $key, true ) === 'on' ? true : $skip;
	}

	public static function real_issues( $r ) {
		$out = array();
		foreach ( (array) ( is_array( $r ) && isset( $r['issues'] ) ? $r['issues'] : array() ) as $i ) {
			$note = mb_strtolower( isset( $i['note'] ) ? (string) $i['note'] : '' );
			if ( $note !== '' && preg_match( '/^(equivalent|same meaning|no (difference|omission|change|issue))|\b(equivalent|identical)( wording| meaning)?[.;,]? *(no (difference|omission|change))?\.?$/u', trim( $note ) ) ) continue;
			$out[] = $i;
		}
		return $out;
	}

	/** 2.17.4: number flags only (in the original but not the translation, or the reverse). */
	public static function open_numbers( $id ) {
		$r = get_post_meta( $id, '_lmgt_report', true );
		if ( ! is_array( $r ) ) return 0;
		return ( isset( $r['numbers']['missing'] ) ? count( (array) $r['numbers']['missing'] ) : 0 ) + ( isset( $r['numbers']['extra'] ) ? count( (array) $r['numbers']['extra'] ) : 0 );
	}

	public static function open_issues( $id ) {
		$r = get_post_meta( $id, '_lmgt_report', true );
		if ( ! is_array( $r ) ) return 0;
		$n = count( self::real_issues( $r ) );
		$n += isset( $r['numbers']['missing'] ) ? count( (array) $r['numbers']['missing'] ) : 0;
		$n += isset( $r['numbers']['extra'] ) ? count( (array) $r['numbers']['extra'] ) : 0;
		return $n;
	}

	/**
	 * A translation with flags cannot be published until someone has ticked
	 * "I have read the check" on its edit screen. It stays a draft and says why.
	 */
	public static function publish_gate( $data, $postarr ) {
		if ( $data['post_type'] !== LMGT_CPT || $data['post_status'] !== 'publish' ) return $data;
		$id = isset( $postarr['ID'] ) ? (int) $postarr['ID'] : 0;
		if ( ! $id || ! self::open_issues( $id ) ) return $data;
		// The gate guards the first publication. An update to a translation that is
		// already live never takes it offline.
		if ( get_post_status( $id ) === 'publish' ) return $data;
		$ticked = ! empty( $_POST['lmgt_reviewed'] ) || self::is_reviewed( $id );
		if ( $ticked ) return $data;
		$data['post_status'] = 'draft';
		set_transient( 'lmgt_gate_' . get_current_user_id(), $id, 60 );
		return $data;
	}

	/**
	 * Trashing a published translation: its address answers 410 Gone on
	 * traveltalk.dk (where tt_410_handler is installed), so Google drops it fast.
	 */
	public static function on_transition( $new, $old, $post ) {
		if ( $post->post_type !== LMGT_CPT ) return;
		if ( $old === 'publish' && $new === 'trash' && function_exists( 'tt_410_add_path' ) ) {
			$l = LMGT_Langs::get( get_post_meta( $post->ID, '_lmgt_lang', true ) );
			$slug = preg_replace( '/__trashed$/', '', $post->post_name );
			if ( $l && $slug ) tt_410_add_path( '/' . $l['prefix'] . '/' . $slug . '/' );
		}
		if ( $old === 'publish' || $new === 'publish' ) {
			self::purge_cluster( (int) get_post_meta( $post->ID, '_lmgt_source', true ) );
			// Other translations may link to this one's original; their links switch on the next view.
			do_action( 'litespeed_purge_posttype', LMGT_CPT );
		}
	}

	/**
	 * hreflang only counts when the pages point at each other, and every page in
	 * a set prints the whole set. When one version appears, disappears or moves,
	 * the cached copies of all the others are stale: clear them all.
	 */
	public static function purge_cluster( $source_id ) {
		if ( ! $source_id ) return;
		foreach ( array_merge( array( (int) $source_id ), array_values( self::of( $source_id ) ) ) as $id ) {
			do_action( 'litespeed_purge_post', $id );
		}
	}

	// ---- Tagging hand-written translations -----------------------------------

	/**
	 * Mark an existing post as the hand-written $lang version of $source_id.
	 * Status, address, content and post type are left exactly as they are.
	 *
	 * @return true|WP_Error
	 */
	public static function tag( $id, $source_id, $lang ) {
		$p   = get_post( $id );
		$src = get_post( $source_id );
		$l   = LMGT_Langs::get( $lang );
		if ( ! $p || ! in_array( $p->post_type, LMGT_Store::types(), true ) ) return new WP_Error( 'lmgt_tag', 'Only a post or page can be tagged.' );
		if ( ! $src || ! in_array( $src->post_type, LMGT_Store::types(), true ) || self::is_tagged( $source_id ) ) return new WP_Error( 'lmgt_tag', 'The original must be an untagged post or page.' );
		if ( (int) $id === (int) $source_id ) return new WP_Error( 'lmgt_tag', 'A post cannot be its own original.' );
		if ( ! $l || $lang === LMGT_Langs::source() ) return new WP_Error( 'lmgt_tag', 'Pick a language other than the site\'s own.' );
		if ( self::of( $id ) ) return new WP_Error( 'lmgt_tag', 'This post has translations of its own, so it is an original.' );
		$have = self::of( $source_id );
		if ( isset( $have[ $lang ] ) && $have[ $lang ] !== (int) $id ) return new WP_Error( 'lmgt_tag', 'The original already has a ' . $l['name'] . ' translation.' );
		$read = self::reads_as( $p );
		if ( $read && $read !== $lang ) return new WP_Error( 'lmgt_tag', 'This post reads as ' . LMGT_Langs::get( $read )['name'] . ', not ' . $l['name'] . '. Nothing changed.' );
		$read = self::reads_as( $src );
		if ( $read && $read !== LMGT_Langs::source() ) return new WP_Error( 'lmgt_tag', 'The original reads as ' . LMGT_Langs::get( $read )['name'] . ', not ' . LMGT_Langs::get( LMGT_Langs::source() )['name'] . '. Pick the ' . LMGT_Langs::get( LMGT_Langs::source() )['name'] . ' article as the original. Nothing changed.' );

		update_post_meta( $id, '_lmgt_source', (int) $source_id );
		update_post_meta( $id, '_lmgt_lang', $lang );
		update_option( 'lmgt_tagged', array_values( array_unique( array_merge( self::tagged(), array( (int) $id ) ) ) ), false );
		self::purge_cluster( $source_id );
		do_action( 'litespeed_purge_all' ); // the post leaves the front page, archive and category listings
		return true;
	}

	/** Undo tag(): the post becomes an ordinary post in the listings again. */
	public static function untag( $id ) {
		$source_id = (int) get_post_meta( $id, '_lmgt_source', true );
		delete_post_meta( $id, '_lmgt_source' );
		delete_post_meta( $id, '_lmgt_lang' );
		update_option( 'lmgt_tagged', array_values( array_diff( self::tagged(), array( (int) $id ) ) ), false );
		self::purge_cluster( $source_id );
		do_action( 'litespeed_purge_post', $id );
		do_action( 'litespeed_purge_all' );
	}
}
