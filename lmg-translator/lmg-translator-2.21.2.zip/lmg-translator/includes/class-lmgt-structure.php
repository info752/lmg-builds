<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 2.2.29 (G, 4 Nov 2026): one structure for every Traveltalk article and page,
 * translations included.
 *
 *   1. Intro: inviting, says what the text tells and why to read it.
 *   2. Middle: decided by the content.
 *   3. Practical part last: when, how, getting there and around.
 *   4. "Read more" block at the very end: the place's page, its region's page
 *      and up to three related travel interests, in the page's language.
 *
 * Also here:
 *   - where added sections land (LMGT_Admin::place() asks this class): the
 *     heading the engine named, matched loosely; else the section whose words
 *     overlap most; else just before the practical part, never after it. A
 *     heading inside a layout block no longer sends the section to the end.
 *   - .travel: translations of posts are listed with the site's own posts
 *     (front page, blog, feeds, latest-posts blocks), newest first.
 */
class LMGT_Structure {

	const PRACTICAL_WORDS = array(
		'en' => array( 'practical', 'good to know', 'getting there', 'how to get', 'when to go', 'best time', 'travel tips', 'getting around', 'before you go', 'plan your', 'where to stay' ),
		'da' => array( 'praktisk', 'godt at vide', 'sådan kommer du', 'hvornår skal', 'bedste tid', 'bedste rejsetid', 'rejsetips', 'kom rundt', 'transport', 'hvor skal du bo', 'overnatning' ),
		'de' => array( 'praktisch', 'gut zu wissen', 'anreise', 'beste reisezeit', 'reisetipps', 'unterwegs', 'unterkunft', 'so kommen sie' ),
		'fr' => array( 'pratique', 'bon à savoir', 'comment y aller', 'quand partir', 'meilleure période', 'conseils', 'se déplacer', 'où dormir', 'se rendre' ),
		'es' => array( 'práctic', 'bueno saber', 'cómo llegar', 'cuándo ir', 'mejor época', 'consejos', 'moverse', 'dónde alojarse' ),
		'it' => array( 'pratic', 'buono a sapersi', 'come arrivare', 'quando andare', 'periodo migliore', 'consigli', 'spostarsi', 'dove dormire' ),
		'pt' => array( 'prátic', 'bom saber', 'como chegar', 'quando ir', 'melhor época', 'dicas', 'deslocar', 'onde ficar' ),
		'sv' => array( 'praktisk', 'bra att veta', 'så tar du dig', 'när ska', 'bästa tid', 'resetips', 'ta sig runt', 'boende' ),
		'nb' => array( 'praktisk', 'greit å vite', 'slik kommer du', 'når bør', 'beste tid', 'reisetips', 'komme seg rundt', 'overnatting' ),
		'fi' => array( 'käytännö', 'hyvä tietää', 'miten pääse', 'milloin', 'paras aika', 'matkavinkit', 'liikkuminen', 'majoitus' ),
	);

	const PRACTICAL_HEADING = array(
		'en' => 'Practical information', 'da' => 'Praktisk information', 'de' => 'Praktische Informationen', 'fr' => 'Informations pratiques',
		'es' => 'Información práctica', 'it' => 'Informazioni pratiche', 'pt' => 'Informações práticas', 'sv' => 'Praktisk information',
		'nb' => 'Praktisk informasjon', 'fi' => 'Käytännön tietoa',
	);

	const RM_TITLE = array(
		'en' => 'Read more', 'da' => 'Læs mere', 'de' => 'Weiterlesen', 'fr' => 'À lire aussi', 'es' => 'Sigue leyendo',
		'it' => 'Continua a leggere', 'pt' => 'Continue a ler', 'sv' => 'Läs mer', 'nb' => 'Les mer', 'fi' => 'Lue lisää',
	);

	const RM_ABOUT = array(
		'en' => 'Read more about %s', 'da' => 'Læs mere om %s', 'de' => 'Mehr über %s', 'fr' => 'En savoir plus : %s', 'es' => 'Más sobre %s',
		'it' => 'Scopri di più: %s', 'pt' => 'Saiba mais sobre %s', 'sv' => 'Läs mer om %s', 'nb' => 'Les mer om %s', 'fi' => 'Lue lisää: %s',
	);

	const RM_INTERESTS = array(
		'en' => 'Related travel interests', 'da' => 'Relaterede rejseinteresser', 'de' => 'Passende Reisethemen', 'fr' => 'Thèmes de voyage associés',
		'es' => 'Temas de viaje relacionados', 'it' => 'Temi di viaggio correlati', 'pt' => 'Temas de viagem relacionados', 'sv' => 'Relaterade reseintressen',
		'nb' => 'Relaterte reiseinteresser', 'fi' => 'Aiheeseen liittyvät matkateemat',
	);

	public static function boot() {
		add_action( 'pre_get_posts', array( __CLASS__, 'front_lists' ), 20 );
		add_filter( 'the_content', array( __CLASS__, 'read_more' ), 19 );
		add_shortcode( 'lmg_read_more', array( __CLASS__, 'shortcode' ) );
		add_action( 'wp_head', array( __CLASS__, 'css' ), 40 );
		add_action( 'add_meta_boxes', function () {
			add_meta_box( 'lmgt_structure', 'Structure', array( __CLASS__, 'box' ), LMGT_Store::types( true ), 'side', 'default' );
		} );
		add_action( 'save_post', array( __CLASS__, 'save_box' ), 10, 2 );
		add_action( 'admin_post_lmgt_structure', array( __CLASS__, 'handle_propose' ) );
		add_action( 'admin_post_lmgt_structure_apply', array( __CLASS__, 'handle_apply' ) );
		foreach ( array( 'post', 'page' ) as $t ) {
			add_filter( 'manage_' . $t . 's_columns', function ( $c ) { $c['lmgt_struct'] = 'Structure'; return $c; } );
			add_action( 'manage_' . $t . 's_custom_column', array( __CLASS__, 'column' ), 10, 2 );
		}
		add_filter( 'manage_' . LMGT_CPT . '_posts_columns', function ( $c ) { $c['lmgt_struct'] = 'Structure'; return $c; } );
	}

	// ---- .travel: translations of posts are new posts on the front page ----------------

	public static function front_lists( $q ) {
		if ( ! LMGT_Bridge::is_target() || ! get_option( 'lmgt_front_translations', 1 ) ) return;
		if ( is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || $q->is_singular() || $q->is_search() ) return;
		if ( $q->get( 'lmgt_all' ) || $q->get( 'lmgt_lang_home' ) || $q->get( 'post__in' ) || $q->get( 'p' ) || $q->get( 'name' ) || $q->get( 's' ) ) return;
		if ( $q->is_main_query() && ! ( $q->is_home() || $q->is_feed() ) ) return; // archives, categories, tags, authors: translations carry none
		$type = $q->get( 'post_type' );
		if ( $type && $type !== 'post' && (array) $type !== array( 'post' ) ) return;
		foreach ( array( 'cat', 'category_name', 'category__in', 'category__and', 'tag', 'tag_id', 'tag__in', 'tag__and', 'tax_query', 'author', 'author_name', 'author__in', 'meta_key', 'year', 'monthnum', 'm' ) as $k ) {
			if ( $q->get( $k ) ) return;
		}
		$meta   = (array) $q->get( 'meta_query' );
		$meta[] = array(
			'relation' => 'OR',
			array( 'key' => '_lmgt_lang', 'compare' => 'NOT EXISTS' ),
			array(
				'relation' => 'AND',
				array( 'key' => '_lmgt_lang', 'value' => 'en' ),
				array(
					'relation' => 'OR',
					array( 'key' => '_lmgt_source_type', 'compare' => 'NOT EXISTS' ),
					array( 'key' => '_lmgt_source_type', 'value' => 'page', 'compare' => '!=' ),
				),
			),
		);
		$q->set( 'post_type', array( 'post', LMGT_CPT ) );
		$q->set( 'meta_query', $meta );
	}

	// ---- Headings and sections -------------------------------------------------------

	private static function norm( $t ) {
		$t = mb_strtolower( html_entity_decode( wp_strip_all_tags( (string) $t ), ENT_QUOTES, 'UTF-8' ) );
		$t = preg_replace( '/[^\p{L}\p{N}]+/u', ' ', $t );
		return trim( preg_replace( '/\s+/u', ' ', $t ) );
	}

	private static function words( $t ) {
		$w = array_filter( explode( ' ', self::norm( $t ) ), function ( $x ) { return mb_strlen( $x ) >= 4; } );
		return array_values( array_unique( $w ) );
	}

	/** The heading in $heads that $after names, matched loosely; '' when none fits. */
	public static function match_heading( $after, array $heads ) {
		$a = self::norm( $after );
		if ( $a === '' ) return '';
		foreach ( $heads as $h ) if ( self::norm( $h ) === $a ) return $h;
		foreach ( $heads as $h ) {
			$n = self::norm( $h );
			if ( $n !== '' && ( mb_strpos( $n, $a ) !== false || mb_strpos( $a, $n ) !== false ) ) return $h;
		}
		$aw = self::words( $after );
		$best = '';
		$top  = 0.5;
		foreach ( $heads as $h ) {
			$hw = self::words( $h );
			if ( ! $aw || ! $hw ) continue;
			$j = count( array_intersect( $aw, $hw ) ) / count( array_unique( array_merge( $aw, $hw ) ) );
			if ( $j >= $top ) { $top = $j; $best = $h; }
		}
		return $best;
	}

	/** Headings with level, offsets and the text under each up to the next heading. */
	public static function sections( $html ) {
		$out = array();
		if ( ! preg_match_all( '#<h([1-6])[^>]*>(.*?)</h\1>#is', $html, $m, PREG_OFFSET_CAPTURE ) ) return $out;
		$n = count( $m[0] );
		for ( $i = 0; $i < $n; $i++ ) {
			$end  = $m[0][ $i ][1] + strlen( $m[0][ $i ][0] );
			$next = $i + 1 < $n ? $m[0][ $i + 1 ][1] : strlen( $html );
			$out[] = array(
				'level' => (int) $m[1][ $i ][0],
				'text'  => trim( html_entity_decode( wp_strip_all_tags( $m[2][ $i ][0] ), ENT_QUOTES, 'UTF-8' ) ),
				'start' => $m[0][ $i ][1],
				'end'   => $end,
				'body'  => wp_strip_all_tags( substr( $html, $end, $next - $end ) ),
			);
		}
		return $out;
	}

	public static function is_practical( $heading, $lang = '' ) {
		$h = ' ' . self::norm( $heading ) . ' ';
		$lists = $lang && isset( self::PRACTICAL_WORDS[ $lang ] ) ? array( self::PRACTICAL_WORDS[ $lang ] ) : array_values( self::PRACTICAL_WORDS );
		foreach ( $lists as $list ) {
			foreach ( $list as $w ) {
				if ( mb_strpos( $h, ' ' . self::norm( $w ) ) !== false ) return true;
			}
		}
		return false;
	}

	/** Where a heading named by the engine is missing: the section whose words overlap most with the new one. */
	public static function best_after( $content, array $section ) {
		$new = self::words( ( isset( $section['heading'] ) ? $section['heading'] : '' ) . ' ' . ( isset( $section['html'] ) ? $section['html'] : '' ) );
		if ( ! $new ) return '';
		$new_practical = self::is_practical( isset( $section['heading'] ) ? $section['heading'] : '' );
		$best = '';
		$top  = 2;
		foreach ( self::sections( $content ) as $s ) {
			if ( $s['level'] > 3 || ( ! $new_practical && self::is_practical( $s['text'] ) ) ) continue;
			$score = count( array_intersect( $new, self::words( $s['text'] . ' ' . $s['text'] . ' ' . $s['body'] ) ) );
			if ( $score > $top ) { $top = $score; $best = $s['text']; }
		}
		return $best;
	}

	/** Block nesting depth at a byte offset (0 = top level). */
	public static function depth_at( $content, $pos ) {
		$seg = substr( $content, 0, $pos );
		$open  = preg_match_all( '#<!-- wp:[^>]*?(?<!/)-->#', $seg );
		$close = preg_match_all( '#<!-- /wp:#', $seg );
		return $open - $close;
	}

	/**
	 * The last offset in [$from, $to] where block nesting is back at the depth
	 * of the block that holds $from (the heading block, still open at $from).
	 * A section added there sits beside the heading's own blocks, inside the
	 * same column or group, so no layout block is cut.
	 */
	public static function safe_point( $content, $from, $to ) {
		$seg = substr( $content, $from, $to - $from );
		if ( ! preg_match_all( '#<!-- (/?)wp:[^>]*?(/?)-->#', $seg, $m, PREG_OFFSET_CAPTURE ) ) return $to;
		$depth = 1;
		$point = $to;
		$last  = null;
		foreach ( $m[0] as $i => $tok ) {
			$after = $from + $tok[1] + strlen( $tok[0] );
			if ( $m[1][ $i ][0] === '/' ) {
				$depth--;
				if ( $depth < 0 ) return $last !== null ? $last : $from + $tok[1];
				if ( $depth === 0 ) $last = $after;
			} elseif ( $m[2][ $i ][0] === '/' ) {
				if ( $depth === 0 ) $last = $after;
			} else {
				$depth++;
			}
		}
		if ( $depth === 0 ) return $point;
		return $last !== null ? $last : $point;
	}

	/** End of the article for a new section: before a practical part that closes it, else the end. */
	public static function end_point( $content, $new_heading = '' ) {
		$blocks = strpos( $content, '<!-- wp:' ) !== false;
		if ( ! self::is_practical( $new_heading ) ) {
			$h2 = array_values( array_filter( self::sections( $content ), function ( $s ) { return $s['level'] <= 2; } ) );
			$first = null;
			for ( $i = count( $h2 ) - 1; $i >= 0 && $i >= count( $h2 ) - 3; $i-- ) {
				if ( self::is_practical( $h2[ $i ]['text'] ) ) $first = $h2[ $i ]; else break;
			}
			if ( $first ) {
				$at = $first['start'];
				if ( $blocks && preg_match( '#<!-- wp:[a-z0-9/-]+(?: \{[^\n]*?\})? -->\s*$#', substr( $content, 0, $at ), $op, PREG_OFFSET_CAPTURE ) ) $at = $op[0][1];
				if ( ! $blocks || self::depth_at( $content, $at ) === 0 ) return $at;
			}
		}
		// 2.14.0: a new section goes before the Translator's boxes at the end, never after them.
		$box = self::boxes_at_end( $content );
		if ( $box !== false ) return $box;
		$pos = strpos( $content, '[lmg_read_more' );
		return $pos !== false ? $pos : strlen( rtrim( $content ) );
	}

	// ---- The Read more block -----------------------------------------------------------

	private static function lang_of( $id ) {
		if ( get_post_type( $id ) === LMGT_CPT || LMGT_Store::is_tagged( $id ) ) {
			$l = get_post_meta( $id, '_lmgt_lang', true );
			if ( LMGT_Langs::get( $l ) ) return $l;
		}
		return LMGT_Langs::source();
	}

	private static function label( array $map, $lang ) {
		return isset( $map[ $lang ] ) ? $map[ $lang ] : $map['en'];
	}

	private static function skip_ids() {
		$ids = array_filter( array_map( 'intval', preg_split( '/[\s,]+/', (string) get_option( 'lmgt_rm_skip', LMGT_Bridge::is_target() ? '79,84' : '' ) ) ) );
		$ids[] = (int) get_option( 'page_on_front' );
		$ids[] = (int) get_option( 'page_for_posts' );
		return array_filter( $ids );
	}

	/** The page that stands for a post's place: the page with its category's slug (2.2.10 rule). */
	private static function hub_of_post( $id ) {
		$primary = (int) get_post_meta( $id, 'rank_math_primary_category', true );
		$cats    = $primary ? array( get_term( $primary, 'category' ) ) : get_the_category( $id );
		foreach ( (array) $cats as $c ) {
			if ( ! $c || is_wp_error( $c ) || (int) $c->term_id === (int) get_option( 'default_category' ) ) continue;
			$hub = get_posts( array( 'post_type' => 'page', 'name' => $c->slug, 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids', 'lmgt_all' => true ) );
			if ( $hub ) return (int) $hub[0];
		}
		return 0;
	}

	/** Place pages on this site from the top down, the original itself last when it is a page. */
	private static function local_chain( $id ) {
		$post = get_post( $id );
		if ( ! $post ) return array();
		if ( $post->post_type === 'page' ) $chain = array_merge( array_reverse( get_post_ancestors( $post ) ), array( (int) $id ) );
		else {
			$hub   = self::hub_of_post( $id );
			$chain = $hub ? array_merge( array_reverse( get_post_ancestors( $hub ) ), array( $hub ) ) : array();
		}
		$skip = self::skip_ids();
		return array_values( array_filter( $chain, function ( $p ) use ( $skip ) { return ! in_array( (int) $p, $skip, true ) && get_post_status( $p ) === 'publish'; } ) );
	}

	/** A page in $lang: itself in the site's language, else its published translation. [name, url] or null. */
	private static function in_lang( $pid, $lang ) {
		if ( $lang !== LMGT_Langs::source() ) {
			$set = LMGT_Store::of( $pid, array( 'publish' ) );
			if ( empty( $set[ $lang ] ) ) return null;
			$pid = (int) $set[ $lang ];
		}
		$set  = trim( (string) get_post_meta( $pid, 'rank_math_breadcrumb_title', true ) );
		$name = $set !== '' ? $set : LMGT_Trail::short( html_entity_decode( get_the_title( $pid ), ENT_QUOTES, 'UTF-8' ) );
		return array( $name, get_permalink( $pid ), $pid );
	}

	/**
	 * [place => [name, url]|null, region => [name, url]|null, interests => [[name, url]]]
	 * for the text being shown. Manual choices in the Structure box win.
	 */
	public static function cluster( $id ) {
		$lang  = self::lang_of( $id );
		$self  = get_permalink( $id );
		$levels = array(); // [name, url] from the top down, the text itself excluded
		$is_page = get_post_type( $id ) === 'page' || ( get_post_type( $id ) === LMGT_CPT && get_post_meta( $id, '_lmgt_source_type', true ) === 'page' );

		if ( get_post_type( $id ) === LMGT_CPT && get_post_meta( $id, '_lmgt_remote_source', true ) ) {
			$c = LMGT_Trail::crumbs( $id );
			foreach ( $c ? $c['levels'] : array() as $l ) if ( $l[1] ) $levels[] = array( $l[0], $l[1] );
		} else {
			$src = get_post_type( $id ) === LMGT_CPT || LMGT_Store::is_tagged( $id ) ? (int) get_post_meta( $id, '_lmgt_source', true ) : (int) $id;
			foreach ( self::local_chain( $src ? $src : $id ) as $pid ) {
				if ( (int) $pid === (int) $src && $is_page ) continue;
				$v = self::in_lang( $pid, $lang );
				if ( $v ) $levels[] = array( $v[0], $v[1] );
			}
		}
		$levels = array_values( array_filter( $levels, function ( $l ) use ( $self ) { return untrailingslashit( $l[1] ) !== untrailingslashit( $self ); } ) );
		$n      = count( $levels );
		$place  = null;
		$region = null;
		if ( $is_page ) {
			$region = $n ? $levels[ $n - 1 ] : null;
		} else {
			$place  = $n ? $levels[ $n - 1 ] : null;
			$region = $n > 1 ? $levels[ $n - 2 ] : null;
		}

		$manual = get_post_meta( $id, '_lmgt_rm', true );
		$manual = is_array( $manual ) ? $manual : array();
		foreach ( array( 'place', 'region' ) as $k ) {
			if ( empty( $manual[ $k ] ) ) continue;
			$v = self::in_lang( (int) $manual[ $k ], $lang );
			if ( $v ) ${$k} = array( $v[0], $v[1] );
		}

		$interests = array();
		$picked    = ! empty( $manual['interests'] ) ? array_map( 'intval', (array) $manual['interests'] ) : self::auto_interests( $id, $lang );
		foreach ( array_slice( $picked, 0, 3 ) as $pid ) {
			$v = self::in_lang( $pid, $lang );
			if ( $v && untrailingslashit( $v[1] ) !== untrailingslashit( $self ) ) $interests[] = array( $v[0], $v[1] );
		}
		// 2.2.30: where interests are categories (traveltalk.dk), the sub-categories the text mentions; only in the site's own language.
		if ( ! $interests && empty( $manual['interests'] ) && $lang === LMGT_Langs::source() ) {
			$interests = self::category_interests( $id );
		}
		return array( 'place' => $place, 'region' => $region, 'interests' => $interests, 'lang' => $lang );
	}

	/** Sub-categories of the Travel Interests category whose name the text uses, most used first, up to 3. */
	private static function category_interests( $id ) {
		$parent = (int) get_option( 'lmgt_rm_interests_cat', 0 );
		if ( ! $parent ) return array();
		$kids = get_terms( array( 'taxonomy' => 'category', 'parent' => $parent, 'hide_empty' => true, 'number' => 80 ) );
		if ( is_wp_error( $kids ) || ! $kids ) return array();
		$score = array();
		foreach ( $kids as $t ) {
			$n = self::fit( $id, $t->name );
			if ( $n >= self::MIN_FIT ) $score[ $t->term_id ] = $n;
		}
		arsort( $score );
		$out = array();
		foreach ( array_slice( array_keys( $score ), 0, 3 ) as $tid ) {
			$t = get_term( $tid, 'category' );
			$l = $t && ! is_wp_error( $t ) ? get_term_link( $t ) : '';
			if ( $l && ! is_wp_error( $l ) ) $out[] = array( $t->name, $l );
		}
		return $out;
	}

	/** Children of the Travel Interests page whose name or focus keyword the text uses, most used first. */
	/**
	 * 2.2.31: how strongly a text is about a term: mentions in the text, three times over for each in a heading,
	 * five times over in the title. An interest is offered from MIN_FIT on, so one passing "camping" is not enough.
	 */
	const MIN_FIT = 4;

	private static function fit( $id, $term ) {
		$t = self::norm( $term );
		if ( mb_strlen( $t ) < 4 ) return 0;
		$html  = (string) get_post_field( 'post_content', $id );
		$heads = '';
		foreach ( self::sections( $html ) as $h ) $heads .= ' ' . $h['text'] . ' ';
		$one = function ( $x ) use ( $t ) { return substr_count( ' ' . self::norm( $x ) . ' ', ' ' . $t . ' ' ); };
		return $one( $html ) + 3 * $one( $heads ) + 5 * $one( get_the_title( $id ) );
	}

	private static function auto_interests( $id, $lang ) {
		$parent = (int) get_option( 'lmgt_rm_interests', LMGT_Bridge::is_target() ? 84 : 0 );
		if ( ! $parent ) return array();
		$kids = get_posts( array( 'post_type' => 'page', 'post_parent' => $parent, 'post_status' => 'publish', 'posts_per_page' => 60, 'fields' => 'ids', 'lmgt_all' => true ) );
		if ( ! $kids ) return array();
		$score = array();
		foreach ( $kids as $pid ) {
			$v = self::in_lang( $pid, $lang );
			if ( ! $v ) continue;
			$terms = array( $v[0] );
			$kw    = (string) get_post_meta( $v[2], 'rank_math_focus_keyword', true );
			if ( $kw !== '' ) $terms[] = trim( explode( ',', $kw )[0] );
			$n = 0;
			foreach ( $terms as $t ) $n += self::fit( $id, $t );
			if ( $n >= self::MIN_FIT ) $score[ $pid ] = $n;
		}
		arsort( $score );
		return array_keys( $score );
	}

	/** [name, url] for a text without a place: a post's own category (originals only), else the destinations page. */
	private static function fallback_place( $id, $lang ) {
		$translated = get_post_type( $id ) === LMGT_CPT || LMGT_Store::is_tagged( $id );
		if ( get_post_type( $id ) === 'post' && ! $translated ) {
			$primary = (int) get_post_meta( $id, 'rank_math_primary_category', true );
			$cats    = $primary ? array( get_term( $primary, 'category' ) ) : get_the_category( $id );
			foreach ( (array) $cats as $t ) {
				if ( ! $t || is_wp_error( $t ) || (int) $t->term_id === (int) get_option( 'default_category' ) ) continue;
				$l = get_term_link( $t );
				if ( $l && ! is_wp_error( $l ) ) return array( $t->name, $l );
			}
		}
		$hub = (int) get_option( 'lmgt_rm_hub', LMGT_Bridge::is_target() ? 79 : 0 );
		if ( $hub && (int) $hub !== (int) $id ) {
			$v = self::in_lang( $hub, $lang );
			if ( $v ) return array( $v[0], $v[1] );
		}
		return null;
	}

	/** Address of the overview of all travel interests in $lang: the interests page, or the category on a site that uses one. */
	private static function interests_hub( $lang ) {
		$page = (int) get_option( 'lmgt_rm_interests', LMGT_Bridge::is_target() ? 84 : 0 );
		if ( $page ) {
			$v = self::in_lang( $page, $lang );
			return $v ? $v[1] : '';
		}
		$cat = (int) get_option( 'lmgt_rm_interests_cat', 0 );
		if ( $cat && $lang === LMGT_Langs::source() ) {
			$l = get_term_link( $cat, 'category' );
			return $l && ! is_wp_error( $l ) ? $l : '';
		}
		return '';
	}

	public static function block_html( $id ) {
		$c = self::cluster( $id );
		$lang = $c['lang'];
		$rows = array();
		foreach ( array( 'place', 'region' ) as $k ) {
			if ( $c[ $k ] ) $rows[] = '<li><a href="' . esc_url( $c[ $k ][1] ) . '">' . esc_html( sprintf( self::label( self::RM_ABOUT, $lang ), $c[ $k ][0] ) ) . '</a></li>';
		}
		// 2.2.31: a text with no place or region still gets a way on: its category, else the destinations page.
		if ( ! $c['place'] && ! $c['region'] ) {
			$fb = self::fallback_place( $id, $lang );
			if ( $fb ) $rows[] = '<li><a href="' . esc_url( $fb[1] ) . '">' . esc_html( sprintf( self::label( self::RM_ABOUT, $lang ), $fb[0] ) ) . '</a></li>';
		}
		if ( $c['interests'] ) {
			$links = array();
			foreach ( $c['interests'] as $i ) $links[] = '<a href="' . esc_url( $i[1] ) . '">' . esc_html( $i[0] ) . '</a>';
			$rows[] = '<li>' . esc_html( self::label( self::RM_INTERESTS, $lang ) ) . ': ' . implode( ' · ', $links ) . '</li>';
		} else {
			$hub = self::interests_hub( $lang );
			if ( $hub ) $rows[] = '<li><a href="' . esc_url( $hub ) . '">' . esc_html( self::label( self::RM_INTERESTS, $lang ) ) . '</a></li>';
		}
		$subject = $c['place'] ? $c['place'][0] : ( $c['region'] ? $c['region'][0] : ( isset( $fb ) && $fb ? $fb[0] : '' ) );
		$top     = LMGT_Top::row( $id, $lang, $subject );
		if ( $top ) $rows[] = $top;
		if ( ! $rows ) return '';
		return '<nav class="lmgt-readmore" aria-label="' . esc_attr( self::label( self::RM_TITLE, $lang ) ) . '"><p class="lmgt-readmore-title">' . esc_html( self::label( self::RM_TITLE, $lang ) ) . '</p><ul>' . implode( '', $rows ) . '</ul></nav>';
	}

	private static function shown_here() {
		if ( ! get_option( 'lmgt_readmore', 1 ) || is_admin() || is_feed() || ! is_singular( LMGT_Store::types( true ) ) || is_front_page() || ! in_the_loop() || ! is_main_query() ) return false;
		$id = get_the_ID();
		if ( (int) $id !== (int) get_queried_object_id() || get_post_meta( $id, '_lmgt_rm_off', true ) ) return false;
		return true;
	}

	public static function read_more( $content ) {
		if ( ! self::shown_here() || strpos( $content, 'lmgt-readmore' ) !== false ) return $content;
		return $content . self::block_html( get_the_ID() );
	}

	/** [lmg_read_more] puts the block where the editor wants it; the automatic one is then left out. */
	public static function shortcode() {
		return self::shown_here() ? self::block_html( get_the_ID() ) : '';
	}

	public static function css() {
		if ( ! get_option( 'lmgt_readmore', 1 ) || ! is_singular() || is_front_page() ) return;
		echo '<style>.lmgt-readmore{margin:2.5em 0 1.5em;padding:1.1em 1.4em;border-left:4px solid #B8956A;background:#f8f4ee;border-radius:6px}'
			. '.lmgt-readmore-title{margin:0 0 .4em;font-weight:700;font-size:1.05em}.lmgt-readmore ul{margin:0;padding:0;list-style:none}'
			. '.lmgt-readmore li{margin:.3em 0}.lmgt-readmore a{font-weight:600}.lmgt-top{margin-top:.9em}.lmgt-top-title{display:block;font-weight:700;margin-bottom:.2em}.lmgt-top ul{list-style:disc;margin:.2em 0 0 1.2em;padding:0}</style>' . "\n";
	}

	// ---- The check ---------------------------------------------------------------------

	/**
	 * 2.14.0 (G, 12 Nov, Japan): the text without the Translator's own boxes (fact
	 * box, Know before you go, Who takes you there). Their headings are not the
	 * article's sections: counted as such, the boxes that sit at the end made the
	 * practical part look as if it sat in the middle, however often it was moved.
	 */
	public static function without_boxes( $html ) {
		return preg_replace( '#<!-- lmgt:(facts|faq|who|map|toc) -->.*?<!-- /lmgt:\1 -->#s', '', (string) $html );
	}

	/** Where the Translator's boxes at the end of the text begin; false when none close it. */
	private static function boxes_at_end( $content ) {
		if ( ! preg_match_all( '#<!-- lmgt:(?:facts|faq|who) -->#', $content, $m, PREG_OFFSET_CAPTURE ) ) return false;
		foreach ( $m[0] as $hit ) {
			$rest = self::without_boxes( substr( $content, $hit[1] ) );
			$rest = preg_replace( '#\[lmg_read_more[^\]]*\]#', '', $rest );
			if ( trim( wp_strip_all_tags( preg_replace( '#<!--.*?-->#s', '', $rest ) ) ) === '' ) return $hit[1];
		}
		return false;
	}

	/**
	 * 2.17.23 (G, 20 Nov: "I am forth and back a number of times"): what the structure check looks at – the headings
	 * and the words of the intro. Links, boxes or a map added later do not change it, so "kept as it is" stays.
	 */
	public static function shape( $html ) {
		$secs  = self::sections( $html );
		$first = null;
		foreach ( $secs as $s ) if ( $s['level'] <= 2 ) { $first = $s; break; }
		$intro = LMGT_Text::plain( $first ? substr( $html, 0, $first['start'] ) : '' );
		return md5( implode( '|', array_map( function ( $s ) { return $s['level'] . ':' . $s['text']; }, $secs ) ) . '#' . preg_replace( '/\s+/u', ' ', $intro ) );
	}

	/** [intro => ok|short|long|missing, intro_words, practical => ok|middle|missing, practical_at] */
	public static function check( $post ) {
		$post = get_post( $post );
		$html = $post ? self::without_boxes( (string) $post->post_content ) : '';
		$lang = $post ? self::lang_of( $post->ID ) : 'en';
		$secs = self::sections( $html );
		$first = null;
		foreach ( $secs as $s ) if ( $s['level'] <= 2 ) { $first = $s; break; }
		$intro = LMGT_Text::plain( $first ? substr( $html, 0, $first['start'] ) : $html );
		$iw    = $intro === '' ? 0 : count( preg_split( '/\s+/u', $intro ) );
		$h2    = array_values( array_filter( $secs, function ( $s ) { return $s['level'] <= 2; } ) );
		$prac  = 'missing';
		$where = '';
		// 2.17.20 (G, 19 Nov: "Propose the structure … the same errors"): headings are read in the page's own
		// language only ("transport" or "boende" in an English heading is not a practical part), and only the
		// closing headings count. A practical-sounding heading early in a route ("Stage 2: getting to Colmar")
		// no longer makes every heading after it "in the middle".
		$isp = function ( $t ) use ( $lang ) { return isset( self::PRACTICAL_WORDS[ $lang ] ) ? self::is_practical( $t, $lang ) : self::is_practical( $t ); };
		$cnt = count( $h2 );
		$last = -1;
		foreach ( $h2 as $i => $s ) if ( $isp( $s['text'] ) ) { $last = $i; $where = $s['text']; }
		if ( $last >= 0 ) {
			// The last practical heading within the closing three; an FAQ or a last word after it is fine.
			$prac = $last >= $cnt - 3 ? 'ok' : 'middle';
		}
		// 2.17.20: a structure Claude checked and found nothing to change in counts as fine until the text changes.
		$kept = $post && get_post_meta( $post->ID, '_lmgt_struct_kept', true ) === self::shape( $html );
		if ( $kept ) $prac = 'ok';
		// 2.5.2 (G, 7 Nov, Botswana): a heading that only repeats the title, and a shortcode missing its opening or closing tag.
		$t      = $post ? self::norm( html_entity_decode( $post->post_title, ENT_QUOTES, 'UTF-8' ) ) : '';
		$repeat = array();
		foreach ( $secs as $sc ) if ( $t !== '' && self::norm( $sc['text'] ) === $t ) $repeat[] = $sc['text'];
		$broken = array();
		if ( strpos( $html, '[/' ) !== false || preg_match( '/\[[a-z]/i', $html ) ) {
			preg_match_all( '/\[\/([a-z][a-z0-9_-]*)\]/i', $html, $cl );
			foreach ( array_unique( array_map( 'strtolower', $cl[1] ) ) as $tag ) {
				$open  = preg_match_all( '/\[' . preg_quote( $tag, '/' ) . '(?:[\s\]])/i', $html );
				$close = preg_match_all( '/\[\/' . preg_quote( $tag, '/' ) . '\]/i', $html );
				if ( $open !== $close ) $broken[] = array( $tag, $open, $close );
			}
		}
		return array(
			'repeat'       => $repeat,
			'shortcodes'   => $broken,
			'kept'         => $kept,
			'intro'        => ( ! $first || $kept ) ? 'ok' : ( $iw < 25 ? ( $iw ? 'short' : 'missing' ) : ( $iw > 250 ? 'long' : 'ok' ) ),
			'intro_words'  => $iw,
			// 2.17.2 (G, 14 Nov, winetalk "Grechetto"): only travel texts need a practical part (when to go, getting there).
			'practical'    => ( count( $h2 ) < 2 || self::subject() !== 'travel' ) ? 'ok' : $prac,
			'practical_at' => $where,
			'lang'         => $lang,
		);
	}

	public static function column( $col, $id ) {
		if ( $col !== 'lmgt_struct' ) return;
		if ( LMGT_Store::as_written( $id ) ) { echo '—'; return; }
		$c  = self::check( $id );
		$ok = function ( $b ) { return $b ? '<span style="color:#008a20">✓</span>' : '<span style="color:#b32d2e">✗</span>'; };
		echo 'Intro ' . $ok( $c['intro'] === 'ok' ) . ' · Practical ' . $ok( $c['practical'] === 'ok' )
			. ( $c['repeat'] ? ' · <span style="color:#b32d2e">title twice</span>' : '' ) . ( $c['shortcodes'] ? ' · <span style="color:#b32d2e">broken shortcode</span>' : '' );
	}

	// ---- Edit screen -------------------------------------------------------------------

	public static function box( $post ) {
		if ( ! current_user_can( 'edit_others_posts' ) ) return;
		if ( ! empty( $_GET['lmgt_smsg'] ) ) echo '<p><strong>' . esc_html( wp_unslash( $_GET['lmgt_smsg'] ) ) . '</strong></p>';
		$pend = get_post_meta( $post->ID, '_lmgt_structure', true );
		if ( is_array( $pend ) && ! empty( $pend['content'] ) ) {
			echo '<div class="notice notice-info inline"><p><strong>New structure waiting</strong> (' . esc_html( $pend['at'] ) . ' UTC):</p><ul style="list-style:disc;margin-left:16px">';
			foreach ( (array) $pend['notes'] as $n ) echo '<li>' . esc_html( $n ) . '</li>';
			echo '</ul>';
			$base = admin_url( 'admin-post.php?action=lmgt_structure_apply&post=' . $post->ID );
			echo '<p><a class="button button-primary" href="' . esc_url( wp_nonce_url( $base . '&do=apply', 'lmgt_structure_' . $post->ID ) ) . '">Accept: put it in the text</a> <a class="button" href="' . esc_url( wp_nonce_url( $base . '&do=drop', 'lmgt_structure_' . $post->ID ) ) . '">Reject: keep my text</a></p>';
			echo '<p class="description">Applying keeps the current text under Revisions. Save your own edits first.</p></div>';
		}
		// 2.6.3 (G, 8 Nov): pillar status in plain sight. It is Rank Math's tick; Translator only shows it and never removes it.
		$pil = get_post_meta( $post->ID, 'rank_math_pillar_content', true ) === 'on';
		echo '<p style="margin:4px 0"><strong>Pillar:</strong> ' . ( $pil ? '<span style="color:#008a20">yes, ticked</span>' : 'no' ) . ' <span class="description">(Rank Math → Pillar Content)</span></p>';
		if ( LMGT_Store::as_written( $post->ID ) ) {
			echo '<p class="description">News: kept as written. The Read more block is still shown.</p>';
		} else {
			$c = self::check( $post );
			$line = function ( $ok, $txt ) { echo '<p style="margin:4px 0">' . ( $ok ? '<span style="color:#008a20">✓</span> ' : '<span style="color:#b32d2e">✗</span> ' ) . esc_html( $txt ) . '</p>'; };
			$it = array( 'ok' => 'Intro: ' . $c['intro_words'] . ' words before the first heading.', 'short' => 'Intro too short (' . $c['intro_words'] . ' words). Aim for 40–150.', 'long' => 'Intro long (' . $c['intro_words'] . ' words). Aim for 40–150.', 'missing' => 'No intro before the first heading.' );
			$line( $c['intro'] === 'ok', $it[ $c['intro'] ] );
			$pt = array( 'ok' => 'Practical part last' . ( $c['practical_at'] ? ': "' . $c['practical_at'] . '"' : '' ) . '.', 'middle' => 'Practical part sits in the middle ("' . $c['practical_at'] . '"). It belongs last.', 'missing' => 'No practical part (when to go, getting there, getting around).' );
			$line( $c['practical'] === 'ok', $pt[ $c['practical'] ] );
			$line( ! $c['repeat'], $c['repeat'] ? 'A heading repeats the title: "' . $c['repeat'][0] . '". The title should appear once; rename the heading to what its section is about, or remove it.' : 'No heading repeats the title.' );
			foreach ( $c['shortcodes'] as $b ) {
				$line( false, 'Shortcode [' . $b[0] . '] has ' . $b[1] . ' opening and ' . $b[2] . ' closing tag(s). Readers see the brackets as text, and translations copy the fault. Fix the tags before translating.' );
			}
			if ( ( $c['intro'] !== 'ok' || $c['practical'] !== 'ok' ) && LMGT_Engines::ai_available() && ! is_array( $pend ) ) {
				$go = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_structure&post=' . $post->ID ), 'lmgt_structure_' . $post->ID );
				echo '<p><a class="button" href="' . esc_url( $go ) . '">Propose the structure</a></p><p class="description">Writes the intro if it is missing or weak, moves practical sections to the end, and writes a short practical part from facts already in the text when there is none. Nothing changes until you apply it.</p>';
			}
		}
		$cl = self::cluster( $post->ID );
		echo '<hr><p><strong>Read more block</strong>' . ( class_exists( 'LMGT_Stamps' ) ? str_replace( 'Last run', 'Last changed', LMGT_Stamps::line( $post->ID, 'Read more' ) ) : '' ) . '</p>';
		$html = self::block_html( $post->ID );
		echo $html ? '<div style="font-size:12px">' . wp_kses_post( str_replace( '<a ', '<a target="_blank" ', $html ) ) . '</div>' : '<p class="description">Nothing to link yet: no place page found for this text in its language.</p>';
		$m = get_post_meta( $post->ID, '_lmgt_rm', true );
		$m = is_array( $m ) ? $m : array();
		wp_nonce_field( 'lmgt_rm_' . $post->ID, 'lmgt_rm_nonce' );
		echo '<details><summary>Change it</summary>';
		echo '<p><label>Place page ID<br><input type="number" name="lmgt_rm_place" value="' . esc_attr( isset( $m['place'] ) ? $m['place'] : '' ) . '" class="small-text"></label> <label>Region page ID<br><input type="number" name="lmgt_rm_region" value="' . esc_attr( isset( $m['region'] ) ? $m['region'] : '' ) . '" class="small-text"></label></p>';
		echo '<p><label>Travel interest page IDs (up to 3)<br><input type="text" name="lmgt_rm_interests" value="' . esc_attr( isset( $m['interests'] ) ? implode( ',', (array) $m['interests'] ) : '' ) . '" style="width:100%"></label></p>';
		echo '<p class="description">Empty = found by itself. IDs of pages in the site\'s own language; translations show their version in their language.</p>';
		echo '<p><label><input type="checkbox" name="lmgt_rm_off" value="1"' . checked( get_post_meta( $post->ID, '_lmgt_rm_off', true ), '1', false ) . '> No Read more block on this one</label></p></details>';
	}

	public static function save_box( $id, $post ) {
		if ( wp_is_post_revision( $id ) || empty( $_POST['lmgt_rm_nonce'] ) || ! wp_verify_nonce( $_POST['lmgt_rm_nonce'], 'lmgt_rm_' . $id ) || ! current_user_can( 'edit_post', $id ) ) return;
		$ints = array_slice( array_filter( array_map( 'intval', preg_split( '/[\s,]+/', (string) wp_unslash( $_POST['lmgt_rm_interests'] ) ) ) ), 0, 3 );
		$m    = array_filter( array( 'place' => (int) $_POST['lmgt_rm_place'], 'region' => (int) $_POST['lmgt_rm_region'], 'interests' => $ints ) );
		$before = array( get_post_meta( $id, '_lmgt_rm', true ), (string) get_post_meta( $id, '_lmgt_rm_off', true ) );
		$m ? update_post_meta( $id, '_lmgt_rm', $m ) : delete_post_meta( $id, '_lmgt_rm' );
		! empty( $_POST['lmgt_rm_off'] ) ? update_post_meta( $id, '_lmgt_rm_off', '1' ) : delete_post_meta( $id, '_lmgt_rm_off' );
		// 2.9.4 (G, 9 Nov): the date the Read more choices were last changed.
		if ( class_exists( 'LMGT_Stamps' ) && $before !== array( get_post_meta( $id, '_lmgt_rm', true ), (string) get_post_meta( $id, '_lmgt_rm_off', true ) ) ) LMGT_Stamps::set( $id, 'Read more' );
	}

	private static function back( $id, $msg ) {
		wp_safe_redirect( add_query_arg( 'lmgt_smsg', rawurlencode( $msg ), get_edit_post_link( $id, 'url' ) ) );
		exit;
	}

	// ---- Propose and apply -------------------------------------------------------------

	/** 2.17.2: travel, wine or sport – the same answer the boxes use. */
	public static function subject() {
		return class_exists( 'LMGT_Boxes' ) ? LMGT_Boxes::subject() : 'travel';
	}

	public static function prompt( $lang, $title, $outline, array $h2, array $c ) {
		$l = LMGT_Langs::get( $lang );
		$name = $l ? $l['name'] : 'English';
		$sub  = self::subject();
		if ( $sub !== 'travel' ) {
			$house = $sub === 'wine' ? 'Winetalk, a wine media house' : 'WorldSportTalk, a sport media house';
			return "You edit {$house}. ARTICLE is a {$name} text titled \"{$title}\". Headings are marked with #. Every text opens with an intro before the first heading: inviting, it grabs attention in the first sentence, says what the text tells the reader and why it is worth reading. 50 to 120 words, one or two short paragraphs.\n"
				. "Tasks:\n"
				. "- intro: " . ( $c['intro'] === 'ok' ? "the intro is fine: return \"\"." : "the current intro is " . $c['intro'] . ". Write one in {$name}, built only on what ARTICLE says." ) . " html uses only <p>, <strong>, <em>.\n"
				. "- move_to_end: always [].\n- practical: always empty heading and html.\n"
				. "Rules: never invent a fact, number, date or name. No exclamation marks. Never mention the article's own structure. Never: phrases like delve, landscape, journey, navigate, it is important to note, in conclusion.\n"
				. "Return JSON: {\"intro\":\"<p>…</p>\",\"move_to_end\":[],\"practical\":{\"heading\":\"\",\"html\":\"\"}}.\n\n"
				. "ARTICLE:\n{$outline}";
		}
		return "You edit Traveltalk, a travel media house. ARTICLE is a {$name} travel text titled \"{$title}\". Headings are marked with #. Every Traveltalk text has one structure:\n"
			. "1. An intro before the first heading: inviting and inspiring, it grabs attention in the first sentence, says what the text tells the reader and why it is worth reading. 50 to 120 words, one or two short paragraphs.\n"
			. "2. The middle, decided by the content.\n"
			. "3. The practical part last: when to go, how to get there, getting around, where to stay, good to know.\n"
			. "Tasks:\n"
			. "- intro: " . ( $c['intro'] === 'ok' ? "the intro is fine: return \"\"." : "the current intro is " . $c['intro'] . ". Write one in {$name}, built only on what ARTICLE says. Write new sentences: never copy a sentence from ARTICLE, never name or link another article." ) . " html uses only <p>, <strong>, <em>.\n"
			. "- move_to_end: the H2 headings, copied exactly from H2, whose sections are practical information in the sense of point 3 and are not already at the end. [] when none.\n"
			. "- practical: only when ARTICLE has no practical section at all: one section in {$name}, heading \"" . self::label( self::PRACTICAL_HEADING, $lang ) . "\", 80 to 200 words, built only from practical facts ARTICLE already states. Empty heading and html when ARTICLE states no such facts.\n"
			. "Rules: never invent a fact, price, time, distance, date, route or business name. No exclamation marks. Never mention the article's own structure. Never: phrases like delve, landscape, journey, navigate, it is important to note, in conclusion. Match the tone of ARTICLE." . ( $lang === 'en' ? ' British spelling.' : '' ) . "\n"
			. "Return JSON: {\"intro\":\"<p>…</p>\",\"move_to_end\":[\"…\"],\"practical\":{\"heading\":\"…\",\"html\":\"<p>…</p>\"}}.\n\n"
			. "H2:\n" . implode( "\n", $h2 ) . "\n\nARTICLE:\n{$outline}";
	}

	private static function outline( $html ) {
		$html = preg_replace_callback( '#<h([1-6])[^>]*>(.*?)</h\1>#is', function ( $m ) { return "\n\n" . str_repeat( '#', (int) $m[1] ) . ' ' . wp_strip_all_tags( $m[2] ) . "\n"; }, $html );
		$html = preg_replace( '#</(p|li|ul|ol|div|table|tr)>#i', "$0\n", $html );
		return trim( preg_replace( "/\n{3,}/", "\n\n", html_entity_decode( wp_strip_all_tags( strip_shortcodes( $html ) ), ENT_QUOTES, 'UTF-8' ) ) );
	}

	public static function handle_propose() {
		$id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
		check_admin_referer( 'lmgt_structure_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$post = get_post( $id );
		if ( ! $post ) wp_die( 'Not found.' );
		@set_time_limit( 200 );
		$c    = self::check( $post );
		$html = $post->post_content;
		$h2   = array();
		foreach ( self::sections( $html ) as $s ) if ( $s['level'] <= 2 ) $h2[] = $s['text'];
		$schema = array(
			'type'       => 'object',
			'properties' => array(
				'intro'       => array( 'type' => 'string' ),
				'move_to_end' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
				'practical'   => array( 'type' => 'object', 'properties' => array( 'heading' => array( 'type' => 'string' ), 'html' => array( 'type' => 'string' ) ), 'required' => array( 'heading', 'html' ), 'additionalProperties' => false ),
			),
			'required'             => array( 'intro', 'move_to_end', 'practical' ),
			'additionalProperties' => false,
		);
		$r = LMGT_Engines::ai_json( self::prompt( $c['lang'], $post->post_title, mb_substr( self::outline( $html ), 0, 45000 ), $h2, $c ), $schema );
		LMGT_Meter::charge( $id );
		if ( is_wp_error( $r ) ) self::back( $id, 'No structure proposed: ' . $r->get_error_message() );

		$blocks = strpos( $html, '<!-- wp:' ) !== false;
		$notes  = array();
		$allow  = array( 'p' => array(), 'ul' => array(), 'li' => array(), 'strong' => array(), 'em' => array() );

		// Practical sections to the end, in their order, each only when it can be lifted out whole.
		$moved = '';
		foreach ( (array) $r['move_to_end'] as $want ) {
			$name = self::match_heading( (string) $want, $h2 );
			if ( $name === '' ) continue;
			$cut = self::section_span( $html, $name, $blocks );
			if ( ! $cut ) { $notes[] = '"' . $name . '" could not be moved: it sits inside a layout block. Move it by hand.'; continue; }
			$moved .= "\n\n" . trim( substr( $html, $cut[0], $cut[1] - $cut[0] ) );
			$html   = substr( $html, 0, $cut[0] ) . substr( $html, $cut[1] );
			$notes[] = '"' . $name . '" moved to the end.';
		}
		if ( $moved !== '' ) {
			$at   = self::end_point( $html, 'practical' );
			$html = rtrim( substr( $html, 0, $at ) ) . $moved . "\n\n" . ltrim( substr( $html, $at ) );
		}

		$p = isset( $r['practical'] ) && is_array( $r['practical'] ) ? $r['practical'] : array();
		if ( $c['practical'] === 'missing' && $moved === '' && ! empty( $p['heading'] ) && ! empty( $p['html'] ) ) {
			$s    = array( 'heading' => sanitize_text_field( $p['heading'] ), 'html' => wp_kses( (string) $p['html'], $allow ) );
			$at   = self::end_point( $html, 'practical' );
			$html = rtrim( substr( $html, 0, $at ) ) . LMGT_Admin::section_markup( $s, $blocks, 2 ) . "\n\n" . ltrim( substr( $html, $at ) );
			$notes[] = 'Practical part written: "' . $s['heading'] . '" (' . str_word_count( wp_strip_all_tags( $s['html'] ) ) . ' words, from facts already in the text).';
		}

		// 2.17.24 (G, 20 Nov: "structure still takes 3–4 tries"): when the practical part stays as it was (no facts for
		// one, or nothing Claude can move), say so in the proposal; accepting it then settles the step.
		$prac_left = $c['practical'] !== 'ok' && $moved === '' && ! ( $c['practical'] === 'missing' && ! empty( $p['heading'] ) && ! empty( $p['html'] ) );
		if ( $prac_left ) $notes[] = $c['practical'] === 'missing' ? 'No practical part written: the text states no practical facts (when to go, getting there, getting around). Add them by hand if you want one; the step counts as done once you accept.' : 'The practical part stays where it is: Claude found nothing that should move. The step counts as done once you accept.';
		// 2.17.25 (G, 20 Nov, Vinrejser i Italien: the text opened with the heading "Artiklen", so the intro looked missing
		// and Claude's "new" intro repeated the first paragraph). A label heading at the very top is taken out instead:
		// the paragraph under it becomes the intro. A link the engine wrote is dropped with its words, not kept as text.
		$label = self::label_heading( $html );
		$intro = trim( wp_kses( preg_replace( '#<a\b[^>]*>.*?</a>#is', '', (string) $r['intro'] ), array( 'p' => array(), 'strong' => array(), 'em' => array() ) ) );
		if ( $c['intro'] === 'missing' && $label ) {
			$html    = substr( $html, 0, $label[0] ) . substr( $html, $label[1] );
			$notes[] = 'The text opened with the heading "' . $label[2] . '"; it is taken out, so the first paragraph is the intro. No new intro written.';
			$intro   = '';
		} elseif ( $intro !== '' && self::copies( $intro, $html ) ) {
			$notes[] = 'Claude\'s intro repeated sentences already in the text, so it was left out. Write the intro by hand, or propose again.';
			$intro   = '';
		}
		if ( $c['intro'] !== 'ok' && $intro !== '' ) {
			$html    = self::put_intro( $html, $intro, $blocks, $c['intro'] );
			$notes[] = $c['intro'] === 'missing' ? 'Intro written: ' . mb_substr( wp_strip_all_tags( $intro ), 0, 140 ) . '…' : 'Intro rewritten (the first paragraph is replaced): ' . mb_substr( wp_strip_all_tags( $intro ), 0, 140 ) . '…';
		}
		// 2.17.20: nothing Claude can change is a result, not an error – the step counts as done until the text changes.
		if ( ! $notes || $html === $post->post_content || ( $prac_left && count( $notes ) === 1 ) ) {
			update_post_meta( $id, '_lmgt_struct_kept', self::shape( self::without_boxes( (string) $post->post_content ) ) );
			self::back( $id, 'Checked: nothing to move. The structure is kept as it is' . ( $notes ? ' (' . implode( ' ', $notes ) . ')' : '' ) . '. The step counts as done until the text changes.' );
		}
		update_post_meta( $id, '_lmgt_structure', wp_slash( array( 'content' => $html, 'notes' => $notes, 'at' => current_time( 'mysql', true ), 'prac_left' => $prac_left ? 1 : 0 ) ) );
		self::back( $id, 'Structure proposed. Read it in the Structure box, then apply or discard.' );
	}

	/** [start, end] of an H2 section (heading to the next H2), only when it is whole at the top level. */
	private static function section_span( $html, $name, $blocks ) {
		$secs = array_values( array_filter( self::sections( $html ), function ( $s ) { return $s['level'] <= 2; } ) );
		foreach ( $secs as $i => $s ) {
			if ( $s['text'] !== $name ) continue;
			$a = $s['start'];
			$b = isset( $secs[ $i + 1 ] ) ? $secs[ $i + 1 ]['start'] : self::end_point( $html, 'practical' );
			if ( $blocks ) {
				$op = '#<!-- wp:[a-z0-9/-]+(?: \{[^\n]*?\})? -->\s*$#';
				if ( preg_match( $op, substr( $html, 0, $a ), $m, PREG_OFFSET_CAPTURE ) ) $a = $m[0][1];
				if ( isset( $secs[ $i + 1 ] ) && preg_match( $op, substr( $html, 0, $b ), $m, PREG_OFFSET_CAPTURE ) ) $b = $m[0][1];
				if ( self::depth_at( $html, $a ) !== 0 || self::depth_at( $html, $b ) !== 0 ) return null;
			}
			return array( $a, $b );
		}
		return null;
	}

	const LABELS = array( 'artiklen', 'artikel', 'indledning', 'intro', 'introduktion', 'introduction', 'the article', 'article', 'einleitung', 'introducción', 'introduzione', 'inledning', 'innledning', 'johdanto' );

	/** [start, end, text] of a label heading ("Artiklen", "Intro") with no text above it, block markers included; else null. */
	private static function label_heading( $html ) {
		foreach ( self::sections( $html ) as $s ) {
			if ( trim( LMGT_Text::plain( substr( $html, 0, $s['start'] ) ) ) !== '' ) return null;
			if ( ! in_array( mb_strtolower( trim( $s['text'], " :.-–" ) ), self::LABELS, true ) ) return null;
			$a = $s['start']; $b = $s['end'];
			if ( preg_match( '#<!-- wp:heading[^>]*-->\s*$#', substr( $html, 0, $a ), $m, PREG_OFFSET_CAPTURE ) ) $a = $m[0][1];
			if ( preg_match( '#^\s*<!-- /wp:heading -->#', substr( $html, $b ), $m ) ) $b += strlen( $m[0] );
			return array( $a, $b, $s['text'] );
		}
		return null;
	}

	/** True when a sentence of 8 words or more in $intro already stands in $html. */
	private static function copies( $intro, $html ) {
		$all = ' ' . self::norm( LMGT_Text::plain( $html ) ) . ' ';
		foreach ( preg_split( '/(?<=[.!?])\s+/u', LMGT_Text::plain( $intro ) ) as $sen ) {
			$n = self::norm( $sen );
			if ( count( explode( ' ', $n ) ) >= 8 && mb_strpos( $all, ' ' . $n . ' ' ) !== false ) return true;
		}
		return false;
	}

	private static function put_intro( $html, $intro, $blocks, $state ) {
		$parts = preg_split( '#(?<=</p>)\s*#', $intro, -1, PREG_SPLIT_NO_EMPTY );
		$mk    = '';
		foreach ( $parts as $p ) $mk .= $blocks ? "<!-- wp:paragraph -->\n" . trim( $p ) . "\n<!-- /wp:paragraph -->\n\n" : trim( $p ) . "\n\n";
		$first = null;
		foreach ( self::sections( $html ) as $s ) if ( $s['level'] <= 2 ) { $first = $s; break; }
		$limit = $first ? $first['start'] : strlen( $html );
		if ( $state !== 'missing' && preg_match( $blocks ? '#<!-- wp:paragraph[^>]*-->\s*<p[^>]*>.*?</p>\s*<!-- /wp:paragraph -->#s' : '#<p[^>]*>.*?</p>#s', $html, $m, PREG_OFFSET_CAPTURE ) && $m[0][1] < $limit ) {
			return substr( $html, 0, $m[0][1] ) . rtrim( $mk ) . substr( $html, $m[0][1] + strlen( $m[0][0] ) );
		}
		$at = $limit;
		if ( $first && $blocks && preg_match( '#<!-- wp:[a-z0-9/-]+(?: \{[^\n]*?\})? -->\s*$#', substr( $html, 0, $at ), $op, PREG_OFFSET_CAPTURE ) ) $at = $op[0][1];
		if ( $blocks && self::depth_at( $html, $at ) !== 0 ) $at = 0;
		return substr( $html, 0, $at ) . $mk . substr( $html, $at );
	}

	public static function handle_apply() {
		$id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
		check_admin_referer( 'lmgt_structure_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) wp_die( 'Not allowed.' );
		$p = get_post_meta( $id, '_lmgt_structure', true );
		// 2.7.1: the proposal was made from the text as it was then; edits made since would be lost.
		if ( isset( $_GET['do'] ) && $_GET['do'] === 'apply' && empty( $_GET['anyway'] ) && is_array( $p ) && ! empty( $p['at'] ) && LMGT_Stamps::edited_since( $id, '_lmgt_structure', $p['at'] ) ) {
			$any = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_structure_apply&do=apply&anyway=1&post=' . $id ), 'lmgt_structure_' . $id );
			wp_die( '<h2>Not accepted – your edits would be lost</h2><p>The text was edited after this structure was proposed (' . esc_html( $p['at'] ) . ' UTC). Accepting would put the older text back.</p><p><a class="button button-primary" href="' . esc_url( get_edit_post_link( $id, 'url' ) ) . '">Back: keep my text</a> &nbsp; <a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_structure&post=' . $id ), 'lmgt_structure_' . $id ) ) . '">Propose again from my text</a> &nbsp; <a class="button" href="' . esc_url( $any ) . '">Accept anyway</a></p><p class="description">Propose again from my text: a new structure made from the text as it is now (about a minute). Accept anyway: the proposal wins and the changes since are lost; they stay under Revisions.</p>', 'Not accepted', array( 'response' => 200 ) );
		}
		delete_post_meta( $id, '_lmgt_structure' );
		if ( ! isset( $_GET['do'] ) || $_GET['do'] !== 'apply' || ! is_array( $p ) || empty( $p['content'] ) ) self::back( $id, 'Discarded. The text is unchanged.' );
		$r = LMGT_Store::update_content( $id, array( 'post_content' => $p['content'] ), true );
		// 2.6.2 (G, 8 Nov: "the structure does not change"): say so when the text did not take it.
		if ( is_wp_error( $r ) || ! $r ) self::back( $id, 'The new structure could not be saved: ' . ( is_wp_error( $r ) ? $r->get_error_message() : 'unknown error' ) . '. The text is unchanged.' );
		if ( md5( (string) get_post_field( 'post_content', $id, 'raw' ) ) !== md5( (string) $p['content'] ) ) self::back( $id, 'The new structure was saved, but the text was changed again straight after (another plugin or the editor). Reload the page and check before you edit.' );
		delete_post_meta( $id, '_lmgt_reviewed' );
		if ( ! empty( $p['prac_left'] ) ) update_post_meta( $id, '_lmgt_struct_kept', self::shape( self::without_boxes( (string) $p['content'] ) ) );
		$msg = 'New structure applied. The previous version is under Revisions. If the editor still shows the old text, reload the page before you press Update.';
		if ( get_post_type( $id ) !== LMGT_CPT && ! LMGT_Store::is_tagged( $id ) ) {
			$queued = 0;
			foreach ( array_keys( LMGT_Store::of( $id ) ) as $lang ) {
				if ( ! is_wp_error( LMGT_Jobs::add( $id, $lang ) ) ) $queued++;
			}
			if ( $queued ) $msg .= ' ' . $queued . ' language(s) queued for translation again, so they follow.';
		}
		self::back( $id, $msg );
	}
}
