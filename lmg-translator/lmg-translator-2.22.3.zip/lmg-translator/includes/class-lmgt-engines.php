<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * DeepL and Gemini. Every call either returns what was asked for or a WP_Error
 * — never the input text dressed up as a result. That single rule is the fix
 * for the old plugin, whose last line returned the Danish original whenever
 * both engines failed, and saved it as Swedish.
 *
 * Keys travel in headers, never in a URL, so they do not end up in server logs.
 */
class LMGT_Engines {

	// ---- DeepL ---------------------------------------------------------------

	/** Saved in Settings, else LMGT_DEEPL_KEY in wp-config.php (where 2.0.0 kept it). */
	public static function deepl_key() {
		$k = trim( (string) get_option( 'lmgt_deepl_key', '' ) );
		return $k !== '' || ! defined( 'LMGT_DEEPL_KEY' ) ? $k : trim( (string) LMGT_DEEPL_KEY );
	}

	private static function deepl_base() {
		$key = self::deepl_key();
		if ( $key === '' ) return null;
		return substr( $key, -3 ) === ':fx' ? 'https://api-free.deepl.com/v2/' : 'https://api.deepl.com/v2/';
	}

	private static function deepl_headers() {
		return array(
			'Authorization' => 'DeepL-Auth-Key ' . self::deepl_key(),
			'Content-Type'  => 'application/json',
		);
	}

	public static function deepl_available() {
		return self::deepl_base() !== null;
	}

	/** @return array{count:int,limit:int}|WP_Error */
	public static function deepl_usage() {
		$base = self::deepl_base();
		if ( ! $base ) return new WP_Error( 'lmgt_deepl', 'No DeepL key saved.' );
		$r = wp_remote_get( $base . 'usage', array( 'headers' => self::deepl_headers(), 'timeout' => 20 ) );
		if ( is_wp_error( $r ) ) return $r;
		$b = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( wp_remote_retrieve_response_code( $r ) !== 200 || ! isset( $b['character_count'] ) ) {
			return new WP_Error( 'lmgt_deepl', 'DeepL usage check failed (HTTP ' . wp_remote_retrieve_response_code( $r ) . ').' );
		}
		return array( 'count' => (int) $b['character_count'], 'limit' => (int) $b['character_limit'] );
	}

	/**
	 * @param string[] $texts  Up to 50 strings, HTML allowed.
	 * @return array{texts:string[],detected:string[]}|WP_Error
	 */
	public static function deepl( array $texts, $from, $to ) {
		$base = self::deepl_base();
		if ( ! $base ) return new WP_Error( 'lmgt_deepl', 'No DeepL key saved.' );
		$src = LMGT_Langs::get( $from );
		$tgt = LMGT_Langs::get( $to );

		$out = array( 'texts' => array(), 'detected' => array() );
		// DeepL caps a request at 50 texts and 128 KiB; stay well under both.
		$batch = array();
		$size  = 0;
		$flush = function () use ( &$batch, &$size, &$out, $base, $src, $tgt ) {
			if ( ! $batch ) return true;
			$r = wp_remote_post( $base . 'translate', array(
				'headers' => self::deepl_headers(),
				'timeout' => 90,
				'body'    => wp_json_encode( array(
					'text'                => array_values( $batch ),
					'source_lang'         => $src['deepl_src'],
					'target_lang'         => $tgt['deepl'],
					'tag_handling'        => 'html',
					'preserve_formatting' => true,
					'show_billed_characters' => true,
				) ),
			) );
			if ( is_wp_error( $r ) ) return $r;
			$code = (int) wp_remote_retrieve_response_code( $r );
			if ( $code === 456 ) return new WP_Error( 'lmgt_quota', 'DeepL monthly character allowance is used up.' );
			if ( $code === 429 ) return new WP_Error( 'lmgt_busy', 'DeepL asked us to slow down (HTTP 429). Try again in a minute.' );
			if ( $code === 403 ) return new WP_Error( 'lmgt_deepl', 'DeepL rejected the key (HTTP 403).' );
			$b = json_decode( wp_remote_retrieve_body( $r ), true );
			if ( $code !== 200 || empty( $b['translations'] ) || count( $b['translations'] ) !== count( $batch ) ) {
				return new WP_Error( 'lmgt_deepl', 'DeepL returned an unusable answer (HTTP ' . $code . ').' );
			}
			$billed = 0;
			foreach ( $b['translations'] as $n => $t ) {
				$billed += isset( $t['billed_characters'] ) ? (int) $t['billed_characters'] : mb_strlen( $batch[ $n ] );
				$out['texts'][]    = (string) $t['text'];
				$out['detected'][] = isset( $t['detected_source_language'] ) ? $t['detected_source_language'] : '';
			}
			LMGT_Meter::deepl( $billed );
			$batch = array();
			$size  = 0;
			return true;
		};
		foreach ( $texts as $t ) {
			$len = strlen( $t );
			if ( $batch && ( count( $batch ) >= 40 || $size + $len > 100000 ) ) {
				$ok = $flush();
				if ( is_wp_error( $ok ) ) return $ok;
			}
			$batch[] = (string) $t;
			$size   += $len;
		}
		$ok = $flush();
		if ( is_wp_error( $ok ) ) return $ok;
		return $out;
	}

	// ---- Gemini --------------------------------------------------------------

	// The "AI" step (translate, polish, back-translate, compare) runs on Gemini or
	// Claude, chosen in Settings. The gemini_* names below are that step's entry
	// points and hand over to Claude when Claude is chosen.

	public static function ai_is_claude() {
		return true; // 2.13.0: Claude only (agreed 26 Oct); Gemini is no longer used.
	}

	public static function ai_name() {
		return self::ai_is_claude() ? 'Claude' : 'Gemini';
	}

	/** Name and model, for the review box: shows which engine wrote a draft. */
	public static function ai_label() {
		return self::ai_name() . ' (' . ( self::ai_is_claude() ? self::claude_model() : self::gemini_model() ) . ')';
	}

	/**
	 * 2.2.27: was gemini_available / gemini_json; they serve whichever AI engine is chosen
	 * (Claude on both sites). The stored settings keep their old names (lmgt_gemini_key,
	 * lmgt_gemini_model): those really are Gemini's, and renaming them would move a saved key.
	 */
	public static function ai_available() {
		if ( self::ai_is_claude() ) return self::claude_key() !== '';
		return trim( (string) get_option( 'lmgt_gemini_key', '' ) ) !== '';
	}

	public static function gemini_model() {
		$m = trim( (string) get_option( 'lmgt_gemini_model', '' ) );
		return preg_match( '/^[a-z0-9.\-]+$/', $m ) ? $m : 'gemini-2.5-flash';
	}

	/**
	 * One prompt in, one JSON object out.
	 * @return array|WP_Error
	 */
	/**
	 * 2.17.21 (G, 19 Nov: Italy "stalling for 10 min" on a box): a click in wp-admin waits for one answer, and the
	 * host stops a page after a few minutes without telling the browser. A click's calls share 150 seconds from
	 * the moment the page was asked for; a second try only starts if there is time left. Background work keeps 120 s a try.
	 */
	public static function wait_for( $default = 120 ) {
		if ( ( defined( 'DOING_CRON' ) && DOING_CRON ) || ! is_admin() ) return array( $default, true );
		$start = isset( $_SERVER['REQUEST_TIME'] ) ? (int) $_SERVER['REQUEST_TIME'] : time();
		$left  = 150 - ( time() - $start );
		return array( max( 5, min( $default, $left ) ), $left >= 30 );
	}

	public static function ai_json( $prompt, $schema = null ) {
		if ( self::ai_is_claude() ) return self::claude_json( $prompt, $schema );
		$key = trim( (string) get_option( 'lmgt_gemini_key', '' ) );
		if ( $key === '' ) return new WP_Error( 'lmgt_gemini', 'No Gemini key saved.' );
		$url = 'https://generativelanguage.googleapis.com/v1beta/models/' . self::gemini_model() . ':generateContent';

		for ( $attempt = 1; $attempt <= 2; $attempt++ ) {
			list( $wait, $room ) = self::wait_for();
			if ( ! $room && $attempt > 1 ) return new WP_Error( 'lmgt_slow', 'Gemini took too long to answer (over two minutes). Nothing was changed. Try once more.' );
			$r = wp_remote_post( $url, array(
				'headers' => array( 'x-goog-api-key' => $key, 'Content-Type' => 'application/json' ),
				'timeout' => $wait,
				'body'    => wp_json_encode( array(
					'contents'         => array( array( 'role' => 'user', 'parts' => array( array( 'text' => $prompt ) ) ) ),
					'generationConfig' => array( 'responseMimeType' => 'application/json', 'temperature' => 0.2 ),
				) ),
			) );
			if ( is_wp_error( $r ) ) return $r;
			$code = (int) wp_remote_retrieve_response_code( $r );
			$b    = json_decode( wp_remote_retrieve_body( $r ), true );
			if ( $code === 429 ) return new WP_Error( 'lmgt_busy', 'Gemini asked us to slow down (HTTP 429). Try again in a minute.' );
			if ( $code === 404 ) return new WP_Error( 'lmgt_gemini', 'Gemini model "' . self::gemini_model() . '" not found — change it in Translator → Settings.' );
			if ( $code !== 200 ) {
				$msg = isset( $b['error']['message'] ) ? $b['error']['message'] : '';
				return new WP_Error( 'lmgt_gemini', 'Gemini error (HTTP ' . $code . ') ' . $msg );
			}
			$u = isset( $b['usageMetadata'] ) ? $b['usageMetadata'] : array();
			LMGT_Meter::ai( self::gemini_model(), isset( $u['promptTokenCount'] ) ? $u['promptTokenCount'] : 0, ( isset( $u['candidatesTokenCount'] ) ? $u['candidatesTokenCount'] : 0 ) + ( isset( $u['thoughtsTokenCount'] ) ? $u['thoughtsTokenCount'] : 0 ) );
			$text = '';
			foreach ( (array) ( isset( $b['candidates'][0]['content']['parts'] ) ? $b['candidates'][0]['content']['parts'] : array() ) as $p ) {
				if ( isset( $p['text'] ) ) $text .= $p['text'];
			}
			$text = trim( preg_replace( '/^```(?:json)?\s*|\s*```$/', '', trim( $text ) ) );
			$json = json_decode( $text, true );
			if ( is_array( $json ) ) return $json;
			$finish = isset( $b['candidates'][0]['finishReason'] ) ? $b['candidates'][0]['finishReason'] : '';
			if ( $finish === 'MAX_TOKENS' ) return new WP_Error( 'lmgt_gemini', 'Gemini ran out of room for this section. Nothing saved.' );
		}
		return new WP_Error( 'lmgt_gemini', 'Gemini did not return valid JSON twice in a row. Nothing saved.' );
	}

	// ---- Claude --------------------------------------------------------------

	/** Own key, else LMGT_ANTHROPIC_KEY in wp-config.php (2.0.0), else the key LeisureIntel already holds on this site. */
	public static function claude_key() {
		$k = trim( (string) get_option( 'lmgt_claude_key', '' ) );
		if ( $k === '' && defined( 'LMGT_ANTHROPIC_KEY' ) ) $k = trim( (string) LMGT_ANTHROPIC_KEY );
		return $k !== '' ? $k : trim( (string) get_option( 'li_claude_api_key', '' ) );
	}

	public static function claude_model() {
		$m = trim( (string) get_option( 'lmgt_claude_model', '' ) );
		return preg_match( '/^claude-[a-z0-9.\-]+$/', $m ) ? $m : 'claude-haiku-5-5';
	}

	/** Translation needs no reasoning step; switch it off where the model allows. */
	private static function claude_thinking( $model ) {
		if ( strpos( $model, 'claude-sonnet-5-5' ) === 0 ) return array( 'thinking' => array( 'type' => 'between_tools' ) );
		if ( strpos( $model, 'claude-haiku-5' ) === 0 ) return array( 'thinking' => array( 'type' => 'disabled' ) );
		if ( preg_match( '/^claude-(opus-5|fable)/', $model ) ) return array( 'output_config' => array( 'effort' => 'low' ) );
		return array();
	}

	/**
	 * With a schema, Claude's structured output guarantees parseable JSON of that
	 * shape; long texts with quotes and line breaks can then no longer break it.
	 */
	private static function claude_body( $model, $prompt, $schema ) {
		$b = array_merge( array(
			'model'      => $model,
			'max_tokens' => 16000,
			'system'     => 'Reply with one raw JSON object only. No markdown, no code fences, no text before or after.',
			'messages'   => array( array( 'role' => 'user', 'content' => $prompt ) ),
		), self::claude_thinking( $model ) );
		if ( $schema ) {
			$b['output_config'] = array_merge( isset( $b['output_config'] ) ? $b['output_config'] : array(), array( 'format' => array( 'type' => 'json_schema', 'schema' => $schema ) ) );
		}
		return $b;
	}

	/** An object of string fields, all required. */
	public static function schema_strings( array $keys ) {
		$p = array();
		foreach ( $keys as $k ) $p[ (string) $k ] = array( 'type' => 'string' );
		return array( 'type' => 'object', 'properties' => (object) $p, 'required' => array_values( array_map( 'strval', $keys ) ), 'additionalProperties' => false );
	}

	private static function schema_list( array $keys ) {
		return array( 'type' => 'array', 'items' => self::schema_strings( $keys ) );
	}

	/** The compare step's answer. */
	public static function schema_compare() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'issues'               => self::schema_list( array( 'type', 'original', 'back', 'note' ) ),
				'original_suggestions' => self::schema_list( array( 'text', 'suggestion', 'why' ) ),
				'title_lang'           => array( 'type' => 'string' ),
				'body_lang'            => array( 'type' => 'string' ),
				'gaps'                 => self::schema_list( array( 'topic', 'add' ) ),
			),
			'required'             => array( 'issues', 'original_suggestions', 'title_lang', 'body_lang', 'gaps' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * Same contract as ai_json: one prompt in, one JSON object out.
	 * @return array|WP_Error
	 */
	public static function claude_json( $prompt, $schema = null ) {
		$key = self::claude_key();
		if ( $key === '' ) return new WP_Error( 'lmgt_claude', 'No Claude key saved.' );
		$model = self::claude_model();

		for ( $attempt = 1; $attempt <= 2; $attempt++ ) {
			list( $wait, $room ) = self::wait_for();
			if ( ! $room && $attempt > 1 ) return new WP_Error( 'lmgt_slow', 'Claude took too long to answer (over two minutes). Nothing was changed. Try once more; a very long text can take two tries.' );
			$r = wp_remote_post( 'https://api.anthropic.com/v1/messages', array(
				'headers' => array( 'x-api-key' => $key, 'anthropic-version' => '2023-06-01', 'Content-Type' => 'application/json' ),
				'timeout' => $wait,
				'body'    => wp_json_encode( self::claude_body( $model, $prompt, $schema ) ),
			) );
			if ( is_wp_error( $r ) ) return $r;
			$code = (int) wp_remote_retrieve_response_code( $r );
			$b    = json_decode( wp_remote_retrieve_body( $r ), true );
			if ( $code === 429 || $code === 529 ) return new WP_Error( 'lmgt_busy', 'Claude asked us to slow down (HTTP ' . $code . '). Try again in a minute.' );
			if ( $code === 404 ) return new WP_Error( 'lmgt_claude', 'Claude model "' . $model . '" not found — change it in Translator → Settings.' );
			if ( $code !== 200 ) {
				$msg = isset( $b['error']['message'] ) ? $b['error']['message'] : '';
				return new WP_Error( 'lmgt_claude', 'Claude error (HTTP ' . $code . ') ' . $msg );
			}
			$u = isset( $b['usage'] ) ? $b['usage'] : array();
			$in = 0;
			foreach ( array( 'input_tokens', 'cache_creation_input_tokens', 'cache_read_input_tokens' ) as $k ) $in += isset( $u[ $k ] ) ? (int) $u[ $k ] : 0;
			LMGT_Meter::ai( $model, $in, isset( $u['output_tokens'] ) ? $u['output_tokens'] : 0 );
			$stop = isset( $b['stop_reason'] ) ? $b['stop_reason'] : '';
			if ( $stop === 'max_tokens' ) return new WP_Error( 'lmgt_claude', 'Claude ran out of room for this section. Nothing saved.' );
			if ( $stop === 'refusal' ) return new WP_Error( 'lmgt_claude', 'Claude declined this section. Nothing saved.' );
			$text = '';
			foreach ( (array) ( isset( $b['content'] ) ? $b['content'] : array() ) as $p ) {
				if ( isset( $p['type'], $p['text'] ) && $p['type'] === 'text' ) $text .= $p['text'];
			}
			$text = trim( preg_replace( '/^```(?:json)?\s*|\s*```$/', '', trim( $text ) ) );
			$json = json_decode( $text, true );
			if ( is_array( $json ) ) return $json;
		}
		return new WP_Error( 'lmgt_claude', 'Claude did not return valid JSON twice in a row. Nothing saved.' );
	}

	// ---- Prompts -------------------------------------------------------------

	private static function rules( $to ) {
		$l = LMGT_Langs::get( $to );
		$r = "Rules:\n"
			. "- Keep every HTML tag and attribute exactly as it is. Translate only the visible text, plus the values of alt=\"…\" and title=\"…\" attributes (image descriptions), which are translated too.\n"
			. "- Keep every <lmgt-p data-i=\"N\"></lmgt-p> placeholder exactly as written, the same number of them, in the same order.\n"
			. "- Do not add, remove, summarise or reorder content. No notes, no explanations.\n"
			. "- Keep every number, price, date, distance and opening time exactly. Keep names of people, places and businesses.\n"
			. "- Write as a native {$l['name']} " . LMGT_Subject::w( 'writer' ) . " would: natural, idiomatic, not literal. No exclamation marks unless the source has them.\n";
		if ( $to === 'en' ) $r .= "- British English spelling.\n";
		if ( $to === 'nb' ) $r .= "- Norwegian Bokmål, not Danish spellings (av not af, etter not efter, mye not meget).\n";
		if ( $to === 'sv' ) $r .= "- Swedish, not Danish or Norwegian.\n";
		if ( $to === 'pt' ) $r .= "- Brazilian Portuguese (você, ônibus, trem), not European Portuguese.\n";
		$r .= "- Keep the names traveltalk, traveltalk.dk, traveltalk.travel, winetalk, worldsporttalk and think-smarter exactly as they are.\n";
		// 2.17.18 (Travel 360 3b): adapted for international readers, not word for word.
		$r .= "- Prices in Danish kroner: write them as DKK (\"DKK 5,000\", not \"5.000 kr.\"), same amount. Danish-only references a foreign reader would not know (Danish TV programmes, Danish chains, Danish holidays) get a few words of explanation or are put in general terms.\n";
		// 2.6.0 (G, 8 Nov): the outlook follows the site. traveltalk.dk writes from Denmark and the Nordics;
		// its translations are read by the world. Never swap Denmark for another country.
		$r .= "- The source is written for Danish and Nordic readers; the translation is for international readers. Where the source speaks from Denmark (\"Danish golfers\", \"close to Denmark\", \"for Danes\", Danish airports, Danish associations, prices only in Danish kroner), say the same thing without the Danish point of view: \"golfers\", the place and its distance from where it actually is. Never replace Denmark with another country or nationality.\n";
		// Settings → Glossary (2.2.0, brief 4.14).
		$g = LMGT_Sync::glossary( $to );
		if ( $g !== '' ) $r .= "- Fixed terms. Where the source has the term on the left, write the term on the right:\n" . $g . "\n";
		return $r;
	}

	/** Gemini as translator, when DeepL is not used for this job. */
	public static function prompt_translate( $from, $to, array $fields ) {
		$a = LMGT_Langs::get( $from );
		$b = LMGT_Langs::get( $to );
		return "Translate this {$a['name']} " . LMGT_Subject::w( 'kind' ) . " content into {$b['name']}.\n" . self::rules( $to )
			. "Return JSON with exactly the same keys as the input, each value translated.\n\nINPUT JSON:\n"
			. wp_json_encode( $fields, JSON_UNESCAPED_UNICODE );
	}

	/** Gemini as editor of a DeepL draft — the "polish" pass. */
	public static function prompt_polish( $from, $to, array $source, array $draft ) {
		$a = LMGT_Langs::get( $from );
		$b = LMGT_Langs::get( $to );
		return "You are a native {$b['name']} editor. DRAFT is a machine translation of SOURCE ({$a['name']}). "
			. "Improve DRAFT so it reads as if written in {$b['name']} from the start, while saying exactly what SOURCE says.\n"
			. self::rules( $to )
			. "Return JSON with exactly the keys of DRAFT, each value the improved {$b['name']} text.\n\n"
			. 'SOURCE JSON:' . "\n" . wp_json_encode( $source, JSON_UNESCAPED_UNICODE ) . "\n\n"
			. 'DRAFT JSON:' . "\n" . wp_json_encode( $draft, JSON_UNESCAPED_UNICODE );
	}

	/** Back-translation into the source language, plain text. */
	public static function prompt_back( $from, $to, array $fields ) {
		$a = LMGT_Langs::get( $from );
		$b = LMGT_Langs::get( $to );
		return "Translate this {$b['name']} text into {$a['name']} as literally as is still readable. "
			. "Do not correct, improve or smooth anything — the point is to show what the {$b['name']} text actually says. "
			. "Return JSON with the same keys.\n\nINPUT JSON:\n" . wp_json_encode( $fields, JSON_UNESCAPED_UNICODE );
	}

	/** Corrections for flagged passages, as exact find/replace pairs on the translation's HTML. */
	public static function prompt_fix( $from, $to, $orig_text, $tr_html, array $issues ) {
		$a = LMGT_Langs::get( $from );
		$b = LMGT_Langs::get( $to );
		$list = '';
		foreach ( $issues as $n => $i ) {
			$list .= $n . '. original: "' . ( isset( $i['original'] ) ? $i['original'] : '' ) . '" | back-translated: "' . ( isset( $i['back'] ) ? $i['back'] : '' ) . '" | note: ' . ( isset( $i['note'] ) ? $i['note'] : '' ) . "\n";
		}
		return "TRANSLATION is the {$b['name']} version (HTML) of ORIGINAL ({$a['name']}). A check flagged the passages in ISSUES as saying something different from ORIGINAL.\n"
			. "For each issue that is a real difference in meaning, fact, number, name, omission or addition, correct the {$b['name']} sentence so it says what ORIGINAL says. Skip issues that are only wording.\n"
			. "- find: an exact, unique substring of TRANSLATION as given, at most one sentence, never crossing a paragraph.\n"
			. "- replace: the corrected text. Keep every tag and attribute inside it unchanged. Natural {$b['name']}.\n"
			. "Return JSON: {\"fixes\":[{\"issue\":N,\"find\":\"…\",\"replace\":\"…\"}],\"skipped\":[N]}.\n\n"
			. "ISSUES:\n{$list}\nORIGINAL:\n{$orig_text}\n\nTRANSLATION:\n{$tr_html}";
	}

	private static function gaps_rule( array $ctx = array() ) {
		$end = 'topic: two to four words; add: one sentence on what to write. Leave the list empty when the article is complete.';
		if ( self::is_spoke( $ctx ) && LMGT_Subject::is_travel() ) {
			return 'the 3 to 6 things that would make a reader understand the subject of ORIGINAL better, judged by its title and what it is filed under, '
				. 'that ORIGINAL lacks or covers too thinly: go deeper into the subject itself (for a safari article: kinds of safari, the seasons for wildlife, how the camps differ, '
				. 'the local guides and communities, what a day is like, what it costs in broad terms, at most once and fairly). Never a gap whose point is a warning or a downside. '
				. 'Do not list visa, entry, currency, vaccinations or general getting there and around: they belong on the place page'
				. ( ! empty( $ctx['place'] ) ? ' (' . $ctx['place'][0] . '), and one gap may be a single line linking to it' : '' ) . '. ' . $end;
		}
		return 'the 3 to 6 most important things ' . LMGT_Subject::w( 'reader' ) . ' expects from an article on this topic that ORIGINAL lacks or covers too thinly '
			. '(for example ' . LMGT_Subject::w( 'gaps' ) . '). ' . $end;
	}

	/**
	 * Draft sections for the gaps, in the house voice. Facts the engine cannot
	 * know are marked [CHECK: …] so nothing invented reaches a reader.
	 */
	public static function prompt_gap_sections( $from, $title, $text, array $gaps, array $headings = array(), array $providers = array(), array $links = array() ) {
		$a    = LMGT_Langs::get( $from );
		$list = '';
		foreach ( $gaps as $n => $g ) $list .= $n . '. ' . $g['topic'] . ( ! empty( $g['add'] ) ? ': ' . $g['add'] : '' ) . "\n";
		if ( $providers ) {
			$names = array();
			foreach ( $providers as $pv ) $names[] = $pv['name'] . ( ! empty( $pv['what'] ) ? ' (' . $pv['what'] . ')' : '' ) . ( isset( $pv['kind'] ) && $pv['kind'] === 'abroad' ? ' [abroad]' : '' ) . ( ! empty( $pv['web'] ) && ! empty( $pv['live'] ) ? ' [web: ' . $pv['web'] . ']' : '' );
			$list .= count( $gaps ) . '. Who takes you there: one section naming exactly these providers, checked by the editor, and no others: ' . implode( '; ', $names ) . '. Local ones first, those [abroad] after. Say what each does in a sentence; never rank, grade or recommend one over another; no prices or contact details. Where a provider has [web: …], link its name once to exactly that address as <a href=\"…\">name</a>.' . "\n";
		}
		$r = "You write for " . LMGT_Subject::w( 'house' ) . ". ARTICLE is a {$a['name']} " . LMGT_Subject::w( 'kind' ) . " article titled \"{$title}\". Write one new section for each GAP, in {$a['name']}, to be added to ARTICLE.\n"
			. "House rules:\n"
			. "- " . LMGT_Subject::w( 'lead' ) . " Tell the reader what they do not already know; when something is inconvenient, say it once, fairly, with the upside.\n"
			. "- Accuracy is the product. Never invent a fact. Write only what you are certain of. Leave out any price, time, distance, date, opening hour, statistic, rule or business name you are not sure of; practical guidance in general terms is fine. Never write placeholders or notes to the editor.\n"
			. "- 120 to 300 words per section. Short paragraphs. Plain, signposting heading. No exclamation marks.\n"
			. "- Never: " . LMGT_Subject::w( 'never' ) . ", phrases like delve, landscape, journey, navigate, it is important to note, in conclusion, arguably, in many ways. No paragraph that only announces the next one. Never mention the article's own structure.\n"
			. "- Do not repeat what ARTICLE already says. Match its tone.\n";
		if ( $from === 'en' ) $r .= "- British spelling.\n";
		if ( $from === 'da' ) $r .= "- Idiomatic Danish, not translated-sounding Danish.\n";
		return $r . "- \"after\" is copied exactly from HEADINGS: the heading whose section the new one belongs after, so it lands where a reader looks for it. " . LMGT_Subject::w( 'order' ) . " \"\" only when no heading fits.\n"
			. ( $links ? "- 2.7.1: link to the site's own articles where they fit naturally: one to three links per section, only to addresses in LINKS, as <a href=\"…\">words from the sentence</a>. Never invent an address.\n" : '' )
			. "Return JSON: {\"sections\":[{\"gap\":N,\"after\":\"…\",\"heading\":\"…\",\"html\":\"<p>…</p><p>…</p>\"}]}. html uses only <p>, <ul>, <li>, <strong>, <em>" . ( $links ? ", <a href>" : '' ) . ".\n\n"
			. ( $links ? "LINKS:\n" . implode( "\n", array_map( function ( $t, $u ) { return $t . ' | ' . $u; }, array_keys( $links ), $links ) ) . "\n\n" : '' )
			. self::voice() . "\n"
			. "GAPS:\n{$list}\nHEADINGS:\n" . implode( "\n", $headings ) . "\n\nARTICLE:\n{$text}";
	}

	/**
	 * Search basics for a translation, from one call so they agree: the search
	 * term a reader in that language types, a meta description that carries it
	 * naturally, and a short address built around it.
	 */
	public static function prompt_seo( $to, $title, $intro, $guide = false, $fixed = '' ) {
		$b = LMGT_Langs::get( $to );
		// Destination guides rank on the place's name alone (G, 26 Oct: the
		// English Austria page reached Rank Math 92 with keyword "Austria").
		$kw = $guide
			? "- keyword: this is a destination guide (a country, region or city page). The keyword is the destination's name alone, as {$b['name']} speakers write it (Austria: Österreich in German, Autriche in French), with nothing added.\n"
			: "- keyword: the main search term (1 to 4 words) a {$b['name']}-speaking reader would type to find it.\n";
		// 2.7.3: when the page already has a focus keyword, it stays, and the meta must carry it exactly (Rank Math: "Focus Keyword not found in your SEO Meta Description").
		if ( $fixed !== '' ) $kw = "- keyword: exactly \"{$fixed}\" (already chosen; return it unchanged). The meta must contain these exact words.\n";
		return "For this {$b['name']} " . LMGT_Subject::w( 'kind' ) . " article give:\n"
			. $kw
			. "- meta: a meta description in {$b['name']}, 140 to 160 characters, containing keyword naturally, stating " . LMGT_Subject::w( 'worth' ) . ", not just the topic. No exclamation marks.\n"
			. "- slug: URL slug in {$b['name']}, 3 to 6 words, lowercase, hyphens, no stop words, no numbers or years, built around keyword.\n"
			. "Return JSON: {\"keyword\":\"…\",\"meta\":\"…\",\"slug\":\"…\"}.\n\nTITLE: {$title}\nINTRO: {$intro}";
	}

	/**
	 * 2.22.3 (G, 28 Nov 2026): the voice for every step that writes, expands or corrects text. The Schweiz page
	 * came back saying five or six times how expensive Switzerland is: that knocks the destination and the
	 * tourist office we want to work with. We are in the selling business; we just do not accept mediocre writing.
	 */
	public static function voice() {
		return "VOICE (overrides anything above that pulls the other way):\n"
			. "- We write to make people want to go, and we work with the places and their tourist offices. Be positive and fair. Never talk a place down.\n"
			. "- A downside (price, weather, crowds, distance) is said once in the whole text, honestly, with the upside or a practical tip beside it, where it belongs. The level to match (Danish): \"Schweiz er et af de dyrere rejsemål i Europa. … det kan betale sig at handle i supermarkeder og indrette sig med en picnic ind imellem. Eller også er det bare merprisen værd.\" Or: \"Du vil finde Schweiz noget dyrere end gennemsnittet i Europa, men rejseoplevelsen matcher prisen.\"\n"
			. "- Never repeat a warning ARTICLE already gives, never add a warning or downside ARTICLE does not have, and never make a warning the point of a section. A section on what things cost is fine when it is practical (tips, where it pays to save) and ends fairly, like the example.\n"
			. "- The human text is the base: build on it. Never strip, flatten or rewrite what is good in it. Wordplay, alliteration and a line with a twist stay.\n";
	}

	/** Content gaps of one article, without translating it. */
	public static function prompt_gaps( $from, $title, $text, array $ctx = array() ) {
		$a = LMGT_Langs::get( $from );
		// 2.19.0: the site's subject (a sport or wine site is not asked about travel), and the Top 10 goal.
		$subj = class_exists( 'LMGT_Boxes' ) ? LMGT_Boxes::subject() : 'travel';
		$r = "ORIGINAL is a {$a['name']} {$subj} article titled \"{$title}\".\n" . self::context_line( $ctx ) . "List gaps: " . self::gaps_rule( $ctx );
		if ( ! empty( $ctx['top10'] ) ) $r .= "\nGoal: rank in Google's top 10 for \"{$ctx['top10']}\". Judge the gaps against what the pages that rank best for that search typically cover (as you know such pages): list the topics and questions they answer that ORIGINAL lacks or covers too thinly. Never copy them; only name what is missing.";
		$json = "{\"gaps\":[{\"topic\":\"…\",\"add\":\"…\"}]";
		if ( self::is_spoke( $ctx ) && $subj === 'travel' ) {
			$r   .= "\nAlso list providers who take a traveller there, in four kinds: local (companies, camps, lodges or guides in the place that do what the article describes), airline (airlines that fly there), agency (travel agencies that sell trips there" . ( $from === 'da' ? ', preferably Nordic ones' : '' ) . "), transport (domestic flights, trains, ferries or car hire on the spot). At most four of each kind. Only names you are certain exist and operate now; an empty list is better than a guess. Never rank or grade them. name: the business name; kind: local, airline, agency or transport; what: a few words on what they do and where; web: its own website address (home page), empty if you are not sure.";
			$json .= ",\"providers\":[{\"name\":\"…\",\"kind\":\"local|airline|agency|transport\",\"what\":\"…\",\"web\":\"https://…\"}]";
		}
		return $r . "\n" . self::voice() . "Return JSON: {$json}}. Write in {$a['name']}.\n\nORIGINAL:\n{$text}";
	}

	/**
	 * 2.4.2: what kind of text this is, for the gap rules. kind: hub (country or
	 * destination page, pillar) or spoke (an article on a place or interest);
	 * cats: category names; place: [name, url] of the place page above it.
	 */
	public static function gap_context( $id ) {
		$id  = (int) $id;
		$src = get_post_type( $id ) === LMGT_CPT ? (int) get_post_meta( $id, '_lmgt_source', true ) : $id;
		if ( ! $src ) $src = $id;
		$cats = array();
		foreach ( (array) get_the_category( $src ) as $c ) {
			if ( $c && (int) $c->term_id !== (int) get_option( 'default_category' ) ) $cats[] = html_entity_decode( $c->name, ENT_QUOTES, 'UTF-8' );
		}
		$place = null;
		if ( class_exists( 'LMGT_Structure' ) ) {
			$cl    = LMGT_Structure::cluster( $src );
			$place = $cl['place'] ? $cl['place'] : $cl['region'];
		}
		return array(
			'kind'  => LMGT_Store::is_pillar( $src ) ? 'hub' : 'spoke',
			'cats'  => $cats,
			'place' => $place,
		);
	}

	public static function is_spoke( array $ctx ) {
		return isset( $ctx['kind'] ) && $ctx['kind'] === 'spoke';
	}

	private static function context_line( array $ctx ) {
		if ( ! $ctx ) return '';
		$l = self::is_spoke( $ctx ) ? 'It is an article on one subject, not a country or destination page.' : 'It is a country or destination page (a hub).';
		if ( ! empty( $ctx['cats'] ) ) $l .= ' Filed under: ' . implode( ', ', $ctx['cats'] ) . '.';
		if ( self::is_spoke( $ctx ) && ! empty( $ctx['place'] ) ) $l .= ' The site has a page for ' . $ctx['place'][0] . ' (' . $ctx['place'][1] . ') that carries the practical basics.';
		return $l . "\n";
	}

	/**
	 * 2.4.2 (G, 7 Nov): the other way round, as a list only. What ENGLISH covers
	 * that the Danish ORIGINAL lacks, for a person to write in Danish. Nothing is
	 * translated into Danish (house style: no machine translation into Danish).
	 */
	public static function prompt_en_extra( $orig_title, $orig_text, $en_title, $en_text ) {
		return "ORIGINAL is a Danish travel article from traveltalk.dk. ENGLISH is its English version on traveltalk.travel, which may have been extended since.\n"
			. "List each part of ENGLISH whose content ORIGINAL lacks or covers clearly more thinly. Ignore wording, order and anything ORIGINAL already says.\n"
			. "heading: the English heading of that part, or a short name when it has none. what: two sentences in Danish on what it says. facts: the numbers, prices, dates and names in it, copied exactly. Empty list when ORIGINAL covers it all.\n"
			. "Return JSON: {\"parts\":[{\"heading\":\"…\",\"what\":\"…\",\"facts\":\"…\"}]}.\n\n"
			. "ORIGINAL_TITLE: {$orig_title}\nORIGINAL:\n{$orig_text}\n\nENGLISH_TITLE: {$en_title}\nENGLISH:\n{$en_text}";
	}

	/** Improve and keep (2.1.5): what the Danish original adds to an existing English page. */
	public static function schema_improve() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'sections' => self::schema_list( array( 'after', 'heading', 'html' ) ),
				'replace'  => self::schema_list( array( 'find', 'replace', 'why' ) ),
			),
			'required'             => array( 'sections', 'replace' ),
			'additionalProperties' => false,
		);
	}

	public static function prompt_improve( $orig_title, $orig_text, $en_title, $en_text, array $en_headings ) {
		return "You edit traveltalk.travel, an English travel site for international readers. ENGLISH is one of its pages, written for the site and kept as it is. ORIGINAL is the Danish page on the same subject from traveltalk.dk, the Danish sister site. Headings are marked with #.\n"
			. "1. sections: everything ORIGINAL covers that ENGLISH lacks or covers clearly more thinly, as new sections in English to add to ENGLISH. Translate what ORIGINAL says faithfully: keep every number, price, date and name exactly, with its currency; never convert, round or invent. Leave out what only matters to readers travelling from Denmark (Danish airports, Danish holidays, prices only in Danish kroner), and phrases such as \"Danes\" or \"for Danish travellers\": write for international readers. Do not repeat what ENGLISH already says. 120 to 400 words per section, short paragraphs, a plain signposting heading, British spelling, no exclamation marks. html uses only <p>, <ul>, <li>, <strong>, <em>. after: copied exactly from HEADINGS, the heading the new section belongs under, so it lands where a reader looks for it. Practical information (when to go, getting there, getting around, where to stay) belongs in the practical part at the end; everything else in the middle, never after a practical heading. \"\" only when no heading fits.\n"
			. "2. replace: only sentences in ENGLISH that speak to Danish readers, or that ORIGINAL shows to be wrong. find: an exact, unique substring of ENGLISH, at most one sentence. replace: the corrected sentence. why: a few words. Leave everything else in ENGLISH exactly as written: it is the author's text.\n"
			. "Empty lists are a good answer when ENGLISH already covers ORIGINAL.\n"
			. "Return JSON: {\"sections\":[{\"after\":\"…\",\"heading\":\"…\",\"html\":\"<p>…</p>\"}],\"replace\":[{\"find\":\"…\",\"replace\":\"…\",\"why\":\"…\"}]}.\n\n"
			. self::voice() . "\n"
			. "HEADINGS:\n" . implode( "\n", $en_headings ) . "\n\nENGLISH_TITLE: {$en_title}\nENGLISH:\n{$en_text}\n\nORIGINAL_TITLE: {$orig_title}\nORIGINAL:\n{$orig_text}";
	}

	/** Compare original with back-translation; also judge the translation's own language. */
	public static function prompt_compare( $from, $to, $orig_title, $orig_text, $back_title, $back_text, $tr_title, $tr_sample, array $ctx = array() ) {
		$a = LMGT_Langs::get( $from );
		$b = LMGT_Langs::get( $to );
		return "ORIGINAL is a {$a['name']} travel article. BACK is a back-translation into {$a['name']} of its {$b['name']} translation.\n"
			. "1. List every place where BACK says something different from ORIGINAL: a changed fact, number, date, name, place, negation, an omission or an addition. Ignore differences in wording or style that keep the meaning.\n"
			. "2. List clear errors in ORIGINAL itself that the comparison exposes: a wrong or inconsistent fact, a sentence whose meaning is ambiguous, a typo. Only clear cases. text is the exact wrong passage; suggestion is only the corrected replacement text, never a comment. Leave out anything that needs no change.\n"
			. "3. State the language of TRANSLATED_TITLE and of TRANSLATED_SAMPLE as ISO 639-1 codes (Norwegian Bokmål = nb).\n"
			. "Return JSON: {\"issues\":[{\"type\":\"meaning|number|name|missing|added\",\"original\":\"…\",\"back\":\"…\",\"note\":\"…\"}],"
			. "\"original_suggestions\":[{\"text\":\"…\",\"suggestion\":\"…\",\"why\":\"…\"}],\"title_lang\":\"xx\",\"body_lang\":\"xx\","
			. "\"gaps\":[{\"topic\":\"…\",\"add\":\"…\"}]}. Write notes in {$a['name']}.\n"
			. "4. gaps: " . self::context_line( $ctx ) . self::gaps_rule( $ctx ) . "\n\n"
			. "ORIGINAL_TITLE: {$orig_title}\nORIGINAL:\n{$orig_text}\n\nBACK_TITLE: {$back_title}\nBACK:\n{$back_text}\n\n"
			. "TRANSLATED_TITLE: {$tr_title}\nTRANSLATED_SAMPLE:\n{$tr_sample}";
	}
}
