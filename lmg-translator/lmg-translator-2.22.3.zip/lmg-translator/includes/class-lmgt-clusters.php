<?php
/**
 * 2.5.0 (G, 7 Nov 2026): Translator → Clusters, on the site that writes the
 * originals (traveltalk.dk). One country page at a time, Botswana first.
 *
 *   1. Inventory: every article that belongs to the country page (its category
 *      by the page's own slug, and articles whose title names the country),
 *      whether it links up to the page and whether the page links down to it,
 *      as a reader sees the pages. Problems that only show across the set are
 *      reported, never fixed: an article that competes with the page for the
 *      same title, a country category without a parent.
 *   2. Down-links: for a country page the person switches on, the articles the
 *      page does not already link to are listed at the end of it ("Mere om …").
 *      Nothing is written into any text; switching off removes the list.
 *   3. Suggestions: new articles the cluster lacks, and site interests with no
 *      article for this country. A list for a person; nothing is drafted here.
 *
 * Options: lmgt_cluster_on [page ids], lmgt_cluster_sugg [page id => [at, items]].
 * Transients: lmgt_cl_html_<md5 url> (rendered page, 12 hours).
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class LMGT_Clusters {

	public static function boot() {
		if ( LMGT_Bridge::on() && ! LMGT_Bridge::is_source() ) return;
		add_action( 'admin_menu', function () {
			add_submenu_page( 'lmgt', 'Clusters', 'Clusters', 'edit_others_posts', 'lmgt-clusters', array( __CLASS__, 'page' ) );
		}, 28 );
		add_action( 'admin_post_lmgt_cluster_toggle', array( __CLASS__, 'handle_toggle' ) );
		add_action( 'admin_post_lmgt_cluster_suggest', array( __CLASS__, 'handle_suggest' ) );
		add_action( 'admin_post_lmgt_cluster_refresh', array( __CLASS__, 'handle_refresh' ) );
		add_filter( 'the_content', array( __CLASS__, 'downlinks' ), 30 );
		add_action( 'admin_post_lmgt_pagewins', array( __CLASS__, 'handle_pagewins' ) );
		add_filter( 'request', array( __CLASS__, 'page_wins' ), PHP_INT_MAX ); // 2.6.1: last, after permalink plugins
		add_filter( 'the_content', array( __CLASS__, 'page_posts' ), 31 );
		add_action( 'send_headers', array( __CLASS__, 'why_header' ) );
	}

	// ---- 2.6.0: interests, and the page wins a shared address -------------------------
	//
	// G, 8 Nov 2026: pages are the hubs for destinations and interests; categories only file
	// posts. On traveltalk.dk 28 interest pages share their address with a category, and the
	// category is what readers get, so the page's text is never seen. With "Pages win" on,
	// such an address shows the page, with the category's newest articles under it. No
	// address changes. Interests out on mission grounds (house style 3B) are never promoted.

	const SKIP = array( 'charterferie', 'busrejser', 'erhvervsrejser' );

	private static function pagewins_on() {
		return get_option( 'lmgt_pagewins', '0' ) === '1';
	}

	/** The page at a request path, when a category also answers to it. */
	private static function shared_page( $path ) {
		$path = trim( (string) $path, '/' );
		if ( $path === '' || preg_match( '#/page/\d+$#', $path ) ) return null;
		$leaf = basename( $path );
		if ( in_array( $leaf, self::SKIP, true ) ) return null;
		$page = get_page_by_path( $path, OBJECT, 'page' );
		if ( ! $page || $page->post_status !== 'publish' ) return null;
		$cat = get_category_by_slug( $leaf );
		return $cat && ! is_wp_error( $cat ) ? array( $page, $cat ) : null;
	}

	public static function page_wins( $vars ) {
		if ( is_admin() || ! self::pagewins_on() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) return $vars;
		$path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) : '';
		$home = trim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
		$path = trim( $path, '/' );
		if ( $home !== '' && strpos( $path, $home . '/' ) === 0 ) $path = substr( $path, strlen( $home ) + 1 );
		// 2.6.1: decide on the address, not on which query vars a permalink plugin happened to set.
		// 2.6.0 waited for category_name, which traveltalk.dk's rewrite does not use, so nothing changed.
		if ( ! empty( $vars['paged'] ) || ! empty( $vars['feed'] ) ) { self::$why = 'paged-or-feed'; return $vars; }
		$hit = self::shared_page( $path );
		if ( ! $hit ) { self::$why = 'no-shared-page'; return $vars; }
		self::$why = 'page';
		return array( 'pagename' => $path );
	}

	/** 2.6.1: what Pages win decided for this address, sent as a header so it can be checked from outside. */
	private static $why = '';

	public static function why_header() {
		if ( self::$why !== '' && ! headers_sent() ) header( 'X-LMGT-Pagewins: ' . self::$why );
	}

	/** Under a page that won its address: the category's newest articles, and the way to the rest. */
	public static function page_posts( $content ) {
		if ( ! self::pagewins_on() || ! is_page() || ! in_the_loop() || ! is_main_query() ) return $content;
		$hit = self::shared_page( wp_parse_url( get_permalink(), PHP_URL_PATH ) );
		if ( ! $hit ) return $content;
		list( $page, $cat ) = $hit;
		$ids = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'cat' => $cat->term_id, 'posts_per_page' => 24, 'fields' => 'ids' ) );
		if ( ! $ids ) return $content;
		$li = '';
		foreach ( $ids as $id ) {
			if ( strpos( $content, untrailingslashit( (string) wp_parse_url( get_permalink( $id ), PHP_URL_PATH ) ) ) !== false ) continue;
			$li .= '<li><a href="' . esc_url( get_permalink( $id ) ) . '">' . esc_html( get_the_title( $id ) ) . '</a></li>';
		}
		if ( $li === '' ) return $content;
		$more = $cat->count > 24 ? '<p><a href="' . esc_url( trailingslashit( get_permalink( $page ) ) . 'page/2/' ) . '">' . esc_html( sprintf( 'Alle %d artikler om %s', $cat->count, $page->post_title ) ) . '</a></p>' : '';
		return $content . '<div class="lmgt-cluster"><h2>' . esc_html( sprintf( 'Artikler om %s', mb_strtolower( $page->post_title ) ) ) . '</h2><ul>' . $li . '</ul>' . $more . '</div>';
	}

	public static function handle_pagewins() {
		check_admin_referer( 'lmgt_pagewins' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Not allowed.' );
		update_option( 'lmgt_pagewins', self::pagewins_on() ? '0' : '1', false );
		do_action( 'litespeed_purge_all' );
		self::back( admin_url( 'admin.php?page=lmgt-clusters&view=interests' ), self::pagewins_on() ? 'Pages win: on. Shared addresses now show the page.' : 'Pages win: off. Shared addresses show the category again.' );
	}

	/** The interests report: every interest page and category, side by side. */
	private static function interests_view() {
		$pcat = (int) get_option( 'lmgt_rm_interests_cat', 0 );
		$root = $pcat ? get_term( $pcat, 'category' ) : null;
		$rootp = $root && ! is_wp_error( $root ) ? get_page_by_path( $root->slug, OBJECT, 'page' ) : null;
		if ( ! $root || is_wp_error( $root ) ) {
			echo '<p>Set the Travel Interests category under Translator → Settings → Read more block first.</p>';
			return;
		}
		$pages = $rootp ? get_pages( array( 'parent' => $rootp->ID, 'post_status' => 'publish' ) ) : array();
		$cats  = get_terms( array( 'taxonomy' => 'category', 'parent' => $pcat, 'hide_empty' => false ) );
		$rows  = array();
		foreach ( $pages as $p ) $rows[ $p->post_name ]['page'] = $p;
		foreach ( (array) $cats as $c ) $rows[ $c->slug ]['cat'] = $c;
		ksort( $rows );
		$on = self::pagewins_on();
		$t  = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_pagewins' ), 'lmgt_pagewins' );
		echo '<h2>Travel interests</h2><p>Pages are the hubs; categories file the posts (G, 8 Nov 2026). Pages win shared addresses: <span style="display:inline-block;padding:2px 10px;border-radius:10px;font-weight:600;color:#fff;background:' . ( $on ? '#00a32a' : '#8c8f94' ) . '">' . ( $on ? 'ON' : 'OFF' ) . '</span> <a class="button" href="' . esc_url( $t ) . '">' . ( $on ? 'Turn off' : 'Turn on' ) . '</a></p>';
		echo '<p class="description">On: where a page and a category share an address, readers see the page with the category\'s newest articles under it. No address changes. Charter, bus and business travel are never promoted.</p>';
		echo '<table class="widefat striped"><thead><tr><th>Interest</th><th>Page</th><th>Words</th><th>Category</th><th>Posts</th><th>State</th></tr></thead><tbody>';
		foreach ( $rows as $slug => $r ) {
			$p = isset( $r['page'] ) ? $r['page'] : null;
			$c = isset( $r['cat'] ) ? $r['cat'] : null;
			$w = $p ? LMGT_Store::words( $p ) : 0;
			if ( in_array( $slug, self::SKIP, true ) ) $state = '<span class="description">out on mission grounds</span>';
			elseif ( $p && $c ) $state = $on ? '<span style="color:#008a20">page shown</span>' : '<strong style="color:#b32d2e">page hidden by the category</strong>';
			elseif ( $p ) $state = 'page only – check for a category with another address';
			else $state = '<strong style="color:#b32d2e">no page – category text only</strong>';
			if ( $p && $w < LMGT_Store::min_words( $p->ID ) && ! in_array( $slug, self::SKIP, true ) ) $state .= ' · <span style="color:#b32d2e">thin</span>';
			echo '<tr><td>' . esc_html( $p ? $p->post_title : $c->name ) . '</td><td>' . ( $p ? '<a href="' . esc_url( get_edit_post_link( $p->ID ) ) . '">' . (int) $p->ID . '</a>' : '–' ) . '</td><td>' . ( $p ? (int) $w : '–' ) . '</td><td>' . ( $c ? '<a href="' . esc_url( get_term_link( $c ) ) . '" target="_blank">' . esc_html( $c->slug ) . '</a>' : '–' ) . '</td><td>' . ( $c ? (int) $c->count : '–' ) . '</td><td>' . $state . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	// ---- Which pages are country pages --------------------------------------

	/** A published page whose slug is also a category's slug: the rule the site's own country grids use. */
	public static function hubs() {
		$out = array();
		foreach ( get_terms( array( 'taxonomy' => 'category', 'hide_empty' => true, 'number' => 500 ) ) as $c ) {
			$p = get_posts( array( 'post_type' => 'page', 'name' => $c->slug, 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids', 'lmgt_all' => true ) );
			if ( $p ) $out[ (int) $p[0] ] = $c;
		}
		uasort( $out, function ( $a, $b ) { return strcoll( $a->name, $b->name ); } );
		return $out;
	}

	private static function cat_of( $hub ) {
		$slug = get_post_field( 'post_name', $hub );
		$c    = get_category_by_slug( $slug );
		return $c && ! is_wp_error( $c ) ? $c : null;
	}

	/** Articles that belong to a country page: its category and sub-categories, and posts whose title names it. */
	public static function spokes( $hub ) {
		$cat  = self::cat_of( $hub );
		$ids  = $cat ? get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'cat' => $cat->term_id, 'posts_per_page' => 200, 'fields' => 'ids', 'lmgt_all' => true ) ) : array();
		$name = html_entity_decode( get_the_title( $hub ), ENT_QUOTES, 'UTF-8' );
		foreach ( get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 's' => $name, 'posts_per_page' => 100, 'fields' => 'ids', 'lmgt_all' => true ) ) as $id ) {
			if ( mb_stripos( get_the_title( $id ), $name ) !== false ) $ids[] = $id;
		}
		return array_values( array_unique( array_map( 'intval', $ids ) ) );
	}

	// ---- What a reader sees ---------------------------------------------------

	/** The page as served, cached 12 hours. '' when the site could not fetch itself. */
	private static function html( $url, $fresh = false ) {
		$key = 'lmgt_cl_html_' . md5( $url );
		if ( ! $fresh ) {
			$h = get_transient( $key );
			if ( $h !== false ) return $h;
		}
		$r = wp_remote_get( add_query_arg( 'lmgt_cl', time(), $url ), array( 'timeout' => 20, 'redirection' => 2 ) );
		$h = is_wp_error( $r ) || (int) wp_remote_retrieve_response_code( $r ) !== 200 ? '' : (string) wp_remote_retrieve_body( $r );
		set_transient( $key, $h, 12 * HOUR_IN_SECONDS );
		return $h;
	}

	private static function links_to( $html, $url ) {
		$path = wp_parse_url( $url, PHP_URL_PATH );
		return $path && $html !== '' && preg_match( '#href=["\'](?:https?://[^/"\']+)?' . preg_quote( untrailingslashit( $path ), '#' ) . '/?(?:[?\#][^"\']*)?["\']#i', $html );
	}

	/** [rows, problems, unknown] for one country page. */
	public static function inventory( $hub, $fresh = false ) {
		$hub_url  = get_permalink( $hub );
		$hub_html = self::html( $hub_url, $fresh );
		$name     = html_entity_decode( get_the_title( $hub ), ENT_QUOTES, 'UTF-8' );
		$rows     = array();
		$problems = array();
		foreach ( self::spokes( $hub ) as $id ) {
			$url  = get_permalink( $id );
			$html = self::html( $url, $fresh );
			$t    = html_entity_decode( get_the_title( $id ), ENT_QUOTES, 'UTF-8' );
			$rows[] = array(
				'id'    => $id,
				'title' => $t,
				'url'   => $url,
				'up'    => $html === '' ? null : (bool) self::links_to( $html, $hub_url ),
				'down'  => $hub_html === '' ? null : (bool) self::links_to( $hub_html, $url ),
			);
			if ( mb_strtolower( trim( $t ) ) === mb_strtolower( trim( $name ) ) ) {
				$problems[] = 'The article <a href="' . esc_url( $url ) . '" target="_blank">' . esc_html( $t ) . '</a> has the same title as the country page. Two texts compete for "' . esc_html( $name ) . '": decide which one keeps the subject.';
			}
		}
		$cat = self::cat_of( $hub );
		if ( $cat && ! $cat->parent ) {
			$problems[] = 'The category <a href="' . esc_url( get_term_link( $cat ) ) . '" target="_blank">' . esc_html( $cat->name ) . '</a> has no parent category, so it does not sit under its continent.';
		}
		if ( ! $cat ) $problems[] = 'No category with the same address as the page, so the site\'s own article grid finds nothing for it.';
		return array( $rows, $problems, $hub_html === '' );
	}

	// ---- Down-links on the page itself -----------------------------------------

	private static function on() {
		return array_map( 'intval', (array) get_option( 'lmgt_cluster_on', array() ) );
	}

	/** On a switched-on country page: the articles it does not already link to, at the end. */
	public static function downlinks( $content ) {
		if ( is_admin() || ! is_page() || ! in_the_loop() || ! is_main_query() ) return $content;
		$hub = get_the_ID();
		if ( ! in_array( (int) $hub, self::on(), true ) ) return $content;
		$cat    = self::cat_of( $hub );
		$shown  = $cat ? get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'cat' => $cat->term_id, 'posts_per_page' => 12, 'fields' => 'ids' ) ) : array(); // the site's own grid: 12 newest
		$name   = html_entity_decode( get_the_title( $hub ), ENT_QUOTES, 'UTF-8' );
		$li     = '';
		foreach ( self::spokes( $hub ) as $id ) {
			if ( in_array( $id, $shown, true ) ) continue;
			$url = get_permalink( $id );
			if ( strpos( $content, untrailingslashit( wp_parse_url( $url, PHP_URL_PATH ) ) ) !== false ) continue;
			if ( mb_strtolower( trim( get_the_title( $id ) ) ) === mb_strtolower( trim( $name ) ) ) continue; // a competing page is reported, not promoted
			$li .= '<li><a href="' . esc_url( $url ) . '">' . esc_html( get_the_title( $id ) ) . '</a></li>';
		}
		if ( $li === '' ) return $content;
		return $content . '<div class="lmgt-cluster"><h2>' . esc_html( sprintf( 'Mere om %s', $name ) ) . '</h2><ul>' . $li . '</ul></div>';
	}

	// ---- Suggestions ----------------------------------------------------------

	private static function interests() {
		$parent = (int) get_option( 'lmgt_rm_interests_cat', 0 );
		if ( ! $parent ) return array();
		$out = array();
		foreach ( get_terms( array( 'taxonomy' => 'category', 'parent' => $parent, 'hide_empty' => true, 'number' => 80 ) ) as $t ) $out[] = html_entity_decode( $t->name, ENT_QUOTES, 'UTF-8' );
		return $out;
	}

	public static function prompt( $name, $hub_text, array $titles, array $interests ) {
		return "You plan content for traveltalk.dk, a Danish travel magazine for Nordic readers. COUNTRY is the country page for {$name}; ARTICLES are the site's articles about {$name}; INTERESTS are the travel interests the site covers.\n"
			. "House rules: describe the place, not the trip; bounded subjects beat broad ones; never a top-10; never an article about buying cheap trips, charter or business travel.\n"
			. "1. new: 4 to 8 articles the cluster lacks, each a bounded subject a reader would search for and that COUNTRY cannot cover in depth. title: a Danish working title. angle: one sentence on what it tells. interest: the matching name from INTERESTS, or \"\".\n"
			. "2. unused: names from INTERESTS that fit {$name} well but have no article in ARTICLES, with one sentence on why they fit. Only real fits.\n"
			. "Do not suggest what ARTICLES already cover. Write in Danish.\n"
			. "Return JSON: {\"new\":[{\"title\":\"…\",\"angle\":\"…\",\"interest\":\"…\"}],\"unused\":[{\"interest\":\"…\",\"why\":\"…\"}]}.\n\n"
			. LMGT_Engines::voice() . "INTERESTS: " . implode( ', ', $interests ) . "\n\nARTICLES:\n- " . implode( "\n- ", $titles ) . "\n\nCOUNTRY:\n{$hub_text}";
	}

	public static function handle_suggest() {
		$hub = (int) $_GET['hub'];
		check_admin_referer( 'lmgt_cluster_suggest_' . $hub );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_die( 'Not allowed.' );
		$back = admin_url( 'admin.php?page=lmgt-clusters&hub=' . $hub );
		$titles = array();
		foreach ( self::spokes( $hub ) as $id ) $titles[] = html_entity_decode( get_the_title( $id ), ENT_QUOTES, 'UTF-8' );
		@set_time_limit( 200 );
		$r = LMGT_Engines::ai_json( self::prompt( html_entity_decode( get_the_title( $hub ), ENT_QUOTES, 'UTF-8' ), mb_substr( LMGT_Text::plain( get_post_field( 'post_content', $hub ) ), 0, 20000 ), $titles, self::interests() ) );
		if ( is_wp_error( $r ) ) self::back( $back, $r->get_error_message() );
		$clean = function ( $list, array $keys ) {
			$out = array();
			foreach ( (array) $list as $x ) {
				if ( ! is_array( $x ) ) continue;
				$row = array();
				foreach ( $keys as $k ) $row[ $k ] = isset( $x[ $k ] ) ? sanitize_text_field( $x[ $k ] ) : '';
				if ( $row[ $keys[0] ] !== '' ) $out[] = $row;
			}
			return $out;
		};
		$all         = (array) get_option( 'lmgt_cluster_sugg', array() );
		$all[ $hub ] = array(
			'at'     => current_time( 'mysql', true ),
			'new'    => $clean( isset( $r['new'] ) ? $r['new'] : array(), array( 'title', 'angle', 'interest' ) ),
			'unused' => $clean( isset( $r['unused'] ) ? $r['unused'] : array(), array( 'interest', 'why' ) ),
		);
		update_option( 'lmgt_cluster_sugg', $all, false );
		self::back( $back, 'Suggestions ready.' );
	}

	// ---- Actions and page -------------------------------------------------------

	public static function handle_toggle() {
		$hub = (int) $_GET['hub'];
		check_admin_referer( 'lmgt_cluster_toggle_' . $hub );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_die( 'Not allowed.' );
		$on = self::on();
		$on = in_array( $hub, $on, true ) ? array_values( array_diff( $on, array( $hub ) ) ) : array_merge( $on, array( $hub ) );
		update_option( 'lmgt_cluster_on', $on, false );
		do_action( 'litespeed_purge_post', $hub );
		delete_transient( 'lmgt_cl_html_' . md5( get_permalink( $hub ) ) );
		self::back( admin_url( 'admin.php?page=lmgt-clusters&hub=' . $hub ), in_array( $hub, $on, true ) ? 'Down-links switched on for this page.' : 'Down-links switched off for this page.' );
	}

	public static function handle_refresh() {
		$hub = (int) $_GET['hub'];
		check_admin_referer( 'lmgt_cluster_refresh_' . $hub );
		if ( ! current_user_can( 'edit_others_posts' ) ) wp_die( 'Not allowed.' );
		@set_time_limit( 200 );
		self::inventory( $hub, true );
		self::back( admin_url( 'admin.php?page=lmgt-clusters&hub=' . $hub ), 'Pages read again.' );
	}

	private static function back( $url, $msg ) {
		wp_safe_redirect( add_query_arg( 'lmgt_msg', rawurlencode( $msg ), $url ) );
		exit;
	}

	public static function page() {
		$hubs = self::hubs();
		$hub  = isset( $_GET['hub'] ) ? (int) $_GET['hub'] : 0;
		if ( ! $hub ) {
			foreach ( $hubs as $id => $c ) if ( $c->slug === 'botswana' ) $hub = $id;
		}
		echo '<div class="wrap"><h1>Clusters</h1>';
		if ( ! empty( $_GET['lmgt_msg'] ) ) echo '<div class="notice notice-info"><p>' . esc_html( wp_unslash( $_GET['lmgt_msg'] ) ) . '</p></div>';
		$view = isset( $_GET['view'] ) && $_GET['view'] === 'interests' ? 'interests' : 'countries';
		echo '<h2 class="nav-tab-wrapper"><a class="nav-tab' . ( $view === 'countries' ? ' nav-tab-active' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=lmgt-clusters' ) ) . '">Countries</a><a class="nav-tab' . ( $view === 'interests' ? ' nav-tab-active' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=lmgt-clusters&view=interests' ) ) . '">Travel interests</a></h2>';
		if ( $view === 'interests' ) { self::interests_view(); echo '</div>'; return; }
		echo '<p>One country page and the articles that belong to it: whether they link to each other as a reader sees the pages, what competes, and what is missing. Nothing in any text is changed here.</p>';
		echo '<form method="get"><input type="hidden" name="page" value="lmgt-clusters"><select name="hub">';
		foreach ( $hubs as $id => $c ) echo '<option value="' . (int) $id . '"' . selected( $hub, $id, false ) . '>' . esc_html( get_the_title( $id ) ) . '</option>';
		echo '</select> <button class="button">Show</button></form>';
		if ( ! $hub || ! get_post( $hub ) ) { echo '</div>'; return; }

		list( $rows, $problems, $unknown ) = self::inventory( $hub );
		$url = get_permalink( $hub );
		echo '<h2><a href="' . esc_url( $url ) . '" target="_blank">' . esc_html( get_the_title( $hub ) ) . '</a></h2>';
		if ( $unknown ) echo '<div class="notice notice-warning inline"><p>The site could not read its own page, so the links are shown as unknown. Try "Read the pages again".</p></div>';
		$up = 0; $down = 0;
		foreach ( $rows as $r ) { if ( $r['up'] ) $up++; if ( $r['down'] ) $down++; }
		echo '<p><strong>' . count( $rows ) . ' article(s).</strong> Link up to the country page: ' . $up . ' of ' . count( $rows ) . '. Linked from the country page: ' . $down . ' of ' . count( $rows ) . '.</p>';
		$yn = function ( $v ) { return $v === null ? '–' : ( $v ? '<span style="color:#008a20">yes</span>' : '<strong style="color:#b32d2e">no</strong>' ); };
		echo '<table class="widefat striped"><thead><tr><th>Article</th><th>Links up to the page</th><th>The page links to it</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			echo '<tr><td><a href="' . esc_url( $r['url'] ) . '" target="_blank">' . esc_html( $r['title'] ) . '</a> · <a href="' . esc_url( get_edit_post_link( $r['id'] ) ) . '">edit</a></td><td>' . $yn( $r['up'] ) . '</td><td>' . $yn( $r['down'] ) . '</td></tr>';
		}
		echo '</tbody></table>';

		echo '<h3>Problems in the set</h3>';
		echo $problems ? '<ul style="list-style:disc;margin-left:20px"><li>' . implode( '</li><li>', $problems ) . '</li></ul><p class="description">Reported only. Nothing is merged, moved, redirected or deleted.</p>' : '<p style="color:#008a20">None found.</p>';

		$is_on = in_array( $hub, self::on(), true );
		$t = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_cluster_toggle&hub=' . $hub ), 'lmgt_cluster_toggle_' . $hub );
		$f = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_cluster_refresh&hub=' . $hub ), 'lmgt_cluster_refresh_' . $hub );
		echo '<h3>Links from the country page</h3><p>' . ( $is_on ? '<strong>On.</strong> Articles the page does not already link to are listed at its end under "Mere om ' . esc_html( get_the_title( $hub ) ) . '".' : 'Off. Switch on to list the articles the page does not link to at its end. The text itself is not changed; switching off removes the list.' ) . '</p>';
		echo '<p><a class="button' . ( $is_on ? '' : ' button-primary' ) . '" href="' . esc_url( $t ) . '">' . ( $is_on ? 'Switch off' : 'Switch on for this page' ) . '</a> <a class="button" href="' . esc_url( $f ) . '">Read the pages again</a></p>';

		echo '<h3>Suggestions</h3>';
		$all = (array) get_option( 'lmgt_cluster_sugg', array() );
		$s   = isset( $all[ $hub ] ) ? $all[ $hub ] : null;
		if ( $s ) {
			echo '<p class="description">From ' . esc_html( $s['at'] ) . ' UTC. Ideas for a person to judge; nothing is written.</p>';
			if ( $s['new'] ) {
				echo '<p><strong>New articles the cluster lacks</strong></p><ul style="list-style:disc;margin-left:20px">';
				foreach ( $s['new'] as $x ) echo '<li><strong>' . esc_html( $x['title'] ) . '</strong> – ' . esc_html( $x['angle'] ) . ( $x['interest'] !== '' ? ' <span class="description">(' . esc_html( $x['interest'] ) . ')</span>' : '' ) . '</li>';
				echo '</ul>';
			}
			if ( $s['unused'] ) {
				echo '<p><strong>Interests with no article for this country</strong></p><ul style="list-style:disc;margin-left:20px">';
				foreach ( $s['unused'] as $x ) echo '<li><strong>' . esc_html( $x['interest'] ) . '</strong> – ' . esc_html( $x['why'] ) . '</li>';
				echo '</ul>';
			}
		}
		if ( LMGT_Engines::ai_available() ) {
			$g = wp_nonce_url( admin_url( 'admin-post.php?action=lmgt_cluster_suggest&hub=' . $hub ), 'lmgt_cluster_suggest_' . $hub );
			echo '<p><a class="button" href="' . esc_url( $g ) . '">' . ( $s ? 'Suggest again' : 'Suggest new articles' ) . '</a></p>';
		}
		echo '</div>';
	}
}
