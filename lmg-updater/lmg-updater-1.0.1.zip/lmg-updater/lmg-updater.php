<?php
/**
 * Plugin Name: LMG Updater
 * Description: Updates for Leisure Media Group's own plugins from one list. A new version shows under Dashboard → Updates like any other; you press Update. Tools → LMG Updates shows which version runs on which site.
 * Version:     1.0.1
 * Author:      Leisure Media Group Ltd
 *
 * Agreed with G, 14 Nov 2026: one list says what should run where; each site offers the update in its
 * own Dashboard → Updates; a person presses Update (nothing installs by itself – house rule: no
 * unattended writes to a live site); a status page shows done / waiting / issues across the sites.
 *
 * The list: manifest.json in the public repository info752/lmg-builds (builds only, no content).
 * Every zip carries a SHA-256 fingerprint in the list; a download that does not match is refused.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'LMGU_VERSION', '1.0.1' );
define( 'LMGU_MANIFEST', 'https://raw.githubusercontent.com/info752/lmg-builds/main/manifest.json' );

class LMGU {

	const CACHE = 'lmgu_manifest';

	public static function boot() {
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'offer' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'details' ), 20, 3 );
		add_filter( 'upgrader_pre_download', array( __CLASS__, 'download' ), 10, 4 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'done' ), 10, 2 );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'admin_menu', function () {
			add_management_page( 'LMG Updates', 'LMG Updates', 'update_plugins', 'lmg-updates', array( __CLASS__, 'page' ) );
		} );
		add_action( 'admin_post_lmgu_refresh', array( __CLASS__, 'refresh' ) );
	}

	private static function host( $url = '' ) {
		return preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( $url ? $url : home_url(), PHP_URL_HOST ) ) );
	}

	/** The list, kept 30 minutes. */
	public static function manifest( $fresh = false ) {
		$m = $fresh ? false : get_transient( self::CACHE );
		if ( is_array( $m ) ) return $m;
		$url = (string) get_option( 'lmgu_manifest', LMGU_MANIFEST );
		$r   = wp_remote_get( add_query_arg( 'v', time(), $url ), array( 'timeout' => 15 ) );
		if ( is_wp_error( $r ) || wp_remote_retrieve_response_code( $r ) !== 200 ) {
			update_option( 'lmgu_error', 'The list could not be read (' . ( is_wp_error( $r ) ? $r->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code( $r ) ) . ').', false );
			return array();
		}
		$m = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( ! is_array( $m ) || empty( $m['plugins'] ) ) { update_option( 'lmgu_error', 'The list is not readable.', false ); return array(); }
		delete_option( 'lmgu_error' );
		set_transient( self::CACHE, $m, 30 * MINUTE_IN_SECONDS );
		return $m;
	}

	/** Plugins in the list meant for this site: [plugin file => entry]. */
	private static function mine() {
		$m   = self::manifest();
		$me  = self::host();
		$out = array();
		foreach ( (array) ( isset( $m['plugins'] ) ? $m['plugins'] : array() ) as $file => $e ) {
			if ( empty( $e['version'] ) || empty( $e['zip'] ) || empty( $e['sha256'] ) ) continue;
			$sites = array_map( array( __CLASS__, 'host' ), array_map( function ( $s ) { return 'https://' . $s; }, (array) ( isset( $e['sites'] ) ? $e['sites'] : array() ) ) );
			if ( in_array( $me, $sites, true ) ) $out[ $file ] = $e;
		}
		return $out;
	}

	private static function installed() {
		if ( ! function_exists( 'get_plugins' ) ) require_once ABSPATH . 'wp-admin/includes/plugin.php';
		return get_plugins();
	}

	public static function offer( $t ) {
		if ( ! is_object( $t ) ) return $t;
		$have = self::installed();
		foreach ( self::mine() as $file => $e ) {
			if ( ! isset( $have[ $file ] ) || version_compare( $have[ $file ]['Version'], $e['version'], '>=' ) ) continue;
			$t->response[ $file ] = (object) array(
				'slug'        => dirname( $file ),
				'plugin'      => $file,
				'new_version' => $e['version'],
				'package'     => $e['zip'],
				'url'         => isset( $e['notes'] ) ? $e['notes'] : '',
				'lmgu'        => 1,
			);
		}
		return $t;
	}

	/** "View version details": the release notes from the list. */
	public static function details( $res, $action, $args ) {
		if ( $action !== 'plugin_information' || empty( $args->slug ) ) return $res;
		foreach ( self::mine() as $file => $e ) {
			if ( dirname( $file ) !== $args->slug ) continue;
			return (object) array(
				'name' => isset( $e['name'] ) ? $e['name'] : $args->slug, 'slug' => $args->slug, 'version' => $e['version'],
				'author' => 'Leisure Media Group Ltd', 'sections' => array( 'changelog' => wpautop( esc_html( isset( $e['summary'] ) ? $e['summary'] : 'See the release notes.' ) ) . ( ! empty( $e['notes'] ) ? '<p><a href="' . esc_url( $e['notes'] ) . '" target="_blank">Full release notes</a></p>' : '' ) ),
			);
		}
		return $res;
	}

	/** Download our zips ourselves and refuse any that do not match the fingerprint in the list. */
	public static function download( $reply, $package, $upgrader, $hook_extra = array() ) {
		$entry = null;
		foreach ( self::mine() as $e ) if ( $e['zip'] === $package ) $entry = $e;
		if ( ! $entry ) return $reply;
		if ( ! function_exists( 'download_url' ) ) require_once ABSPATH . 'wp-admin/includes/file.php';
		$tmp = download_url( $package, 120 );
		if ( is_wp_error( $tmp ) ) return $tmp;
		if ( ! hash_equals( strtolower( $entry['sha256'] ), hash_file( 'sha256', $tmp ) ) ) {
			@unlink( $tmp );
			update_option( 'lmgu_last', array( 'at' => current_time( 'mysql', true ), 'issue' => basename( $package ) . ': fingerprint does not match the list – not installed.' ), false );
			return new WP_Error( 'lmgu_hash', 'LMG Updater: this download does not match its fingerprint in the list, so it was not installed.' );
		}
		return $tmp;
	}

	public static function done( $upgrader, $extra ) {
		if ( empty( $extra['type'] ) || $extra['type'] !== 'plugin' ) return;
		// One plugin ("plugin") or several at once from Dashboard → Updates ("plugins").
		$files = ! empty( $extra['plugins'] ) ? (array) $extra['plugins'] : ( ! empty( $extra['plugin'] ) ? array( $extra['plugin'] ) : array() );
		if ( ! $files ) return;
		wp_clean_plugins_cache( false );
		$have = self::installed();
		$log  = (array) get_option( 'lmgu_log', array() );
		$last = get_option( 'lmgu_last' );
		foreach ( $files as $f ) {
			// Only an update that really brought the version in the list clears an earlier problem with it.
			$want = self::mine();
			$ok   = isset( $have[ $f ], $want[ $f ] ) && version_compare( $have[ $f ]['Version'], $want[ $f ]['version'], '>=' );
			if ( $ok && is_array( $last ) && ! empty( $last['issue'] ) && strpos( $last['issue'], dirname( $f ) ) === 0 ) delete_option( 'lmgu_last' );
			if ( ! $ok && isset( $want[ $f ] ) ) update_option( 'lmgu_last', array( 'at' => current_time( 'mysql', true ), 'issue' => dirname( $f ) . ': update to ' . $want[ $f ]['version'] . ' did not complete (still ' . ( isset( $have[ $f ] ) ? $have[ $f ]['Version'] : '?' ) . ').' ), false );
			$log[] = array( 'at' => current_time( 'mysql', true ), 'plugin' => $f, 'version' => isset( $have[ $f ] ) ? $have[ $f ]['Version'] : '?', 'active' => is_plugin_active( $f ) );
		}
		update_option( 'lmgu_log', array_slice( $log, -30 ), false );
	}

	/** Public, read-only: which of the listed plugins run here, in which version. No other data. */
	public static function routes() {
		register_rest_route( 'lmg-updater/v1', '/status', array( 'methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => function () {
			$have = LMGU::installed_public();
			// 1.0.1: never cached (LiteSpeed kept an empty answer on traveltalk.dk).
			if ( ! headers_sent() ) { nocache_headers(); header( 'X-LiteSpeed-Cache-Control: no-cache' ); }
			return array( 'site' => preg_replace( '/^www\./', '', wp_parse_url( home_url(), PHP_URL_HOST ) ), 'updater' => LMGU_VERSION, 'plugins' => $have, 'issue' => get_option( 'lmgu_last', null ), 'list_error' => get_option( 'lmgu_error', '' ), 'at' => current_time( 'mysql', true ) );
		} ) );
	}

	public static function installed_public() {
		if ( ! function_exists( 'is_plugin_active' ) ) require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$m    = self::manifest();
		$have = self::installed();
		$out  = array();
		foreach ( array_keys( (array) ( isset( $m['plugins'] ) ? $m['plugins'] : array() ) ) as $f ) {
			$out[ $f ] = isset( $have[ $f ] ) ? array( 'version' => $have[ $f ]['Version'], 'active' => is_plugin_active( $f ) ) : null;
		}
		return $out;
	}

	public static function refresh() {
		check_admin_referer( 'lmgu_refresh' );
		if ( ! current_user_can( 'update_plugins' ) ) wp_die( 'Not allowed.' );
		self::manifest( true );
		delete_site_transient( 'update_plugins' );
		wp_update_plugins();
		wp_safe_redirect( admin_url( 'tools.php?page=lmg-updates&lmgu=1' ) );
		exit;
	}

	/** Tools → LMG Updates: plugin by plugin, site by site. */
	public static function page() {
		$m = self::manifest();
		echo '<div class="wrap"><h1>LMG Updates</h1>';
		if ( isset( $_GET['lmgu'] ) ) echo '<div class="notice notice-success"><p>List read again. New versions show under <a href="' . esc_url( admin_url( 'update-core.php' ) ) . '">Dashboard → Updates</a>.</p></div>';
		if ( $e = get_option( 'lmgu_error' ) ) echo '<div class="notice notice-error"><p>' . esc_html( $e ) . '</p></div>';
		echo '<p><a class="button button-primary" href="' . esc_url( admin_url( 'update-core.php' ) ) . '">Go to Dashboard → Updates</a> <a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=lmgu_refresh' ), 'lmgu_refresh' ) ) . '">Read the list again</a></p>';
		if ( ! $m ) { echo '</div>'; return; }
		$sites = array();
		foreach ( $m['plugins'] as $e ) foreach ( (array) ( isset( $e['sites'] ) ? $e['sites'] : array() ) as $s ) $sites[ $s ] = true;
		$sites = array_keys( $sites );
		$stat  = array();
		foreach ( $sites as $s ) {
			$c = get_transient( 'lmgu_st_' . md5( $s ) );
			if ( ! is_array( $c ) ) {
				$r = wp_remote_get( 'https://' . $s . '/wp-json/lmg-updater/v1/status?v=' . time(), array( 'timeout' => 10 ) );
				$c = ( ! is_wp_error( $r ) && wp_remote_retrieve_response_code( $r ) === 200 ) ? json_decode( wp_remote_retrieve_body( $r ), true ) : array( 'down' => is_wp_error( $r ) ? $r->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code( $r ) );
				set_transient( 'lmgu_st_' . md5( $s ), $c, 5 * MINUTE_IN_SECONDS );
			}
			$stat[ $s ] = $c;
		}
		echo '<table class="widefat striped" style="max-width:1000px"><thead><tr><th>Plugin</th><th>Should run</th>';
		foreach ( $sites as $s ) echo '<th>' . esc_html( $s ) . '</th>';
		echo '</tr></thead><tbody>';
		foreach ( $m['plugins'] as $f => $e ) {
			echo '<tr><td><strong>' . esc_html( isset( $e['name'] ) ? $e['name'] : $f ) . '</strong>' . ( ! empty( $e['notes'] ) ? '<br><a href="' . esc_url( $e['notes'] ) . '" target="_blank">release notes</a>' : '' ) . '</td><td>' . esc_html( $e['version'] ) . '</td>';
			foreach ( $sites as $s ) {
				$want = in_array( $s, (array) $e['sites'], true );
				$st   = $stat[ $s ];
				if ( ! $want ) { echo '<td class="description">–</td>'; continue; }
				if ( ! empty( $st['down'] ) || empty( $st['plugins'] ) ) { echo '<td>⚠️ no answer<br><span class="description">LMG Updater installed there?</span></td>'; continue; }
				$p = isset( $st['plugins'][ $f ] ) ? $st['plugins'][ $f ] : null;
				if ( ! $p ) echo '<td>⚠️ not installed</td>';
				elseif ( version_compare( $p['version'], $e['version'], '>=' ) ) echo '<td>✅ ' . esc_html( $p['version'] ) . ( $p['active'] ? '' : ' <span style="color:#b32d2e">(inactive)</span>' ) . '</td>';
				else echo '<td>⏳ ' . esc_html( $p['version'] ) . '<br><span class="description">update waiting</span></td>';
			}
			echo '</tr>';
		}
		echo '</tbody></table>';
		$issues = array();
		foreach ( $stat as $s => $st ) {
			if ( ! empty( $st['issue']['issue'] ) ) $issues[] = $s . ': ' . $st['issue']['issue'];
			if ( ! empty( $st['list_error'] ) ) $issues[] = $s . ': ' . $st['list_error'];
		}
		echo '<h2>Issues</h2>' . ( $issues ? '<ul style="list-style:disc;margin-left:18px"><li>' . implode( '</li><li>', array_map( 'esc_html', $issues ) ) . '</li></ul>' : '<p>None.</p>' );
		echo '<p class="description">Read every 5 minutes from each site. ✅ runs the version in the list · ⏳ update waiting under Dashboard → Updates on that site · ⚠️ needs a look.</p></div>';
	}
}
LMGU::boot();
