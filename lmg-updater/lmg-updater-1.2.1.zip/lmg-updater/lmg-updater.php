<?php
/**
 * Plugin Name: LMG Updater
 * Description: Updates for Leisure Media Group's own plugins from one list. A new version shows under Dashboard → Updates like any other; you press Update. Tools → LMG Updates shows which version runs on which site.
 * Version:     1.2.1
 * Author:      Leisure Media Group Ltd
 *
 * Agreed with G, 14 Nov 2026: one list says what should run where; each site offers the update in its
 * own Dashboard → Updates; a person presses Update (nothing installs by itself – house rule: no
 * unattended writes to a live site); a status page shows done / waiting / issues across the sites.
 *
 * The list: manifest.json in the public repository info752/lmg-builds (builds only, no content).
 * Every zip carries a SHA-256 fingerprint in the list; a download that does not match is refused.
 *
 * 1.2.0 (G, 25 Nov 2026: "update the list and project, with the big number of plugins and a continuous dev"):
 *  - the list may name a plugin by its name ("name:LMG Match") instead of its file; the site finds the file;
 *  - entries without a build are watched only: shown in the table, never offered;
 *  - a site that runs a newer version than the list is flagged (the list is behind);
 *  - single-file plugins are updated by the Updater itself, with a copy of the old file kept to put back;
 *  - a build whose folder name differs from the installed folder is unpacked into the installed folder;
 *  - Tools → LMG Updates lists this site's own plugins, each with "Download a copy" (for the builds).
 */
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'LMGU_VERSION', '1.2.1' );
// 1.1.1 (14 Nov): GitHub's public file address kept serving an old list for 20+ minutes; the API answers at once.
define( 'LMGU_MANIFEST', 'https://api.github.com/repos/info752/lmg-builds/contents/manifest.json?ref=main' );
define( 'LMGU_MANIFEST_FALLBACK', 'https://raw.githubusercontent.com/info752/lmg-builds/main/manifest.json' );

class LMGU {

	const CACHE = 'lmgu_manifest';

	/** The list entry whose zip is being installed right now (set when its download passed the fingerprint check). */
	private static $current = null;

	public static function boot() {
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'offer' ) );
		add_filter( 'plugins_api', array( __CLASS__, 'details' ), 20, 3 );
		add_filter( 'upgrader_pre_download', array( __CLASS__, 'download' ), 10, 4 );
		add_filter( 'upgrader_source_selection', array( __CLASS__, 'same_folder' ), 10, 4 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'done' ), 10, 2 );
		// 1.2.1 (G, 26 Nov): the "update done" screen also links to the site's front page.
		add_filter( 'update_bulk_plugins_complete_actions', array( __CLASS__, 'front_link' ), 20 );
		add_filter( 'update_plugin_complete_actions', array( __CLASS__, 'front_link' ), 20 );
		add_filter( 'install_plugin_complete_actions', array( __CLASS__, 'front_link' ), 20 );
		add_filter( 'update_bulk_theme_complete_actions', array( __CLASS__, 'front_link' ), 20 );
		add_filter( 'update_theme_complete_actions', array( __CLASS__, 'front_link' ), 20 );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'admin_menu', function () {
			add_management_page( 'LMG Updates', 'LMG Updates', 'update_plugins', 'lmg-updates', array( __CLASS__, 'page' ) );
		} );
		add_action( 'admin_post_lmgu_refresh', array( __CLASS__, 'refresh' ) );
		add_action( 'admin_post_lmgu_update_all', array( __CLASS__, 'update_all' ) );
		add_action( 'admin_post_lmgu_restore', array( __CLASS__, 'restore' ) );
		add_action( 'admin_post_lmgu_copy', array( __CLASS__, 'copy' ) );
		// 1.1.0 (G, 14 Nov: "I still need to know here"): a notice on every admin page with one button.
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
		add_action( 'admin_init', array( __CLASS__, 'watch' ) );
	}

	public static function front_link( $actions ) {
		$actions = (array) $actions;
		$actions['lmgu_front'] = '<a href="' . esc_url( home_url( '/' ) ) . '" target="_parent">Go to the site\'s front page</a>';
		return $actions;
	}

	private static function host( $url = '' ) {
		return preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( $url ? $url : home_url(), PHP_URL_HOST ) ) );
	}

	/** The list, kept 10 minutes. */
	public static function manifest( $fresh = false ) {
		$m = $fresh ? false : get_transient( self::CACHE );
		if ( is_array( $m ) ) return $m;
		$url = (string) get_option( 'lmgu_manifest', LMGU_MANIFEST );
		$r   = wp_remote_get( $url, array( 'timeout' => 15, 'headers' => array( 'Accept' => 'application/vnd.github.raw', 'User-Agent' => 'LMG-Updater/' . LMGU_VERSION ) ) );
		if ( ( is_wp_error( $r ) || wp_remote_retrieve_response_code( $r ) !== 200 ) && $url === LMGU_MANIFEST ) {
			$r = wp_remote_get( add_query_arg( 'v', time(), LMGU_MANIFEST_FALLBACK ), array( 'timeout' => 15 ) );
		}
		if ( is_wp_error( $r ) || wp_remote_retrieve_response_code( $r ) !== 200 ) {
			update_option( 'lmgu_error', 'The list could not be read (' . ( is_wp_error( $r ) ? $r->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code( $r ) ) . ').', false );
			return array();
		}
		$m = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( ! is_array( $m ) || empty( $m['plugins'] ) ) { update_option( 'lmgu_error', 'The list is not readable.', false ); return array(); }
		delete_option( 'lmgu_error' );
		set_transient( self::CACHE, $m, 10 * MINUTE_IN_SECONDS );
		return $m;
	}

	private static function entries() {
		$m = self::manifest();
		return (array) ( isset( $m['plugins'] ) ? $m['plugins'] : array() );
	}

	private static function has_build( $e ) {
		return ! empty( $e['version'] ) && ! empty( $e['zip'] ) && ! empty( $e['sha256'] );
	}

	private static function for_me( $e ) {
		$me = self::host();
		foreach ( (array) ( isset( $e['sites'] ) ? $e['sites'] : array() ) as $s ) if ( self::host( 'https://' . $s ) === $me ) return true;
		return false;
	}

	/** 1.2.0: the installed file for a list entry – by file, or by the plugin's name ("name:…" entries, or a moved folder). */
	private static function resolve( $key, $e, $have ) {
		if ( strpos( $key, 'name:' ) !== 0 && isset( $have[ $key ] ) ) return $key;
		$name = strtolower( trim( isset( $e['name'] ) ? $e['name'] : substr( $key, 5 ) ) );
		if ( strpos( $key, 'name:' ) === 0 ) $name = strtolower( trim( substr( $key, 5 ) ) );
		foreach ( $have as $f => $p ) if ( strtolower( trim( $p['Name'] ) ) === $name ) return $f;
		return null;
	}

	/** Entries with a build meant for this site and installed here: [installed file => entry + key]. */
	private static function mine() {
		$have = self::installed();
		$out  = array();
		foreach ( self::entries() as $key => $e ) {
			if ( ! self::has_build( $e ) || ! self::for_me( $e ) ) continue;
			$f = self::resolve( $key, $e, $have );
			if ( $f ) $out[ $f ] = $e + array( 'key' => $key );
		}
		return $out;
	}

	private static function installed() {
		if ( ! function_exists( 'get_plugins' ) ) require_once ABSPATH . 'wp-admin/includes/plugin.php';
		return get_plugins();
	}

	private static function single( $file ) {
		return strpos( $file, '/' ) === false;
	}

	/** 1.1.0: when the list changes, WordPress is told at once, so the update shows without waiting half a day. */
	public static function watch() {
		if ( ! current_user_can( 'update_plugins' ) ) return;
		$m = self::manifest();
		if ( ! $m ) return;
		$h = md5( wp_json_encode( self::mine() ) );
		if ( get_option( 'lmgu_seen' ) === $h ) return;
		update_option( 'lmgu_seen', $h, false );
		delete_site_transient( 'update_plugins' );
		wp_update_plugins();
	}

	/** [installed file => [name, from, to]] for plugins with a newer version waiting here. */
	public static function waiting() {
		$have = self::installed();
		$out  = array();
		foreach ( self::mine() as $f => $e ) {
			if ( version_compare( $have[ $f ]['Version'], $e['version'], '<' ) ) $out[ $f ] = array( isset( $e['name'] ) ? $e['name'] : $f, $have[ $f ]['Version'], $e['version'] );
		}
		return $out;
	}

	public static function notice() {
		if ( ! current_user_can( 'update_plugins' ) ) return;
		$w = self::waiting();
		if ( ! $w ) return;
		$url  = wp_nonce_url( admin_url( 'admin-post.php?action=lmgu_update_all' ), 'lmgu_update_all' );
		$list = array();
		foreach ( $w as $x ) $list[] = esc_html( $x[0] . ' ' . $x[1] . ' → ' . $x[2] );
		echo '<div class="notice notice-warning"><p><strong>LMG: ' . count( $w ) . ' update(s) waiting</strong> – ' . implode( ' · ', $list ) . ' &nbsp; <a class="button button-primary" href="' . esc_url( $url ) . '">Update all now</a> <a href="' . esc_url( admin_url( 'tools.php?page=lmg-updates' ) ) . '">status</a></p></div>';
	}

	/** "Update all now": single-file plugins here, folder plugins through WordPress's own update screen. */
	public static function update_all() {
		check_admin_referer( 'lmgu_update_all' );
		if ( ! current_user_can( 'update_plugins' ) ) wp_die( 'Not allowed.' );
		$w       = self::waiting();
		$mine    = self::mine();
		$folders = array();
		$done    = array();
		foreach ( array_keys( $w ) as $f ) {
			if ( ! self::single( $f ) ) { $folders[] = $f; continue; }
			$r      = self::install_single( $f, $mine[ $f ] );
			$done[] = is_wp_error( $r ) ? $mine[ $f ]['name'] . ': ' . $r->get_error_message() : $mine[ $f ]['name'] . ' ' . $mine[ $f ]['version'] . ' installed';
		}
		if ( $done ) set_transient( 'lmgu_done_' . get_current_user_id(), $done, 10 * MINUTE_IN_SECONDS );
		if ( $folders ) {
			wp_safe_redirect( add_query_arg( array( 'action' => 'update-selected', 'plugins' => rawurlencode( implode( ',', $folders ) ), '_wpnonce' => wp_create_nonce( 'bulk-update-plugins' ) ), self_admin_url( 'update.php' ) ) );
			exit;
		}
		wp_safe_redirect( admin_url( 'tools.php?page=lmg-updates' ) );
		exit;
	}

	private static function backup_dir() {
		$u = wp_upload_dir();
		$d = trailingslashit( $u['basedir'] ) . 'lmg-updater-backups';
		if ( ! is_dir( $d ) ) {
			wp_mkdir_p( $d );
			@file_put_contents( $d . '/index.php', "<?php // Silence.\n" );
			@file_put_contents( $d . '/.htaccess', "Require all denied\nDeny from all\n" );
		}
		return $d;
	}

	/** 1.2.0: a single-file plugin (one .php directly in the plugins folder). WordPress's own route would move it into a new folder and switch it off. */
	public static function install_single( $file, $e ) {
		if ( ! function_exists( 'download_url' ) ) require_once ABSPATH . 'wp-admin/includes/file.php';
		if ( ! class_exists( 'ZipArchive' ) ) return new WP_Error( 'lmgu_zip', 'this server cannot open zip files.' );
		$tmp = download_url( $e['zip'], 120 );
		if ( is_wp_error( $tmp ) ) return $tmp;
		if ( ! hash_equals( strtolower( $e['sha256'] ), hash_file( 'sha256', $tmp ) ) ) {
			@unlink( $tmp );
			self::issue( basename( $e['zip'] ) . ': fingerprint does not match the list – not installed.' );
			return new WP_Error( 'lmgu_hash', 'the download does not match its fingerprint in the list, so it was not installed.' );
		}
		$zip = new ZipArchive();
		if ( $zip->open( $tmp ) !== true ) { @unlink( $tmp ); return new WP_Error( 'lmgu_zip', 'the zip could not be opened.' ); }
		$code = null;
		$want = basename( $file );
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$n = $zip->getNameIndex( $i );
			if ( basename( $n ) === $want && substr_count( trim( $n, '/' ), '/' ) <= 1 ) { $code = $zip->getFromIndex( $i ); break; }
		}
		$zip->close();
		@unlink( $tmp );
		if ( ! is_string( $code ) || $code === '' ) return new WP_Error( 'lmgu_missing', 'the zip does not hold ' . $want . '.' );
		$dest = WP_PLUGIN_DIR . '/' . $file;
		$new  = $dest . '.lmgu-new';
		if ( @file_put_contents( $new, $code ) === false ) return new WP_Error( 'lmgu_write', 'the plugins folder is not writable.' );
		$hdr = get_file_data( $new, array( 'Name' => 'Plugin Name', 'Version' => 'Version' ) );
		if ( $hdr['Version'] !== $e['version'] ) {
			@unlink( $new );
			return new WP_Error( 'lmgu_version', 'the file in the zip says version ' . ( $hdr['Version'] ? $hdr['Version'] : '?' ) . ', not ' . $e['version'] . ' – not installed.' );
		}
		$have = self::installed();
		$old  = isset( $have[ $file ] ) ? $have[ $file ]['Version'] : '?';
		$id   = preg_replace( '/[^A-Za-z0-9._-]/', '-', basename( $file, '.php' ) . '-' . $old . '-' . gmdate( 'Ymd-His' ) ) . '.php.txt';
		if ( ! @copy( $dest, self::backup_dir() . '/' . $id ) ) { @unlink( $new ); return new WP_Error( 'lmgu_backup', 'no copy of the old version could be kept, so nothing was changed.' ); }
		$b        = (array) get_option( 'lmgu_backups', array() );
		$b[ $id ] = array( 'file' => $file, 'version' => $old, 'at' => current_time( 'mysql', true ) );
		update_option( 'lmgu_backups', array_slice( $b, -20, null, true ), false );
		if ( ! @rename( $new, $dest ) ) { @unlink( $new ); return new WP_Error( 'lmgu_write', 'the new file could not be put in place.' ); }
		if ( function_exists( 'opcache_invalidate' ) ) @opcache_invalidate( $dest, true );
		wp_clean_plugins_cache( false );
		self::log( $file );
		return true;
	}

	/** Put back a single-file plugin from the copy kept at its last update. */
	public static function restore() {
		check_admin_referer( 'lmgu_restore' );
		if ( ! current_user_can( 'update_plugins' ) ) wp_die( 'Not allowed.' );
		$id = isset( $_GET['id'] ) ? (string) wp_unslash( $_GET['id'] ) : '';
		if ( ! preg_match( '/^[A-Za-z0-9._-]+$/', $id ) || strpos( $id, '..' ) !== false ) $id = '';
		$b  = (array) get_option( 'lmgu_backups', array() );
		$src = self::backup_dir() . '/' . $id;
		$msg = 'Nothing was put back: that copy is not there.';
		if ( $id && isset( $b[ $id ] ) && is_file( $src ) && self::single( $b[ $id ]['file'] ) ) {
			$dest = WP_PLUGIN_DIR . '/' . $b[ $id ]['file'];
			if ( @copy( $src, $dest ) ) {
				if ( function_exists( 'opcache_invalidate' ) ) @opcache_invalidate( $dest, true );
				wp_clean_plugins_cache( false );
				$msg = basename( $b[ $id ]['file'] ) . ' ' . $b[ $id ]['version'] . ' put back.';
			} else {
				$msg = 'The plugins folder is not writable; nothing was put back.';
			}
		}
		set_transient( 'lmgu_done_' . get_current_user_id(), array( $msg ), 10 * MINUTE_IN_SECONDS );
		wp_safe_redirect( admin_url( 'tools.php?page=lmg-updates' ) );
		exit;
	}

	public static function offer( $t ) {
		if ( ! is_object( $t ) ) return $t;
		$have = self::installed();
		foreach ( self::mine() as $file => $e ) {
			// Single-file plugins go through "Update all now" (WordPress's route would move them into a folder).
			if ( self::single( $file ) || version_compare( $have[ $file ]['Version'], $e['version'], '>=' ) ) continue;
			$t->response[ $file ] = (object) array(
				'slug'        => dirname( $file ),
				'plugin'      => $file,
				'new_version' => $e['version'],
				'package'     => $e['zip'],
				'url'         => isset( $e['notes'] ) ? $e['notes'] : '',
				'lmgu'        => 1,
			);
		}
		return $t;
	}

	/** "View version details": the release notes from the list. */
	public static function details( $res, $action, $args ) {
		if ( $action !== 'plugin_information' || empty( $args->slug ) ) return $res;
		foreach ( self::mine() as $file => $e ) {
			if ( dirname( $file ) !== $args->slug ) continue;
			return (object) array(
				'name' => isset( $e['name'] ) ? $e['name'] : $args->slug, 'slug' => $args->slug, 'version' => $e['version'],
				'author' => 'Leisure Media Group Ltd', 'sections' => array( 'changelog' => wpautop( esc_html( isset( $e['summary'] ) ? $e['summary'] : 'See the release notes.' ) ) . ( ! empty( $e['notes'] ) ? '<p><a href="' . esc_url( $e['notes'] ) . '" target="_blank">Full release notes</a></p>' : '' ) ),
			);
		}
		return $res;
	}

	/** Download our zips ourselves and refuse any that do not match the fingerprint in the list. */
	public static function download( $reply, $package, $upgrader, $hook_extra = array() ) {
		self::$current = null;
		$entry = null;
		foreach ( self::mine() as $e ) if ( $e['zip'] === $package ) $entry = $e;
		if ( ! $entry ) return $reply;
		if ( ! function_exists( 'download_url' ) ) require_once ABSPATH . 'wp-admin/includes/file.php';
		$tmp = download_url( $package, 120 );
		if ( is_wp_error( $tmp ) ) return $tmp;
		if ( ! hash_equals( strtolower( $entry['sha256'] ), hash_file( 'sha256', $tmp ) ) ) {
			@unlink( $tmp );
			self::issue( basename( $package ) . ': fingerprint does not match the list – not installed.' );
			return new WP_Error( 'lmgu_hash', 'LMG Updater: this download does not match its fingerprint in the list, so it was not installed.' );
		}
		self::$current = $entry;
		return $tmp;
	}

	/** 1.2.0: our build is unpacked into the folder the plugin already lives in, whatever the zip's folder is called. */
	public static function same_folder( $source, $remote_source, $upgrader, $hook_extra = array() ) {
		if ( ! self::$current || is_wp_error( $source ) || empty( $hook_extra['plugin'] ) || self::single( $hook_extra['plugin'] ) ) return $source;
		global $wp_filesystem;
		$slug = dirname( $hook_extra['plugin'] );
		if ( untrailingslashit( basename( $source ) ) === $slug || ! $wp_filesystem ) return $source;
		$to = trailingslashit( $remote_source ) . $slug . '/';
		if ( $wp_filesystem->exists( $to ) || ! $wp_filesystem->move( untrailingslashit( $source ), untrailingslashit( $to ) ) ) return $source;
		return $to;
	}

	private static function issue( $text ) {
		update_option( 'lmgu_last', array( 'at' => current_time( 'mysql', true ), 'issue' => $text ), false );
	}

	private static function log( $f ) {
		if ( ! function_exists( 'is_plugin_active' ) ) require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$have  = self::installed();
		$log   = (array) get_option( 'lmgu_log', array() );
		$log[] = array( 'at' => current_time( 'mysql', true ), 'plugin' => $f, 'version' => isset( $have[ $f ] ) ? $have[ $f ]['Version'] : '?', 'active' => is_plugin_active( $f ) );
		update_option( 'lmgu_log', array_slice( $log, -30 ), false );
	}

	public static function done( $upgrader, $extra ) {
		self::$current = null;
		if ( empty( $extra['type'] ) || $extra['type'] !== 'plugin' ) return;
		// One plugin ("plugin") or several at once from Dashboard → Updates ("plugins").
		$files = ! empty( $extra['plugins'] ) ? (array) $extra['plugins'] : ( ! empty( $extra['plugin'] ) ? array( $extra['plugin'] ) : array() );
		if ( ! $files ) return;
		wp_clean_plugins_cache( false );
		$have = self::installed();
		$want = self::mine();
		$last = get_option( 'lmgu_last' );
		foreach ( $files as $f ) {
			if ( ! isset( $want[ $f ] ) ) continue;
			// Only an update that really brought the version in the list clears an earlier problem with it.
			$ok = isset( $have[ $f ] ) && version_compare( $have[ $f ]['Version'], $want[ $f ]['version'], '>=' );
			if ( $ok && is_array( $last ) && ! empty( $last['issue'] ) && strpos( $last['issue'], dirname( $f ) ) === 0 ) delete_option( 'lmgu_last' );
			// Keep a fingerprint refusal from this same run: it says more than "did not complete".
			$fresh = is_array( $last ) && ! empty( $last['issue'] ) && strpos( $last['issue'], 'fingerprint' ) !== false && strtotime( $last['at'] . ' UTC' ) >= time() - 300;
			if ( ! $ok && ! $fresh ) self::issue( dirname( $f ) . ': update to ' . $want[ $f ]['version'] . ' did not complete (still ' . ( isset( $have[ $f ] ) ? $have[ $f ]['Version'] : '?' ) . ').' );
			self::log( $f );
		}
	}

	/** Public, read-only: which of the listed plugins run here, in which version. No other data. */
	public static function routes() {
		register_rest_route( 'lmg-updater/v1', '/status', array( 'methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => function () {
			$have = LMGU::installed_public();
			// 1.0.1: never cached (LiteSpeed kept an empty answer on traveltalk.dk).
			if ( ! headers_sent() ) { nocache_headers(); header( 'X-LiteSpeed-Cache-Control: no-cache' ); }
			return array( 'site' => preg_replace( '/^www\./', '', wp_parse_url( home_url(), PHP_URL_HOST ) ), 'updater' => LMGU_VERSION, 'plugins' => $have, 'issue' => get_option( 'lmgu_last', null ), 'list_error' => get_option( 'lmgu_error', '' ), 'at' => current_time( 'mysql', true ) );
		} ) );
	}

	/** Keyed as in the list, so every site's table lines up. */
	public static function installed_public() {
		if ( ! function_exists( 'is_plugin_active' ) ) require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$have = self::installed();
		$out  = array();
		foreach ( self::entries() as $key => $e ) {
			$f           = self::resolve( $key, $e, $have );
			$out[ $key ] = $f ? array( 'version' => $have[ $f ]['Version'], 'active' => is_plugin_active( $f ) ) : null;
		}
		return $out;
	}

	public static function refresh() {
		check_admin_referer( 'lmgu_refresh' );
		if ( ! current_user_can( 'update_plugins' ) ) wp_die( 'Not allowed.' );
		self::manifest( true );
		global $wpdb;
		$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_lmgu\\_st\\_%' OR option_name LIKE '\\_transient\\_timeout\\_lmgu\\_st\\_%'" );
		delete_site_transient( 'update_plugins' );
		wp_update_plugins();
		wp_safe_redirect( admin_url( 'tools.php?page=lmg-updates&lmgu=1' ) );
		exit;
	}

	/** 1.2.0: one of this site's own plugins as a zip, exactly as it is installed – the live copy a new build starts from. */
	public static function copy() {
		check_admin_referer( 'lmgu_copy' );
		if ( ! current_user_can( 'update_plugins' ) || ! current_user_can( 'activate_plugins' ) ) wp_die( 'Not allowed.' );
		$f    = isset( $_GET['plugin'] ) ? wp_unslash( $_GET['plugin'] ) : '';
		$have = self::installed();
		if ( ! isset( $have[ $f ] ) || ! self::ours( $have[ $f ] ) || ! class_exists( 'ZipArchive' ) ) wp_die( 'This copy cannot be made here.' );
		$tmp = wp_tempnam( 'lmgu-copy' );
		$zip = new ZipArchive();
		if ( $zip->open( $tmp, ZipArchive::OVERWRITE ) !== true ) wp_die( 'The copy could not be made.' );
		if ( self::single( $f ) ) {
			$zip->addFile( WP_PLUGIN_DIR . '/' . $f, $f );
		} else {
			$base = WP_PLUGIN_DIR . '/' . dirname( $f );
			$it   = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $base, FilesystemIterator::SKIP_DOTS ) );
			foreach ( $it as $file ) {
				if ( ! $file->isFile() ) continue;
				$rel = dirname( $f ) . '/' . str_replace( '\\', '/', substr( $file->getPathname(), strlen( $base ) + 1 ) );
				if ( strpos( $rel, '/.git/' ) !== false ) continue;
				$zip->addFile( $file->getPathname(), $rel );
			}
		}
		$zip->close();
		$name = sanitize_file_name( ( self::single( $f ) ? basename( $f, '.php' ) : dirname( $f ) ) . '-' . $have[ $f ]['Version'] . '-live-' . self::host() . '.zip' );
		nocache_headers();
		header( 'Content-Type: application/zip' );
		header( 'Content-Disposition: attachment; filename="' . $name . '"' );
		header( 'Content-Length: ' . filesize( $tmp ) );
		readfile( $tmp );
		@unlink( $tmp );
		exit;
	}

	/** Our own plugins: by author, or by the names we give them. */
	private static function ours( $p ) {
		if ( preg_match( '/leisure|\bLMG\b|traveltalk|think.?smarter/i', isset( $p['Author'] ) ? $p['Author'] : '' ) ) return true;
		return (bool) preg_match( '/^(LMG|TT|Leisure|TravelTalk|Traveltalk|WST|WineTalk|Think)/', isset( $p['Name'] ) ? $p['Name'] : '' );
	}

	private static function cell( $e, $p, $for_site ) {
		if ( ! $for_site ) return '<td class="description">–</td>';
		if ( ! $p ) return '<td class="description">not here</td>';
		$v   = esc_html( $p['version'] ) . ( $p['active'] ? '' : ' <span style="color:#b32d2e">(inactive)</span>' );
		$cmp = version_compare( $p['version'], $e['version'] );
		if ( $cmp === 0 ) return '<td>✅ ' . $v . '</td>';
		if ( $cmp > 0 ) return '<td style="background:#fcf0e1">🔼 ' . $v . '<br><span class="description">newer than the list – the list is behind</span></td>';
		if ( self::has_build( $e ) ) return '<td>⏳ ' . $v . '<br><span class="description">update waiting</span></td>';
		return '<td>⬇ ' . $v . '<br><span class="description">older; no build in the list</span></td>';
	}

	/** Tools → LMG Updates: plugin by plugin, site by site. */
	public static function page() {
		$m = self::manifest();
		echo '<div class="wrap"><h1>LMG Updates</h1>';
		if ( isset( $_GET['lmgu'] ) ) echo '<div class="notice notice-success"><p>List read again. New versions show under <a href="' . esc_url( admin_url( 'update-core.php' ) ) . '">Dashboard → Updates</a>.</p></div>';
		$done = get_transient( 'lmgu_done_' . get_current_user_id() );
		if ( $done ) { delete_transient( 'lmgu_done_' . get_current_user_id() ); echo '<div class="notice notice-info"><p>' . implode( '<br>', array_map( 'esc_html', (array) $done ) ) . '</p></div>'; }
		if ( $e = get_option( 'lmgu_error' ) ) echo '<div class="notice notice-error"><p>' . esc_html( $e ) . '</p></div>';
		echo '<p><a class="button button-primary" href="' . esc_url( admin_url( 'update-core.php' ) ) . '">Go to Dashboard → Updates</a> <a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=lmgu_refresh' ), 'lmgu_refresh' ) ) . '">Read the list again</a></p>';
		if ( ! $m ) { echo '</div>'; return; }
		$sites = array();
		foreach ( $m['plugins'] as $e ) foreach ( (array) ( isset( $e['sites'] ) ? $e['sites'] : array() ) as $s ) $sites[ $s ] = true;
		$sites = array_keys( $sites );
		$stat  = array();
		foreach ( $sites as $s ) {
			$c = get_transient( 'lmgu_st_' . md5( $s ) );
			if ( ! is_array( $c ) ) {
				$r = wp_remote_get( 'https://' . $s . '/wp-json/lmg-updater/v1/status?v=' . time(), array( 'timeout' => 10 ) );
				$c = ( ! is_wp_error( $r ) && wp_remote_retrieve_response_code( $r ) === 200 ) ? json_decode( wp_remote_retrieve_body( $r ), true ) : array( 'down' => is_wp_error( $r ) ? $r->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code( $r ) );
				set_transient( 'lmgu_st_' . md5( $s ), $c, 5 * MINUTE_IN_SECONDS );
			}
			$stat[ $s ] = $c;
		}
		$groups = array(
			'Updated through the list'               => array_filter( $m['plugins'], array( __CLASS__, 'has_build' ) ),
			'Watched only (no build in the list yet)' => array_filter( $m['plugins'], function ( $e ) { return ! LMGU::has_build_public( $e ); } ),
		);
		foreach ( $groups as $title => $rows ) {
			if ( ! $rows ) continue;
			uasort( $rows, function ( $a, $b ) { return strcasecmp( isset( $a['name'] ) ? $a['name'] : '', isset( $b['name'] ) ? $b['name'] : '' ); } );
			echo '<h2>' . esc_html( $title ) . ' (' . count( $rows ) . ')</h2>';
			echo '<table class="widefat striped" style="max-width:1200px"><thead><tr><th>Plugin</th><th>Should run</th>';
			// 1.1.2 (G, 14 Nov): each site's name opens its Dashboard → Updates in a new tab.
			foreach ( $sites as $s ) echo '<th><a href="' . esc_url( 'https://' . $s . '/wp-admin/update-core.php' ) . '" target="_blank" rel="noopener">' . esc_html( $s ) . ' ↗</a></th>';
			echo '</tr></thead><tbody>';
			foreach ( $rows as $f => $e ) {
				$key = (string) $f;
				echo '<tr><td><strong>' . esc_html( isset( $e['name'] ) ? $e['name'] : $key ) . '</strong>' . ( ! empty( $e['notes'] ) ? '<br><a href="' . esc_url( $e['notes'] ) . '" target="_blank">release notes</a>' : '' ) . '</td><td>' . esc_html( $e['version'] ) . '</td>';
				foreach ( $sites as $s ) {
					$st = $stat[ $s ];
					if ( ! in_array( $s, (array) $e['sites'], true ) ) { echo '<td class="description">–</td>'; continue; }
					if ( ! empty( $st['down'] ) || empty( $st['plugins'] ) ) { echo '<td>⚠️ no answer<br><span class="description">LMG Updater installed there?</span></td>'; continue; }
					if ( ! array_key_exists( $key, $st['plugins'] ) ) { echo '<td class="description">? older Updater there</td>'; continue; }
					echo self::cell( $e, $st['plugins'][ $key ], true );
				}
				echo '</tr>';
			}
			echo '</tbody></table>';
		}
		$issues = array();
		foreach ( $stat as $s => $st ) {
			if ( ! empty( $st['issue']['issue'] ) ) $issues[] = $s . ': ' . $st['issue']['issue'];
			if ( ! empty( $st['list_error'] ) ) $issues[] = $s . ': ' . $st['list_error'];
			if ( ! empty( $st['updater'] ) && version_compare( $st['updater'], LMGU_VERSION, '<' ) ) $issues[] = $s . ': runs LMG Updater ' . $st['updater'] . ' – update it there first.';
		}
		echo '<h2>Issues</h2>' . ( $issues ? '<ul style="list-style:disc;margin-left:18px"><li>' . implode( '</li><li>', array_map( 'esc_html', $issues ) ) . '</li></ul>' : '<p>None.</p>' );
		echo '<p class="description">Read every 5 minutes from each site. ✅ runs the version in the list · ⏳ update waiting on that site · 🔼 newer than the list (the list must be brought up to date) · ⬇ older, but no build in the list yet · ⚠️ needs a look.</p>';

		// This site's own plugins, with a copy to download for the builds.
		$have   = self::installed();
		$listed = array();
		foreach ( self::entries() as $key => $e ) { $r = self::resolve( $key, $e, $have ); if ( $r ) $listed[ $r ] = true; }
		echo '<h2>Our plugins on this site</h2><p class="description">"Download a copy" gives the plugin exactly as it is installed here, as a zip – the starting point for its next build.</p>';
		echo '<table class="widefat striped" style="max-width:1200px"><thead><tr><th>Plugin</th><th>Version</th><th>File</th><th>In the list</th><th></th></tr></thead><tbody>';
		uasort( $have, function ( $a, $b ) { return strcasecmp( $a['Name'], $b['Name'] ); } );
		foreach ( $have as $f => $p ) {
			if ( ! self::ours( $p ) ) continue;
			$dl = wp_nonce_url( admin_url( 'admin-post.php?action=lmgu_copy&plugin=' . rawurlencode( $f ) ), 'lmgu_copy' );
			echo '<tr><td>' . esc_html( $p['Name'] ) . ( is_plugin_active( $f ) ? '' : ' <span style="color:#b32d2e">(inactive)</span>' ) . '</td><td>' . esc_html( $p['Version'] ) . '</td><td><code>' . esc_html( $f ) . '</code></td><td>' . ( isset( $listed[ $f ] ) ? 'yes' : '<strong>no</strong>' ) . '</td><td><a href="' . esc_url( $dl ) . '">Download a copy</a></td></tr>';
		}
		echo '</tbody></table>';

		$b = (array) get_option( 'lmgu_backups', array() );
		if ( $b ) {
			echo '<h2>Copies kept from single-file updates</h2><table class="widefat striped" style="max-width:1200px"><tbody>';
			foreach ( array_reverse( $b, true ) as $id => $x ) {
				$u = wp_nonce_url( admin_url( 'admin-post.php?action=lmgu_restore&id=' . rawurlencode( $id ) ), 'lmgu_restore' );
				echo '<tr><td>' . esc_html( basename( $x['file'] ) . ' ' . $x['version'] ) . '</td><td>' . esc_html( $x['at'] ) . ' UTC</td><td><a class="button" href="' . esc_url( $u ) . '">Put this version back</a></td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';
	}

	public static function has_build_public( $e ) {
		return self::has_build( $e );
	}
}
LMGU::boot();
