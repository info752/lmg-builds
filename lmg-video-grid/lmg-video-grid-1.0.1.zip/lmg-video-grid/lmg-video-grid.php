<?php
/**
 * Plugin Name: LMG Video Grid
 * Description: Reusable click-to-play YouTube grid. Curated IDs now; API-driven most-viewed later. Shortcode: [lmg_video_grid ids="id1,id2" titles="A|B" cols="3" channel="Watch more on YouTube" channel_url="..."]
 * Version: 1.0.1
 * Author: LMG
 */
if ( ! defined('ABSPATH') ) exit;

add_shortcode('lmg_video_grid', function($atts){
    $a = shortcode_atts([
        'ids'         => '',
        'titles'      => '',
        'cols'        => '3',
        'channel'     => '',      // optional "watch more" label
        'channel_url' => '',      // optional channel link
    ], $atts, 'lmg_video_grid');

    $ids = array_values(array_filter(array_map('trim', explode(',', $a['ids']))));
    if ( ! $ids ) return '';
    $titles = $a['titles'] !== '' ? array_map('trim', explode('|', $a['titles'])) : [];
    $cols = max(1, min(4, (int)$a['cols']));

    ob_start(); ?>
<div class="lmg-vgrid" style="--lmg-vcols:<?php echo $cols; ?>">
<?php foreach ($ids as $i => $vid):
        $vid   = preg_replace('/[^A-Za-z0-9_\-]/','',$vid);
        $title = isset($titles[$i]) ? $titles[$i] : '';
        $thumb = 'https://i.ytimg.com/vi/'.$vid.'/hqdefault.jpg';
    ?>
    <div class="lmg-vcard">
        <button type="button" class="lmg-vthumb" data-id="<?php echo esc_attr($vid); ?>" aria-label="Play: <?php echo esc_attr($title); ?>" style="background-image:url('<?php echo esc_url($thumb); ?>')">
            <span class="lmg-vplay" aria-hidden="true">
                <svg viewBox="0 0 68 48" width="58" height="40"><path class="lmg-vplay-bg" d="M66.5 7.7c-.8-2.9-3-5.1-5.9-5.9C55.3.5 34 .5 34 .5S12.7.5 7.4 1.8C4.5 2.6 2.3 4.8 1.5 7.7.2 13 .2 24 .2 24s0 11 1.3 16.3c.8 2.9 3 5.1 5.9 5.9C12.7 47.5 34 47.5 34 47.5s21.3 0 26.6-1.3c2.9-.8 5.1-3 5.9-5.9C67.8 35 67.8 24 67.8 24s0-11-1.3-16.3z" fill="#212121" fill-opacity=".85"></path><path d="M45 24 27 14v20z" fill="#fff"></path></svg>
            </span>
        </button>
        <?php if ($title): ?><p class="lmg-vtitle"><?php echo esc_html($title); ?></p><?php endif; ?>
    </div>
<?php endforeach; ?>
</div>
<?php if ($a['channel'] && $a['channel_url']): ?>
<p class="lmg-vmore"><a href="<?php echo esc_url($a['channel_url']); ?>" target="_blank" rel="noopener"><?php echo esc_html($a['channel']); ?> →</a></p>
<?php endif; ?>
<?php
/* VideoObject structured data -> eligible for Google video rich results */
$lmg_ld=[]; $lmg_date=get_the_date('c')?:date('c');
foreach($ids as $i=>$v){ $v=preg_replace('/[^A-Za-z0-9_\-]/','',$v); $tt=isset($titles[$i])?$titles[$i]:'TravelTalk film';
  $lmg_ld[]=['@type'=>'VideoObject','name'=>$tt,'description'=>$tt,'thumbnailUrl'=>['https://i.ytimg.com/vi/'.$v.'/hqdefault.jpg'],'uploadDate'=>$lmg_date,'embedUrl'=>'https://www.youtube-nocookie.com/embed/'.$v,'contentUrl'=>'https://www.youtube.com/watch?v='.$v]; }
if($lmg_ld){ echo '<script type="application/ld+json" data-no-optimize="1" data-no-defer="1" data-no-minify="1">'.wp_json_encode(['@context'=>'https://schema.org','@graph'=>$lmg_ld]).'</script>'; }
?>
<style id="lmg-vgrid-css" data-no-optimize="1" data-no-defer="1" data-no-minify="1">
.lmg-vgrid{display:grid;grid-template-columns:repeat(var(--lmg-vcols,3),1fr);gap:1.4rem;margin:1.5rem auto;max-width:1100px}
.lmg-vcard{margin:0}
.lmg-vthumb{display:block;position:relative;width:100%;aspect-ratio:16/9;border:0;padding:0;border-radius:10px;overflow:hidden;cursor:pointer;background-size:cover;background-position:center;box-shadow:0 4px 14px rgba(0,0,0,.12);transition:transform .18s ease,box-shadow .18s ease}
.lmg-vthumb:hover{transform:translateY(-3px);box-shadow:0 10px 26px rgba(0,0,0,.18)}
.lmg-vplay{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;z-index:2}
.lmg-vplay svg{filter:drop-shadow(0 2px 6px rgba(0,0,0,.4));transition:transform .18s ease}
.lmg-vthumb:hover .lmg-vplay svg{transform:scale(1.08)}
.lmg-vthumb:hover .lmg-vplay-bg{fill:#C4704A;fill-opacity:1}
/* Title: smaller text in a fixed invisible box so the gold initial has a design grip */
.lmg-vtitle,.entry-content .lmg-vgrid p.lmg-vtitle,.wp-block-post-content .lmg-vgrid p.lmg-vtitle{margin:.7rem 0 0!important;font-family:'Playfair Display',Georgia,serif!important;font-size:.86rem!important;font-weight:500!important;line-height:1.34!important;color:#1a1a1a!important;text-indent:0!important;overflow:hidden!important;min-height:2.7em!important}
/* 1.0.1 (G, 2 Nov 2026): no drop cap on titles – at this size it read as a typo ("B oracay"). Beats the theme's own drop cap. */
.entry-content .lmg-vgrid .lmg-vtitle::first-letter,
.wp-block-post-content .lmg-vgrid .lmg-vtitle::first-letter,
.lmg-vgrid .lmg-vcard .lmg-vtitle::first-letter{font-size:inherit!important;font-weight:inherit!important;color:inherit!important;float:none!important;line-height:inherit!important;margin:0!important;padding:0!important;background:none!important}
/* "Watch more" line: NO drop cap */
.entry-content .lmg-vmore.lmg-vmore::first-letter,.wp-block-post-content .lmg-vmore.lmg-vmore::first-letter,.lmg-vmore.lmg-vmore::first-letter{font-size:inherit!important;font-weight:inherit!important;color:inherit!important;float:none!important;line-height:inherit!important;margin:0!important;padding:0!important}
.lmg-vcard iframe{width:100%;aspect-ratio:16/9;border:0;border-radius:10px;display:block}
.lmg-vmore{text-align:center;margin:.5rem 0 0}
.lmg-vmore a{font-family:'Inter',sans-serif;font-size:13px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:#C4704A;text-decoration:none}
@media(max-width:900px){.lmg-vgrid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:560px){.lmg-vgrid{grid-template-columns:1fr}}
</style>
<script data-no-optimize="1" data-no-defer="1">
(function(){
  var open=false;
  function removeOverlay(){ var lb=document.getElementById('lmg-vlb'); if(lb) lb.remove(); open=false; window.removeEventListener('popstate',onPop); document.removeEventListener('keydown',onEsc); }
  function onPop(){ removeOverlay(); }            // browser Back -> close video, stay on page
  function userClose(){ if(open){ history.back(); } } // X / backdrop / Esc -> back -> onPop -> remove
  function onEsc(e){ if(e.key==='Escape') userClose(); }
  document.addEventListener('click',function(e){
    var btn=e.target.closest('.lmg-vthumb'); if(!btn)return;
    var id=btn.getAttribute('data-id'); if(!id)return;
    if(open) removeOverlay();
    var lb=document.createElement('div'); lb.id='lmg-vlb';
    lb.style.cssText='position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.86);display:flex;align-items:center;justify-content:center;padding:5vmin';
    var inner=document.createElement('div');
    inner.style.cssText='position:relative;width:min(880px,92vw);aspect-ratio:16/9;max-height:82vh';
    var f=document.createElement('iframe');
    f.style.cssText='width:100%;height:100%;border:0;border-radius:10px;display:block;box-shadow:0 14px 50px rgba(0,0,0,.55)';
    f.setAttribute('allow','accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share');
    f.setAttribute('allowfullscreen','');
    f.src='https://www.youtube-nocookie.com/embed/'+id+'?autoplay=1&rel=0';
    var c=document.createElement('button'); c.type='button'; c.innerHTML='&times;'; c.setAttribute('aria-label','Close');
    c.style.cssText='position:absolute;top:-46px;right:0;width:42px;height:42px;border:0;border-radius:50%;background:rgba(255,255,255,.16);color:#fff;font-size:26px;line-height:1;cursor:pointer';
    inner.appendChild(f); inner.appendChild(c); lb.appendChild(inner);
    lb.addEventListener('click',function(ev){ if(ev.target===lb||ev.target===c) userClose(); });
    document.body.appendChild(lb);
    open=true;
    history.pushState({lmgvlb:1},'');             // so Back closes the video, doesn't leave the site
    window.addEventListener('popstate',onPop);
    document.addEventListener('keydown',onEsc);
  });
})();
</script>
<?php
    return ob_get_clean();
});
