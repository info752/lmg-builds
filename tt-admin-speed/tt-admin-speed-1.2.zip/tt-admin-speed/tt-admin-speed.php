<?php
/**
 * Plugin Name: TT Admin Speed Fix
 * Description: Lightweight admin-speed optimisations. Reversible — deactivate to restore vanilla behaviour.
 * Version: 1.2
 * Author: LMG
 */
if ( ! defined( 'ABSPATH' ) ) exit;

// ── 1. Throttle Heartbeat in admin from 15s → 120s ──────────────────────────
// Cuts admin background DB hits by ~8x. The 15s default was set for collaborative
// editing in 2012; for a single-author admin it's just overhead.
add_filter( 'heartbeat_settings', function( $settings ) {
    $settings['interval'] = 120;
    $settings['minimalInterval'] = 120;
    return $settings;
} );

// ── 2. Disable Heartbeat entirely on dashboard + plugin pages ────────────────
// We keep it on post-edit (autosave needs it) but kill it everywhere else.
add_action( 'init', function() {
    global $pagenow;
    if ( ! is_admin() ) return;
    $kill_on = [ 'index.php', 'plugins.php', 'themes.php', 'tools.php', 'options-general.php', 'edit.php' ];
    if ( in_array( $pagenow, $kill_on, true ) ) {
        wp_deregister_script( 'heartbeat' );
    }
}, 1 );

// ── 3. Kill do_pings — 46-second-per-fire dead-blog-directory pinger ─────────
remove_action( 'do_pings', 'do_all_pings', 10, 1 );
add_action( 'init', function() {
    if ( wp_next_scheduled( 'do_pings' ) ) {
        wp_clear_scheduled_hook( 'do_pings' );
    }
} );

// ── 4. Remove ONLY the genuinely useless dashboard widgets ───────────────────
// G's vitals (Site Kit, RankMath, LeisureHealth, At-a-Glance, plugin cockpits) stay visible.
// Only kill the WordPress.org news feed (slow external HTTP, no LMG value).
add_action( 'wp_dashboard_setup', function() {
    remove_meta_box( 'dashboard_primary', 'dashboard', 'side' );          // WordPress.org news (slow ext fetch)
}, 99 );

// ── 5. Disable WP's emoji JS/CSS in admin ────────────────────────────────────
// Saves an HTTP request + a tiny bit of parse time on every admin page.
remove_action( 'admin_print_styles', 'print_emoji_styles' );
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );

// ── 6. (Removed in 1.2) Application passwords stay on: the LMG Translator bridge logs in with one.

// ── 7. Disable RSS dashboard widget feed fetch ───────────────────────────────
// The WP "Events and News" widget makes a blocking HTTP call to WordPress.org.
add_action( 'admin_init', function() {
    remove_action( 'welcome_panel', 'wp_welcome_panel' );
} );
