<?php
/**
 * Plugin Name: LMG GA4 Key
 * Description: Upload the Google service account key for LeisureIntel's GA4 connection from wp-admin. Stores it outside the web root (or in a locked folder) and points Intel to it.
 * Version: 1.0.0
 * Author: Leisure Media Group
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) exit;

class LMG_GA4_Key {
    const SLUG = 'lmg-ga4-key';

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'menu'], 99);
        add_action('admin_post_lmg_ga4_key_upload', [__CLASS__, 'handle_upload']);
        add_action('admin_post_lmg_ga4_key_remove', [__CLASS__, 'handle_remove']);
        add_action('admin_notices', [__CLASS__, 'intel_notice']);
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($l) {
            array_unshift($l, '<a href="' . esc_url(self::url()) . '">Upload key</a>');
            return $l;
        });
    }

    public static function url() {
        return admin_url((self::intel_active() ? 'admin.php' : 'options-general.php') . '?page=' . self::SLUG);
    }

    private static function intel_active() {
        global $admin_page_hooks;
        return !empty($admin_page_hooks['leisureintel']);
    }

    public static function menu() {
        if (self::intel_active()) {
            add_submenu_page('leisureintel', 'GA4 key', 'GA4 key (upload)', 'manage_options', self::SLUG, [__CLASS__, 'page']);
        } else {
            add_options_page('GA4 key', 'GA4 key (upload)', 'manage_options', self::SLUG, [__CLASS__, 'page']);
        }
    }

    private static function dir() {
        $outside = dirname(untrailingslashit(ABSPATH)) . '/lmg-private';
        if ((is_dir($outside) || @wp_mkdir_p($outside)) && is_writable($outside)) return $outside;
        $inside = WP_CONTENT_DIR . '/lmg-private';
        if (!is_dir($inside)) wp_mkdir_p($inside);
        if (!file_exists($inside . '/.htaccess')) @file_put_contents($inside . '/.htaccess', "Require all denied\nDeny from all\n");
        if (!file_exists($inside . '/index.php')) @file_put_contents($inside . '/index.php', "<?php // Silence\n");
        if (!file_exists($inside . '/web.config')) @file_put_contents($inside . '/web.config', '<?xml version="1.0"?><configuration><system.webServer><authorization><deny users="*" /></authorization></system.webServer></configuration>');
        return $inside;
    }

    private static function current_path() {
        return (string) get_option('li_ga4_credentials_path', '');
    }

    private static function read_key($path) {
        if (!$path || !is_readable($path)) return null;
        $j = json_decode((string) file_get_contents($path), true);
        return is_array($j) ? $j : null;
    }

    public static function handle_upload() {
        if (!current_user_can('manage_options')) wp_die('No access');
        check_admin_referer('lmg_ga4_key_upload');
        $back = self::url();
        $f = $_FILES['lmg_ga4_key'] ?? null;
        if (!$f || !empty($f['error']) || empty($f['tmp_name']) || !is_uploaded_file($f['tmp_name'])) {
            wp_safe_redirect(add_query_arg('lmg_ga4', 'nofile', $back)); exit;
        }
        if ($f['size'] > 20000) { wp_safe_redirect(add_query_arg('lmg_ga4', 'big', $back)); exit; }
        $raw = (string) file_get_contents($f['tmp_name']);
        @unlink($f['tmp_name']);
        $j = json_decode($raw, true);
        if (!is_array($j) || ($j['type'] ?? '') !== 'service_account' || empty($j['private_key']) || empty($j['client_email'])
            || !openssl_pkey_get_private($j['private_key'])) {
            wp_safe_redirect(add_query_arg('lmg_ga4', 'invalid', $back)); exit;
        }
        $dir  = self::dir();
        $old  = self::current_path();
        $path = $dir . '/ga4-' . wp_generate_password(20, false, false) . '.json';
        if (file_put_contents($path, $raw, LOCK_EX) === false) {
            wp_safe_redirect(add_query_arg('lmg_ga4', 'write', $back)); exit;
        }
        @chmod($path, 0600);
        update_option('li_ga4_credentials_path', $path);
        if (!empty($_POST['lmg_ga4_property'])) {
            update_option('li_ga4_property_id', preg_replace('/\D/', '', wp_unslash($_POST['lmg_ga4_property'])));
        }
        if ($old && $old !== $path && strpos(basename($old), 'ga4-') === 0 && strpos($old, '/lmg-private/') !== false) @unlink($old);
        delete_transient('li_ga4_token');
        wp_safe_redirect(add_query_arg('lmg_ga4', 'ok', $back)); exit;
    }

    public static function handle_remove() {
        if (!current_user_can('manage_options')) wp_die('No access');
        check_admin_referer('lmg_ga4_key_remove');
        $p = self::current_path();
        if ($p && strpos($p, '/lmg-private/ga4-') !== false) @unlink($p);
        delete_option('li_ga4_credentials_path');
        wp_safe_redirect(add_query_arg('lmg_ga4', 'removed', self::url())); exit;
    }

    private static function test() {
        if (!class_exists('LI_GA4')) return ['warn', 'LeisureIntel not active: key saved, no test possible.'];
        $g = new LI_GA4();
        if (!$g->is_configured()) return ['warn', 'GA4 ikke konfigureret'];
        $ref = new ReflectionClass($g);
        if ($ref->hasMethod('get_access_token')) {
            $m = $ref->getMethod('get_access_token'); $m->setAccessible(true);
            $t = $m->invoke($g);
            if (is_wp_error($t)) return ['err', 'GA4 aktiv, but Google refused the key: ' . $t->get_error_message()];
            $prop = get_option('li_ga4_property_id', '');
            $r = wp_remote_post('https://analyticsdata.googleapis.com/v1beta/properties/' . rawurlencode($prop) . ':runReport', [
                'timeout' => 15,
                'headers' => ['Authorization' => 'Bearer ' . $t, 'Content-Type' => 'application/json'],
                'body'    => wp_json_encode(['dateRanges' => [['startDate' => '7daysAgo', 'endDate' => 'yesterday']], 'metrics' => [['name' => 'sessions']]]),
            ]);
            if (is_wp_error($r)) return ['err', 'GA4 aktiv, connection error: ' . $r->get_error_message()];
            $code = wp_remote_retrieve_response_code($r);
            $body = json_decode(wp_remote_retrieve_body($r), true);
            if ($code === 200) {
                $s = $body['rows'][0]['metricValues'][0]['value'] ?? '0';
                return ['ok', 'GA4 aktiv. Live read OK: ' . number_format_i18n((int) $s) . ' sessions last 7 days.'];
            }
            return ['err', 'GA4 aktiv, but Google answered ' . $code . ': ' . ($body['error']['message'] ?? 'unknown')];
        }
        return ['ok', 'GA4 aktiv'];
    }

    public static function intel_notice() {
        if (!current_user_can('manage_options') || ($_GET['page'] ?? '') !== 'leisureintel') return;
        if (class_exists('LI_GA4') && (new LI_GA4())->is_configured()) return;
        echo '<div class="notice notice-warning"><p>GA4 is not connected. <a class="button button-primary" href="' . esc_url(self::url()) . '">Upload key</a></p></div>';
    }

    public static function page() {
        if (!current_user_can('manage_options')) return;
        $msgs = [
            'ok' => ['success', 'Key saved.'], 'removed' => ['success', 'Key removed.'],
            'nofile' => ['error', 'No file received.'], 'big' => ['error', 'File too large for a key.'],
            'invalid' => ['error', 'Not a valid Google service account key (.json).'], 'write' => ['error', 'Could not save the file on the server.'],
        ];
        $k = sanitize_key($_GET['lmg_ga4'] ?? '');
        $path = self::current_path();
        $key  = self::read_key($path);
        $prop = get_option('li_ga4_property_id', '445373117');
        $outside = strpos($path, untrailingslashit(ABSPATH)) !== 0;
        ?>
        <div class="wrap">
            <h1>GA4 key</h1>
            <?php if (isset($msgs[$k])) printf('<div class="notice notice-%s"><p>%s</p></div>', esc_attr($msgs[$k][0]), esc_html($msgs[$k][1])); ?>
            <?php if ($key) { [$lvl, $txt] = self::test(); $cls = ['ok' => 'success', 'warn' => 'warning', 'err' => 'error'][$lvl]; ?>
                <div class="notice notice-<?php echo esc_attr($cls); ?> inline"><p><strong><?php echo esc_html($txt); ?></strong></p></div>
                <table class="form-table">
                    <tr><th>Service account</th><td><code><?php echo esc_html($key['client_email']); ?></code><p class="description">Add this address as Viewer in GA4 → Admin → Property access management.</p></td></tr>
                    <tr><th>Project</th><td><code><?php echo esc_html($key['project_id'] ?? ''); ?></code></td></tr>
                    <tr><th>Stored</th><td><?php echo $outside ? 'Outside the web root' : 'Locked folder in wp-content'; ?></td></tr>
                    <tr><th>Property ID</th><td><code><?php echo esc_html($prop); ?></code></td></tr>
                </table>
            <?php } else { ?>
                <div class="notice notice-warning inline"><p><strong>GA4 ikke konfigureret</strong></p></div>
            <?php } ?>
            <h2><?php echo $key ? 'Replace key' : 'Upload key'; ?></h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data">
                <?php wp_nonce_field('lmg_ga4_key_upload'); ?>
                <input type="hidden" name="action" value="lmg_ga4_key_upload">
                <table class="form-table">
                    <tr><th><label for="lmg_ga4_key">Service account key (.json)</label></th>
                        <td><input type="file" id="lmg_ga4_key" name="lmg_ga4_key" accept=".json,application/json" required></td></tr>
                    <tr><th><label for="lmg_ga4_property">GA4 Property ID</label></th>
                        <td><input type="text" id="lmg_ga4_property" name="lmg_ga4_property" value="<?php echo esc_attr($prop); ?>" class="regular-text"></td></tr>
                </table>
                <?php submit_button('Upload key'); ?>
            </form>
            <?php if ($key) { ?>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" onsubmit="return confirm('Remove the key?');">
                    <?php wp_nonce_field('lmg_ga4_key_remove'); ?>
                    <input type="hidden" name="action" value="lmg_ga4_key_remove">
                    <?php submit_button('Remove key', 'delete small', 'submit', false); ?>
                </form>
            <?php } ?>
        </div>
        <?php
    }
}
LMG_GA4_Key::init();
