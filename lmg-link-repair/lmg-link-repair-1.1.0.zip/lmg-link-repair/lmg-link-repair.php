<?php
/**
 * Plugin Name: LMG Link Repair
 * Description: Recovery steps 1–3: point internal links straight at the live page, answer old GTranslate language addresses with 410, and list orphan posts. Preview first; nothing changes until you press Apply.
 * Version: 1.1.0
 * Author: Leisure Media Group Ltd
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) exit;

final class LMG_Link_Repair {
	const VER        = '1.1.0';
	const SLUG       = 'lmg-link-repair';
	const OPT_SCAN   = 'lmg_lr_scan';
	const OPT_LANG   = 'lmg_lr_lang';
	const OPT_LOG    = 'lmg_lr_lang_log';
	const META_BAK   = '_lmg_lr_backup';
	const META_HUB   = '_lmg_lr_backup_hub';
	const BATCH      = 80;

	const GT_CODES = 'af,sq,am,ar,hy,az,eu,be,bn,bs,bg,ca,ceb,ny,zh-cn,zh-tw,co,hr,cs,da,nl,en,eo,et,tl,fi,fr,fy,gl,ka,de,el,gu,ht,ha,haw,iw,he,hi,hmn,hu,is,ig,id,ga,it,ja,jw,kn,kk,km,ko,ku,ky,lo,la,lv,lt,lb,mk,mg,ms,ml,mt,mi,mr,mn,my,ne,no,nb,ps,fa,pl,pt,pa,ro,ru,sm,gd,sr,st,sn,sd,si,sk,sl,so,es,su,sw,sv,se,tg,ta,te,th,tr,uk,ur,uz,vi,cy,xh,yi,yo,zu';
	const KEEP     = 'da,en,de,fr,es,it,nl,pt,pl,sv,se,no,nb,fi,ja,zh,zh-cn,zh-tw,ko';

	private $cache = [];

	public static function boot() { static $i; if (!$i) $i = new self(); return $i; }

	private function __construct() {
		add_action('admin_menu', [$this, 'menu']);
		add_action('admin_post_lmg_lr', [$this, 'handle']);
		add_action('template_redirect', [$this, 'old_language'], 999);
	}

	public function menu() {
		add_management_page('Link repair', 'Link repair', 'manage_options', self::SLUG, [$this, 'page']);
	}

	/* ---------- helpers ---------- */

	private function hosts() {
		$h = strtolower(wp_parse_url(home_url(), PHP_URL_HOST));
		$bare = preg_replace('/^www\./', '', $h);
		return [$bare, 'www.' . $bare];
	}

	private function norm($url) {
		$p = wp_parse_url($url);
		$path = isset($p['path']) ? $p['path'] : '/';
		return home_url(user_trailingslashit(untrailingslashit($path) ?: '/'));
	}

	/** Return [href => final-or-''] for an internal href; null when the href is not ours or not a page. */
	private function internal_path($href) {
		$href = html_entity_decode(trim($href));
		if ($href === '' || $href[0] === '#') return null;
		$p = wp_parse_url($href);
		if ($p === false) return null;
		if (!empty($p['host'])) {
			if (!in_array(strtolower($p['host']), $this->hosts(), true)) return null;
		} elseif (empty($p['path']) || $p['path'][0] !== '/') {
			return null;
		}
		$path = isset($p['path']) ? $p['path'] : '/';
		if (preg_match('~^/(wp-content|wp-admin|wp-includes|wp-json|feed)/~', $path)) return null;
		if (preg_match('~\.[a-z0-9]{2,5}$~i', $path)) return null;
		if (!empty($p['query'])) return null;
		return $path;
	}

	private function rm_target($path) {
		global $wpdb;
		$t = $wpdb->prefix . 'rank_math_redirections';
		static $rows = null;
		if ($rows === null) {
			$rows = [];
			if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) === $t) {
				foreach ($wpdb->get_results("SELECT sources, url_to, header_code FROM $t WHERE status='active'") as $r) {
					$src = maybe_unserialize($r->sources);
					if (!is_array($src)) continue;
					foreach ($src as $s) {
						if (isset($s['comparison'], $s['pattern']) && $s['comparison'] === 'exact') {
							$rows[trim(strtolower($s['pattern']), '/')] = ((int) $r->header_code === 410) ? '' : $r->url_to;
						}
					}
				}
			}
		}
		$k = trim(strtolower(rawurldecode($path)), '/');
		return array_key_exists($k, $rows) ? $rows[$k] : null;
	}

	/** Resolve a site path to its live URL. Returns '' when it leads nowhere. */
	private function resolve($path, $depth = 0) {
		$key = strtolower($path);
		if (isset($this->cache[$key])) return $this->cache[$key];
		$final = '';
		if ($depth < 5) {
			$full = $this->norm($path);
			$pid = url_to_postid($full);
			if ($pid && get_post_status($pid) === 'publish') {
				$final = get_permalink($pid);
			} else {
				$slugpath = trim($path, '/');
				$cat = $slugpath !== '' ? get_category_by_path($slugpath, false) : null;
				if ($cat && !is_wp_error($cat)) {
					$final = get_category_link($cat);
				} elseif ($slugpath === '') {
					$final = home_url('/');
				}
				if ($final === '') {
					$seg = basename(untrailingslashit($path));
					$old = $seg !== '' ? get_posts(['post_type' => 'any', 'post_status' => 'publish', 'numberposts' => 1, 'fields' => 'ids',
						'meta_query' => [['key' => '_wp_old_slug', 'value' => $seg]]]) : [];
					if ($old) $final = get_permalink($old[0]);
				}
				$rm = $this->rm_target($path);
				if ($rm !== null) {
					if ($rm === '') { $final = ''; }
					else {
						$next = $this->internal_path($rm);
						$final = ($next !== null && $next !== $path) ? $this->resolve($next, $depth + 1) : $rm;
					}
				}
			}
		}
		return $this->cache[$key] = $final;
	}

	/** A link detours when following it costs a redirect: other host form, http, missing slash or moved page. */
	private function is_detour($href, $final) {
		$h = html_entity_decode(trim($href));
		$a = wp_parse_url($h);
		$b = wp_parse_url($final);
		$path_a = rawurldecode($a['path'] ?? '/');
		$path_b = rawurldecode($b['path'] ?? '/');
		if (strtolower($path_a) !== strtolower($path_b)) return true;
		if (empty($a['host'])) return false;
		return strtolower($a['host']) !== strtolower($b['host'] ?? '') || strtolower($a['scheme'] ?? '') !== strtolower($b['scheme'] ?? '');
	}

	/* ---------- step 1: scan / apply / undo ---------- */

	private function scan_batch($offset) {
		global $wpdb;
		$ids = $wpdb->get_col($wpdb->prepare(
			"SELECT ID FROM {$wpdb->posts} WHERE post_status='publish' AND post_type IN ('post','page') ORDER BY ID LIMIT %d OFFSET %d",
			self::BATCH, $offset));
		$scan = get_option(self::OPT_SCAN, []);
		foreach ($ids as $id) {
			$content = get_post_field('post_content', $id, 'raw');
			if (!preg_match_all('~<a\s[^>]*href=(["\'])(.*?)\1~is', $content, $m)) continue;
			foreach (array_unique($m[2]) as $href) {
				$path = $this->internal_path($href);
				if ($path === null) continue;
				$final = $this->resolve($path);
				if ($final === '') {
					$scan['items'][] = ['p' => (int) $id, 'old' => $href, 'new' => '', 't' => 'broken'];
				} elseif ($this->is_detour($href, $final)) {
					$scan['items'][] = ['p' => (int) $id, 'old' => $href, 'new' => $final, 't' => 'detour'];
				}
			}
		}
		$scan['done'] = $offset + count($ids);
		$scan['finished'] = count($ids) < self::BATCH;
		update_option(self::OPT_SCAN, $scan, false);
		return $scan;
	}

	private function apply() {
		global $wpdb;
		$scan = get_option(self::OPT_SCAN, []);
		$by = [];
		foreach ((array) ($scan['items'] ?? []) as $i) if ($i['t'] === 'detour') $by[$i['p']][$i['old']] = $i['new'];
		$posts = 0; $links = 0;
		foreach ($by as $pid => $map) {
			$c = get_post_field('post_content', $pid, 'raw');
			$new = $c; $n = 0;
			foreach ($map as $old => $to) {
				foreach (['"', "'"] as $q) {
					$new = str_replace('href=' . $q . $old . $q, 'href=' . $q . esc_url_raw($to) . $q, $new, $cnt);
					$n += $cnt;
				}
			}
			if ($n && $new !== $c) {
				if (!metadata_exists('post', $pid, self::META_BAK)) add_post_meta($pid, self::META_BAK, wp_slash($c), true);
				$wpdb->update($wpdb->posts, ['post_content' => $new], ['ID' => $pid]);
				clean_post_cache($pid);
				$posts++; $links += $n;
			}
		}
		if (function_exists('litespeed_purge_all')) litespeed_purge_all(); else do_action('litespeed_purge_all');
		$scan['applied'] = ['posts' => $posts, 'links' => $links, 'at' => current_time('mysql')];
		update_option(self::OPT_SCAN, $scan, false);
	}

	private function undo() {
		global $wpdb;
		$rows = $wpdb->get_results($wpdb->prepare("SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key=%s", self::META_BAK));
		foreach ($rows as $r) {
			$wpdb->update($wpdb->posts, ['post_content' => $r->meta_value], ['ID' => $r->post_id]);
			delete_post_meta($r->post_id, self::META_BAK);
			clean_post_cache($r->post_id);
		}
		do_action('litespeed_purge_all');
		$scan = get_option(self::OPT_SCAN, []);
		$scan['undone'] = ['posts' => count($rows), 'at' => current_time('mysql')];
		unset($scan['applied']);
		update_option(self::OPT_SCAN, $scan, false);
	}

	/* ---------- step 2: old language addresses ---------- */

	private function lang_opt() {
		return wp_parse_args(get_option(self::OPT_LANG, []), ['active' => 0, 'keep' => self::KEEP]);
	}

	/** Keep list from settings, plus every language Translator has actually used on this site. */
	private function keep_codes() {
		$o = $this->lang_opt();
		$keep = array_filter(array_map('trim', explode(',', strtolower($o['keep']))));
		$tr = get_transient('lmg_lr_tr_langs');
		if ($tr === false) {
			global $wpdb;
			$tr = array_map('strtolower', (array) $wpdb->get_col($wpdb->prepare("SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key=%s", '_lmgt_lang')));
			set_transient('lmg_lr_tr_langs', $tr, HOUR_IN_SECONDS);
		}
		return array_values(array_unique(array_merge($keep, $tr)));
	}

	/** Never touch an address that belongs to real content, even if WordPress called it a 404. */
	private function is_live($path) {
		if (url_to_postid(home_url($path))) return true;
		$slug = basename(untrailingslashit($path));
		if ($slug === '') return false;
		$hit = get_posts(['post_type' => 'any', 'name' => sanitize_title($slug), 'post_status' => 'publish', 'numberposts' => 1, 'fields' => 'ids']);
		return !empty($hit);
	}

	public function old_language() {
		if (!is_404()) return;
		$path = (string) wp_parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
		if (!preg_match('~^/([a-z]{2,3}(?:-[a-z]{2})?)(/|$)~i', $path, $m)) return;
		$code = strtolower($m[1]);
		$gt   = array_map('trim', explode(',', self::GT_CODES));
		$o    = $this->lang_opt();
		if (!in_array($code, $gt, true) || in_array($code, $this->keep_codes(), true)) return;
		if ($this->is_live($path)) return;
		$log = get_option(self::OPT_LOG, []);
		array_unshift($log, ['t' => current_time('mysql'), 'p' => substr($path, 0, 200), 'a' => $o['active'] ? '410' : 'logged']);
		update_option(self::OPT_LOG, array_slice($log, 0, 200), false);
		if (!$o['active']) return;
		status_header(410);
		nocache_headers();
		header('X-Robots-Tag: noindex');
		echo '<!doctype html><meta charset="utf-8"><title>410</title><p>This page no longer exists. <a href="' . esc_url(home_url('/')) . '">' . esc_html(get_bloginfo('name')) . '</a></p>';
		exit;
	}

	/* ---------- step 3: orphans ---------- */

	private function orphans() {
		global $wpdb;
		$t = $wpdb->prefix . 'rank_math_internal_meta';
		if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) !== $t) return null;
		$ids = array_map('intval', $wpdb->get_col("SELECT p.ID FROM {$wpdb->posts} p JOIN $t m ON m.object_id=p.ID
			WHERE p.post_status='publish' AND p.post_type='post' AND m.incoming_link_count=0 ORDER BY p.ID"));
		// Rank Math only recounts when a hub is saved in the editor, so hide the posts we have already linked.
		return array_values(array_diff($ids, array_map('intval', (array) get_option('lmg_lr_linked', []))));
	}

	private function hub_for($pid) {
		$cats = get_the_category($pid);
		if (!$cats) return ['', ''];
		usort($cats, function ($a, $b) { return count(get_ancestors($b->term_id, 'category')) - count(get_ancestors($a->term_id, 'category')); });
		$c = $cats[0];
		$page = get_page_by_path($c->slug, OBJECT, 'page');
		if (!$page) {
			$q = get_posts(['post_type' => 'page', 'name' => $c->slug, 'post_status' => 'publish', 'numberposts' => 1]);
			$page = $q ? $q[0] : null;
		}
		return [$c->name, $page ? get_permalink($page) : get_category_link($c), $page ? (int) $page->ID : 0];
	}

	/** Why a row should not be linked automatically, or '' when it is safe. */
	private function flag_for($pid, $cat, $hub, $hub_id) {
		if (!$hub) return 'No category, so no hub';
		if (!$hub_id) return 'The hub is a category archive, not a page with text';
		if ($hub_id === (int) $pid) return 'This post is the hub itself';
		$t = mb_strtolower(trim(wp_strip_all_tags(get_the_title($pid))));
		if ($t === mb_strtolower(trim($cat)) || untrailingslashit(get_permalink($pid)) === untrailingslashit($hub)) return 'Same name as its hub: possible duplicate, your call';
		if (get_post_status($hub_id) !== 'publish') return 'The hub page is not published';
		return '';
	}

	private function heading() {
		$l = substr(get_locale(), 0, 2);
		$h = ['da' => 'Læs også', 'sv' => 'Läs också', 'nb' => 'Les også', 'fi' => 'Lue myös', 'de' => 'Lesen Sie auch', 'fr' => 'À lire aussi', 'es' => 'Lee también', 'it' => 'Leggi anche', 'nl' => 'Lees ook'];
		return isset($h[$l]) ? $h[$l] : 'Read more';
	}

	/** Add the given posts to a "Read more" list at the end of the hub's text. Returns the number added. */
	private function link_into_hub($hub_id, $pids) {
		global $wpdb;
		$c = get_post_field('post_content', $hub_id, 'raw');
		$items = '';
		$n = 0;
		foreach ($pids as $pid) {
			$url = get_permalink($pid);
			if (strpos($c, $url) !== false || strpos($c, wp_make_link_relative($url) . '"') !== false) continue;
			$items .= '<li><a href="' . esc_url($url) . '">' . esc_html(wp_strip_all_tags(get_the_title($pid))) . '</a></li>' . "\n";
			$n++;
		}
		if (!$n) return 0;
		if (strpos($c, '<!-- /lmg-lr-related -->') !== false) {
			$new = str_replace('</ul>' . "\n" . '<!-- /lmg-lr-related -->', $items . '</ul>' . "\n" . '<!-- /lmg-lr-related -->', $c);
		} else {
			$new = rtrim($c) . "\n\n" . '<!-- lmg-lr-related -->' . "\n" . '<h2>' . esc_html($this->heading()) . '</h2>' . "\n" . '<ul class="lmg-related">' . "\n" . $items . '</ul>' . "\n" . '<!-- /lmg-lr-related -->';
		}
		if ($new === $c) return 0;
		if (!metadata_exists('post', $hub_id, self::META_HUB)) add_post_meta($hub_id, self::META_HUB, wp_slash($c), true);
		$wpdb->update($wpdb->posts, ['post_content' => $new], ['ID' => $hub_id]);
		clean_post_cache($hub_id);
		return $n;
	}

	private function link_orphans($only) {
		$by = [];
		foreach ((array) $this->orphans() as $pid) {
			if ($only && !in_array((int) $pid, $only, true)) continue;
			[$cat, $hub, $hub_id] = $this->hub_for($pid);
			if ($this->flag_for($pid, $cat, $hub, $hub_id) !== '') continue;
			$by[$hub_id][] = (int) $pid;
		}
		$added = 0;
		$done = (array) get_option('lmg_lr_linked', []);
		foreach ($by as $hub_id => $pids) { $added += $this->link_into_hub($hub_id, $pids); $done = array_merge($done, $pids); }
		update_option('lmg_lr_linked', array_values(array_unique(array_map('intval', $done))), false);
		do_action('litespeed_purge_all');
		update_option('lmg_lr_orphan_msg', 'Linked ' . $added . ' posts from ' . count($by) . ' hubs, ' . current_time('mysql') . '. Undo removes them again.', false);
	}

	private function undo_hubs() {
		global $wpdb;
		$rows = $wpdb->get_results($wpdb->prepare("SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key=%s", self::META_HUB));
		foreach ($rows as $r) {
			$wpdb->update($wpdb->posts, ['post_content' => $r->meta_value], ['ID' => $r->post_id]);
			delete_post_meta($r->post_id, self::META_HUB);
			clean_post_cache($r->post_id);
		}
		delete_option('lmg_lr_linked');
		do_action('litespeed_purge_all');
		update_option('lmg_lr_orphan_msg', 'Undone: ' . count($rows) . ' hubs restored, ' . current_time('mysql') . '.', false);
	}

	/* ---------- handler ---------- */

	public function handle() {
		if (!current_user_can('manage_options')) wp_die('No access');
		check_admin_referer('lmg_lr');
		$do = sanitize_key($_REQUEST['do'] ?? '');
		$tab = 'links';
		switch ($do) {
			case 'scan':
				delete_option(self::OPT_SCAN);
				$this->scan_batch(0);
				break;
			case 'scan_next':
				$s = get_option(self::OPT_SCAN, []);
				$this->scan_batch((int) ($s['done'] ?? 0));
				break;
			case 'apply': $this->apply(); break;
			case 'undo':  $this->undo(); break;
			case 'link_all':  $tab = 'orphans'; $this->link_orphans([]); break;
			case 'link_sel':
				$tab = 'orphans';
				$sel = array_map('intval', (array) ($_POST['pids'] ?? []));
				if ($sel) $this->link_orphans($sel);
				break;
			case 'undo_hubs': $tab = 'orphans'; $this->undo_hubs(); break;
			case 'lang':
				$tab = 'lang';
				update_option(self::OPT_LANG, [
					'active' => empty($_POST['active']) ? 0 : 1,
					'keep'   => sanitize_text_field(wp_unslash($_POST['keep'] ?? self::KEEP)),
				], false);
				break;
			case 'csv_broken':
			case 'csv_orphans':
				$this->csv($do);
				exit;
		}
		wp_safe_redirect(admin_url('tools.php?page=' . self::SLUG . '&tab=' . $tab));
		exit;
	}

	private function csv($which) {
		nocache_headers();
		header('Content-Type: text/csv; charset=utf-8');
		header('Content-Disposition: attachment; filename=' . ($which === 'csv_broken' ? 'broken-links' : 'orphans') . '-' . gmdate('Y-m-d') . '.csv');
		$out = fopen('php://output', 'w');
		if ($which === 'csv_broken') {
			fputcsv($out, ['post_id', 'post_url', 'broken_link']);
			foreach ((array) (get_option(self::OPT_SCAN, [])['items'] ?? []) as $i)
				if ($i['t'] === 'broken') fputcsv($out, [$i['p'], get_permalink($i['p']), $i['old']]);
		} else {
			fputcsv($out, ['post_id', 'title', 'url', 'country_or_category', 'hub_url', 'check_first']);
			foreach ((array) $this->orphans() as $id) {
				[$cat, $hub, $hub_id] = $this->hub_for($id);
				fputcsv($out, [$id, get_the_title($id), get_permalink($id), $cat, $hub, $this->flag_for($id, $cat, $hub, $hub_id)]);
			}
		}
		fclose($out);
	}

	/* ---------- page ---------- */

	/** Raw action URL. wp_nonce_url() returns an HTML-escaped URL, and escaping it again broke the nonce (1.0.0). */
	private function act_url($do) {
		return add_query_arg(['action' => 'lmg_lr', 'do' => $do, '_wpnonce' => wp_create_nonce('lmg_lr')], admin_url('admin-post.php'));
	}

	private function btn($do, $label, $primary = false, $confirm = '') {
		$u = $this->act_url($do);
		$c = $confirm ? ' onclick="return confirm(' . esc_attr(wp_json_encode($confirm)) . ')"' : '';
		return '<a class="button' . ($primary ? ' button-primary' : '') . '" href="' . esc_url($u) . '"' . $c . '>' . esc_html($label) . '</a> ';
	}

	public function page() {
		$tab = sanitize_key($_GET['tab'] ?? 'links');
		$tabs = ['links' => '1. Links that detour', 'lang' => '2. Old language addresses', 'orphans' => '3. Orphan posts'];
		echo '<div class="wrap"><h1>Link repair</h1><nav class="nav-tab-wrapper">';
		foreach ($tabs as $k => $l) echo '<a class="nav-tab' . ($tab === $k ? ' nav-tab-active' : '') . '" href="' . esc_url(admin_url('tools.php?page=' . self::SLUG . '&tab=' . $k)) . '">' . esc_html($l) . '</a>';
		echo '</nav>';
		if ($tab === 'lang') $this->page_lang();
		elseif ($tab === 'orphans') $this->page_orphans();
		else $this->page_links();
		echo '</div>';
	}

	private function page_links() {
		$s = get_option(self::OPT_SCAN, []);
		echo '<p>Finds links inside posts and pages that go through a redirect or end on a dead page. Detours can be pointed straight at the live page; dead links are only listed, for you to decide.</p>';
		echo '<p>' . $this->btn('scan', $s ? 'Scan again' : 'Start scan', !$s) . '</p>';
		if (!$s) return;
		if (empty($s['finished'])) {
			$next = $this->act_url('scan_next');
			echo '<p><strong>Scanning… ' . (int) $s['done'] . ' posts read.</strong> The page continues by itself.</p>';
			echo '<script>setTimeout(function(){location.href=' . wp_json_encode($next) . '},400)</script>';
			return;
		}
		$items = (array) ($s['items'] ?? []);
		$det = array_values(array_filter($items, function ($i) { return $i['t'] === 'detour'; }));
		$brk = array_values(array_filter($items, function ($i) { return $i['t'] === 'broken'; }));
		$pc  = count(array_unique(array_column($det, 'p')));
		echo '<h2>Result: ' . count($det) . ' detours in ' . $pc . ' posts, ' . count($brk) . ' dead links</h2>';
		if (!empty($s['applied'])) echo '<div class="notice notice-success inline"><p>Applied ' . esc_html($s['applied']['at']) . ': ' . (int) $s['applied']['links'] . ' links fixed in ' . (int) $s['applied']['posts'] . ' posts. The old text is kept, so Undo puts it all back.</p></div>';
		if (!empty($s['undone'])) echo '<div class="notice notice-info inline"><p>Undone ' . esc_html($s['undone']['at']) . ': ' . (int) $s['undone']['posts'] . ' posts restored.</p></div>';
		echo '<p>' . $this->btn('apply', 'Apply: fix all ' . count($det) . ' detours', true, 'Fix ' . count($det) . ' links in ' . $pc . ' posts? The original text is saved and Undo restores it.')
			. $this->btn('undo', 'Undo all', false, 'Restore every post changed by Link repair?')
			. $this->btn('csv_broken', 'Download dead links (CSV)') . '</p>';
		echo '<p class="description">Only the link address changes. The post date, text and translations stay as they are. The LiteSpeed cache is purged after Apply.</p>';
		echo '<h3>Preview, first 300 detours</h3><table class="widefat striped"><thead><tr><th>Post</th><th>Now links to</th><th>Will link to</th></tr></thead><tbody>';
		foreach (array_slice($det, 0, 300) as $i) {
			echo '<tr><td><a href="' . esc_url(get_permalink($i['p'])) . '" target="_blank">' . esc_html(get_the_title($i['p'])) . '</a></td><td><code>' . esc_html($i['old']) . '</code></td><td><code>' . esc_html($i['new']) . '</code></td></tr>';
		}
		echo '</tbody></table>';
		echo '<h3>Dead links, first 100</h3><table class="widefat striped"><thead><tr><th>Post</th><th>Dead link</th></tr></thead><tbody>';
		foreach (array_slice($brk, 0, 100) as $i) {
			echo '<tr><td><a href="' . esc_url(get_edit_post_link($i['p'])) . '">' . esc_html(get_the_title($i['p'])) . '</a></td><td><code>' . esc_html($i['old']) . '</code></td></tr>';
		}
		echo '</tbody></table>';
	}

	private function page_lang() {
		$o = $this->lang_opt();
		$log = get_option(self::OPT_LOG, []);
		echo '<p>Old GTranslate addresses like <code>/lt/…</code> or <code>/tr/…</code> still get visits and end on a 404. When switched on, they answer <strong>410 Gone</strong>, which tells Google to drop them for good.</p>';
		echo '<p>Three guards: it only acts on addresses that are already a 404; never on a language in the keep list or any language Translator has used on this site; and never on an address whose last part matches a published post, page or translation.</p>';
		echo '<p>Protected here now: <code>' . esc_html(implode(', ', $this->keep_codes())) . '</code></p>';
		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
		wp_nonce_field('lmg_lr');
		echo '<input type="hidden" name="action" value="lmg_lr"><input type="hidden" name="do" value="lang">';
		echo '<p><label><input type="checkbox" name="active" value="1"' . checked($o['active'], 1, false) . '> Answer 410 (off = only log what would happen)</label></p>';
		echo '<p><label>Keep list<br><input type="text" class="regular-text" name="keep" value="' . esc_attr($o['keep']) . '"></label></p>';
		submit_button('Save');
		echo '</form><h3>Last ' . count($log) . ' hits</h3><table class="widefat striped"><thead><tr><th>Time</th><th>Address</th><th>Action</th></tr></thead><tbody>';
		foreach ($log as $l) echo '<tr><td>' . esc_html($l['t']) . '</td><td><code>' . esc_html($l['p']) . '</code></td><td>' . esc_html($l['a']) . '</td></tr>';
		echo '</tbody></table>';
	}

	private function page_orphans() {
		$ids = $this->orphans();
		if ($ids === null) { echo '<p>Rank Math\'s link table was not found. Turn on the Link Counter module.</p>'; return; }
		$msg = get_option('lmg_lr_orphan_msg');
		if ($msg) echo '<div class="notice notice-success inline"><p>' . esc_html($msg) . '</p></div>';
		$rows = []; $ok = 0;
		foreach ($ids as $id) {
			[$cat, $hub, $hub_id] = $this->hub_for($id);
			$flag = $this->flag_for($id, $cat, $hub, $hub_id);
			if ($flag === '') $ok++;
			$rows[] = [$id, $cat, $hub, $flag];
		}
		echo '<p><strong>' . count($ids) . ' published posts have no link pointing to them.</strong> Link repair adds each one to a short "' . esc_html($this->heading()) . '" list at the end of its hub\'s text. It adds the list once per hub and extends it later, and it never removes anything.</p>';
		echo '<p>' . $ok . ' can be linked now. ' . (count($ids) - $ok) . ' are marked "check first" for you to decide, and are never linked automatically.</p>';
		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
		wp_nonce_field('lmg_lr');
		echo '<input type="hidden" name="action" value="lmg_lr"><input type="hidden" name="do" value="link_sel">';
		echo '<p><button class="button button-primary" onclick="return confirm(\'Add the ticked posts to their hubs?\')">Link ticked posts</button> '
			. $this->btn('link_all', 'Link all ' . $ok, false, 'Add all ' . $ok . ' posts to their hubs? Undo removes them again.')
			. $this->btn('undo_hubs', 'Undo hub links', false, 'Restore every hub changed here?')
			. $this->btn('csv_orphans', 'Download list (CSV)') . '</p>';
		echo '<table class="widefat striped"><thead><tr><td class="check-column"><input type="checkbox" onclick="document.querySelectorAll(\'.lmg-pid\').forEach(c=>c.checked=this.checked)"></td><th>Post</th><th>Country / category</th><th>Hub to link from</th><th>Check first</th></tr></thead><tbody>';
		foreach ($rows as [$id, $cat, $hub, $flag]) {
			$box = $flag === '' ? '<input type="checkbox" class="lmg-pid" name="pids[]" value="' . (int) $id . '">' : '';
			echo '<tr><th class="check-column">' . $box . '</th><td><a href="' . esc_url(get_permalink($id)) . '" target="_blank">' . esc_html(get_the_title($id)) . '</a></td><td>' . esc_html($cat) . '</td><td>' . ($hub ? '<a href="' . esc_url($hub) . '" target="_blank">' . esc_html(wp_parse_url($hub, PHP_URL_PATH)) . '</a>' : '–') . '</td><td>' . ($flag ? '<strong style="color:#b32d2e">' . esc_html($flag) . '</strong>' : '') . '</td></tr>';
		}
		echo '</tbody></table></form>';
	}
}

LMG_Link_Repair::boot();
