<?php
/**
 * Plugin Name: LMG Post Grid
 * Description: Post grids (Kadence Posts blocks, e.g. Travel News, Rejsenyt): each preview is cut to 3 lines; the Travel News page shows no sidebar. Same file on traveltalk.dk and traveltalk.travel.
 * Version:     1.0.2
 * Author:      Leisure Media Group
 * Requires at least: 6.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;

// Shielded so LiteSpeed/QUIC optimisation does not strip or defer it (G, 2 Nov 2026).
add_action( 'wp_head', function () {
	echo '<style id="tt-kb-posts-clamp" data-no-optimize="1" data-no-defer="1" data-no-minify="1">.kb-posts .entry-summary{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}.kb-posts .entry-summary p{margin:0}</style>';
}, 2 );

// 1.0.1: the Travel News page (post grid) has no sidebar; the grid takes the full width. Articles and other pages (e.g. Europe) keep theirs (G, 2 Nov 2026).
add_action( 'wp_head', function () {
	if ( ! is_page( 'travel-news' ) ) return;
	echo '<style id="tt-travel-news-nosidebar" data-no-optimize="1" data-no-defer="1" data-no-minify="1">body.has-sidebar #secondary{display:none!important}body.has-sidebar .content-container{grid-template-columns:100%!important}</style>';
}, 2 );

// 1.0.2: a post without a hand-written excerpt gets its preview from its own paragraphs, read directly.
// On the traveltalk.travel front page another plugin adds the hero ("Travel with soul" and its titles)
// to every post's text, and WordPress's own preview picked that up (G, 2 Nov 2026).
function lmg_post_grid_excerpt( $text, $post = null ) {
	if ( $text !== '' || is_admin() ) return $text;
	$post = get_post( $post );
	if ( ! $post ) return $text;
	$html = strip_shortcodes( preg_replace( '#<h[1-6][^>]*>.*?</h[1-6]>#is', ' ', $post->post_content ) );
	$body = preg_match_all( '#<p[^>]*>(.*?)</p>#is', $html, $m ) ? implode( ' ', $m[1] ) : $html;
	$plain = trim( preg_replace( '/\s+/u', ' ', html_entity_decode( wp_strip_all_tags( $body ), ENT_QUOTES, 'UTF-8' ) ) );
	return $plain === '' ? $text : wp_trim_words( $plain, 40, '…' );
}
add_filter( 'get_the_excerpt', 'lmg_post_grid_excerpt', 9, 2 );
