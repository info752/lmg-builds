<?php
/**
 * Plugin Name: LMG Concierge
 * Description: A first-party concierge in the lower-right corner. Answers readers' questions in conversation — freely where the answer is judgment, from the site's own published articles where it is a claim — and links the piece it answered from. One codebase, one JSON config per site; the persona on traveltalk.dk is Aianna. The browser never talks to the model: a thin server-side layer holds the key, the rate limit and the monthly ceiling.
 * Version:     0.9.2
 * Author:      LMG
 * License:     GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// The assets have STABLE filenames and carry the version as ?ver=. Bump this
// constant alone; nothing is renamed, and nothing 404s.
//
// This reverses the rule that stood here until 15 Sep 2026, which put the version
// in the filenames because "this stack strips ?ver=". REMEASURED against
// production the same day, and that is not true: the edge treats the query as
// part of the cache key (x-qc-cache miss on a new ?ver=, hit on a repeat, miss
// again on a different one), and LiteSpeed ships its own combined CSS as
// ...css?ver=f02bb, so query strings survive the HTML rewrite too. Browsers key
// on the full URL, so a new ?ver= is a new entry however long the max-age is —
// and it is a year here.
//
// The old rule made every release a three-file rename that had to land in the
// same deploy as this constant, or the panel 404d for every reader. That is a
// real risk repeated on every release, and it bought nothing.
define( 'LMG_CONCIERGE_VERSION', '0.9.2' );
define( 'LMG_CONCIERGE_DIR', plugin_dir_path( __FILE__ ) );
define( 'LMG_CONCIERGE_URL', plugin_dir_url( __FILE__ ) );
// A year, not a quarter. Ninety days answers "what is being asked this month";
// it cannot answer "is this growing", and growth is the question the log exists
// to settle (G, 4 Oct 2026: "3 months is not enough to track dev"). A year also
// carries a full season cycle, so October's ski questions can be read against
// last October's rather than against August's. The row itself is unchanged —
// still no IP, no user agent, no user id, no cross-visit identifier, and still
// rounded to the hour — so holding it longer widens the window, not the record.
define( 'LMG_CONCIERGE_RETENTION_DAYS', 365 );

// The portrait's shape, in ONE place. The card renders 80 × 106 CSS pixels, so
// the stills are that ratio at 2x, 1x and large. Change this pair and the three
// registered sizes follow; nothing else encodes the shape.
//
// Provisional, 4 Oct 2026 — taken from the card's own dimensions because that is
// what the live set matches. G is sending the cut spec; when it lands this is the
// line it changes.
define( 'LMG_CONCIERGE_FACE_W', 312 );
define( 'LMG_CONCIERGE_FACE_H', 413 );

require_once LMG_CONCIERGE_DIR . 'includes/class-lmg-concierge-config.php';
require_once LMG_CONCIERGE_DIR . 'includes/class-lmg-concierge-retrieval.php';
require_once LMG_CONCIERGE_DIR . 'includes/class-lmg-concierge-guard.php';
require_once LMG_CONCIERGE_DIR . 'includes/class-lmg-concierge-log.php';
require_once LMG_CONCIERGE_DIR . 'includes/class-lmg-concierge-model.php';
require_once LMG_CONCIERGE_DIR . 'includes/class-lmg-concierge-catalogue.php';
require_once LMG_CONCIERGE_DIR . 'includes/class-lmg-concierge-admin.php';
require_once LMG_CONCIERGE_DIR . 'includes/class-lmg-concierge-keepsake.php';
require_once LMG_CONCIERGE_DIR . 'includes/class-lmg-concierge-band.php';
require_once LMG_CONCIERGE_DIR . 'includes/class-lmg-concierge-partners.php';
LMG_Concierge_Partners::boot();

// -----------------------------------------------------------------------------
// Activation
// -----------------------------------------------------------------------------

register_activation_hook( __FILE__, function () {
	LMG_Concierge_Log::install();
	LMG_Concierge_Keepsake::install();
	if ( ! wp_next_scheduled( 'lmg_concierge_prune' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'lmg_concierge_prune' );
	}
	// The demand digest. Weekly, and silent unless something crossed the bar.
	if ( ! wp_next_scheduled( 'lmg_concierge_weekly_demand' ) ) {
		wp_schedule_event( time() + 2 * HOUR_IN_SECONDS, 'weekly', 'lmg_concierge_weekly_demand' );
	}
	// Default to admins-only so activation never puts a bubble in front of readers.
	if ( get_option( 'lmg_concierge_visibility', null ) === null ) add_option( 'lmg_concierge_visibility', 'admins' );
} );

register_deactivation_hook( __FILE__, function () {
	wp_clear_scheduled_hook( 'lmg_concierge_prune' );
	wp_clear_scheduled_hook( 'lmg_concierge_weekly_demand' );
	wp_clear_scheduled_hook( 'lmg_concierge_warm' );
} );

add_action( 'lmg_concierge_prune', function () {
	LMG_Concierge_Log::prune( LMG_CONCIERGE_RETENTION_DAYS );
	// A saved answer expires on a promise made to the reader, so the sweep is not optional.
	LMG_Concierge_Keepsake::prune();
} );

// Cut from whatever is uploaded, so one picture in the media library is a whole
// avatar. Hard-cropped: a portrait that letterboxes in the card defeats the point.
add_action( 'after_setup_theme', function () {
	$w = (int) LMG_CONCIERGE_FACE_W;
	$h = (int) LMG_CONCIERGE_FACE_H;
	add_image_size( 'lmgc-face-156', (int) round( $w / 2 ), (int) round( $h / 2 ), true );
	add_image_size( 'lmgc-face-312', $w, $h, true );
	add_image_size( 'lmgc-face-480', (int) round( $w * 1.538 ), (int) round( $h * 1.538 ), true );
} );

add_action( 'plugins_loaded', array( 'LMG_Concierge_Log', 'maybe_upgrade' ) );

/**
 * The five questions, landing in the same table as everything else.
 *
 * lmg-match announces its events; this turns a finished run into a row of the
 * shape the readout already understands — the facets in `question`, the
 * articles in `source_ids`. The conversation token is derived from Match's own
 * session so the row passes the real-traffic filter and the turns of one run
 * stitch together, and it is a one-way hash of a value that is itself random
 * and tab-scoped: nothing about a person goes in, so nothing comes out.
 */
add_action( 'lmg_match_event', function ( $event, $config, $session, $data ) {
	lmg_concierge_absorb_match( $event, $config, $session, $data );
}, 10, 4 );

/**
 * The same bridge, without needing lmg-match to be updated at all.
 *
 * lmg-match fires lmg_match_event as of 4 Oct 2026, but shipping that means a
 * second plugin in the deploy, and a second plugin is a second thing to get
 * wrong on a live site by someone who has ten minutes. This watches its REST
 * route instead, so the concierge alone carries the change.
 *
 * Both paths are kept: the action is the clean one and wins where lmg-match is
 * current, and the guard below means the row is written once either way.
 */
add_filter( 'rest_request_after_callbacks', function ( $response, $handler, $request ) {
	if ( ! is_a( $request, 'WP_REST_Request' ) ) return $response;
	if ( $request->get_route() !== '/lmg-match/v1/event' ) return $response;
	if ( is_wp_error( $response ) ) return $response;

	$body = $request->get_json_params();
	if ( ! is_array( $body ) ) return $response;

	$event = isset( $body['event'] ) ? sanitize_key( $body['event'] ) : '';
	$data  = isset( $body['data'] ) && is_array( $body['data'] ) ? $body['data'] : array();
	lmg_concierge_absorb_match(
		$event,
		isset( $body['config'] ) ? (string) $body['config'] : '',
		isset( $body['session'] ) ? (string) $body['session'] : '',
		$data
	);
	return $response;
}, 10, 3 );

function lmg_concierge_absorb_match( $event, $config, $session, $data ) {
	if ( $event !== 'result' ) return;

	// Written once, however many routes reported it. The key is the run, not the
	// request: lmg-match's action and this plugin's REST watcher both fire for the
	// same POST, and a demand table that counted each finished run twice would be
	// worse than one that counted none.
	static $seen = array();
	$once = md5( (string) $config . '|' . (string) $session );
	if ( isset( $seen[ $once ] ) ) return;
	$seen[ $once ] = true;

	$cfg = LMG_Concierge_Config::get();

	$parts = array();
	foreach ( (array) ( isset( $data['answers'] ) ? $data['answers'] : array() ) as $facet => $values ) {
		if ( ! is_array( $values ) ) continue;
		$parts[] = sanitize_key( $facet ) . '=' . implode( ',', array_map( 'sanitize_key', array_slice( $values, 0, 8 ) ) );
	}
	if ( ! $parts ) return;

	LMG_Concierge_Log::write( array(
		'site'         => $cfg['id'],
		'conversation' => 'c' . substr( hash_hmac( 'sha256', 'match:' . $session, wp_salt( 'auth' ) ), 0, 13 ),
		'kind'         => 'match',
		'question'     => trim( sanitize_text_field( (string) $config ) . ' | ' . implode( ' · ', $parts ) ),
		'coverage'     => ! empty( $data['thin'] ) ? 'partial' : 'covered',
		'source_ids'   => isset( $data['ids'] ) ? array_slice( (array) $data['ids'], 0, 4 ) : null,
		'variant'      => isset( $data['variant'] ) ? substr( sanitize_key( $data['variant'] ), 0, 32 ) : null,
		'status'       => 'ok',
	) );
}

LMG_Concierge_Admin::boot();
LMG_Concierge_Band::boot();
LMG_Concierge_Keepsake::boot();

// -----------------------------------------------------------------------------
// Front end — the bubble, and nothing else, until the reader touches it
// -----------------------------------------------------------------------------

/**
 * Performance budget (brief §6): one small deferred script in the footer draws
 * the bubble; its styles are a few hundred bytes inline. The panel's script,
 * stylesheet and the animated face are fetched on first interaction (prefetched
 * on hover/focus). No framework, no render-blocking request, no cookie.
 */
add_action( 'wp_enqueue_scripts', function () {
	if ( is_admin() || is_feed() || is_embed() ) return;
	if ( ! LMG_Concierge_Config::visible_to_current_user() ) return;
	// Inline placement loads no script at all on page load; see the inline section below.
	if ( lmg_concierge_is_inline() ) return;
	if ( LMG_Concierge_Partners::is_partner_page() ) return; // 0.9.0: no reader bubble on the partner page

	$v = LMG_CONCIERGE_VERSION;
	// $ver, not a filename: WordPress appends ?ver=, which is what busts the cache.
	wp_enqueue_script( 'lmg-concierge-boot', LMG_CONCIERGE_URL . 'assets/lmg-concierge-boot.js', array(), $v, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	// Registered, not enqueued: the boot script loads these on demand by URL.
	wp_register_style( 'lmg-concierge', LMG_CONCIERGE_URL . 'assets/lmg-concierge.css', array(), $v );
	wp_register_script( 'lmg-concierge-panel', LMG_CONCIERGE_URL . 'assets/lmg-concierge-panel.js', array(), $v, true );
}, 20 );

/** Keep LiteSpeed's combine/UCSS/defer pipeline off these files (house lesson). */
add_filter( 'script_loader_tag', function ( $tag, $handle ) {
	if ( strpos( $handle, 'lmg-concierge' ) === 0 ) $tag = str_replace( '<script ', '<script data-no-optimize="1" ', $tag );
	return $tag;
}, 10, 2 );
add_filter( 'style_loader_tag', function ( $tag, $handle ) {
	if ( strpos( $handle, 'lmg-concierge' ) === 0 ) $tag = str_replace( '<link ', '<link data-no-optimize="1" ', $tag );
	return $tag;
}, 10, 2 );

/** The mount point: config for the browser, asset URLs, page context. */
add_action( 'wp_footer', function () {
	if ( is_admin() || is_feed() || is_embed() ) return;
	if ( ! LMG_Concierge_Config::visible_to_current_user() ) return;
	$inline = lmg_concierge_is_inline();
	// Inline: the data block only where the_content actually drew a card.
	if ( $inline && ! lmg_concierge_inline_rendered() ) return;

	$v    = LMG_CONCIERGE_VERSION;
	$cfg  = LMG_Concierge_Config::public_config();
	$post = is_singular() ? get_post() : null;

	// The avatar file set is per site, not per build: config `assets.prefix`
	// names it (`aianna-*` on traveltalk, `bottiglia-*` on winetalk). Default
	// stays 'aianna' so an older config keeps working unchanged.
	$full = LMG_Concierge_Config::get();
	$ap   = isset( $full['assets']['prefix'] ) ? LMG_Concierge_Config::safe_file( $full['assets']['prefix'] ) : '';
	if ( $ap === '' ) $ap = 'aianna';

	// A portrait chosen in the media library wins over the file set below.
	//
	// The file set is six hand-cut files that have to sit INSIDE the plugin
	// directory, which the media library cannot write to — so changing a face
	// meant FTP and somebody with server access, and Kai sat unbuilt for a month
	// behind a broken image for exactly that reason. One upload in wp-admin is
	// now enough: the three stills come from WordPress's own sizes, and the turn
	// clip is optional. Nothing is required of the file set, and a site that
	// already has one keeps using it untouched.
	$av = LMG_Concierge_Config::avatar();

	$data = array(
		'config'   => $cfg,
		'assets'   => array(
			// These two are NOT enqueued — the boot script injects them by URL when
			// the reader first touches the panel — so WordPress never gets to append
			// ?ver= for us and it has to be added here by hand. Miss this and the
			// panel is the one asset a version bump cannot reach.
			'css'       => add_query_arg( 'ver', $v, LMG_CONCIERGE_URL . 'assets/lmg-concierge.css' ),
			'panel'     => add_query_arg( 'ver', $v, LMG_CONCIERGE_URL . 'assets/lmg-concierge-panel.js' ),
			// The turn-and-hold set, cut 6 Sep 2026 from the second Midjourney
			// clip: she is three-quarter away at the start, turns, and settles
			// facing the reader. Plays ONCE and holds on that last frame — no
			// loop, because a loop would snap her back to looking away.
			'turn'       => $av ? $av['turn'] : LMG_CONCIERGE_URL . "assets/img/{$ap}-turn-312.mp4",
			'turnPoster' => $av ? $av['face'] : LMG_CONCIERGE_URL . "assets/img/{$ap}-turn-poster-312.jpg",
			'turnPoster1x' => $av ? $av['face1x'] : LMG_CONCIERGE_URL . "assets/img/{$ap}-turn-poster-156.jpg",
			// Where the turn ends: her looking at you. Also the reduced-motion still.
			'face'      => $av ? $av['face'] : LMG_CONCIERGE_URL . "assets/img/{$ap}-face-312.jpg",
			'face1x'    => $av ? $av['face1x'] : LMG_CONCIERGE_URL . "assets/img/{$ap}-face-156.jpg",
			'faceLarge' => $av ? $av['faceLarge'] : LMG_CONCIERGE_URL . "assets/img/{$ap}-face-480.jpg",
		),
		'endpoint' => array(
			'ask'   => esc_url_raw( rest_url( 'lmg-concierge/v1/ask' ) ),
			'event' => esc_url_raw( rest_url( 'lmg-concierge/v1/event' ) ),
			'save'  => esc_url_raw( rest_url( 'lmg-concierge/v1/save' ) ),
		),
		// LMG Match, if installed: the question sets she can run herself. The engine
		// is deliberately headless (describe/recommend), so she is a second front
		// door to the SAME ranking — not a second recommender.
		'match' => lmg_concierge_match_sets(),
		// REST nonce for logged-in users (cookie auth requires it); empty for readers.
		'nonce' => is_user_logged_in() ? wp_create_nonce( 'wp_rest' ) : '',
		// The page is content, not a visitor identifier.
		'page' => array(
			'id'      => $post ? (int) $post->ID : 0,
			'title'   => $post ? html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ) : '',
			'url'     => $post ? get_permalink( $post ) : home_url( add_query_arg( array() ) ),
			// The front page carries her top-right inside the .tt-hero photo instead of
			// the fixed corner (G, 6 Sep 2026 — balances the H1 line). Boot script falls
			// back to the normal fixed placement if that container isn't there to find.
			'isFront' => is_front_page(),
		),
	);
	if ( ! $inline ) echo '<div id="lmg-concierge" hidden></div>' . "\n";
	echo '<script type="application/json" id="lmg-concierge-data">' . wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ) . '</script>' . "\n";
	if ( $inline ) lmg_concierge_inline_loader();
}, 50 );

// -----------------------------------------------------------------------------
// Inline placement — traveltalk.dk and traveltalk.travel
//
// The card sits after the article on every post and page, not in the corner,
// and never on the front page, archives or search. It is static HTML plus a
// few lines of inline CSS. No plugin script is enqueued: a ~600-byte inline
// click handler injects the panel's CSS and JS on the first click of
// "Spørg Aianna". The boot script and the turn clip are not used here.
//
// On by default for traveltalk.dk and traveltalk.travel; config `placement` ("inline" | "corner")
// overrides it for any site. Opt-out per post or page:
// `wp post meta update <ID> _lmg_concierge_hide 1 --allow-root`.
// -----------------------------------------------------------------------------

function lmg_concierge_is_inline() {
	$cfg = LMG_Concierge_Config::get();
	if ( isset( $cfg['placement'] ) ) return $cfg['placement'] === 'inline';
	return isset( $cfg['site'] ) && in_array( $cfg['site'], array( 'traveltalk.dk', 'traveltalk.travel' ), true );
}

/** Is this request a single post or page that should carry the inline card? */
function lmg_concierge_inline_here() {
	if ( is_admin() || is_feed() || is_embed() ) return false;
	if ( ! lmg_concierge_is_inline() ) return false;
	if ( ! is_singular( array( 'post', 'page' ) ) || is_front_page() ) return false;
	if ( ! LMG_Concierge_Config::visible_to_current_user() ) return false;
	if ( LMG_Concierge_Partners::is_partner_page() ) return false; // 0.9.0: the partner chat has the page
	return ! get_post_meta( get_queried_object_id(), '_lmg_concierge_hide', true );
}

/**
 * The front-page band ([aianna] / [lmg_concierge_band] in the homepage content)
 * renders nothing while inline placement is on: no markup, no inline CSS/JS.
 * The homepage content is left untouched, so switching placement back to
 * "corner" restores the band as it was.
 */
add_filter( 'pre_do_shortcode_tag', function ( $out, $tag ) {
	if ( $tag !== 'aianna' && $tag !== 'lmg_concierge_band' ) return $out;
	if ( is_front_page() && lmg_concierge_is_inline() ) return '';
	return $out;
}, 10, 2 );

/** Set once by the_content when the card is drawn; read by wp_footer. */
function lmg_concierge_inline_rendered( $set = false ) {
	static $done = false;
	if ( $set ) $done = true;
	return $done;
}

/** The card's styles: a few hundred bytes, in <head>, only where the card can appear. */
add_action( 'wp_head', function () {
	if ( ! lmg_concierge_inline_here() ) return;
	$cfg    = LMG_Concierge_Config::get();
	$accent = isset( $cfg['accent'] ) ? sanitize_hex_color( $cfg['accent'] ) : '';
	if ( ! $accent ) $accent = '#B8956A';
	echo '<style id="lmg-concierge-inline-css" data-no-optimize="1">'
		. '.lmgc-inline{display:flex;align-items:center;gap:14px;clear:both;margin:1.5em 0;padding:10px 14px;background:#FAFAF7;border:1px solid #E6E3DC;border-radius:12px;font-family:"Inter",-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}'
		. '.lmgc-inline .lmgc-inline__face{flex:0 0 auto;display:block;width:48px;height:64px;max-width:none;margin:0;border-radius:8px;object-fit:cover;object-position:50% 40%;background:#ECEAE4}'
		. '.lmgc-inline .lmgc-inline__text{flex:1 1 auto;min-width:0;margin:0;font-size:14px;line-height:1.45;color:#3a3a40}'
		. '.lmgc-inline .lmgc-inline__text strong{color:#252528;font-weight:600}'
		. '@media (max-width:600px){.lmgc-inline{flex-wrap:wrap}.lmgc-inline .lmgc-inline__text{flex-basis:calc(100% - 62px)}.lmgc-inline .lmgc-inline__ask{margin-left:62px}}'
		. '.lmgc-inline__ask{flex:0 0 auto;white-space:nowrap;display:inline-block;margin:0;padding:8px 18px;border:0;border-radius:999px;background:' . $accent . ';color:#252528;font:inherit;font-size:14px;font-weight:600;line-height:1.3;cursor:pointer}'
		. '.lmgc-inline__ask:hover,.lmgc-inline__ask:focus-visible{filter:brightness(.94);outline:2px solid ' . $accent . ';outline-offset:2px}'
		. '.lmgc-inline__ask[disabled]{opacity:.7;cursor:progress}'
		. '</style>' . "\n";
}, 20 );

/** At the end of the post content, above the Leisure Family block. */
add_filter( 'the_content', function ( $content ) {
	if ( ! in_the_loop() || ! is_main_query() ) return $content;
	if ( lmg_concierge_inline_rendered() || ! lmg_concierge_inline_here() ) return $content;
	if ( (int) get_the_ID() !== (int) get_queried_object_id() ) return $content;

	$full = LMG_Concierge_Config::get();
	$p    = isset( $full['persona'] ) ? $full['persona'] : array();
	$name = isset( $p['name'] ) ? $p['name'] : 'Aianna';
	$tag  = isset( $p['tagline'] ) ? $p['tagline'] : '';
	$ap   = isset( $full['assets']['prefix'] ) ? LMG_Concierge_Config::safe_file( $full['assets']['prefix'] ) : '';
	if ( $ap === '' ) $ap = 'aianna';
	// Same source as the footer: a media-library portrait wins over the file set.
	$av   = LMG_Concierge_Config::avatar();
	$img1 = $av ? $av['face1x'] : LMG_CONCIERGE_URL . "assets/img/{$ap}-face-156.jpg";
	$img2 = $av ? $av['face'] : LMG_CONCIERGE_URL . "assets/img/{$ap}-face-312.jpg";
	$alt  = isset( $full['ui']['bubbleAlt'] ) ? $full['ui']['bubbleAlt'] : $name;
	// Button label in the site's language: Danish on traveltalk.dk, English on traveltalk.travel.
	$da   = isset( $full['locale'] ) ? strpos( $full['locale'], 'da' ) === 0 : true;
	$ask  = ( $da ? 'Spørg ' : 'Ask ' ) . $name;
	// What she does, then the five questions. DRAFT copy for G's approval
	// (15 Oct 2026); override per site with ui.inlineText / ui.inlineMatchText
	// in the config, {name} and {site} are filled in. The match line promises
	// "many destinations" because the five questions exist only where
	// lmg-match has a set — she offers them when the page or the reader's
	// question names one.
	$site = isset( $full['site'] ) ? $full['site'] : '';
	$ui   = isset( $full['ui'] ) ? $full['ui'] : array();
	// Two lines at most (G, 15 Oct 2026): the longer pitch waits until there
	// are partner links to offer and a bigger section earns its space.
	$t1   = ! empty( $ui['inlineText'] ) ? $ui['inlineText'] : ( $da
		? 'Spørg om rejsemål, rejsetid og oplevelser'
		: ( strpos( $site, 'sport' ) !== false ? 'Ask about teams, players, rules and the big events' : 'Ask about destinations, when to go and what to do' ) );
	$t2   = ! empty( $ui['inlineMatchText'] ) ? $ui['inlineMatchText'] : ( $da
		? ' – ved mange rejsemål også med fem hurtige spørgsmål.'
		: ' – for many destinations also through five quick questions.' );
	$fill = array( '{name}' => $name, '{site}' => $site );
	$t1   = strtr( $t1, $fill );
	// No Match installed = no five questions to offer, so no line promising them.
	$t2   = lmg_concierge_match_sets() ? strtr( $t2, $fill ) : '.';
	// Værktøjer → Aianna-kort wins over both the config and the defaults.
	$o_text = trim( (string) get_option( 'lmg_concierge_card_text', '' ) );
	if ( $o_text !== '' ) { $t1 = strtr( $o_text, $fill ); $t2 = ''; }
	$o_head = trim( (string) get_option( 'lmg_concierge_card_head', '' ) );
	$o_btn  = trim( (string) get_option( 'lmg_concierge_card_button', '' ) );
	if ( $o_btn !== '' ) $ask = strtr( $o_btn, $fill );

	lmg_concierge_inline_rendered( true );

	$card = '<aside class="lmgc-inline" aria-label="' . esc_attr( $alt ) . '">'
		. '<img class="lmgc-inline__face" src="' . esc_url( $img1 ) . '" srcset="' . esc_url( $img1 ) . ' 1x, ' . esc_url( $img2 ) . ' 2x" width="48" height="64" alt="' . esc_attr( $alt ) . '" loading="lazy" decoding="async">'
		. '<div class="lmgc-inline__text"><strong>' . esc_html( $o_head !== '' ? strtr( $o_head, $fill ) : $name . ( $tag ? ', ' . $tag : '' ) . '.' ) . '</strong> ' . esc_html( $t1 . $t2 ) . '</div>'
		. '<button type="button" class="lmgc-inline__ask" aria-haspopup="dialog" aria-expanded="false">' . esc_html( $ask ) . '</button>'
		. '</aside>';

	// 0.9.2 (G, 14 Nov 2026): at the end of the text, never near the top, where
	// she competed with the top widget. Priority 999 keeps her just above the
	// Leisure Family block, which LMG Leisure Family adds at 1000.
	return $content . $card;
}, 999 );

/**
 * The only script an inline page carries: on first click it injects the panel's
 * CSS and JS (URLs from the data block) and opens it. data-no-optimize so the
 * cache plugin's JS delay never holds back the click.
 */
/**
 * Værktøjer → Aianna-kort: the card's words, editable without a deploy.
 * Empty field = the built-in default. Saving purges LiteSpeed so the change
 * shows at once.
 */
add_action( 'admin_menu', function () {
	add_management_page( 'Aianna-kort', 'Aianna-kort', 'manage_options', 'lmg-concierge-card', 'lmg_concierge_card_page' );
} );
add_action( 'admin_init', function () {
	foreach ( array( 'lmg_concierge_card_head', 'lmg_concierge_card_text', 'lmg_concierge_card_button' ) as $k ) {
		register_setting( 'lmg_concierge_card', $k, array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ) );
	}
} );
add_action( 'update_option', function ( $option ) {
	if ( strpos( $option, 'lmg_concierge_card_' ) === 0 ) do_action( 'litespeed_purge_all' );
} );

function lmg_concierge_card_page() {
	if ( ! current_user_can( 'manage_options' ) ) return;
	$full = LMG_Concierge_Config::get();
	$name = isset( $full['persona']['name'] ) ? $full['persona']['name'] : 'Aianna';
	$tag  = isset( $full['persona']['tagline'] ) ? $full['persona']['tagline'] : '';
	$da   = isset( $full['locale'] ) ? strpos( $full['locale'], 'da' ) === 0 : true;
	$defaults = array(
		'lmg_concierge_card_head'   => $name . ( $tag ? ', ' . $tag : '' ) . '.',
		'lmg_concierge_card_text'   => $da ? 'Spørg om rejsemål, rejsetid og oplevelser – ved mange rejsemål også med fem hurtige spørgsmål.' : ( isset( $full['site'] ) && strpos( $full['site'], 'sport' ) !== false ? 'Ask about teams, players, rules and the big events.' : 'Ask about destinations, when to go and what to do – for many destinations also through five quick questions.' ),
		'lmg_concierge_card_button' => ( $da ? 'Spørg ' : 'Ask ' ) . $name,
	);
	$labels = array(
		'lmg_concierge_card_head'   => 'Overskrift (fed)',
		'lmg_concierge_card_text'   => 'Tekst',
		'lmg_concierge_card_button' => 'Knap',
	);
	echo '<div class="wrap"><h1>Aianna-kort</h1><p>Teksten på kortet efter første afsnit i artikler og sider. Tomt felt = standardteksten, som står i feltet i grå. Hold det til to linjer på computer. <code>{name}</code> bliver til personaens navn, <code>{site}</code> til sitets adresse.</p>';
	echo '<form method="post" action="options.php">';
	settings_fields( 'lmg_concierge_card' );
	echo '<table class="form-table">';
	foreach ( $labels as $k => $label ) {
		$v = get_option( $k, '' );
		$tag_name = $k === 'lmg_concierge_card_text' ? 'textarea' : 'input';
		echo '<tr><th><label for="' . esc_attr( $k ) . '">' . esc_html( $label ) . '</label></th><td>';
		if ( $tag_name === 'textarea' ) {
			echo '<textarea id="' . esc_attr( $k ) . '" name="' . esc_attr( $k ) . '" rows="3" class="large-text" placeholder="' . esc_attr( $defaults[ $k ] ) . '">' . esc_textarea( $v ) . '</textarea>';
		} else {
			echo '<input id="' . esc_attr( $k ) . '" name="' . esc_attr( $k ) . '" type="text" class="regular-text" value="' . esc_attr( $v ) . '" placeholder="' . esc_attr( $defaults[ $k ] ) . '">';
		}
		echo '</td></tr>';
	}
	echo '</table>';
	submit_button( 'Gem' );
	echo '</form></div>';
}

function lmg_concierge_inline_loader() {
	echo '<script data-no-optimize="1">(function(w,d){'
		. 'var b=d.querySelector(".lmgc-inline__ask"),n=d.getElementById("lmg-concierge-data");if(!b||!n)return;'
		. 'var D;try{D=JSON.parse(n.textContent)}catch(e){return}var L=null;'
		. 'function load(){if(w.LMGConcierge)return Promise.resolve(w.LMGConcierge);if(L)return L;'
		. 'L=new Promise(function(ok,no){var l=d.createElement("link");l.rel="stylesheet";l.href=D.assets.css;l.setAttribute("data-no-optimize","1");d.head.appendChild(l);'
		. 'var s=d.createElement("script");s.src=D.assets.panel;s.setAttribute("data-no-optimize","1");'
		. 's.onload=function(){w.LMGConcierge?ok(w.LMGConcierge):no()};s.onerror=function(){L=null;no()};d.head.appendChild(s)});return L}'
		. 'b.addEventListener("click",function(){b.disabled=true;load().then(function(P){P.open(D,{bubble:b})})["catch"](function(){}).then(function(){b.disabled=false})})'
		. '})(window,document);</script>' . "\n";
}

// -----------------------------------------------------------------------------
// REST — the thin service
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// DEMAND ALERT — the loop that turns questions into decisions
//
// The log has always held the answer to "what do readers keep asking that we
// have not written", but only as 40 raw rows on an admin screen nobody opens.
// G, 9 Sep 2026: "if we have 10 or 100 searches for hotels in Marbella … where
// does the alert turn up? So I can decide to write one or hook up with a partner
// or not." So it now comes to him: a weekly mail that stays quiet unless a topic
// actually crosses the bar.
//
// WP-Cron, not system cron, and that is measured, not preferred: these Hostinger
// accounts have no cron spool and no writable path outside the webroot, which is
// why lmg-weekly-link-sweep runs the same way.
// -----------------------------------------------------------------------------

add_action( 'lmg_concierge_weekly_demand', 'lmg_concierge_send_demand_alert' );

// 0.8.2: keep the shop catalogue warm, so a reader's question never waits for
// bottiglia.wine. Twice a day, inside the 12-hour cache; also queued at once
// when a reader finds the cache expired.
add_action( 'lmg_concierge_warm', function () {
	LMG_Concierge_Catalogue::refresh( LMG_Concierge_Config::get() );
} );

/**
 * Schedule it here as well as on activation, because the activation hook only
 * fires on activation — and on every site where this plugin was ALREADY active
 * when the feature shipped, that moment is in the past. Measured 9 Sep 2026:
 * after deploying, wp_next_scheduled() returned nothing on traveltalk.dk. A
 * feature that silently never runs is worse than one that was never built.
 */
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'lmg_concierge_weekly_demand' ) ) {
		wp_schedule_event( time() + 2 * HOUR_IN_SECONDS, 'weekly', 'lmg_concierge_weekly_demand' );
	}
	if ( ! wp_next_scheduled( 'lmg_concierge_warm' ) ) {
		wp_schedule_event( time() + 60, 'twicedaily', 'lmg_concierge_warm' );
	}
} );

function lmg_concierge_alert_settings() {
	return array(
		'days'  => 30,
		'min'   => max( 2, (int) get_option( 'lmg_concierge_alert_min_asks', 5 ) ),
		'share' => max( 1, min( 100, (int) get_option( 'lmg_concierge_alert_thin_share', 60 ) ) ),
		'to'    => trim( (string) get_option( 'lmg_concierge_alert_email', '' ) ) ?: get_option( 'admin_email' ),
	);
}

/**
 * Silence is the default. A digest that arrives every week whether or not it has
 * anything to say is a digest that stops being read — so nothing is sent unless
 * a topic actually crossed the threshold.
 */
function lmg_concierge_send_demand_alert() {
	$cfg = LMG_Concierge_Config::get();
	$s   = lmg_concierge_alert_settings();
	$hits = LMG_Concierge_Log::alerts( $s['days'], $s['min'], $s['share'] );
	if ( ! $hits ) return;

	$site   = isset( $cfg['site'] ) ? $cfg['site'] : home_url();
	$who    = isset( $cfg['persona']['name'] ) ? $cfg['persona']['name'] : 'Aianna';
	$lines  = array();
	$lines[] = sprintf( '%s — %d emne(r) over grænsen på %s', $who, count( $hits ), $site );
	$lines[] = '';
	$lines[] = sprintf( 'Grænse: mindst %d spørgsmål på %d dage, og mindst %d %% af dem tynde.', $s['min'], $s['days'], $s['share'] );
	$lines[] = 'Tynd = svaret måtte være »ikke dækket« eller »delvist«. Det er efterspørgsel, vi ikke honorerer.';
	$lines[] = '';
	foreach ( $hits as $h ) {
		$lines[] = sprintf( '· %s — spurgt %d gange, %d tynde (%d %%), senest %s',
			$h['topic'], $h['asks'], $h['thin'], $h['thin_share'], substr( (string) $h['last'], 0, 10 ) );
		foreach ( $h['examples'] as $ex ) $lines[] = '     "' . $ex . '"';
	}
	$lines[] = '';
	$lines[] = 'Beslutningen er den samme hver gang: skriv artiklen, find en partner til pladsen, eller lad den ligge.';
	$lines[] = 'Tallene bag: ' . admin_url( 'tools.php?page=lmg-concierge' );
	$lines[] = '';
	$lines[] = 'Kun rigtige læsersamtaler tælles med; egne test er filtreret fra.';

	wp_mail(
		$s['to'],
		sprintf( '[%s] %d emne(r) læserne spørger om, som vi ikke dækker', $site, count( $hits ) ),
		implode( "\n", $lines )
	);
}

add_action( 'rest_api_init', function () {
	/**
	 * Demand, for the LMG Cockpit to federate across sites. Reader questions are
	 * the site's own research, so this is never public: it needs the same
	 * capability as the admin screen that shows the identical numbers.
	 */
	register_rest_route( 'lmg-concierge/v1', '/demand', array(
		'methods'             => 'GET',
		'permission_callback' => function () { return current_user_can( 'manage_options' ); },
		'callback'            => function ( $req ) {
			$cfg = LMG_Concierge_Config::get();
			$s   = lmg_concierge_alert_settings();
			$days = (int) ( $req->get_param( 'days' ) ?: $s['days'] );
			$min  = (int) ( $req->get_param( 'min' ) ?: 2 );
			return array(
				'site'      => isset( $cfg['site'] ) ? $cfg['site'] : home_url(),
				'persona'   => isset( $cfg['persona']['name'] ) ? $cfg['persona']['name'] : '',
				'days'      => $days,
				'threshold' => array( 'min_asks' => $s['min'], 'thin_share' => $s['share'] ),
				'coverage'  => LMG_Concierge_Log::coverage( $days ),
				'demand'    => LMG_Concierge_Log::demand( $days, $min, 25 ),
				'alerts'    => LMG_Concierge_Log::alerts( $days, $s['min'], $s['share'] ),
			);
		},
	) );

	// Once visible to all, /ask is public by design: readers are anonymous and
	// pages are cached, so a nonce would be stale on arrival. The guard — five
	// limits and the ceiling — is what protects the wallet, and nothing stored
	// identifies a visitor. Until then, only administrators may call it.
	register_rest_route( 'lmg-concierge/v1', '/ask', array(
		'methods'             => 'POST',
		'callback'            => 'lmg_concierge_rest_ask',
		'permission_callback' => 'lmg_concierge_rest_permission',
	) );
	register_rest_route( 'lmg-concierge/v1', '/event', array(
		'methods'             => 'POST',
		'callback'            => 'lmg_concierge_rest_event',
		'permission_callback' => '__return_true',
	) );
	register_rest_route( 'lmg-concierge/v1', '/save', array(
		'methods'             => 'POST',
		'callback'            => 'lmg_concierge_rest_save',
		'permission_callback' => 'lmg_concierge_rest_permission',
	) );
} );

/**
 * Who may ask. While Aianna is visible to administrators only, only a logged-in
 * administrator may call /ask — otherwise the endpoint is public while the
 * bubble is hidden, and anyone with the URL can run up the bill unseen
 * (measured 2026-09-05: an anonymous curl got a full answer). Logged-in calls
 * carry the standard REST nonce (X-WP-Nonce) from the mount data.
 */
function lmg_concierge_rest_permission() {
	$v = LMG_Concierge_Config::visibility();
	if ( $v === 'all' ) return true;
	if ( $v === 'off' ) return false;
	return is_user_logged_in() && current_user_can( 'manage_options' );
}

/**
 * "Send me the answer" — the reader's own conversation, mailed to them.
 *
 * This route knows NOTHING about the newsletter, and that is the design, not an
 * omission. The panel makes two independent requests: this one always, and the
 * subscribe one only if the reader ticked an unticked box. Bundling them is the
 * GDPR art. 7(4) problem the config's `newsletter.gate: false` is already
 * waiting on a legal read for — so the two never meet in one payload.
 *
 * The address is used once and never stored: it goes to wp_mail and is gone.
 */
function lmg_concierge_rest_save( WP_REST_Request $req ) {
	$cfg  = LMG_Concierge_Config::get();
	$body = $req->get_json_params();
	if ( ! is_array( $body ) ) return new WP_REST_Response( array( 'ok' => false, 'reason' => 'bad_body' ), 400 );

	if ( empty( $cfg['keepsake']['enabled'] ) ) {
		return new WP_REST_Response( array( 'ok' => false, 'reason' => 'disabled' ), 403 );
	}

	// The address is OPTIONAL. "Copy link" is a first-class action: the reader who
	// only wants to send the answer to themselves later, or into a WhatsApp group,
	// hands over nothing at all. That is the whole reason share is a link and not
	// a mail from us — no address, no consent question, no third party.
	$email = isset( $body['email'] ) ? sanitize_email( (string) $body['email'] ) : '';
	if ( $email !== '' && ! is_email( $email ) ) {
		return new WP_REST_Response( array( 'ok' => false, 'reason' => 'bad_email' ), 400 );
	}

	// Sending mail on an anonymous POST is the one thing here worth abusing, so
	// this bucket is much tighter than the event one: a handful per ten minutes.
	$fp   = 'lmgc_save_' . substr( hash_hmac( 'sha256', LMG_Concierge_Guard::remote_addr(), wp_salt( 'auth' ) ), 0, 24 );
	$hits = (int) get_transient( $fp );
	if ( $hits >= 5 ) return new WP_REST_Response( array( 'ok' => false, 'reason' => 'rate' ), 429 );
	set_transient( $fp, $hits + 1, 10 * MINUTE_IN_SECONDS );

	$token = LMG_Concierge_Keepsake::create(
		isset( $body['turns'] ) ? $body['turns'] : array(),
		isset( $body['sources'] ) ? $body['sources'] : array()
	);
	if ( ! $token ) return new WP_REST_Response( array( 'ok' => false, 'reason' => 'empty' ), 400 );

	$sent = $email ? LMG_Concierge_Keepsake::mail( $email, $token ) : false;

	// Logged WITHOUT the address, like every other row in this table.
	LMG_Concierge_Log::write( array(
		'site'         => $cfg['id'],
		'conversation' => lmg_concierge_conversation_token( isset( $body['conversation'] ) ? $body['conversation'] : '' ),
		'turn'         => isset( $body['turn'] ) ? (int) $body['turn'] : 0,
		'kind'         => $email ? 'save' : 'share',
		'status'       => ( ! $email || $sent ) ? 'ok' : 'mail_failed',
	) );

	return new WP_REST_Response( array(
		'ok'    => true,
		'sent'  => (bool) $sent,
		'url'   => LMG_Concierge_Keepsake::url( $token ),
		'days'  => LMG_Concierge_Keepsake::expire_days(),
	), 200 );
}

/**
 * The LMG Match question sets she can run, read from disk at runtime.
 *
 * She does not carry her own copy of the ranking: she loads Match's engine and
 * calls it, so a change to the weights, the exclusions or a content map changes
 * her answers and the widget's answers together. If Match is not installed this
 * returns null and she simply never offers the funnel.
 *
 * Enumerated at runtime rather than hard-coded: three sets are live today, five
 * exist in the repo, more will come. Whatever is on disk is what she can run.
 */
function lmg_concierge_match_sets() {
	$dir = WP_PLUGIN_DIR . '/lmg-match';
	if ( ! is_dir( $dir . '/config' ) ) return null;

	$engine = glob( $dir . '/assets/lmg-match-engine-*.js' );
	if ( ! $engine ) return null;
	sort( $engine );

	$base = $dir . '/lmg-match.php';
	$sets = array();
	foreach ( (array) glob( $dir . '/config/*.json' ) as $path ) {
		$name = basename( $path, '.json' );
		$cfg  = json_decode( file_get_contents( $path ), true );
		if ( ! is_array( $cfg ) || empty( $cfg['subject'] ) || empty( $cfg['content'] ) ) continue;
		if ( ! file_exists( $dir . '/content/' . $cfg['content'] ) ) continue;  // a set without its map is not offerable

		// set_url_scheme so these always match the page's scheme: a mixed-content
		// block would kill the funnel silently, and plugins_url() has no HTTPS
		// context under WP-CLI.
		$sets[] = array(
			'id'      => $cfg['id'],
			'subject' => $cfg['subject'],
			// The real number of questions, so the invitation can never promise a
			// count the set does not have. Five today; a set with six would say six.
			'count'   => count( (array) $cfg['questions'] ),
			'config'  => set_url_scheme( plugins_url( 'config/' . $name . '.json', $base ) ),
			'content' => set_url_scheme( plugins_url( 'content/' . $cfg['content'], $base ) ),
		);
	}
	if ( ! $sets ) return null;

	return array(
		'engine' => set_url_scheme( plugins_url( 'assets/' . basename( end( $engine ) ), $base ) ),
		'sets'   => $sets,
	);
}

function lmg_concierge_conversation_token( $raw ) {
	$t = preg_replace( '/[^a-z0-9]/', '', strtolower( (string) $raw ) );
	return substr( $t !== '' ? $t : 'anon', 0, 16 );
}

function lmg_concierge_rest_ask( WP_REST_Request $req ) {
	$cfg  = LMG_Concierge_Config::get();
	$body = $req->get_json_params();
	if ( ! is_array( $body ) ) return new WP_REST_Response( array( 'ok' => false, 'reason' => 'bad_request' ), 400 );

	$lim      = isset( $cfg['limits'] ) ? $cfg['limits'] : array();
	$max_q    = (int) ( isset( $lim['maxQuestionChars'] ) ? $lim['maxQuestionChars'] : 600 );
	$question = isset( $body['question'] ) ? trim( sanitize_textarea_field( wp_unslash( (string) $body['question'] ) ) ) : '';
	if ( $question === '' ) return new WP_REST_Response( array( 'ok' => false, 'reason' => 'empty' ), 400 );
	if ( mb_strlen( $question ) > $max_q ) return new WP_REST_Response( array( 'ok' => false, 'reason' => 'too_long' ), 413 );

	$conv = lmg_concierge_conversation_token( isset( $body['conversation'] ) ? $body['conversation'] : '' );
	$turn = max( 1, min( 99, (int) ( isset( $body['turn'] ) ? $body['turn'] : 1 ) ) );
	$max_turns = (int) ( isset( $lim['maxTurns'] ) ? $lim['maxTurns'] : 12 );
	if ( $turn > $max_turns ) return new WP_REST_Response( array( 'ok' => false, 'reason' => 'turns' ), 429 );

	// Gates, cheapest first. A refused request is logged with its reason so the
	// admin page can tell "nobody asked" from "we said no".
	$admit = LMG_Concierge_Guard::admit( $cfg );
	if ( $admit !== true ) {
		LMG_Concierge_Log::write( array( 'site' => $cfg['id'], 'conversation' => $conv, 'turn' => $turn, 'kind' => 'ask', 'question' => $question, 'status' => $admit ) );
		$http = ( $admit === 'rate' || $admit === 'daily' ) ? 429 : 503;
		return new WP_REST_Response( array( 'ok' => false, 'reason' => $admit ), $http );
	}

	// ---------------------------------------------------------------------------
	// CONCURRENCY GATE — the concierge must never be able to starve the site.
	//
	// MEASURED on traveltalk.dk, 9 Sep 2026, and it is the reason this exists:
	// an /ask holds a PHP worker for 14-19 seconds. With ONE running, five
	// ordinary page loads all returned 200 in ~1s. With TWO running, both
	// answered — and a plain reader's page load came back **508 Resource Limit
	// Reached**. So two people asking at the same time is enough to serve an
	// error page to everyone else, and to any crawler in that window.
	//
	// The site is worth more than the answer. Above the cap we refuse INSTANTLY
	// and cheaply, without taking a worker for 15 seconds: the asker is told to
	// try again in a moment (and the panel retries once by itself), while the
	// reader who is merely reading is never affected.
	//
	// The TTL is the safety net: if a request dies without decrementing, the
	// slot frees itself rather than locking the concierge out forever.
	$inflight_max = max( 1, (int) ( isset( $lim['maxConcurrent'] ) ? $lim['maxConcurrent'] : 1 ) );
	$inflight_key = 'lmg_concierge_inflight';
	$inflight     = (int) get_transient( $inflight_key );
	if ( $inflight >= $inflight_max ) {
		LMG_Concierge_Log::write( array( 'site' => $cfg['id'], 'conversation' => $conv, 'turn' => $turn, 'kind' => 'ask', 'question' => $question, 'status' => 'busy' ) );
		return new WP_REST_Response( array( 'ok' => false, 'reason' => 'busy' ), 503 );
	}
	set_transient( $inflight_key, $inflight + 1, 60 );
	// Released however this request ends — normal return, error, or fatal.
	$inflight_release = function () use ( $inflight_key ) {
		$n = (int) get_transient( $inflight_key );
		if ( $n <= 1 ) delete_transient( $inflight_key );
		else set_transient( $inflight_key, $n - 1, 60 );
	};
	register_shutdown_function( $inflight_release );

	// History: text only, bounded, roles whitelisted. The client sends it back
	// because the server keeps no conversation state (pages are cached, no cookie).
	$history = array();
	$max_h   = 2 * (int) ( isset( $lim['maxHistoryTurns'] ) ? $lim['maxHistoryTurns'] : 6 );
	foreach ( array_slice( (array) ( isset( $body['history'] ) ? $body['history'] : array() ), -$max_h ) as $h ) {
		if ( ! is_array( $h ) ) continue;
		$history[] = array(
			'role' => ( isset( $h['role'] ) && $h['role'] === 'assistant' ) ? 'assistant' : 'user',
			'text' => mb_substr( sanitize_textarea_field( wp_unslash( (string) ( isset( $h['text'] ) ? $h['text'] : '' ) ) ), 0, 2000 ),
		);
	}

	// Page context: only what WordPress itself confirms about the id.
	$page_id = isset( $body['page']['id'] ) ? absint( $body['page']['id'] ) : 0;
	$page    = array( 'title' => '', 'url' => '' );
	if ( $page_id && ( $p = get_post( $page_id ) ) && $p->post_status === 'publish' ) {
		$page = array( 'title' => html_entity_decode( get_the_title( $p ), ENT_QUOTES, 'UTF-8' ), 'url' => get_permalink( $p ) );
	}

	// Retrieval: this question blended with the previous one, so a refinement
	// ("og i januar?") still finds the articles the reader is actually asking about.
	$prev = '';
	for ( $i = count( $history ) - 1; $i >= 0; $i-- ) {
		if ( $history[ $i ]['role'] === 'user' ) { $prev = $history[ $i ]['text']; break; }
	}
	$search = trim( $question . ( $prev ? ' ' . mb_substr( $prev, 0, 120 ) : '' ) );
	$candidates = LMG_Concierge_Retrieval::candidates( $search, $cfg, $page_id );
	if ( ! $candidates && $prev ) $candidates = LMG_Concierge_Retrieval::candidates( $question, $cfg, $page_id );

	$candidates = array_merge( (array) $candidates, LMG_Concierge_Catalogue::candidates( $search, $cfg ) );
	$res = LMG_Concierge_Model::ask( $cfg, $question, $history, $candidates, $page );

	$usage = isset( $res['usage'] ) ? $res['usage'] : array();
	$model = isset( $res['model'] ) ? $res['model'] : ( isset( $cfg['model']['id'] ) ? $cfg['model']['id'] : '' );
	$cost  = $usage ? LMG_Concierge_Model::cost_usd( $model, $usage ) : 0;
	if ( $usage ) LMG_Concierge_Guard::record( $cost, isset( $usage['input_tokens'] ) ? $usage['input_tokens'] : 0, isset( $usage['output_tokens'] ) ? $usage['output_tokens'] : 0 );

	if ( empty( $res['ok'] ) ) {
		LMG_Concierge_Log::write( array(
			'site' => $cfg['id'], 'conversation' => $conv, 'turn' => $turn, 'kind' => 'ask', 'question' => $question,
			'model' => $model, 'tokens_in' => isset( $usage['input_tokens'] ) ? $usage['input_tokens'] : null,
			'tokens_out' => isset( $usage['output_tokens'] ) ? $usage['output_tokens'] : null, 'cost_usd' => $cost ?: null,
			'latency_ms' => isset( $res['latency_ms'] ) ? $res['latency_ms'] : null, 'status' => $res['reason'],
		) );
		if ( ! empty( $res['detail'] ) ) error_log( '[lmg-concierge] ' . $res['reason'] . ': ' . $res['detail'] );
		return new WP_REST_Response( array( 'ok' => false, 'reason' => $res['reason'] ), $res['reason'] === 'upstream_rate' ? 429 : 502 );
	}

	// Sources: only ids the model was given, only ones still live (P3).
	$by_id = array();
	foreach ( $candidates as $c ) $by_id[ $c['id'] ] = $c;
	$sources = array();
	foreach ( (array) ( isset( $res['data']['sources'] ) ? $res['data']['sources'] : array() ) as $s ) {
		$id = isset( $s['id'] ) ? (int) $s['id'] : 0;
		if ( ! isset( $by_id[ $id ] ) || isset( $sources[ $id ] ) ) continue;
		if ( ! LMG_Concierge_Retrieval::link_ok( $by_id[ $id ]['url'], $cfg ) ) continue;
		$sources[ $id ] = array(
			'id'    => $id,
			'title' => $by_id[ $id ]['title'],
			'url'   => $by_id[ $id ]['url'],
			'image' => $by_id[ $id ]['image'],
			'why'   => mb_substr( sanitize_text_field( isset( $s['why'] ) ? $s['why'] : '' ), 0, 120 ),
		);
		if ( count( $sources ) >= 3 ) break;
	}
	$sources  = array_values( $sources );
	$coverage = isset( $res['data']['coverage'] ) ? $res['data']['coverage'] : ( $sources ? 'partial' : 'none' );
	// The model cannot claim coverage it did not cite.
	if ( $coverage === 'covered' && ! $sources ) $coverage = 'none';
	$lang = ( isset( $res['data']['language'] ) && $res['data']['language'] === 'en' ) ? 'en' : 'da';

	LMG_Concierge_Log::write( array(
		'site' => $cfg['id'], 'conversation' => $conv, 'turn' => $turn, 'kind' => 'ask', 'lang' => $lang,
		'question' => $question, 'coverage' => $coverage, 'source_ids' => array_map( function ( $s ) { return $s['id']; }, $sources ),
		'model' => $model, 'tokens_in' => isset( $usage['input_tokens'] ) ? $usage['input_tokens'] : null,
		'tokens_out' => isset( $usage['output_tokens'] ) ? $usage['output_tokens'] : null, 'cost_usd' => $cost,
		'latency_ms' => $res['latency_ms'], 'status' => 'ok',
	) );

	// The count in the prose is corrected against the list that survived, never
	// against the one the model named — see align_source_count().
	$reply = LMG_Concierge_Model::strip_ids( $res['data']['reply'] );
	$reply = LMG_Concierge_Model::align_source_count( $reply, count( $sources ), $lang );

	return new WP_REST_Response( array(
		'ok'       => true,
		'reply'    => wp_kses( $reply, array() ),
		'sources'  => $sources,
		'coverage' => $coverage,
		'language' => $lang,
		// What the reader was reading about, for a tailored signup. Derived from
		// the sources that survived, so it describes the answer the reader saw.
		// Carries no identifier and is never logged against the conversation.
		'interest' => LMG_Concierge_Retrieval::interest_auto( array_map( function ( $s ) { return $s['id']; }, $sources ) ),
	), 200 );
}

/** Whitelisted, aggregate-shaped events: open, dismiss, click, signup. */
function lmg_concierge_rest_event( WP_REST_Request $req ) {
	$cfg  = LMG_Concierge_Config::get();
	$body = $req->get_json_params();
	if ( ! is_array( $body ) ) return new WP_REST_Response( array( 'ok' => false ), 400 );

	$kind = isset( $body['kind'] ) ? sanitize_key( $body['kind'] ) : '';
	if ( ! in_array( $kind, array( 'open', 'dismiss', 'click', 'signup', 'newsletter_shown', 'match', 'save', 'share', 'band_shown' ), true ) ) {
		return new WP_REST_Response( array( 'ok' => false ), 400 );
	}

	// Flood control shares the ask limiter's shape but its own, looser bucket.
	$fp   = 'lmgc_ev_' . substr( hash_hmac( 'sha256', LMG_Concierge_Guard::remote_addr(), wp_salt( 'auth' ) ), 0, 24 );
	$hits = (int) get_transient( $fp );
	if ( $hits > 120 ) return new WP_REST_Response( array( 'ok' => false ), 429 );
	set_transient( $fp, $hits + 1, 10 * MINUTE_IN_SECONDS );

	// A completed Match run is the most valuable row this table gets: what a real
	// person wanted, in facets, and what the engine gave back. Stored in the same
	// shape as an answered question so the existing readout shows it without a
	// migration — the facet string in `question`, the articles in `source_ids`.
	$question = null;
	$sources  = null;
	$coverage = null;
	if ( $kind === 'match' ) {
		$parts = array();
		foreach ( (array) ( isset( $body['answers'] ) ? $body['answers'] : array() ) as $facet => $values ) {
			if ( ! is_array( $values ) ) continue;
			$parts[] = sanitize_key( $facet ) . '=' . implode( ',', array_map( 'sanitize_key', array_slice( $values, 0, 8 ) ) );
		}
		$subject  = isset( $body['subject'] ) ? sanitize_text_field( $body['subject'] ) : '';
		$question = trim( $subject . ' | ' . implode( ' · ', $parts ) );
		$sources  = isset( $body['ids'] ) ? array_slice( (array) $body['ids'], 0, 4 ) : null;
		$coverage = ! empty( $body['thin'] ) ? 'partial' : 'covered';
	}

	LMG_Concierge_Log::write( array(
		'site'         => $cfg['id'],
		'conversation' => lmg_concierge_conversation_token( isset( $body['conversation'] ) ? $body['conversation'] : '' ),
		'turn'         => isset( $body['turn'] ) ? (int) $body['turn'] : 0,
		'kind'         => $kind,
		'question'     => $question,
		'coverage'     => $coverage,
		'source_ids'   => $sources,
		'post_id'      => ( $kind === 'click' && isset( $body['post_id'] ) ) ? absint( $body['post_id'] ) : null,
		'status'       => 'ok',
		// Which wording was on screen when this happened. Null everywhere the
		// band is not involved, which is most rows.
		'variant'      => isset( $body['variant'] ) ? substr( sanitize_key( $body['variant'] ), 0, 32 ) : null,
	) );
	return new WP_REST_Response( null, 204 );
}
