<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * The band — Aianna in the page, not in the corner.
 *
 * G's call, 4 Oct 2026, with a screenshot of the front page: put her under the
 * Lens strip, same height, and take the space out of the "Seneste rejsenyt"
 * headline rather than pushing the page down. His words: "we have used the same
 * area better, not crushed."
 *
 * The whole design is one decision: BORROW THE LENS STRIP'S SHELL. Same
 * background, same border, same radius, same pill button, same height. A module
 * that invents its own styling reads as an advert dropped onto the page; one
 * that matches the strip above it reads as part of the page. That is the entire
 * reason this is not a floating box.
 *
 * Two ways in, one row:
 *   - the pill starts the five questions (lmg-match's engine, under her name)
 *   - the field is free text and opens her panel with the question already asked
 * A reader who will not answer five questions types "Italien" instead, and we
 * get a logged question either way. That is the point of having both.
 *
 * Laptop first, by G's instruction — the three-column row is the design, and the
 * phone stacks it. Below 720px the portrait sits beside the text and the pill
 * goes full width, because a 108px portrait above a headline is a lot of nothing.
 */
class LMG_Concierge_Band {

	public static function boot() {
		add_shortcode( 'aianna', array( __CLASS__, 'render' ) );
		add_shortcode( 'lmg_concierge_band', array( __CLASS__, 'render' ) );
		add_filter( 'the_content', array( __CLASS__, 'straighten' ), 9 );
	}

	/**
	 * Curly quotes inside our own shortcode, straightened before it is parsed.
	 *
	 * WordPress's shortcode regex matches " and ' and nothing else. Paste a tag
	 * out of a document, a chat window or the visual editor and the quotes
	 * arrive as ” and ’, the attribute silently fails to parse, and the band
	 * renders without its set — or the whole tag prints as text and looks like
	 * the plugin is broken. G hit exactly this on 4 Oct 2026.
	 *
	 * Scoped to our two tags by name, at priority 9 so it lands before
	 * do_shortcode at 11. Nothing else in the content is touched: straightening
	 * quotes across a whole post would damage the prose, which is the opposite
	 * of helpful on a site whose product is the writing.
	 */
	public static function straighten( $content ) {
		if ( strpos( $content, '[aianna' ) === false && strpos( $content, '[lmg_concierge_band' ) === false ) {
			return $content;
		}
		return preg_replace_callback(
			'/\[(aianna|lmg_concierge_band)\b[^\]]*\]/u',
			function ( $m ) {
				return str_replace(
					array( '“', '”', '„', '‟', '‘', '’', '‚', '‛' ),
					array( '"', '"', '"', '"', "'", "'", "'", "'" ),
					$m[0]
				);
			},
			$content
		);
	}

	/**
	 * The wordings in rotation. G, 4 Oct 2026: "we can interchange them and
	 * measure what works better then keep that until a new version beats it."
	 *
	 * Ships with the two framings that were actually argued over, so the first
	 * thing measured is the disagreement itself rather than a straw man:
	 * 'udbytte' leads with what the reader gets, 'format' leads with what the
	 * thing is. Add a third and it joins the rotation; leave one and the rotation
	 * stops, which is how a winner is kept.
	 *
	 * Assignment is random PER RENDER, not per person. That is the only split
	 * available without an identifier, and an identifier is the one thing this
	 * log has promised never to hold. The cost is that a reader may meet two
	 * wordings in a session; the benefit is a clean randomised split and no
	 * cookie. At this traffic that is the right side of the trade.
	 */
	public static function variants() {
		$stored = get_option( 'lmg_concierge_band_variants', '' );
		if ( $stored ) {
			$v = json_decode( $stored, true );
			if ( is_array( $v ) && $v ) return $v;
		}
		return array(
			array(
				'key'      => 'udbytte',
				'headline' => 'Fem nemme spørgsmål — så er ferien på vej',
				'subline'  => 'Få nye øjne på dine rejseplaner. Det tager 30 sekunder.',
				'cta'      => 'Start de fem →',
			),
			array(
				'key'      => 'format',
				'headline' => 'Miniquiz: fem spørgsmål om din næste rejse',
				'subline'  => 'Svar på fem spørgsmål, så finder Aianna rejsen. Tager 30 sekunder.',
				'cta'      => 'Tag miniquizzen →',
			),
		);
	}

	/**
	 * Strings: config file first, option second, so the wording can be changed
	 * at Værktøjer → Aianna without a deploy — the same rule the resting line
	 * and the campaign already follow.
	 */
	private static function strings( $cfg ) {
		$ui   = isset( $cfg['ui'] ) ? $cfg['ui'] : array();
		$band = isset( $ui['band'] ) && is_array( $ui['band'] ) ? $ui['band'] : array();
		$name = isset( $cfg['persona']['name'] ) ? $cfg['persona']['name'] : 'Aianna';

		// The objection is to the PROMISE, not to the word. G, 4 Oct 2026: "I am
		// not against miniquiz, but it does not say it helps you build your
		// vacation, it sounds like a fun thing to do some other day."
		//
		// So the default copy leads with the outcome and the cost — the holiday
		// is on its way, it takes 30 seconds — and never with the format. Call it
		// a miniquiz or a test if the label earns its place; just never let the
		// label be the whole message. Every string here is editable at
		// Værktøjer → Aianna, so that is a field, not a deploy.
		$d = array(
			'eyebrow'     => sprintf( 'Traveltalks rejseguide %s', $name ),
			'headline'    => 'Fem nemme spørgsmål — så er ferien på vej',
			'subline'     => 'Få nye øjne på dine rejseplaner. Det tager 30 sekunder.',
			'placeholder' => '…eller skriv bare »Italien« eller »Skiferie«',
			'cta'         => 'Start de fem →',
			'ctaPlain'    => sprintf( 'Spørg %s →', $name ),
		);
		foreach ( $d as $k => $v ) {
			if ( ! empty( $band[ $k ] ) ) $d[ $k ] = $band[ $k ];
			$opt = get_option( 'lmg_concierge_band_' . strtolower( $k ), '' );
			if ( $opt !== '' ) $d[ $k ] = $opt;
		}
		return $d;
	}

	/**
	 * [aianna] — or [aianna set="italien"] to point the five questions at one set.
	 *
	 * With no set named, or with lmg-match absent, the pill asks her directly
	 * instead of starting five questions that are not there. The band never
	 * renders a button that leads nowhere: lmg-match is installed on
	 * traveltalk.dk and on no other site in the group, and this file is shared
	 * by all of them.
	 */
	public static function render( $atts = array() ) {
		$atts = shortcode_atts( array( 'set' => '', 'align' => 'wide' ), $atts, 'aianna' );

		// Same gate as the bubble. An admins-only concierge must not leave a
		// reader-visible band on the front page advertising a panel they cannot open.
		if ( ! LMG_Concierge_Config::visible_to_current_user() ) return '';

		$cfg  = LMG_Concierge_Config::get();
		$s    = self::strings( $cfg );
		$name = isset( $cfg['persona']['name'] ) ? $cfg['persona']['name'] : 'Aianna';

		$set = sanitize_file_name( $atts['set'] );
		$has_set = ( $set !== '' && defined( 'LMG_MATCH_DIR' ) && file_exists( LMG_MATCH_DIR . 'config/' . $set . '.json' ) );

		$av   = LMG_Concierge_Config::avatar();
		$face = $av ? $av['face'] : LMG_CONCIERGE_URL . 'assets/img/' . self::prefix( $cfg ) . '-face-312.jpg';

		self::assets( $cfg );

		// Pick a wording. Only where there is something to measure — with no set
		// there is no five-question offer and nothing to phrase two ways.
		$variant = '';
		if ( $has_set ) {
			$vs = self::variants();
			$pick = $vs[ wp_rand( 0, count( $vs ) - 1 ) ];
			$variant = isset( $pick['key'] ) ? sanitize_key( $pick['key'] ) : '';
			foreach ( array( 'headline', 'subline', 'cta' ) as $k ) {
				if ( ! empty( $pick[ $k ] ) ) $s[ $k ] = $pick[ $k ];
			}
		}

		$cta = $has_set ? $s['cta'] : $s['ctaPlain'];
		$id  = 'lmgcb-' . wp_rand( 1000, 9999 );

		ob_start(); ?>
		<div class="lmgcb<?php echo $atts['align'] === 'wide' ? ' lmgcb--wide' : ''; ?>"
		     data-set="<?php echo esc_attr( $has_set ? $set : '' ); ?>"
		     data-set-url="<?php echo esc_attr( $has_set ? LMG_MATCH_URL . 'config/' . $set . '.json' : '' ); ?>"
		     data-variant="<?php echo esc_attr( $variant ); ?>"
		     data-event="<?php echo esc_url( rest_url( 'lmg-concierge/v1/event' ) ); ?>">
			<div class="lmgcb__face">
				<img src="<?php echo esc_url( $face ); ?>" alt="<?php echo esc_attr( $name ); ?>" width="108" height="108" loading="lazy" decoding="async">
			</div>
			<div class="lmgcb__body">
				<p class="lmgcb__eyebrow"><?php echo esc_html( $s['eyebrow'] ); ?></p>
				<p class="lmgcb__h"><?php echo esc_html( $s['headline'] ); ?></p>
				<?php if ( $has_set && $s['subline'] !== '' ) : ?>
				<p class="lmgcb__sub"><?php echo esc_html( $s['subline'] ); ?></p>
				<?php endif; ?>
				<form class="lmgcb__ask" role="search">
					<label class="lmgcb__sr" for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( sprintf( 'Spørg %s', $name ) ); ?></label>
					<input id="<?php echo esc_attr( $id ); ?>" type="text" autocomplete="off"
					       placeholder="<?php echo esc_attr( $s['placeholder'] ); ?>">
					<button type="submit" class="lmgcb__go" aria-label="<?php echo esc_attr( sprintf( 'Spørg %s', $name ) ); ?>">→</button>
				</form>
			</div>
			<button type="button" class="lmgcb__pill"><?php echo esc_html( $cta ); ?></button>
		</div>
		<?php
		return ob_get_clean();
	}

	private static function prefix( $cfg ) {
		$p = isset( $cfg['assets']['prefix'] ) ? LMG_Concierge_Config::safe_file( $cfg['assets']['prefix'] ) : '';
		return $p !== '' ? $p : 'aianna';
	}

	/**
	 * Styles and behaviour, inline and only where the shortcode renders.
	 *
	 * Inline because the band is small and because a new asset file would be a
	 * fourth thing to keep in step with LMG_CONCIERGE_VERSION. The accent and the
	 * green come from the config, so a second site gets its own colours without
	 * a stylesheet of its own.
	 */
	private static function assets( $cfg ) {
		static $done = false;
		if ( $done ) return;
		$done = true;

		$accent = isset( $cfg['accent'] ) ? $cfg['accent'] : '#B8956A';
		$brand  = isset( $cfg['band']['brand'] ) ? $cfg['band']['brand'] : '#0E5A3F';

		$css = '
.lmgcb{display:flex;align-items:center;gap:20px;background:var(--lmgcb-panel,#F1F7F4);border:1px solid var(--lmgcb-bord,#D7E6DF);border-radius:12px;padding:14px;margin:0 0 12px}
.lmgcb__face{flex:0 0 108px;height:108px;border-radius:9px;overflow:hidden;background:#e9eeec}
.lmgcb__face img{width:100%;height:100%;object-fit:cover;object-position:50% 38%;display:block}
.lmgcb__body{flex:1;min-width:0}
.lmgcb__eyebrow{font-size:11px;font-weight:600;letter-spacing:.13em;text-transform:uppercase;color:' . esc_attr( $brand ) . ';margin:0 0 5px}
.lmgcb__h{font-size:21px;font-weight:700;letter-spacing:-.01em;line-height:1.2;margin:0 0 3px}
.lmgcb__sub{font-size:13px;line-height:1.4;opacity:.72;margin:0 0 9px}
.lmgcb__ask{display:flex;align-items:center;gap:7px}
.lmgcb__ask input{flex:1;min-width:0;font:inherit;font-size:13px;padding:9px 13px;border:1px solid var(--lmgcb-bord,#D7E6DF);border-radius:999px;background:#fff;color:inherit}
.lmgcb__ask input:focus{outline:2px solid ' . esc_attr( $accent ) . ';outline-offset:1px}
.lmgcb__go{flex:0 0 auto;width:34px;height:34px;border:0;border-radius:999px;background:' . esc_attr( $accent ) . ';color:#fff;font-size:15px;line-height:1;cursor:pointer}
.lmgcb__pill{flex:0 0 auto;background:' . esc_attr( $brand ) . ';color:#fff;border:0;border-radius:999px;padding:13px 24px;font-size:15px;font-weight:600;cursor:pointer;white-space:nowrap}
.lmgcb__pill:hover,.lmgcb__go:hover{filter:brightness(1.12)}
.lmgcb__sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}
@media (max-width:720px){
.lmgcb{flex-wrap:wrap;gap:14px}
.lmgcb__face{flex:0 0 72px;height:72px}
.lmgcb__body{flex:1 1 60%}
.lmgcb__h{font-size:17px}
.lmgcb__sub{font-size:12px}
.lmgcb__pill{width:100%;order:3}
}
@media (prefers-color-scheme:dark){
.lmgcb{--lmgcb-panel:#1b2420;--lmgcb-bord:#2b3a34}
.lmgcb__ask input{background:#101714}
}';

		// The five questions are lmg-match's engine wearing her name. Nothing about the
		// widget changes — it is mounted on demand into a holder below the band,
		// which is why the shortcode does not render one until it is wanted.
		$js = '
(function(){
 var b=document.querySelector(".lmgcb"); if(!b) return;
 var form=b.querySelector(".lmgcb__ask"), input=b.querySelector("input"), pill=b.querySelector(".lmgcb__pill");
 var variant=b.getAttribute("data-variant")||"", evt=b.getAttribute("data-event")||"";
 function send(kind){
   if(!evt||!variant) return;
   try{ navigator.sendBeacon(evt, new Blob([JSON.stringify({kind:kind,variant:variant})],{type:"application/json"})); }catch(e){}
 }
 // Shown means seen, not served. A band below the fold that nobody scrolled to
 // is not a wording that failed, and counting it as one would quietly punish
 // whichever variant happened to sit on longer pages.
 if("IntersectionObserver" in window){
   var io=new IntersectionObserver(function(es){
     es.forEach(function(e){ if(e.isIntersecting){ send("band_shown"); io.disconnect(); } });
   },{threshold:.5});
   io.observe(b);
 } else { send("band_shown"); }
 function warm(){ if(window.LMGConciergeDock) window.LMGConciergeDock.warm(); }
 input.addEventListener("focus", warm, {once:true});
 pill.addEventListener("pointerenter", warm, {once:true});
 form.addEventListener("submit", function(e){
   e.preventDefault();
   var q=(input.value||"").trim(); if(!q) { input.focus(); return; }
   if(!window.LMGConciergeDock) return;
   send("open");
   window.LMGConciergeDock.open(q).then(function(){ input.value=""; });
 });
 pill.addEventListener("click", function(){
   send("open");
   var url=b.getAttribute("data-set-url");
   if(!url){ if(window.LMGConciergeDock) window.LMGConciergeDock.open(); return; }
   var holder=b.nextElementSibling;
   if(!holder||!holder.hasAttribute("data-lmg-match")){
     holder=document.createElement("div");
     holder.setAttribute("data-lmg-match","1");
     holder.setAttribute("data-config",url);
     var c=b.getAttribute("data-content"); if(c) holder.setAttribute("data-content",c);
     b.parentNode.insertBefore(holder,b.nextSibling);
     if(window.LMGMatch&&window.LMGMatch.mount) window.LMGMatch.mount(holder);
   }
   holder.scrollIntoView({behavior:"smooth",block:"nearest"});
 });
})();';

		wp_register_style( 'lmg-concierge-band', false, array(), LMG_CONCIERGE_VERSION );
		wp_enqueue_style( 'lmg-concierge-band' );
		wp_add_inline_style( 'lmg-concierge-band', $css );

		wp_register_script( 'lmg-concierge-band', false, array(), LMG_CONCIERGE_VERSION, true );
		wp_enqueue_script( 'lmg-concierge-band' );
		wp_add_inline_script( 'lmg-concierge-band', $js );

		// The question engine, where it exists. Registered by lmg-match itself; this
		// only asks for it, and asking for a handle that is not registered is a
		// no-op rather than a fatal.
		if ( wp_script_is( 'lmg-match-ui', 'registered' ) ) {
			wp_enqueue_style( 'lmg-match' );
			wp_enqueue_script( 'lmg-match-ui' );
		}
	}
}