<?php
/**
 * The keepsake — a reader's own answer, kept.
 *
 * Two features share one artefact. "Send me the answer" mails the conversation;
 * "share" hands the reader a link they send themselves. Both need the same
 * thing: the exchange, stored, at a URL.
 *
 * THREE RULES ARE LOAD-BEARING HERE. They are not preferences.
 *
 * 1. The answer is NEVER gated. The reader has already read it on screen before
 *    this class is ever called. Mailing someone the answer they asked for is
 *    delivery of a service they requested, not marketing — which is exactly why
 *    it must not be bundled with a newsletter opt-in (GDPR art. 7(4)).
 *
 * 2. The page is noindex, and it is not a post. An indexable page carrying
 *    AI-written prose on traveltalk.dk is the precise mechanism behind the 2025
 *    collapse — the daily article bot, killswitched 22 May 2026. So the keepsake
 *    is served from a query var and never becomes a WP_Post: no sitemap can list
 *    what is not a post. That is belt (construction) and braces (meta + header).
 *
 * 3. The address is never stored. It is used to send one mail and dropped. The
 *    subscriber list and the conversation log stay apart, as they already do.
 *
 * @package LMG_Concierge
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class LMG_Concierge_Keepsake {

	const QUERY_VAR   = 'lmgc';
	const TOKEN_BYTES = 16;          // 32 hex chars — not guessable, not a secret worth guarding
	const MAX_TURNS   = 24;

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'lmg_concierge_saved';
	}

	public static function install() {
		global $wpdb;
		$table   = self::table();
		$collate = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			token CHAR(32) NOT NULL,
			site VARCHAR(48) NOT NULL,
			created_at DATETIME NOT NULL,
			expires_at DATETIME NOT NULL,
			payload LONGTEXT NOT NULL,
			views INT UNSIGNED NOT NULL DEFAULT 0,
			PRIMARY KEY (id),
			UNIQUE KEY token (token),
			KEY expires_at (expires_at)
		) {$collate};";
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	/** Expiry is a promise to the reader, so it is enforced twice: on read, and by this sweep. */
	public static function prune() {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::table() . ' WHERE expires_at < %s', current_time( 'mysql' ) ) );
	}

	public static function expire_days() {
		$cfg = LMG_Concierge_Config::get();
		$d   = isset( $cfg['keepsake']['expireDays'] ) ? (int) $cfg['keepsake']['expireDays'] : 30;
		return max( 1, min( 365, $d ) );
	}

	/**
	 * Store one exchange and return its token.
	 *
	 * The transcript arrives from the browser, so every field is treated as
	 * hostile: roles are whitelisted, text is stripped of tags and capped, and a
	 * source URL is kept only when it is on this site. That last check is what
	 * stops the keepsake from becoming an open redirect dressed as our page.
	 */
	public static function create( $turns, $sources ) {
		global $wpdb;
		$cfg = LMG_Concierge_Config::get();

		$clean = array();
		foreach ( (array) $turns as $t ) {
			if ( ! is_array( $t ) ) continue;
			$role = ( isset( $t['role'] ) && $t['role'] === 'user' ) ? 'user' : 'assistant';
			$text = isset( $t['text'] ) ? wp_strip_all_tags( (string) $t['text'] ) : '';
			$text = trim( mb_substr( $text, 0, 4000 ) );
			if ( $text === '' ) continue;
			$clean[] = array( 'role' => $role, 'text' => $text );
			if ( count( $clean ) >= self::MAX_TURNS ) break;
		}
		if ( ! $clean ) return null;

		$home = wp_parse_url( home_url(), PHP_URL_HOST );
		$srcs = array();
		foreach ( (array) $sources as $s ) {
			if ( ! is_array( $s ) || empty( $s['url'] ) ) continue;
			$url = esc_url_raw( (string) $s['url'] );
			if ( ! $url || wp_parse_url( $url, PHP_URL_HOST ) !== $home ) continue;   // our own links only
			$srcs[] = array(
				'url'   => $url,
				'title' => trim( wp_strip_all_tags( isset( $s['title'] ) ? (string) $s['title'] : '' ) ),
				'id'    => isset( $s['id'] ) ? absint( $s['id'] ) : 0,
			);
			if ( count( $srcs ) >= 6 ) break;
		}

		$token = bin2hex( random_bytes( self::TOKEN_BYTES ) );
		$ok = $wpdb->insert( self::table(), array(
			'token'      => $token,
			'site'       => $cfg['id'],
			'created_at' => current_time( 'mysql' ),
			'expires_at' => gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) + self::expire_days() * DAY_IN_SECONDS ),
			'payload'    => wp_json_encode( array( 'turns' => $clean, 'sources' => $srcs ) ),
			'views'      => 0,
		) );
		return $ok ? $token : null;
	}

	public static function get( $token ) {
		global $wpdb;
		if ( ! preg_match( '/^[a-f0-9]{32}$/', (string) $token ) ) return null;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE token = %s', $token ), ARRAY_A );
		if ( ! $row ) return null;
		if ( strtotime( $row['expires_at'] ) < strtotime( current_time( 'mysql' ) ) ) return 'expired';
		$row['data'] = json_decode( $row['payload'], true );
		return $row;
	}

	public static function url( $token ) {
		return add_query_arg( self::QUERY_VAR, $token, home_url( '/' ) );
	}

	/**
	 * The newsletter offer, as it appears INSIDE a keepsake. Twice per answer
	 * (handoff, 15 Sep 2026): once under the links, once in the footer.
	 *
	 * The panel's own offer is a form. A keepsake is not: it is read in an inbox or
	 * at a link weeks later, where no form of ours can post, so this is a plain
	 * paragraph and the site's own signup address. That is also why it changes
	 * nothing about rule 1 above — the answer is delivered either way, and consent
	 * is taken on traveltalk.dk's own signup page, never here and never bundled
	 * with the mail the reader asked for.
	 *
	 * $where is 'answer' (under the links) or 'foot'. `footerCta` lets the second
	 * placement be a short line so the paragraph is not repeated verbatim in the
	 * same artefact; unset, both placements carry the full paragraph.
	 *
	 * Returns null when the site has no newsletter, or no copy for this placement.
	 */
	private static function newsletter_cta( $cfg, $where ) {
		$n = isset( $cfg['newsletter'] ) && is_array( $cfg['newsletter'] ) ? $cfg['newsletter'] : array();
		if ( empty( $n['enabled'] ) ) return null;

		$text = ( $where === 'foot' && ! empty( $n['footerCta'] ) ) ? $n['footerCta'] : ( isset( $n['answerCta'] ) ? $n['answerCta'] : '' );
		$text = trim( (string) $text );
		if ( $text === '' ) return null;

		$label = isset( $n['signupLabel'] ) ? trim( (string) $n['signupLabel'] ) : '';
		return array(
			'text'  => $text,
			'url'   => isset( $n['signupUrl'] ) ? trim( (string) $n['signupUrl'] ) : '',
			'label' => $label !== '' ? $label : 'Tilmeld nyhedsbrev →',
		);
	}

	// -------------------------------------------------------------------------
	// The page
	// -------------------------------------------------------------------------

	public static function boot() {
		add_filter( 'query_vars', function ( $v ) { $v[] = self::QUERY_VAR; return $v; } );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_render' ) );
	}

	public static function maybe_render() {
		$token = get_query_var( self::QUERY_VAR );
		if ( ! $token ) return;

		// Braces. The construction (never a post) is the belt.
		if ( ! headers_sent() ) {
			header( 'X-Robots-Tag: noindex, nofollow, noarchive', true );
			status_header( 200 );
			nocache_headers();
		}

		// MEASURED 2026-09-10, and it is not optional: `nocache_headers()` is NOT
		// enough here. The page went out with `no-store, private` and QUIC.cloud
		// cached it anyway (`x-qc-cache: hit`) — so a deleted keepsake kept
		// serving from the edge and the expiry promise was quietly broken.
		// LiteSpeed has to be told in its own language, or it stamps the response
		// cacheable before the CDN ever sees our header. Same family as the
		// year-long static-asset hold this stack is already known for.
		do_action( 'litespeed_control_set_nocache', 'lmg-concierge keepsake is per-token and expires' );

		// ...and the hook alone is STILL not enough, measured the same day. This
		// page ends in exit(), so WordPress's `shutdown` never runs, so LSCWP
		// never gets to stamp its own header — and with no `X-LiteSpeed-Cache-
		// Control` present, QUIC.cloud falls back to its own policy and caches
		// the HTML even though we sent `no-store, private`. (Diagnosis:
		// `x-litespeed-cache: miss` while `x-qc-cache` went miss -> hit.)
		// So we emit the header the edge actually reads, ourselves.
		header( 'X-LiteSpeed-Cache-Control: no-cache', true );

		$row = self::get( $token );
		if ( $row === 'expired' || ! $row ) {
			self::render_page( null );
			exit;
		}
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::table() . ' SET views = views + 1 WHERE token = %s', $token ) );
		self::render_page( $row );
		exit;
	}

	/**
	 * Rendered standalone, not through the theme. A keepsake must survive a theme
	 * change, must not drag the site's header/menu (this page is not navigation),
	 * and must not inherit a stylesheet that a cache could be serving stale.
	 */
	public static function render_page( $row ) {
		$cfg     = LMG_Concierge_Config::get();
		$k       = isset( $cfg['keepsake'] ) ? $cfg['keepsake'] : array();
		$persona = isset( $cfg['persona']['name'] ) ? $cfg['persona']['name'] : 'Concierge';
		$accent  = isset( $cfg['accent'] ) ? $cfg['accent'] : '#1a6b54';
		$site    = isset( $cfg['site'] ) ? $cfg['site'] : wp_parse_url( home_url(), PHP_URL_HOST );
		$expired = ! $row;
		$nl_read = self::newsletter_cta( $cfg, 'answer' );
		$nl_foot = self::newsletter_cta( $cfg, 'foot' );

		$title = $expired
			? ( isset( $k['expiredTitle'] ) ? $k['expiredTitle'] : 'Linket er udløbet' )
			: ( isset( $k['pageTitle'] ) ? $k['pageTitle'] : 'Dit svar fra ' . $persona );

		header( 'Content-Type: text/html; charset=utf-8' );
		?><!doctype html>
<html lang="<?php echo esc_attr( str_replace( '_', '-', get_locale() ) ); ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow, noarchive">
<title><?php echo esc_html( $title ); ?></title>
<style>
:root{--a:<?php echo esc_attr( $accent ); ?>;--fg:#1d2321;--mu:#5d6b66;--bd:#e3e8e6;--bg:#fbfcfc}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--fg);font:16px/1.65 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
.wrap{max-width:680px;margin:0 auto;padding:32px 20px 64px}
.eyebrow{font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:var(--a);margin:0 0 6px}
h1{font-size:26px;line-height:1.25;margin:0 0 20px}
.turn{margin:0 0 18px}
.who{font-size:12px;letter-spacing:.06em;text-transform:uppercase;color:var(--mu);margin:0 0 4px}
.said{margin:0;padding:14px 16px;border:1px solid var(--bd);border-radius:12px;background:#fff;white-space:pre-wrap}
.turn--user .said{background:#f2f6f5;border-color:#dfe8e5}
.srcs{margin:28px 0 0;padding:20px 0 0;border-top:1px solid var(--bd)}
.srcs h2{font-size:14px;letter-spacing:.04em;text-transform:uppercase;color:var(--mu);margin:0 0 10px}
.srcs a{display:block;padding:10px 0;color:var(--fg);text-decoration:none;border-bottom:1px solid var(--bd)}
.srcs a:hover{color:var(--a)}
.foot{margin:32px 0 0;padding:18px 0 0;border-top:1px solid var(--bd);font-size:13px;color:var(--mu)}
.foot a{color:var(--a)}
.note{margin:6px 0 0}
.nl{margin:24px 0 0;padding:16px 18px;border:1px solid var(--bd);border-radius:12px;background:#fff}
.nl p{margin:0}
.nl__cta{margin:10px 0 0}
.nl__cta a{color:var(--a);font-weight:600;text-decoration:none}
.nl__cta a:hover{text-decoration:underline}
.foot .nl{margin:0 0 14px;padding:0;border:0;border-radius:0;background:none}
.foot .nl__cta{margin:6px 0 0}
</style>
</head>
<body>
<div class="wrap">
<?php if ( $expired ) : ?>
	<p class="eyebrow"><?php echo esc_html( $site ); ?></p>
	<h1><?php echo esc_html( $title ); ?></h1>
	<p><?php echo esc_html( isset( $k['expiredBody'] ) ? $k['expiredBody'] : sprintf( 'Gemte svar slettes automatisk efter %d dage. Du er velkommen til at spørge igen.', self::expire_days() ) ); ?></p>
	<p><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( isset( $k['backLabel'] ) ? $k['backLabel'] : 'Gå til forsiden' ); ?></a></p>
<?php else : ?>
	<p class="eyebrow"><?php echo esc_html( $site ); ?></p>
	<h1><?php echo esc_html( $title ); ?></h1>
	<?php foreach ( (array) $row['data']['turns'] as $t ) : ?>
		<div class="turn turn--<?php echo esc_attr( $t['role'] ); ?>">
			<p class="who"><?php echo esc_html( $t['role'] === 'user' ? ( isset( $k['youLabel'] ) ? $k['youLabel'] : 'Dit spørgsmål' ) : $persona ); ?></p>
			<p class="said"><?php echo esc_html( $t['text'] ); ?></p>
		</div>
	<?php endforeach; ?>
	<?php if ( ! empty( $row['data']['sources'] ) ) : ?>
		<div class="srcs">
			<h2><?php echo esc_html( isset( $k['sourcesLabel'] ) ? $k['sourcesLabel'] : 'Læs videre' ); ?></h2>
			<?php foreach ( $row['data']['sources'] as $s ) : ?>
				<a href="<?php echo esc_url( $s['url'] ); ?>"><?php echo esc_html( $s['title'] ? $s['title'] : $s['url'] ); ?></a>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
	<?php // Placement 1: directly under the links, where a reader who has just finished reading actually is. ?>
	<?php if ( $nl_read ) : ?>
		<div class="nl">
			<p><?php echo esc_html( $nl_read['text'] ); ?></p>
			<?php if ( $nl_read['url'] ) : ?>
				<p class="nl__cta"><a href="<?php echo esc_url( $nl_read['url'] ); ?>"><?php echo esc_html( $nl_read['label'] ); ?></a></p>
			<?php endif; ?>
		</div>
	<?php endif; ?>
	<div class="foot">
		<?php // Placement 2: the footer. This page IS the save/share permalink, so the offer sits above the disclaimer. ?>
		<?php if ( $nl_foot ) : ?>
			<div class="nl">
				<p><?php echo esc_html( $nl_foot['text'] ); ?></p>
				<?php if ( $nl_foot['url'] ) : ?>
					<p class="nl__cta"><a href="<?php echo esc_url( $nl_foot['url'] ); ?>"><?php echo esc_html( $nl_foot['label'] ); ?></a></p>
				<?php endif; ?>
			</div>
		<?php endif; ?>
		<?php // The disclaimer travels with the artefact. It is read weeks later, by someone who may not have been in the conversation. ?>
		<p><?php echo esc_html( isset( $cfg['ui']['disclaimer'] ) ? $cfg['ui']['disclaimer'] : '' ); ?></p>
		<p class="note"><?php echo esc_html( sprintf( isset( $k['expiryNote'] ) ? $k['expiryNote'] : 'Dette link slettes automatisk %d dage efter, det blev gemt.', self::expire_days() ) ); ?></p>
		<p class="note"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( isset( $k['backLabel'] ) ? $k['backLabel'] : 'Gå til forsiden' ); ?></a></p>
	</div>
<?php endif; ?>
</div>
</body>
</html><?php
	}

	// -------------------------------------------------------------------------
	// The mail
	// -------------------------------------------------------------------------

	/** Plain, readable, and it carries the disclaimer. Returns bool. */
	public static function mail( $to, $token ) {
		$row = self::get( $token );
		if ( ! $row || $row === 'expired' ) return false;
		$cfg     = LMG_Concierge_Config::get();
		$k       = isset( $cfg['keepsake'] ) ? $cfg['keepsake'] : array();
		$persona = isset( $cfg['persona']['name'] ) ? $cfg['persona']['name'] : 'Concierge';
		$subject = isset( $k['mailSubject'] ) ? $k['mailSubject'] : 'Dit svar fra ' . $persona;

		$lines = array();
		foreach ( (array) $row['data']['turns'] as $t ) {
			$lines[] = ( $t['role'] === 'user' ? ( isset( $k['youLabel'] ) ? $k['youLabel'] : 'Dit spørgsmål' ) : $persona ) . ':';
			$lines[] = $t['text'];
			$lines[] = '';
		}
		if ( ! empty( $row['data']['sources'] ) ) {
			// strtoupper() is BYTE-based: on "Læs videre" it leaves the multi-byte
			// æ untouched and ships "LæS VIDERE" to the reader. Danish copy must
			// never go through it. mbstring is already required by this file
			// (mb_substr above), but the fallback keeps the line honest anyway.
			$label = isset( $k['sourcesLabel'] ) ? $k['sourcesLabel'] : 'Læs videre';
			$lines[] = function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $label, 'UTF-8' ) : $label;
			foreach ( $row['data']['sources'] as $s ) {
				$lines[] = '- ' . ( $s['title'] ? $s['title'] : '' ) . "\n  " . $s['url'];
			}
			$lines[] = '';
		}
		// Placement 1 — directly under the link list, above the rule.
		$nl_read = self::newsletter_cta( $cfg, 'answer' );
		if ( $nl_read ) {
			$lines[] = $nl_read['text'];
			if ( $nl_read['url'] ) $lines[] = $nl_read['label'] . ' ' . $nl_read['url'];
			$lines[] = '';
		}
		$lines[] = str_repeat( '-', 48 );
		$lines[] = ( isset( $k['mailLinkIntro'] ) ? $k['mailLinkIntro'] : 'Gem eller del dette svar:' ) . ' ' . self::url( $token );
		$lines[] = sprintf( isset( $k['expiryNote'] ) ? $k['expiryNote'] : 'Dette link slettes automatisk %d dage efter, det blev gemt.', self::expire_days() );
		$lines[] = '';
		// Placement 2 — under the save/share line, above the disclaimer.
		$nl_foot = self::newsletter_cta( $cfg, 'foot' );
		if ( $nl_foot ) {
			$lines[] = $nl_foot['text'];
			if ( $nl_foot['url'] ) $lines[] = $nl_foot['label'] . ' ' . $nl_foot['url'];
			$lines[] = '';
		}
		if ( ! empty( $cfg['ui']['disclaimer'] ) ) $lines[] = $cfg['ui']['disclaimer'];

		return (bool) wp_mail( $to, $subject, implode( "\n", $lines ) );
	}
}
