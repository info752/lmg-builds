<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Configuration — one JSON file per site, plus a handful of wp_options that
 * override it (visibility, key, model, ceiling). Nothing about a site is in code.
 */
class LMG_Concierge_Config {

	/** @var array|null */
	private static $cache = null;

	/**
	 * Sanitise a bare filename. NOT sanitize_file_name(): it mangles multi-dot
	 * names (lmg-match, 2026-09-05). Do not "fix" this back.
	 */
	public static function safe_file( $name ) {
		$name = basename( (string) $name );
		$name = preg_replace( '/[^A-Za-z0-9._-]/', '', $name );
		return ( $name === '' || strpos( $name, '..' ) !== false ) ? '' : $name;
	}

	public static function config_name() {
		$def  = 'traveltalk';
		$host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		if ( strpos( $host, 'winetalk' ) !== false ) $def = 'winetalk';
		elseif ( strpos( $host, 'worldsporttalk' ) !== false ) $def = 'worldsporttalk';
		elseif ( strpos( $host, 'traveltalk.travel' ) !== false ) $def = 'traveltalktravel';
		$name = self::safe_file( get_option( 'lmg_concierge_config', $def ) );
		return $name ? preg_replace( '/\.json$/', '', $name ) : $def;
	}

	/**
	 * 0.9.0: run this request on another config file (the partner chat on
	 * traveltalk.travel). The reader concierge's wp-admin options are NOT
	 * applied: they belong to the reader concierge.
	 */
	public static function override( $name ) {
		$name = self::safe_file( $name );
		$path = LMG_CONCIERGE_DIR . 'config/' . preg_replace( '/\.json$/', '', (string) $name ) . '.json';
		$cfg  = ( $name && file_exists( $path ) ) ? json_decode( file_get_contents( $path ), true ) : null;
		if ( ! is_array( $cfg ) ) return false;
		self::$cache = $cfg;
		return $cfg;
	}

	/** Full config, options applied on top. Cached per request. */
	public static function get() {
		if ( self::$cache !== null ) return self::$cache;

		$path = LMG_CONCIERGE_DIR . 'config/' . self::config_name() . '.json';
		$cfg  = file_exists( $path ) ? json_decode( file_get_contents( $path ), true ) : null;
		if ( ! is_array( $cfg ) ) $cfg = array();

		// Options win over the file, so the admin page can change the running
		// values without a deploy. Empty option = "use the file".
		$model = get_option( 'lmg_concierge_model', '' );
		if ( $model ) $cfg['model']['id'] = sanitize_text_field( $model );

		$ceiling = get_option( 'lmg_concierge_ceiling_usd', '' );
		if ( $ceiling !== '' && is_numeric( $ceiling ) ) $cfg['limits']['monthlyCeilingUsd'] = (float) $ceiling;

		$line = get_option( 'lmg_concierge_resting_line', '' );
		if ( $line ) $cfg['ui']['restingLine'] = sanitize_text_field( $line );

		// The card's shape, and the sentence only the wide shape has room for.
		//
		// The tall card could never carry an explanation: a longer line wrapped to
		// three lines UNDER a 92px portrait and made the card bulky, which is why
		// it was cut back to "Spørg Traveltalk" on 6 Sep 2026. Beside the portrait
		// instead of beneath it, the same sentence fits — so this is the layout
		// answer to a copy problem, not a reversal of that ruling.
		$shape = get_option( 'lmg_concierge_card_shape', 'tall' );
		$cfg['ui']['cardShape'] = in_array( $shape, array( 'tall', 'wide' ), true ) ? $shape : 'tall';

		$card = get_option( 'lmg_concierge_card_line', '' );
		if ( $card === '' && isset( $cfg['ui']['cardLine'] ) ) $card = $cfg['ui']['cardLine'];
		$cfg['ui']['cardLine'] = sanitize_text_field( (string) $card );

		self::$cache = $cfg;
		return $cfg;
	}

	/**
	 * The campaign line — an announcement the owner writes in Værktøjer → Aianna:
	 * a new partner, a season, a launch. Three plain fields, no HTML, because the
	 * point is that G can change it without a session (G, 6 Sep 2026: "we welcome
	 * Nyhavn Rejser to traveltalk … se Nyhavns velkomsttilbud her").
	 *
	 * The SAME text goes two places — the panel renders it, and the model is handed
	 * it as owner-written fact — so there is one thing to edit, never two that drift.
	 * Empty text = no campaign anywhere; the feature is simply absent.
	 */
	public static function campaign() {
		$text = trim( (string) get_option( 'lmg_concierge_campaign_text', '' ) );
		if ( $text === '' ) return null;

		$out = array( 'text' => $text );
		$url = trim( (string) get_option( 'lmg_concierge_campaign_url', '' ) );
		if ( $url !== '' ) {
			$label        = trim( (string) get_option( 'lmg_concierge_campaign_label', '' ) );
			$out['url']   = $url;
			$out['label'] = $label !== '' ? $label : 'Læs mere';
		}
		return $out;
	}

	/** off | admins | all — default admins, so nothing reader-facing appears by accident. */
	public static function visibility() {
		$v = get_option( 'lmg_concierge_visibility', 'admins' );
		return in_array( $v, array( 'off', 'admins', 'all' ), true ) ? $v : 'admins';
	}

	/**
	 * The portrait, when one has been chosen in the media library.
	 *
	 * Returns null when nothing is set, and the caller then uses the six-file set
	 * in the plugin directory exactly as before — so this is additive and no
	 * existing site changes behaviour until someone picks an image.
	 *
	 * The turn clip is OPTIONAL here, and that is the point. The file set made
	 * all six files mandatory: without the mp4 and its two posters the card
	 * opened on a poster that did not exist and showed a broken image, which is
	 * where Kai has been stuck since 8 Sep 2026. One still is now a complete
	 * avatar; the clip is something to add later, not a precondition.
	 */
	public static function avatar() {
		$id  = (int) get_option( 'lmg_concierge_avatar_id', 0 );
		$url = trim( (string) get_option( 'lmg_concierge_avatar_url', '' ) );

		if ( $id > 0 && wp_attachment_is_image( $id ) ) {
			// Falls back to the full-size file for any size WordPress has not cut
			// — a slightly heavier image, never a missing one.
			$face  = wp_get_attachment_image_url( $id, 'lmgc-face-312' );
			$small = wp_get_attachment_image_url( $id, 'lmgc-face-156' );
			$large = wp_get_attachment_image_url( $id, 'lmgc-face-480' );
			$full  = wp_get_attachment_image_url( $id, 'full' );
			$face  = $face ? $face : $full;
			if ( ! $face ) return null;
		} elseif ( $url !== '' ) {
			$face = $small = $large = $url;
		} else {
			return null;
		}

		$turn = trim( (string) get_option( 'lmg_concierge_turn_url', '' ) );

		return array(
			'face'      => $face,
			'face1x'    => $small ? $small : $face,
			'faceLarge' => $large ? $large : $face,
			'turn'      => $turn, // '' means: no clip, hold on the still
		);
	}

	/**
	 * The model key. Own option first; falls back to LeisureIntel's key on this
	 * site so the first run needs no new secret. Never rendered anywhere.
	 */
	public static function api_key() {
		$key = trim( (string) get_option( 'lmg_concierge_api_key', '' ) );
		if ( $key === '' ) $key = trim( (string) get_option( 'li_claude_api_key', '' ) );
		return $key;
	}

	public static function key_source() {
		if ( trim( (string) get_option( 'lmg_concierge_api_key', '' ) ) !== '' ) return 'own';
		if ( trim( (string) get_option( 'li_claude_api_key', '' ) ) !== '' ) return 'leisureintel';
		return 'none';
	}

	/** Should the bubble render for the current visitor? */
	public static function visible_to_current_user() {
		$v = self::visibility();
		if ( $v === 'off' ) return false;
		if ( $v === 'all' ) return true;
		return is_user_logged_in() && current_user_can( 'manage_options' );
	}

	/** The subset of config the browser needs. No limits, no model, no rules. */
	public static function public_config() {
		$cfg = self::get();
		$keys = array( 'id', 'site', 'accent', 'persona', 'ui', 'newsletter', 'keepsake', 'offers', 'analytics' );
		$out = array();
		foreach ( $keys as $k ) if ( isset( $cfg[ $k ] ) ) $out[ $k ] = $cfg[ $k ];
		// Strip the underscore-prefixed author notes; they are for people reading the file.
		$out = self::strip_notes( $out );

		// Added after the strip: the campaign comes from options, not the file, and
		// carries no notes to remove.
		$campaign = self::campaign();
		if ( $campaign ) $out['campaign'] = $campaign;

		return $out;
	}

	private static function strip_notes( $arr ) {
		if ( ! is_array( $arr ) ) return $arr;
		$out = array();
		foreach ( $arr as $k => $v ) {
			if ( is_string( $k ) && strpos( $k, '_' ) === 0 ) continue;
			$out[ $k ] = self::strip_notes( $v );
		}
		return $out;
	}
}
