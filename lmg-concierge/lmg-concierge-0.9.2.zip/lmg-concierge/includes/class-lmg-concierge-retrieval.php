<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Retrieval — the site's own published content, and nothing else.
 *
 * The corpus is queried live rather than indexed into a file: the concierge
 * inherits the site's search (Relevanssi where active), the exclusions are
 * applied in the query, and a post that is unpublished is gone from the corpus
 * the moment it is unpublished. Every URL emitted is get_permalink() — the
 * canonical WordPress returns — never a constructed one (brief §2 P2).
 */
class LMG_Concierge_Retrieval {

	/** Year range to exclude, set per query for the posts_where filter. */
	private static $exclude_years = null;

	/**
	 * @param string $query   Search text (the question, blended with the previous one).
	 * @param array  $cfg     Full config.
	 * @param int    $context Post ID of the page the reader is on, if any.
	 * @return array  Candidate rows: id, title, url, date, categories, excerpt.
	 */
	public static function candidates( $query, $cfg, $context = 0 ) {
		$corpus = isset( $cfg['corpus'] ) ? $cfg['corpus'] : array();
		$limit  = max( 3, min( 12, (int) ( isset( $corpus['candidates'] ) ? $corpus['candidates'] : 8 ) ) );
		$excl   = isset( $corpus['exclusions'] ) ? $corpus['exclusions'] : array();
		$types  = ! empty( $corpus['postTypes'] ) ? (array) $corpus['postTypes'] : array( 'post', 'page' );

		$args = array(
			'post_type'           => $types,
			'post_status'         => 'publish',
			's'                   => $query,
			'posts_per_page'      => $limit + 10,  // headroom: year/category/id exclusions are applied after the query
			'orderby'             => 'relevance',
			'no_found_rows'       => true,
			'ignore_sticky_posts' => true,
		);

		// Category exclusions — only terms that exist, so a missing term does not
		// break the query (WP_Query returns nothing for an invalid tax_query term).
		$slugs = array();
		foreach ( (array) ( isset( $excl['categories'] ) ? $excl['categories'] : array() ) as $slug ) {
			if ( term_exists( $slug, 'category' ) ) $slugs[] = $slug;
		}
		if ( $slugs ) {
			$args['tax_query'] = array( array(
				'taxonomy' => 'category', 'field' => 'slug', 'terms' => $slugs, 'operator' => 'NOT IN',
			) );
		}

		if ( ! empty( $excl['ids'] ) ) {
			$args['post__not_in'] = array_map( 'absint', (array) $excl['ids'] );
		}

		// Two search paths, one result shape.
		//
		// Relevanssi (active on traveltalk.dk) hooks WP_Query's search, but when the
		// query is built programmatically — REST, CLI — its hook returns NOTHING,
		// silently, instead of falling back to core search. Measured 2026-09-05:
		// plain WP_Query( s=Sicilien ) → 0 posts; relevanssi_do_query() → 5. So where
		// Relevanssi exists it is called by its own API, which also honours tax_query.
		// The year exclusion cannot ride on posts_where there (Relevanssi does not
		// query wp_posts by WHERE), so row() re-checks year, category and id for
		// every candidate regardless of which path produced it.
		if ( function_exists( 'relevanssi_do_query' ) ) {
			$q = new WP_Query();
			$q->parse_query( $args );
			relevanssi_do_query( $q );
		} else {
			self::$exclude_years = null;
			if ( ! empty( $excl['dateRange']['from'] ) && ! empty( $excl['dateRange']['to'] ) ) {
				self::$exclude_years = array( (int) $excl['dateRange']['from'], (int) $excl['dateRange']['to'] );
				add_filter( 'posts_where', array( __CLASS__, 'where_exclude_years' ), 10, 2 );
			}
			$q = new WP_Query( $args );

			// Core search is an AND across every word, so a conversational question
			// matches almost nothing while its keywords match plenty. MEASURED on
			// traveltalk.travel, 8 Sep 2026 (no Relevanssi there):
			//   "Where should I go skiing in Italy?" →  1 result
			//   "skiing"                            → 15
			//   "ski"                               → 47
			// A concierge is asked in sentences, so without this the whole feature is
			// weak on exactly its own use case — and it fails quietly, as a plausible
			// "not covered yet". Relevanssi does this itself, so this runs only on the
			// core path, and only when the first pass came back thin.
			// Two widening steps, each only taken if still thin: the content words
			// together, then the single strongest one. It stops as soon as there is
			// enough, so a question that searched well costs nothing extra.
			$have = array();
			foreach ( $q->posts as $p ) $have[ $p->ID ] = true;
			foreach ( self::widen( $query ) as $s ) {
				if ( count( $q->posts ) >= 4 ) break;
				if ( $s === '' || $s === $query ) continue;
				$a2      = $args;
				$a2['s'] = $s;
				$q2      = new WP_Query( $a2 );
				foreach ( (array) $q2->posts as $p ) {
					if ( empty( $have[ $p->ID ] ) ) { $q->posts[] = $p; $have[ $p->ID ] = true; }
				}
			}

			if ( self::$exclude_years ) {
				remove_filter( 'posts_where', array( __CLASS__, 'where_exclude_years' ), 10 );
			}
		}

		$rows = array();
		$seen = array();

		// The page the reader is on comes first, if it is in the corpus. "What is
		// this page about" must work without a search hit.
		if ( $context ) {
			$row = self::row( get_post( $context ), $excl );
			if ( $row ) { $rows[] = $row; $seen[ $row['id'] ] = true; }
		}

		foreach ( $q->posts as $p ) {
			if ( isset( $seen[ $p->ID ] ) ) continue;
			$row = self::row( $p, $excl );
			if ( ! $row ) continue;
			$rows[] = $row;
			$seen[ $p->ID ] = true;
			if ( count( $rows ) >= $limit ) break;
		}

		return $rows;
	}

	/**
	 * The content words of a question — what is left after the words every
	 * sentence contains. Danish and English together, because a reader on either
	 * Traveltalk site may type either. Deliberately a small, boring list: this is
	 * a widening pass, so over-stripping costs nothing but a broader search,
	 * while stripping a real subject word would cost the answer.
	 *
	 * Returns '' when nothing meaningful is left, and the caller then keeps the
	 * original result rather than searching for nothing.
	 */
	/**
	 * Progressively broader searches to try when the sentence itself came back
	 * thin: first the content words together, then the longest one alone. Order
	 * matters — the narrower query runs first, so a precise match is preferred
	 * and the broad one only fills the remaining slots.
	 */
	private static function widen( $query ) {
		$kw = self::keywords( $query );
		if ( $kw === '' ) return array();
		$words = preg_split( '/\s+/u', $kw, -1, PREG_SPLIT_NO_EMPTY );
		$out   = array( $kw );
		if ( count( $words ) > 1 ) {
			usort( $words, function ( $a, $b ) { return mb_strlen( $b ) - mb_strlen( $a ); } );
			$out[] = $words[0];
		}
		return $out;
	}

	private static function keywords( $q ) {
		$stop = array(
			// English
			'a','an','and','are','as','at','be','best','but','by','can','could','do','does','for','from','get','go',
			'good','has','have','how','i','in','is','it','its','me','my','of','on','or','our','should','so','some',
			'that','the','their','there','they','this','to','us','was','we','what','when','where','which','who','why',
			'will','with','would','you','your','about','any','like','time','place','places','visit','see','trip',
			// Danish
			'af','alle','at','bedst','bedste','bør','da','de','den','der','det','du','en','er','et','for','fra','gode',
			'har','hvad','hvem','hvilke','hvilken','hvor','hvordan','hvornår','i','ind','jeg','kan','kunne','man','med',
			'men','mig','min','og','om','os','på','skal','som','til','var','vi','vil','være','et','ikke','rejse','rejser',
		);
		$q = preg_replace( '/[^\p{L}\p{N}\s-]+/u', ' ', (string) $q );
		$out = array();
		foreach ( preg_split( '/\s+/u', $q, -1, PREG_SPLIT_NO_EMPTY ) as $w ) {
			if ( mb_strlen( $w ) < 3 ) continue;
			if ( in_array( mb_strtolower( $w ), $stop, true ) ) continue;
			$out[] = $w;
			if ( count( $out ) >= 4 ) break;
		}
		return implode( ' ', $out );
	}

	public static function where_exclude_years( $where, $wp_query ) {
		global $wpdb;
		if ( ! self::$exclude_years ) return $where;
		list( $from, $to ) = self::$exclude_years;
		$where .= $wpdb->prepare( " AND YEAR({$wpdb->posts}.post_date) NOT BETWEEN %d AND %d", $from, $to );
		return $where;
	}

	/** One candidate row, or null if the post is not in the corpus. */
	public static function row( $p, $excl = array() ) {
		if ( ! $p || $p->post_status !== 'publish' ) return null;
		if ( ! empty( $excl['ids'] ) && in_array( (int) $p->ID, array_map( 'absint', (array) $excl['ids'] ), true ) ) return null;

		$year = (int) substr( $p->post_date, 0, 4 );
		if ( ! empty( $excl['dateRange']['from'] ) && $year >= (int) $excl['dateRange']['from'] && $year <= (int) $excl['dateRange']['to'] ) return null;

		$cats = wp_get_post_categories( $p->ID, array( 'fields' => 'all' ) );
		$cat_names = array(); $cat_slugs = array();
		foreach ( (array) $cats as $c ) { $cat_names[] = $c->name; $cat_slugs[] = $c->slug; }
		if ( ! empty( $excl['categories'] ) && array_intersect( $cat_slugs, (array) $excl['categories'] ) ) return null;

		$text = wp_strip_all_tags( strip_shortcodes( $p->post_content ) );
		$text = preg_replace( '/\s+/u', ' ', $text );

		return array(
			'id'         => (int) $p->ID,
			'title'      => html_entity_decode( get_the_title( $p ), ENT_QUOTES, 'UTF-8' ),
			'url'        => get_permalink( $p ),
			'date'       => substr( $p->post_date, 0, 7 ),
			'categories' => array_slice( $cat_names, 0, 4 ),
			'excerpt'    => wp_html_excerpt( $text, 420, '…' ),
			'image'      => self::thumb( $p->ID ),
		);
	}

	/**
	 * A small thumbnail URL without touching image_downsize(): a share of this
	 * site's attachments carry incomplete metadata (no 'file'/'width' keys), and
	 * core's size lookup then emits PHP warnings — which, in a REST response,
	 * would land inside the JSON. Built from the metadata we can see; full-size
	 * URL as the fallback; empty string when there is no usable image.
	 */
	public static function thumb( $post_id ) {
		$tid = (int) get_post_thumbnail_id( $post_id );
		if ( ! $tid ) return '';
		$full = wp_get_attachment_url( $tid );
		if ( ! $full ) return '';
		$meta = wp_get_attachment_metadata( $tid );
		if ( is_array( $meta ) && ! empty( $meta['sizes']['medium']['file'] ) ) {
			return trailingslashit( dirname( $full ) ) . $meta['sizes']['medium']['file'];
		}
		return $full;
	}

	/**
	 * The primary category of one post, as a slug.
	 *
	 * WordPress has no notion of a primary category; Rank Math does, and this site
	 * runs it, so its meta is read first. Where an editor never set one, the first
	 * category WordPress returns stands in — skipping Uncategorized, which is a
	 * default rather than a statement about the article.
	 *
	 * Returns '' when the post carries nothing usable. A caller must treat that as
	 * "no interest to infer", never as a category named "".
	 */
	public static function primary_category( $post_id ) {
		$post_id = (int) $post_id;
		$cats    = wp_get_post_categories( $post_id, array( 'fields' => 'all' ) );
		if ( ! $cats || is_wp_error( $cats ) ) return '';

		$by_id = array();
		foreach ( $cats as $c ) $by_id[ (int) $c->term_id ] = $c->slug;

		$rm = (int) get_post_meta( $post_id, 'rank_math_primary_category', true );
		if ( $rm && isset( $by_id[ $rm ] ) ) return $by_id[ $rm ];

		foreach ( $cats as $c ) {
			if ( in_array( $c->slug, array( 'uncategorized', 'uncategorised', 'ukategoriseret' ), true ) ) continue;
			return $c->slug;
		}
		return '';
	}

	/**
	 * What the reader was reading about, inferred — the `interest_auto` of the
	 * tailored-signup handoff. Derived from the articles that actually rendered
	 * under the answer, never from the ones the model merely considered.
	 *
	 * The rule is the handoff's: the primary category of the top-ranked post, and
	 * a comma-joined set when the top three share none. "Share" is read literally —
	 * if every one of the top three carries the leader's primary category among
	 * its own, the reader was plainly reading about that one thing and one slug is
	 * the honest answer. Otherwise the set is genuinely mixed, and flattening it to
	 * the first article's category would be a guess presented as a fact.
	 *
	 * Order matters and is the order the sources render in, so this must be handed
	 * the surviving list, in rank order.
	 */
	public static function interest_auto( $post_ids ) {
		$primaries = array();
		foreach ( array_slice( (array) $post_ids, 0, 3 ) as $id ) {
			$slug = self::primary_category( $id );
			if ( $slug !== '' ) $primaries[ (int) $id ] = $slug;
		}
		if ( ! $primaries ) return '';

		$lead = reset( $primaries );
		if ( count( $primaries ) > 1 ) {
			$shared = true;
			foreach ( array_keys( $primaries ) as $id ) {
				$slugs = wp_get_post_categories( $id, array( 'fields' => 'slugs' ) );
				if ( ! is_array( $slugs ) || ! in_array( $lead, $slugs, true ) ) { $shared = false; break; }
			}
			if ( ! $shared ) return implode( ',', array_values( array_unique( $primaries ) ) );
		}
		return $lead;
	}

	/** The candidate block the model reads. Plain text, ids first. */
	public static function format( $rows ) {
		if ( ! $rows ) return "(no articles were retrieved for this question)";
		$out = array();
		foreach ( $rows as $r ) {
			$out[] = sprintf( "[%d] %s\n    %s · %s%s\n    %s",
				$r['id'], $r['title'], $r['date'],
				$r['categories'] ? implode( ', ', $r['categories'] ) : '—',
				'', $r['excerpt'] );
		}
		return implode( "\n\n", $out );
	}

	/**
	 * Brief §2 P3: every link the concierge emits is resolved at answer time and
	 * must return 200. The permalink is our own canonical, so this is a HEAD to
	 * ourselves — cached a day per URL so the cost is paid once, not per answer.
	 * A URL that does not return 200 drops the source rather than shipping a 404.
	 */
	public static function link_ok( $url, $cfg ) {
		if ( empty( $cfg['corpus']['verifyLinks'] ) ) return true;
		$key = 'lmgc_link_' . md5( $url );
		$hit = get_transient( $key );
		if ( $hit === 'ok' ) return true;
		if ( $hit === 'bad' ) return false;

		// 0.8.2: our own published post needs no request to ourselves. The HEAD
		// stays for everything else (the shop, pages we cannot resolve).
		if ( wp_parse_url( $url, PHP_URL_HOST ) === wp_parse_url( home_url(), PHP_URL_HOST ) ) {
			$pid = url_to_postid( $url );
			if ( $pid && get_post_status( $pid ) === 'publish' && get_permalink( $pid ) === $url ) {
				set_transient( $key, 'ok', DAY_IN_SECONDS );
				return true;
			}
		}

		$res  = wp_remote_head( $url, array( 'timeout' => 4, 'redirection' => 3, 'sslverify' => true ) );
		$code = is_wp_error( $res ) ? 0 : (int) wp_remote_retrieve_response_code( $res );
		$ok   = ( $code === 200 );
		// A transient failure (timeout, 5xx) should not blacklist a good URL for a
		// day — cache the negative briefly, the positive for a day.
		set_transient( $key, $ok ? 'ok' : 'bad', $ok ? DAY_IN_SECONDS : 10 * MINUTE_IN_SECONDS );
		return $ok;
	}
}
