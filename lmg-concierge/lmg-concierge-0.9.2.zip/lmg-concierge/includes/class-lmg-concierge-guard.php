<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Guard — the ceiling and the rate limits (brief §8: "build the cap in from the
 * start; do not add it later"). Three gates, cheapest first:
 *   1. per-address burst limit (salted hash, transient, never stored)
 *   2. global daily request count
 *   3. monthly spend against the ceiling — checked BEFORE the model is called
 */
class LMG_Concierge_Guard {

	const SPEND_OPTION = 'lmg_concierge_spend';

	/** @return true|string  true, or a reason code: rate | daily | ceiling | nokey */
	public static function admit( $cfg ) {
		$lim = isset( $cfg['limits'] ) ? $cfg['limits'] : array();

		if ( LMG_Concierge_Config::api_key() === '' ) return 'nokey';

		// 1. burst per address. Salted hash, 10 minutes, abuse control only.
		$per_ip = (int) ( isset( $lim['perIpPer10Min'] ) ? $lim['perIpPer10Min'] : 20 );
		$fp     = 'lmgc_rl_' . substr( hash_hmac( 'sha256', self::remote_addr(), wp_salt( 'auth' ) ), 0, 24 );
		$hits   = (int) get_transient( $fp );
		if ( $hits >= $per_ip ) return 'rate';
		set_transient( $fp, $hits + 1, 10 * MINUTE_IN_SECONDS );

		// 1b. per address per day — the burst limit alone would let one address
		// spend the whole month in an afternoon (20 × 6 × 24 × 0.03 USD).
		$per_ip_day = (int) ( isset( $lim['perIpPerDay'] ) ? $lim['perIpPerDay'] : 60 );
		$fpd        = 'lmgc_rld_' . gmdate( 'Ymd' ) . substr( $fp, 8, 16 );
		$dhits      = (int) get_transient( $fpd );
		if ( $dhits >= $per_ip_day ) return 'rate';
		set_transient( $fpd, $dhits + 1, DAY_IN_SECONDS + HOUR_IN_SECONDS );

		// 2. global daily count
		$daily = (int) ( isset( $lim['dailyRequests'] ) ? $lim['dailyRequests'] : 600 );
		$dkey  = 'lmgc_day_' . gmdate( 'Ymd' );
		$dn    = (int) get_transient( $dkey );
		if ( $dn >= $daily ) return 'daily';
		set_transient( $dkey, $dn + 1, DAY_IN_SECONDS + HOUR_IN_SECONDS );

		// 2b. global daily spend — no single day may eat the month.
		$daily_usd = (float) ( isset( $lim['dailySpendUsd'] ) ? $lim['dailySpendUsd'] : 0 );
		if ( $daily_usd > 0 && self::day_spend() >= $daily_usd ) return 'ceiling_day';

		// 3. monthly ceiling
		$ceiling = (float) ( isset( $lim['monthlyCeilingUsd'] ) ? $lim['monthlyCeilingUsd'] : 0 );
		if ( $ceiling > 0 && self::month_spend() >= $ceiling ) return 'ceiling';

		return true;
	}

	/** Spend this calendar month (UTC), USD. */
	public static function month_spend( $ym = null ) {
		$ym    = $ym ? $ym : gmdate( 'Y-m' );
		$spend = get_option( self::SPEND_OPTION, array() );
		return isset( $spend[ $ym ]['usd'] ) ? (float) $spend[ $ym ]['usd'] : 0.0;
	}

	public static function month_stats( $ym = null ) {
		$ym    = $ym ? $ym : gmdate( 'Y-m' );
		$spend = get_option( self::SPEND_OPTION, array() );
		$row   = isset( $spend[ $ym ] ) ? $spend[ $ym ] : array();
		return array(
			'usd'   => isset( $row['usd'] ) ? (float) $row['usd'] : 0.0,
			'calls' => isset( $row['calls'] ) ? (int) $row['calls'] : 0,
			'in'    => isset( $row['in'] ) ? (int) $row['in'] : 0,
			'out'   => isset( $row['out'] ) ? (int) $row['out'] : 0,
		);
	}

	/** Spend today (UTC), USD. A transient, so it expires on its own. */
	public static function day_spend() {
		return (float) get_transient( 'lmgc_spend_' . gmdate( 'Ymd' ) );
	}

	/** Record one model call. Keeps the last 13 months. */
	public static function record( $usd, $in, $out ) {
		set_transient( 'lmgc_spend_' . gmdate( 'Ymd' ), self::day_spend() + (float) $usd, 2 * DAY_IN_SECONDS );
		$ym    = gmdate( 'Y-m' );
		$spend = get_option( self::SPEND_OPTION, array() );
		if ( ! isset( $spend[ $ym ] ) ) $spend[ $ym ] = array( 'usd' => 0.0, 'calls' => 0, 'in' => 0, 'out' => 0 );
		$spend[ $ym ]['usd']   += (float) $usd;
		$spend[ $ym ]['calls'] += 1;
		$spend[ $ym ]['in']    += (int) $in;
		$spend[ $ym ]['out']   += (int) $out;
		krsort( $spend );
		$spend = array_slice( $spend, 0, 13, true );
		update_option( self::SPEND_OPTION, $spend, false );
	}

	public static function remote_addr() {
		foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ) as $key ) {
			if ( ! empty( $_SERVER[ $key ] ) ) {
				$parts = explode( ',', $_SERVER[ $key ] );
				return trim( $parts[0] );
			}
		}
		return '0.0.0.0';
	}
}
