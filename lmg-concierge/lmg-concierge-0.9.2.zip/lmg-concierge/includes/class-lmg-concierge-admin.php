<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Værktøjer → Aianna. Status first, counts second — an empty dashboard must
 * never be ambiguous between "no readers" and "switched off" (lmg-match lesson,
 * 2026-09-05).
 */
class LMG_Concierge_Admin {

	public static function boot() {
		add_action( 'admin_menu', function () {
			// The menu carries the site's own persona: Aianna on traveltalk,
			// Bottiglia on winetalk. One codebase, two names.
			$cfg  = LMG_Concierge_Config::get();
			$name = isset( $cfg['persona']['name'] ) && $cfg['persona']['name'] !== '' ? $cfg['persona']['name'] : 'Aianna';
			$hook = add_management_page( $name, $name, 'manage_options', 'lmg-concierge', array( __CLASS__, 'page' ) );
			// The media library's own picker, on this screen only.
			add_action( 'load-' . $hook, function () { wp_enqueue_media(); } );
		} );
		add_action( 'admin_post_lmg_concierge_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_lmg_concierge_export', array( __CLASS__, 'export' ) );
	}

	/**
	 * CSV out. The question text is the harvested search data, and until now it
	 * only ever expired — there was no way to carry a year of it into a
	 * spreadsheet, a brief or next October's comparison.
	 *
	 * Excel reads a bare UTF-8 CSV as Latin-1 and turns "Grækenland" into
	 * mojibake, so the BOM goes first. The whole point is Danish question text.
	 */
	public static function export() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Ingen adgang' );
		check_admin_referer( 'lmg_concierge_export' );

		$days = isset( $_GET['days'] ) ? (int) $_GET['days'] : 365;
		if ( $days < 1 || $days > 3650 ) $days = 365;
		$only_real = empty( $_GET['include_tests'] );

		$cfg  = LMG_Concierge_Config::get();
		$site = isset( $cfg['site'] ) ? sanitize_title( $cfg['site'] ) : 'lmg';
		$name = sprintf( '%s-aianna-%dd-%s%s.csv', $site, $days, gmdate( 'Y-m-d' ), $only_real ? '' : '-med-test' );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $name . '"' );

		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" );
		fputcsv( $out, LMG_Concierge_Log::columns() );
		foreach ( LMG_Concierge_Log::export( $days, $only_real ) as $row ) {
			fputcsv( $out, array_values( $row ) );
		}
		fclose( $out );
		exit;
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Ingen adgang' );
		check_admin_referer( 'lmg_concierge_save' );

		$vis = isset( $_POST['visibility'] ) ? sanitize_key( $_POST['visibility'] ) : 'admins';
		update_option( 'lmg_concierge_visibility', in_array( $vis, array( 'off', 'admins', 'all' ), true ) ? $vis : 'admins' );

		// Empty field = keep the stored key. A blank submit must never wipe a secret by accident.
		if ( isset( $_POST['api_key'] ) && trim( $_POST['api_key'] ) !== '' ) {
			update_option( 'lmg_concierge_api_key', sanitize_text_field( wp_unslash( $_POST['api_key'] ) ), false );
		}
		if ( ! empty( $_POST['clear_key'] ) ) delete_option( 'lmg_concierge_api_key' );

		$model = isset( $_POST['model'] ) ? sanitize_text_field( wp_unslash( $_POST['model'] ) ) : '';
		update_option( 'lmg_concierge_model', preg_match( '/^[a-z0-9.-]{3,48}$/', $model ) ? $model : '' );

		$ceiling = isset( $_POST['ceiling_usd'] ) ? trim( $_POST['ceiling_usd'] ) : '';
		update_option( 'lmg_concierge_ceiling_usd', ( $ceiling !== '' && is_numeric( $ceiling ) && (float) $ceiling >= 0 ) ? (string) (float) $ceiling : '' );

		update_option( 'lmg_concierge_resting_line', isset( $_POST['resting_line'] ) ? sanitize_text_field( wp_unslash( $_POST['resting_line'] ) ) : '' );

		$shape = isset( $_POST['card_shape'] ) ? sanitize_key( $_POST['card_shape'] ) : 'tall';
		update_option( 'lmg_concierge_card_shape', in_array( $shape, array( 'tall', 'wide' ), true ) ? $shape : 'tall' );
		update_option( 'lmg_concierge_card_line', isset( $_POST['card_line'] ) ? sanitize_text_field( wp_unslash( $_POST['card_line'] ) ) : '' );

		// Portrait. An attachment id is the normal route; the URL field is there
		// for a file that is already on the server and not in the library.
		update_option( 'lmg_concierge_avatar_id', isset( $_POST['avatar_id'] ) ? max( 0, (int) $_POST['avatar_id'] ) : 0 );
		$a_url = isset( $_POST['avatar_url'] ) ? trim( wp_unslash( $_POST['avatar_url'] ) ) : '';
		update_option( 'lmg_concierge_avatar_url', $a_url !== '' ? esc_url_raw( $a_url ) : '' );
		$t_url = isset( $_POST['turn_url'] ) ? trim( wp_unslash( $_POST['turn_url'] ) ) : '';
		update_option( 'lmg_concierge_turn_url', $t_url !== '' ? esc_url_raw( $t_url ) : '' );

		// The alert threshold belongs to whoever reads the mail, not to whoever
		// wrote the plugin — G will want to raise it the week it gets noisy, and
		// he should not need a session to do it.
		$min = isset( $_POST['alert_min_asks'] ) ? (int) $_POST['alert_min_asks'] : 5;
		update_option( 'lmg_concierge_alert_min_asks', max( 2, min( 100, $min ) ) );
		$share = isset( $_POST['alert_thin_share'] ) ? (int) $_POST['alert_thin_share'] : 60;
		update_option( 'lmg_concierge_alert_thin_share', max( 1, min( 100, $share ) ) );
		$mail = isset( $_POST['alert_email'] ) ? sanitize_email( wp_unslash( $_POST['alert_email'] ) ) : '';
		update_option( 'lmg_concierge_alert_email', is_email( $mail ) ? $mail : '' );

		// Campaign: plain text only. sanitize_textarea_field keeps line breaks and
		// strips tags, so nothing the owner pastes can inject markup into the panel.
		update_option( 'lmg_concierge_campaign_text', isset( $_POST['campaign_text'] ) ? sanitize_textarea_field( wp_unslash( $_POST['campaign_text'] ) ) : '' );
		$c_url = isset( $_POST['campaign_url'] ) ? trim( wp_unslash( $_POST['campaign_url'] ) ) : '';
		update_option( 'lmg_concierge_campaign_url', $c_url !== '' ? esc_url_raw( $c_url ) : '' );
		update_option( 'lmg_concierge_campaign_label', isset( $_POST['campaign_label'] ) ? sanitize_text_field( wp_unslash( $_POST['campaign_label'] ) ) : '' );

		wp_safe_redirect( add_query_arg( array( 'page' => 'lmg-concierge', 'saved' => 1 ), admin_url( 'tools.php' ) ) );
		exit;
	}

	public static function page() {
		$cfg   = LMG_Concierge_Config::get();
		$vis   = LMG_Concierge_Config::visibility();
		$ksrc  = LMG_Concierge_Config::key_source();
		$month = LMG_Concierge_Guard::month_stats();
		$ceil  = (float) ( isset( $cfg['limits']['monthlyCeilingUsd'] ) ? $cfg['limits']['monthlyCeilingUsd'] : 0 );
		$model = isset( $cfg['model']['id'] ) ? $cfg['model']['id'] : '';

		// --- status line: which state are we in? ------------------------------
		$problems = array();
		if ( $ksrc === 'none' ) $problems[] = 'Ingen API-nøgle — Aianna kan ikke svare.';
		if ( $vis === 'off' ) $problems[] = 'Slået fra — boblen vises for ingen.';
		if ( $ceil > 0 && $month['usd'] >= $ceil ) $problems[] = sprintf( 'Loftet er nået (%.2f af %.2f USD) — Aianna holder pause til næste måned.', $month['usd'], $ceil );
		elseif ( $ceil > 0 && $month['usd'] >= 0.8 * $ceil ) $problems[] = sprintf( '80 %% af loftet brugt (%.2f af %.2f USD).', $month['usd'], $ceil );

		$vis_label = array( 'off' => 'ingen', 'admins' => 'kun indloggede administratorer', 'all' => 'alle læsere' );

		echo '<div class="wrap"><h1>' . esc_html( isset( $cfg['persona']['name'] ) ? $cfg['persona']['name'] : 'Aianna' ) . ' — ' . esc_html( isset( $cfg['site'] ) ? $cfg['site'] : '' ) . '</h1>';
		if ( isset( $_GET['saved'] ) ) echo '<div class="notice notice-success is-dismissible"><p>Gemt.</p></div>';

		if ( $problems ) {
			echo '<div class="notice notice-warning"><p><strong>⚠️ ' . esc_html( implode( ' ', $problems ) ) . '</strong></p></div>';
		} else {
			printf( '<div class="notice notice-success"><p><strong>✅ Svarer.</strong> Synlig for %s · model <code>%s</code> · nøgle: %s · forbrug denne måned <strong>%.2f USD</strong> af %s · %d kald.</p></div>',
				esc_html( $vis_label[ $vis ] ), esc_html( $model ),
				$ksrc === 'own' ? 'egen' : 'LeisureIntels',
				$month['usd'], $ceil > 0 ? esc_html( number_format( $ceil, 2 ) . ' USD' ) : 'intet loft', $month['calls'] );
		}

		$lim = isset( $cfg['limits'] ) ? $cfg['limits'] : array();
		printf( '<p style="color:#555"><strong>Grænser:</strong> %d ture pr. samtale · %d pr. adresse pr. 10 min · %d pr. adresse pr. dag · %d spørgsmål pr. dag · %s USD pr. dag · %s USD pr. måned. <strong>I dag:</strong> %d spørgsmål, %.2f USD.</p>',
			(int) ( isset( $lim['maxTurns'] ) ? $lim['maxTurns'] : 12 ), (int) ( isset( $lim['perIpPer10Min'] ) ? $lim['perIpPer10Min'] : 20 ),
			(int) ( isset( $lim['perIpPerDay'] ) ? $lim['perIpPerDay'] : 60 ), (int) ( isset( $lim['dailyRequests'] ) ? $lim['dailyRequests'] : 600 ),
			esc_html( number_format( (float) ( isset( $lim['dailySpendUsd'] ) ? $lim['dailySpendUsd'] : 0 ), 2 ) ), esc_html( number_format( $ceil, 2 ) ),
			(int) get_transient( 'lmgc_day_' . gmdate( 'Ymd' ) ), LMG_Concierge_Guard::day_spend() );

		// --- settings ---------------------------------------------------------
		echo '<h2>Indstillinger</h2>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'lmg_concierge_save' );
		echo '<input type="hidden" name="action" value="lmg_concierge_save">';
		echo '<table class="form-table" style="max-width:760px">';
		echo '<tr><th>Synlig for</th><td><select name="visibility">';
		foreach ( $vis_label as $k => $label ) printf( '<option value="%s" %s>%s</option>', $k, selected( $vis, $k, false ), esc_html( $label ) );
		echo '</select><p class="description">»kun administratorer« lader dig teste på det levende site, uden at læsere ser noget.</p></td></tr>';
		$shape = get_option( 'lmg_concierge_card_shape', 'tall' );
		echo '<tr><th>Kortets form</th><td><select name="card_shape">';
		foreach ( array( 'tall' => 'højt — portræt med linje under (nuværende)', 'wide' => 'bredt — halvt portræt, halvt forklaring' ) as $k => $label ) {
			printf( '<option value="%s" %s>%s</option>', $k, selected( $shape, $k, false ), esc_html( $label ) );
		}
		echo '</select><p class="description">Det brede kort er lige så <strong>højt</strong> som det høje — det vokser til siden, ikke nedad. Kun det brede har plads til at forklare, hvad hun er; det høje har kun plads til hvilelinjen.</p></td></tr>';

		echo '<tr><th>Hvilelinje</th><td><input type="text" name="resting_line" value="' . esc_attr( get_option( 'lmg_concierge_resting_line', '' ) ) . '" style="width:100%;max-width:480px" placeholder="' . esc_attr( isset( $cfg['ui']['restingLine'] ) ? $cfg['ui']['restingLine'] : '' ) . '"><p class="description">Den korte opfordring. I det høje kort står den under portrættet; i det brede står den nederst inde i kortet. Hold den kort — den skal ikke ombrydes.</p></td></tr>';

		echo '<tr><th>Forklaring</th><td><textarea name="card_line" rows="2" style="width:100%;max-width:480px" placeholder="Aianna er Traveltalks AI-rejseguide. Hun svarer ud fra vores egne artikler.">' . esc_textarea( get_option( 'lmg_concierge_card_line', '' ) ) . '</textarea>';
		echo '<p class="description"><strong>Vises kun i det brede kort.</strong> Dette er nyt for folk — sig hvad hun er, og hvad hun gør ved spørgsmålet. Hold den på to linjer: ca. 90–110 tegn er, hvad der er plads til ved siden af portrættet.</p></td></tr>';
		// --- portrait ---------------------------------------------------------
		$av_id  = (int) get_option( 'lmg_concierge_avatar_id', 0 );
		$av_src = $av_id ? wp_get_attachment_image_url( $av_id, 'lmgc-face-156' ) : '';
		if ( ! $av_src ) $av_src = trim( (string) get_option( 'lmg_concierge_avatar_url', '' ) );
		$pname  = isset( $cfg['persona']['name'] ) ? $cfg['persona']['name'] : 'Aianna';

		echo '<tr><th>Portræt</th><td>';
		echo '<div style="display:flex;gap:1em;align-items:flex-start">';
		printf( '<img id="lmgc-av-preview" src="%s" alt="" style="width:80px;height:106px;object-fit:cover;border-radius:10px;background:#f0f0f1;%s">',
			esc_url( $av_src ), $av_src ? '' : 'display:none' );
		echo '<div>';
		echo '<input type="hidden" id="lmgc-av-id" name="avatar_id" value="' . esc_attr( $av_id ) . '">';
		echo '<p><button type="button" class="button" id="lmgc-av-pick">Vælg billede</button> ';
		echo '<button type="button" class="button-link" id="lmgc-av-clear" style="color:#b32d2e;' . ( $av_src ? '' : 'display:none' ) . '">Fjern</button></p>';
		printf( '<p class="description">Ét billede er nok. WordPress beskærer selv til de tre størrelser, kortet bruger (%d × %d og op/ned derfra). Tomt felt = de håndskårne filer i plugin-mappen, som før.</p>',
			(int) LMG_CONCIERGE_FACE_W, (int) LMG_CONCIERGE_FACE_H );
		echo '<p><label>…eller en adresse <input type="url" name="avatar_url" value="' . esc_attr( get_option( 'lmg_concierge_avatar_url', '' ) ) . '" style="width:100%;max-width:360px" placeholder="https://…/' . esc_attr( sanitize_title( $pname ) ) . '.jpg"></label></p>';
		echo '<p><label>Turn-klip, valgfrit <input type="url" name="turn_url" value="' . esc_attr( get_option( 'lmg_concierge_turn_url', '' ) ) . '" style="width:100%;max-width:360px" placeholder="https://…/' . esc_attr( sanitize_title( $pname ) ) . '-turn.mp4"></label></p>';
		echo '<p class="description">Klippet spiller <strong>én gang</strong> og bliver stående på sidste billede — aldrig i løkke. Uden klip står portrættet stille, og det er et færdigt resultat, ikke et halvt.</p>';
		echo '</div></div></td></tr>';

		echo '<tr><th>Kampagne</th><td>';
		echo '<textarea name="campaign_text" rows="3" style="width:100%;max-width:480px" placeholder="F.eks.: Vi byder Nyhavn Rejser velkommen hos Traveltalk. Du kan allerede nu søge på Nyhavn.">' . esc_textarea( get_option( 'lmg_concierge_campaign_text', '' ) ) . '</textarea>';
		echo '<p class="description">Vises i panelet under hilsenen, og Aianna får den samme tekst som redaktionens eget udsagn, så hun kan svare på den. <strong>Ren tekst — ingen HTML.</strong> Hun siger intet ud over det, der står her: skriv prisen eller datoen med, hvis den skal kunne nævnes. Tom = ingen kampagne.</p>';
		echo '<p><label>Link <input type="url" name="campaign_url" value="' . esc_attr( get_option( 'lmg_concierge_campaign_url', '' ) ) . '" style="width:100%;max-width:360px" placeholder="https://traveltalk.dk/…"></label></p>';
		echo '<p><label>Linktekst <input type="text" name="campaign_label" value="' . esc_attr( get_option( 'lmg_concierge_campaign_label', '' ) ) . '" style="width:260px" placeholder="Læs mere"></label></p>';
		echo '<p class="description">Linket skal pege på en side, der findes — skriv siden først, link så. Uden link vises kun teksten.</p></td></tr>';
		echo '<tr><th>Model</th><td><input type="text" name="model" value="' . esc_attr( get_option( 'lmg_concierge_model', '' ) ) . '" style="width:260px" placeholder="' . esc_attr( isset( $cfg['model']['id'] ) ? $cfg['model']['id'] : '' ) . '"><p class="description">Tom = filens valg. <code>claude-opus-5</code> · <code>claude-sonnet-5</code> (ca. en tredjedel af prisen) · <code>claude-haiku-4-5</code>.</p></td></tr>';
		echo '<tr><th>Månedligt loft (USD)</th><td><input type="number" step="0.5" min="0" name="ceiling_usd" value="' . esc_attr( get_option( 'lmg_concierge_ceiling_usd', '' ) ) . '" style="width:120px" placeholder="' . esc_attr( $ceil ) . '"><p class="description">Når forbruget rammer loftet, holder Aianna pause — intet kald sendes. 0 = intet loft.</p></td></tr>';
		echo '<tr><th>API-nøgle</th><td><input type="password" name="api_key" value="" autocomplete="new-password" style="width:100%;max-width:480px" placeholder="' . ( $ksrc === 'own' ? 'gemt — skriv kun for at udskifte' : ( $ksrc === 'leisureintel' ? 'bruger LeisureIntels nøgle — skriv for at give Aianna sin egen' : 'ingen nøgle fundet' ) ) . '">';
		if ( $ksrc === 'own' ) echo '<br><label><input type="checkbox" name="clear_key" value="1"> Slet Aiannas egen nøgle (fald tilbage til LeisureIntels)</label>';
		echo '</td></tr>';
		$next = wp_next_scheduled( 'lmg_concierge_weekly_demand' );
		echo '<tr><th>Efterspørgsels-alarm</th><td>';
		echo '<label>Mindst <input type="number" min="2" max="100" name="alert_min_asks" value="' . esc_attr( get_option( 'lmg_concierge_alert_min_asks', 5 ) ) . '" style="width:70px"> spørgsmål om samme emne</label> ';
		echo '<label>og mindst <input type="number" min="1" max="100" name="alert_thin_share" value="' . esc_attr( get_option( 'lmg_concierge_alert_thin_share', 60 ) ) . '" style="width:70px"> % af dem tynde</label>';
		echo '<p><label>Mail til <input type="email" name="alert_email" value="' . esc_attr( get_option( 'lmg_concierge_alert_email', '' ) ) . '" style="width:100%;max-width:320px" placeholder="' . esc_attr( get_option( 'admin_email' ) ) . '"></label></p>';
		echo '<p class="description">Én mail om ugen, og <strong>kun hvis noget er over grænsen</strong> — en fast ugentlig mail uden indhold holder man op med at læse. '
		   . 'Hæv tallet, når den bliver støjende. Næste kørsel: ' . ( $next ? esc_html( date_i18n( 'j. M Y H:i', $next ) ) : '<strong>ikke planlagt — deaktivér og aktivér plugin\'et</strong>' ) . '.</p>';
		echo '</td></tr>';
		echo '</table><p><button class="button button-primary">Gem</button></p></form>';

		// The media picker. Inline because it is twenty lines bound to the three
		// ids above, and a separate file would be one more thing to keep in step.
		?>
		<script>
		( function () {
			var pick = document.getElementById( 'lmgc-av-pick' ),
			    clear = document.getElementById( 'lmgc-av-clear' ),
			    field = document.getElementById( 'lmgc-av-id' ),
			    prev  = document.getElementById( 'lmgc-av-preview' ),
			    frame;
			if ( ! pick ) return;
			// 0.8.1: wp.media is loaded in the footer, after this script has run, so it is looked
			// for at the click, not here. Checking it here left the button dead on every site.
			pick.addEventListener( 'click', function () {
				if ( ! window.wp || ! wp.media ) { alert( 'The media library is not loaded on this page. Reload the page and try again, or paste the image address in the field below.' ); return; }
				if ( ! frame ) {
					frame = wp.media( { title: 'Vælg portræt', library: { type: 'image' }, button: { text: 'Brug billedet' }, multiple: false } );
					frame.on( 'select', function () {
						var a = frame.state().get( 'selection' ).first().toJSON(),
						    s = ( a.sizes && a.sizes['lmgc-face-156'] ) ? a.sizes['lmgc-face-156'].url : a.url;
						field.value = a.id;
						prev.src = s;
						prev.style.display = '';
						clear.style.display = '';
					} );
				}
				frame.open();
			} );
			clear.addEventListener( 'click', function () {
				field.value = '';
				prev.style.display = 'none';
				clear.style.display = 'none';
			} );
		} )();
		</script>
		<?php

		// --- readout ----------------------------------------------------------

		// EFTERSPØRGSEL FØRST. Rålisten nedenfor er hændelser; denne er mønsteret,
		// og mønsteret er dét, man kan træffe en beslutning på (G, 9. sep. 2026:
		// »if we have 10 or 100 searches for hotels in Marbella … so I can decide
		// to write one or hook up with a partner or not«).
		$min    = (int) get_option( 'lmg_concierge_alert_min_asks', 5 );
		$share  = (int) get_option( 'lmg_concierge_alert_thin_share', 60 );
		$demand = LMG_Concierge_Log::demand( 30, 2, 25 );

		echo '<h2>Efterspørgsel — hvad læserne bliver ved med at spørge om</h2>';
		echo '<p>Emner fra de sidste 30 dage, hyppigste først. <strong>»Tynd«</strong> tæller de gange, svaret måtte være »ikke dækket« eller »delvist«. '
		   . 'Et emne med mange spørgsmål og en høj tynd-andel er enten en artikel at bestille eller en partner at finde — <strong>' . esc_html( $min ) . '+ spørgsmål og mindst ' . esc_html( $share ) . ' % tynde udløser en mail.</strong></p>';
		echo '<p style="color:#666"><em>Kun rigtige samtaler tælles med. Egne test og diagnostik fra kommandolinjen filtreres fra på samtale-formatet, så bestillingslisten ikke kommer til at måle os selv.</em></p>';

		if ( ! $demand ) {
			echo '<p><em>Ingen emner endnu. Der skal to spørgsmål om det samme til, før noget vises her.</em></p>';
		} else {
			echo '<table class="widefat striped" style="max-width:1100px"><thead><tr>'
			   . '<th>Emne</th><th>Spørgsmål</th><th>Heraf tynde</th><th>Tynd-andel</th><th>Senest</th><th>Eksempler</th></tr></thead><tbody>';
			foreach ( $demand as $d ) {
				$hot = ( $d['asks'] >= $min && $d['thin_share'] >= $share );
				echo '<tr' . ( $hot ? ' style="background:#fff3cd"' : '' ) . '>';
				echo '<td><strong>' . esc_html( $d['topic'] ) . '</strong>' . ( $hot ? ' &nbsp;<span title="Over grænsen">🔔</span>' : '' ) . '</td>';
				echo '<td>' . (int) $d['asks'] . '</td>';
				echo '<td>' . (int) $d['thin'] . '</td>';
				echo '<td>' . (int) $d['thin_share'] . ' %</td>';
				echo '<td>' . esc_html( substr( (string) $d['last'], 0, 10 ) ) . '</td>';
				echo '<td style="color:#555">' . esc_html( implode( ' · ', $d['examples'] ) ) . '</td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
		}

		// Every table below obeys this one switch, so the page can never again say
		// two different things at once about who asked what.
		$raw = ! empty( $_GET['include_tests'] );
		$url = function ( $on ) { return esc_url( add_query_arg( array( 'page' => 'lmg-concierge', 'include_tests' => $on ? 1 : false ), admin_url( 'tools.php' ) ) ); };

		echo '<h2>De enkelte spørgsmål</h2>';
		printf( '<p style="padding:.6em .9em;background:%s;border-left:4px solid %s;max-width:1100px">%s &nbsp; <a href="%s" class="button button-small">%s</a></p>',
			$raw ? '#fff3cd' : '#f0f6fc', $raw ? '#dba617' : '#2271b1',
			$raw
				? '<strong>Viser også egne test.</strong> Tallene herunder er ikke læsere — de rummer kommandolinje-prøver og diagnostik. Brug kun denne visning til fejlsøgning.'
				: '<strong>Kun rigtige læsersamtaler.</strong> Egne test og kommandolinje-prøver er filtreret fra på samtale-formatet — også i de rå tabeller, ikke kun i efterspørgslen.',
			$url( ! $raw ), $raw ? 'Vis kun læsere' : 'Vis også egne test' );

		// Which wording is winning — printed above the gaps, because it is the one
		// table on this page that settles an argument rather than opening one.
		$vars = LMG_Concierge_Log::variants( 30 );
		if ( $vars ) {
			echo '<h2>Ordlyd — hvilken version virker</h2>';
			echo '<p>Båndet på forsiden skifter mellem formuleringerne, og linjerne herunder er, hvad læserne gjorde ved hver. '
			   . '<strong>Vist</strong> tæller kun de gange, båndet faktisk kom på skærmen — ikke de gange, det lå under kanten. '
			   . '<strong>Raten</strong> er spørgsmål og gennemførte svarrunder delt med vist.</p>';
			echo '<p style="color:#666"><em>Her kåres ingen vinder. Ved den nuværende trafik er en halv snes spørgsmåls forskel støj, '
			   . 'og en tabel, der udnævnte en vinder, ville blive læst som en dom. Tallene står her; valget er dit.</em></p>';
			self::table( $vars, array( 'variant' => 'Version', 'shown' => 'Vist', 'open' => 'Åbnet', 'ask' => 'Spørgsmål', 'match' => 'Svarrunder', 'rate' => 'Rate %' ) );
		}

		echo '<h2>Huller i dækningen — det, vi ikke har skrevet om</h2>';
		echo '<p>De enkelte spørgsmål bag tallene ovenfor, nyeste først.</p>';
		self::table( LMG_Concierge_Log::gaps( 40, ! $raw ), array( 'created_hour' => 'Time (UTC)', 'lang' => 'Sprog', 'coverage' => 'Dækning', 'question' => 'Spørgsmål' ) );

		echo '<h2>Dækning, 30 dage</h2>';
		self::table( LMG_Concierge_Log::coverage( 30, ! $raw ), array( 'coverage' => 'Dækning', 'n' => 'Antal' ) );

		echo '<h2>Hændelser, 30 dage</h2>';
		self::table( LMG_Concierge_Log::counts( 30, ! $raw ), array( 'kind' => 'Hændelse', 'n' => 'Antal', 'conversations' => 'Samtaler' ) );

		echo '<h2>Mest klikkede artikler, 30 dage</h2>';
		$rows = LMG_Concierge_Log::top_clicked( 30, 15, ! $raw );
		foreach ( $rows as &$r ) { $r['title'] = get_the_title( (int) $r['post_id'] ); }
		unset( $r );
		self::table( $rows, array( 'post_id' => 'ID', 'title' => 'Titel', 'n' => 'Klik' ) );

		echo '<h2>Seneste 30 spørgsmål</h2>';
		self::table( LMG_Concierge_Log::recent( 30, ! $raw ), array( 'created_hour' => 'Time (UTC)', 'lang' => 'Sprog', 'coverage' => 'Dækning', 'status' => 'Status', 'question' => 'Spørgsmål', 'source_ids' => 'Kilder', 'latency_ms' => 'ms', 'cost_usd' => 'USD' ) );

		// --- export ------------------------------------------------------------
		$first = LMG_Concierge_Log::earliest();
		echo '<h2>Hent data ud</h2>';
		echo '<p>Spørgsmålsteksten <em>er</em> søgedataene. En CSV kan åbnes i et regneark, lægges ved et oplæg eller sammenlignes med den samme måned næste år.</p>';
		echo '<form method="get" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="padding:.9em;background:#f6f7f7;border:1px solid #dcdcde;max-width:1100px">';
		echo '<input type="hidden" name="action" value="lmg_concierge_export">';
		wp_nonce_field( 'lmg_concierge_export' );
		echo '<label>Periode <select name="days">';
		foreach ( array( 30 => '30 dage', 90 => '90 dage', 365 => '12 måneder', 3650 => 'alt, hvad der er gemt' ) as $d => $label ) {
			printf( '<option value="%d"%s>%s</option>', $d, selected( $d, 365, false ), esc_html( $label ) );
		}
		echo '</select></label> &nbsp; ';
		echo '<label><input type="checkbox" name="include_tests" value="1"> tag egne test med</label> &nbsp; ';
		echo '<button class="button button-primary">Hent CSV</button>';
		printf( '<p class="description">Alle kolonner, én række pr. hændelse. %s</p>',
			$first ? 'Ældste gemte række: <strong>' . esc_html( substr( (string) $first, 0, 10 ) ) . '</strong>.' : 'Ingen rækker gemt endnu.' );
		echo '</form>';

		printf( '<p style="margin-top:2em;color:#666">Ingen IP, ingen user agent, intet bruger-id, intet id på tværs af besøg. Tidsstempler er rundet til timen. Rækker slettes efter %d dage. Spørgsmålsteksten gemmes, fordi den er emneforskningen — den er den eneste fritekst i tabellen.</p>', (int) LMG_CONCIERGE_RETENTION_DAYS );
		echo '</div>';
	}

	private static function table( $rows, $cols ) {
		if ( ! $rows ) { echo '<p><em>Ingen rækker endnu.</em></p>'; return; }
		echo '<table class="widefat striped" style="max-width:1100px"><thead><tr>';
		foreach ( $cols as $label ) echo '<th>' . esc_html( $label ) . '</th>';
		echo '</tr></thead><tbody>';
		foreach ( $rows as $r ) {
			echo '<tr>';
			foreach ( $cols as $k => $label ) echo '<td>' . esc_html( isset( $r[ $k ] ) ? $r[ $k ] : '' ) . '</td>';
			echo '</tr>';
		}
		echo '</tbody></table>';
	}
}
