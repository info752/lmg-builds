<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Log — brief §8: "Log every conversation, every signup, every outbound click,
 * and every 'we haven't written about that'. Anonymised, no IP, retention short
 * and stated. The last of those four is the most valuable output."
 *
 * One table, one row per event. Timestamps are rounded to the hour: at this
 * site's traffic an exact second plus a distinctive question is close to a
 * fingerprint. No IP, no user agent, no user id, no cross-visit identifier. The
 * conversation token is random, lives in the tab, and stitches turns together
 * for one visit only.
 */
class LMG_Concierge_Log {

	const TABLE = 'lmg_concierge_log';

	// Bump when the schema changes. 2: variant, added 4 Oct 2026 so two wordings
	// of the same band can be told apart by what readers did with them.
	const DB_VERSION = 2;

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . self::TABLE;
	}

	public static function install() {
		global $wpdb;
		$table   = self::table();
		$collate = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created_hour DATETIME NOT NULL,
			site VARCHAR(48) NOT NULL,
			conversation CHAR(16) NOT NULL,
			turn SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			kind VARCHAR(16) NOT NULL,
			lang CHAR(2) DEFAULT NULL,
			question VARCHAR(600) DEFAULT NULL,
			coverage VARCHAR(8) DEFAULT NULL,
			source_ids VARCHAR(120) DEFAULT NULL,
			post_id BIGINT UNSIGNED DEFAULT NULL,
			model VARCHAR(48) DEFAULT NULL,
			tokens_in INT UNSIGNED DEFAULT NULL,
			tokens_out INT UNSIGNED DEFAULT NULL,
			cost_usd DECIMAL(10,6) DEFAULT NULL,
			latency_ms INT UNSIGNED DEFAULT NULL,
			status VARCHAR(16) DEFAULT NULL,
			variant VARCHAR(32) DEFAULT NULL,
			PRIMARY KEY (id),
			KEY kind_hour (kind, created_hour),
			KEY coverage (coverage),
			KEY conversation (conversation),
			KEY variant (variant)
		) {$collate};";
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
		update_option( 'lmg_concierge_db', self::DB_VERSION, false );
	}

	/**
	 * Run install() when the schema moved under a site that is already live.
	 *
	 * dbDelta is additive and safe to re-run; the guard is only so it does not
	 * run on every request. Activation alone is not enough — a plugin updated in
	 * place is never deactivated, so a column added in a release would never
	 * appear and every write touching it would fail silently.
	 */
	public static function maybe_upgrade() {
		if ( (int) get_option( 'lmg_concierge_db', 0 ) === self::DB_VERSION ) return;
		self::install();
	}

	/** Insert one row. Only named columns; anything else is dropped. */
	public static function write( $row ) {
		global $wpdb;
		$allowed = array( 'site', 'conversation', 'turn', 'kind', 'lang', 'question', 'coverage', 'source_ids', 'post_id', 'model', 'tokens_in', 'tokens_out', 'cost_usd', 'latency_ms', 'status', 'variant' );
		$data = array( 'created_hour' => gmdate( 'Y-m-d H:00:00' ) );
		foreach ( $allowed as $k ) {
			if ( ! array_key_exists( $k, $row ) || $row[ $k ] === null ) continue;
			$v = $row[ $k ];
			if ( $k === 'question' ) $v = mb_substr( sanitize_textarea_field( (string) $v ), 0, 600 );
			elseif ( in_array( $k, array( 'turn', 'post_id', 'tokens_in', 'tokens_out', 'latency_ms' ), true ) ) $v = (int) $v;
			elseif ( $k === 'cost_usd' ) $v = round( (float) $v, 6 );
			elseif ( $k === 'source_ids' ) $v = substr( implode( ',', array_map( 'absint', (array) $v ) ), 0, 120 );
			else $v = substr( sanitize_text_field( (string) $v ), 0, 64 );
			$data[ $k ] = $v;
		}
		$wpdb->insert( self::table(), $data );
	}

	public static function prune( $days ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( "DELETE FROM " . self::table() . " WHERE created_hour < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)", (int) $days ) );
	}

	// --- readout queries -----------------------------------------------------

	/**
	 * $only_real on every readout, not just demand().
	 *
	 * The filter below was written for demand() alone on 9 Sep 2026, and that was
	 * half a fix: the four raw tables kept showing our own probes, so the admin
	 * page contradicted itself — one table said "readers ask about places", the
	 * one under it said "readers ask what it costs", and the second was fifteen
	 * curl calls. On 4 Oct 2026 that is exactly what the page was read to mean.
	 * The tables now agree by default, and the checkbox puts the probes back for
	 * anyone debugging.
	 */
	public static function counts( $days = 30, $only_real = true ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT kind, COUNT(*) n, COUNT(DISTINCT conversation) conversations
			 FROM " . self::table() . " WHERE created_hour >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)"
			 . ( $only_real ? self::real_traffic_sql() : '' ) . "
			 GROUP BY kind ORDER BY n DESC", (int) $days ), ARRAY_A );
	}

	public static function coverage( $days = 30, $only_real = true ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT coverage, COUNT(*) n FROM " . self::table() . "
			 WHERE kind = 'ask' AND status = 'ok' AND created_hour >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)"
			 . ( $only_real ? self::real_traffic_sql() : '' ) . "
			 GROUP BY coverage", (int) $days ), ARRAY_A );
	}

	/** "We haven't written about that" — the list of what to write. */
	public static function gaps( $limit = 40, $only_real = true ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT created_hour, lang, coverage, question FROM " . self::table() . "
			 WHERE kind = 'ask' AND status = 'ok' AND coverage IN ('none','partial')"
			 . ( $only_real ? self::real_traffic_sql() : '' ) . "
			 ORDER BY id DESC LIMIT %d", (int) $limit ), ARRAY_A );
	}

	/**
	 * Real reader conversations only.
	 *
	 * The panel mints its conversation token as 'c' + 8 base36 chars + 5 more
	 * (see token() in the panel script), so every genuine conversation is exactly
	 * 'c' followed by 13 chars of [a-z0-9]. A hand-made probe from a console or a
	 * curl never has that shape.
	 *
	 * THIS IS NOT COSMETIC. On 9 Sep 2026 roughly 15 of the site's 58 logged
	 * questions were diagnostic probes I had just run, and they had already
	 * distorted the picture — "firenze, asked 5 times, thin every time" was me,
	 * not readers. A commissioning list built on that would have commissioned an
	 * article for an audience of one robot. Demand figures must never include our
	 * own testing.
	 *
	 * It fails safe: a real conversation always matches, so no reader demand is
	 * ever filtered out — only things that could not have come from the panel.
	 */
	public static function real_traffic_sql() {
		return " AND conversation REGEXP '^c[a-z0-9]{13}$' ";
	}

	/**
	 * EXPORT — every column, every row, for a period. The log is the only record
	 * of what readers asked, and until 4 Oct 2026 it had no way out of the
	 * database: it expired in place. A pattern you cannot carry forward is not an
	 * asset.
	 *
	 * $only_real applies the same filter the demand table uses, so an export can
	 * be reader traffic alone or the whole table including our own probes. Both
	 * are legitimate — the first for editorial decisions, the second for
	 * debugging — and the caller says which, rather than the function guessing.
	 *
	 * Streamed in batches: a year of rows is small today, but an export that
	 * works at 400 rows and dies at 400,000 is a trap left for later.
	 */
	public static function export( $days = 365, $only_real = true, $batch = 2000 ) {
		global $wpdb;
		$cols  = 'id, created_hour, site, conversation, turn, kind, lang, question, coverage, source_ids, post_id, model, tokens_in, tokens_out, cost_usd, latency_ms, status, variant';
		$where = $wpdb->prepare( 'created_hour >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)', (int) $days )
		       . ( $only_real ? self::real_traffic_sql() : '' );
		$after = 0;
		while ( true ) {
			$rows = $wpdb->get_results( $wpdb->prepare(
				"SELECT {$cols} FROM " . self::table() . " WHERE {$where} AND id > %d ORDER BY id ASC LIMIT %d",
				(int) $after, (int) $batch ), ARRAY_A );
			if ( ! $rows ) return;
			foreach ( $rows as $r ) { $after = (int) $r['id']; yield $r; }
			if ( count( $rows ) < $batch ) return;
		}
	}

	public static function columns() {
		return array( 'id', 'created_hour', 'site', 'conversation', 'turn', 'kind', 'lang', 'question', 'coverage', 'source_ids', 'post_id', 'model', 'tokens_in', 'tokens_out', 'cost_usd', 'latency_ms', 'status', 'variant' );
	}

	/** Oldest row held, so the page can say what the export actually covers. */
	public static function earliest() {
		global $wpdb;
		return $wpdb->get_var( 'SELECT MIN(created_hour) FROM ' . self::table() );
	}

	/**
	 * DEMAND — the question this whole log exists to answer: what do readers keep
	 * asking that we have not written?
	 *
	 * Groups questions into topic words, counts them, and counts how many of those
	 * asks Aianna could only answer thinly ('none' or 'partial'). A topic with
	 * many asks and a high thin share is either an article to commission or a
	 * partner to sign — which is the decision this is built to support, and it is
	 * G's decision, not the machine's.
	 *
	 * Deliberately word-frequency and not clustering: it must be explainable in
	 * one sentence and auditable by eye. "Marbella asked 7 times, 7 of them thin"
	 * is a fact anyone can check against the raw rows underneath it.
	 */
	public static function demand( $days = 30, $min_asks = 5, $limit = 25 ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT question, coverage, created_hour FROM " . self::table() . "
			 WHERE kind = 'ask' AND status = 'ok' AND question IS NOT NULL
			   AND created_hour >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)"
			 . self::real_traffic_sql(), (int) $days ), ARRAY_A );

		$stop = self::stopwords();
		$agg  = array();
		foreach ( $rows as $r ) {
			$thin  = in_array( $r['coverage'], array( 'none', 'partial' ), true );
			$words = preg_split( '/[^\p{L}\p{N}]+/u', mb_strtolower( (string) $r['question'] ), -1, PREG_SPLIT_NO_EMPTY );
			foreach ( array_unique( $words ) as $w ) {
				if ( mb_strlen( $w ) < 4 || isset( $stop[ $w ] ) ) continue;
				if ( ! isset( $agg[ $w ] ) ) $agg[ $w ] = array( 'topic' => $w, 'asks' => 0, 'thin' => 0, 'last' => '', 'examples' => array() );
				$agg[ $w ]['asks'] += 1;
				if ( $thin ) $agg[ $w ]['thin'] += 1;
				if ( $r['created_hour'] > $agg[ $w ]['last'] ) $agg[ $w ]['last'] = $r['created_hour'];
				if ( count( $agg[ $w ]['examples'] ) < 3 ) $agg[ $w ]['examples'][] = $r['question'];
			}
		}

		$out = array();
		foreach ( $agg as $a ) {
			if ( $a['asks'] < (int) $min_asks ) continue;
			$a['thin_share'] = $a['asks'] ? (int) round( 100 * $a['thin'] / $a['asks'] ) : 0;
			$out[] = $a;
		}
		// Loudest first: how much was asked, then how badly we answered it.
		usort( $out, function ( $x, $y ) {
			if ( $x['asks'] !== $y['asks'] ) return $y['asks'] - $x['asks'];
			return $y['thin_share'] - $x['thin_share'];
		} );
		return array_slice( $out, 0, (int) $limit );
	}

	/** Topics that crossed the bar AND are mostly unanswered — the alert itself. */
	public static function alerts( $days = 30, $min_asks = 5, $min_thin_share = 60 ) {
		$out = array();
		foreach ( self::demand( $days, $min_asks, 50 ) as $d ) {
			if ( $d['thin_share'] >= (int) $min_thin_share ) $out[] = $d;
		}
		return $out;
	}

	/**
	 * Words that carry no subject. Danish and English together — readers on the
	 * group's sites write in both. Kept boring on purpose: a word wrongly left in
	 * shows up as an obviously silly topic and is easy to spot and add here, while
	 * a subject word wrongly removed would hide real demand and nobody would know.
	 */
	private static function stopwords() {
		$list = array(
			'hvad','hvor','hvem','hvilke','hvilken','hvordan','hvornår','koster','pris','priser','bedste','bedst',
			'gode','godt','skal','vil','kan','kunne','have','være','blive','anbefale','anbefaler','synes','tage',
			'rejse','rejser','rejsen','turen','ferie','noget','nogle','meget','mange','sådan','samt','også',
			'about','what','when','where','which','who','how','best','good','cost','costs','price','prices',
			'should','would','could','there','their','this','that','with','from','into','your','you','and','the',
			'trip','travel','going','visit','like','some','more','most','need','want','make','take','time','year',
		);
		$out = array();
		foreach ( $list as $w ) $out[ $w ] = true;
		return $out;
	}

	public static function recent( $limit = 30, $only_real = true ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT created_hour, lang, coverage, status, question, source_ids, latency_ms, cost_usd FROM " . self::table() . "
			 WHERE kind = 'ask'" . ( $only_real ? self::real_traffic_sql() : '' ) . "
			 ORDER BY id DESC LIMIT %d", (int) $limit ), ARRAY_A );
	}

	/**
	 * WHICH WORDING WORKS — G, 4 Oct 2026: "we can interchange them and measure
	 * what works better then keep that until a new version beats it."
	 *
	 * Shown is how often a variant was put in front of someone; the rest is what
	 * they then did. The rate that matters is asks over shown — a band that is
	 * admired and not used has not worked.
	 *
	 * Deliberately NOT declaring a winner. At this traffic a dozen asks apart is
	 * noise, and a readout that announces one would be read as a verdict. It
	 * prints the counts and leaves the call to a person.
	 */
	public static function variants( $days = 30 ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT variant, kind, COUNT(*) n FROM " . self::table() . "
			 WHERE variant IS NOT NULL AND variant <> ''
			   AND created_hour >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)"
			 . self::real_traffic_sql() . "
			 GROUP BY variant, kind", (int) $days ), ARRAY_A );

		$out = array();
		foreach ( $rows as $r ) {
			$v = $r['variant'];
			if ( ! isset( $out[ $v ] ) ) $out[ $v ] = array( 'variant' => $v, 'shown' => 0, 'open' => 0, 'ask' => 0, 'match' => 0 );
			$k = $r['kind'] === 'band_shown' ? 'shown' : $r['kind'];
			if ( isset( $out[ $v ][ $k ] ) ) $out[ $v ][ $k ] += (int) $r['n'];
		}
		foreach ( $out as &$o ) {
			$o['rate'] = $o['shown'] ? round( 100 * ( $o['ask'] + $o['match'] ) / $o['shown'], 1 ) : 0;
		}
		unset( $o );
		usort( $out, function ( $a, $b ) { return $b['shown'] - $a['shown']; } );
		return array_values( $out );
	}

	public static function top_clicked( $days = 30, $limit = 15, $only_real = true ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT post_id, COUNT(*) n FROM " . self::table() . "
			 WHERE kind = 'click' AND post_id IS NOT NULL AND created_hour >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)"
			 . ( $only_real ? self::real_traffic_sql() : '' ) . "
			 GROUP BY post_id ORDER BY n DESC LIMIT %d", (int) $days, (int) $limit ), ARRAY_A );
	}
}
