<?php
/**
 * 0.9.0 – "Aianna for partners" (G, 12 Nov 2026).
 *
 * The Concierge with a transactional layer, on a hidden page of traveltalk.travel
 * that opens only with a personal code. The code carries who the partner is
 * (name, job title, company, e-mail), our page about their destination and their
 * offer. The chat answers from config/partners.json (the knowledge base), shows a
 * mock-up of their profile, and ends in two buttons, "Send me a real offer" and
 * "Book a call", that mail Mio and contact@, plus an unticked box that puts them
 * on the partner newsletter list in Brevo. Per code it counts opens, questions
 * and clicks, so the Asia test can be read per partner.
 *
 * No payment and no price negotiation happen here; people take over.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class LMG_Concierge_Partners {

	const OPT       = 'lmgc_partner_codes';
	const SHORTCODE = 'aianna_partners';
	const CAP       = 'edit_others_posts';

	/** Set for one /partner/ask request; read by LMG_Concierge_Model::ask(). */
	public static $turn_context = '';

	public static function boot() {
		add_shortcode( self::SHORTCODE, array( __CLASS__, 'render' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'admin_menu', function () {
			add_management_page( 'Aianna for partners', 'Aianna for partners', self::CAP, 'lmgc-partners', array( __CLASS__, 'admin_page' ) );
		} );
		add_action( 'admin_post_lmgcp_codes', array( __CLASS__, 'admin_save_codes' ) );
		add_action( 'admin_post_lmgcp_settings', array( __CLASS__, 'admin_save_settings' ) );
		add_action( 'admin_post_lmgcp_archive', array( __CLASS__, 'admin_archive' ) );

		// The page is private: not in Google, not cached, no reader concierge on it.
		add_action( 'template_redirect', function () {
			if ( ! self::is_partner_page() ) return;
			if ( ! defined( 'DONOTCACHEPAGE' ) ) define( 'DONOTCACHEPAGE', true );
			do_action( 'litespeed_control_set_nocache', 'lmg-concierge partner page' );
			nocache_headers();
		} );
		add_filter( 'wp_robots', function ( $robots ) {
			if ( ! self::is_partner_page() ) return $robots;
			return array( 'noindex' => true, 'nofollow' => true );
		}, 99 );
		add_filter( 'rank_math/frontend/robots', function ( $robots ) {
			return self::is_partner_page() ? array( 'index' => 'noindex', 'follow' => 'nofollow' ) : $robots;
		}, 99 );
		add_action( 'wp_enqueue_scripts', function () {
			if ( ! self::is_partner_page() ) return;
			wp_enqueue_style( 'lmg-concierge-partners', LMG_CONCIERGE_URL . 'assets/lmg-concierge-partner.css', array(), LMG_CONCIERGE_VERSION );
			wp_enqueue_script( 'lmg-concierge-partners', LMG_CONCIERGE_URL . 'assets/lmg-concierge-partner.js', array(), LMG_CONCIERGE_VERSION, true );
		} );
	}

	/**
	 * 0.9.1: test mode. Mio and G (logged in with editor rights or more), and
	 * anyone using a master code, can use the page freely: nothing is counted
	 * in a partner's statistics, requests are mailed marked TEST or DEMO, and
	 * the newsletter box adds no one to Brevo.
	 */
	public static function is_staff() {
		return is_user_logged_in() && current_user_can( self::CAP );
	}

	public static function test_mode( $r ) {
		if ( ! empty( $r['master'] ) ) return 'demo';
		return self::is_staff() ? 'test' : '';
	}

	public static function is_partner_page() {
		if ( is_admin() || ! is_singular() ) return false;
		$p = get_queried_object();
		return $p instanceof WP_Post && has_shortcode( (string) $p->post_content, self::SHORTCODE );
	}

	// -------------------------------------------------------------------------
	// Codes
	// -------------------------------------------------------------------------

	public static function all() {
		$c = get_option( self::OPT, array() );
		return is_array( $c ) ? $c : array();
	}

	private static function save_all( $codes ) {
		update_option( self::OPT, $codes, false );
	}

	public static function clean_code( $raw ) {
		return substr( preg_replace( '/[^A-Z0-9]/', '', strtoupper( (string) $raw ) ), 0, 12 );
	}

	/** A live code's record, or null. */
	public static function get( $code ) {
		$code = self::clean_code( $code );
		if ( $code === '' ) return null;
		$all = self::all();
		if ( empty( $all[ $code ] ) || ! empty( $all[ $code ]['archived'] ) ) return null;
		return $all[ $code ];
	}

	private static function touch( $code, $fn ) {
		$all = self::all();
		if ( ! isset( $all[ $code ] ) ) return;
		$all[ $code ] = $fn( $all[ $code ] );
		self::save_all( $all );
	}

	private static function new_code( $all ) {
		$chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O, 1/I
		do {
			$c = '';
			for ( $i = 0; $i < 8; $i++ ) $c .= $chars[ random_int( 0, strlen( $chars ) - 1 ) ];
		} while ( isset( $all[ $c ] ) );
		return $c;
	}

	public static function offers() {
		return array(
			'profile'    => 'Profile: USD 200 for 3 months or USD 500 for a year',
			'free_month' => 'Free first month, then USD 500 for a year',
		);
	}

	private static function first_name( $name ) {
		$p = preg_split( '/\s+/', trim( (string) $name ) );
		return $p && $p[0] !== '' ? $p[0] : '';
	}

	/** The <partner> block the model receives each turn. */
	private static function context( $r ) {
		$offer = ( $r['offer'] === 'free_month' )
			? 'Their offer includes a free first month: the first month is free, then USD 500 for a year if they want to continue. They may also choose USD 200 for 3 months instead.'
			: 'Their offer: USD 200 for 3 months, or USD 500 for a year; they choose. No free month.';
		$lines = array(
			'Name: ' . $r['name'] . ( $r['title'] !== '' ? ' (' . $r['title'] . ')' : '' ),
			'Company: ' . $r['company'],
			'Traveltalk\'s page about their destination: ' . ( $r['dest_title'] !== '' ? $r['dest_title'] . ' – ' : '' ) . $r['dest_url'],
			$offer,
		);
		return implode( "\n", $lines );
	}

	public static function page_url() {
		$id = (int) get_option( 'lmgcp_page_id', 0 );
		return $id ? get_permalink( $id ) : '';
	}

	public static function link( $code ) {
		$u = self::page_url();
		return $u ? add_query_arg( 'code', $code, $u ) : '';
	}

	// -------------------------------------------------------------------------
	// The page
	// -------------------------------------------------------------------------

	public static function render() {
		$code = isset( $_GET['code'] ) ? self::clean_code( wp_unslash( $_GET['code'] ) ) : '';
		$r    = $code !== '' ? self::get( $code ) : null;
		if ( ! $r ) {
			return '<div class="lmgcp lmgcp--closed"><p>This page opens with a personal link from Traveltalk. If yours does not work, write to <a href="mailto:contact@traveltalk.media">contact@traveltalk.media</a>.</p></div>';
		}
		$first   = self::first_name( $r['name'] );
		$company = $r['company'];
		$dest    = $r['dest_title'] !== '' ? $r['dest_title'] : 'destination';
		$avatar  = LMG_Concierge_Config::avatar();
		$data    = array(
			'code'      => $code,
			'endpoint'  => array(
				'ask'    => esc_url_raw( rest_url( 'lmg-concierge/v1/partner/ask' ) ),
				'event'  => esc_url_raw( rest_url( 'lmg-concierge/v1/partner/event' ) ),
				'action' => esc_url_raw( rest_url( 'lmg-concierge/v1/partner/action' ) ),
			),
			'greeting'  => sprintf( 'Hi %s, I\'m Aianna, Traveltalk\'s AI assistant for partners. Ask me anything about putting %s on our %s page: what you get, what it costs and how it works. We keep this conversation so Mio can follow up.', $first !== '' ? $first : 'there', $company, $dest ),
			'face'      => $avatar ? $avatar['face'] : '',
			'test'      => self::test_mode( $r ),
			// Logged-in REST calls need the nonce, or WordPress treats them as anonymous.
			'nonce'     => is_user_logged_in() ? wp_create_nonce( 'wp_rest' ) : '',
		);
		$test = self::test_mode( $r );

		$initials = '';
		foreach ( array_slice( preg_split( '/\s+/', trim( $company ) ), 0, 2 ) as $w ) $initials .= mb_strtoupper( mb_substr( $w, 0, 1 ) );

		ob_start();
		?>
		<div class="lmgcp" data-lmgcp="<?php echo esc_attr( wp_json_encode( $data ) ); ?>">
			<?php if ( $test === 'demo' ) : ?>
				<p class="lmgcp-test">Master code: a demo. Nothing is counted, requests are marked DEMO, and the newsletter box adds no one.</p>
			<?php elseif ( $test === 'test' ) : ?>
				<p class="lmgcp-test">Preview: you are logged in, so nothing you do here counts in <?php echo esc_html( $company ); ?>'s statistics. Requests are marked TEST, and the newsletter box adds no one.</p>
			<?php endif; ?>
			<div class="lmgcp-preview">
				<p class="lmgcp-preview__label">Preview: how your profile could look</p>
				<div class="lmgcp-profile">
					<span class="lmgcp-stamp">Traveltalk partner</span>
					<div class="lmgcp-profile__head">
						<span class="lmgcp-logo" aria-hidden="true"><?php echo esc_html( $initials ); ?></span>
						<h3><?php echo esc_html( $company ); ?></h3>
					</div>
					<p class="lmgcp-muted">Your two lines about what you offer go here.</p>
					<span class="lmgcp-visit">Visit <?php echo esc_html( $company ); ?> →</span>
					<p class="lmgcp-on">Shown on: <a href="<?php echo esc_url( $r['dest_url'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $dest ); ?></a></p>
				</div>
				<p class="lmgcp-muted lmgcp-small">A mock-up, not live. Your logo, text and link replace the placeholders.</p>
			</div>
			<div class="lmgcp-chat" aria-live="polite">
				<div class="lmgcp-log"></div>
				<form class="lmgcp-form">
					<label class="screen-reader-text" for="lmgcp-q">Your question</label>
					<textarea id="lmgcp-q" rows="2" maxlength="600" placeholder="Ask about prices, what you get, how it works …"></textarea>
					<button type="submit">Send</button>
				</form>
			</div>
			<div class="lmgcp-next">
				<button type="button" class="lmgcp-act" data-action="offer">Send me a real offer</button>
				<button type="button" class="lmgcp-act lmgcp-act--quiet" data-action="call">Book a call</button>
				<label class="lmgcp-nl"><input type="checkbox" data-action="newsletter"> Send me the partner newsletter</label>
				<p class="lmgcp-done" hidden></p>
				<p class="lmgcp-muted lmgcp-small">Aianna is an AI assistant. Mio DeCastro and Gunnar Gad at Traveltalk take over from here. Leisure Media Group Ltd, 128 City Road, London.</p>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	// -------------------------------------------------------------------------
	// REST
	// -------------------------------------------------------------------------

	public static function routes() {
		$open = function () { return true; }; // the code is the key; checked in each handler
		register_rest_route( 'lmg-concierge/v1', '/partner/ask', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_ask' ), 'permission_callback' => $open ) );
		register_rest_route( 'lmg-concierge/v1', '/partner/event', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_event' ), 'permission_callback' => $open ) );
		register_rest_route( 'lmg-concierge/v1', '/partner/action', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rest_action' ), 'permission_callback' => $open ) );
	}

	private static function code_from( WP_REST_Request $req ) {
		$b = $req->get_json_params();
		return is_array( $b ) && isset( $b['code'] ) ? self::clean_code( $b['code'] ) : '';
	}

	public static function rest_ask( WP_REST_Request $req ) {
		$code = self::code_from( $req );
		$r    = self::get( $code );
		if ( ! $r ) return new WP_REST_Response( array( 'ok' => false, 'reason' => 'code' ), 403 );

		$cfg = LMG_Concierge_Config::override( 'partners' );
		if ( ! $cfg ) return new WP_REST_Response( array( 'ok' => false, 'reason' => 'config' ), 500 );

		$per_day = (int) ( $cfg['limits']['perCodePerDay'] ?? 40 );
		$dk = 'lmgcp_d_' . $code . '_' . gmdate( 'Ymd' );
		$n  = (int) get_transient( $dk );
		if ( $n >= $per_day ) return new WP_REST_Response( array( 'ok' => false, 'reason' => 'daily' ), 429 );
		set_transient( $dk, $n + 1, DAY_IN_SECONDS + HOUR_IN_SECONDS );

		self::$turn_context = self::context( $r );
		$res = lmg_concierge_rest_ask( $req );
		self::$turn_context = '';

		$b = $req->get_json_params();
		$q = isset( $b['question'] ) ? mb_substr( sanitize_textarea_field( wp_unslash( (string) $b['question'] ) ), 0, 600 ) : '';
		$ok = $res instanceof WP_REST_Response && ! empty( $res->get_data()['ok'] );
		if ( self::test_mode( $r ) ) return $res;
		self::touch( $code, function ( $x ) use ( $q, $ok ) {
			$x['questions'] = (int) ( $x['questions'] ?? 0 ) + 1;
			$x['last_at']   = time();
			$asked          = (array) ( $x['asked'] ?? array() );
			$asked[]        = array( time(), $q, $ok ? 1 : 0 );
			$x['asked']     = array_slice( $asked, -50 );
			return $x;
		} );
		return $res;
	}

	public static function rest_event( WP_REST_Request $req ) {
		$code = self::code_from( $req );
		$r    = self::get( $code );
		if ( ! $r ) return new WP_REST_Response( array( 'ok' => false ), 403 );
		if ( self::test_mode( $r ) ) return new WP_REST_Response( array( 'ok' => true, 'test' => true ) );
		// Counted from the page's script, so mail scanners that only fetch the
		// link (and run no script) do not count as opens.
		self::touch( $code, function ( $x ) {
			$x['opens']      = (int) ( $x['opens'] ?? 0 ) + 1;
			$x['first_open'] = $x['first_open'] ?? time();
			$x['last_open']  = time();
			return $x;
		} );
		return new WP_REST_Response( array( 'ok' => true ) );
	}

	public static function rest_action( WP_REST_Request $req ) {
		$code = self::code_from( $req );
		$r    = self::get( $code );
		if ( ! $r ) return new WP_REST_Response( array( 'ok' => false, 'reason' => 'code' ), 403 );
		$b      = (array) $req->get_json_params();
		$action = isset( $b['action'] ) ? (string) $b['action'] : '';
		if ( ! in_array( $action, array( 'offer', 'call', 'newsletter' ), true ) ) return new WP_REST_Response( array( 'ok' => false, 'reason' => 'action' ), 400 );

		// Tests and demos are never blocked by, and never set, a partner's 10-minute lock.
		$test = self::test_mode( $r );
		$lock = 'lmgcp_a_' . $code . '_' . $action;
		if ( ! $test ) {
			if ( get_transient( $lock ) ) return new WP_REST_Response( array( 'ok' => true, 'repeat' => true ) );
			set_transient( $lock, 1, 10 * MINUTE_IN_SECONDS );
		}
		if ( $action === 'newsletter' && $test ) {
			return new WP_REST_Response( array( 'ok' => true, 'test' => true ) );
		}
		if ( $action === 'newsletter' ) {
			$res = self::subscribe( $r );
			if ( ! $res['ok'] ) {
				delete_transient( $lock );
				error_log( '[lmg-concierge partners] Brevo: ' . $res['detail'] );
				return new WP_REST_Response( array( 'ok' => false, 'reason' => 'newsletter' ), 502 );
			}
			self::touch( $code, function ( $x ) { $x['newsletter_at'] = time(); return $x; } );
			return new WP_REST_Response( array( 'ok' => true ) );
		}

		$transcript = array();
		foreach ( array_slice( (array) ( $b['history'] ?? array() ), -24 ) as $h ) {
			if ( ! is_array( $h ) ) continue;
			$who          = ( isset( $h['role'] ) && $h['role'] === 'assistant' ) ? 'Aianna' : self::first_name( $r['name'] );
			$transcript[] = $who . ': ' . mb_substr( sanitize_textarea_field( wp_unslash( (string) ( $h['text'] ?? '' ) ) ), 0, 2000 );
		}
		$what    = $action === 'offer' ? 'asks for a real offer' : 'asks for a call';
		$offers  = self::offers();
		$subject = ( $test ? '[' . strtoupper( $test ) . '] ' : '' ) . '[Partner chat] ' . $r['company'] . ' ' . $what;
		$body    = $r['name'] . ( $r['title'] !== '' ? ', ' . $r['title'] : '' ) . ', ' . $r['company'] . ' ' . $what . ".\n\n"
			. 'E-mail: ' . $r['email'] . "\n"
			. 'Offer in their code: ' . ( $offers[ $r['offer'] ] ?? $r['offer'] ) . "\n"
			. 'Our page: ' . $r['dest_url'] . "\n"
			. 'Code: ' . $code . "\n\n"
			. "Take over from here: reply to this mail to write to them.\n\n"
			. ( $transcript ? "The conversation:\n\n" . implode( "\n\n", $transcript ) : 'No questions asked in the chat.' ) . "\n";
		$headers = array();
		if ( is_email( $r['email'] ) ) $headers[] = 'Reply-To: ' . $r['name'] . ' <' . $r['email'] . '>';
		$to   = array_filter( array_map( 'trim', explode( ',', (string) get_option( 'lmgcp_recipients', 'mio@traveltalk.media, contact@traveltalk.media' ) ) ), 'is_email' );
		$sent = $to ? wp_mail( $to, $subject, $body, $headers ) : false;
		if ( ! $sent ) {
			delete_transient( $lock );
			error_log( '[lmg-concierge partners] the mail for ' . $code . ' (' . $action . ') could not be sent.' );
			return new WP_REST_Response( array( 'ok' => false, 'reason' => 'mail' ), 502 );
		}
		if ( $test ) return new WP_REST_Response( array( 'ok' => true, 'test' => true ) );
		self::touch( $code, function ( $x ) use ( $action ) { $x[ $action . '_at' ] = time(); return $x; } );
		return new WP_REST_Response( array( 'ok' => true ) );
	}

	/** Partner newsletter: Brevo key and list from LMG Newsletter's partner settings unless set here. */
	private static function subscribe( $r ) {
		if ( ! is_email( $r['email'] ) ) return array( 'ok' => false, 'detail' => 'no e-mail on the code' );
		$key = trim( (string) get_option( 'lmgn_partner_key', '' ) );
		if ( $key === '' ) $key = defined( 'LMG_BREVO_API_KEY' ) ? trim( (string) LMG_BREVO_API_KEY ) : trim( (string) get_option( 'lmg_brevo_api_key', '' ) );
		$list = (int) get_option( 'lmgcp_brevo_list', 0 );
		if ( ! $list ) {
			$ids  = array_filter( array_map( 'intval', preg_split( '/[\s,]+/', (string) get_option( 'lmgn_partner_lists', '' ) ) ) );
			$list = $ids ? (int) reset( $ids ) : 0;
		}
		if ( $key === '' || ! $list ) return array( 'ok' => false, 'detail' => 'no Brevo key or partner list set' );
		$send = function ( $attrs ) use ( $key, $list, $r ) {
			$payload = array( 'email' => $r['email'], 'listIds' => array( $list ), 'updateEnabled' => true );
			if ( $attrs ) $payload['attributes'] = $attrs;
			return wp_remote_post( 'https://api.brevo.com/v3/contacts', array(
				'timeout' => 15,
				'headers' => array( 'api-key' => $key, 'content-type' => 'application/json', 'accept' => 'application/json' ),
				'body'    => wp_json_encode( $payload ),
			) );
		};
		$attrs = array( 'SOURCE' => 'aianna-partners', 'SITE' => wp_parse_url( home_url(), PHP_URL_HOST ), 'SIGNUP_AT' => current_time( 'c' ), 'PAGE_URL' => self::page_url() );
		$res   = $send( $attrs );
		$code  = is_wp_error( $res ) ? 0 : (int) wp_remote_retrieve_response_code( $res );
		// An account without these attributes rejects them: keep the subscriber, drop the attributes.
		if ( $code === 400 ) { $res = $send( array() ); $code = is_wp_error( $res ) ? 0 : (int) wp_remote_retrieve_response_code( $res ); }
		if ( in_array( $code, array( 200, 201, 204 ), true ) ) return array( 'ok' => true );
		return array( 'ok' => false, 'detail' => is_wp_error( $res ) ? $res->get_error_message() : ( 'HTTP ' . $code . ' ' . wp_remote_retrieve_body( $res ) ) );
	}

	// -------------------------------------------------------------------------
	// Admin: Tools → Aianna for partners
	// -------------------------------------------------------------------------

	public static function admin_save_codes() {
		if ( ! current_user_can( self::CAP ) ) wp_die( 'No access.' );
		check_admin_referer( 'lmgcp_codes' );
		$all   = self::all();
		$rows  = array();
		$one   = array_map( function ( $k ) { return isset( $_POST[ $k ] ) ? sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) : ''; }, array( 'name' => 'name', 'title' => 'title', 'company' => 'company', 'email' => 'email', 'dest' => 'dest', 'offer' => 'offer' ) );
		if ( $one['company'] !== '' ) $rows[] = array_values( $one );
		$bulk = isset( $_POST['bulk'] ) ? (string) wp_unslash( $_POST['bulk'] ) : '';
		foreach ( preg_split( '/\R/', $bulk ) as $line ) {
			if ( trim( $line ) === '' ) continue;
			$f = array_map( 'trim', str_getcsv( $line, ';' ) );
			$rows[] = array_map( 'sanitize_text_field', array_pad( $f, 6, '' ) );
		}
		$added = 0; $errors = array();
		foreach ( $rows as $f ) {
			list( $name, $title, $company, $email, $dest, $offer ) = $f;
			if ( $company === '' || $name === '' ) { $errors[] = 'Missing name or company: ' . implode( '; ', $f ); continue; }
			$dest_url = esc_url_raw( $dest );
			$pid      = $dest_url ? url_to_postid( $dest_url ) : 0;
			$offer    = in_array( $offer, array( 'free_month', 'free month', 'A', 'a' ), true ) ? 'free_month' : 'profile';
			$code     = self::new_code( $all );
			$all[ $code ] = array(
				'name' => $name, 'title' => $title, 'company' => $company, 'email' => sanitize_email( $email ),
				'dest_url' => $dest_url, 'dest_title' => $pid ? html_entity_decode( get_the_title( $pid ), ENT_QUOTES, 'UTF-8' ) : '',
				'offer' => $offer, 'created' => time(), 'by' => get_current_user_id(),
				'master' => ! empty( $_POST['master'] ) && $f === $rows[0] && $one['company'] !== '',
			);
			if ( $dest_url && ! $pid ) $errors[] = $company . ': the page ' . $dest_url . ' was not found on this site; the code works, but check the link.';
			$added++;
		}
		self::save_all( $all );
		set_transient( 'lmgcp_msg_' . get_current_user_id(), array( $added, $errors ), 300 );
		wp_safe_redirect( admin_url( 'tools.php?page=lmgc-partners' ) );
		exit;
	}

	public static function admin_save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'No access.' );
		check_admin_referer( 'lmgcp_settings' );
		update_option( 'lmgcp_page_id', absint( $_POST['page_id'] ?? 0 ), false );
		$to = array_filter( array_map( 'trim', explode( ',', sanitize_text_field( wp_unslash( $_POST['recipients'] ?? '' ) ) ) ), 'is_email' );
		update_option( 'lmgcp_recipients', implode( ', ', $to ), false );
		update_option( 'lmgcp_brevo_list', absint( $_POST['brevo_list'] ?? 0 ), false );
		wp_safe_redirect( admin_url( 'tools.php?page=lmgc-partners' ) );
		exit;
	}

	public static function admin_archive() {
		if ( ! current_user_can( self::CAP ) ) wp_die( 'No access.' );
		$code = self::clean_code( $_GET['code'] ?? '' );
		check_admin_referer( 'lmgcp_archive_' . $code );
		self::touch( $code, function ( $x ) { $x['archived'] = empty( $x['archived'] ); return $x; } );
		wp_safe_redirect( admin_url( 'tools.php?page=lmgc-partners' ) );
		exit;
	}

	private static function when( $t ) {
		return $t ? esc_html( wp_date( 'j M, H:i', (int) $t ) ) : '–';
	}

	public static function admin_page() {
		$all  = self::all();
		$msg  = get_transient( 'lmgcp_msg_' . get_current_user_id() );
		delete_transient( 'lmgcp_msg_' . get_current_user_id() );
		$page = self::page_url();
		echo '<div class="wrap"><h1>Aianna for partners</h1>';
		echo '<style>.lmgcp-t{border-collapse:collapse;background:#fff;margin:8px 0 24px}.lmgcp-t th,.lmgcp-t td{border:1px solid #dcdcde;padding:6px 8px;text-align:left;vertical-align:top}.lmgcp-t td.r{text-align:right}.lmgcp-t tr.arch{opacity:.5}.lmgcp-t input.lnk{width:260px;font-size:11px}</style>';
		if ( is_array( $msg ) ) {
			echo '<div class="notice notice-success"><p>' . (int) $msg[0] . ' code(s) added.</p></div>';
			foreach ( (array) $msg[1] as $e ) echo '<div class="notice notice-warning"><p>' . esc_html( $e ) . '</p></div>';
		}
		if ( ! $page ) echo '<div class="notice notice-warning"><p>No partner page chosen yet. Create a page with the shortcode <code>[aianna_partners]</code> as its only content, then choose it under Settings at the bottom.</p></div>';

		// Totals: the test, read at a glance.
		$tot = array( 'codes' => 0, 'opened' => 0, 'asked' => 0, 'offer' => 0, 'call' => 0, 'nl' => 0 );
		foreach ( $all as $r ) {
			if ( ! empty( $r['archived'] ) || ! empty( $r['master'] ) ) continue;
			$tot['codes']++;
			if ( ! empty( $r['opens'] ) ) $tot['opened']++;
			if ( ! empty( $r['questions'] ) ) $tot['asked']++;
			if ( ! empty( $r['offer_at'] ) ) $tot['offer']++;
			if ( ! empty( $r['call_at'] ) ) $tot['call']++;
			if ( ! empty( $r['newsletter_at'] ) ) $tot['nl']++;
		}
		echo '<p>Partner codes only; master codes and visits by logged-in editors are not counted. <strong>' . $tot['codes'] . '</strong> codes · <strong>' . $tot['opened'] . '</strong> opened · <strong>' . $tot['asked'] . '</strong> asked questions · <strong>' . $tot['offer'] . '</strong> asked for an offer · <strong>' . $tot['call'] . '</strong> asked for a call · <strong>' . $tot['nl'] . '</strong> took the newsletter</p>';

		$offers = self::offers();
		echo '<table class="lmgcp-t"><tr><th>Company</th><th>Person</th><th>Offer</th><th>Personal link</th><th>Opened</th><th class="r">Questions</th><th>Offer</th><th>Call</th><th>Newsletter</th><th></th></tr>';
		if ( ! $all ) echo '<tr><td colspan="10">No codes yet.</td></tr>';
		uasort( $all, function ( $a, $b ) { return ( $b['created'] ?? 0 ) <=> ( $a['created'] ?? 0 ); } );
		foreach ( $all as $code => $r ) {
			$arch = ! empty( $r['archived'] );
			echo '<tr' . ( $arch ? ' class="arch"' : '' ) . '><td><strong>' . esc_html( $r['company'] ) . '</strong>';
			if ( $r['dest_url'] ) echo '<br><a href="' . esc_url( $r['dest_url'] ) . '" target="_blank">' . esc_html( $r['dest_title'] !== '' ? $r['dest_title'] : $r['dest_url'] ) . '</a>';
			echo '</td><td>' . esc_html( $r['name'] ) . ( $r['title'] !== '' ? '<br><span class="description">' . esc_html( $r['title'] ) . '</span>' : '' ) . '<br><span class="description">' . esc_html( $r['email'] ) . '</span></td>';
			echo '<td>' . ( ! empty( $r['master'] ) ? '<strong>Master (demo)</strong>' : esc_html( $r['offer'] === 'free_month' ? 'Free month' : 'Profile' ) ) . '</td>';
			echo '<td>' . ( $page ? '<input class="lnk" readonly onclick="this.select()" value="' . esc_attr( self::link( $code ) ) . '"><br><a href="' . esc_url( self::link( $code ) ) . '" target="_blank" rel="noopener">Preview</a> <span class="description">(not counted while you are logged in)</span>' : esc_html( $code ) ) . '</td>';
			echo '<td>' . ( ! empty( $r['opens'] ) ? (int) $r['opens'] . '× (first ' . self::when( $r['first_open'] ?? 0 ) . ')' : '–' ) . '</td>';
			echo '<td class="r">' . (int) ( $r['questions'] ?? 0 );
			if ( ! empty( $r['asked'] ) ) {
				echo '<details><summary>show</summary><ol>';
				foreach ( $r['asked'] as $a ) echo '<li>' . self::when( $a[0] ) . ': ' . esc_html( $a[1] ) . ( empty( $a[2] ) ? ' <em>(no answer)</em>' : '' ) . '</li>';
				echo '</ol></details>';
			}
			echo '</td><td>' . self::when( $r['offer_at'] ?? 0 ) . '</td><td>' . self::when( $r['call_at'] ?? 0 ) . '</td><td>' . self::when( $r['newsletter_at'] ?? 0 ) . '</td>';
			echo '<td><a href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=lmgcp_archive&code=' . $code ), 'lmgcp_archive_' . $code ) ) . '">' . ( $arch ? 'Reopen' : 'Close' ) . '</a></td></tr>';
		}
		echo '</table>';

		echo '<h2>New codes</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="lmgcp_codes">';
		wp_nonce_field( 'lmgcp_codes' );
		echo '<table class="form-table" role="presentation">';
		foreach ( array( 'name' => 'Name', 'title' => 'Job title', 'company' => 'Company', 'email' => 'E-mail', 'dest' => 'Our page about their destination (link)' ) as $k => $l ) {
			echo '<tr><th><label for="lmgcp-' . $k . '">' . esc_html( $l ) . '</label></th><td><input class="regular-text" id="lmgcp-' . $k . '" name="' . $k . '"></td></tr>';
		}
		echo '<tr><th>Offer</th><td><select name="offer">';
		foreach ( $offers as $k => $l ) echo '<option value="' . esc_attr( $k ) . '">' . esc_html( $l ) . '</option>';
		echo '</select></td></tr>';
		echo '<tr><th>Master code</th><td><label><input type="checkbox" name="master" value="1"> Master code for Mio or G: opens the page as the company above, works on any device without logging in, and nothing is counted. Requests are mailed marked DEMO; the newsletter box adds no one.</label><p class="description">For demos on a call and for testing. Use a made-up company, e.g. "Demo Travel Co", and a real destination page. Close it in the list when it is no longer needed.</p></td></tr>';
		echo '<tr><th>Or many at once</th><td><textarea name="bulk" rows="5" class="large-text" placeholder="Name; Job title; Company; E-mail; Link to our page; profile or free_month"></textarea><p class="description">One partner per line, fields separated by semicolons. The last field is <code>profile</code> (USD 200 / 3 months or USD 500 / year) or <code>free_month</code>.</p></td></tr>';
		echo '</table><p><button class="button button-primary">Create codes</button></p></form>';

		if ( current_user_can( 'manage_options' ) ) {
			echo '<h2>Settings</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="lmgcp_settings">';
			wp_nonce_field( 'lmgcp_settings' );
			echo '<table class="form-table" role="presentation"><tr><th>Partner page</th><td>';
			wp_dropdown_pages( array( 'name' => 'page_id', 'selected' => (int) get_option( 'lmgcp_page_id', 0 ), 'show_option_none' => '— choose —', 'post_status' => array( 'publish', 'private' ) ) );
			echo '<p class="description">A page with <code>[aianna_partners]</code> as its content. The plugin keeps it out of Google and out of the cache.</p></td></tr>';
			echo '<tr><th>Requests go to</th><td><input class="regular-text" name="recipients" value="' . esc_attr( get_option( 'lmgcp_recipients', 'mio@traveltalk.media, contact@traveltalk.media' ) ) . '"><p class="description">E-mail addresses, separated by commas.</p></td></tr>';
			echo '<tr><th>Partner newsletter: Brevo list</th><td><input name="brevo_list" value="' . esc_attr( get_option( 'lmgcp_brevo_list', '' ) ) . '" placeholder="from LMG Newsletter"><p class="description">Empty = the first partner list set in Newsletter → Overview → Settings.</p></td></tr>';
			echo '</table><p><button class="button">Save</button></p></form>';
		}
		echo '</div>';
	}
}
