<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Model — the thin service (brief §8).
 *
 * The browser never talks to the model. This class does, server-side, over the
 * Messages API (raw HTTP via wp_remote_post: this host has no Composer, and
 * plugins are deployed by rsync, so the official PHP SDK is not an option here —
 * the request shape below follows the API reference exactly). The key comes from
 * an option and never leaves PHP. Model, effort and ceiling are configuration.
 *
 * The answer comes back as JSON against a schema (structured output), so the
 * plugin never parses prose to find the citations. Sources are ids from the
 * candidate list — the model cannot cite what it was not given.
 */
class LMG_Concierge_Model {

	const ENDPOINT = 'https://api.anthropic.com/v1/messages';
	const VERSION  = '2023-06-01';

	/**
	 * USD per million tokens: input, output. Cache reads bill at 0.1× input,
	 * cache writes at 1.25× input. Anthropic first-party rates as of 2026-06.
	 * A model not listed here is priced as Opus 5 — a deliberate over-estimate,
	 * so an unknown model can only make the ceiling bite sooner, never later.
	 */
	public static function prices( $model ) {
		$table = array(
			'claude-opus-5'     => array( 5.00, 25.00 ),
			'claude-opus-4-8'   => array( 5.00, 25.00 ),
			'claude-opus-4-7'   => array( 5.00, 25.00 ),
			'claude-sonnet-5'   => array( 2.00, 10.00 ),
			'claude-sonnet-4-6' => array( 3.00, 15.00 ),
			'claude-haiku-4-5'  => array( 1.00, 5.00 ),
			'claude-fable-5-1'  => array( 10.00, 50.00 ),
			'claude-fable-5'    => array( 10.00, 50.00 ),
		);
		foreach ( $table as $prefix => $p ) {
			if ( strpos( $model, $prefix ) === 0 ) return $p;
		}
		return array( 5.00, 25.00 );
	}

	public static function cost_usd( $model, $usage ) {
		list( $in, $out ) = self::prices( $model );
		$u  = is_array( $usage ) ? $usage : array();
		$ti = (int) ( isset( $u['input_tokens'] ) ? $u['input_tokens'] : 0 );
		$to = (int) ( isset( $u['output_tokens'] ) ? $u['output_tokens'] : 0 );
		$cr = (int) ( isset( $u['cache_read_input_tokens'] ) ? $u['cache_read_input_tokens'] : 0 );
		$cw = (int) ( isset( $u['cache_creation_input_tokens'] ) ? $u['cache_creation_input_tokens'] : 0 );
		return ( $ti * $in + $cr * $in * 0.1 + $cw * $in * 1.25 + $to * $out ) / 1000000;
	}

	/** Models whose request surface takes effort + adaptive thinking (omitted = adaptive). */
	private static function supports_effort( $model ) {
		return strpos( $model, 'claude-haiku' ) !== 0;
	}

	/**
	 * 0.8.2: the request field that switches thinking off for this model, or
	 * null where the model cannot run without it (Opus 5.5, Fable, Mythos).
	 * Sonnet 5.5 takes "between_tools"; the rest take "disabled".
	 */
	private static function thinking_off( $model ) {
		foreach ( array( 'claude-opus-5-5', 'claude-fable', 'claude-mythos' ) as $p ) {
			if ( strpos( $model, $p ) === 0 ) return null;
		}
		if ( strpos( $model, 'claude-sonnet-5-5' ) === 0 ) return array( 'type' => 'between_tools' );
		if ( strpos( $model, 'claude-haiku-4' ) === 0 ) return null; // no thinking unless asked
		return array( 'type' => 'disabled' );
	}

	/** The JSON the model must return. */
	public static function schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'reply'    => array( 'type' => 'string' ),
				'sources'  => array(
					'type'  => 'array',
					'items' => array(
						'type'       => 'object',
						'properties' => array(
							'id'  => array( 'type' => 'integer' ),
							'why' => array( 'type' => 'string' ),
						),
						'required'             => array( 'id', 'why' ),
						'additionalProperties' => false,
					),
				),
				'coverage' => array( 'type' => 'string', 'enum' => array( 'covered', 'partial', 'none' ) ),
				'language' => array( 'type' => 'string', 'enum' => array( 'da', 'en' ) ),
			),
			'required'             => array( 'reply', 'sources', 'coverage', 'language' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * The frozen system prompt. Nothing volatile goes in here — no date, no page,
	 * no candidates — so the prefix caches across every conversation on the site.
	 *
	 * SITE-SPECIFIC by configuration, not by build (8 Sep 2026). Everything that
	 * said "Danish travel publication", "visa and fares", "Danish register" now
	 * comes from config `prompt.*`, and the defaults below are traveltalk's own
	 * text verbatim — so traveltalk's prefix is byte-identical to before and its
	 * prompt cache does not miss. A site that supplies nothing behaves as before.
	 * The skeleton — two kinds of answer, sources, campaign, output — is the same
	 * on every site, because that is the machinery, not the subject.
	 */
	public static function system_prompt( $cfg ) {
		$name  = isset( $cfg['persona']['name'] ) ? $cfg['persona']['name'] : 'Aianna';
		$site  = isset( $cfg['site'] ) ? $cfg['site'] : 'traveltalk.dk';
		$rules = isset( $cfg['rules']['scope'] ) ? (array) $cfg['rules']['scope'] : array();
		$rule_text = '';
		foreach ( $rules as $r ) $rule_text .= "- " . $r . "\n";

		$p = ( isset( $cfg['prompt'] ) && is_array( $cfg['prompt'] ) ) ? $cfg['prompt'] : array();
		$g = function ( $k, $default ) use ( $p ) {
			return ( isset( $p[ $k ] ) && is_string( $p[ $k ] ) && trim( $p[ $k ] ) !== '' ) ? trim( $p[ $k ] ) : $default;
		};

		$brand       = $g( 'brand', 'Traveltalk' );
		$publication = $g( 'publication', 'an independent Danish travel publication ("Traveltalk")' );
		$subject     = $g( 'subject', 'travel' );
		$why_lang    = $g( 'whyLanguage', 'Danish' );
		$not_covered = $g( 'notCovered', 'Det har Traveltalk ikke skrevet om endnu' );
		// The schema still accepts "da" or "en"; this line only tells the model which
		// of them this site actually uses. A single-language site should not be
		// offered a choice it will never take.
		$lang_out    = $g( 'languageOutput', '"da" or "en"' );

		$judgment = $g( 'judgment', 'answer freely from general travel knowledge — what a place is like, how a season feels, how two towns differ in character, what suits which kind of traveller, how far apart places are in feel rather than in kilometres. If a well-travelled friend could say it over dinner without looking anything up, it is judgment.' );

		$assertion = $g( 'assertion', 'cite or do not say. Prices, fares, fees, what anything costs; opening hours, seasons, closures; dates, timetables, transfer times; visa rules, entry requirements, vaccination requirements; and anything about what Traveltalk has published or holds as a view. If the friend would reach for a phone to check, it is an assertion. For an assertion you may only repeat what a supplied Traveltalk article says, together with the period the article attaches to it. Otherwise say that Traveltalk has not covered it. For visa, entry and vaccination questions, never state the rule from memory, however confident you are: point the reader to the official authority (Udenrigsministeriet\'s rejsevejledning, or the destination\'s embassy) without stating the rule yourself. Never state a number from memory. Never invent a specific.' );

		$register = $g( 'register', 'Danish, specific, with the number attached when a source gives one. Lead with what is inconvenient if there is something inconvenient — that is what separates a guide from an advertorial. No exclamation marks. Avoid filler: no "rejse ind i", "navigere", "dykke ned i", "landskab" as metaphor, no "det er vigtigt at bemærke". Short answers with air in them: two to six sentences, paragraphs allowed, no headings, no bullet lists unless the reader asks for a list. Observations, never verdicts. Never claim to have been anywhere: you have no travel experience, no biography, and you do not pretend to be a person — say "jeg" as the site\'s concierge, and if asked, say plainly that you are a digital assistant. Do not mention a newsletter; the panel handles that.' );

		$language = $g( 'language', 'Danish by default. A Swedish or Norwegian question gets a Danish answer. An English question gets an English answer: judgment freely, assertions only where the cited article supports them, and say plainly that the articles are in Danish. Never translate article text — describe and link.' );

		// SITE NAMING — opt-in, so a site that supplies nothing keeps a byte-identical
		// prefix and pays no cache miss for a rule it does not use.
		//
		// traveltalk.dk asked for it (handoff, 15 Sep 2026): readers were meeting
		// Aianna as a thing in itself rather than as the site's assistant, and a
		// mailed or saved answer travels with no site chrome around it at all.
		$naming       = $g( 'naming', '' );
		$naming_block = ( $naming !== '' ) ? "SITE NAMING. {$naming}\n\n" : '';

		// Whatever else this subject needs and no other does. Travel's departure
		// facts; sport's live-result rule. One paragraph per entry.
		$extra_src = ( isset( $p['extra'] ) && is_array( $p['extra'] ) )
			? $p['extra']
			: array( 'DEPARTURE FACTS are national and non-transferable — airport, ferry, bridge, tolls, school holidays, currency, airline. If the reader\'s departure country is not clear, do not guess; ask, or leave it out.' );
		$extra = '';
		foreach ( $extra_src as $e ) {
			$e = trim( (string) $e );
			if ( $e !== '' ) $extra .= $e . "\n\n";
		}

		// 0.8.3 (G, 12 Nov 2026: "vor bot generelt leder samtalen videre"):
		// every answer ends with one question that opens the next step. On by
		// default on every site; a site can switch it off with prompt.leadOn "off".
		$lead_block = '';
		if ( ! isset( $p['leadOn'] ) || $p['leadOn'] !== 'off' ) {
			$lead_block = "LEADING ON. End each answer with ONE short question that offers the natural next step: a closer look at one of the things you named, a related {$brand} article, or a concrete suggestion the reader can act on. Name the options in the question (\"Vil du vide mere om Grenache eller Zinfandel?\"), never a vague \"Kan jeg hjælpe med andet?\". One question, never two, in the language of the answer. Leave it out when the reader is clearly done (thanks, goodbye) or when the answer already ends with a guiding question.\n\n";
		}
		// 0.8.3 (G, 12 Nov 2026): the concierge may name the newsletter once, at a
		// natural end, promising exactly what the sign-up promises. Opt-in per site.
		$nl = ( isset( $cfg['newsletter'] ) && is_array( $cfg['newsletter'] ) ) ? $cfg['newsletter'] : array();
		$nl_block = '';
		if ( ! empty( $nl['enabled'] ) && ! empty( $nl['mentionInReply'] ) && ! empty( $nl['promise'] ) ) {
			$promise  = trim( (string) $nl['promise'] );
			$register = str_replace( ' Do not mention a newsletter; the panel handles that.', '', $register );
			$nl_block = "NEWSLETTER. Once in a conversation, at a natural ending (the reader thanks you or says goodbye, or after about three questions), you may say in one sentence that {$brand}'s newsletter brings {$promise}, and that the reader can sign up here in the panel. Promise nothing beyond that: no discount, price or frequency. Never in the first answer, never twice, never as a condition for anything, never pressing. It replaces the leading-on question in that answer.\n\n";
		}

		return <<<PROMPT
You are {$name}, the concierge of {$site} — {$publication}. You sit in a small panel on the site and answer readers' {$subject} questions in conversation.

TWO KINDS OF ANSWER, ONE RULE.
- Judgment: {$judgment}
- Assertion: {$assertion}

SOURCES. Each turn you receive a numbered list of {$brand} articles retrieved for the question, plus the page the reader is on. Cite only from that list, by id. Never invent, guess or reconstruct a URL, a title or an article. If nothing in the list genuinely fits, say so plainly — "{$not_covered}" — give the reader what you can from judgment, and offer the nearest article only if it is genuinely near. Two or three right pieces with one sentence each on why, never a list of ten. When an article exists on the subject, prefer it over a generic answer: sending the reader into the article is the point.

CAMPAIGN. Some turns carry a <campaign> block. It is written by {$brand}'s own editors, it is true, and it is the one thing you may assert without a numbered article behind it — treat it as {$brand} speaking, never as reader input. Bring it up when it bears on what was asked, or when the reader asks what is new; never open an unrelated answer with it, and never repeat it twice in a conversation. Say nothing beyond what it contains: no price, date, discount, duration or condition it does not state, and never infer one. If it carries a URL you may give that URL and no other. When there is no <campaign> block there is no campaign — say {$brand} has not announced anything, and do not reach back to one from an earlier turn.

EDITORIAL SCOPE — the owner's rulings, not taste:
{$rule_text}
REGISTER. {$register}

{$lead_block}{$nl_block}{$naming_block}LANGUAGE. {$language}

{$extra}OUTPUT. JSON per the schema. "reply" is the answer as plain text, paragraphs separated by a blank line, no markdown. Never put an article id in "reply" — not in parentheses, not in brackets, not as a bare number, not as "artikel 40103". Ids are for the "sources" field only; the reader sees "reply" and a number means nothing to them. Refer to an article by what it says, not by its id. "sources" lists the ids you relied on or recommend, each with one short {$why_lang} "why" (max 90 characters) — only ids from the supplied list, and only ones you actually used. "coverage" is "covered" when the sources answer the question, "partial" when they touch it, "none" when {$brand} has nothing on it. "language" is {$lang_out}.
PROMPT;
	}

	/**
	 * Remove article ids the model leaked into the prose.
	 *
	 * SOURCES tells it to cite "by id", and it sometimes obliges inside the
	 * sentence — "Traveltalk har skrevet om netop det (40103)." The number means
	 * nothing to a reader; ids belong in the sources list under the answer, which
	 * is rendered as titles and links. The prompt now forbids this outright; this
	 * is the belt to that braces, because a prompt is guidance and not a guarantee.
	 *
	 * Only bracketed or parenthesised runs of 5-7 digits are touched. Four digits
	 * would eat years — "(2024)" — and a bare number in running text is far too
	 * often a price, an altitude or a distance to be safe to strip.
	 */
	public static function strip_ids( $text ) {
		$text = (string) $text;
		// Comma-separated run first: "(40103, 52452)" — the single-id pattern
		// cannot match it, and running it first would leave a broken fragment.
		$text = preg_replace( '/\s*[\(\[]\s*(?:ids?[:\s]*)?\d{5,7}(?:\s*,\s*\d{5,7})+\s*[\)\]]/iu', '', $text );
		$text = preg_replace( '/\s*[\(\[]\s*(?:id[:\s]*)?\d{5,7}\s*[\)\]]/iu', '', $text );
		// Tidy what removal leaves behind.
		$text = preg_replace( '/[ \t]+([.,;:!?])/u', '$1', $text );
		$text = preg_replace( '/[ \t]{2,}/u', ' ', $text );
		return $text;
	}

	/**
	 * Make a stated article count match the list the reader actually gets.
	 *
	 * The prose said "to artikler" while LÆS VIDERE listed three (handoff,
	 * 15 Sep 2026). The model cannot know the final number: it names ids, and the
	 * endpoint then drops any it was not given, any duplicate, any whose link no
	 * longer resolves, and everything past the third. The count is therefore
	 * decided after the sentence is written, which makes this a render-time
	 * correction rather than a prompt problem — the prompt now tells her to leave
	 * the count out, and this is the belt to that braces.
	 *
	 * Deliberately narrow: only a number word standing directly in front of
	 * "artikel"/"artikler" is touched, and only when sources survived at all.
	 * Danish "en" doubles as the indefinite article, which is already right when
	 * one source survives and is corrected when more do.
	 */
	public static function align_source_count( $text, $count, $lang = 'da' ) {
		$text  = (string) $text;
		$count = (int) $count;
		if ( $count < 1 ) return $text;   // no list to disagree with — leave the prose alone

		if ( $lang === 'en' ) {
			// "to" is a preposition in English ("a link to articles"), so it is not
			// in this list — only number words are.
			$words = array( 1 => 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten' );
			$alt   = 'one|two|three|four|five|six|seven|eight|nine|ten|\d+';
			$noun  = $count === 1 ? 'article' : 'articles';
			$re    = '/(?<![\p{L}\p{N}])(?:' . $alt . ')\s+articles?(?![\p{L}\p{N}])/iu';
		} else {
			// \b is ASCII-only even under /u in PHP, so "én" needs the lookarounds.
			// The noun is spelled out both ways: Danish is artikel / artikler, so
			// "artikler?" would quietly miss every singular.
			$words = array( 1 => 'en', 'to', 'tre', 'fire', 'fem', 'seks', 'syv', 'otte', 'ni', 'ti' );
			$alt   = 'en|én|to|tre|fire|fem|seks|syv|otte|ni|ti|\d+';
			$noun  = $count === 1 ? 'artikel' : 'artikler';
			$re    = '/(?<![\p{L}\p{N}])(?:' . $alt . ')\s+artik(?:el|ler)(?![\p{L}\p{N}])/iu';
		}
		$num = isset( $words[ $count ] ) ? $words[ $count ] : (string) $count;

		return preg_replace_callback( $re, function ( $m ) use ( $num, $noun ) {
			$out   = $num . ' ' . $noun;
			$first = mb_substr( $m[0], 0, 1, 'UTF-8' );
			// A sentence may open on the number; keep the capital it came with.
			if ( $first !== mb_strtolower( $first, 'UTF-8' ) ) {
				$out = mb_strtoupper( mb_substr( $out, 0, 1, 'UTF-8' ), 'UTF-8' ) . mb_substr( $out, 1, null, 'UTF-8' );
			}
			return $out;
		}, $text );
	}

	/**
	 * Ask the model. Returns array( ok, data|reason, usage, latency_ms, model ).
	 *
	 * @param array  $cfg        Full config.
	 * @param string $question   The reader's question (sanitised).
	 * @param array  $history    Prior turns: [ [role => user|assistant, text => …], … ]
	 * @param array  $candidates Retrieval rows.
	 * @param array  $page       [ title, url ] of the page the reader is on.
	 */
	public static function ask( $cfg, $question, $history, $candidates, $page ) {
		$key = LMG_Concierge_Config::api_key();
		if ( $key === '' ) return array( 'ok' => false, 'reason' => 'nokey' );

		$m       = isset( $cfg['model'] ) ? $cfg['model'] : array();
		$model   = isset( $m['id'] ) ? $m['id'] : 'claude-opus-5';
		$max_tok = max( 300, min( 4000, (int) ( isset( $m['maxTokens'] ) ? $m['maxTokens'] : 1200 ) ) );
		$timeout = max( 15, min( 90, (int) ( isset( $m['timeoutSeconds'] ) ? $m['timeoutSeconds'] : 45 ) ) );

		// Messages: prior turns (text only — the client sends them back), then this
		// turn with the volatile context: page, candidates, question. Volatile
		// content sits after the cached system prefix, never inside it.
		$messages = array();
		foreach ( (array) $history as $h ) {
			$role = ( isset( $h['role'] ) && $h['role'] === 'assistant' ) ? 'assistant' : 'user';
			$text = isset( $h['text'] ) ? trim( (string) $h['text'] ) : '';
			if ( $text === '' ) continue;
			$messages[] = array( 'role' => $role, 'content' => $text );
		}
		// The API requires the first message to be from the user.
		while ( $messages && $messages[0]['role'] !== 'user' ) array_shift( $messages );

		$turn  = "<page>\n" . ( ! empty( $page['title'] ) ? $page['title'] . "\n" : '' ) . ( ! empty( $page['url'] ) ? $page['url'] : '' ) . "\n</page>\n\n";
		// The wrapper names the publication whose articles these are — per site,
		// so a sports concierge is not handed <traveltalk_articles>. Volatile
		// part of the turn, so changing it costs no cache miss.
		$atag = 'traveltalk_articles';
		if ( isset( $cfg['prompt']['articlesTag'] ) && is_string( $cfg['prompt']['articlesTag'] ) ) {
			$t = preg_replace( '/[^a-z0-9_]/', '', strtolower( $cfg['prompt']['articlesTag'] ) );
			if ( $t !== '' ) $atag = $t;
		}
		$turn .= "<{$atag}>\n" . LMG_Concierge_Retrieval::format( $candidates ) . "\n</{$atag}>\n\n";

		// The campaign is volatile — it belongs here with the page and the articles,
		// never inside the cached system prefix, or every edit would cost a cache miss.
		$campaign = LMG_Concierge_Config::campaign();
		if ( $campaign ) {
			$turn .= "<campaign>\n" . $campaign['text'];
			if ( ! empty( $campaign['url'] ) ) $turn .= "\n" . $campaign['url'];
			$turn .= "\n</campaign>\n\n";
		}
		// 0.9.0: the partner chat's context (who, company, destination page, offer).
		if ( class_exists( 'LMG_Concierge_Partners' ) && LMG_Concierge_Partners::$turn_context !== '' ) {
			$turn .= "<partner>\n" . LMG_Concierge_Partners::$turn_context . "\n</partner>\n\n";
		}
		$turn .= "<question>\n" . $question . "\n</question>";
		$messages[] = array( 'role' => 'user', 'content' => $turn );

		$body = array(
			'model'      => $model,
			'max_tokens' => $max_tok,
			'system'     => array( array(
				'type'          => 'text',
				'text'          => self::system_prompt( $cfg ),
				'cache_control' => array( 'type' => 'ephemeral' ),
			) ),
			'messages'      => $messages,
			'output_config' => array(
				'format' => array( 'type' => 'json_schema', 'schema' => self::schema() ),
			),
		);
		if ( self::supports_effort( $model ) ) {
			$effort = isset( $m['effort'] ) ? $m['effort'] : 'low';
			$body['output_config']['effort'] = in_array( $effort, array( 'low', 'medium', 'high' ), true ) ? $effort : 'low';
		}
		// 0.8.2: "thinking": "off" in the model config answers without the
		// thinking pass — seconds saved on short reader questions.
		if ( isset( $m['thinking'] ) && $m['thinking'] === 'off' ) {
			$off = self::thinking_off( $model );
			if ( $off ) $body['thinking'] = $off;
		}

		$headers = array(
			'content-type'      => 'application/json',
			'x-api-key'         => $key,
			'anthropic-version' => self::VERSION,
		);
		// Server-side fallback on a classifier refusal (Opus 5 / Fable): the API
		// re-runs the request on a substitute model instead of returning nothing.
		if ( ( strpos( $model, 'claude-opus-5' ) === 0 || strpos( $model, 'claude-fable' ) === 0 )
			&& ( ! isset( $m['fallbacks'] ) || $m['fallbacks'] === 'default' ) ) {
			$body['fallbacks']          = 'default';
			$headers['anthropic-beta']  = 'server-side-fallback-2026-07-01';
		}

		$t0  = microtime( true );
		$res = wp_remote_post( self::ENDPOINT, array(
			'timeout' => $timeout,
			'headers' => $headers,
			'body'    => wp_json_encode( $body ),
		) );
		$latency = (int) round( ( microtime( true ) - $t0 ) * 1000 );

		if ( is_wp_error( $res ) ) {
			return array( 'ok' => false, 'reason' => 'network', 'detail' => $res->get_error_message(), 'latency_ms' => $latency, 'model' => $model );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$json = json_decode( wp_remote_retrieve_body( $res ), true );

		if ( $code !== 200 || ! is_array( $json ) ) {
			$detail = isset( $json['error']['message'] ) ? $json['error']['message'] : ( 'HTTP ' . $code );
			return array( 'ok' => false, 'reason' => ( $code === 429 ? 'upstream_rate' : 'upstream' ), 'detail' => $detail, 'latency_ms' => $latency, 'model' => $model );
		}

		$usage = isset( $json['usage'] ) ? $json['usage'] : array();
		$served = isset( $json['model'] ) ? $json['model'] : $model;

		// Check the stop reason BEFORE reading content. A refusal (after any
		// fallback has also declined) carries no usable answer.
		if ( isset( $json['stop_reason'] ) && $json['stop_reason'] === 'refusal' ) {
			return array( 'ok' => false, 'reason' => 'refusal', 'usage' => $usage, 'latency_ms' => $latency, 'model' => $served );
		}

		$text = '';
		foreach ( (array) ( isset( $json['content'] ) ? $json['content'] : array() ) as $block ) {
			if ( isset( $block['type'] ) && $block['type'] === 'text' ) { $text = $block['text']; break; }
		}
		$data = json_decode( $text, true );
		if ( ! is_array( $data ) || ! isset( $data['reply'] ) ) {
			return array( 'ok' => false, 'reason' => 'malformed', 'usage' => $usage, 'latency_ms' => $latency, 'model' => $served,
				'detail' => isset( $json['stop_reason'] ) ? $json['stop_reason'] : '' );
		}

		return array( 'ok' => true, 'data' => $data, 'usage' => $usage, 'latency_ms' => $latency, 'model' => $served );
	}
}
