<?php
/**
 * External catalogue: wine and producer pages of a shop on another domain,
 * read from its sitemap and cached. Candidates carry ids from 9000000 up so
 * they never collide with WordPress post ids.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class LMG_Concierge_Catalogue {

	const BASE_ID = 9000000;

	private static function conf( $cfg ) {
		return ( isset( $cfg['catalogue'] ) && is_array( $cfg['catalogue'] ) && ! empty( $cfg['catalogue']['sitemap'] ) ) ? $cfg['catalogue'] : null;
	}

	/**
	 * All catalogue rows, cached.
	 *
	 * 0.8.2: a reader never waits for the shop. A cold fetch is the sitemap plus
	 * up to 60 pages, one after the other; that now runs only in the background
	 * (refresh(), on WP-Cron). When the cache has expired, the reader gets the
	 * last good copy at once and a refresh is queued. Only the very first fetch
	 * on a site, before any copy exists, is still done during a question.
	 */
	public static function rows( $cfg, $force = false ) {
		$c = self::conf( $cfg );
		if ( ! $c ) return array();
		$key = 'lmgc_cat_' . md5( $c['sitemap'] );
		if ( ! $force ) {
			$hit = get_transient( $key );
			if ( is_array( $hit ) ) return $hit;
			$old = get_option( $key . '_last', array() );
			if ( is_array( $old ) && $old ) {
				if ( ! wp_next_scheduled( 'lmg_concierge_warm' ) ) wp_schedule_single_event( time(), 'lmg_concierge_warm' );
				return $old;
			}
		}

		$host = wp_parse_url( $c['sitemap'], PHP_URL_HOST );
		$res  = wp_remote_get( $c['sitemap'], array( 'timeout' => 8 ) );
		if ( is_wp_error( $res ) || (int) wp_remote_retrieve_response_code( $res ) !== 200 ) {
			$old = get_option( $key . '_last', array() );
			return is_array( $old ) ? $old : array();
		}
		preg_match_all( '#<loc>\s*([^<\s]+)\s*</loc>#i', wp_remote_retrieve_body( $res ), $m );
		$paths = ! empty( $c['paths'] ) ? (array) $c['paths'] : array( '/wines/', '/producers/' );
		$urls  = array();
		foreach ( $m[1] as $u ) {
			if ( wp_parse_url( $u, PHP_URL_HOST ) !== $host ) continue;
			foreach ( $paths as $p ) {
				if ( strpos( (string) wp_parse_url( $u, PHP_URL_PATH ), $p ) === 0 ) { $urls[] = $u; break; }
			}
		}
		$urls = array_slice( array_unique( $urls ), 0, 60 );

		$rows = array();
		foreach ( $urls as $i => $u ) {
			$r = wp_remote_get( $u, array( 'timeout' => 8 ) );
			if ( is_wp_error( $r ) || (int) wp_remote_retrieve_response_code( $r ) !== 200 ) continue;
			$html = wp_remote_retrieve_body( $r );
			$title = '';
			if ( preg_match( '#<h1[^>]*>(.*?)</h1>#is', $html, $t ) ) $title = $t[1];
			if ( $title === '' && preg_match( '#<title>(.*?)</title>#is', $html, $t ) ) $title = $t[1];
			$title = trim( html_entity_decode( wp_strip_all_tags( $title ), ENT_QUOTES, 'UTF-8' ) );
			$body  = preg_replace( '#<(script|style|noscript|svg|nav|footer)\b.*?</\1>#is', ' ', $html );
			$text  = trim( preg_replace( '/\s+/u', ' ', html_entity_decode( wp_strip_all_tags( $body ), ENT_QUOTES, 'UTF-8' ) ) );
			// Price only when it is unambiguous (has decimals). "€16999" is not.
			$price = '';
			if ( preg_match( '/€\s?(\d{1,4}[.,]\d{2})/u', $text, $pm ) ) $price = '€' . $pm[1];
			$text = preg_replace( '/€\s?\d+(?:[.,]\d+)?/u', '', $text );
			// The page just answered 200: record it, so the link check at answer time needs no request.
			set_transient( 'lmgc_link_' . md5( $u ), 'ok', DAY_IN_SECONDS );
			$kind = ( strpos( (string) wp_parse_url( $u, PHP_URL_PATH ), '/producers/' ) === 0 ) ? 'producer' : 'wine';
			$rows[] = array(
				'id' => self::BASE_ID + $i, 'title' => $title !== '' ? $title : $u, 'url' => $u,
				'date' => '', 'categories' => array( $kind === 'wine' ? 'Bottiglia.wine · vin til salg' : 'Bottiglia.wine · producent' ),
				'excerpt' => wp_html_excerpt( $text, 420, '…' ) . ( $price ? ' Pris: ' . $price . ' pr. flaske.' : '' ),
				'image' => '', 'kind' => $kind,
			);
		}
		if ( $rows ) {
			set_transient( $key, $rows, 12 * HOUR_IN_SECONDS );
			update_option( $key . '_last', $rows, false );
		}
		return $rows;
	}

	/** 0.8.2: background refresh (WP-Cron), so no reader pays for the fetch. */
	public static function refresh( $cfg ) {
		if ( ! self::conf( $cfg ) ) return;
		self::rows( $cfg, true );
	}

	/** Matching rows for a query; buying intent returns the wines. */
	public static function candidates( $query, $cfg, $max = 4 ) {
		$rows = self::rows( $cfg );
		if ( ! $rows ) return array();
		$q = mb_strtolower( $query );
		$words = array_filter( preg_split( '/[^\p{L}\p{N}]+/u', $q ), function ( $w ) { return mb_strlen( $w ) >= 4; } );
		$scored = array();
		foreach ( $rows as $r ) {
			$hay = mb_strtolower( $r['title'] . ' ' . $r['excerpt'] . ' ' . $r['url'] );
			$s = 0;
			foreach ( $words as $w ) if ( strpos( $hay, $w ) !== false ) $s++;
			if ( $s ) $scored[] = array( $s, $r );
		}
		usort( $scored, function ( $a, $b ) { return $b[0] - $a[0]; } );
		$out = array_map( function ( $x ) { return $x[1]; }, array_slice( $scored, 0, $max ) );
		if ( ! $out && preg_match( '/bottiglia|k[øo]b|buy|bestil|sælger|udvalg|hvilke vine|which wines|shop|butik/u', $q ) ) {
			$wines = array_values( array_filter( $rows, function ( $r ) { return $r['kind'] === 'wine'; } ) );
			$out = array_slice( $wines, 0, $max + 2 );
		}
		return $out;
	}
}
