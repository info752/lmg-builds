# LMG Concierge — Aianna

A first-party concierge in the lower-right corner of the site. It answers readers' travel
questions in conversation — freely where the answer is judgment, from the site's own published
articles where it is a claim — and links the piece it answered from. The persona on
traveltalk.dk is **Aianna**.

Built from the brief *traveltalk.dk — brief for Code: The Traveltalk Concierge* (5 Sep 2026)
and the group rollout note. One codebase, one JSON config per site (`config/traveltalk.json`);
nothing about a site is in code. The second site is a config file, not a build.

Status: **v0.4.1 — three sites live** (8 Sep 2026). traveltalk.dk: **Aianna**, Danish, visible to all
readers. worldsporttalk.com: **Kai**, US English, administrators only, **no API key yet — he cannot
answer until one is set**. traveltalk.travel: **Aianna in English, visible to all readers** (9 Sep 2026).
winetalk.dk (**Bottiglia**) is written and **frozen — do not deploy it**: G, 9 Sep 2026, *"Bottiglia
don't touch, Mike may have done a bot himself."* Check what already exists on winetalk.dk and
bottiglia.wine before any further work there; two assistants in one corner is worse than none. Ceiling 10 USD/month, 1.50 USD/day **per site — the sites
do not share a pot**, so each one opened raises the group's worst case by 10 USD/month.

**0.4.0 made the "one JSON per site" promise true.** It was not, before: the system prompt was
hard-coded to *"an independent Danish travel publication"*, Danish register, travel assertions (visa,
fares) and `<traveltalk_articles>`. A second site inherited all of it. The site-specific half now lives
in `config/*.json` under `prompt.*` (`brand · publication · subject · articlesTag · whyLanguage ·
languageOutput · notCovered · judgment · assertion · register · language · extra[]`); the skeleton —
two kinds of answer, sources, campaign, output — stays shared, because that is the machinery, not the
subject. **Defaults are traveltalk's own text word for word, and the two were compared on the server:
5,624 bytes against 5,624 bytes, identical.** Aianna's cached prefix does not miss.

**0.4.1** fixes the name mark and the thin-corpus search. `persona.mark` names the SUBSTRING to paint
in the accent — the old code coloured the first two characters, which is right only for **Ai**anna and
painted **"Ka"** on Kai, splitting the pun instead of showing it. And on a site without Relevanssi the
core search ANDs every word, so a conversational question collapsed (measured on traveltalk.travel:
the sentence returned 1 result, `skiing` returned 15); retrieval now widens twice when the first pass
comes back thin. See §7.

**v0.1.2 (same evening, after G: "the gif effect requires more space and a rectangular frame"):** the resting
element is now a 116×154 px rounded RECTANGLE (not a circle) showing the "wide" crop — the whole composition,
not the tight bubble crop — with the resting line as a bottom-scrim caption. It starts as a still (cheap, no
jank at first paint) and swaps itself to the looping video automatically, once, shortly after the page finishes
loading (`window.load` + `requestIdleCallback`, ~700ms fallback) — no click required. That is a deliberate
departure from the original "load only on interaction" performance rule: G wants the animation to be the reason
someone clicks, so it has to be visible before anyone touches anything. It still costs nothing at the moment
that matters for page-speed metrics (load has already fired), only a moment after. `prefers-reduced-motion`
visitors never get the swap — the still stays the still. Verified: correct element size, `readyState 4`, no
network/console errors, `play()` resolves without rejection on the exact asset used elsewhere in the panel.

---

## 1. Shape

```
lmg-concierge/
  lmg-concierge.php                    plugin: assets, footer mount, REST (/ask, /event), activation
  includes/
    class-lmg-concierge-config.php     JSON config + the wp_options that override it
    class-lmg-concierge-retrieval.php  the corpus: published posts/pages, exclusions, link check
    class-lmg-concierge-model.php      the thin service: Messages API, structured JSON answer, pricing
    class-lmg-concierge-guard.php      rate limits + monthly ceiling, checked BEFORE the model call
    class-lmg-concierge-log.php        anonymised log table + readout queries
    class-lmg-concierge-admin.php      Værktøjer → Aianna: status, settings, gaps
  config/traveltalk.json               persona, copy, exclusions, model, limits, newsletter, rules
  assets/
    lmg-concierge-boot.js              the bubble (6 KB) — the only script a page view pays for
    lmg-concierge-panel.js             the conversation, loaded on first interaction
    lmg-concierge.css                  the panel, loaded on first interaction
    lmg-concierge-*-0.5.2.* and older  previous releases, kept for rollback — not served
    img/aianna-*                       stills + loops cut from the Midjourney source (see assets/aianna)
  demo/                                local harness: mock_server.py fakes the two endpoints
```

**The filenames are stable; the version is `?ver=`.** Bump `LMG_CONCIERGE_VERSION` and that is the
whole release — nothing is renamed and nothing can 404.

This reverses the rule that stood here until 15 Sep 2026, which put the version in the filenames
because "this stack strips `?ver=`". Remeasured against production the same day, and it does not:
the edge treats the query as part of the cache key (`x-qc-cache` miss on a new `?ver=`, hit on a
repeat, miss again on a different one), and LiteSpeed emits its own combined CSS as
`...css?ver=f02bb`, so query strings survive the HTML rewrite too. Browsers key on the full URL, so
a new `?ver=` is a new entry however long the `max-age` — and it is a year here.

The old rule made every release a three-file rename that had to land in the same deploy as the
constant, or the panel 404d for every reader. One caveat survives it: `assets.css` and
`assets.panel` in the footer payload are injected by the boot script rather than enqueued, so
WordPress never appends `?ver=` to them and `lmg-concierge.php` adds it by hand. Miss that and the
panel is the one asset a version bump cannot reach.

## 2. How a question travels

1. Reader types; the panel POSTs `{question, history, conversation, turn, page}` to
   `/wp-json/lmg-concierge/v1/ask`. The browser never sees a model or a key.
2. **Guard** (cheapest first): 20 per address per 10 min → 60 per address per day (salted hashes,
   transients, never stored) → 600 per day site-wide → **1.50 USD per day** → **10 USD per month**. Spend
   caps are checked before the model is called. A refused turn is logged with its reason, so the admin
   page can tell "nobody asked" from "we said no". One determined visitor can still spend the day's
   1.50 USD and pause her for everyone until midnight UTC — the ceiling protects the wallet, not
   availability; tighten the per-address numbers if that matters.
3. **Retrieval**: the question, blended with the previous one, against the site's own published
   posts and pages. Relevanssi is called through its own API where present — its WP_Query hook
   returns *nothing* for programmatic queries (measured: `WP_Query(s=Sicilien)` → 0,
   `relevanssi_do_query()` → 5). Exclusions (categories, the 2020–22 vintage, ids) are applied to
   every candidate regardless of which path produced it. The page the reader is on is always a
   candidate, so "what is this page about" works.
4. **Model**: a frozen system prompt (cached — 1.9K tokens, the site's rules inside it), then one
   user turn carrying the page, the candidates and the question. The answer comes back as JSON
   against a schema: `{reply, sources[{id, why}], coverage, language}`. The model can only cite ids
   it was given.
5. **Post-check**: every cited id must be in the candidate list, still published, and its permalink
   must return 200 (HEAD, cached a day) — brief §2 P3. A source that fails is dropped, and
   "covered" without a surviving source becomes "none". Reply text is stripped of any HTML.
6. **Log** one row: hour-rounded time, conversation token, coverage, source ids, tokens, cost,
   latency. No IP, no user agent, no user id. The question text is kept — it *is* the subject
   research — and is the only free text in the table. Rows are pruned after 365 days, and the readout exports them as CSV.

Measured on the live corpus, 5 Sep 2026, one real round-trip: 8 candidates in ~450 ms (1.2 s cold),
Opus 5 at effort `low` answered in **15 s**, 1948 in + 541 out tokens, **USD 0.036** for a first turn
(cache write); later turns in a conversation read the cached prefix and cost less. The reply led
with what was closed, stated no number it had not been given, and said plainly that Traveltalk has
no January-specific piece.

## 3. What the brief asked for, and where it lives

| Brief | Where |
| --- | --- |
| §0 data scope | Retrieval touches `wp_posts` of this site only. No Drive, no mail, no other site. |
| §1 v1 restrictions as configuration | `rules.scope`, `vendors: []`, `corpus.exclusions` — all JSON, none in code |
| §2 P2 one URL rule | every emitted link is `get_permalink()`; the plugin never constructs a URL |
| §2 P3 200 at answer time | `LMG_Concierge_Retrieval::link_ok()` |
| §2 P4 exclusions | `corpus.exclusions` — charter/bus/erhverv categories, 2020–22, id 45668 (the published Charterferie page) |
| §2 P5 no publishing | the plugin publishes nothing, ever |
| §3 judgment vs assertion | the system prompt, verbatim rule; visa/entry never from memory |
| §4 Tier B rulings | `rules.scope` → system prompt; register rules in the prompt |
| §5 language | prompt: da default, sv/no → da, en → en (composition, not translation) |
| §6 does not open itself | boot script draws a closed bubble; nothing auto-opens, no delayed greeting |
| §6 resting line | `ui.restingLine` = **»Hvor drømmer du om at rejse hen?«** (G, 5 Sep 2026) — override at Værktøjer → Aianna |
| §6 dismiss for the session | `sessionStorage`, across pages; nothing set before the reader acts |
| §6 keyboard, focus trap, Esc | panel: `role=dialog`, Tab cycles inside, Esc closes and returns focus |
| §6 mobile | bottom sheet ≤ 600 px; bubble shows the face only |
| §6 performance | bubble styles inline; panel JS/CSS/video fetched on first interaction, prefetched on hover |
| §6 persona asset | `assets/img/aianna-*` — still on the bubble, 2.4 s loop in the panel head, `prefers-reduced-motion` → still |
| §7 corpus | live REST-equivalent queries; published only; re-index is implicit |
| §8 thin service, key never in page | `class-lmg-concierge-model.php`, key from an option |
| §8 ceiling from the start | `limits.monthlyCeilingUsd` = **10 USD while testing** (G, 5 Sep 2026) |
| §8 log the four things | `wp_lmg_concierge_log`: ask, open, dismiss, click, signup, newsletter_shown |
| §9 newsletter once, reversible | offered once per conversation after a useful answer; `gate: false`; posts to the existing `/wp-json/lmg/v1/subscribe` |
| Fusion with LMG Match | if `[data-lmg-match]` is on the page, the panel offers "Find dit Italien — fem spørgsmål" and hands off |

GA4: `concierge_open`, `concierge_ask`, `concierge_answer{coverage, sources_count, lang}`,
`concierge_source_click`, `concierge_signup`, `concierge_dismiss`, `concierge_error`,
`concierge_match_handoff`. Generic names, `site` as a parameter, **no conversation identifier** —
the same ruling as LMG Match. Parameters must be registered as custom dimensions in GA4 before
collection starts; they do not backfill.

## 4. Settings — Værktøjer → Aianna

- **Synlig for**: `off` · `kun administratorer` (default — test on the live site, readers see nothing; **`/ask` refuses anyone but a logged-in administrator until this is `alle læsere`**) · `alle læsere`
- **Hvilelinje** — overrides `ui.restingLine`
- **Model** — overrides `model.id` (`claude-opus-5` default; `claude-sonnet-5` ≈ a third of the cost per turn)
- **Månedligt loft (USD)** — overrides `limits.monthlyCeilingUsd`; at the ceiling Aianna answers with `ui.pausedLine` and no call is made
- **API-nøgle** — own option; falls back to LeisureIntel's key on this site so the first run needs no new secret

The status banner leads with the state, not the counts: key present or not, visible to whom,
spend against ceiling, 80 % warning, ceiling reached.

## 5. Verified

- Front end in a browser against the demo harness: bubble → panel → question → reply with two
  sources and coverage badge → newsletter offered once, not again on later turns → `none` /
  error / ceiling paths render their lines → Esc closes and returns focus → dismiss survives a
  reload for the session → mobile bottom sheet.
- PHP: `php -l` clean on all seven files; retrieval and one model round-trip run through the
  plugin's own code on the live server via `wp eval-file` (plugin inactive, CLI SAPI).
- Live after activation: anonymous page → 0 concierge markup; `/event` → 204; `/ask` → 200 in 15.8 s with
  three verified sources; log row and spend recorded. Not yet seen: the admin page and the bubble as a
  logged-in administrator — that is Gunnar's first look.

## 6. Found on the way

- **Relevanssi returns nothing for programmatic `WP_Query` searches** on this site. Anything else
  that builds a search in code (REST, cron, CLI) and trusts the empty result is standing on the
  same hole. Portfolio-level: Relevanssi runs on several sites.
- **The Charterferie page (45668, `/rejseinteresser/charterferie/`) is published.** The brief says
  it is in draft. Excluded here by id; whether it goes to draft is Gunnar's call.
- **LMG Match's newsletter form sends nothing.** It shows "Tak. Tjek din indbakke" and posts to no
  endpoint (`lmg-match-ui-0.2.0.js`, `renderNewsletter`). The concierge posts to the Brevo bridge;
  Match should do the same. Not fixed here — different plugin.
- **A share of attachments carry incomplete metadata**, so core's `get_the_post_thumbnail_url()`
  emits PHP warnings. The concierge builds thumbnail URLs from the metadata it can see instead.

## 7. Open — Gunnar's, before activation

1. ~~The resting line~~ — **decided 5 Sep 2026: »Hvor drømmer du om at rejse hen?«**
2. ~~The monthly ceiling~~ — **decided 5 Sep 2026: 10 USD while testing** (≈ 300–400 turns on Opus 5). Raise when she goes to all readers.
3. ~~Activate~~ — **done 5 Sep 2026, visibility = administrators.** Web-SAPI `/ask` verified live: 200, 15.8 s, three
   sources with real thumbnails, USD 0.033, log row written. Anonymous pages carry no concierge markup.
4. **Model**: Opus 5 (15 s, ≈ USD 0.03/turn) or Sonnet 5 (faster, ≈ a third). Either is a setting.
5. The Charterferie page — draft or leave.
6. Legal read on the newsletter gate (brief §9) — `gate: false` until it is back.
