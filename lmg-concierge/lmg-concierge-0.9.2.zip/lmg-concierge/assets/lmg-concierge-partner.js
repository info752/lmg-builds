/* LMG Concierge 0.9.0 – Aianna for partners. The chat on the hidden partner page. */
(function () {
    'use strict';
    var root = document.querySelector('.lmgcp[data-lmgcp]');
    if (!root) return;
    var D;
    try { D = JSON.parse(root.getAttribute('data-lmgcp')); } catch (e) { return; }

    var log = root.querySelector('.lmgcp-log');
    var form = root.querySelector('.lmgcp-form');
    var input = form.querySelector('textarea');
    var sendBtn = form.querySelector('button');
    var done = root.querySelector('.lmgcp-done');
    var history = [];
    var turn = 0;
    var busy = false;
    var conversation = ('p' + D.code + Math.random().toString(36).slice(2, 8)).toLowerCase().slice(0, 16);

    function post(url, body) {
        var h = { 'Content-Type': 'application/json' };
        if (D.nonce) h['X-WP-Nonce'] = D.nonce;
        return fetch(url, { method: 'POST', headers: h, credentials: 'same-origin', body: JSON.stringify(body) })
            .then(function (r) { return r.json().catch(function () { return { ok: false }; }); })
            .catch(function () { return { ok: false, reason: 'network' }; });
    }

    function el(tag, cls, text) {
        var n = document.createElement(tag);
        if (cls) n.className = cls;
        if (text != null) n.textContent = text;
        return n;
    }

    function say(role, text, sources) {
        var m = el('div', 'lmgcp-msg lmgcp-msg--' + role);
        if (role === 'assistant' && D.face) {
            var img = el('img', 'lmgcp-face');
            img.src = D.face; img.alt = ''; img.width = 32; img.height = 32;
            m.appendChild(img);
        }
        var b = el('div', 'lmgcp-bubble');
        String(text).split(/\n\s*\n/).forEach(function (p) { if (p.trim()) b.appendChild(el('p', null, p.trim())); });
        if (sources && sources.length) {
            var ul = el('ul', 'lmgcp-sources');
            sources.forEach(function (s) {
                var li = el('li');
                var a = el('a', null, s.title);
                a.href = s.url; a.target = '_blank'; a.rel = 'noopener';
                li.appendChild(a);
                if (s.why) li.appendChild(el('span', null, ' – ' + s.why));
                ul.appendChild(li);
            });
            b.appendChild(ul);
        }
        m.appendChild(b);
        log.appendChild(m);
        log.scrollTop = log.scrollHeight;
        return m;
    }

    var reasons = {
        busy: 'I am busy for a moment. Try again in a few seconds.',
        rate: 'Many questions in a short time. Wait a moment, then try again.',
        daily: 'That is all the questions I can take today. Use the buttons below, and Mio will answer the rest.',
        turns: 'That is as long as this conversation can be. Use the buttons below, and Mio will take it from here.',
        too_long: 'That was a long question. Could you shorten it a little?',
        code: 'This link no longer works. Write to contact@traveltalk.media.'
    };

    say('assistant', D.greeting);
    post(D.endpoint.event, { code: D.code, event: 'open' });

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        var q = input.value.trim();
        if (!q || busy) return;
        busy = true; sendBtn.disabled = true;
        say('user', q);
        input.value = '';
        turn++;
        var wait = say('assistant', 'Aianna is writing …');
        wait.classList.add('lmgcp-wait');
        post(D.endpoint.ask, { code: D.code, question: q, history: history, conversation: conversation, turn: turn })
            .then(function (r) {
                wait.remove();
                if (r && r.ok) {
                    say('assistant', r.reply, r.sources);
                    history.push({ role: 'user', text: q }, { role: 'assistant', text: r.reply });
                } else {
                    say('assistant', reasons[r && r.reason] || 'Something went wrong on my side. Try again in a moment, or use the buttons below.');
                    turn--;
                }
            })
            .then(function () { busy = false; sendBtn.disabled = false; input.focus(); });
    });

    input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); form.requestSubmit ? form.requestSubmit() : form.dispatchEvent(new Event('submit')); }
    });

    var thanks = {
        offer: 'Thank you. Mio will send you a real offer by e-mail.',
        call: 'Thank you. Mio will write to you to find a time for a call.',
        newsletter: 'Added. You can unsubscribe in every newsletter.'
    };

    function act(action, control) {
        control.disabled = true;
        post(D.endpoint.action, { code: D.code, action: action, history: history }).then(function (r) {
            done.hidden = false;
            if (r && r.ok) {
                done.textContent = (r.test && action === 'newsletter') ? 'Test: no one was added to the newsletter.' : (r.test ? '[' + (D.test || 'test').toUpperCase() + '] ' : '') + thanks[action];
                if (control.tagName === 'BUTTON') control.textContent = control.textContent + ' ✓';
            } else {
                done.textContent = 'That did not go through. Try again, or write to contact@traveltalk.media.';
                control.disabled = false;
                if (control.type === 'checkbox') control.checked = false;
            }
        });
    }

    root.querySelectorAll('button.lmgcp-act').forEach(function (b) {
        b.addEventListener('click', function () { act(b.getAttribute('data-action'), b); });
    });
    var box = root.querySelector('input[data-action="newsletter"]');
    if (box) box.addEventListener('change', function () { if (box.checked) act('newsletter', box); });
})();
