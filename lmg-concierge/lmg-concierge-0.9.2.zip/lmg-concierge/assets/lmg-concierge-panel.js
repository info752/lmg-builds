/**
 * lmg-concierge panel — the conversation.
 *
 * Loaded on first interaction by the boot script. Renders the dialog, sends the
 * reader's question to the site's own endpoint (never to a model directly), and
 * shows the answer with the articles it came from. Keyboard accessible, focus
 * trapped while open, Esc closes. The newsletter is offered once per
 * conversation, after a useful answer, and the answer never depends on it.
 *
 * GA4 events are generic, carry the site as a parameter, and carry NO
 * conversation identifier — same ruling as LMG Match.
 */
(function (window, document) {
    'use strict';

    function el(tag, attrs, children) {
        var node = document.createElement(tag);
        for (var k in attrs || {}) {
            if (k === 'text') node.textContent = attrs[k];
            else if (attrs[k] !== null && attrs[k] !== undefined) node.setAttribute(k, attrs[k]);
        }
        (children || []).forEach(function (c) { if (c) node.appendChild(c); });
        return node;
    }

    function tpl(str, vars) {
        return String(str || '').replace(/\{\{(\w+)\}\}/g, function (m, k) { return vars[k] !== undefined ? vars[k] : m; });
    }

    function token() {
        // Random, lives in this tab, gone when it closes. Stitches one visit's
        // turns together; it is not a visitor identifier and is never sent to GA4.
        return 'c' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-5);
    }

    var reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // --- state -------------------------------------------------------------------

    var S = {
        data: null, cfg: null, ui: null,
        panel: null, body: null, input: null, send: null, opener: null, dock: null,
        conversation: token(), turn: 0, history: [], busy: false,
        newsletterOffered: false, greeted: false, open: false,
        keepsakeOffered: false, lastSources: [],
        // Set by either door (the newsletter form, or the tick inside the
        // keepsake). Survives a reset: a reader who signed up is not asked again.
        signedUp: false,
        // The subject of the last answer, as the server derived it from the
        // sources that actually rendered. A category slug, or '' — never a guess,
        // and never an identifier for the reader.
        lastInterest: '',
        // Bumped every time the panel is reset. A request in flight when the
        // reader closes carries the generation it started in; if it comes back
        // after a reset, it is dropped rather than landing in the fresh thread.
        gen: 0
    };

    // --- telemetry ---------------------------------------------------------------

    function ga(name, params) {
        if (typeof window.gtag !== 'function') return;
        var out = { site: (S.cfg && S.cfg.site) || '' };
        for (var k in params || {}) {
            var v = params[k];
            if (v === undefined || v === null || v === '') continue;
            out[k] = typeof v === 'boolean' ? (v ? 1 : 0) : String(v).slice(0, 100);
        }
        try { window.gtag('event', name, out); } catch (e) { /* never break the panel */ }
    }

    function event(kind, extra) {
        var payload = { kind: kind, conversation: S.conversation, turn: S.turn };
        for (var k in extra || {}) payload[k] = extra[k];
        try {
            var body = JSON.stringify(payload);
            if (navigator.sendBeacon) navigator.sendBeacon(S.data.endpoint.event, new Blob([body], { type: 'application/json' }));
            else fetch(S.data.endpoint.event, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: body, keepalive: true }).catch(function () {});
        } catch (e) { /* analytics must never break the experience */ }
    }

    // --- rendering ---------------------------------------------------------------

    function scrollDown() {
        if (S.body) S.body.scrollTop = S.body.scrollHeight;
    }

    function paragraphs(text) {
        return String(text || '').split(/\n\s*\n/).map(function (p) { return p.trim(); }).filter(Boolean)
            .map(function (p) { return el('p', { text: p }); });
    }

    function addMessage(role, text, extraClass) {
        var node = el('div', { class: 'lmgc-msg lmgc-msg--' + role + (extraClass ? ' ' + extraClass : '') }, paragraphs(text));
        S.body.appendChild(node);
        scrollDown();
        return node;
    }

    function addNote(text) {
        var node = el('div', { class: 'lmgc-msg lmgc-msg--note', text: text });
        S.body.appendChild(node);
        scrollDown();
        return node;
    }

    /**
     * The owner's announcement, written in Værktøjer → Aianna. Shown once, on the
     * turn the panel opens, between the greeting and the disclaimer. The model is
     * handed the same text as fact, so what the reader sees and what she can say
     * are the same string — see LMG_Concierge_Config::campaign().
     */
    function addCampaign() {
        var c = S.cfg.campaign;
        if (!c || !c.text) return;

        var node = el('div', { class: 'lmgc-msg lmgc-msg--campaign' }, paragraphs(c.text));
        if (c.url) {
            var a = el('a', { class: 'lmgc-campaign__link', href: c.url, target: '_blank', rel: 'noopener', text: c.label || 'Læs mere' });
            a.addEventListener('click', function () {
                event('campaign_click', {});
                ga('concierge_campaign_click', {});
            });
            node.appendChild(a);
        }
        S.body.appendChild(node);
        scrollDown();
    }

    /**
     * `subject` names the label rather than adding a fifth thing to click.
     *
     * These cards are already the most-used part of the panel — 12 clicks against
     * 26 questions in the log — and they ARE "vil du vide mere om Italien". The
     * generic "Læs videre" was underselling them, so the fix is the sign, not
     * another door (G, 7 Sep 2026). Falls back to the generic label whenever the
     * subject is unknown, which is honest: detectSet only recognises subjects we
     * actually have a Match set for, so a question about Peru stays "Læs videre"
     * instead of inventing a topic.
     */
    function renderSources(sources, subject) {
        if (!sources || !sources.length) return;
        var label = subject && S.ui.sourcesLabelSubject
            ? tpl(S.ui.sourcesLabelSubject, { subject: subject })
            : (S.ui.sourcesLabel || 'Læs videre');
        var list = el('div', { class: 'lmgc-sources' }, [
            el('p', { class: 'lmgc-sources__label', text: label })
        ]);
        var made = 0;
        sources.forEach(function (s, i) {
            // An <a> without an href reads as a link and does nothing — the one
            // broken-link class no checker can see. Never render one.
            if (!s.url) return;
            var a = el('a', { class: 'lmgc-source', href: s.url, target: '_blank', rel: 'noopener' }, [
                s.image ? el('img', { class: 'lmgc-source__img', src: s.image, alt: '', loading: 'lazy', decoding: 'async' }) : null,
                el('span', {}, [
                    el('span', { class: 'lmgc-source__title', text: s.title }),
                    s.why ? el('span', { class: 'lmgc-source__why', text: s.why }) : null
                ])
            ]);
            a.addEventListener('click', function () {
                event('click', { post_id: s.id });
                ga('concierge_source_click', { article_id: s.id, position: i + 1, turn: S.turn });
            });
            list.appendChild(a);
            made++;
        });
        if (!made) return;
        S.lastSources = sources.filter(function (s) { return s.url; }).map(function (s) {
            return { id: s.id, title: s.title, url: s.url };
        });
        S.body.appendChild(list);
        scrollDown();
    }

    function renderCoverage(coverage) {
        if (coverage === 'none') addBadge(S.ui.noneLabel || 'Ikke dækket endnu');
        else if (coverage === 'partial') addBadge(S.ui.partialLabel || 'Delvist dækket');
    }

    function addBadge(text) {
        S.body.appendChild(el('span', { class: 'lmgc-badge', text: text }));
    }

    /**
     * "Keep this answer" — the reader's own conversation, mailed or linked.
     *
     * THE ANSWER IS ALREADY ON SCREEN when this runs. That ordering is the whole
     * point and it is enforced by construction: this is called from the same
     * block that has just appended the reply and the cards, never before it.
     * Nothing here gates anything — the reader who ignores it has lost nothing.
     *
     * Two doors, because they cost the reader different things:
     *   - "Send it to me" wants an address, and mails the exchange.
     *   - "Copy link" wants nothing at all, and hands back a URL they send
     *     themselves. We never mail a third party; that address was never given
     *     to us and never consented to.
     * The newsletter rides along as a SEPARATE, UNTICKED line. Never bundled:
     * the mail goes whether or not it is ticked.
     */
    /**
     * Tailored signup — what the reader is actually interested in, so the
     * newsletter can be segmented instead of sent flat.
     *
     * Three inputs, one form, and only the first costs the reader anything at all:
     *   - implicit: the subject of the articles she was just given, derived
     *     server-side from the sources that rendered (never from the ones the
     *     model merely considered);
     *   - explicit: up to eight checkboxes, every one of them untouched at render;
     *   - free text: one optional line.
     *
     * THE FORM MUST SUBMIT ON THE EMAIL ALONE. Nothing here is required, nothing
     * here disables the button, and a reader who ticks the newsletter and types
     * nothing else is subscribed exactly as she was before this existed. That is
     * the same rule the keepsake already lives by, one level down.
     *
     * Consent is its own sentence above the boxes, never folded into the generic
     * newsletter line: stored and inferred interests are personal data, and the
     * existing consent does not cover them. Returns null while `tailored` is off,
     * which is how this ships until GM has signed off on the labels and wording.
     */
    function interestBlock(openAtRender) {
        var n = S.cfg.newsletter || {};
        if (!n.tailored) return null;

        var wrap = el('div', { class: 'lmgc-int' });
        if (!openAtRender) wrap.hidden = true;

        if (n.interestConsent) wrap.appendChild(el('p', { class: 'lmgc-int__consent', text: n.interestConsent }));
        if (n.interestLegend) wrap.appendChild(el('p', { class: 'lmgc-int__legend', text: n.interestLegend }));

        var boxes = [];
        var list = (n.interests || []).slice(0, 8);
        if (list.length) {
            var group = el('div', { class: 'lmgc-int__tags' });
            list.forEach(function (t, i) {
                if (!t || !t.slug) return;
                var id = 'lmgc-int-' + i + '-' + S.conversation;
                // No `checked` attribute is ever set here, and that is asserted in
                // the DOM rather than trusted — same posture as the newsletter box.
                var box = el('input', { type: 'checkbox', class: 'lmgc-int__box', id: id, value: t.slug });
                group.appendChild(el('label', { class: 'lmgc-int__tag', for: id }, [
                    box, el('span', { text: t.label || t.slug })
                ]));
                boxes.push(box);
            });
            wrap.appendChild(group);
        }

        var free = el('input', {
            type: 'text', class: 'lmgc-int__free', maxlength: '300',
            placeholder: n.interestFreePlaceholder || '',
            'aria-label': n.interestFreePlaceholder || ''
        });
        wrap.appendChild(free);

        return {
            node: wrap,
            show: function (on) { wrap.hidden = !on; },
            // Read at submit time, never held in state: the reader may tick,
            // untick and retype before she presses the button.
            values: function () {
                return {
                    interest_auto: S.lastInterest || '',
                    interest_tags: boxes.filter(function (b) { return b.checked; }).map(function (b) { return b.value; }),
                    interest_free: (free.value || '').trim(),
                    question_url: (S.data.page && S.data.page.url) || ''
                };
            }
        };
    }

    /** One signup request, with whatever the reader chose to tell us. */
    function subscribe(email, source, interests) {
        var n = S.cfg.newsletter || {};
        var body = { email: email, source: source };
        if (interests) {
            var v = interests.values();
            if (v.interest_auto) body.interest_auto = v.interest_auto;
            if (v.interest_tags.length) body.interest_tags = v.interest_tags;
            if (v.interest_free) body.interest_free = v.interest_free;
            if (v.question_url) body.question_url = v.question_url;
        }
        // The address goes to the ESP through the site's own endpoint and is never
        // attached to the conversation log — the list and the log stay apart.
        return fetch(n.endpoint || '/wp-json/lmg/v1/subscribe', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        }).catch(function () {});
    }

    function maybeOfferKeepsake() {
        var k = S.cfg.keepsake;
        if (!k || !k.enabled || S.keepsakeOffered) return false;
        if (!S.history.length) return false;
        S.keepsakeOffered = true;

        var wrap = el('div', { class: 'lmgc-keep' });
        var head = el('p', { class: 'lmgc-keep__headline', text: k.headline || 'Vil du have svaret sendt til dig?' });
        var sub  = k.sub ? el('p', { class: 'lmgc-keep__sub', text: k.sub }) : null;

        var email  = el('input', { type: 'email', class: 'lmgc-keep__email', placeholder: k.placeholder || 'Din e-mail', 'aria-label': k.placeholder || 'Din e-mail', autocomplete: 'email' });
        var send   = el('button', { type: 'submit', class: 'lmgc-btn', text: k.cta || 'Send mig svaret' });

        // Unticked at render. Criterion 2 of the brief, and it is asserted in the
        // DOM rather than trusted: no `checked` attribute is ever set here.
        var nlBox   = el('input', { type: 'checkbox', class: 'lmgc-keep__nlbox', id: 'lmgc-keep-nl' });
        var nlLine  = (S.cfg.newsletter && S.cfg.newsletter.enabled && !S.signedUp)
            ? el('label', { class: 'lmgc-keep__nl', for: 'lmgc-keep-nl' }, [
                nlBox, el('span', { text: k.newsletterLine || 'Send mig også nyhedsbrevet' })
              ])
            : null;

        // The interests belong to the newsletter, not to the answer-mail, so they
        // appear only once the reader has actually asked for the newsletter.
        var interests = nlLine ? interestBlock(false) : null;
        if (interests) {
            nlBox.addEventListener('change', function () { interests.show(nlBox.checked); });
        }

        var form = el('form', { class: 'lmgc-keep__form', novalidate: 'novalidate' }, [
            el('div', { class: 'lmgc-keep__field' }, [email, send]),
            nlLine,
            interests ? interests.node : null,
            k.legal ? el('p', { class: 'lmgc-keep__legal', text: k.legal }) : null
        ]);

        var copy = el('button', { type: 'button', class: 'lmgc-btn lmgc-btn--ghost', text: k.shareCta || 'Kopiér link' });

        function post(address, then) {
            return fetch((S.data.endpoint && S.data.endpoint.save) || '/wp-json/lmg-concierge/v1/save', {
                method: 'POST',
                headers: S.data.nonce ? { 'Content-Type': 'application/json', 'X-WP-Nonce': S.data.nonce } : { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    conversation: S.conversation, turn: S.turn,
                    email: address || '',
                    turns: S.history.slice(-12),
                    sources: S.lastSources
                })
            }).then(function (r) { return r.json(); }).then(then).catch(function () {
                wrap.appendChild(el('p', { class: 'lmgc-keep__sub', text: k.errorLine || 'Det kunne ikke sendes lige nu. Prøv igen om lidt.' }));
            });
        }

        form.addEventListener('submit', function (e) {
            e.preventDefault();
            var v = (email.value || '').trim();
            if (!v || v.indexOf('@') === -1 || v.indexOf('.') === -1) { email.focus(); return; }
            send.disabled = true;
            var wantsNewsletter = nlBox.checked;   // read BEFORE the form is replaced
            post(v, function (j) {
                if (!j || !j.ok) { send.disabled = false; return; }
                event('save');
                ga('concierge_save', { turn: S.turn });
                wrap.replaceChildren(
                    el('p', { class: 'lmgc-keep__sub', text: k.thanks || 'Sendt. Tjek din indbakke.' }),
                    linkRow(j.url)
                );
            });
            // A SECOND, INDEPENDENT request. The answer-mail above does not know
            // this happened, and does not wait for it.
            if (wantsNewsletter) {
                S.signedUp = true;
                var n = S.cfg.newsletter || {};
                subscribe(v, (n.source || 'aianna') + '-keepsake', interests);
                event('signup');
                ga('concierge_signup', { turn: S.turn });
            }
        });

        copy.addEventListener('click', function () {
            copy.disabled = true;
            post('', function (j) {
                if (!j || !j.ok) { copy.disabled = false; return; }
                event('share');
                ga('concierge_share', { turn: S.turn });
                wrap.appendChild(linkRow(j.url));
                copy.remove();
            });
        });

        function linkRow(url) {
            var field = el('input', { class: 'lmgc-keep__link', value: url, readonly: 'readonly', 'aria-label': k.shareCta || 'Link' });
            var btn   = el('button', { type: 'button', class: 'lmgc-btn lmgc-btn--ghost', text: k.copyLabel || 'Kopiér' });
            btn.addEventListener('click', function () {
                field.select();
                var done = function () { btn.textContent = k.copiedLabel || 'Kopieret'; };
                if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(url).then(done, done);
                else { try { document.execCommand('copy'); done(); } catch (e) { done(); } }
            });
            return el('div', { class: 'lmgc-keep__linkrow' }, [field, btn]);
        }

        wrap.appendChild(head);
        if (sub) wrap.appendChild(sub);
        wrap.appendChild(form);
        wrap.appendChild(el('div', { class: 'lmgc-keep__or' }, [copy]));
        S.body.appendChild(wrap);
        scrollDown();
        return true;
    }

    /**
     * Newsletter — once, after a useful answer, never in every reply (brief §9).
     * Goes to the site's own Brevo bridge. The reader gets the answer whether or
     * not they sign up; the gate stays open until the legal read is back.
     */
    function maybeOfferNewsletter(coverage) {
        var n = S.cfg.newsletter;
        if (!n || !n.enabled || S.newsletterOffered || S.signedUp) return false;
        if (S.turn < (n.offerAfterTurn || 1)) return false;
        S.newsletterOffered = true;

        var email = el('input', { type: 'email', class: 'lmgc-nl__email', placeholder: n.placeholder || 'Din e-mail', 'aria-label': n.placeholder || 'E-mail', autocomplete: 'email', required: 'required' });
        var submit = el('button', { type: 'submit', class: 'lmgc-btn', text: n.cta || 'Ja tak' });
        // This form IS the newsletter, so the interests are open from the start —
        // there is no prior tick to wait for.
        var interests = interestBlock(true);
        var form = el('form', { class: 'lmgc-nl', novalidate: 'novalidate' }, [
            el('p', { class: 'lmgc-nl__eyebrow', text: 'Nyhedsbrev' }),
            el('p', { class: 'lmgc-nl__headline', text: n.headline || '' }),
            n.sub ? el('p', { class: 'lmgc-nl__sub', text: n.sub }) : null,
            el('div', { class: 'lmgc-nl__field' }, [email, submit]),
            interests ? interests.node : null,
            n.legal ? el('p', { class: 'lmgc-nl__legal', text: n.legal }) : null
        ]);
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            var v = (email.value || '').trim();
            if (!v || v.indexOf('@') === -1 || v.indexOf('.') === -1) { email.focus(); return; }
            submit.disabled = true;
            S.signedUp = true;
            subscribe(v, (n.source || 'aianna') + '-' + (location.pathname || '/'), interests);
            event('signup');
            ga('concierge_signup', { turn: S.turn });
            form.replaceChildren(el('p', { class: 'lmgc-nl__sub', text: n.thanks || 'Tak.' }));
        });
        S.body.appendChild(form);
        event('newsletter_shown');
        scrollDown();
        return true;
    }

    /**
     * Offers after an answer — at most one per turn. `offers` in the site config
     * is the order to try them in; the first one that is due renders, the rest
     * wait for a later turn. No `offers` key keeps the 0.7.1 behaviour exactly:
     * the keepsake where it is enabled, otherwise the newsletter.
     */
    var OFFERS = {
        keepsake:   function () { return maybeOfferKeepsake(); },
        newsletter: function (coverage) { return maybeOfferNewsletter(coverage); }
    };

    function runOffers(coverage) {
        var order = S.cfg.offers;
        if (!Array.isArray(order)) {
            order = (S.cfg.keepsake && S.cfg.keepsake.enabled) ? ['keepsake'] : ['newsletter'];
        }
        for (var i = 0; i < order.length; i++) {
            var fn = OFFERS[order[i]];
            if (fn && fn(coverage)) return true;
        }
        return false;
    }

    /* ---------------------------------------------------------------------------
     * LMG Match, run by her.
     *
     * Not a handoff any more. Match's engine is headless by design — describe()
     * hands over the question set, recommend() ranks — so she asks the same five
     * questions in her own voice and calls the SAME engine. One ranking, two
     * front doors: change a weight or an exclusion in Match and both change.
     *
     * It costs nothing to run. The questions come from Match's config and the
     * ranking is deterministic, so a guided conversation makes no model call at
     * all — the expensive part of her is only used for the things a rule engine
     * cannot do.
     * ------------------------------------------------------------------------- */

    var Match = { engine: null, loading: null, cache: {}, used: false };

    function matchSets() {
        return (S.data && S.data.match && S.data.match.sets) || [];
    }

    /** Which destination, if any, is this reader talking about? */
    function detectSet(text) {
        var t = ' ' + String(text || '').toLowerCase() + ' ';
        var sets = matchSets();
        for (var i = 0; i < sets.length; i++) {
            if (t.indexOf(sets[i].subject.toLowerCase()) !== -1) return sets[i];
        }
        return null;
    }

    /**
     * A bare destination ("Italien", "jeg vil til Spanien") is what the funnel is
     * for. A specific question ("er der åbent i januar?") deserves an answer
     * first — she should never dodge a question by handing over a quiz.
     */
    function looksLikeBrowsing(text) {
        var t = String(text || '').trim();
        if (t.length > 60) return false;
        if (t.indexOf('?') !== -1) return false;
        return !/\b(hvor|hvad|hvorfor|hvordan|hvornår|kan |er |skal |koster|åben|visum|vejr)\b/i.test(t);
    }

    function loadEngine() {
        if (window.LMGMatch) { Match.engine = window.LMGMatch; return Promise.resolve(window.LMGMatch); }
        if (Match.loading) return Match.loading;
        Match.loading = new Promise(function (resolve, reject) {
            var sc = el('script', { src: S.data.match.engine, 'data-no-optimize': '1' });
            sc.onload = function () { Match.engine = window.LMGMatch; window.LMGMatch ? resolve(window.LMGMatch) : reject(new Error('engine missing')); };
            sc.onerror = function () { Match.loading = null; reject(new Error('engine failed')); };
            document.head.appendChild(sc);
        });
        return Match.loading;
    }

    function loadSet(set) {
        if (Match.cache[set.id]) return Promise.resolve(Match.cache[set.id]);
        return Promise.all([
            loadEngine(),
            fetch(set.config).then(function (r) { return r.json(); }),
            fetch(set.content).then(function (r) { return r.json(); })
        ]).then(function (out) {
            Match.cache[set.id] = { config: out[1], items: out[2] };
            return Match.cache[set.id];
        });
    }

    /** The invitation. Never auto-starts — she asks first. */
    function offerMatch(set, phrasing) {
        if (Match.used) return;
        var ui = S.ui;
        // Sold as a benefit with the real numbers in it, not as a quiz dropped in
        // the reader's lap (G, 6 Sep 2026). The count comes from the set itself,
        // so the copy cannot promise five questions to a set that has six.
        var vars = { subject: set.subject, count: set.count || 5, seconds: ui.matchSeconds || 30 };
        var wrap = el('div', { class: 'lmgc-offer' }, [
            el('p', { class: 'lmgc-offer__line', text: tpl(phrasing || ui.matchOffer, vars) })
        ]);
        var yes = el('button', { type: 'button', class: 'lmgc-chip', text: tpl(ui.matchYes || 'Ja tak', vars) });
        var no = el('button', { type: 'button', class: 'lmgc-chip lmgc-chip--quiet', text: tpl(ui.matchNo || 'Nej tak', vars) });
        no.addEventListener('click', function () {
            wrap.remove();
            Match.used = true;             // asked once, answered — she does not ask again

            // "Nej tak" used to end here, and that was the whole bug (G, 6 Sep 2026):
            // the invitation vanished and NOTHING replaced it, so the reader sat in an
            // empty panel with no sign that she could still simply be asked. G: "we
            // should give people 2 options — 5 easy questions OR the Aianna answer, or
            // we drop them on the floor."
            //
            // So declining the quiz is not declining her. She says so, and the cursor
            // lands in the box, which is the cheapest possible nudge to option B.
            addMessage('assistant', tpl(
                ui.matchDeclined || 'Helt fint. Så spørg mig i stedet — hvad vil du gerne vide om {{subject}}?',
                vars
            ));
            if (S.input) {
                try { S.input.focus({ preventScroll: true }); } catch (e) { S.input.focus(); }
            }
            ga('concierge_match_declined', { subject: set.subject });
        });
        yes.addEventListener('click', function () {
            wrap.remove();
            startMatch(set);
        });
        wrap.appendChild(yes);
        wrap.appendChild(no);
        S.body.appendChild(wrap);
        scrollDown();
        ga('concierge_match_offered', { subject: set.subject });
    }

    function startMatch(set) {
        Match.used = true;
        var thinking = addMessage('assistant', S.ui.matchLoading || 'Et øjeblik …', 'lmgc-msg--thinking');
        loadSet(set).then(function (loaded) {
            thinking.remove();
            var session = Match.engine.createSession(loaded.config, loaded.items);
            ga('concierge_match_start', { subject: set.subject });
            askQuestion(set, session);
        }).catch(function () {
            thinking.remove();
            addMessage('assistant', S.ui.errorLine);
        });
    }

    /** One question at a time, as her own message with the options beneath it. */
    function askQuestion(set, session) {
        var q = session.current;
        if (!q || session.complete) { finishMatch(set, session); return; }

        var vars = { subject: set.subject };
        addMessage('assistant', tpl(q.title, vars));

        var chosen = [];
        var group = el('div', { class: 'lmgc-options' });

        // Say the limit out loud. Match's config carries the help text ("Vælg op
        // til 3") and a max; enforcing the max silently, as this did, leaves a
        // reader tapping a fourth option and wondering why nothing happens.
        var help = null;
        if (q.multiple) {
            var helpText = q.help ? tpl(q.help, vars)
                : (q.max ? tpl(S.ui.matchPickMax || 'Vælg op til {{max}}', { max: q.max }) : '');
            if (helpText) {
                help = el('p', { class: 'lmgc-options__help', text: helpText });
                S.body.appendChild(help);
            }
        }

        function refreshHelp() {
            if (!help || !q.max) return;
            var atMax = chosen.length >= q.max;
            help.textContent = atMax
                ? tpl(S.ui.matchPickedMax || '{{max}} valgt — tryk Videre, eller fravælg et for at bytte', { max: q.max })
                : (q.help ? tpl(q.help, vars) : tpl(S.ui.matchPickMax || 'Vælg op til {{max}}', { max: q.max }));
            help.classList.toggle('is-full', atMax);
            // Grey out what can no longer be picked, rather than letting taps die.
            Array.prototype.forEach.call(group.querySelectorAll('.lmgc-chip'), function (b) {
                if (b.classList.contains('is-on')) { b.classList.remove('is-spent'); return; }
                b.classList.toggle('is-spent', atMax);
            });
        }

        (q.options || []).forEach(function (o) {
            var b = el('button', { type: 'button', class: 'lmgc-chip', text: tpl(o.label, vars) });
            b.addEventListener('click', function () {
                if (q.multiple) {
                    var at = chosen.indexOf(o.value);
                    if (at === -1) {
                        if (q.max && chosen.length >= q.max) return;   // and the chip is greyed, so this is a backstop
                        chosen.push(o.value);
                        b.classList.add('is-on');
                    } else {
                        chosen.splice(at, 1);
                        b.classList.remove('is-on');
                    }
                    done.disabled = chosen.length === 0;
                    refreshHelp();
                } else {
                    group.remove();
                    if (help) help.remove();
                    addMessage('user', tpl(o.label, vars));
                    session.answer(q.id, [o.value]).next();
                    ga('concierge_match_answer', { facet: q.facet, value: o.value });
                    askQuestion(set, session);
                }
            });
            group.appendChild(b);
        });

        var done = null;
        if (q.multiple) {
            done = el('button', { type: 'button', class: 'lmgc-btn lmgc-options__done', text: S.ui.matchNext || 'Videre' });
            done.disabled = true;
            done.addEventListener('click', function () {
                if (!chosen.length) return;
                var labels = chosen.map(function (v) {
                    var m = (q.options || []).filter(function (o) { return o.value === v; })[0];
                    return m ? tpl(m.label, vars) : v;
                });
                group.remove();
                if (help) help.remove();
                addMessage('user', labels.join(', '));
                session.answer(q.id, chosen).next();
                ga('concierge_match_answer', { facet: q.facet, value: chosen.join(',') });
                askQuestion(set, session);
            });
            group.appendChild(done);
        }

        if (q.required === false) {
            var skip = el('button', { type: 'button', class: 'lmgc-chip lmgc-chip--quiet', text: S.ui.matchSkip || 'Spring over' });
            skip.addEventListener('click', function () {
                group.remove();
                if (help) help.remove();
                session.next();
                askQuestion(set, session);
            });
            group.appendChild(skip);
        }

        S.body.appendChild(group);
        scrollDown();
    }

    /** The same recommend() the widget calls, rendered in her shape. */
    function finishMatch(set, session) {
        var out = session.recommend();
        var res = (S.data.match && S.data.match.results) || {};
        var cfgResults = (Match.cache[set.id] && Match.cache[set.id].config.results) || {};
        var vars = { subject: set.subject };

        if (!out.results.length) {
            addMessage('assistant', tpl(cfgResults.emptyNote || 'Det har vi ikke dækket endnu.', vars));
        } else {
            addMessage('assistant', tpl(out.thin
                ? (cfgResults.thinNote || 'Vi har ikke skrevet så meget om lige den kombination. Her er det nærmeste, vi har.')
                : (S.ui.matchResult || 'Her er dit {{subject}}, ud fra det du har svaret.'), vars));
            renderCoverage(out.thin ? 'partial' : 'covered');
            renderSources(out.results.slice(0, 3).map(function (r) {
                return {
                    id: r.item.id,
                    title: r.item.title,
                    url: r.item.link || r.item.url || '',   // Match items carry the canonical URL as `link`; asking for `url` produced an <a> with no href
                    image: r.item.image || '',
                    why: (r.reasons && r.reasons.length)
                        ? (cfgResults.matchPrefix || 'Matcher') + ' ' + r.reasons.slice(0, 2).join(' og ')
                        : ''
                };
            }), set.subject);   // a finished run always knows its subject
        }

        // The knowledge half of the merge: what was asked for, and what it
        // produced. Recorded in HER log, which has no consent gate on it, so the
        // demand signal lands even while Match's own gate is still shut.
        event('match', {
            subject: set.subject,
            answers: session.answers,
            ids: out.results.slice(0, 4).map(function (r) { return r.item.id; }),
            thin: out.thin ? 1 : 0
        });
        ga('concierge_match_complete', {
            subject: set.subject, results: out.results.length,
            thin: out.thin, confident: out.confident
        });

        // Deliberately the newsletter, not runOffers(): five answered questions is
        // the warmest moment the panel gets. S.signedUp still keeps it from asking twice.
        maybeOfferNewsletter(out.thin ? 'partial' : 'covered');
    }

    // --- asking --------------------------------------------------------------------

    /**
     * A failure the request itself may survive if we simply ask again: the edge
     * refused it, the connection died, or the model came back unreadable. These
     * are the ones worth one silent retry (see attempt() below).
     *
     * 508 is the one that prompted this — LiteSpeed's "Resource Limit Reached".
     * It never reaches PHP, so it leaves no log row anywhere, and the reader is
     * simply told something went wrong. Three of those in a row is what G saw
     * on 9 Sep 2026.
     */
    function isTransient(reason, status) {
        if (status === 0 || status === 502 || status === 503 || status === 504 ||
            status === 508 || status === 520 || status === 522 || status === 524) return true;
        return reason === 'network' || reason === 'upstream' || reason === 'malformed' || reason === 'busy';
    }

    function lineFor(reason) {
        var ui = S.ui;
        switch (reason) {
            case 'rate': case 'daily': case 'turns': case 'upstream_rate': return ui.rateLine;
            case 'ceiling': case 'ceiling_day': case 'nokey': case 'rest_forbidden': case 'http_401': case 'http_403': return ui.pausedLine;
            case 'too_long': return ui.tooLongLine;
            // The model's own classifier declined the subject. It is not a fault,
            // and telling the reader "something went wrong at my end" was both
            // untrue and a dead end.
            case 'refusal': return ui.refusalLine || ui.errorLine;
            // Server or edge trouble that survived the retry. The reader did
            // nothing wrong and must be handed a way forward, not an apology.
            case 'network': case 'upstream': case 'malformed': case 'busy': case 'bad_request': case 'empty':
            case 'http_500': case 'http_502': case 'http_503': case 'http_504': case 'http_508':
            case 'http_520': case 'http_522': case 'http_524': case 'http_0':
                return ui.busyLine || ui.errorLine;
            default: return ui.errorLine;
        }
    }

    function ask(question) {
        if (S.busy) return;
        question = (question || '').trim();
        if (!question) return;

        // A bare destination is what the funnel is for, and it costs nothing to
        // run. A real question gets answered first — she never dodges one by
        // handing over a quiz.
        var browsingSet = (!Match.used && matchSets().length) ? detectSet(question) : null;
        if (browsingSet && looksLikeBrowsing(question)) {
            S.input.value = '';
            autosize();
            addMessage('user', question);
            offerMatch(browsingSet, S.ui.matchOfferTyped || '{{subject}} — godt valg. Skal vi tage fem hurtige spørgsmål, så finder jeg dit {{subject}}?');
            return;
        }

        S.busy = true;
        S.turn += 1;
        S.send.disabled = true;
        S.input.value = '';
        autosize();

        addMessage('user', question);
        var thinking = addMessage('assistant', S.ui.thinking || '…', 'lmgc-msg--thinking');
        ga('concierge_ask', { turn: S.turn });

        var payload = {
            question: question,
            history: S.history.slice(-12),
            conversation: S.conversation,
            turn: S.turn,
            page: { id: (S.data.page && S.data.page.id) || 0 }
        };

        var t0 = Date.now();
        var gen = S.gen;
        var headers = { 'Content-Type': 'application/json' };
        if (S.data.nonce) headers['X-WP-Nonce'] = S.data.nonce;   // logged-in testers; readers send none

        // ONE silent retry on a transient failure, then give up gracefully.
        //
        // An /ask holds a PHP worker for 10-15 seconds, which makes it the request
        // most likely to meet LiteSpeed's resource limit on a shared box — and a
        // 508 comes back as HTML, so r.json() throws and the reader is told the
        // whole thing broke. It usually has not: the same question a moment later
        // is answered normally. Measured 9 Sep 2026: the endpoint returned 200 in
        // 13.6s while five ordinary page loads stayed at 200 in ~1s, so a single
        // question does not starve the site — the failure is intermittent, which
        // is exactly the shape a retry fixes.
        //
        // Deliberately ONE retry, not a loop: two attempts turn a blip into an
        // answer, while a loop against a site already at its limit would push it
        // further under.
        //
        // The 2500 ms wait is MEASURED, not guessed (traveltalk.dk, 9 Sep 2026).
        // A question fired straight after a 13 s one came back 508 in 0.0 s; the
        // same question 3 s later came back 200 in 14.3 s. Ordinary page loads
        // stayed 200 the whole time, so the throttle sat on this endpoint, not on
        // the site. A 508 costs the reader nothing in time — it fails instantly —
        // so waiting 2.5 s before the real attempt is cheap, and it is the whole
        // difference between an answer and "something went wrong".
        function attempt(n) {
        if (gen !== S.gen) return;   // closed and reset while we waited
        fetch(S.data.endpoint.ask, {
            method: 'POST', headers: headers, body: JSON.stringify(payload)
        }).then(function (r) {
            return r.json().then(function (j) { return { status: r.status, json: j || {} }; }, function () { return { status: r.status, json: {} }; });
        }).then(function (res) {
            if (gen !== S.gen) return;   // answer to a thread the reader has closed
            var j = res.json;
            if (!j.ok) {
                var reason = j.reason || j.code || ('http_' + res.status);
                if (n === 0 && isTransient(reason, res.status)) {
                    ga('concierge_retry', { reason: reason, turn: S.turn });
                    setTimeout(function () { attempt(1); }, 2500);
                    return;   // the thinking indicator stays up; the reader sees one attempt
                }
                thinking.remove();
                addMessage('assistant', lineFor(reason));
                ga('concierge_error', { reason: reason, turn: S.turn, attempts: n + 1 });
                // A refused turn does not count against the conversation.
                S.turn -= 1;
                S.busy = false; S.send.disabled = false; if (S.open) S.input.focus();
                return;
            }
            thinking.remove();
            addMessage('assistant', j.reply);
            renderCoverage(j.coverage);
            // Derived from the sources that survived, so it describes the answer
            // the reader can see. Overwritten each turn: the signup is tagged with
            // what she was reading when she signed up, not with everything she asked.
            S.lastInterest = j.interest || '';
            // Detect the topic BEFORE the cards render, so the label can name it.
            // Deliberately not gated on Match.used: the offer may already be spent,
            // but the reader is still reading about Italien and the sign should say so.
            var topic = matchSets().length ? detectSet(question + ' ' + j.reply) : null;
            renderSources(j.sources, topic && topic.subject);
            S.history.push({ role: 'user', text: question });
            S.history.push({ role: 'assistant', text: j.reply });
            ga('concierge_answer', { coverage: j.coverage, sources_count: (j.sources || []).length, lang: j.language, turn: S.turn, seconds: Math.round((Date.now() - t0) / 1000) });
            // Answered first, then the deeper door: if the exchange was about a
            // destination she can run, offer the five questions underneath it.
            var followUp = (!Match.used && matchSets().length) ? topic : null;
            if (followUp) offerMatch(followUp, S.ui.matchOfferAfter || 'Vil du have det snævret ind? Fem hurtige spørgsmål, så finder jeg dit {{subject}}.');
            // Answer, cards, then the keepsake. Never the other way round.
            runOffers(j.coverage);
            S.busy = false; S.send.disabled = false; if (S.open) S.input.focus();
        }).catch(function () {
            if (gen !== S.gen) return;   // closed and reset while we waited
            // The fetch itself failed — offline, DNS, the edge dropping the
            // connection. Same treatment: one retry, then the busy line.
            if (n === 0) {
                ga('concierge_retry', { reason: 'network', turn: S.turn });
                setTimeout(function () { attempt(1); }, 2500);
                return;
            }
            thinking.remove();
            addMessage('assistant', S.ui.busyLine || S.ui.errorLine);
            ga('concierge_error', { reason: 'network', turn: S.turn, attempts: 2 });
            S.turn -= 1;
            S.busy = false; S.send.disabled = false; if (S.open) S.input.focus();
        });
        }
        attempt(0);
    }

    function autosize() {
        var i = S.input;
        i.style.height = 'auto';
        i.style.height = Math.min(120, i.scrollHeight) + 'px';
    }

    // --- open / close / focus --------------------------------------------------------

    function focusables() {
        return Array.prototype.filter.call(
            S.panel.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'),
            function (n) { return n.offsetParent !== null; }
        );
    }

    /**
     * One capture-phase handler for every way of closing by pointer.
     *
     * The close button kept not working on the live site even after its styling
     * was locked down (G, 6 Sep 2026, twice). The symptom fits an element of the
     * theme's sitting on top of it: the click lands on that element, so the
     * button never sees it — and because that element is inside the panel, an
     * outside-click guard correctly ignores it too. So this does not ask WHAT was
     * clicked, it asks WHERE: any click inside the close button's rectangle
     * closes the panel, whatever happens to be painted over it.
     */
    function onGlobalClick(e) {
        if (!S.open || !S.panel) return;

        var btn = S.panel.querySelector('.lmgc-head__close');
        if (btn) {
            var r = btn.getBoundingClientRect();
            if (r.width && e.clientX >= r.left && e.clientX <= r.right &&
                e.clientY >= r.top && e.clientY <= r.bottom) {
                e.preventDefault();
                e.stopPropagation();
                close(false);
                return;
            }
        }

        if (e.type === 'pointerdown') return;   // the geometry check above is the only pointerdown job
        if (S.panel.contains(e.target)) return;
        if (S.opener && S.opener.contains(e.target)) return;   // the card toggles itself
        close(false);
    }

    function onKey(e) {
        if (e.key === 'Escape') { e.preventDefault(); close(false); return; }
        if (e.key !== 'Tab') return;
        var f = focusables();
        if (!f.length) return;
        var first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }

    function build() {
        var cfg = S.cfg, ui = S.ui, a = S.data.assets;
        var persona = cfg.persona || {};

        // The panel header shows her settled, looking at the reader — the turn
        // already happened on the card that opened this. A still, not a loop:
        // nothing should be moving while someone is reading an answer.
        var face = el('img', { class: 'lmgc-head__face', src: a.face, alt: '', width: '48', height: '48' });

        var closeBtn = el('button', { type: 'button', class: 'lmgc-head__close', 'aria-label': ui.closeLabel || 'Luk', text: '×' });
        closeBtn.addEventListener('click', function () { close(false); });

        var titleId = 'lmgc-title-' + S.conversation;
        // The mark is styling, not a second spelling — the same string as
        // persona.name everywhere else, with the syllable that carries the
        // machine picked out in the site's accent.
        //
        // It used to colour the first two characters, which is only right for
        // Aianna. On Kai that painted "Ka" and left the "i" behind — the exact
        // half of the pun it was meant to reveal (G, 8 Sep 2026). So the config
        // now names the SUBSTRING, because its position differs per persona:
        // "Ai" in Aianna, "ai" in Kai, "Bot" in Bottiglia. Absent, or not found
        // in the name, falls back to the first two characters — so a config
        // written before this change behaves exactly as it did.
        var fullName = persona.name || 'Aianna';
        var mark = (typeof persona.mark === 'string') ? persona.mark : '';
        var at   = mark ? fullName.indexOf(mark) : 0;
        if (at < 0) { at = 0; mark = ''; }
        var len  = mark ? mark.length : Math.min(2, fullName.length);
        var nameNode = el('h2', { class: 'lmgc-head__name', id: titleId }, []);
        if (at > 0) nameNode.appendChild(document.createTextNode(fullName.slice(0, at)));
        nameNode.appendChild(el('span', { class: 'ai-mark', text: fullName.substr(at, len) }));
        if (at + len < fullName.length) nameNode.appendChild(document.createTextNode(fullName.slice(at + len)));
        if (persona.tagline) {
            nameNode.appendChild(document.createTextNode(', '));
            nameNode.appendChild(el('span', { class: 'lmgc-head__tagline', text: persona.tagline }));
        }
        var head = el('div', { class: 'lmgc-head' }, [
            face,
            el('div', { class: 'lmgc-head__text' }, [ nameNode ]),
            closeBtn
        ]);

        S.body = el('div', { class: 'lmgc-body', 'aria-live': 'polite' });

        S.input = el('textarea', { class: 'lmgc-input', rows: '1', placeholder: ui.placeholder || '', 'aria-label': ui.placeholder || 'Spørgsmål', maxlength: '600' });
        S.send = el('button', { type: 'submit', class: 'lmgc-btn', text: ui.send || 'Send' });
        var form = el('form', { class: 'lmgc-form' }, [S.input, S.send]);
        form.addEventListener('submit', function (e) { e.preventDefault(); ask(S.input.value); });
        S.input.addEventListener('input', autosize);
        S.input.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ask(S.input.value); }
        });

        S.panel = el('section', { class: 'lmgc-panel', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': titleId, hidden: 'hidden' }, [head, S.body, form]);
        if (cfg.accent) S.panel.style.setProperty('--lmgc-accent', cfg.accent);
        S.panel.addEventListener('keydown', onKey);
        document.body.appendChild(S.panel);
    }

    /** On opening, if the page itself is about a destination she can run. */
    function offerOnOpen() {
        var page = (S.data.page && S.data.page.title) || '';
        var set = detectSet(page);
        if (set) offerMatch(set, S.ui.matchOfferPage || 'Du står på {{subject}}. Skal vi tage fem hurtige spørgsmål, så finder jeg dit {{subject}}?');
    }

    function open(data, ctx) {
        if (!S.panel) {
            S.data = data; S.cfg = data.config || {}; S.ui = S.cfg.ui || {};
            build();
        }
        S.opener = ctx && ctx.bubble; S.dock = ctx && ctx.dock;
        if (S.open) { S.input.focus(); return; }

        S.open = true;
        S.panel.hidden = false;
        document.documentElement.classList.add('lmgc-open');
        // A second way out, in case a theme ever eats the close button's click
        // again: anywhere outside the panel closes it. Bound on the next tick so
        // the click that opened it doesn't immediately close it.
        window.setTimeout(function () {
            // Bound in four places on purpose. This button has failed three times
            // on the live site (G, 6 Sep 2026): an overlay took the click, and a
            // capture listener on window would run before one on document and
            // could stop it before we saw it. pointerdown fires before click.
            window.addEventListener('pointerdown', onGlobalClick, true);
            window.addEventListener('click', onGlobalClick, true);
            document.addEventListener('pointerdown', onGlobalClick, true);
            document.addEventListener('click', onGlobalClick, true);
        }, 0);
        if (S.dock) S.dock.style.display = 'none';
        if (S.opener) S.opener.setAttribute('aria-expanded', 'true');

        if (!S.greeted) {
            S.greeted = true;
            if (S.ui.greeting) addMessage('assistant', S.ui.greeting);
            addCampaign();
            if (S.ui.disclaimer) addNote(S.ui.disclaimer);
            offerOnOpen();
            event('open');
            ga('concierge_open', {});
        }
        S.input.focus();
    }

    /**
     * Closing is a RESET, not a minimise.
     *
     * Before this, close() only hid the panel: the thread, the typed input, the
     * turn count and the spent Match offer all survived, so reopening dropped the
     * reader back into a conversation they had visibly ended — and the greeting,
     * campaign line and disclaimer never came back, because S.greeted stayed true.
     * Close + reopen on the same page now lands exactly where a page load does.
     *
     * The conversation token is reissued too: a new thread is a new conversation
     * for logging, not a continuation of the one that was closed.
     */
    function reset() {
        if (!S.panel) return;
        S.gen += 1;                 // orphans any request still in flight
        S.body.innerHTML = '';
        S.input.value = '';
        autosize();
        S.history = [];
        S.turn = 0;
        S.busy = false;
        S.send.disabled = false;
        S.greeted = false;
        S.newsletterOffered = false;
        S.keepsakeOffered = false;
        S.lastSources = [];
        S.lastInterest = '';
        S.conversation = token();
        Match.used = false;
    }

    function close(silent) {
        if (!S.panel || !S.open) return;
        S.open = false;
        S.panel.hidden = true;
        document.documentElement.classList.remove('lmgc-open');
        window.removeEventListener('pointerdown', onGlobalClick, true);
        window.removeEventListener('click', onGlobalClick, true);
        document.removeEventListener('pointerdown', onGlobalClick, true);
        document.removeEventListener('click', onGlobalClick, true);
        if (S.dock) S.dock.style.display = '';
        if (S.opener) {
            S.opener.setAttribute('aria-expanded', 'false');
            if (!silent) S.opener.focus();
        }
        reset();
    }

    window.LMGConcierge = { open: open, close: close, ask: ask };
})(window, document);
