/**
 * lmg-concierge boot — the resting card, and nothing else.
 *
 * The only script a page view pays for. Draws a light portrait card at first
 * paint from a still, then once the page has finished loading and the browser
 * is idle, plays the turn ONCE and holds on the last frame — she is
 * three-quarter away at the start, turns, and settles looking at the reader.
 * No loop: a loop would snap her back to looking away every few seconds, which
 * is the opposite of the effect. (G, 6 Sep 2026: "turn and hold".)
 *
 * It does not open itself. Ever. (Brief §6.) Reduced-motion visitors get the
 * settled face still and no video at all.
 *
 * Diagnostic: append ?lmgc_debug=1 to any URL for a readout of what this script
 * actually did on that device — built for the "invisible on iPhone" hunt.
 * Harmless to leave in; it renders only when explicitly asked for.
 */
(function (window, document) {
    'use strict';

    var debug = /[?&]lmgc_debug=1/.test(window.location.search);
    var notes = [];
    function note(k, v) { notes.push(k + ': ' + v); }

    function readData() {
        var node = document.getElementById('lmg-concierge-data');
        if (!node) return null;
        try { return JSON.parse(node.textContent); } catch (e) { return null; }
    }


    function el(tag, attrs, children) {
        var node = document.createElement(tag);
        for (var k in attrs || {}) {
            if (k === 'text') node.textContent = attrs[k];
            else if (attrs[k] !== null && attrs[k] !== undefined) node.setAttribute(k, attrs[k]);
        }
        (children || []).forEach(function (c) { if (c) node.appendChild(c); });
        return node;
    }

    function showDebug(extra) {
        var box = el('div', { id: 'lmgc-debug' });
        box.setAttribute('style', 'position:fixed;left:8px;right:8px;bottom:8px;z-index:2147483647;' +
            'background:#111;color:#0f0;font:11px/1.45 ui-monospace,Menlo,monospace;padding:10px 12px;' +
            'border-radius:8px;max-height:60vh;overflow:auto;white-space:pre-wrap');
        box.textContent = 'LMG CONCIERGE DEBUG\n' + notes.concat(extra || []).join('\n');
        (document.body || document.documentElement).appendChild(box);
    }

    var data = readData();
    note('script ran', 'yes');
    note('data block found', data ? 'yes' : 'NO');
    note('viewport', window.innerWidth + 'x' + window.innerHeight);

    if (!data || !data.config) {
        if (debug) showDebug(['stopped: no data block — not logged in as an admin on this device, or visibility is off']);
        return;
    }

    var cfg = data.config;
    var ui = cfg.ui || {};
    var accent = cfg.accent || '#B8956A';
    var reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    note('reduced motion', reducedMotion ? 'yes — still only' : 'no');
    note('is front page', (data.page && data.page.isFront) ? 'yes' : 'no');

    // --- card styles: inline, present at first paint ---------------------------
    //
    // Light, not heavy (G, 6 Sep 2026: "keep it light and elegant, what we are").
    // Nothing is written over her face. The resting line — "Spørg Traveltalk",
    // short by G's call because "the rest is a given" — sits in a small pill
    // UNDER the card, as a sibling, not a band across the portrait. The earlier
    // long line wrapped to three lines and hid her chin behind the band.
    //
    // 92×122, down again from 104×138 ("not too big"). Ratio held at ~0.754, the
    // exact ratio the crop was cut to, so the image fills it with no letterboxing.
    //
    // Back to a plain bottom:20px — GTranslate's switcher moved to bottom_left on
    // 6 Sep 2026, so the 78px clearance it used to need is gone.

    var css = [
        '.lmgc-dock{position:fixed;right:20px;bottom:20px;z-index:99980;display:inline-block;font-family:"Inter",-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}',
        '.lmgc-card{position:relative;display:block;width:92px;height:122px;padding:0;margin:0;border:0;border-radius:14px;overflow:hidden;cursor:pointer;background:#FAFAF7;box-shadow:0 4px 16px rgba(0,0,0,.16);-webkit-tap-highlight-color:transparent;transition:box-shadow .15s,transform .15s}',
        '.lmgc-card:hover,.lmgc-card:focus-visible{box-shadow:0 8px 22px rgba(0,0,0,.22);transform:translateY(-1px);outline:2px solid ' + accent + ';outline-offset:2px}',
        '.lmgc-card__media{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:50% 42%;display:block}',
        '.lmgc-dock__line{display:block;margin:5px auto 0;padding:3px 8px;width:-webkit-fit-content;width:fit-content;max-width:132px;background:rgba(255,255,255,.93);color:#252528;font-size:10px;font-weight:500;line-height:1.3;letter-spacing:.01em;text-align:center;white-space:nowrap;border-radius:999px;box-shadow:0 2px 8px rgba(0,0,0,.14);pointer-events:none}',
        '@media (max-width:600px){.lmgc-dock{right:14px;bottom:calc(16px + env(safe-area-inset-bottom,0))}.lmgc-card{width:68px;height:90px;border-radius:10px}.lmgc-dock__line{font-size:9px;padding:2px 7px;margin-top:4px}}',

        // --- the wide shape ---------------------------------------------------
        //
        // Half portrait, half why. Same HEIGHT as the tall card — it grows
        // sideways, never downward, because a taller card eats the article and
        // a wider one sits along the foot of it and reads as part of the page.
        // The explanation lives INSIDE the card, so the thing you read and the
        // thing you click are one object rather than a pill floating under a face.
        '.lmgc-dock--wide .lmgc-card{display:flex;width:304px;height:122px;text-align:left;background:#FAFAF7}',
        '.lmgc-dock--wide .lmgc-card__media{position:relative;inset:auto;width:50%;height:100%;flex:0 0 50%;border-radius:14px 0 0 14px}',
        '.lmgc-dock--wide .lmgc-card__say{display:flex;flex-direction:column;justify-content:center;gap:3px;width:50%;padding:0 12px;box-sizing:border-box}',
        '.lmgc-dock--wide .lmgc-card__name{color:#252528;font-size:13px;font-weight:600;line-height:1.25;letter-spacing:-.01em}',
        '.lmgc-dock--wide .lmgc-card__why{color:#55555c;font-size:11px;font-weight:400;line-height:1.35}',
        '.lmgc-dock--wide .lmgc-card__cue{color:' + accent + ';font-size:11px;font-weight:600;line-height:1.3}',
        // Below 600px a 304px card is most of the screen, so it comes in to 268
        // and the explanation tightens. It does not fall back to the tall shape:
        // the phone is where "what is this" is asked most and answered least.
        '@media (max-width:600px){.lmgc-dock--wide .lmgc-card{width:268px;height:104px}.lmgc-dock--wide .lmgc-card__say{padding:0 10px}.lmgc-dock--wide .lmgc-card__name{font-size:12px}.lmgc-dock--wide .lmgc-card__why{font-size:10px;line-height:1.3}.lmgc-dock--wide .lmgc-card__cue{font-size:10px}}',
        '@media (prefers-reduced-motion:reduce){.lmgc-card{transition:none}}'
    ].join('');
    var style = el('style', { 'data-no-optimize': '1' });
    style.textContent = css;
    document.head.appendChild(style);

    // --- the dock ----------------------------------------------------------------
    //
    // Reduced motion starts on the settled face; everyone else starts on the frame
    // the turn begins from, so the motion has somewhere to travel from.

    // No clip configured means no clip is coming: open on the settled face and
    // never reach for a poster that does not exist. Until 4 Oct 2026 the card
    // always started on turnPoster, so a site with a portrait but no turn — which
    // is every site that has not had six files hand-cut — opened on a 404 and
    // showed a broken image. That is what kept Kai off worldsporttalk.com.
    var hasTurn = !!(data.assets.turn && data.assets.turnPoster);
    var startImg = (reducedMotion || !hasTurn) ? data.assets.face : data.assets.turnPoster;
    var media = el('img', {
        src: startImg, width: '80', height: '106', alt: '', 'aria-hidden': 'true',
        class: 'lmgc-card__media', decoding: 'async'
    });
    var wide = (ui.cardShape === 'wide');

    // The wide card says three things in the space the tall one had for none:
    // who she is, what she does with your question, and that you may click.
    var inside = [ media ];
    if (wide) {
        var say = el('span', { class: 'lmgc-card__say' });
        say.appendChild(el('span', {
            class: 'lmgc-card__name',
            text: ((cfg.persona || {}).name || 'Aianna') + ((cfg.persona || {}).tagline ? ', ' + cfg.persona.tagline : '')
        }));
        if (ui.cardLine) say.appendChild(el('span', { class: 'lmgc-card__why', text: ui.cardLine }));
        if (ui.restingLine) say.appendChild(el('span', { class: 'lmgc-card__cue', text: ui.restingLine }));
        inside.push(say);
    }

    var card = el('button', {
        type: 'button', class: 'lmgc-card',
        'aria-label': ui.openLabel || ('Åbn ' + ((cfg.persona || {}).name || 'Aianna')),
        'aria-haspopup': 'dialog', 'aria-expanded': 'false'
    }, inside);
    // No dismiss control on the card, by G's ruling of 6 Sep 2026: »the (x) is only
    // for when the user has opened the main window … you should be able to close that
    // and see her always in the corner«. The panel's × closes the PANEL and hands the
    // reader straight back to the card; nothing takes her off the page. Do not put a
    // second × back on the card without asking — it is a deliberate choice, not an
    // oversight, and it is marked "for now".
    // The pill under the portrait belongs to the tall shape only — in the wide
    // card the same words sit inside it, and a second copy underneath would be
    // the bulk the 6 Sep ruling cut.
    var restLine = (!wide && ui.restingLine)
        ? el('span', { class: 'lmgc-dock__line', text: ui.restingLine, 'aria-hidden': 'true' })
        : null;
    var dock = el('div', { class: 'lmgc-dock' + (wide ? ' lmgc-dock--wide' : '') }, [card, restLine]);

    // The bottom-right corner, on every page. Two placements were tried on the
    // front page on 6 Sep 2026 and both were withdrawn by G the same day: the
    // white headline band ("forget my asking to move her"), then the hero photo's
    // top-right ("too much going on in top right corner" — the header's menu and
    // search already live there). The language picker moved to bottom_left the
    // same day, so the corner a concierge belongs in is free.
    var mount = document.getElementById('lmg-concierge');
    if (mount) { mount.hidden = false; mount.appendChild(dock); } else { document.body.appendChild(dock); }
    note('placement', 'bottom-right corner');

    // --- the turn: played once after load, then held -----------------------------

    function idle(fn) {
        if ('requestIdleCallback' in window) window.requestIdleCallback(fn, { timeout: 2000 });
        else window.setTimeout(fn, 700);
    }

    function playTurn() {
        if (!document.body.contains(card)) return;
        var video = el('video', {
            class: 'lmgc-card__media', poster: data.assets.turnPoster, width: '80', height: '106',
            autoplay: '', muted: '', playsinline: '', preload: 'auto', 'aria-hidden': 'true'
        });
        video.muted = true;          // property as well as attribute — Safari needs both
        video.setAttribute('muted', '');
        video.playsInline = true;    // ditto, or iOS plays it fullscreen
        video.src = data.assets.turn;
        media.replaceWith(video);
        media = video;

        // Autoplay refused, or the file is not there at all. Either way the
        // answer is the same — fall back to the settled face rather than leave
        // her frozen mid-turn looking away, or worse, show a broken element.
        // The error listener is the half that was missing: play() resolves
        // happily and then the source 404s, which no catch() ever sees.
        function settle() {
            if (media !== video) return;
            var img = el('img', {
                src: data.assets.face, width: '80', height: '106', alt: '',
                'aria-hidden': 'true', class: 'lmgc-card__media', decoding: 'async'
            });
            video.replaceWith(img);
            media = img;
        }
        video.addEventListener('error', settle, { once: true });
        var p = video.play();
        if (p && p.catch) p.catch(settle);
    }

    if (!reducedMotion && hasTurn) {
        if (document.readyState === 'complete') idle(playTurn);
        else window.addEventListener('load', function () { idle(playTurn); }, { once: true });
    }

    // --- lazy loading of the panel -----------------------------------------------

    var loading = null;
    function loadPanel() {
        if (window.LMGConcierge) return Promise.resolve(window.LMGConcierge);
        if (loading) return loading;
        loading = new Promise(function (resolve, reject) {
            var link = el('link', { rel: 'stylesheet', href: data.assets.css, 'data-no-optimize': '1' });
            document.head.appendChild(link);
            var script = el('script', { src: data.assets.panel, 'data-no-optimize': '1' });
            script.onload = function () { window.LMGConcierge ? resolve(window.LMGConcierge) : reject(new Error('panel missing')); };
            script.onerror = function () { loading = null; reject(new Error('panel failed')); };
            document.head.appendChild(script);
        });
        return loading;
    }

    card.addEventListener('pointerenter', function () { loadPanel().catch(function () {}); }, { once: true });
    card.addEventListener('focus', function () { loadPanel().catch(function () {}); }, { once: true });

    card.addEventListener('click', function () {
        card.disabled = true;
        loadPanel().then(function (Panel) {
            Panel.open(data, { dock: dock, bubble: card });
        }).catch(function () {
            // The panel could not load. Say nothing loud; the card simply stays.
        }).then(function () { card.disabled = false; });
    });

    // --- the in-page band's way in -----------------------------------------------
    //
    // The band on the front page is server-rendered and knows nothing about the
    // panel, the config blob or the lazy loader. It calls this. Re-implementing
    // the loader in the band would be a second copy of the one piece of this
    // plugin that is genuinely fiddly — two stylesheets, a script tag, and a
    // promise that must not fire twice.
    window.LMGConciergeDock = {
        warm: function () { return loadPanel().catch(function () {}); },
        open: function (prefill) {
            return loadPanel().then(function (Panel) {
                Panel.open(data, { dock: dock, bubble: card });
                if (prefill) Panel.ask(prefill);
                return Panel;
            });
        }
    };
    window.dispatchEvent(new CustomEvent('lmgc:ready'));

    if (debug) {
        var r = card.getBoundingClientRect();
        showDebug([
            'card rendered: ' + Math.round(r.width) + 'x' + Math.round(r.height) +
                ' at top ' + Math.round(r.top) + ', left ' + Math.round(r.left),
            'card on screen: ' + (r.width > 0 && r.height > 0 && r.bottom > 0 &&
                r.top < window.innerHeight && r.right > 0 && r.left < window.innerWidth
                ? 'YES' : 'NO — rendered off screen'),
            'turn clip: ' + data.assets.turn
        ]);
    }

    window.LMGConciergeBoot = { data: data, dock: dock, card: card, load: loadPanel };
})(window, document);
