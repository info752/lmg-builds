<?php
/**
 * Udseende → Forsidens hero.
 *
 * Settings plus a preview of the live slides. The list follows publishing; pin a post to lead.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action(
	'admin_menu',
	function () {
		add_theme_page(
			'Forsidens hero',
			'Forsidens hero',
			'edit_theme_options',
			'tt-front-hero',
			'tt_hero_admin_page'
		);
	}
);

add_action(
	'admin_init',
	function () {
		register_setting(
			'tt_hero',
			'tt_hero_settings',
			array(
				'type'              => 'array',
				'sanitize_callback' => 'tt_hero_sanitize',
				'default'           => tt_hero_defaults(),
			)
		);
	}
);

/* options.php checks manage_options unless told otherwise; the screen itself is edit_theme_options. */
add_filter(
	'option_page_capability_tt_hero',
	function () {
		return 'edit_theme_options';
	}
);

/**
 * Clean the submitted settings.
 *
 * @param mixed $in Submitted values.
 * @return array
 */
function tt_hero_sanitize( $in ) {
	$in = (array) $in;

	return array(
		'limit'       => max( 1, min( 12, absint( $in['limit'] ?? 5 ) ) ),
		'interval'    => max( 2, min( 30, absint( $in['interval'] ?? 5 ) ) ),
		'stem'        => sanitize_text_field( $in['stem'] ?? '' ),
		'exclude'     => array_values( array_filter( array_map( 'absint', preg_split( '/[\s,]+/', (string) ( $in['exclude'] ?? '' ) ) ) ) ),
		'dest_root'   => absint( $in['dest_root'] ?? 0 ),
		'video_path'  => sanitize_title( $in['video_path'] ?? '' ),
		'video_label' => sanitize_text_field( $in['video_label'] ?? '' ),
		'auto'        => empty( $in['auto'] ) ? 0 : 1,
		'replace'     => empty( $in['replace'] ) ? 0 : 1,
		'mode'        => ( isset( $in['mode'] ) && 'carousel' === $in['mode'] ) ? 'carousel' : 'hero',
	);
}

/**
 * The settings form.
 */
function tt_hero_settings_form() {
	$rows = array(
		'mode'        => array( 'Type', 'select', '<strong>Hero</strong>: billeder af de nyeste artikler (som på traveltalk). <strong>Karrusel</strong>: forsidens første sektion bliver stående som slide 1, uændret, og de nyeste artikler med udvalgt billede følger efter, med pile og prikker. Artikler uden udvalgt billede springes over.' ),
		'limit'       => array( 'Antal slides', 'number', 'I karrusellen: antal artikler efter første sektion (fx 4).' ),
		'interval'    => array( 'Sekunder pr. slide', 'number', '' ),
		'stem'        => array( 'Overskriftens stamme', 'text', 'Fx <code>Rejser med sjæl</code>. Hero-halen fra kategorien sættes efter.' ),
		'exclude'     => array( 'Udelad kategorier (ID)', 'text', 'Kommasepareret, fx <code>3069</code>. Tom = ingen.' ),
		'dest_root'   => array( 'Rejsemål-kategori (ID)', 'number', 'Bruges kun til Region-kolonnen herunder. 0 = ingen.' ),
		'video_path'  => array( 'Videoside (slug)', 'text', 'Hjørnelinket vises kun, når siden er udgivet. Tom = intet link.' ),
		'video_label' => array( 'Videolinkets tekst', 'text', '' ),
		'auto'        => array( 'Placér automatisk', 'checkbox', 'Heroen sættes øverst på forsiden uden at redigere siden. Ikke nødvendig, hvis siden har <code>[tt_hero]</code>.' ),
		'replace'     => array( 'Erstat første sektion', 'checkbox', 'Heroen træder i stedet for forsidens første sektion (fx en velkomst). Kræver automatisk placering. Bruges ikke af karrusellen.' ),
	);

	echo '<form method="post" action="options.php">';
	settings_fields( 'tt_hero' );
	echo '<table class="form-table" role="presentation">';

	foreach ( $rows as $key => $row ) {
		$val = tt_hero_opt( $key );
		if ( is_array( $val ) ) {
			$val = implode( ', ', $val );
		}

		echo '<tr><th scope="row"><label for="tt_hero_' . esc_attr( $key ) . '">' . esc_html( $row[0] ) . '</label></th><td>';
		if ( 'select' === $row[1] ) {
			printf( '<select id="tt_hero_%1$s" name="tt_hero_settings[%1$s]">', esc_attr( $key ) );
			foreach ( array( 'hero' => 'Hero', 'carousel' => 'Karrusel' ) as $v => $l ) {
				printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $v ), selected( $val, $v, false ), esc_html( $l ) );
			}
			echo '</select>';
		} elseif ( 'checkbox' === $row[1] ) {
			printf(
				'<input id="tt_hero_%1$s" name="tt_hero_settings[%1$s]" type="checkbox" value="1"%2$s>',
				esc_attr( $key ),
				checked( (int) $val, 1, false )
			);
		} else {
			printf(
				'<input id="tt_hero_%1$s" name="tt_hero_settings[%1$s]" type="%2$s" value="%3$s" class="%4$s">',
				esc_attr( $key ),
				esc_attr( $row[1] ),
				esc_attr( $val ),
				'number' === $row[1] ? 'small-text' : 'regular-text'
			);
		}
		if ( $row[2] ) {
			echo '<p class="description">' . wp_kses( $row[2], array( 'code' => array(), 'strong' => array() ) ) . '</p>';
		}
		echo '</td></tr>';
	}

	echo '</table>';
	submit_button();
	echo '</form>';
}

/**
 * Render the live slides.
 */
function tt_hero_admin_table() {
	$set = tt_hero_pick();

	echo '<table class="widefat striped" style="margin-bottom:1em"><thead><tr>'
		. '<th style="width:60px">#</th><th style="width:120px">Billede</th><th>Artikel</th>'
		. '<th style="width:160px">Region</th><th style="width:160px">Hero-hale</th>'
		. '<th style="width:240px">Overskrift der vises</th>'
		. '</tr></thead><tbody>';

	foreach ( $set as $i => $id ) {
		$region      = tt_hero_region( $id );
		$region_term = $region ? get_term( $region, 'category' ) : null;
		$tail        = tt_hero_tail( $id );

		echo '<tr>';
		echo '<td>' . esc_html( $i + 1 ) . '</td>';
		echo '<td>' . get_the_post_thumbnail( $id, array( 100, 60 ), array( 'style' => 'width:100px;height:60px;object-fit:cover' ) ) . '</td>';
		echo '<td><a href="' . esc_url( get_edit_post_link( $id ) ) . '">' . esc_html( get_the_title( $id ) ) . '</a><br>'
			. '<a href="' . esc_url( get_permalink( $id ) ) . '" target="_blank" rel="noopener" style="color:#666">Se live &rarr;</a></td>';
		echo '<td>' . esc_html( $region_term && ! is_wp_error( $region_term ) ? $region_term->name : '—' ) . '</td>';
		echo '<td>' . ( $tail ? esc_html( $tail ) : '<span style="color:#b32d2e">tom</span>' ) . '</td>';
		echo '<td><strong>' . esc_html( tt_hero_headline( $id ) ) . '</strong></td>';

		echo '</tr>';
	}

	echo '</tbody></table>';
}

/**
 * The screen.
 */
function tt_hero_admin_page() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}

	echo '<div class="wrap"><h1>Forsidens hero</h1>';

	$video = tt_hero_video_url();
	if ( ! $video && tt_hero_opt( 'video_path' ) ) {
		echo '<div class="notice notice-warning"><p><strong>Hjørnelinket til videobiblioteket vises ikke.</strong> '
			. 'Siden <code>/' . esc_html( tt_hero_opt( 'video_path' ) ) . '/</code> findes ikke endnu. Linket tænder af sig selv, '
			. 'når siden er udgivet — der skal ikke rettes noget her.</p></div>';
	}

	echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=tt-front-hero-notes' ) ) . '">Release notes</a> · version ' . esc_html( TT_HERO_VERSION ) . '</p>';

	tt_hero_settings_form();

	if ( tt_hero_is_carousel() ) {
		echo '<h2>Slides lige nu</h2>';
		echo '<p>' . ( tt_hero_opt( 'auto' ) ? 'Karrusellen er <strong>tændt</strong>.' : 'Karrusellen er <strong>slukket</strong>: sæt hak i Placér automatisk og gem.' )
			. ' Slide 1 er forsidens første sektion. Derefter de ' . esc_html( (int) tt_hero_opt( 'limit' ) ) . ' nyeste artikler med udvalgt billede, '
			. 'skift hvert ' . esc_html( (int) tt_hero_opt( 'interval' ) ) . '. sekund. Indlæggene i nyhedsgitteret under karrusellen ændres ikke.</p>';
		echo '<table class="widefat striped" style="margin-bottom:1em"><thead><tr><th style="width:60px">#</th><th style="width:120px">Billede</th><th>Slide</th></tr></thead><tbody>';
		echo '<tr><td>1</td><td>—</td><td>Forsidens første sektion, som den er</td></tr>';
		$n = 1;
		foreach ( tt_hero_pool() as $id ) {
			if ( $n > (int) tt_hero_opt( 'limit' ) ) {
				break;
			}
			$n++;
			echo '<tr><td>' . esc_html( $n ) . '</td><td>' . get_the_post_thumbnail( $id, array( 100, 60 ), array( 'style' => 'width:100px;height:60px;object-fit:cover' ) ) . '</td>'
				. '<td><a href="' . esc_url( get_edit_post_link( $id ) ) . '">' . esc_html( get_the_title( $id ) ) . '</a></td></tr>';
		}
		echo '</tbody></table></div>';
		return;
	}

	echo '<h2>Slides lige nu</h2>';
	echo '<p>Heroen viser de ' . esc_html( (int) tt_hero_opt( 'limit' ) ) . ' nyeste artikler med udvalgt billede, nyeste først, '
		. 'og skifter hvert ' . esc_html( (int) tt_hero_opt( 'interval' ) ) . '. sekund. '
		. 'Vil du have en bestemt artikel først, så fastgør den (Fastgør øverst på bloggen). Hero-halen (<em>i Italien</em>, <em>på Bali</em>) '
		. 'sættes én gang pr. kategori under <a href="' . esc_url( admin_url( 'edit-tags.php?taxonomy=category' ) ) . '">Indlæg → Kategorier</a>. '
		. 'Er den tom, vises kun stammen <strong>' . esc_html( tt_hero_opt( 'stem' ) ) . '</strong> — det er en gyldig overskrift, ikke en fejl.</p>';

	tt_hero_admin_table();

	echo '</div>';
}
