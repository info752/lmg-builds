<?php
/**
 * 1.4.0: release notes, from RELEASE-NOTES.md in the plugin folder.
 *
 * Udseende → Forsidens hero links to the page. After an update, each user who can edit
 * the theme sees one notice linking to it, until they open the page or dismiss the notice.
 * Same pattern as LMG Translator.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action(
	'admin_menu',
	function () {
		add_submenu_page( 'options.php', 'TT Front Hero – release notes', 'TT Front Hero – release notes', 'edit_theme_options', 'tt-front-hero-notes', 'tt_hero_notes_page' );
	}
);

add_action(
	'wp_ajax_tt_hero_notes_seen',
	function () {
		check_ajax_referer( 'tt_hero_notes_seen' );
		update_user_meta( get_current_user_id(), 'tt_hero_notes_seen', TT_HERO_VERSION );
		wp_send_json_success();
	}
);

add_action(
	'admin_notices',
	function () {
		if ( ! current_user_can( 'edit_theme_options' ) || get_user_meta( get_current_user_id(), 'tt_hero_notes_seen', true ) === TT_HERO_VERSION ) {
			return;
		}
		if ( isset( $_GET['page'] ) && 'tt-front-hero-notes' === $_GET['page'] ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		echo '<div class="notice notice-info is-dismissible" id="tt-hero-notes-notice"><p>TT Front Hero is updated to ' . esc_html( TT_HERO_VERSION )
			. '. <a href="' . esc_url( admin_url( 'admin.php?page=tt-front-hero-notes' ) ) . '">What is new</a></p></div>';
		echo "<script>jQuery(document).on('click','#tt-hero-notes-notice .notice-dismiss',function(){jQuery.post(ajaxurl,{action:'tt_hero_notes_seen',_ajax_nonce:'" . esc_js( wp_create_nonce( 'tt_hero_notes_seen' ) ) . "'});});</script>";
	}
);

/**
 * The page.
 */
function tt_hero_notes_page() {
	update_user_meta( get_current_user_id(), 'tt_hero_notes_seen', TT_HERO_VERSION );
	$file = plugin_dir_path( __FILE__ ) . 'RELEASE-NOTES.md';
	$md   = is_readable( $file ) ? file_get_contents( $file ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions
	echo '<div class="wrap" style="max-width:820px">' . ( '' === $md ? '<h1>Release notes</h1><p>No release notes found.</p>' : tt_hero_notes_html( $md ) ) . '</div>';
}

/**
 * The few Markdown forms the notes use: headings, lists, bold, paragraphs.
 *
 * @param string $md Markdown.
 * @return string
 */
function tt_hero_notes_html( $md ) {
	$out  = '';
	$open = false;
	foreach ( preg_split( '/\R/', $md ) as $line ) {
		$t = preg_replace( '/\*\*(.+?)\*\*/', '<strong>$1</strong>', esc_html( $line ) );
		if ( preg_match( '/^- (.*)$/', $line ) ) {
			$out .= ( $open ? '' : '<ul style="list-style:disc;margin-left:20px">' ) . '<li>' . substr( $t, 2 ) . '</li>';
			$open = true;
			continue;
		}
		if ( $open ) {
			$out .= '</ul>';
			$open = false;
		}
		if ( '' === trim( $line ) ) {
			continue;
		}
		if ( preg_match( '/^(#{1,3}) /', $line, $h ) ) {
			$n    = strlen( $h[1] );
			$out .= '<h' . $n . '>' . substr( $t, $n + 1 ) . '</h' . $n . '>';
		} else {
			$out .= '<p>' . $t . '</p>';
		}
	}
	return $out . ( $open ? '</ul>' : '' );
}
