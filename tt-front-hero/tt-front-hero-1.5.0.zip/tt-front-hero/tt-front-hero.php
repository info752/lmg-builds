<?php
/**
 * Plugin Name: TT Front Hero
 * Description: Rotating front-page hero or carousel. Hero: the latest posts, newest first, as [tt_hero]. Carousel: the front page's first section as slide 1, then the newest posts. Settings: Udseende → Forsidens hero.
 * Version:     1.5.0
 * Author:      LMG / Code
 * Text Domain: tt-front-hero
 *
 * Why a plugin and not functions.php: traveltalk.dk runs the Kadence PARENT theme with no child
 * theme, so anything written into functions.php is destroyed by the next theme update.
 * A plugin survives updates and G can switch it off from wp-admin without a session.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TT_HERO_VERSION', '1.5.0' );
define( 'TT_HERO_POOL', 60 );

/* -------------------------------------------------------------------------
 * Settings
 *
 * One option per site, edited under Udseende → Forsidens hero. A Danish site gets
 * traveltalk.dk's values, so an upgrade there needs no configuration; any other
 * language gets neutral English ones.
 * ---------------------------------------------------------------------- */

/**
 * Default settings.
 *
 * dest_root: the geographic container (Rejsemål, 52). Continents are its CHILDREN, so
 * the region column keys on the child of this term. 0 = no destination tree.
 * exclude:   agency cards (Rejsebureauer, 3069) publish in bursts and would otherwise
 * take hero slots. Also filterable: add_filter( 'tt_hero_excluded_cats', ... ).
 *
 * @return array
 */
function tt_hero_defaults() {
	if ( 0 === strpos( get_locale(), 'da' ) ) {
		return array(
			'limit'       => 5,
			'interval'    => 5,
			'stem'        => 'Rejser med sjæl',
			'exclude'     => array( 3069 ),
			'dest_root'   => 52,
			'video_path'  => 'rejsefilm',
			'video_label' => 'Rejsedrømme lever her',
			'auto'        => 0,
			'replace'     => 0,
			'mode'        => 'hero',
		);
	}

	// Any other site (traveltalk.travel …): no traveltalk.dk category IDs or Danish copy.
	return array(
		'limit'       => 5,
		'interval'    => 5,
		'stem'        => 'Travel with soul',
		'exclude'     => array(),
		'dest_root'   => 0,
		'video_path'  => '',
		'video_label' => 'Travel films',
		'auto'        => 1,
		'replace'     => 1,
		'mode'        => 'hero',
	);
}

/* -------------------------------------------------------------------------
 * First install (1.4.0)
 *
 * A site that has never saved settings gets the carousel, switched OFF: nothing changes
 * on the front page until someone ticks "Placér automatisk". Sites that already run the
 * hero (traveltalk.dk, traveltalk.travel) are updated, not activated, so this never runs
 * there; and it never overwrites settings that exist.
 * ---------------------------------------------------------------------- */

register_activation_hook(
	__FILE__,
	function () {
		if ( false !== get_option( 'tt_hero_settings', false ) ) {
			return;
		}
		add_option(
			'tt_hero_settings',
			array_merge(
				tt_hero_defaults(),
				array(
					'mode'     => 'carousel',
					'limit'    => 4,
					'interval' => 6,
					'auto'     => 0,
					'replace'  => 0,
				)
			)
		);
	}
);

/**
 * Carousel mode: the page's own first section stays as slide 1, posts follow.
 *
 * @return bool
 */
function tt_hero_is_carousel() {
	return 'carousel' === tt_hero_opt( 'mode' );
}

/**
 * A setting, falling back to its default.
 *
 * @param string $key Setting.
 * @return mixed
 */
function tt_hero_opt( $key ) {
	$opts = wp_parse_args( (array) get_option( 'tt_hero_settings', array() ), tt_hero_defaults() );
	return $opts[ $key ];
}

/* -------------------------------------------------------------------------
 * Selection
 * ---------------------------------------------------------------------- */

/**
 * The region a post counts as, for the spread rule.
 *
 * Prefers a term that sits under Rejsemål and returns that term's continent-level
 * ancestor (Europa, Asien, Afrika …). Falls back to the top-level ancestor of the
 * first category for non-destination posts (Rejsetrends, Flyselskaber …).
 *
 * @param int $post_id Post.
 * @return int Term ID, or 0 when the post has no category.
 */
function tt_hero_region( $post_id ) {
	$cats = get_the_category( $post_id );
	if ( empty( $cats ) ) {
		return 0;
	}

	$fallback = 0;

	foreach ( $cats as $cat ) {
		$chain = array_reverse( get_ancestors( $cat->term_id, 'category', 'taxonomy' ) ); // top-most first
		$chain[] = $cat->term_id;

		$pos = array_search( (int) tt_hero_opt( 'dest_root' ), $chain, true );
		if ( false !== $pos ) {
			// The term directly below Rejsemål is the continent. If the post is filed on
			// Rejsemål itself, treat Rejsemål as the region.
			return isset( $chain[ $pos + 1 ] ) ? (int) $chain[ $pos + 1 ] : (int) tt_hero_opt( 'dest_root' );
		}

		if ( ! $fallback ) {
			$fallback = (int) $chain[0];
		}
	}

	return $fallback;
}

/**
 * Categories a hero candidate may not belong to.
 *
 * @return int[]
 */
function tt_hero_excluded_cats() {
	return array_map( 'intval', (array) apply_filters( 'tt_hero_excluded_cats', tt_hero_opt( 'exclude' ) ) );
}

/**
 * Candidate pool: recent published posts with a featured image, minus excluded categories.
 *
 * @return int[] Post IDs, newest first.
 */
function tt_hero_pool() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}

	$posts = get_posts(
		array(
			'numberposts'      => TT_HERO_POOL,
			'post_status'      => 'publish',
			'orderby'          => 'date',
			'order'            => 'DESC',
			'meta_key'         => '_thumbnail_id', // phpcs:ignore WordPress.DB.SlowDBQuery
			'category__not_in' => tt_hero_excluded_cats(),
			'fields'           => 'ids',
			'suppress_filters' => false,
		)
	);

	$cache = array_values(
		array_filter(
			$posts,
			function ( $id ) {
				return has_post_thumbnail( $id );
			}
		)
	);

	return $cache;
}

/**
 * The slides: the latest posts, newest first. No stored set — freshness follows publishing.
 * A sticky post (Fastgør øverst på bloggen) goes first.
 *
 * @return int[]
 */
function tt_hero_pick() {
	$pool   = tt_hero_pool();
	$sticky = array_map( 'intval', (array) get_option( 'sticky_posts', array() ) );
	$lead   = array_values( array_intersect( $pool, $sticky ) );
	$ids    = array_values( array_unique( array_merge( $lead, $pool ) ) );

	return array_map( 'intval', array_slice( $ids, 0, (int) tt_hero_opt( 'limit' ) ) );
}

/* -------------------------------------------------------------------------
 * The headline tail
 * ---------------------------------------------------------------------- */

/**
 * The moving tail of the headline — the whole phrase including its preposition
 * ("i Italien", "på Bali", "på krydstogt"). Per-post override wins; otherwise the
 * most specific category that carries one.
 *
 * @param int $post_id Post.
 * @return string
 */
function tt_hero_tail( $post_id ) {
	$own = get_post_meta( $post_id, 'hero_tail', true );
	if ( $own ) {
		return $own;
	}

	$best  = '';
	$depth = -1;

	foreach ( get_the_category( $post_id ) as $cat ) {
		$tail = get_term_meta( $cat->term_id, 'hero_tail', true );
		if ( ! $tail ) {
			continue;
		}
		$d = count( get_ancestors( $cat->term_id, 'category', 'taxonomy' ) );
		if ( $d > $depth ) {
			$best  = $tail;
			$depth = $d;
		}
	}

	return $best;
}

/**
 * The assembled H1 for a post.
 *
 * @param int $post_id Post.
 * @return string
 */
function tt_hero_headline( $post_id ) {
	$stem = apply_filters( 'tt_hero_stem', tt_hero_opt( 'stem' ) );
	$tail = tt_hero_tail( $post_id );

	if ( ! $stem ) {
		return $tail ? $tail : get_the_title( $post_id );
	}

	return $tail ? $stem . ' — ' . $tail : $stem;
}

/* term meta field on the category screens */
foreach ( array( 'category_add_form_fields', 'category_edit_form_fields' ) as $tt_hero_hook ) {
	add_action(
		$tt_hero_hook,
		function ( $term ) {
			$val = is_object( $term ) ? get_term_meta( $term->term_id, 'hero_tail', true ) : '';
			$row = is_object( $term );

			echo $row ? '<tr class="form-field"><th scope="row">' : '<div class="form-field">';
			echo '<label for="hero_tail">Hero-hale</label>';
			echo $row ? '</th><td>' : '';
			echo '<input name="hero_tail" id="hero_tail" type="text" value="' . esc_attr( $val ) . '">';
			echo '<p class="description">Hele frasen med forholdsord — fx <code>i Italien</code>, '
				. '<code>på Bali</code>, <code>på krydstogt</code>. Tom = ingen hale.</p>';
			echo $row ? '</td></tr>' : '</div>';
		}
	);
}

foreach ( array( 'created_category', 'edited_category' ) as $tt_hero_hook ) {
	add_action(
		$tt_hero_hook,
		function ( $term_id ) {
			if ( ! current_user_can( 'manage_categories' ) ) {
				return;
			}
			if ( isset( $_POST['hero_tail'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				update_term_meta( $term_id, 'hero_tail', sanitize_text_field( wp_unslash( $_POST['hero_tail'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification
			}
		}
	);
}
unset( $tt_hero_hook );

/* -------------------------------------------------------------------------
 * Render
 * ---------------------------------------------------------------------- */

/**
 * Is the video library live yet? The corner link must never point at a 404.
 *
 * @return string URL, or '' when the page does not exist.
 */
function tt_hero_video_url() {
	$path = tt_hero_opt( 'video_path' );
	if ( ! $path ) {
		return '';
	}

	$page = get_page_by_path( $path );

	if ( $page && 'publish' === $page->post_status ) {
		return get_permalink( $page );
	}

	return '';
}

/**
 * Category links above the headline, as in the post hero (1.5.0).
 *
 * @param int $post_id Post.
 * @return string
 */
function tt_hero_cats( $post_id ) {
	$skip  = array_merge( tt_hero_excluded_cats(), array( (int) get_option( 'default_category' ) ) );
	$links = array();

	foreach ( (array) get_the_category( $post_id ) as $cat ) {
		if ( in_array( (int) $cat->term_id, $skip, true ) ) {
			continue;
		}
		$links[] = '<a href="' . esc_url( get_category_link( $cat ) ) . '" rel="tag">' . esc_html( $cat->name ) . '</a>';
		if ( count( $links ) >= (int) apply_filters( 'tt_hero_max_cats', 3 ) ) {
			break;
		}
	}

	return $links ? '<div class="tt-hero__cats">' . implode( '<span aria-hidden="true"> | </span>', $links ) . '</div>' : '';
}

/**
 * The hero.
 *
 * @return string
 */
function tt_hero_render() {
	$ids = tt_hero_pick();
	if ( empty( $ids ) ) {
		return '';
	}

	wp_enqueue_style( 'tt-front-hero' );
	wp_enqueue_script( 'tt-front-hero' );

	$out   = '<div class="tt-hero" data-tt-hero data-tt-interval="' . esc_attr( (int) tt_hero_opt( 'interval' ) ) . '">';
	$index = 0;

	foreach ( $ids as $id ) {
		$thumb_id = get_post_thumbnail_id( $id );
		if ( ! $thumb_id ) {
			continue;
		}

		$first = ( 0 === $index );

		$link = esc_url( get_permalink( $id ) );

		/* 1.5.0: the slide is a box, not one link, so the categories can be links of their own.
		 * The picture is a link too (out of the tab order), so a tap anywhere still opens the post. */
		$out .= sprintf(
			'<div class="tt-hero__slide%1$s" data-pos="%2$d" data-id="%3$d"%4$s>',
			$first ? ' is-active' : '',
			$index + 1,
			(int) $id,
			$first ? '' : ' inert'
		);
		$out .= '<a class="tt-hero__media" href="' . $link . '" tabindex="-1" aria-hidden="true">';

		/* wp_get_attachment_image gives srcset + sizes off the full size, so the browser
		 * downloads a width that fits the device. A bare full-size <img> would put a
		 * desktop-width JPEG on every phone and cost the page its LCP. */
		$out .= wp_get_attachment_image(
			$thumb_id,
			'full',
			false,
			array(
				'class'         => 'tt-hero__img',
				'decoding'      => 'async',
				'sizes'         => '100vw',
				'loading'       => $first ? 'eager' : 'lazy',
				'fetchpriority' => $first ? 'high' : 'low',
			)
		);

		$out .= '</a>';

		$tag  = $first ? 'h1' : 'h2';
		$out .= '<div class="tt-hero__text">';
		$out .= '<' . $tag . ' class="tt-hero__h1">' . esc_html( tt_hero_headline( $id ) ) . '</' . $tag . '>';
		$out .= tt_hero_cats( $id );
		$out .= '<h2 class="tt-hero__title"><a href="' . $link . '">' . esc_html( get_the_title( $id ) ) . '</a></h2>';
		$out .= '</div></div>';

		$index++;
	}

	$video = tt_hero_video_url();
	if ( $video ) {
		$out .= '<a class="tt-hero__video" href="' . esc_url( $video ) . '">'
			. '<span aria-hidden="true">&#9654;</span> ' . esc_html( tt_hero_opt( 'video_label' ) ) . '</a>';
	}

	$out .= '</div>';

	return $out;
}
add_shortcode( 'tt_hero', 'tt_hero_render' );

/**
 * The carousel (1.4.0): the page's first section as slide 1, then the newest posts.
 *
 * Posts come from the pool (featured image required), so a post without a picture is
 * skipped and the next one fills in. A picture that will not render is skipped the same way.
 *
 * @param string $first Block markup of the page's first section, still unrendered.
 * @return string Markup for the_content; the first section is rendered by do_blocks as before.
 */
function tt_hero_carousel( $first ) {
	$want   = (int) tt_hero_opt( 'limit' );
	$sticky = array_map( 'intval', (array) get_option( 'sticky_posts', array() ) );
	$pool   = tt_hero_pool();
	$ids    = array_values( array_unique( array_merge( array_values( array_intersect( $pool, $sticky ) ), $pool ) ) );
	$slides = array();

	foreach ( $ids as $id ) {
		if ( count( $slides ) >= $want ) {
			break;
		}
		$img = wp_get_attachment_image(
			get_post_thumbnail_id( $id ),
			'full',
			false,
			array(
				'class'         => 'tt-hero__img',
				'decoding'      => 'async',
				'sizes'         => '100vw',
				'loading'       => 'lazy',
				'fetchpriority' => 'low',
				'alt'           => '',
			)
		);
		if ( ! $img ) {
			continue;
		}
		$slides[] = array( $id, $img );
	}

	if ( ! $slides ) {
		return $first;
	}

	wp_enqueue_style( 'tt-front-hero' );
	wp_enqueue_script( 'tt-front-hero' );

	$total = count( $slides ) + 1;
	$t     = 0 !== strpos( get_locale(), 'da' )
		? array( 'region' => 'Featured', 'prev' => 'Previous slide', 'next' => 'Next slide', 'go' => 'Show slide %1$d of %2$d' )
		: array( 'region' => 'Udvalgt', 'prev' => 'Forrige', 'next' => 'Næste', 'go' => 'Vis slide %1$d af %2$d' );

	$out  = '<div class="tt-hero tt-hero--carousel alignfull" data-tt-hero data-tt-carousel data-tt-interval="' . esc_attr( (int) tt_hero_opt( 'interval' ) ) . '"'
		. ' role="region" aria-roledescription="carousel" aria-label="' . esc_attr( $t['region'] ) . '">';
	$out .= '<div class="tt-hero__slide tt-hero__slide--page is-active" data-pos="1" role="group" aria-roledescription="slide" aria-label="1 / ' . $total . '">'
		. "\n" . $first . "\n" . '</div>';

	foreach ( $slides as $n => $slide ) {
		list( $id, $img ) = $slide;
		$pos  = $n + 2;
		$out .= sprintf(
			'<a class="tt-hero__slide" href="%1$s" data-pos="%2$d" data-id="%3$d" role="group" aria-roledescription="slide" aria-label="%2$d / %4$d">',
			esc_url( get_permalink( $id ) ),
			$pos,
			(int) $id,
			$total
		);
		$out .= $img;
		$out .= '<span class="tt-hero__text"><h2 class="tt-hero__h1">' . esc_html( get_the_title( $id ) ) . '</h2></span></a>';
	}

	$out .= '<button type="button" class="tt-hero__arrow tt-hero__arrow--prev" data-tt-step="-1" aria-label="' . esc_attr( $t['prev'] ) . '"><span aria-hidden="true">&#8249;</span></button>';
	$out .= '<button type="button" class="tt-hero__arrow tt-hero__arrow--next" data-tt-step="1" aria-label="' . esc_attr( $t['next'] ) . '"><span aria-hidden="true">&#8250;</span></button>';
	$out .= '<div class="tt-hero__dots">';
	for ( $i = 1; $i <= $total; $i++ ) {
		$out .= '<button type="button" class="tt-hero__dot' . ( 1 === $i ? ' is-active' : '' ) . '" data-tt-go="' . $i . '"'
			. ' aria-label="' . esc_attr( sprintf( $t['go'], $i, $total ) ) . '"' . ( 1 === $i ? ' aria-current="true"' : '' ) . '></button>';
	}
	$out .= '</div></div>';

	return $out;
}

/* -------------------------------------------------------------------------
 * Automatic placement
 *
 * With 'auto' on, the hero goes on top of the front page without editing it. With
 * 'replace' on, it takes the place of the page's first section (a welcome row).
 * Runs before do_blocks (priority 9) on the raw block markup; a page that already
 * carries [tt_hero] is left alone.
 * ---------------------------------------------------------------------- */

add_filter(
	'the_content',
	function ( $content ) {
		if ( ! tt_hero_opt( 'auto' ) || ! is_front_page() || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}
		if ( has_shortcode( $content, 'tt_hero' ) ) {
			return $content;
		}

		if ( tt_hero_is_carousel() ) {
			// The first section moves, unchanged, into slide 1. Without blocks there is no
			// first section to keep, so the page is left as it is.
			if ( ! has_blocks( $content ) ) {
				return $content;
			}
			$blocks = parse_blocks( $content );
			foreach ( $blocks as $i => $block ) {
				if ( null === $block['blockName'] && '' === trim( $block['innerHTML'] ) ) {
					continue;
				}
				$first = serialize_block( $block );
				unset( $blocks[ $i ] );
				return tt_hero_carousel( $first ) . "\n\n" . serialize_blocks( array_values( $blocks ) );
			}
			return $content;
		}

		$hero = "<!-- wp:shortcode -->\n[tt_hero]\n<!-- /wp:shortcode -->\n\n";

		if ( ! tt_hero_opt( 'replace' ) || ! has_blocks( $content ) ) {
			return $hero . $content;
		}

		$blocks = parse_blocks( $content );
		foreach ( $blocks as $i => $block ) {
			// Skip the whitespace between blocks; drop the first real one.
			if ( null === $block['blockName'] && '' === trim( $block['innerHTML'] ) ) {
				continue;
			}
			unset( $blocks[ $i ] );
			break;
		}

		return $hero . serialize_blocks( array_values( $blocks ) );
	},
	8
);

/* -------------------------------------------------------------------------
 * Layout rules in the page head (1.3.1)
 *
 * LiteSpeed loads the stylesheets after first paint. Until hero.css arrived, the five
 * slides stood stacked at full picture height and then collapsed into the 4:3 box:
 * PageSpeed counted that as a layout shift of 0.41. These few rules give the box its
 * final size from the first paint. Marked so LiteSpeed leaves them in place.
 * ---------------------------------------------------------------------- */

add_action(
	'wp_head',
	function () {
		if ( ! is_front_page() ) {
			return;
		}
		echo '<style id="tt-hero-critical" data-no-optimize="1" data-no-defer="1" data-no-minify="1">'
			. '.tt-hero{position:relative;width:100%;aspect-ratio:16/7;overflow:hidden;background:#0d1b1e}'
			. '@media (max-width:768px){.tt-hero{aspect-ratio:4/3}}'
			. '.tt-hero__slide{position:absolute;inset:0;display:block;opacity:0}'
			. '.tt-hero__slide.is-active{opacity:1}'
			. '.tt-hero__slide picture{display:block;position:absolute;inset:0}'
			. '.tt-hero__slide img,.tt-hero .tt-hero__img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;max-width:none}'
			. '.tt-hero__text{position:absolute;left:0;bottom:0;z-index:2}'
			/* 1.4.0 carousel: slide 1 is the page's own section and sets the height, so the
			 * box is exactly as tall as that section is today; the post slides lie on top. */
			. '.tt-hero--carousel{aspect-ratio:auto;background:none}'
			. '.tt-hero--carousel>.tt-hero__slide--page{position:relative;inset:auto}'
			. '.tt-hero--carousel>.tt-hero__slide:not(.is-active){visibility:hidden}'
			. '.tt-hero__arrow,.tt-hero__dots{position:absolute;z-index:5}'
			. '</style>' . "\n";
	},
	5
);

/* -------------------------------------------------------------------------
 * Assets
 * ---------------------------------------------------------------------- */

add_action(
	'wp_enqueue_scripts',
	function () {
		$dir = plugin_dir_path( __FILE__ );
		$url = plugin_dir_url( __FILE__ );

		wp_register_style(
			'tt-front-hero',
			$url . 'assets/hero.css',
			array(),
			file_exists( $dir . 'assets/hero.css' ) ? filemtime( $dir . 'assets/hero.css' ) : TT_HERO_VERSION
		);

		/* 1.5.0: post heroes share the front hero's headline size and thumb-sized category links. */
		if ( is_singular( 'post' ) && apply_filters( 'tt_hero_style_post_hero', true ) ) {
			wp_enqueue_style(
				'tt-post-hero',
				$url . 'assets/post-hero.css',
				array(),
				file_exists( $dir . 'assets/post-hero.css' ) ? filemtime( $dir . 'assets/post-hero.css' ) : TT_HERO_VERSION
			);
		}

		wp_register_script(
			'tt-front-hero',
			$url . 'assets/hero.js',
			array(),
			file_exists( $dir . 'assets/hero.js' ) ? filemtime( $dir . 'assets/hero.js' ) : TT_HERO_VERSION,
			true
		);
	}
);

/* -------------------------------------------------------------------------
 * Keep the hero's picks out of the grid below it
 *
 * "Seneste rejsenyt" is a Kadence posts BLOCK, not the main loop, so pre_get_posts
 * never sees it. Kadence exposes kadence_blocks_posts_query_args for exactly this.
 * The curated "Forsiden" block (tag 3068, three posts) is left alone — excluding
 * there could empty it.
 * ---------------------------------------------------------------------- */

add_filter(
	'kadence_blocks_posts_query_args',
	function ( $args ) {
		if ( is_admin() || ! is_front_page() || tt_hero_is_carousel() ) {
			return $args;
		}

		// Leave curated/tag-filtered blocks untouched.
		if ( ! empty( $args['tag__in'] ) || ! empty( $args['tag_slug__in'] ) || ! empty( $args['tax_query'] ) ) {
			return $args;
		}

		$ids = tt_hero_pick();
		if ( ! $ids ) {
			return $args;
		}

		$existing            = isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : array();
		$args['post__not_in'] = array_values( array_unique( array_merge( $existing, $ids ) ) );

		return $args;
	}
);

require_once plugin_dir_path( __FILE__ ) . 'admin.php';
require_once plugin_dir_path( __FILE__ ) . 'notes.php';
