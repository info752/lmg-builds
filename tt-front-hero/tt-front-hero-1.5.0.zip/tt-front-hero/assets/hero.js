/* TT Front Hero — crossfade + GA4 click instrumentation. No dependencies. */
(function () {
  var root = document.querySelector('[data-tt-hero]');
  if (!root) return;
  if (root.hasAttribute('data-tt-carousel')) return carousel(root);

  var slides = root.querySelectorAll('.tt-hero__slide');
  if (slides.length < 2) return;

  /* 1.5.0: a slide holds several links (picture, headline, categories); count each click. */
  root.addEventListener('click', function (e) {
    var a = e.target.closest('a'), s = a && a.closest('.tt-hero__slide');
    if (s && typeof gtag === 'function') {
      gtag('event', 'hero_click', {
        slide_position: s.dataset.pos,
        post_id: s.dataset.id,
        link_url: a.getAttribute('href'),
        link_kind: a.closest('.tt-hero__cats') ? 'category' : 'post'
      });
    }
  });

  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  var i = 0, timer = null;
  var delay = (parseInt(root.getAttribute('data-tt-interval'), 10) || 5) * 1000;

  function show(n) {
    slides[i].classList.remove('is-active');
    slides[i].setAttribute('inert', '');
    i = n % slides.length;
    slides[i].classList.add('is-active');
    slides[i].removeAttribute('inert');
  }
  function start() { if (!timer) timer = setInterval(function () { show(i + 1); }, delay); }
  function stop() { clearInterval(timer); timer = null; }

  root.addEventListener('focusin', stop);
  document.addEventListener('visibilitychange', function () {
    document.hidden ? stop() : start();
  });

  start();

  /* 1.4.0 carousel: slide 1 is the page's own first section. Arrows and dots are buttons,
   * so they work by keyboard. No pause on mouse hover; rotation pauses while keyboard focus
   * is inside a slide or the tab is hidden, and never runs with reduced motion. */
  function carousel(root) {
    var slides = root.querySelectorAll(':scope > .tt-hero__slide');
    var dots = root.querySelectorAll('.tt-hero__dot');
    if (slides.length < 2) return;

    var i = 0, timer = null, held = false;
    var still = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var delay = (parseInt(root.getAttribute('data-tt-interval'), 10) || 6) * 1000;

    function show(n) {
      n = (n + slides.length) % slides.length;
      if (n === i) return;
      slides[i].classList.remove('is-active');
      if (dots[i]) { dots[i].classList.remove('is-active'); dots[i].removeAttribute('aria-current'); }
      i = n;
      slides[i].classList.add('is-active');
      if (dots[i]) { dots[i].classList.add('is-active'); dots[i].setAttribute('aria-current', 'true'); }
    }
    function stop() { clearInterval(timer); timer = null; }
    function start() {
      stop();
      if (!still && !held && !document.hidden) timer = setInterval(function () { show(i + 1); }, delay);
    }

    root.addEventListener('click', function (e) {
      var b = e.target.closest('[data-tt-step],[data-tt-go]');
      if (b) {
        if (b.hasAttribute('data-tt-step')) show(i + parseInt(b.getAttribute('data-tt-step'), 10));
        else show(parseInt(b.getAttribute('data-tt-go'), 10) - 1);
        start();
        return;
      }
      var s = e.target.closest('a.tt-hero__slide');
      if (s && typeof gtag === 'function') {
        gtag('event', 'hero_click', { slide_position: s.dataset.pos, post_id: s.dataset.id, link_url: s.getAttribute('href') });
      }
    });
    root.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
        if (!e.target.closest('.tt-hero__arrow,.tt-hero__dots')) return;
        show(i + (e.key === 'ArrowRight' ? 1 : -1));
        start();
      }
    });
    root.addEventListener('focusin', function (e) {
      if (e.target.closest('.tt-hero__slide')) { held = true; stop(); }
    });
    root.addEventListener('focusout', function (e) {
      if (!root.contains(e.relatedTarget) || !e.relatedTarget.closest('.tt-hero__slide')) { held = false; start(); }
    });
    document.addEventListener('visibilitychange', start);

    start();
  }
})();
