<?php
/**
 * Plugin Name: LMG Publishing Stats
 * Description: Per-site publishing overview — post counts (incl. LMG Translator translations), draft queue, bot cron status. Works on any LMG WordPress site.
 * Version: 1.1
 * Author: LMG / Claude Code
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── Admin menu page ──────────────────────────────────────────────────────────
add_action( 'admin_menu', function () {
    add_menu_page(
        'Publishing Stats',
        'Publishing',
        'edit_posts',
        'lmg-publishing-stats',
        'lmg_ps_render_page',
        'dashicons-chart-bar',
        85
    );
} );

// ── Dashboard widget ─────────────────────────────────────────────────────────
add_action( 'wp_dashboard_setup', function () {
    wp_add_dashboard_widget(
        'lmg_publishing_widget',
        'Publishing Overview',
        'lmg_ps_dashboard_widget'
    );
} );

// ── Helpers ──────────────────────────────────────────────────────────────────

/** 1.1: LMG Translator's translations (post type lmgt_translation) count as published content. */
function lmg_ps_translation_type() {
    return post_type_exists( 'lmgt_translation' ) ? 'lmgt_translation' : '';
}

function lmg_ps_types() {
    $t = [ 'post' ];
    if ( lmg_ps_translation_type() ) $t[] = lmg_ps_translation_type();
    return (array) apply_filters( 'lmg_ps_post_types', $t );
}

function lmg_ps_types_sql( $types = null ) {
    $types = $types === null ? lmg_ps_types() : (array) $types;
    return "'" . implode( "','", array_map( 'esc_sql', $types ) ) . "'";
}

/** Cut-off in site time, same clock as post_date. */
function lmg_ps_after( $days ) {
    return date( 'Y-m-d H:i:s', current_time( 'timestamp' ) - (int) $days * DAY_IN_SECONDS );
}

function lmg_ps_count_posts( $status = 'publish', $days = null, $types = null ) {
    global $wpdb;
    $in = lmg_ps_types_sql( $types );
    if ( $days ) {
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts}
             WHERE post_type IN ($in) AND post_status=%s AND post_date >= %s",
            $status, lmg_ps_after( $days )
        ) );
    }
    return (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->posts}
         WHERE post_type IN ($in) AND post_status=%s",
        $status
    ) );
}

/** Translations only (0 where LMG Translator isn't installed). */
function lmg_ps_count_translations( $status = 'publish', $days = null ) {
    $t = lmg_ps_translation_type();
    return $t ? lmg_ps_count_posts( $status, $days, [ $t ] ) : 0;
}

/** Published translations per language in the last $days, e.g. [ 'en' => 12, 'de' => 4 ]. */
function lmg_ps_translation_langs( $days = 30 ) {
    global $wpdb;
    $t = lmg_ps_translation_type();
    if ( ! $t ) return [];
    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT COALESCE(m.meta_value,'?') AS lang, COUNT(*) AS n
         FROM {$wpdb->posts} p
         LEFT JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_lmgt_lang'
         WHERE p.post_type = %s AND p.post_status = 'publish' AND p.post_date >= %s
         GROUP BY lang ORDER BY n DESC",
        $t, lmg_ps_after( $days )
    ) );
    $out = [];
    foreach ( (array) $rows as $r ) $out[ $r->lang ] = (int) $r->n;
    return $out;
}

function lmg_ps_lang_tag( $post ) {
    if ( ! $post || $post->post_type !== lmg_ps_translation_type() ) return '';
    $l = (string) get_post_meta( $post->ID, '_lmgt_lang', true );
    return $l !== '' ? ' [' . strtoupper( $l ) . ']' : ' [translation]';
}

function lmg_ps_last_published() {
    $p = get_posts( [
        'numberposts'      => 1,
        'post_type'        => lmg_ps_types(),
        'post_status'      => 'publish',
        'orderby'          => 'date',
        'order'            => 'DESC',
        'suppress_filters' => true,
    ] );
    return $p ? $p[0] : null;
}

function lmg_ps_monthly_counts( $months = 6 ) {
    global $wpdb;
    $in     = lmg_ps_types_sql();
    $months = (int) $months;
    $rows = $wpdb->get_results(
        "SELECT DATE_FORMAT(post_date,'%Y-%m') AS ym, COUNT(*) AS n
         FROM {$wpdb->posts}
         WHERE post_type IN ($in) AND post_status='publish'
           AND post_date >= DATE_SUB(NOW(), INTERVAL {$months} MONTH)
         GROUP BY ym ORDER BY ym ASC"
    );
    $out = [];
    foreach ( $rows as $r ) $out[ $r->ym ] = (int) $r->n;
    return $out;
}

function lmg_ps_category_counts( $days = 30, $limit = 6 ) {
    global $wpdb;
    $after = date( 'Y-m-d', strtotime( "-{$days} days" ) );
    return $wpdb->get_results( $wpdb->prepare(
        "SELECT t.name, COUNT(tr.object_id) AS n
         FROM {$wpdb->term_relationships} tr
         JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
         JOIN {$wpdb->terms} t ON t.term_id = tt.term_id
         JOIN {$wpdb->posts} p ON p.ID = tr.object_id
         WHERE tt.taxonomy = 'category'
           AND p.post_type = 'post'
           AND p.post_status = 'publish'
           AND p.post_date >= %s
         GROUP BY t.term_id
         ORDER BY n DESC
         LIMIT %d",
        $after, $limit
    ) );
}

/**
 * Known LMG bot cron hooks + friendly labels.
 * Add new hooks here as new bots come online.
 */
function lmg_ps_known_crons() {
    return [
        'ttt_bot_daily_run'       => 'TravelTalk.travel bot (daily)',
        'wst_bot_daily_run'       => 'WorldSportTalk bot (daily)',
        'leisureintel_weekly_run' => 'LeisureIntel analysis (weekly)',
        'leisureintel_weekly_audit'=> 'LeisureIntel audit (weekly)',
        'tt_dk_bot_daily_run'     => 'TravelTalk.dk bot (daily)',
    ];
}

function lmg_ps_cron_rows() {
    $hooks  = lmg_ps_known_crons();
    $active = [];
    foreach ( $hooks as $hook => $label ) {
        $next = wp_next_scheduled( $hook );
        if ( $next !== false ) {
            $active[] = [ 'label' => $label, 'next' => $next ];
        }
    }
    return $active;
}

function lmg_ps_recent_posts( $n = 8 ) {
    return get_posts( [
        'numberposts'      => $n,
        'post_type'        => lmg_ps_types(),
        'post_status'      => [ 'publish', 'draft' ],
        'orderby'          => 'date',
        'order'            => 'DESC',
        'suppress_filters' => true,
    ] );
}

// ── Dashboard widget (compact) ───────────────────────────────────────────────
function lmg_ps_dashboard_widget() {
    $pub_today  = lmg_ps_count_posts( 'publish', 1 );
    $pub_7d     = lmg_ps_count_posts( 'publish', 7 );
    $pub_30d    = lmg_ps_count_posts( 'publish', 30 );
    $drafts     = lmg_ps_count_posts( 'draft', null, [ 'post' ] );
    $tr_drafts  = lmg_ps_count_translations( 'draft' );
    $tr_on      = (bool) lmg_ps_translation_type();
    $tr_7d      = lmg_ps_count_translations( 'publish', 7 );
    $tr_30d     = lmg_ps_count_translations( 'publish', 30 );
    $tr_langs   = lmg_ps_translation_langs( 30 );
    $last       = lmg_ps_last_published();
    $crons      = lmg_ps_cron_rows();
    ?>
    <style>
    .lmg-widget-grid { display:flex; gap:12px; margin-bottom:12px; flex-wrap:wrap; }
    .lmg-widget-stat { background:#f6f7f7; border:1px solid #dde; border-radius:6px; padding:10px 14px; text-align:center; flex:1; min-width:70px; }
    .lmg-widget-stat .n { font-size:1.8em; font-weight:700; color:#1d2327; line-height:1.1; }
    .lmg-widget-stat .l { font-size:.72em; color:#787c82; margin-top:2px; }
    .lmg-widget-last { font-size:.82em; color:#555; margin-bottom:8px; }
    .lmg-widget-crons { font-size:.78em; color:#555; }
    .lmg-widget-crons span { color:#2a6; font-weight:600; }
    .lmg-widget-link { font-size:.78em; float:right; margin-top:-4px; }
    </style>
    <a class="lmg-widget-link" href="<?php echo admin_url('admin.php?page=lmg-publishing-stats'); ?>">Full view →</a>
    <div class="lmg-widget-grid">
        <div class="lmg-widget-stat"><div class="n"><?php echo $pub_today; ?></div><div class="l">Today</div></div>
        <div class="lmg-widget-stat"><div class="n"><?php echo $pub_7d; ?></div><div class="l">7 days</div></div>
        <div class="lmg-widget-stat"><div class="n"><?php echo $pub_30d; ?></div><div class="l">30 days</div></div>
        <div class="lmg-widget-stat"><div class="n"><?php echo $drafts; ?></div><div class="l">Drafts<?php if ( $tr_drafts ) echo ' (+' . (int) $tr_drafts . ' translation drafts)'; ?></div></div>
    </div>
    <?php if ( $tr_on ) : ?>
    <div class="lmg-widget-last">
        Of these, translations: <strong><?php echo (int) $tr_7d; ?></strong> in 7 days, <strong><?php echo (int) $tr_30d; ?></strong> in 30 days<?php
        if ( $tr_langs ) {
            $bits = [];
            foreach ( $tr_langs as $l => $n ) $bits[] = esc_html( strtoupper( $l ) ) . ' ' . (int) $n;
            echo ' (' . implode( ', ', $bits ) . ')';
        } ?>
    </div>
    <?php endif; ?>
    <?php if ( $last ) : ?>
    <div class="lmg-widget-last">
        Last published: <strong><?php echo esc_html( $last->post_title . lmg_ps_lang_tag( $last ) ); ?></strong>
        — <?php echo human_time_diff( strtotime( $last->post_date ) ); ?> ago
    </div>
    <?php endif; ?>
    <?php if ( $crons ) : ?>
    <div class="lmg-widget-crons">
        <?php foreach ( $crons as $c ) : ?>
        <span>●</span> <?php echo esc_html( $c['label'] ); ?>
        — next <?php echo date( 'd M H:i', $c['next'] ); ?> UTC<br>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <?php
}

// ── Full admin page ──────────────────────────────────────────────────────────
function lmg_ps_render_page() {
    if ( ! current_user_can( 'edit_posts' ) ) return;

    $pub_today  = lmg_ps_count_posts( 'publish', 1 );
    $pub_7d     = lmg_ps_count_posts( 'publish', 7 );
    $pub_30d    = lmg_ps_count_posts( 'publish', 30 );
    $pub_total  = lmg_ps_count_posts( 'publish' );
    $drafts     = lmg_ps_count_posts( 'draft', null, [ 'post' ] );
    $tr_on      = (bool) lmg_ps_translation_type();
    $tr_30d     = lmg_ps_count_translations( 'publish', 30 );
    $tr_total   = lmg_ps_count_translations( 'publish' );
    $tr_drafts  = lmg_ps_count_translations( 'draft' );
    $tr_langs   = lmg_ps_translation_langs( 30 );
    $monthly    = lmg_ps_monthly_counts( 6 );
    $cats       = lmg_ps_category_counts( 30, 8 );
    $crons      = lmg_ps_cron_rows();
    $recent     = lmg_ps_recent_posts( 10 );

    $max_month  = $monthly ? max( array_values( $monthly ) ) : 1;
    ?>
    <div class="wrap">
    <h1 style="display:flex;align-items:center;gap:10px;">
        <span class="dashicons dashicons-chart-bar" style="font-size:1.4em;color:#1d2327;"></span>
        Publishing Overview — <?php echo esc_html( get_bloginfo('name') ); ?>
    </h1>

    <style>
    .lmg-ps-grid    { display:flex; gap:16px; flex-wrap:wrap; margin:20px 0 24px; }
    .lmg-ps-stat    { background:#fff; border:1px solid #c3c4c7; border-radius:8px; padding:18px 24px; flex:1; min-width:110px; box-shadow:0 1px 3px rgba(0,0,0,.06); }
    .lmg-ps-stat .n { font-size:2.4em; font-weight:700; color:#1d2327; line-height:1.1; }
    .lmg-ps-stat .l { font-size:.78em; color:#787c82; margin-top:4px; text-transform:uppercase; letter-spacing:.04em; }
    .lmg-ps-card    { background:#fff; border:1px solid #c3c4c7; border-radius:8px; padding:20px 24px; margin-bottom:20px; box-shadow:0 1px 3px rgba(0,0,0,.06); }
    .lmg-ps-card h2 { margin:0 0 16px; font-size:1em; text-transform:uppercase; letter-spacing:.05em; color:#787c82; border-bottom:1px solid #eee; padding-bottom:10px; }
    .lmg-ps-bar-row { display:flex; align-items:center; gap:10px; margin-bottom:8px; font-size:.88em; }
    .lmg-ps-bar-row .ym  { width:56px; color:#444; }
    .lmg-ps-bar-row .bar { height:18px; background:#2271b1; border-radius:3px; min-width:2px; transition:width .3s; }
    .lmg-ps-bar-row .cnt { color:#666; min-width:28px; }
    .lmg-ps-two-col { display:flex; gap:20px; flex-wrap:wrap; }
    .lmg-ps-two-col .lmg-ps-card { flex:1; min-width:280px; }
    table.lmg-ps-table { width:100%; border-collapse:collapse; font-size:.88em; }
    table.lmg-ps-table th { text-align:left; font-weight:600; color:#444; border-bottom:2px solid #eee; padding:6px 10px 6px 0; }
    table.lmg-ps-table td { padding:7px 10px 7px 0; border-bottom:1px solid #f0f0f0; vertical-align:top; }
    table.lmg-ps-table tr:last-child td { border-bottom:none; }
    .lmg-badge-pub  { display:inline-block; background:#d1fadf; color:#166534; border-radius:4px; padding:1px 7px; font-size:.78em; }
    .lmg-badge-draft{ display:inline-block; background:#fef9c3; color:#854d0e; border-radius:4px; padding:1px 7px; font-size:.78em; }
    .lmg-cron-row   { display:flex; align-items:center; gap:10px; margin-bottom:8px; font-size:.88em; }
    .lmg-cron-dot   { width:8px; height:8px; border-radius:50%; background:#22c55e; flex-shrink:0; }
    .lmg-cron-label { flex:1; color:#333; }
    .lmg-cron-next  { color:#666; font-size:.85em; }
    </style>

    <!-- Summary stats row -->
    <div class="lmg-ps-grid">
        <div class="lmg-ps-stat"><div class="n"><?php echo $pub_today; ?></div><div class="l">Published today</div></div>
        <div class="lmg-ps-stat"><div class="n"><?php echo $pub_7d; ?></div><div class="l">Last 7 days</div></div>
        <div class="lmg-ps-stat"><div class="n"><?php echo $pub_30d; ?></div><div class="l">Last 30 days</div></div>
        <div class="lmg-ps-stat"><div class="n"><?php echo number_format($pub_total); ?></div><div class="l">Total published</div></div>
        <div class="lmg-ps-stat"><div class="n"><?php echo $drafts; ?></div><div class="l">Drafts in queue</div></div>
    </div>
    <?php if ( $tr_on ) : ?>
    <p style="margin:-10px 0 20px;color:#555;">Counts include LMG Translator translations: <?php echo (int) $tr_30d; ?> in the last 30 days, <?php echo number_format( $tr_total ); ?> in total. Translation drafts (not counted above): <?php echo (int) $tr_drafts; ?>.</p>
    <?php endif; ?>

    <?php if ( $tr_langs ) : ?>
    <div class="lmg-ps-card">
        <h2>Translations published — last 30 days, by language</h2>
        <table class="lmg-ps-table">
            <tr><th>Language</th><th>Published</th></tr>
            <?php foreach ( $tr_langs as $l => $n ) : ?>
            <tr><td><?php echo esc_html( strtoupper( $l ) ); ?></td><td><?php echo (int) $n; ?></td></tr>
            <?php endforeach; ?>
        </table>
    </div>
    <?php endif; ?>

    <div class="lmg-ps-two-col">

        <!-- Monthly bar chart -->
        <div class="lmg-ps-card">
            <h2>Published per month</h2>
            <?php if ( $monthly ) : ?>
                <?php foreach ( $monthly as $ym => $cnt ) :
                    $pct = $max_month > 0 ? round( ( $cnt / $max_month ) * 260 ) : 0;
                ?>
                <div class="lmg-ps-bar-row">
                    <span class="ym"><?php echo esc_html( $ym ); ?></span>
                    <div class="bar" style="width:<?php echo $pct; ?>px;"></div>
                    <span class="cnt"><?php echo $cnt; ?></span>
                </div>
                <?php endforeach; ?>
            <?php else : ?>
                <p style="color:#888;font-size:.88em;">No published posts yet.</p>
            <?php endif; ?>
        </div>

        <!-- Top categories (last 30d) -->
        <div class="lmg-ps-card">
            <h2>Top categories — last 30 days</h2>
            <?php if ( $cats ) : ?>
            <table class="lmg-ps-table">
                <tr><th>Category</th><th>Posts</th></tr>
                <?php foreach ( $cats as $c ) : ?>
                <tr>
                    <td><?php echo esc_html( $c->name ); ?></td>
                    <td><?php echo (int) $c->n; ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
            <?php else : ?>
                <p style="color:#888;font-size:.88em;">No published posts in the last 30 days.</p>
            <?php endif; ?>
        </div>

    </div>

    <div class="lmg-ps-two-col">

        <!-- Recent activity -->
        <div class="lmg-ps-card">
            <h2>Recent posts (last 10)</h2>
            <table class="lmg-ps-table">
                <tr><th>Title</th><th>Status</th><th>Date</th></tr>
                <?php foreach ( $recent as $p ) :
                    $edit_url = get_edit_post_link( $p->ID );
                    $badge = $p->post_status === 'publish'
                        ? '<span class="lmg-badge-pub">published</span>'
                        : '<span class="lmg-badge-draft">draft</span>';
                ?>
                <tr>
                    <td><a href="<?php echo esc_url($edit_url); ?>"><?php echo esc_html( ( $p->post_title ?: '(no title)' ) . lmg_ps_lang_tag( $p ) ); ?></a></td>
                    <td><?php echo $badge; ?></td>
                    <td style="white-space:nowrap;color:#666;"><?php echo date( 'd M', strtotime($p->post_date) ); ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
            <p style="margin:12px 0 0;"><a href="<?php echo admin_url('edit.php'); ?>">All posts →</a>
            &nbsp; <a href="<?php echo admin_url('edit.php?post_status=draft'); ?>">All drafts →</a></p>
        </div>

        <!-- Bot cron status -->
        <div class="lmg-ps-card">
            <h2>Bot / cron schedule</h2>
            <?php if ( $crons ) : ?>
                <?php foreach ( $crons as $c ) : ?>
                <div class="lmg-cron-row">
                    <div class="lmg-cron-dot"></div>
                    <span class="lmg-cron-label"><?php echo esc_html( $c['label'] ); ?></span>
                    <span class="lmg-cron-next">next <?php echo date( 'd M H:i', $c['next'] ); ?> UTC</span>
                </div>
                <?php endforeach; ?>
            <?php else : ?>
                <p style="color:#888;font-size:.88em;">No known LMG bots scheduled on this site.</p>
            <?php endif; ?>
            <p style="margin:16px 0 0;font-size:.82em;color:#888;">
                All known hooks: <?php echo implode(', ', array_keys(lmg_ps_known_crons())); ?>
            </p>
        </div>

    </div>
    </div><!-- .wrap -->
    <?php
}
